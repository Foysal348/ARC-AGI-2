# Internal independent review of E26 K100 QUALITY (2026-11-01, Claude reviewer agent, read-only)

## Verdict
**GO** for the first 15-task build (sha 0e6f0159). One blocker was found for the 30-task rebuild: the report scope. It is fixed in sha 5896f992 and covered by tests.

## Checked with evidence (15-task build)
1. **Proven format**
   - Cells 1, 3, 4 and 6 are byte-identical to NB6 SUBMIT 87afcc84; cell 1 equals E18 R2's cell 1.
   - The only diffs are the marked K1-K10 edits.
   - Rerun path:
     - `PROFILE="RERUN_PROD"`;
     - the eval files load only `if not RERUN`;
     - the sha gate is skipped in the rerun;
     - the K7 gates are fatal only when not in the rerun;
     - the probe ARC file falls back to the test file;
     - every k100 step runs inside cell 8's `try`, so CELL 0's fallback submission stays.
2. **Boot plan**
   - `pin_tries` hits `K100_SEQS_TABLE` (21/18/14/9/6). `workers_rule(479, 4096, 6)` = 21, and the captures cover 21.
   - The argv equals the booted K3_ONLY v2. The intended differences are seqs 21, captures to 84, and `MERLIN_SHARE_DRAFT_WORKSPACE=1`.
   - The template / tokenizer shas equal K3 v2's.
3. **Payload**
   - The sha equals the pin, and the blobs are re-checked.
   - The mount paths match K3 v2.
   - If the payload is missing, CELL 1 raises within about a minute, before any GPU work.
4. **Duck phase:** the K100QUALITY row equals NB5QUALITY_R2 key for key. Deliberate differences: the budget, the fixed window, one phase, and the k100 levers.
5. **KV / workers:** about 22.8 blocks per worker, vs NB5's 23.8; NB5 had 0 preemptions.
6. **Gates:** gate_ok plus STATIC_SCALES_APPLIED (FP8). A fatal gate returns before the probes and before solving.
7. **Report:** NB5's FP8 data fed as "k100" gives 13/15 and 18/20; the run-report score equals the generated-attempts score; paired both 13.
8. **Time:** the plan sums to 114.5 ≤ 120 min. The ADMIT / DRAIN deadlines are not used in cells 3-9.

## Blocker for the 30-task build (fixed in 5896f992)
- **Missing order and groups:** the report call passed no `order` / `group_of`, so the k100 record covered only NB5's 15 while the score covered 30.
- **Naive order breaks the comparison:** passing `order` = 30 would count every new task as "W4 unsolved". That fakes discordant pairs, corrupts McNemar, and makes the delta compare 30 against 15.
- **Fix:** `scope_to_reference()` restricts paired / McNemar / delta / the attempt-1 table to NB5's 15. A separate 30-task summary is kept, and `vs_27b` gives the 27B and ARC Prize columns. Tests reproduce both failure modes.

## Notes (all addressed in 5896f992)
- **#60490 not verified:** the run would silently drop to the 6-worker rung. It is now a loud flag.
- **Misleading line:** NB5's `deployment_comparison: INCONCLUSIVE_UNEQUAL_WINDOWS` log line now reads "not applicable (single phase)".
- **Window shortened:** this is now flagged.
- **Push order:** the dataset version must be processed before the kernel push. This is recorded.
- **Recorded, not changed:** seqs 21 with captures to 84 is untested on klee100 (cards 2-3 had 1.19 GiB free at seqs 32 / caps 64); an OOM steps down the ladder. Preemption at long contexts is counted.
