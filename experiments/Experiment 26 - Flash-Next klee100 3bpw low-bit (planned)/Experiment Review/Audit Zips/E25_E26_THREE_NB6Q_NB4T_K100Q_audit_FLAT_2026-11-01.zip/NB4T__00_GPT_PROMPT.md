# E25 NB4T LEVERS: pre-GPU audit (blockers only)

**Answer first with one line: `GO` or `NO-GO`.** Then list **blockers only**: a defect that would crash the notebook, give a
wrong or misleading number or verdict, change the base config, break the hidden-rerun submission, or waste the GPU run. For
each blocker give the file, the line or function, the evidence, and the smallest fix. No style notes, no "nice to have",
no new arms, no new safety rules. If there is no blocker, say `GO` and stop.

## What the notebook is
`Q27-XHIGH-E25_NB4T_LEVERS.ipynb` (built by `build_e25_nb4t.py`; code in `nb4t_code_export.py`) is a ~120-minute GPU
measurement on Kaggle 4×L4 (Flash-Next W4 on Merlin 3.0.0, TP2 × PP2, FP8 KV, MTP K3, 8 streams). It measures the next speed
levers on top of the Q-defer winner of the NB4S run (`E25_NB4S_GPU_v1_2026-11-01.md`, `nb4s_verdict.json`).

| Arm (order) | Config = Q + exactly one change |
|---|---|
| Q (base) | NB4S's B config (NB1 R2 B3: FP8 KV, pin 3,553,580,524 B, `--language-model-only`, #60490, MTP K3, seqs 8, profiler) + the `nb4_ppack.py` rev 2 patch + `NB4_PPDEFER=1` (= NB4S QD, +21.1 % at 8k@8) |
| I8 | `DRAFT_HEAD=int8`, a Merlin `build()` knob (`tools/merlin/launch.py:319-322`, `:441`) → `--speculative-config ... "draft_lm_head_quant":"int8"`; K stays 3 |
| P26 | `VLLM_PP_LAYER_PARTITION=26,22` (exported after `build()`, overriding Merlin's 25,23 from `launch.py:373-374`) |
| P27 | `VLLM_PP_LAYER_PARTITION=27,21`; skipped when P26 OOMs (any launch try or BODY_OOM) |
| C12 | trailing `--max-num-seqs 12`, measured with 12 streams (8k@12 / 40k@12) against Q's 8k@8 / 40k@8; measure only, never the winner |

Per arm: boot; env read-back from the 4 workers (RPC `nb4s_env`); server-log config read-back (non-default args, `Draft
lm_head:` lines, `pipeline layers a-b` per stage); Q-defer read-back (`nb4_ppack.readback_label`); capacity facts (pool
blocks, max concurrency at 131,072, per-stage block bytes, unused pin per stage, per-rank free memory); greedy oracle vs Q
(EXACT / NEAR_TIE); 8k ×2 + profiled 8k + 40k windows; `nb4_timeline` per-stage compute, stall, parity.

## The NB4S fix carried over (please check it is right)
NB4S rejected its base because the base's profiled window split its micro-batches 7 / 1 (every arm was imbalanced too, QD the
same 7 / 1), and its `window_ok` also required a BALANCED histogram for every speed window (all NB4S windows were IMBALANCED).
In `nb4t_lib.py`:
- `parity_of` records every arm's parity (profile label + modal split, timeline verdict, every window's histogram label);
- `parity_compare` / `stall_compare`: the stall / per-stage comparison with Q is made only for the same parity label or the
  same (order-free) modal split, else `PARITY_DIFFERS`;
- `base_check` never rejects Q for parity (it needs DONE, gate PASS, env + config read-back OK, Q-defer ENGAGED);
- `window_ok` no longer has a parity condition (STEADY, running == level, 0 preemptions, tok/s);
- the throughput winner rule is unchanged: 8k speed PASS on both windows (gain > max(Q spread, 2 %)), both 40k windows
  valid, 40k gain ≥ −2 %; lever arms only. Test T6 re-judges the real NB4S records: QD → WIN +21.1 %.

## Rules the notebook must follow (user rules; do not propose changes to them)
- CELL 0 is E18 R2's cell 1 verbatim (= NB6's CELL 0): the hidden rerun writes only that identity `submission.json`.
- Each arm = Q + exactly one change; the never-do list (P2P on, LL128, NCCL CTA knobs, prefix caching off with MTP,
  `--no-async-scheduling`, COUNTERS=1, SSM bf16, ...) is enforced at plan and at launch.
- One OOM policy (NB4S): a launch OOM → one retry 0.25 GiB lower; a body OOM never retries.
- Budget: an arm starts only with `est_min × 60 + 300 s` left; hard stop 120 min; order Q > I8 > P26 > P27 > C12.
- The notebook stays < 400 kB (it is 349,989 B). Nothing below 60k thinking is involved (decode windows only).
- C12 changes no worker rule: it only measures.

## Known facts and estimates (not blockers by themselves; flag only if the code mishandles them)
- NB4S Q-run memory after ready (min of nvidia-smi and the worker): PP0 639 MiB free, PP1 191 MiB free; pool 215 blocks;
  block bytes 14.68 MB (PP0) / 16.52 MB (PP1) → PP1 binds, PP0 leaves ~379 MiB of its pin unused.
- One W4 layer ≈ 0.63-0.68 GiB per card → P26 may OOM at launch on PP0; P27 is then skipped by rule.
- The INT8 draft head is an extra ~310 MiB copy on each PP1 card (the BF16 target head stays) → I8 may OOM at launch on
  PP1 and then retry 0.25 GiB lower; the verdict records `pin.differs` and keeps the speed comparison (a lower pin removes
  KV blocks only; windows with 0 preemptions and running == level stay comparable).
- C12 40k@12 is predicted at or over the 215-block pool (12 × (ceil(46k / 4096) + F 7) ≈ 228); the window still runs,
  its preemptions / KV usage / running == level are recorded, and `capacity_predict` is stored in the window record.
- No `_C.gptq_marlin_repack` preflight: the INT8 copy is packed by `marlin_quantize` (pure torch) and run by
  `apply_gptq_marlin_linear`; NB2 SMOKE ran K2 + INT8 on the same Merlin build on GPU.
- The CPU kit cannot import `vllm._C`; vLLM's own argparse, `--help=all`, the #60490 qsa import and the
  `QuantizedDraftLMHead` import are recorded only there (as in the NB4S kits); the argv fields are checked by the
  notebook's own parser.

## Files in this zip (flat)
- Notebook + code: `Q27-XHIGH-E25_NB4T_LEVERS.ipynb`, `nb4t_code_export.py`, `build_e25_nb4t.py`, `nb4t_lib.py`,
  `nb4t_build_facts.json`, `kernel-metadata_gpu.json`.
- Embedded unchanged modules: `nb4_ppack.py` (rev 2), `nb4_timeline.py`; NB4S reference: `nb4s_lib.py`, `build_e25_nb4s.py`.
- Tests and kits: `nb4t_unit_tests.py` (253/253 local), `nb4t_fixture_nb4s_gpu_2026-11-01.json` (slim real NB4S records +
  log lines), `nb4t_unit_tests_local.log`, `build_e25_nb4t_cpu_kit.py`, `q27-e25-nb4t-kit-units.ipynb`,
  `q27-e25-nb4t-kit-real.ipynb`, `kernel-metadata_kit_units.json`, `kernel-metadata_kit_real.json`,
  `nb4t_kit_units_local.log`.
- Context: `E25_NB4S_GPU_v1_2026-11-01.md`, `nb4s_verdict.json`, `SPEED_GAP_ANALYSIS_docs_2026-11-01.md`.
- Merlin 3.0.0 (ad42e37) sources behind the flags: `merlin__tools_merlin_launch.py`,
  `merlin__vllm_model_executor_layers_draft_lm_head_quant.py`, `merlin__vllm_v1_worker_gpu_spec_decode_speculator.py`,
  `merlin__vllm_distributed_utils.py`, `merlin__vllm_config_speculative.py`, `merlin__vllm_model_executor_models_config.py`,
  `merlin__tools_merlin_registry.py`.
- `SHA256SUMS.json` (LF-normalized bytes).

## Output format
```
GO | NO-GO
Blockers:
1. <file>:<function / line> — <what breaks> — evidence — smallest fix
```
