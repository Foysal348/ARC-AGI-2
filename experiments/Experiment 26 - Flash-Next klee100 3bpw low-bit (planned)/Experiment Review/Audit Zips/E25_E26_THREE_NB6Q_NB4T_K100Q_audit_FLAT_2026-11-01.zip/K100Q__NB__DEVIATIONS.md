# E26 K100 QUALITY: deviations from NB5 QUALITY's FP8 phase (from the builder's report, 2026-11-01)

1. **Payloads in the dataset.**
   - With everything inline the notebook was 420 kB, over the 400 kB limit.
   - So nb5_lib, the klee100 blobs and the worker extension come from one sha-pinned dataset file (`k100q_payload_emb.json`). The lab file (`k100load_lab.py`) comes from the dataset, as klee100 LOAD does.
   - If the dataset is not attached, the notebook raises, as klee100 LOAD's lab loader does.
2. **Model path.**
   - `CKPT=/tmp/fn_klee100`, using klee100's `merge_ckpt`; there are no W4 parts.
   - K6 runs before every launch, there is a `--help` flag gate, and `VLLM_QSA_KV_SCALES` is set.
3. **Tokenizer.** Duck's tokenizer (its B3 reasoning counter) reads the klee100 mount's `tokenizer.json`, because the W4 p1 Model is not attached.
4. **Extra flags from K3 LOAD.**
   - `--language-model-only` and `--worker-extension-cls`.
   - `VLLM_SERVER_DEV_MODE=1`, for the method-map RPC.
5. **Pin ladder, seqs table and captures.**
   - The K3 ladder replaces RC2's pin + 1.0 GiB, with a seqs table per rung.
   - Captures go to 84 instead of CAPS16 (to 64), because CAPS16 would not cover 21 workers × (1 + K).
6. **Window and budget.** A fixed 4,050 s window instead of an equal split; one phase instead of two; a 120-min budget instead of 180.
7. **klee100 gates.** The method map and scales gates run before the probes. They are fatal in commit and only recorded in the rerun, the same rule NB5 applies to its contract probe.
8. **No oracle gate.** NB5 defines `oracle()` but never calls it in its gates, so none is added.
9. **Profiles.** RERUN_PROD is NB6's plus the klee100 boot levers. Only K100QUALITY and RERUN_PROD are allowed in this notebook.

**Inherited from NB5, recorded but not changed:**
- There is no in-run step-down: an OOM after the phases have started leads to NB5's relaunch at the base pin.
- At 120k the resident bound is 13, below the 21 workers. Preemptions are possible; they are counted and affect speed only.

## Added by the 30-task rebuild (sha 5896f992)
10. **Tasks:** 30 instead of 15. NB5's 15 come first, in NB5's order. Then `hard_long` (10) and `sometimes_new` (5), as new report groups.
11. **Window and budget:** a 6,600 s window (NB5: 4,050 s) and a 170-min budget. Only the attempt-1 comparison with W4 on the old 15 is strictly like for like.
12. **27B reference:** `k100q_ref27b.json` holds R3K2 hits / tokens and the ARC Prize xhigh pass. The basis for 20270e3b is "at least one R3K2 hit" (1 of 2 queries).
13. **Packing:** the embedded files use lzma + base85 instead of zlib + base64, to stay under 400 kB.
