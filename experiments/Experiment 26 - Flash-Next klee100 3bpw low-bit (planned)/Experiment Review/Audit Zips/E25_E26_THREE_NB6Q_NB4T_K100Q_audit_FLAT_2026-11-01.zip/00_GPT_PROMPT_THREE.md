# Pre-GPU audit of three notebooks (Kaggle ARC-AGI-2, 4×L4, Flash-Next on Merlin v3.0.0), 2026-11-01

All files are flat; read every file before answering. The prefix tells you which notebook a file belongs to:
- `NB6Q__`: the next production submission notebook;
- `NB4T__`: a speed-lever measurement notebook;
- `K100Q__`: the klee100 accuracy test.

Each prefix has its own detailed `<prefix>00_GPT_PROMPT.md`. Read that one first for each notebook.

The deadline is 2026-11-02, 23:59 UTC, and time is short. **Report ONLY blockers.** A blocker is something that would:
- give wrong raw data;
- crash or hang the run mid-way;
- waste GPU time;
- produce a misleading verdict or score;
- break the hidden-rerun submission.

For each blocker give file:function/line, a concrete scenario, evidence (a reproduction or exact lines) and a minimal fix. Start with three lines, one per notebook: `NB6Q: GO / NO-GO`, `NB4T: GO / NO-GO`, `K100Q: GO / NO-GO`.

## Shared background
**Evidence:** the NB4S GPU run (`NB6Q__E25_NB4S_GPU_v1_2026-11-01.md`), on W4, FP8 KV, MTP K3, 8 streams:
- Q-defer (deferred PP receive, `nb4_ppack.py` rev 2 + `NB4_PPDEFER=1`) gave +21.1 % at 8k@8 and +19.8 % at 40k@8;
- oracle EXACT;
- stage-0 false-dependency stall 19.8 → 0.035 ms;
- read-back ENGAGED (exec share 0.965, fallback 0).

**The user's proven submission format** (must be intact in every notebook):
- CELL 0 = E18 R2's cell 1;
- commit = the eval subset + score;
- rerun = all hidden test tasks in ORDER2 with E15B's writer;
- no sha gate in the rerun;
- E18 R2's server ladder, readiness, retry and fast kill.

**Rules kept on purpose (please do not re-raise without new evidence):**
- **Rerun gates are not fatal.** In the hidden rerun a stop only leaves the identity fallback (about zero score), so continuing is never worse.
- **No own safety rules.** Nothing is added beyond the proven notebooks.
- **NB5's worker rule** is kept in production.

## 1. NB6Q: `NB6Q__Q27-XHIGH-E25_NB6Q_SUBMIT.ipynb` (sha 9c74d125, 397,959 B)
- **What it is:** NB6 SUBMIT (sha 87afcc84, currently submitted to the competition) plus exactly one change, Q-defer. Diff: `NB6Q__NB6_to_NB6Q_cells.diff`.
- **The patch:** applied right after the Merlin install, with pre / post sha verification. `NB4_PPDEFER=1` is set only if the patch is verified.
- **On failure:** byte-exact restore, a loud log, and the run continues exactly like NB6.
- **Read-back:** record only.
- **Tests:**
  - local: 48/48;
  - NB6's units: 85/86 (the only fail is the expected push id);
  - nb4_ppack: 247/247.
- **CPU kits on Kaggle** (`NB6Q__KIT__*`):
  - units, e2e-rerun and e2e-commit: ALL OK;
  - real: all 6 Q-defer checks OK on the real installed Merlin tree (apply, post shas, revert, re-apply, every plan `NB4_PPDEFER=1`). Two checks are NOT OK, the same known CPU-only kit artefacts as NB6's own kit: the rerun / commit argv differ only by port, and vLLM argparse fails on CPU with a torch circular import.
- **Known, not changed:**
  - Q-defer was tested at 8 streams with short windows. NB6Q runs 9 workers, captures to 64, `MERLIN_SHARE_DRAFT_WORKSPACE=1`, and a 12-h Duck run.
  - A boot failure after a successful apply keeps Q-defer on for the next ladder rung.

## 2. NB4T: `NB4T__Q27-XHIGH-E25_NB4T_LEVERS.ipynb` (sha 675b1b9d, 349,989 B)
- **What it is:** a measurement notebook built on NB4S. Base Q = the NB4S base + Q-defer.
- **Arms** (each = Q + one change):

  | Arm | Change |
  |---|---|
  | I8 | INT8 draft LM head, `DRAFT_HEAD=int8` (Merlin `launch.py:319-322`) |
  | P26 | `VLLM_PP_LAYER_PARTITION=26,22` |
  | P27 | `VLLM_PP_LAYER_PARTITION=27,21` |
  | C12 | `--max-num-seqs 12` with 12 streams |

- **Per arm:** read-backs, oracle vs Q, 8k × 2 + 40k windows, a profiled timeline.
- **Hard stop:** 120 min.
- **NB4S verdict defect, fixed here:** NB4S rejected an imbalanced base. Now parity is recorded and compared between arms, and is never a base reject. Re-judging the NB4S records gives QD WIN +21.07 %.
- **Predicted capacity risks:**
  - P26 may OOM at launch (PP0 had 639 MiB free; one layer is about 0.65 GiB). It retries 0.25 GiB lower; P27 is skipped after a P26 OOM.
  - I8 adds about 310 MiB on each PP1 card (191 MiB free) and may need a lower pin.
  - 40k@12 needs about 228 blocks vs a 215-block pool, so it may preempt.
- **Tests:** local 253/253.
- **Kits on Kaggle:**
  - units: ALL OK;
  - real: 20 / 21 OK. `prompts_12_distinct` is a too-strict kit check: it expected exactly 12 prompts but found 34 (8k) and 16 (40k), all distinct and of the right lengths. The notebook takes `prompts[i % len]`, so 8-stream arms use NB4S's prompts 0-7 and C12 uses 12 distinct ones.

## 3. K100Q: `K100Q__Q27-XHIGH-E26_K100_QUALITY.ipynb` (sha f76d634e, 376,957 B)
- **What it is:** a 30-task ARC accuracy test of the klee100 low-bit checkpoint, plus Q-defer.
  - NB5 QUALITY's 15 tasks come first, compared with W4's 13/15.
  - Then 10 `hard_long` and 5 `sometimes_new` tasks.
- **Detail:** see `K100Q__00_GPT_PROMPT.md`. It covers the reporting fixes A-F, Q-defer and the kept rules.
- **Earlier GPT rounds:** they audited older shas (0e6f0159, 5896f992). Every confirmed item since then is fixed and tested; the list is in that prompt.
- **Tests:** units 117/117, report 50/50.
- **CPU kits:** built, not run yet. They need the staged dataset version pushed first.
