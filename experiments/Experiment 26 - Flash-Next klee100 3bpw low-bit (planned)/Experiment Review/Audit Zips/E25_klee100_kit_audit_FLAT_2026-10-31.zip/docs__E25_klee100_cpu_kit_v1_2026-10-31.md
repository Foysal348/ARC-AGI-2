# E25 klee100 compatibility CPU kit v1 (foysalemonshanto, sha 154328a3, 12.5 min) — 2026-10-31

Output: `_scratch/e25_kits_out_klee/q27-e25-klee100-cpu-kit/` (report, raw REAL record, 3 manifests, fixkeys overlay).
Verdict line `NOT OK: M1_MODULE_MAP, M3_WEIGHT_COVERAGE, GATE_A_QUANT_REAL`. Every remaining NOT OK is a CPU-container limit,
not a checkpoint or overlay defect:

| check | result | reading |
|---|---|---|
| inputs sha, fixkeys overlay | OK | |
| GATE_B_PLE | **OK** | on the mounted Merlin FP8 overlay: layout and hash buffers equal; cos_min 0.99951 over the rows; the row-order negative test fails as it should |
| GATE_C_MTP | **OK** | 4,651 MTP tensors, remap layer 0 → `mtp.layers.48`, W4 experts / W8 dense |
| GATE_D_MEMORY (estimate) | OK | 463 KV blocks (534 with pin headroom) vs 149 today |
| M3 static, negative rename | OK; `NO_GO_UNMAPPED_WEIGHT` | |
| GATE_A REAL (Merlin's own resolver, platform patched to CUDA 8.9) | 48 "bad" | all 48 expert layers resolve to **exactly the checkpoint's bits / group** (W3 g128 / W2 g64, 48 of 48 match). Each is flagged only because building the humming method object calls `cuInit` (`CUDA error 34`, no GPU with the stub libcuda). As published: 52 bad. |
| A param coverage | not OK | MTP experts: every checkpoint tensor has a created parameter; `w13_bias` / `w2_bias` are created but not fed. Benign: `auto_gptq.py:620-623` sets them to None when not loaded. W8 linears: `create_weights` needs an initialised tensor-parallel group (the harness's gloo group is not enough). |
| M1 / M3 REAL | not OK | depend on the REAL object builds above |
Conclusion: on CPU the overlay is proven as far as a CPU can go. The quantization resolution is correct for all 48 layers in
Merlin's own code; PLE and MTP pass. The remaining items (humming object, W8 create_weights, the full module build) need a GPU →
next step = a short GPU load test: boot (MTP off first) + short oracle + TF vs W4 BF16 + pool / per-rank HBM, then MTP on.

## v2 (sha b39db932, 14.0 min) — `@@KIT klee100 ALL OK@@`, label CPU_COMPATIBILITY_PASS
Output `_scratch/e25_kits_out_klee_v2/`. All 9 checks true (inputs, fixkeys, M1, M3, Gate A REAL, Gate B, Gate C, Gate D, K7).
- Gate A: RESOLUTION_PASS_CONSTRUCTION_GPU_ONLY — 48/48 target MoE layers resolve to the checkpoint bits / group; the 48 humming
  objects need a GPU to construct; all other quant modules constructed on meta; 0 construction errors; as published 28 bad.
- M3: M3_SAMPLED_REAL_OK; expert-id negatives (0→512, missing qzeros, missing MTP bank, duplicate id) all fail closed.
- Gate B: full sha256 of all 10 FP8 PLE shards OK (K3); cos_min 0.99951.
- K7: shard digest manifest (13 klee100 + 10 FP8 PLE) written for the GPU notebook (`klee100_shard_digests.json`).
- Gate D (estimate): 463 KV blocks.
Meaning: eligible for a GPU load attempt only (meta device, no-op weight loader; humming objects GPU-only). GPU load + accuracy: NOT_TESTED.
