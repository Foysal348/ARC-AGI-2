# File names in this flat zip
Every file sits at the top level. A path like `folder/sub/file` is stored as `folder__sub__file`.
