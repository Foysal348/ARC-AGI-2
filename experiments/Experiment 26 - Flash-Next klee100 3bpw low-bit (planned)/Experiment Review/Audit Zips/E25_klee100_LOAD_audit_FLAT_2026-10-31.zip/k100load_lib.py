"""E25 klee100 GPU load test: the pure parts (stdlib + numpy), embedded in the notebook and imported by the unit tests.

  build_model_dir   one model dir: symlinks to every klee100 file, the 10 FP8 PLE shards, the regenerated fixkeys overlay
  k6_check          every shard named in the index resolves to a file in the dir (K6), else no launch
  digest_plan       the files to stream-hash against the trusted HF LFS digest manifest (K7 + K3)
  verify_digests    streaming sha256 in parallel threads; any mismatch / missing / size difference is fatal before boot
  pin_ladder        --kv-cache-memory-bytes steps from the measured free memory per card (Merlin's pin rule ignores weights)
  tf_label / yardstick / tf_reading / final_label   verdict labels; never an accuracy PASS
"""
import hashlib
import json
import math
import os
import time
from pathlib import Path

GiB, MiB = 1 << 30, 1 << 20
OVERLAY_FILES = ("config.json", "quantization_config.json", "model.safetensors.index.json")
BF16_PLE_SHARD = "model-00001-of-00011.safetensors"          # excluded from the Kaggle Model (BF16 PLE, replaced by FP8)


# ===================================================================================== model dir (K6)
def build_model_dir(dst, k100_dir, ple_dir, overlay_dir, ple_files, link=None):
    """dst <- symlinks to every klee100 file (except the 3 overlay files), symlinks to the FP8 PLE shards, copies of the
    overlay files. Never follows a name outside the three source dirs. Returns the record (no hashing here)."""
    link = link or os.symlink
    dst, k100_dir, ple_dir, overlay_dir = Path(dst), Path(k100_dir), Path(ple_dir), Path(overlay_dir)
    if dst.exists():
        for p in dst.iterdir():
            if p.is_dir() and not p.is_symlink():
                raise RuntimeError(f"unexpected directory in the model dir: {p}")
            p.unlink()
    dst.mkdir(parents=True, exist_ok=True)
    rec = {"dir": str(dst), "klee100_links": [], "ple_links": [], "overlay_copies": {}, "skipped": [], "errors": []}
    for p in sorted(k100_dir.iterdir()):
        if p.is_dir():
            rec["skipped"].append(p.name + "/")
            continue
        if p.name in OVERLAY_FILES:
            rec["skipped"].append(p.name + " (overlay replaces it)")
            continue
        try:
            link(str(p), str(dst / p.name))
            rec["klee100_links"].append(p.name)
        except OSError as e:
            rec["errors"].append(f"link {p.name}: {e!r}"[:200])
    for n in ple_files:
        src = ple_dir / n
        if not src.is_file():
            rec["errors"].append(f"missing FP8 PLE shard {n}")
            continue
        if (dst / n).exists():
            rec["errors"].append(f"name clash {n}")
            continue
        try:
            link(str(src), str(dst / n))
            rec["ple_links"].append(n)
        except OSError as e:
            rec["errors"].append(f"link {n}: {e!r}"[:200])
    for n in OVERLAY_FILES:
        b = (overlay_dir / n).read_bytes()
        (dst / n).write_bytes(b)
        rec["overlay_copies"][n] = {"bytes": len(b), "sha256": hashlib.sha256(b).hexdigest()}
    rec["ok"] = not rec["errors"]
    return rec


def k6_check(ckpt):
    """K6: every shard file named in model.safetensors.index.json must exist in the dir (a symlink is resolved: a dangling
    link is missing). Also: the BF16 PLE shard must not be referenced, and config.json carries the FP8 PLE dtype."""
    ckpt = Path(ckpt)
    out = {"dir": str(ckpt)}
    try:
        idx = json.loads((ckpt / "model.safetensors.index.json").read_text())
        files = sorted(set(idx["weight_map"].values()))
    except Exception as e:
        return dict(out, ok=False, why=f"index unreadable: {type(e).__name__}: {e}"[:300], missing=None)
    missing = [f for f in files if not (ckpt / f).is_file()]
    out.update(index_files=len(files), index_tensors=len(idx["weight_map"]), missing=missing,
               bf16_ple_referenced=BF16_PLE_SHARD in files)
    try:
        cfg = json.loads((ckpt / "config.json").read_text())
        out["ple_embedding_dtype"] = (cfg.get("text_config") or {}).get("ple_embedding_dtype")
    except Exception as e:
        out["ple_embedding_dtype"] = f"unreadable: {e!r}"[:120]
    why = []
    if missing:
        why.append(f"K6_INDEXED_SHARD_MISSING: {missing[:5]} ({len(missing)} of {len(files)})")
    if out["bf16_ple_referenced"]:
        why.append("the index references the BF16 PLE shard " + BF16_PLE_SHARD)
    if out["ple_embedding_dtype"] != "float8_e4m3fn":
        why.append(f"config.json text_config.ple_embedding_dtype = {out['ple_embedding_dtype']!r}")
    out["ok"] = not why
    out["why"] = "; ".join(why) or None
    return out


# ===================================================================================== digests (K7 + K3)
def digest_plan(manifest, k100_dir, ple_dir, extra=("tokenizer.json",)):
    """(name, path, size, sha256, source) of every klee100 shard used (all except the BF16 PLE shard), the FP8 PLE shards and
    the small LFS files in `extra` (tokenizer.json; the original index is replaced by the overlay and checked separately)."""
    k100_dir, ple_dir = Path(k100_dir), Path(ple_dir)
    kd, md = manifest["repos"]["klee100"], manifest["repos"]["merlin_fp8_ple"]
    plan = []
    for f, v in sorted(kd["shards"].items()):
        if f == BF16_PLE_SHARD:
            continue
        plan.append((f, str(k100_dir / f), int(v["size"]), v["sha256"], "klee100 " + kd["revision"][:8]))
    for f in extra:
        v = (kd.get("other_lfs_files") or {}).get(f)
        if v:
            plan.append((f, str(k100_dir / f), int(v["size"]), v["sha256"], "klee100 " + kd["revision"][:8]))
    for f, v in sorted(md["shards"].items()):
        plan.append((f, str(ple_dir / f), int(v["size"]), v["sha256"], "merlin_fp8_ple " + md["revision"][:8]))
    return plan


def sha256_file(path, chunk=1 << 24):
    h = hashlib.sha256()
    n = 0
    with open(path, "rb") as fh:
        while True:
            b = fh.read(chunk)
            if not b:
                break
            h.update(b)
            n += len(b)
    return h.hexdigest(), n


def verify_digests(plan, threads=8, hasher=sha256_file, log=None):
    """Streaming sha256 of every planned file in `threads` threads (hashlib releases the GIL). Fail closed: a missing
    file, a size difference or a digest mismatch -> ok False. Sizes are checked before hashing (fast fail)."""
    from concurrent.futures import ThreadPoolExecutor
    t0 = time.time()
    res, pre = {}, []
    for name, path, size, want, src in plan:
        p = Path(path)
        if not p.is_file():
            res[name] = {"ok": False, "why": "missing", "path": path}
        elif p.stat().st_size != size:
            res[name] = {"ok": False, "why": f"size {p.stat().st_size} != {size}", "path": path}
        else:
            pre.append((name, path, size, want, src))

    def one(item):
        name, path, size, want, src = item
        t = time.time()
        try:
            got, n = hasher(path)
        except Exception as e:
            return name, {"ok": False, "why": f"read error {type(e).__name__}: {e}"[:200], "path": path}
        ok = got == want and n == size
        r = {"ok": ok, "sha256": got, "bytes": n, "sec": round(time.time() - t, 1), "source": src}
        if not ok:
            r["why"] = f"sha256 {got[:16]} != trusted {want[:16]}" if got != want else f"read {n} bytes != {size}"
        if log:
            log("digest", name, "OK" if ok else "MISMATCH", r["sec"], "s")
        return name, r
    with ThreadPoolExecutor(max_workers=max(1, int(threads))) as ex:
        for name, r in ex.map(one, pre):
            res[name] = r
    bad = sorted(n for n, r in res.items() if not r["ok"])
    gb = sum(r.get("bytes", 0) for r in res.values()) / 1e9
    sec = round(time.time() - t0, 1)
    return {"ok": not bad and len(res) == len(plan) and bool(plan), "bad": bad, "n_planned": len(plan), "n_checked": len(res),
            "gb": round(gb, 2), "sec": sec, "gb_per_s": round(gb / sec, 3) if sec else None, "threads": threads, "files": res}


# ===================================================================================== KV pin ladder
def stage_of_card(i, tp=2):
    """Merlin TP2 x PP2 with CUDA_VISIBLE_DEVICES=0,1,2,3 (PCI_BUS_ID): global rank r on device r, PP stage = r // TP
    (NB0 boot B: cards 0 / 1 held the 17.33 GiB PP0 weights, cards 2 / 3 the 16.13 GiB PP1 weights)."""
    return int(i) // tp


def free_by_card(readings):
    """nvidia-smi rows [[index, used_mib, total_mib], ...] (several readings) -> {index: total - max used}."""
    used, tot = {}, {}
    for row in readings or []:
        for r in row or []:
            if not isinstance(r, (list, tuple)) or len(r) < 3:
                continue
            i, u, t = int(r[0]), float(r[1]), float(r[2])
            used[i] = max(used.get(i, 0.0), u)
            tot[i] = t
    return {i: tot[i] - used[i] for i in sorted(tot)}


def pin_ladder(free_mib, base_pin, fracs=(0.9, 0.8, 0.7), safety_mib=1024, reserve_mib_pp1=0, n_cards=4, tp=2,
               align=2 * MiB, min_gain_mib=256):
    """Steps for --kv-cache-memory-bytes from the free memory per card measured at the base pin (all readings of the probe
    boot, the highest use counts). headroom(card) = free(card) - safety - reserve(card) (reserve = the MTP draft's weights
    + its workspace / graphs on the PP1 cards, which the MTP-off probe does not hold); pin(frac) = base + frac x min over
    cards of headroom, rounded down to `align`. Steps that add < min_gain_mib are dropped. Fail closed on missing cards."""
    out = {"base_pin": int(base_pin), "fracs": list(fracs), "safety_mib": safety_mib, "reserve_mib_pp1": reserve_mib_pp1,
           "free_mib_per_card": {str(k): v for k, v in (free_mib or {}).items()}}
    if not free_mib or len(free_mib) != n_cards or any(not isinstance(v, (int, float)) or not math.isfinite(v) or v < 0
                                                        for v in free_mib.values()):
        return dict(out, ok=False, steps=[], why=f"free memory per card not measured on all {n_cards} cards: {free_mib!r}"[:300])
    head = {i: f - safety_mib - (reserve_mib_pp1 if stage_of_card(i, tp) == 1 else 0) for i, f in free_mib.items()}
    hmin = min(head.values())
    out.update(headroom_mib_per_card={str(k): round(v, 1) for k, v in head.items()}, headroom_min_mib=round(hmin, 1),
               binding_card=min(head, key=head.get))
    steps = []
    for fr in fracs:
        add = fr * hmin
        if add < min_gain_mib:
            continue
        pin = int((int(base_pin) + int(add * MiB)) // align * align)
        steps.append({"frac": fr, "kv_bytes": pin, "gain_mib": round((pin - base_pin) / MiB, 1), "gib": round(pin / GiB, 3)})
    out["steps"] = steps
    out["ok"] = bool(steps)
    out["why"] = None if steps else f"no step adds >= {min_gain_mib} MiB (min headroom {hmin:.0f} MiB)"
    return out


def k2_pin_from_k(free_mib, pin, reserve_mib_pp1, min_free_mib=512, floor=0, tp=2, align=2 * MiB, lower_pin=None):
    """K2 (MTP K3) keeps K's pin when K's measured free memory per card (MTP off) covers the MTP reserve on the PP1 cards +
    min_free_mib on every card; otherwise the pin drops by the largest deficit (never below `floor`). `lower_pin` (K
    died of OOM in its teacher-forced call): K2 uses that lower ladder step instead."""
    if lower_pin is not None:
        p = max(int(floor), int(lower_pin))
        return {"kv_bytes": p, "gib": round(p / GiB, 3), "rule": "K_TF_OOM: the next lower ladder step", "deficit_mib": None}
    if not free_mib or not isinstance(pin, int) or isinstance(pin, bool):
        p = max(int(floor), int(pin or floor))
        return {"kv_bytes": p, "gib": round(p / GiB, 3), "rule": "SAME_PIN_AS_K (K's free memory not measured)", "deficit_mib": None}
    need = {i: min_free_mib + (reserve_mib_pp1 if stage_of_card(i, tp) == 1 else 0) for i in free_mib}
    deficit = max(need[i] - free_mib[i] for i in free_mib)
    if deficit <= 0:
        return {"kv_bytes": int(pin), "gib": round(pin / GiB, 3), "rule": "SAME_PIN_AS_K", "deficit_mib": round(deficit, 1),
                "need_mib": need}
    p = max(int(floor), int((int(pin) - int(math.ceil(deficit) * MiB)) // align * align))
    return {"kv_bytes": p, "gib": round(p / GiB, 3), "rule": "LOWERED: K's free memory does not hold the MTP reserve",
            "deficit_mib": round(deficit, 1), "need_mib": need}


def blocks_estimate(pin_bytes, ref_pin_bytes, ref_blocks):
    """Linear pool estimate from a measured (pin, blocks) pair: blocks ~ pin / bytes_per_block."""
    if not ref_blocks or not ref_pin_bytes:
        return None
    return int(pin_bytes / (ref_pin_bytes / ref_blocks))


# ===================================================================================== labels
SCREEN = {"rank1_min": 0.90, "mean_max": 0.15}       # NB0's screening thresholds (external audit 2)
TRIAGE = {"mean_max": 1.0, "rank1_min": 0.5}         # NB0's severe-discrepancy triage (external audit 3)
TF_RANK = {"LOWBIT_TF_CLOSE": 0, "LOWBIT_TF_DIVERGENT": 1, "LOWBIT_TF_DIVERGENT_SEVERE": 2}


def _fin(x):
    return isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x)


def tf_label(c):
    """One comparison (cmp_full / compare_tf record) -> LOWBIT_TF_CLOSE (inside NB0's screening limits: mean <= 0.15 and
    rank-1 >= 0.90) / LOWBIT_TF_DIVERGENT / LOWBIT_TF_DIVERGENT_SEVERE (NB0 triage: mean > 1.0 or rank-1 < 0.5) / INCONCLUSIVE_*."""
    if not isinstance(c, dict):
        return "INCONCLUSIVE_MISSING"
    if c.get("status") not in ("MEASURED", "PARTIAL"):
        return "INCONCLUSIVE_" + str(c.get("status") or "MISSING").replace("INCONCLUSIVE_", "")
    m, r1 = c.get("mean_abs_dlogprob"), c.get("rank1_agreement")
    if not (_fin(m) and _fin(r1)):
        return "INCONCLUSIVE_NONFINITE"
    if m > TRIAGE["mean_max"] or r1 < TRIAGE["rank1_min"]:
        return "LOWBIT_TF_DIVERGENT_SEVERE"
    if m <= SCREEN["mean_max"] and r1 >= SCREEN["rank1_min"]:
        return "LOWBIT_TF_CLOSE"
    return "LOWBIT_TF_DIVERGENT"


def yardstick(c, y):
    """klee100 vs W4 against NB0's FP8-KV vs BF16-KV divergence at the same band and metric (the change NB0 rejected):
    BELOW (smaller mean and higher rank-1), ABOVE (larger mean and lower rank-1), MIXED, or INCONCLUSIVE."""
    if not isinstance(c, dict) or not isinstance(y, dict) or not all(_fin(d.get(k)) for d in (c, y)
                                                                      for k in ("mean_abs_dlogprob", "rank1_agreement")):
        return {"vs_nb0_fp8_kv": "INCONCLUSIVE"}
    dm, dr = c["mean_abs_dlogprob"] - y["mean_abs_dlogprob"], c["rank1_agreement"] - y["rank1_agreement"]
    lab = "BELOW_NB0_FP8_KV" if (dm < 0 and dr > 0) else "ABOVE_NB0_FP8_KV" if (dm > 0 and dr < 0) else "MIXED"
    return {"vs_nb0_fp8_kv": lab, "mean_ratio": round(c["mean_abs_dlogprob"] / y["mean_abs_dlogprob"], 3) if y["mean_abs_dlogprob"] else None,
            "rank1_delta": round(dr, 4), "nb0_fp8_kv": {k: y.get(k) for k in ("mean_abs_dlogprob", "p99_abs_dlogprob", "rank1_agreement")}}


def tf_reading(per_band):
    """per_band {band: {"full": label, ...}} -> the worst full-prompt label over the measured bands (+ which band)."""
    labs = {b: (v or {}).get("label_full") for b, v in (per_band or {}).items()}
    meas = {b: l for b, l in labs.items() if l in TF_RANK}
    if not meas:
        return {"reading": "TF_NOT_MEASURED", "per_band": labs}
    worst = max(meas, key=lambda b: (TF_RANK[meas[b]], b))
    out = {"reading": meas[worst], "worst_band": worst, "per_band": labs}
    if len(meas) < len(labs):
        out["incomplete"] = sorted(set(labs) - set(meas))
    return out


def boot_clean(rec):
    return isinstance(rec, dict) and rec.get("status") in ("DONE",) and rec.get("correctness") == "CLEAN" and rec.get("config_ok") is True


def final_label(gates, k_rec, k2_rec, tf_read):
    """The notebook's one label. gates: ordered {name: (ok, why)} of the pre-boot gates (merge / K6 / overlay / digests /
    install / patch / probe boot). GPU_LOAD_PASS needs every gate, boot K clean (probes, sampled, complete garbage-free
    oracle, config read-back, no NaN) and boot K2 clean; the TF reading is appended, never an accuracy verdict."""
    for name, (ok, why) in (gates or {}).items():
        if ok is not True:
            return {"label": f"FAIL_{name}", "why": why, "accuracy": "NOT_TESTED (an ARC accuracy run is a separate step)"}
    if not boot_clean(k_rec):
        st = (k_rec or {}).get("status")
        return {"label": f"FAIL_BOOT_K_{st}" if st not in (None, "DONE") else f"FAIL_BOOT_K_{(k_rec or {}).get('correctness') or 'NOT_RUN'}",
                "why": (k_rec or {}).get("why") or (k_rec or {}).get("early_stop") or (k_rec or {}).get("config_mismatch"),
                "accuracy": "NOT_TESTED (an ARC accuracy run is a separate step)"}
    tfr = (tf_read or {}).get("reading", "TF_NOT_MEASURED")
    if not boot_clean(k2_rec):
        st = (k2_rec or {}).get("status")
        return {"label": f"GPU_LOAD_PASS_MTP_OFF_ONLY + {tfr}", "k2": st, "k2_correctness": (k2_rec or {}).get("correctness"),
                "why": (k2_rec or {}).get("why") or (k2_rec or {}).get("early_stop") or (k2_rec or {}).get("config_mismatch"),
                "accuracy": "NOT_TESTED (an ARC accuracy run is a separate step)"}
    return {"label": f"GPU_LOAD_PASS + {tfr}", "accuracy": "NOT_TESTED (an ARC accuracy run is a separate step)"}
