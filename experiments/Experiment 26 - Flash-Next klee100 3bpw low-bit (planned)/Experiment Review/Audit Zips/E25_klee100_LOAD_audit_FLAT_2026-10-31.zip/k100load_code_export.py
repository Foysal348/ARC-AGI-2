# ==================================================================== CELL 1 — config, inputs, lab module (RC2 verbatim + E25 klee100 marked edits)
import os, sys, json, math, time, re, shutil, subprocess, hashlib, tarfile, threading, traceback
import struct   # E25 klee100
from pathlib import Path
T_START = time.time()
MODE = "FULL"
RERUN = os.environ.get("KAGGLE_IS_COMPETITION_RERUN", "").strip().lower() in {"1", "true", "yes"}
FAKE = os.environ.get("E23_FAKE_SERVER")                          # local CPU harness only
BUDGET = int(os.environ.get("K100_BUDGET_SEC") or 120 * 60)    # E25 klee100: hard budget 120 min (K0 probe + K + K2)
HARD_STOP = T_START + BUDGET
MAX_LEN = 131072                                                  # user 2026-10-29: thinking up to 120k
OUT = Path(os.environ.get("E23_OUT", "/kaggle/working/k100"))   # E25 klee100
OUT.mkdir(parents=True, exist_ok=True)
LOGS = OUT / "logs"
LOGS.mkdir(exist_ok=True)
TRACES = OUT / "traces"                                           # memory rule: the full text of every long generation
TRACES.mkdir(exist_ok=True)
TMP = Path(os.environ.get("E23_TMP", "/tmp"))
INP = Path(os.environ.get("E23_INPUT", "/kaggle/input"))
R = {"what": "E25 klee100 GPU load test: klee100 3bpw-MTP on Merlin",   # E25 klee100
      "budget_min": BUDGET // 60, "max_len": MAX_LEN,
     "start_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "setup": {}, "sections": {}, "errors": [], "order": []}
_SAVE_LOCK = threading.Lock()
NB1_EXTRA, NB1_ENV, NB1_KV = {}, {}, {}   # E25 klee100 (NB1 hooks): per-boot trailing vllm flags, env and KV pin


def save():
    with _SAVE_LOCK:
        tmp = OUT / "k100_results.json.tmp"                      # E25 klee100
        tmp.write_text(json.dumps(R, indent=1, default=str))
        tmp.replace(OUT / "k100_results.json")                   # E25 klee100


def left():
    return HARD_STOP - time.time()


def log(*a):
    print(f"[{(time.time() - T_START) / 60:6.1f} min]", *a, flush=True)


COMP = INP / "competitions" / "arc-prize-2026-arc-agi-2"


def write_fallback_submission():
    tp = COMP / "arc-agi_test_challenges.json"
    if tp.is_file():
        tasks = json.load(open(tp))
        sub = {k: [{"attempt_1": [[0]], "attempt_2": [[0]]} for _ in v["test"]] for k, v in tasks.items()}
        Path(os.environ.get("RC2_SUBMISSION", "/kaggle/working/submission.json")).write_text(json.dumps(sub))


if RERUN:
    write_fallback_submission()
    print("E25 klee100 load test: competition rerun -> fallback submission.json only")
else:
    LAB_SRC = "\"\"\"E23 lab, rev 3: port-parameterized server lifecycle and measurement for the six-lever notebook (stdlib only).\n\nBase: the Exp 14 VMS harness (VServer / VGen: token ids from return_token_ids, [DONE] + finish_reason required, socket\nshutdown on stop, top-1/top-2 margins, garbage checks on every window). Adopted from the consolidated v3 notebook:\nsame-weight greedy oracle classified by the oracle's logprob margin at the first differing token, a steady decode window\nthat starts only after prefill settled, a GPU-release gate, fail-closed statuses, checkpoint identity, a runtime\n--help flag check, KV + GPU memory samples.\nrev 3 (validation agents 2026-10-29, measurement + robustness):\n  - port check by connect (a TIME_WAIT socket of the previous server is not \"busy\"), with a 90 s wait;\n  - kill(): SIGKILL the whole session after SIGTERM, even when the leader already exited;\n  - steady(): idle gate at entry, admission cap from the prefill to do (700 tok/s assumed), settle needs no preemption\n    and every running stream gaining tokens; in the window: stalled streams, a changing running/waiting set (KV-bound),\n    preemptions and prefills make it INCONCLUSIVE (numbers kept); garbage under load fails it; steps from the\n    vllm:iteration_tokens_total histogram count; replicas measured in one shared window (barrier);\n  - profiled_load(): settle as steady(), bounded profile (delay / max iterations), with_stack off, frontend ignored;\n  - trace_summary(): categories on the kernel base name (attention before GDN: \"fla\" is inside \"flashinfer\"), per-forward\n    graph / kernel launch counts inside the gpu_model_runner forward ranges (VLLM_CUSTOM_SCOPES_FOR_PROFILING=1) and the\n    CUPTI correlation fallback -> FULL / PIECEWISE / EAGER / UNKNOWN; startup cudagraph lines parsed explicitly;\n  - teacher_forced(): prompt logprobs of the last N positions of a long prompt (NVFP4 vs FP8 KV at 40k / 90k);\n  - logprobs keyed by token id (return_tokens_as_token_ids); stop() race closed; compare() flags garbage only when the\n    oracle itself is clean.\n\"\"\"\nimport gzip\nimport hashlib\nimport json\nimport os\nimport re\nimport signal\nimport socket\nimport statistics\nimport subprocess\nimport threading\nimport time\nimport urllib.request as U\nfrom pathlib import Path\n\nFAIL_MARGIN = 0.5          # first differing token: oracle top-1 minus top-2 logprob at or above this = real divergence\nLIVE = set()               # every running Server, for the hard-stop watchdog\n\n\n# ------------------------------------------------------------------ server lifecycle\ndef port_listening(port):\n    \"\"\"True when something accepts connections on 127.0.0.1:port (TIME_WAIT leftovers do not).\"\"\"\n    s = socket.socket()\n    s.settimeout(1.0)\n    try:\n        s.connect((\"127.0.0.1\", int(port)))\n        return True\n    except OSError:\n        return False\n    finally:\n        s.close()\n\n\nclass Server:\n    def __init__(self, name, argv, env, port, log_dir, gpus=\"0,1,2,3\"):\n        self.name, self.argv, self.env, self.port = name, [str(a) for a in argv], dict(env), int(port)\n        self.gpus = str(gpus)\n        self.log_path = Path(log_dir) / f\"server_{name}.log\"\n        self.proc, self.t0, self.ready_sec = None, None, None\n\n    @property\n    def url(self):\n        return f\"http://127.0.0.1:{self.port}\"\n\n    def start(self):\n        end = time.time() + 90\n        while port_listening(self.port):\n            if time.time() > end:\n                raise RuntimeError(f\"PORT_BUSY {self.port} (a listener is still there)\")\n            time.sleep(3)\n        self.log_path.parent.mkdir(parents=True, exist_ok=True)\n        self._fh = open(self.log_path, \"w\", encoding=\"utf-8\")\n        self.t0 = time.perf_counter()\n        self.proc = subprocess.Popen(self.argv, env=self.env, stdout=self._fh, stderr=subprocess.STDOUT,\n                                     start_new_session=True, cwd=\"/tmp\" if os.path.isdir(\"/tmp\") else None)\n        LIVE.add(self)\n        return self\n\n    def alive(self):\n        return self.proc is not None and self.proc.poll() is None\n\n    def log(self):\n        try:\n            return self.log_path.read_text(encoding=\"utf-8\", errors=\"replace\")\n        except Exception:\n            return \"\"\n\n    def rss_mb(self):\n        \"\"\"Host RAM of the server's whole session (engine + workers), MB; None off Linux.\"\"\"\n        try:\n            r = subprocess.run([\"ps\", \"-o\", \"rss=\", \"--sid\", str(self.proc.pid)], capture_output=True, text=True, timeout=20)\n            return round(sum(int(x) for x in r.stdout.split() if x.isdigit()) / 1024, 1)\n        except Exception:\n            return None\n\n    def wait_ready(self, timeout):\n        while time.perf_counter() - self.t0 < timeout:\n            if not self.alive():\n                return False, f\"exited rc={self.proc.returncode}\"\n            try:\n                U.urlopen(self.url + \"/health\", timeout=10).read()\n                self.ready_sec = round(time.perf_counter() - self.t0, 1)\n                return True, f\"ready in {self.ready_sec}s\"\n            except Exception:\n                time.sleep(3)\n        return False, \"startup timeout\"\n\n    def kill(self):\n        if self.proc is None:\n            return\n        pg = self.proc.pid\n        try:\n            os.killpg(pg, signal.SIGTERM) if hasattr(os, \"killpg\") else self.proc.terminate()\n        except Exception:\n            pass\n        try:\n            self.proc.wait(timeout=40)\n        except Exception:\n            pass\n        # rev 3: the leader may exit while EngineCore / workers of the session still hold GPUs: always SIGKILL the group\n        try:\n            os.killpg(pg, signal.SIGKILL) if hasattr(os, \"killpg\") else self.proc.kill()\n        except Exception:\n            pass\n        try:\n            self.proc.wait(timeout=30)\n        except Exception:\n            pass\n        try:\n            self._fh.close()\n        except Exception:\n            pass\n        LIVE.discard(self)\n\n    def facts(self):\n        \"\"\"What vLLM logged at startup: KV pool, max concurrency, selected kernels, graph mode, backend, KV dtype.\"\"\"\n        t = self.log()\n        kv = [int(x.replace(\",\", \"\")) for x in re.findall(r\"GPU KV cache size: ([\\d,]+) tokens\", t)]\n        mc = re.findall(r\"Maximum concurrency for [\\d,]+ tokens per request: ([\\d.]+)x\", t)\n        kern = sorted(set(re.findall(r\"Selected (\\w+Kernel) for\", t)))\n        errs = [l[:300] for l in t.splitlines() if re.search(r\"Traceback|CUDA error|illegal memory|out of memory|\"\n                                                               r\"RuntimeError|AssertionError\", l)][:12]\n        pick = lambda pat, n=8: [l.strip()[:240] for l in t.splitlines() if re.search(pat, l, re.I)][:n]\n        # rev 3 (measurement H5): the decisive startup evidence for the graph mode actually used with spec decode\n        downgrade = pick(r\"not supported with spec-decode.*setting cudagraph_mode|setting cudagraph_mode\\s*=|\"\n                         r\"[Oo]verriding cudagraph_mode to\", 4)       # rev 3e: + the 0.32 wording\n        capture = sorted(set(re.findall(r\"Capturing CUDA graphs \\(([^)]+)\\)\", t)))\n        configured = sorted(set(re.findall(r\"CUDAGraphMode\\.(\\w+)\", t)))\n        return {\"kv_tokens\": min(kv) if kv else None, \"kv_tokens_all\": kv, \"max_concurrency\": float(mc[-1]) if mc else None,\n                \"kernels\": kern, \"error_lines\": errs, \"ready_sec\": self.ready_sec,\n                \"graph_capture_modes\": capture, \"graph_downgrade_lines\": downgrade, \"cudagraph_modes_logged\": configured,\n                \"backend_lines\": pick(r\"attention backend|Using \\w+ backend|backend=|AttentionBackend\"),\n                \"kv_dtype_lines\": pick(r\"kv_cache_dtype|kv cache dtype|nvfp4\"),\n                \"host_embed_lines\": pick(r\"host[- _]?(resident|embed)|HOST_EMBED|embed.*(cpu|host)\", 6)}\n\n\ndef gpu_pids(gpus=None):\n    \"\"\"Compute PIDs on all GPUs, or only on the GPU indices in `gpus` (a bench on another GPU must not fail the release\n    gate of a server that used GPU 0 only). None when nvidia-smi is unavailable.\"\"\"\n    try:\n        a = subprocess.run([\"nvidia-smi\", \"--query-compute-apps=pid,gpu_uuid\", \"--format=csv,noheader,nounits\"],\n                           capture_output=True, text=True, timeout=30)\n        g = subprocess.run([\"nvidia-smi\", \"--query-gpu=index,uuid\", \"--format=csv,noheader,nounits\"],\n                           capture_output=True, text=True, timeout=30)\n    except Exception:\n        return None\n    if a.returncode or g.returncode:\n        return None\n    idx = {u.strip(): int(i) for i, u in (l.split(\",\", 1) for l in g.stdout.strip().splitlines() if \",\" in l)}\n    want = None if gpus is None else {int(x) for x in str(gpus).split(\",\") if str(x).strip() != \"\"}\n    out = set()\n    for l in a.stdout.strip().splitlines():\n        if \",\" not in l:\n            continue\n        pid, uuid = (x.strip() for x in l.split(\",\", 1))\n        if pid.isdigit() and (want is None or idx.get(uuid) in want):\n            out.add(int(pid))\n    return sorted(out)\n\n\ndef gpu_mem():\n    try:\n        r = subprocess.run([\"nvidia-smi\", \"--query-gpu=index,memory.used,memory.total\", \"--format=csv,noheader,nounits\"],\n                           capture_output=True, text=True, timeout=30)\n        return [[int(v) for v in l.split(\",\")] for l in r.stdout.strip().splitlines() if l.strip()]\n    except Exception:\n        return None\n\n\ndef wait_gpu_release(timeout=180, fake=False, gpus=None, free_mib=1024):\n    \"\"\"True when the GPUs in `gpus` (all when None) hold no compute PID AND use < free_mib MiB each (rev 3: compute-app\n    PIDs are often invisible inside Kaggle containers; memory.used is the proven E18 gate); None without nvidia-smi.\"\"\"\n    if fake:\n        return True\n    want = None if gpus is None else {int(x) for x in str(gpus).split(\",\") if str(x).strip() != \"\"}\n    end = time.time() + timeout\n    while time.time() < end:\n        p, mem = gpu_pids(gpus), gpu_mem()\n        if p is None or mem is None:\n            return None\n        used = [m[1] for m in mem if want is None or m[0] in want]\n        if not p and all(u < free_mib for u in used):\n            return True\n        time.sleep(3)\n    return False\n\n\ndef identity(model_dir):\n    \"\"\"Checkpoint identity: sha256 of config / tokenizer / index files (an oracle is only compared with the same weights).\"\"\"\n    root = Path(model_dir)\n    files = [p for n in (\"config.json\", \"tokenizer.json\", \"tokenizer_config.json\", \"generation_config.json\")\n             for p in [root / n] if p.is_file()] + sorted(root.glob(\"*.safetensors.index.json\"))\n    h = hashlib.sha256()\n    for p in files:\n        h.update(p.name.encode())\n        h.update(hashlib.sha256(p.read_bytes()).digest())\n    return {\"dir\": str(root), \"files\": [p.name for p in files], \"sha256\": h.hexdigest()[:16]}\n\n\n_HELP = {}\n\n\ndef help_check(key, argv_prefix, env, flags, timeout=300):\n    \"\"\"The engine's own `serve --help=all` (run once per engine `key`, cached) must list every flag of THIS launch\n    (rev 3: every launch is checked, not only the first); returns the missing ones.\"\"\"\n    if key not in _HELP:\n        try:\n            r = subprocess.run(list(argv_prefix) + [\"--help=all\"], capture_output=True, text=True, timeout=timeout, env=env)\n            _HELP[key] = r.stdout + r.stderr\n        except Exception as e:\n            _HELP[key] = \"ERROR \" + repr(e)[:200]\n    txt = _HELP[key]\n    if len(txt) < 2000:\n        return {\"ran\": False, \"error\": \"help output too short or failed\", \"tail\": txt[-400:]}\n    want = sorted({f for f in flags if isinstance(f, str) and f.startswith(\"--\")})\n    return {\"ran\": True, \"missing\": [f for f in want if f not in txt]}\n\n\ndef start_watchdog(hard_stop_epoch, on_fire):\n    \"\"\"A real hard stop: at `hard_stop_epoch` every live Server is killed and on_fire() is called.\"\"\"\n    def run():\n        while time.time() < hard_stop_epoch:\n            time.sleep(5)\n        try:\n            on_fire()\n        finally:\n            for s in list(LIVE):\n                try:\n                    s.kill()\n                except Exception:\n                    pass\n    t = threading.Thread(target=run, daemon=True, name=\"e23-watchdog\")\n    t.start()\n    return t\n\n\ndef prefetch(paths, threads=16, chunk=16 << 20):\n    \"\"\"Read files once with many readers (page cache warm-up of a cold /kaggle/input mount); returns bytes and seconds.\"\"\"\n    files = [p for root in paths for p in sorted(Path(root).rglob(\"*\")) if p.is_file()]\n    t0, done, lock = time.time(), [0], threading.Lock()\n\n    def worker(fs):\n        for p in fs:\n            try:\n                with open(p, \"rb\") as f:\n                    while True:\n                        b = f.read(chunk)\n                        if not b:\n                            break\n                        with lock:\n                            done[0] += len(b)\n            except Exception:\n                pass\n    big = sorted(files, key=lambda p: -p.stat().st_size)\n    parts = [big[i::threads] for i in range(threads)]\n    ths = [threading.Thread(target=worker, args=(x,), daemon=True) for x in parts if x]\n    for t in ths:\n        t.start()\n    for t in ths:\n        t.join()\n    dt = time.time() - t0\n    return {\"files\": len(files), \"bytes\": done[0], \"sec\": round(dt, 1), \"MBps\": round(done[0] / 1e6 / max(dt, 1e-3), 1)}\n\n\n# ------------------------------------------------------------------ metrics\ndef prom(port):\n    txt = U.urlopen(f\"http://127.0.0.1:{port}/metrics\", timeout=15).read().decode(\"utf-8\", \"replace\")\n    out = {}\n    for line in txt.splitlines():\n        if not line or line.startswith(\"#\"):\n            continue\n        m = re.match(r\"^([A-Za-z_:][A-Za-z0-9_:]*)(\\{[^}]*\\})?\\s+(\\S+)\", line)\n        if not m:\n            continue\n        try:\n            v = float(m.group(3))\n        except ValueError:\n            continue\n        if v != v:\n            continue\n        out[m.group(1)] = out.get(m.group(1), 0.0) + v\n        out[m.group(1) + \"@max\"] = max(out.get(m.group(1) + \"@max\", v), v)\n    return out\n\n\nGEN, PROMPT, RUN, WAIT = (\"vllm:generation_tokens_total\", \"vllm:prompt_tokens_total\", \"vllm:num_requests_running\",\n                          \"vllm:num_requests_waiting\")\nPREEMPT, KVU, ITER = \"vllm:num_preemptions_total\", \"vllm:kv_cache_usage_perc\", \"vllm:iteration_tokens_total_count\"\nACC, DRF, DTOK = (\"vllm:spec_decode_num_accepted_tokens_total\", \"vllm:spec_decode_num_drafts_total\",\n                  \"vllm:spec_decode_num_draft_tokens_total\")\n\n\n# ------------------------------------------------------------------ one streaming request (Exp 14 VGen, port-aware)\nclass Stream(threading.Thread):\n    def __init__(self, port, ids, max_new, temperature=1.0, seed=None, logprobs=0, ignore_eos=True, model=\"q27\"):\n        super().__init__(daemon=True)\n        self.port = int(port)\n        self.body = {\"model\": model, \"prompt\": list(ids), \"max_tokens\": int(max_new), \"temperature\": temperature,\n                     \"top_p\": 0.95 if temperature else 1.0, \"stream\": True, \"ignore_eos\": ignore_eos, \"return_token_ids\": True}\n        if temperature:\n            self.body[\"top_k\"] = 20\n        if seed is not None:\n            self.body[\"seed\"] = int(seed)\n        if logprobs:\n            self.body[\"logprobs\"] = int(logprobs)\n            self.body[\"return_tokens_as_token_ids\"] = True      # rev 3: logprob keys by id (no string collisions)\n        self.text, self.tokens, self.margins = [], [], []\n        self.err, self.done_seen, self.finish_reason = None, False, None\n        self.t_start = self.t_first = self.t_end = None\n        self._resp, self._halt = None, False\n\n    def run(self):\n        self.t_start = time.perf_counter()\n        try:\n            req = U.Request(f\"http://127.0.0.1:{self.port}/v1/completions\", data=json.dumps(self.body).encode(),\n                            method=\"POST\", headers={\"Content-Type\": \"application/json\"})\n            self._resp = U.urlopen(req, timeout=7200)\n            for raw in self._resp:\n                if self._halt:\n                    break\n                line = raw.strip()\n                if not line.startswith(b\"data:\"):\n                    continue\n                payload = line[5:].strip()\n                if payload == b\"[DONE]\":\n                    self.done_seen = True\n                    break\n                d = json.loads(payload)\n                if \"error\" in d or d.get(\"object\") == \"error\":\n                    self.err = (\"stream error: \" + json.dumps(d.get(\"error\") or d.get(\"message\") or d))[:300]\n                    break\n                for c in d.get(\"choices\") or []:\n                    self.text.append(c.get(\"text\") or \"\")\n                    ids_ = c.get(\"token_ids\")\n                    lp = c.get(\"logprobs\") or {}\n                    if ids_ is None:\n                        if c.get(\"text\") or lp.get(\"tokens\"):\n                            self.err = \"MISSING_STREAM_TOKEN_IDS\"\n                    elif any(not isinstance(v, int) or isinstance(v, bool) for v in ids_):\n                        self.err = \"INVALID_STREAM_TOKEN_IDS\"\n                    else:\n                        if ids_ and self.t_first is None:\n                            self.t_first = time.perf_counter()\n                        self.tokens.extend(ids_)\n                    for top in lp.get(\"top_logprobs\") or []:\n                        vals = sorted((v for v in (top or {}).values() if isinstance(v, (int, float))), reverse=True)\n                        self.margins.append(round(vals[0] - vals[1], 4) if len(vals) >= 2 else None)\n                    if c.get(\"finish_reason\") is not None:\n                        self.finish_reason = c[\"finish_reason\"]\n                if self.err:\n                    break\n        except Exception as e:\n            if not self._halt:\n                self.err = repr(e)[:300]\n        finally:                         # rev 3: a stop() before the response existed still closes the socket here\n            try:\n                if self._resp is not None:\n                    self._resp.close()\n            except Exception:\n                pass\n        self.t_end = time.perf_counter()\n        if not self._halt and not self.err and not (self.done_seen and self.finish_reason):\n            self.err = f\"INCOMPLETE_SSE done={self.done_seen} finish={self.finish_reason}\"\n\n    def stop(self):\n        self._halt = True\n        try:\n            self._resp.fp.raw._sock.shutdown(socket.SHUT_RDWR)\n        except Exception:\n            pass\n        try:\n            if self._resp is not None:\n                self._resp.close()\n        except Exception:\n            pass\n\n    def row(self):\n        return {\"text\": \"\".join(self.text), \"tokens\": list(self.tokens), \"margins\": list(self.margins), \"error\": self.err,\n                \"done\": self.done_seen, \"finish_reason\": self.finish_reason}\n\n\n# ------------------------------------------------------------------ correctness\ndef greedy(port, prompts, n_tok=128, logprobs=2, timeout=900, model=\"q27\"):\n    \"\"\"Greedy rows for the same-weight oracle (one request at a time: batch-size effects stay out of the comparison).\"\"\"\n    rows = []\n    for ids in prompts:\n        g = Stream(port, ids, n_tok, temperature=0.0, logprobs=logprobs, ignore_eos=True, model=model)\n        g.start()\n        g.join(timeout)\n        if g.is_alive():\n            g.stop()\n            g.join(10)\n            r = g.row()\n            r[\"error\"] = r[\"error\"] or \"GREEDY_TIMEOUT\"\n        else:\n            r = g.row()\n        rows.append(r)\n    return rows\n\n\ndef degenerate(text):\n    \"\"\"Objective garbage checks: empty, a run of one char, '!!!!' (the E3 / E13 garbage), very low variety.\"\"\"\n    t = text or \"\"\n    if not t.strip():\n        return \"EMPTY\"\n    if re.search(r\"(\\S)\\1{200,}\", t, re.S):      # rev 3: grid rows / separators are not garbage\n        return \"REPEATED_CHAR\"\n    if t.count(\"!\") > 0.5 * max(1, len(t)):\n        return \"BANG_GARBAGE\"\n    words = re.findall(r\"[A-Za-z]{3,}\", t)            # rev 3c: words only; ARC grid dumps (digits) are not garbage\n    if len(words) > 60 and len(set(words)) < 0.08 * len(words):\n        return \"LOW_VARIETY\"\n    return None\n\n\ndef compare(ref, cand):\n    \"\"\"Same-weight oracle: at the first differing token the ORACLE's top-1 - top-2 logprob margin decides:\n    >= FAIL_MARGIN -> FAIL_HIGH_MARGIN, below -> NEAR_TIE; identical -> EXACT; missing data -> INCONCLUSIVE.\"\"\"\n    if not ref or not cand or len(ref) != len(cand):\n        return {\"status\": \"INCONCLUSIVE_PAIRS_MISSING\"}\n    per, worst = [], \"EXACT\"\n    rank = {\"EXACT\": 0, \"NEAR_TIE\": 1, \"INCONCLUSIVE\": 2, \"FAIL_HIGH_MARGIN\": 3}\n    for a, b in zip(ref, cand):\n        if a.get(\"error\") or b.get(\"error\") or not a.get(\"tokens\") or not b.get(\"tokens\"):\n            st, d, m = \"INCONCLUSIVE\", None, None\n        else:\n            x, y = a[\"tokens\"], b[\"tokens\"]\n            d = next((i for i in range(min(len(x), len(y))) if x[i] != y[i]), None)\n            if d is None:\n                st, m = (\"EXACT\" if len(x) == len(y) else \"INCONCLUSIVE\"), None\n            else:\n                mm = a.get(\"margins\") or []\n                m = mm[d] if d < len(mm) else None\n                st = \"INCONCLUSIVE\" if m is None else (\"FAIL_HIGH_MARGIN\" if m >= FAIL_MARGIN else \"NEAR_TIE\")\n        g = degenerate(b.get(\"text\")) if (b.get(\"tokens\") and not b.get(\"error\")) else None\n        if g and degenerate(a.get(\"text\")) is None:           # rev 3c: a request error is not corruption\n            st = \"FAIL_HIGH_MARGIN\"\n        per.append({\"first_diff\": d, \"oracle_margin\": m, \"status\": st, \"garbage\": g})\n        worst = st if rank[st] > rank[worst] else worst\n    return {\"status\": worst, \"rows\": per}\n\n\ndef chat_probes(port, model=\"q27\", cases=((\"Reply with exactly one number: 7 * 6 =\", \"42\"),\n                                          (\"Reply with exactly one number: 2 + 2 =\", \"4\"),\n                                          (\"Reply with exactly one number: 9 - 3 =\", \"6\")), timeout=300):\n    \"\"\"Arithmetic through /v1/chat/completions with thinking off. vLLM 0.32 returns the answer in message.content and\n    the thinking in message.reasoning (NOT reasoning_content: the consolidated notebook's blocker).\"\"\"\n    out = []\n    for q, want in cases:\n        body = {\"model\": model, \"messages\": [{\"role\": \"user\", \"content\": q}], \"temperature\": 0, \"max_tokens\": 32,\n                \"chat_template_kwargs\": {\"enable_thinking\": False}}\n        try:\n            r = json.loads(U.urlopen(U.Request(f\"http://127.0.0.1:{port}/v1/chat/completions\", data=json.dumps(body).encode(),\n                                               headers={\"Content-Type\": \"application/json\"}), timeout=timeout).read())\n            msg = r[\"choices\"][0][\"message\"]\n            got = (msg.get(\"content\") or \"\").strip()\n            out.append({\"q\": q, \"want\": want, \"content\": got[:80], \"reasoning_chars\": len(msg.get(\"reasoning\") or \"\"),\n                        \"ok\": re.search(r\"(?<!\\d)\" + want + r\"(?!\\d)\", got) is not None})\n        except Exception as e:\n            out.append({\"q\": q, \"want\": want, \"error\": repr(e)[:200], \"ok\": False})\n    return {\"ok\": all(x[\"ok\"] for x in out), \"cases\": out}\n\n\ndef template_probe(port, messages, want_ids, model=\"q27\", timeout=120):\n    \"\"\"rev 3h (three GPT SMOKE audits): what the SERVER's chat path renders for `messages` (its own template and default\n    chat-template kwargs, no per-request kwargs) against the production xhigh render `want_ids`. MATCH / MISMATCH /\n    ERROR; the load requests themselves use pre-rendered ids, so this shows chat-path equivalence only.\"\"\"\n    body = {\"model\": model, \"messages\": messages, \"add_generation_prompt\": True}\n    try:\n        r = json.loads(U.urlopen(U.Request(f\"http://127.0.0.1:{port}/tokenize\", data=json.dumps(body).encode(),\n                                           headers={\"Content-Type\": \"application/json\"}), timeout=timeout).read())\n        got = list(r.get(\"tokens\") or [])\n    except Exception as e:\n        return {\"status\": \"ERROR\", \"error\": repr(e)[:200]}\n    want = list(want_ids)\n    first = next((i for i, (a, b) in enumerate(zip(got, want)) if a != b), None if len(got) == len(want) else min(len(got), len(want)))\n    return {\"status\": \"MATCH\" if got == want else \"MISMATCH\", \"server_tokens\": len(got), \"want_tokens\": len(want),\n            \"first_diff\": first}\n\n\ndef teacher_forced(port, ids, last=256, model=\"q27\", timeout=1800):\n    \"\"\"rev 3 (measurement M3): prompt logprobs of the last `last` positions of a long prompt (one prefill, 1 token out),\n    for a lossy-KV comparison (NVFP4 vs FP8 KV) at the context lengths that matter. Returns per-position\n    [logprob of the actual token, its rank, the engine's own rank-1 token id] or an error. rev 3h (three GPT SMOKE\n    audits): the rank-1 token id is kept, so top-1 agreement compares the two engines' predictions.\"\"\"\n    body = {\"model\": model, \"prompt\": list(ids), \"max_tokens\": 1, \"temperature\": 0, \"prompt_logprobs\": 1,\n            \"return_tokens_as_token_ids\": True}\n    try:\n        r = json.loads(U.urlopen(U.Request(f\"http://127.0.0.1:{port}/v1/completions\", data=json.dumps(body).encode(),\n                                           headers={\"Content-Type\": \"application/json\"}), timeout=timeout).read())\n        pl = r[\"choices\"][0].get(\"prompt_logprobs\") or []\n    except Exception as e:\n        return {\"error\": repr(e)[:300]}\n    out = []\n    for pos in range(max(1, len(ids) - last), len(ids)):\n        d = pl[pos] if pos < len(pl) else None\n        if not isinstance(d, dict):\n            out.append(None)\n            continue\n        e = d.get(str(ids[pos])) or d.get(f\"token_id:{ids[pos]}\")     # rev 3c: no fallback to another token\n        top1 = [_tok_id(k) for k, v in d.items() if isinstance(v, dict) and v.get(\"rank\") == 1]\n        out.append([e.get(\"logprob\"), e.get(\"rank\"), top1[0] if len(top1) == 1 else None] if isinstance(e, dict) else None)\n    return {\"positions\": out, \"n\": len(out)}\n\n\ndef _tok_id(k):\n    \"\"\"A prompt-logprob key ('123' or 'token_id:123') as an int id; anything else stays a tagged string.\"\"\"\n    m = re.fullmatch(r\"(?:token_id:)?(-?\\d+)\", str(k))\n    return int(m.group(1)) if m else \"str:\" + str(k)\n\n\ndef compare_tf(ref, cand):\n    \"\"\"Teacher-forced comparison: mean / max |delta logprob| of the actual tokens and rank-1 agreement. rev 3d (four\n    GPT audits): MEASURED only when EVERY expected position is valid on both sides (1 of 256 used to be MEASURED);\n    MEASURED is a measurement, not a PASS (the caller applies the A/A-derived tolerance).\"\"\"\n    if not ref or not cand or ref.get(\"error\") or cand.get(\"error\"):\n        return {\"status\": \"INCONCLUSIVE\"}\n    a_, b_ = ref.get(\"positions\") or [], cand.get(\"positions\") or []\n    if not a_ or len(a_) != len(b_):\n        return {\"status\": \"INCONCLUSIVE_INCOMPLETE_TF\", \"ref_n\": len(a_), \"cand_n\": len(b_)}\n    if any(not a or not b or a[0] is None or b[0] is None for a, b in zip(a_, b_)):\n        return {\"status\": \"INCONCLUSIVE_INCOMPLETE_TF\", \"valid\": sum(1 for a, b in zip(a_, b_) if a and b and a[0] is not None\n                                                                     and b[0] is not None), \"expected\": len(a_)}\n    pairs = list(zip(a_, b_))\n    if any(len(a) < 3 or len(b) < 3 or a[2] is None or b[2] is None for a, b in pairs):\n        return {\"status\": \"INCONCLUSIVE_TOP1_MISSING\", \"expected\": len(pairs),\n                \"with_top1\": sum(1 for a, b in pairs if len(a) >= 3 and len(b) >= 3 and a[2] is not None and b[2] is not None)}\n    d = sorted(abs(a[0] - b[0]) for a, b in pairs)\n    # rev 3h (three GPT SMOKE audits): top-1 agreement = both engines predict the same rank-1 token id. rev 3d-3g counted\n    # \"the forced token is rank 1 on both sides or on neither\", which reads 1.0 for ranks 2 vs 3.\n    r1 = sum(1 for a, b in pairs if a[2] == b[2]) / len(pairs)\n    both = sum(1 for a, b in pairs if (a[1] == 1) == (b[1] == 1)) / len(pairs)\n    p99 = d[min(len(d) - 1, int(round(0.99 * (len(d) - 1))))]          # rev 3e: robust to one outlier position\n    return {\"status\": \"MEASURED\", \"n\": len(pairs), \"mean_abs_dlogprob\": round(statistics.mean(d), 4),\n            \"p99_abs_dlogprob\": round(p99, 3), \"max_abs_dlogprob\": round(d[-1], 3), \"rank1_agreement\": round(r1, 4),\n            \"forced_token_rank1_both_or_neither\": round(both, 4)}\n\n\ndef tf_complete(rows):\n    \"\"\"rev 3e: a teacher-forced row set counts as a reference only when every position of every band is valid\n    (rev 3h: including the rank-1 token id).\"\"\"\n    return bool(rows) and all(isinstance(r, dict) and not r.get(\"error\") and r.get(\"positions\") and\n                              all(p and p[0] is not None and len(p) >= 3 and p[2] is not None for p in r[\"positions\"])\n                              for r in rows.values())\n\n\n# ------------------------------------------------------------------ steady decode\ndef steady(port, prompts, level, secs=60.0, admit=None, max_new=8192, temperature=1.0, seed=1234, model=\"q27\",\n           sample=2.0, prefill_tok_s=700.0, gpu_sample=True, barrier=None):\n    \"\"\"`level` distinct prompts, then a decode window that starts only once prefill has settled. Status:\n    STEADY / CAPACITY_LIMITED (fewer running than asked: KV) / INCONCLUSIVE_* / FAIL_*; numbers are kept on an\n    INCONCLUSIVE window so a KV census survives; never a made-up number. `barrier` (steady_multi) starts every replica's\n    window at the same moment.\"\"\"\n    plen = len(prompts[0]) if prompts else 0\n    admit = admit or max(420.0, 120.0 + level * plen / prefill_tok_s)\n    r = {\"level\": level, \"status\": \"INCONCLUSIVE_NOT_STARTED\", \"port\": port, \"prompt_tokens\": plen, \"max_new\": max_new,\n         \"admit_limit_sec\": round(admit)}\n    if not wait_idle(port, 60):\n        r[\"status\"] = \"INCONCLUSIVE_NOT_IDLE_AT_START\"\n        if barrier:\n            barrier.abort()\n        return r\n    try:\n        p0 = prom(port)\n    except Exception as e:\n        r.update(status=\"INCONCLUSIVE_METRICS_UNAVAILABLE\", error=repr(e)[:200])\n        if barrier:\n            barrier.abort()\n        return r\n    if GEN not in p0 or PROMPT not in p0:\n        r[\"status\"] = \"INCONCLUSIVE_COUNTERS_MISSING\"\n        if barrier:\n            barrier.abort()\n        return r\n    ss = [Stream(port, prompts[i % len(prompts)], max_new, temperature, seed + i, model=model) for i in range(level)]\n    for g in ss:\n        g.start()\n    try:\n        t_adm, best, settled, prev, samples, flat_since = time.perf_counter(), 0, 0, None, [], None\n        last_tok = [0] * len(ss)\n        while time.perf_counter() - t_adm < admit:\n            time.sleep(sample)\n            if all(not g.is_alive() for g in ss):          # rev 3: checked before the metrics read (a dead server)\n                r.update(status=\"INCONCLUSIVE_STREAMS_ENDED_IN_ADMISSION\", errors=[g.err for g in ss if g.err][:3])\n                if barrier:\n                    barrier.abort()                       # rev 3c: the other replicas must not wait for this one\n                return r\n            try:\n                m = prom(port)\n            except Exception:\n                continue\n            run, wait, pt, pre = int(m.get(RUN, 0)), int(m.get(WAIT, 0)), m.get(PROMPT), m.get(PREEMPT, 0)\n            now_tok = [len(g.tokens) for g in ss]\n            first = sum(g.t_first is not None for g in ss)\n            gaining = sum(1 for a, b in zip(last_tok, now_tok) if b > a)\n            last_tok = now_tok\n            best = max(best, run)\n            samples.append([round(time.perf_counter() - t_adm, 1), run, wait, first, gaining])\n            # rev 3: no preemption in the sample, every running request emitted and is gaining tokens\n            calm = run > 0 and prev is not None and pt == prev[0] and pre == prev[1] and first >= run and gaining >= run\n            if calm and run >= level and wait == 0:\n                settled += 1\n            elif calm and run < level and wait > 0:       # KV-bound: the rest wait; accept a plateau held 30 s\n                flat_since = flat_since or time.perf_counter()\n                settled = settled + 1 if time.perf_counter() - flat_since > 30 else 0\n            else:\n                settled, flat_since = 0, None\n            prev = (pt, pre)\n            if settled >= 3:\n                break\n        r[\"admission\"] = {\"sec\": round(time.perf_counter() - t_adm, 1), \"best_running\": best, \"tail\": samples[-6:],\n                          \"prefill_tok_s\": round((prom(port).get(PROMPT, 0) - p0.get(PROMPT, 0)) /\n                                                 max(1e-3, time.perf_counter() - t_adm), 1)}\n        if settled < 3:\n            r[\"status\"] = \"INCONCLUSIVE_NO_SETTLE\"\n            if barrier:\n                barrier.abort()\n            return r\n        if barrier:\n            try:\n                barrier.wait(timeout=max(60.0, admit))\n            except threading.BrokenBarrierError:\n                r[\"status\"] = \"INCONCLUSIVE_REPLICA_BARRIER\"\n                return r\n        m0, t0 = prom(port), time.perf_counter()\n        runs, waits, kvs, mids, gmem, stalls = [], [], [], [], [], [0] * len(ss)\n        last_tok, track, misses = [len(g.tokens) for g in ss], None, 0\n        while time.perf_counter() - t0 < secs:\n            time.sleep(min(sample, max(0.1, secs - (time.perf_counter() - t0))))\n            try:\n                m = prom(port)\n            except Exception:                              # rev 3c: one failed metrics read is not a crash\n                misses += 1\n                if misses >= 5:\n                    break\n                continue\n            mids.append(m)\n            runs.append(m.get(RUN, 0))\n            waits.append(m.get(WAIT, 0))\n            if KVU in m:\n                kvs.append(m[KVU])\n            now_tok = [len(g.tokens) for g in ss]\n            if track is None:                              # rev 3c: only streams decoding at window start can stall\n                track = {i for i in range(len(ss)) if now_tok[i] > last_tok[i]}\n            for i, g in enumerate(ss):\n                if i in track and g.is_alive():\n                    stalls[i] = stalls[i] + 1 if now_tok[i] <= last_tok[i] else 0\n            last_tok = now_tok\n            if any(x >= 3 for x in stalls):\n                break\n            if gpu_sample and len(mids) % 5 == 1:\n                g_ = gpu_mem()\n                if g_:\n                    gmem.append(g_)\n        m1, t1 = prom(port), time.perf_counter()\n        gen = m1.get(GEN, 0) - m0.get(GEN, 0)\n        dt = t1 - t0\n        acc, drf, dtk, it = (m1.get(k, 0) - m0.get(k, 0) for k in (ACC, DRF, DTOK, ITER))\n        rm = statistics.mean(runs) if runs else 0\n        steps = it if it else ((drf / rm) if (drf and rm) else ((gen / rm) if rm else 0))\n        r.update(tok_s=round(gen / dt, 1) if dt else None, gen_tokens=int(gen), window_sec=round(dt, 1),\n                 running_mean=round(rm, 2), running_min=min(runs or [0]), running_max=max(runs or [0]),\n                 waiting_min=min(waits or [0]), waiting_max=max(waits or [0]),\n                 tok_s_per_stream=round(gen / dt / rm, 2) if rm and dt else None,\n                 accept_per_draft=round(acc / drf, 3) if drf else None,\n                 mean_acceptance_length=round(1 + acc / drf, 3) if drf else None,\n                 accept_rate=round(acc / dtk, 3) if dtk else None,\n                 steps=int(steps), steps_source=\"iteration_histogram\" if it else \"estimate\",\n                 step_ms=round(dt * 1000 / steps, 1) if steps else None,\n                 tokens_per_step=round(gen / steps, 2) if steps else None,\n                 kv_usage_mean=round(statistics.mean(kvs), 3) if kvs else None, kv_usage_max=max(kvs) if kvs else None,\n                 gpu_mem_peak_mib=[max(row[i][1] for row in gmem if len(row) > i) for i in range(max(map(len, gmem)))] if gmem else None,\n                 preemptions=m1.get(PREEMPT, 0) - m0.get(PREEMPT, 0), t0=t0, t1=t1)\n        if misses >= 5:\n            r[\"status\"] = \"INCONCLUSIVE_METRICS_LOST\"\n        elif any(x >= 3 for x in stalls):\n            r[\"status\"] = \"INCONCLUSIVE_STALLED_STREAM\"\n        elif sum(g.is_alive() for g in ss) < min(level, best):\n            r[\"status\"] = \"INCONCLUSIVE_STREAMS_ENDED_IN_WINDOW\"\n        elif any(x.get(PROMPT) != m0.get(PROMPT) for x in mids + [m1]):\n            r[\"status\"] = \"INCONCLUSIVE_PREFILL_IN_WINDOW\"\n        elif r[\"preemptions\"] > 0:\n            r[\"status\"] = \"INCONCLUSIVE_PREEMPTION\"\n        elif gen <= 0:\n            r[\"status\"] = \"FAIL_NO_DECODE\"\n        elif min(runs or [0]) < level and (len(set(runs)) > 1 or len(set(waits)) > 1):\n            r[\"status\"] = \"INCONCLUSIVE_RUNNING_SET_CHANGED\"      # KV-bound window must hold one fixed set\n        elif min(runs or [0]) < 0.8 * max(runs or [1]):\n            r[\"status\"] = \"INCONCLUSIVE_RUNNING_UNSTABLE\"\n        else:\n            r[\"status\"] = (\"STEADY\" if min(runs or [0]) == max(runs or [0]) == level else\n                           \"CAPACITY_LIMITED\" if max(runs or [0]) < level else \"INCONCLUSIVE_RUNNING_ABOVE_LEVEL\")\n        return r\n    finally:\n        errs = sorted({g.err for g in ss if g.err})[:3]           # rev 3: snapshot before stop() sets _halt\n        for g in ss:\n            g.stop()\n        for g in ss:\n            g.join(10)\n        r[\"client_leak\"] = any(g.is_alive() for g in ss)\n        r[\"stream_errors\"] = errs\n        gb = [degenerate(\"\".join(g.text)[-4000:]) if g.tokens else None for g in ss]\n        r[\"garbage\"] = {\"streams\": len(ss), \"with_output\": sum(1 for g in ss if g.tokens),\n                        \"garbage\": [x for x in gb if x], \"sample_tail\": \"\".join(ss[0].text)[-200:] if ss and ss[0].tokens else \"\"}\n        if r[\"garbage\"][\"garbage\"] and r.get(\"status\") in (\"STEADY\", \"CAPACITY_LIMITED\"):\n            r[\"status\"] = \"FAIL_GARBAGE_UNDER_LOAD\"\n        r[\"idle_after\"] = wait_idle(port)\n\n\ndef steady_multi(jobs, secs=60.0, **kw):\n    \"\"\"Several servers at once (TP1 replicas): jobs = [(port, prompts, level)]; one shared window (barrier). The aggregate\n    counts only when every window is STEADY / CAPACITY_LIMITED and the windows overlap >= 80 % of the shortest.\"\"\"\n    out = [None] * len(jobs)\n    bar = threading.Barrier(len(jobs))\n\n    def one(i, j):\n        try:\n            out[i] = steady(j[0], j[1], j[2], secs=secs, barrier=bar, **kw)\n        except Exception as e:          # rev 3: a dead replica is recorded, not printed to stderr only\n            out[i] = {\"status\": \"ERROR_REPLICA\", \"error\": f\"{type(e).__name__}: {e}\"[:300], \"port\": j[0]}\n            try:\n                bar.abort()\n            except Exception:\n                pass\n    th = [threading.Thread(target=one, args=(i, j), daemon=True) for i, j in enumerate(jobs)]\n    for t in th:\n        t.start()\n    for t in th:\n        t.join()\n    good = all(o and o.get(\"status\") in (\"STEADY\", \"CAPACITY_LIMITED\") for o in out)\n    ov = (min(o[\"t1\"] for o in out) - max(o[\"t0\"] for o in out)) if good else 0\n    aligned = good and ov > 0.8 * min(o[\"window_sec\"] for o in out)\n    return {\"replicas\": out, \"aligned\": aligned, \"overlap_sec\": round(ov, 1),\n            \"tok_s\": round(sum(o[\"tok_s\"] for o in out), 1) if aligned else None,\n            \"running_mean\": round(sum(o[\"running_mean\"] for o in out), 2) if aligned else None,\n            \"status\": \"AGGREGATE_STEADY\" if aligned else \"INCONCLUSIVE_REPLICA_WINDOWS\"}\n\n\ndef wait_idle(port, wait=90.0):\n    end, hits = time.perf_counter() + wait, 0\n    while time.perf_counter() < end:\n        try:\n            m = prom(port)\n            hits = hits + 1 if m.get(RUN, 0) == 0 and m.get(WAIT, 0) == 0 else 0\n        except Exception:\n            hits = 0\n        if hits >= 3:\n            return True\n        time.sleep(2)\n    return False\n\n\n# ------------------------------------------------------------------ profiler (FULL-graph proof + per-category time)\n# rev 3: matched on the kernel BASE name, attention before GDN (\"fla\" is a substring of \"flashinfer\"), real 0.32 GDN names\nCATS = [(\"nccl\", (\"nccl\", \"allreduce\", \"all_reduce\", \"allgather\", \"all_gather\")),\n        (\"attention\", (\"flashinfer\", \"flash_fwd\", \"unified_attention\", \"paged\", \"attn\", \"attention\", \"batchdecode\", \"batchprefill\",\n                   \"reshape_and_cache\")),\n        (\"gdn_linear_attn\", (\"gdn\", \"delta_rule\", \"chunk_\", \"recurrent\", \"causal_conv\", \"l2norm\", \"solve_tril\", \"merge_16x16\",\n                             \"recompute_w_u\", \"kkt\", \"cumsum\", \"post_conv\", \"layer_norm_gated\", \"gated_delta\")),\n        (\"gemm_marlin\", (\"marlin\",)),\n        (\"gemm_other\", (\"gemm\", \"cutlass\", \"xmma\", \"cublas\", \"sm89_\", \"ampere_\", \"sm80_\")),\n        (\"sampling\", (\"sampl\", \"topk\", \"top_k\", \"argmax\", \"softmax\", \"rejection\"))]\n\n\ndef _cat(name):\n    # rev 3h: \"void (anonymous namespace)::gdn_decode_post_conv_mtp_kernel<...>(...)\" used to reduce to \"void \" -> other\n    s = re.sub(r\"\\(anonymous namespace\\)::\", \"\", str(name))\n    s = re.sub(r\"^\\s*void\\s+\", \"\", s)\n    base = s.split(\"<\")[0].split(\"(\")[0].lower()\n    return next((k for k, pats in CATS if any(p in base for p in pats)), \"other\")\n\n\nCOMPUTE_CATS = (\"nccl\", \"attention\", \"gdn_linear_attn\", \"gemm_marlin\", \"gemm_other\")\n# rev 3h: vLLM 0.32 marks each model execution as execute_context_N(N)_generation_N(N) (no gpu_model_runner range)\nSCOPE_RE = re.compile(r\"^execute_context_\\d+\\(\\d+\\)_generation_\\d+\\(\\d+\\)$\")\n\n\ndef _is_scope(e):\n    n = str(e.get(\"name\", \"\"))\n    return SCOPE_RE.match(n) is not None or (\"forward\" in n.lower() and \"gpu_model_runner\" in n.lower())\n\n\ndef _scope_kind(g, compute_eager, unresolved):\n    \"\"\"FULL = graph-launched with no eager model compute (attention / GDN / GEMM / NCCL) inside the execution scope;\n    eager input-preparation kernels are counted apart and allowed. Unresolved eager launches never read FULL.\"\"\"\n    if g == 0:\n        return \"EAGER\"\n    if compute_eager:\n        return \"PIECEWISE\"\n    if unresolved:\n        return \"PIECEWISE\" if g > 1 else \"MIXED\"\n    return \"FULL\"\n\n\ndef trace_summary(pdir):\n    files = sorted(Path(pdir).rglob(\"*.pt.trace.json*\"), key=lambda p: p.stat().st_mtime)\n    if not files:\n        return {\"error\": \"NO_TRACE_FILE\", \"listing\": [str(p) for p in Path(pdir).rglob(\"*\")][:20]}\n    f = next((p for p in files if re.search(r\"rank0\\.|rank[-_]?0[._]|tp0_\", p.name)), files[0])\n    with (gzip.open if f.name.endswith(\".gz\") else open)(f, \"rt\", encoding=\"utf-8\") as fh:\n        tr = json.load(fh)\n    ev = tr.get(\"traceEvents\", [])\n    kern = [e for e in ev if e.get(\"ph\") == \"X\" and str(e.get(\"cat\", \"\")).lower() in (\"kernel\", \"gpu_kernel\")]\n    rt = [e for e in ev if e.get(\"ph\") == \"X\" and str(e.get(\"cat\", \"\")).lower() in (\"cuda_runtime\", \"cuda_driver\")]\n    is_graph = lambda e: \"GraphLaunch\" in str(e.get(\"name\", \"\"))\n    is_kl = lambda e: re.search(r\"LaunchKernel|cuLaunchKernel\", str(e.get(\"name\", \"\"))) is not None\n    # per-scope counts inside the execution annotations (rev 3h: execute_context_*_generation_*; the older\n    # gpu_model_runner forward ranges still count). rev 3c: user_annotation only, not the gpu_user_annotation copies.\n    fw = sorted([e for e in ev if e.get(\"ph\") == \"X\" and str(e.get(\"cat\", \"\")) == \"user_annotation\" and _is_scope(e)],\n                key=lambda e: e.get(\"ts\", 0))\n    kname = {(e.get(\"args\") or {}).get(\"correlation\"): str(e.get(\"name\", \"\")) for e in kern\n             if (e.get(\"args\") or {}).get(\"correlation\") is not None}\n    per_fw, aux = [], {}\n    for a in fw[:400]:\n        lo, hi, tid = a.get(\"ts\", 0), a.get(\"ts\", 0) + a.get(\"dur\", 0), a.get(\"tid\")\n        inside = [e for e in rt if e.get(\"tid\") == tid and lo <= e.get(\"ts\", -1) <= hi]\n        kls = [e for e in inside if is_kl(e)]\n        ce = un = 0\n        for e in kls:\n            kn = kname.get((e.get(\"args\") or {}).get(\"correlation\"))\n            if kn is None:\n                un += 1\n            elif _cat(kn) in COMPUTE_CATS:\n                ce += 1\n            else:\n                b = re.sub(r\"^\\s*void\\s+\", \"\", re.sub(r\"\\(anonymous namespace\\)::\", \"\", kn)).split(\"<\")[0].split(\"(\")[0][:60]\n                aux[b] = aux.get(b, 0) + 1\n        per_fw.append([sum(1 for e in inside if is_graph(e)), len(kls), ce, un])\n    corr = {(e.get(\"args\") or {}).get(\"correlation\"): str(e.get(\"name\", \"\")) for e in rt\n            if (e.get(\"args\") or {}).get(\"correlation\") is not None}\n    per, tot, names = {k: 0.0 for k, _ in CATS + [(\"other\", ())]}, 0.0, {}\n    src = {k: {\"graph\": 0, \"eager\": 0, \"unknown\": 0} for k in per}\n    for e in kern:\n        d = float(e.get(\"dur\", 0.0))\n        tot += d\n        names[e.get(\"name\", \"\")] = names.get(e.get(\"name\", \"\"), 0.0) + d\n        k = _cat(e.get(\"name\", \"\"))\n        per[k] += d\n        launcher = corr.get((e.get(\"args\") or {}).get(\"correlation\"))\n        src[k][\"graph\" if launcher and \"GraphLaunch\" in launcher else (\"eager\" if launcher else \"unknown\")] += 1\n    tot_k = sum(v[\"graph\"] + v[\"eager\"] for v in src.values())\n    eager_share = round(sum(v[\"eager\"] for v in src.values()) / tot_k, 3) if tot_k else None\n    fw_g = statistics.median([x[0] for x in per_fw]) if per_fw else None\n    fw_k = statistics.median([x[1] for x in per_fw]) if per_fw else None\n    kinds_l = [_scope_kind(g, ce, un) for g, k, ce, un in per_fw]\n    if per_fw:                   # rev 3f (GPT rev 3e audit: 2 FULL + 1 EAGER forwards read FULL by the median)\n        kinds = set(kinds_l)\n        verdict = kinds.pop() if len(kinds) == 1 else \"MIXED\"       # every scope must agree\n        basis = \"per_scope_annotation (all scopes; eager input-prep kernels allowed, eager model compute is not)\"\n    elif tot_k:                  # rev 3d (GPT-2 reproduced FULL with 0 forwards): CUPTI alone never proves FULL\n        att = src[\"attention\"]\n        hint = (\"FULL\" if att[\"eager\"] == 0 and (eager_share or 0) < 0.05 else\n                \"PIECEWISE\" if att[\"eager\"] > 0 and any(v[\"graph\"] for v in src.values()) else\n                \"EAGER\" if not any(v[\"graph\"] for v in src.values()) else \"MIXED\")\n        verdict, basis = \"UNPROVEN\", f\"no forward annotations (cupti hint: {hint})\"\n    else:\n        verdict, basis = \"UNKNOWN\", \"none\"\n    return {\"file\": f.name, \"files\": len(files), \"kernels\": len(kern), \"kernel_us_sum\": round(tot),\n            \"graph_launches\": sum(1 for e in rt if is_graph(e)), \"kernel_launches\": sum(1 for e in rt if is_kl(e)),\n            \"forwards\": len(per_fw), \"forward_kinds\": {k_: kinds_l.count(k_) for k_ in (\"FULL\", \"PIECEWISE\", \"EAGER\", \"MIXED\")},\n            \"per_forward_median_graph_launches\": fw_g, \"per_forward_median_kernel_launches\": fw_k,\n            \"per_forward_median_compute_eager\": statistics.median([x[2] for x in per_fw]) if per_fw else None,\n            \"per_forward_unresolved_eager\": sum(x[3] for x in per_fw),\n            \"scope_names\": sorted({str(a.get(\"name\", \"\")) for a in fw})[:5],\n            \"aux_eager_kernels_in_scopes\": dict(sorted(aux.items(), key=lambda x: -x[1])[:20]),\n            \"launch_source\": src, \"eager_kernel_share\": eager_share, \"graph_verdict\": verdict, \"verdict_basis\": basis,\n            \"by_category_pct\": {k: round(100 * v / tot, 1) for k, v in per.items()} if tot else {},\n            \"top_kernels_us\": dict(sorted(((k, round(v)) for k, v in names.items()), key=lambda x: -x[1])[:25]),\n            \"note\": \"kernel time sums overlapping streams; NCCL time includes rank-skew waiting\"}\n\n\ndef profile(port, pdir, secs=6.0, delay_iters=20, max_iters=40):\n    \"\"\"POST /start_profile (bounded by iterations; falls back to a bare POST), decode, POST /stop_profile, summary.\"\"\"\n    rec = {}\n    try:\n        U.urlopen(U.Request(f\"http://127.0.0.1:{port}/start_profile\", method=\"POST\",\n                            data=json.dumps({\"delay_iterations\": delay_iters, \"max_iterations\": max_iters}).encode(),\n                            headers={\"Content-Type\": \"application/json\"}), timeout=900).read()\n        rec[\"start_profile\"] = \"ok_bounded\"\n    except Exception as e:\n        rec[\"start_profile_bounded_error\"] = repr(e)[:200]\n        try:\n            U.urlopen(U.Request(f\"http://127.0.0.1:{port}/start_profile\", data=b\"\", method=\"POST\"), timeout=900).read()\n            rec[\"start_profile\"] = \"ok\"\n        except Exception as e2:\n            rec[\"start_profile\"] = repr(e2)[:200]\n    time.sleep(secs)\n    try:\n        U.urlopen(U.Request(f\"http://127.0.0.1:{port}/stop_profile\", data=b\"\", method=\"POST\"), timeout=900).read()\n        rec[\"stop_profile\"] = \"ok\"\n    except Exception as e:\n        rec[\"stop_profile\"] = repr(e)[:200]\n    time.sleep(20)\n    try:\n        rec[\"trace\"] = trace_summary(pdir)\n    except Exception as e:\n        rec[\"trace\"] = {\"error\": f\"TRACE_PARSE {type(e).__name__}: {e}\"[:300]}\n    return rec\n\n\ndef profiled_load(port, prompts, level, pdir, secs=6.0, max_new=8192, model=\"q27\", prefill_tok_s=700.0, spec=False):\n    \"\"\"`level` decoding streams (own window: the profiler slows decode), profile() only after prefill settled exactly\n    as in steady() (prompt counter + preemptions flat, every running request emitted and gaining tokens). rev 3d: no\n    profile when unsettled; the profile window must be decode-only (prompt counter flat) and, with `spec`, show\n    speculative drafts (else the trace cannot speak for multi-token verification).\"\"\"\n    plen = len(prompts[0]) if prompts else 0\n    settle = max(300.0, 120.0 + level * plen / prefill_tok_s)\n    ss = [Stream(port, prompts[i % len(prompts)], max_new, 1.0, 4321 + i, model=model) for i in range(level)]\n    for g in ss:\n        g.start()\n    rec, t0, flat, ok, prev, last_tok = {\"level\": level}, time.perf_counter(), None, 0, None, [0] * level\n    try:\n        while time.perf_counter() - t0 < settle:\n            time.sleep(2)\n            try:\n                m = prom(port)\n            except Exception:\n                continue\n            run, wait, pt, pre = int(m.get(RUN, 0)), int(m.get(WAIT, 0)), m.get(PROMPT), m.get(PREEMPT, 0)\n            now_tok = [len(g.tokens) for g in ss]\n            gaining = sum(1 for a, b in zip(last_tok, now_tok) if b > a)\n            last_tok = now_tok\n            first = sum(g.t_first is not None for g in ss)\n            calm = run > 0 and prev is not None and (pt, pre) == prev and first >= run and gaining >= run\n            if calm and run >= level and wait == 0:\n                ok += 1\n            elif calm and wait > 0:\n                flat = flat or time.perf_counter()\n                ok = ok + 1 if time.perf_counter() - flat > 30 else 0\n            else:\n                ok, flat = 0, None\n            prev = (pt, pre)\n            if ok >= 3:\n                break\n        rec[\"settled\"] = ok >= 3\n        if not rec[\"settled\"]:\n            rec[\"status\"] = \"INCONCLUSIVE_PREFILL_NOT_SETTLED\"\n            return rec\n        try:\n            m0 = prom(port)\n            rec[\"running_at_start\"] = m0.get(RUN)\n        except Exception:\n            m0 = {}\n        rec.update(profile(port, pdir, secs))\n        try:\n            m1 = prom(port)\n        except Exception:\n            m1 = {}\n        rec[\"window_deltas\"] = {\"prompt_tokens\": m1.get(PROMPT, 0) - m0.get(PROMPT, 0), \"drafts\": m1.get(DRF, 0) - m0.get(DRF, 0),\n                                \"accepted\": m1.get(ACC, 0) - m0.get(ACC, 0), \"generated\": m1.get(GEN, 0) - m0.get(GEN, 0)}\n        if not m0 or not m1:\n            rec[\"status\"] = \"INCONCLUSIVE_METRICS_UNAVAILABLE\"\n        elif rec[\"window_deltas\"][\"prompt_tokens\"]:\n            rec[\"status\"] = \"INCONCLUSIVE_PREFILL_IN_PROFILE\"\n        elif spec and not (rec[\"window_deltas\"][\"drafts\"] and rec[\"window_deltas\"][\"accepted\"]):\n            rec[\"status\"] = \"INCONCLUSIVE_NO_SPEC_DECODE\"            # rev 3e: drafts AND accepted tokens in the window\n        return rec\n    finally:\n        for g in ss:\n            g.stop()\n        for g in ss:\n            g.join(10)\n        rec[\"idle_after\"] = wait_idle(port)\n"
    (TMP / "e23_lab.py").write_text(LAB_SRC)
    sys.path.insert(0, str(TMP))
    import e23_lab as L
    REQ_LOG = TRACES / "requests.jsonl"                           # memory rule: the full text of EVERY request
    _stream_run = L.Stream.run

    def _traced_run(self):
        try:
            _stream_run(self)
        finally:
            if not self.err and any(m is not None and not (isinstance(m, (int, float)) and math.isfinite(m))
                                    for m in self.margins):
                self.err = "NONFINITE_LOGPROB"           # final audit H2: NaN / Inf logprobs are never data
            try:
                r = self.row()
                pr = self.body.get("prompt") or []
                r.update(port=self.port, sampling={k: v for k, v in self.body.items() if k != "prompt"}, prompt_len=len(pr),
                         prompt_sha=hashlib.sha256(json.dumps(pr).encode()).hexdigest()[:16],
                         ttft=round(self.t_first - self.t_start, 2) if self.t_first and self.t_start else None,
                         sec=round(self.t_end - self.t_start, 2) if self.t_end and self.t_start else None, t=time.time())
                with _SAVE_LOCK, open(REQ_LOG, "a") as fh:
                    fh.write(json.dumps(r) + "\n")
            except Exception:
                pass
    L.Stream.run = _traced_run
    PLE_EXPECTED = json.loads(r"""{"model-plefp8-00000.safetensors": [5200027199, "dc2e845b7edd35bda92834fba3626bf7d199e28d6aceac99fee654aade390cfd"], "model-plefp8-00001.safetensors": [5200027202, "899eaa0716e28594468a1389ee58cb065c23907f1270de3831f5ecb0a4f82d56"], "model-plefp8-00002.safetensors": [5200027198, "06fd8a11abf0419a669f89397b8d70dd6ff42d401e6b2a037c65e49704faaf71"], "model-plefp8-00003.safetensors": [5200027189, "c6aaa1fc08e84eced3c8151ac8679ed943888eba0fcef2556963693430f95bd9"], "model-plefp8-00004.safetensors": [5200027190, "d94e97c96d3ea09208614da016960f3f4b429f47a044c898a51b493f42f74ba2"], "model-plefp8-00005.safetensors": [5200027190, "03d5d4792e14a4ab55bae50bb459624b01786f818bbcfcaed1a5d0235af484c6"], "model-plefp8-00006.safetensors": [5200027190, "586cccbc12383021bc9bc02f206d9b19fbd1672373ed9a5d91e3b0ce34c2418f"], "model-plefp8-00007.safetensors": [5200027190, "c4a23bcc10f3cde6b633e82c282a9a518e3a64d433628283e1bc592c94cf3d6c"], "model-plefp8-00008.safetensors": [5200027190, "2dc8098c0d020bff277c9cf499a6b908e17836b70a5f949dfa24793371c9a87e"], "model-plefp8-00009.safetensors": [4400023163, "61de98b89bb79f386795787d7a76827a26f1e292c26edbb0a1b613da455f5a9c"]}""")                     # 10 FP8 PLE shards: [size, sha256]
    # exact Kaggle mount paths (foysalemonshanto Models, checked through the API 2026-10-31; no recursive search)
    MD = INP / "models" / "foysalemonshanto"
    PART_DIRS = {1: MD / "qwen3-8-flash-next-w4a16-merlin-p1/transformers/default/1",
                 2: MD / "qwen3-8-flash-next-w4a16-merlin-p2/transformers/default/1",
                 3: MD / "qwen3-8-flash-next-w4a16-merlin-p3/transformers/default/1",
                 4: MD / "qwen3-8-flash-next-w4a16-merlin-p4/transformers/default/1",
                 5: MD / "qwen3-8-flash-next-w4a16-merlin-p5/transformers/default/1"}
    PARTS = {}
    for k, d in PART_DIRS.items():                                  # the five checkpoint parts (Models from the kernel outputs)
        mf = d / f"q27_fn_merlin_part{k}_manifest.json"
        PARTS[k] = (d, json.loads(mf.read_text())) if mf.is_file() else None
    PLE_DIR = MD / "qwen38-flash-next-fp8ple-overlay/pytorch/albucino-fp8ple/1"      # our FP8 PLE overlay = albucino's shards
    PLE_DIR = PLE_DIR if (PLE_DIR / "model-plefp8-00000.safetensors").is_file() else None
    MERLIN_PAY = MD / "e23-merlin-env/other/v1/1/merlin_offline_tar.bin"
    MERLIN_PAY = MERLIN_PAY if MERLIN_PAY.is_file() else None
    INTEL = INP / "models/dfranzen/intel-qwen3.8-flash-next-w4a16-autoround/transformers/default/1"
    INTEL = INTEL if (INTEL / "config.json").is_file() else None
    WHEELHOUSE = INP / "datasets/foysalemonshanto/vllm-0-32-0-cu13-wheelhouse/install_wheelhouse.py"
    WHEELHOUSE = WHEELHOUSE if WHEELHOUSE.is_file() else None
    ARC = COMP / "arc-agi_evaluation_challenges.json"
    if not ARC.is_file():
        raise FileNotFoundError(f"{ARC}: attach the competition data")
    PARTS = {}                                     # E25 klee100: no W4 parts; klee100 + the FP8 PLE overlay + the Merlin env
    K100_DIR = MD / "qwen38-flash-next-klee100-3bpw-mtp/pytorch/autoround-3bpw-mtp-nople/1"            # E25 klee100
    if not (K100_DIR / "KAGGLE_MIRROR_MANIFEST.json").is_file():                                          # E25 klee100
        _g = sorted((MD / "qwen38-flash-next-klee100-3bpw-mtp").glob("*/*/*/KAGGLE_MIRROR_MANIFEST.json"))  # E25 klee100
        K100_DIR = _g[0].parent if len(_g) == 1 else None                                                 # E25 klee100
    REF_DIR = next((d for d in (INP / "datasets/foysalemonshanto/q27-e25-nb0-tf-ref", INP / "q27-e25-nb0-tf-ref")   # E25 klee100
                    if (d / "nb0_reference.json").is_file()), None)                                       # E25 klee100
    MERLIN_OK = K100_DIR is not None and PLE_DIR is not None and MERLIN_PAY is not None                   # E25 klee100
    R["inputs"] = {"klee100_dir": str(K100_DIR), "ref_dir": str(REF_DIR), "ple_dir": str(PLE_DIR),   # E25 klee100
                   "merlin_pay": str(MERLIN_PAY), "intel": str(INTEL), "wheelhouse": str(WHEELHOUSE), "arc": str(ARC),
                   "merlin_inputs_ok": MERLIN_OK}
    ABORT = {"why": None}
    NVSMI_OK = bool(L.gpu_mem()) and not FAKE
    R["setup"]["gpus_at_start"] = L.gpu_mem()
    if not FAKE and not os.environ.get("RC2_CPU_KIT") and len(R["setup"]["gpus_at_start"] or []) != 4:   # CPU kit: no GPUs
        R["errors"].append(f"expected 4 GPUs, nvidia-smi shows {R['setup']['gpus_at_start']}")
        save()
        raise RuntimeError("GPU_PREFLIGHT_FAILED: " + repr(R["setup"]["gpus_at_start"]))
    L.start_watchdog(HARD_STOP, lambda: ABORT.update(why="HARD_STOP reached: watchdog killed live servers"))
    log("K100 | budget", BUDGET // 60, "min |", json.dumps(R["inputs"])[:900])
    save()


if not RERUN:
    # ==================================================================== CELL 2 — host facts, checkpoint merge, engines
    def run(name, cmd, timeout=3600, env=None):
        t = time.time()
        try:
            with open(LOGS / f"{name}.log", "w") as f:
                r = subprocess.run(["bash", "-c", "set -o pipefail; " + cmd], stdout=f, stderr=subprocess.STDOUT, timeout=timeout,
                                   env={**os.environ, **(env or {})})
            rc = r.returncode
        except subprocess.TimeoutExpired:
            rc = -9
        txt = (LOGS / f"{name}.log").read_text(errors="replace")
        R["setup"][name] = {"rc": rc, "sec": round(time.time() - t, 1), "tail": txt[-1500:]}
        log(name, "rc", rc, f"{time.time() - t:.0f}s")
        save()
        return rc, txt


    SHIM = TMP / "e23_libcuda"          # FlashInfer JIT links -lcuda; Kaggle has only libcuda.so.1
    SHIM.mkdir(exist_ok=True)
    for d in ("/usr/local/nvidia/lib64", "/usr/lib/x86_64-linux-gnu", "/usr/local/cuda/compat", "/usr/lib64"):
        c = sorted(Path(d).glob("libcuda.so.1")) if Path(d).is_dir() else []
        if c and not (SHIM / "libcuda.so").exists():
            (SHIM / "libcuda.so").symlink_to(c[0])


    def host_facts():
        """A0: what the Kaggle box gives us (glibc, driver, GPUs, PCIe, peer access, cgroup memory, /dev/shm, disk)."""
        f = {}
        for k, cmd in (("glibc", "ldd --version | head -1"), ("uname", "uname -a"),
                       ("nvidia_smi", "nvidia-smi --query-gpu=name,compute_cap,driver_version,memory.total,pcie.link.gen.max,pcie.link.width.max --format=csv,noheader"),
                       ("cuda_version", "nvidia-smi | grep -o 'CUDA Version: [0-9.]*'"), ("shm", "df -h /dev/shm | tail -1"),
                       ("tmp_disk", f"df -h {TMP} | tail -1"), ("nproc", "nproc"),
                       ("cgroup_max", "cat /sys/fs/cgroup/memory.max 2>/dev/null || cat /sys/fs/cgroup/memory/memory.limit_in_bytes"),
                       ("cgroup_cur", "cat /sys/fs/cgroup/memory.current 2>/dev/null || cat /sys/fs/cgroup/memory/memory.usage_in_bytes"),
                       ("meminfo", "grep -E 'MemTotal|MemAvailable' /proc/meminfo"), ("ulimit_l", "ulimit -l"),
                       ("omp", "echo OMP_NUM_THREADS=$OMP_NUM_THREADS"), ("topo", "nvidia-smi topo -m; nvidia-smi topo -p2p r"),
                       ("pcie_now", "nvidia-smi --query-gpu=index,pcie.link.gen.current,pcie.link.width.current,power.limit --format=csv,noheader")):
            try:
                f[k] = subprocess.run(["bash", "-c", cmd], capture_output=True, text=True, timeout=60).stdout.strip()[:600]
            except Exception as e:
                f[k] = repr(e)[:200]
        try:
            import torch
            n = torch.cuda.device_count()
            f["peer_access"] = [[torch.cuda.can_device_access_peer(i, j) if i != j else None for j in range(n)] for i in range(n)]
        except Exception as e:
            f["peer_access"] = repr(e)[:200]
        return f


    def host_mem():
        """MiB. avail_mib = max - (current - inactive_file), Merlin's own rule (RC1's guard counted page cache as used and
        skipped arm 3 with MemAvailable 55 GB); /dev/shm counts against the cgroup."""
        out = {}
        try:
            cur = int(Path("/sys/fs/cgroup/memory.current").read_text())
            mx = Path("/sys/fs/cgroup/memory.max").read_text().strip()
            st = dict(l.split() for l in Path("/sys/fs/cgroup/memory.stat").read_text().splitlines() if len(l.split()) == 2)
            out.update(cgroup_cur_mib=cur >> 20, cgroup_max_mib=None if mx == "max" else int(mx) >> 20,
                       **{k + "_mib": int(st[k]) >> 20 for k in ("anon", "file", "shmem", "inactive_file") if k in st})
            if mx != "max":
                out["avail_mib"] = (int(mx) - (cur - int(st.get("inactive_file", 0)))) >> 20
        except Exception:
            pass
        try:
            for l in open("/proc/meminfo"):
                if l.startswith(("MemAvailable", "MemTotal")):
                    out[l.split(":")[0] + "_mib"] = int(l.split()[1]) >> 10
        except Exception:
            pass
        try:
            out["dev_shm_used_mib"] = shutil.disk_usage("/dev/shm").used >> 20
        except Exception:
            pass
        return out


    TELEMETRY = OUT / "telemetry.jsonl"


    def _telemetry():
        """Host RAM + GPU memory every 10 s for the whole run (Merlin's floor ~69 GiB inside a ~173 GiB cgroup)."""
        while True:
            try:
                with open(TELEMETRY, "a") as fh:
                    fh.write(json.dumps({"t": round(time.time() - T_START, 1), "host": host_mem(), "gpu": L.gpu_mem()}) + "\n")
            except Exception:
                pass
            time.sleep(10)


    threading.Thread(target=_telemetry, daemon=True).start()


    SHM = Path(os.environ.get("RC2_SHM", "/dev/shm"))


    def shm_names():
        try:
            return {p.name for p in SHM.iterdir()}
        except Exception:
            return set()


    def shm_cleanup(before):
        """After a boot's server is dead: only /dev/shm entries that appeared during THIS boot (absent from `before`) and
        match the engine's prefixes are unlinked; everything else is recorded, never touched."""
        out = {"host_before": host_mem(), "removed": [], "kept": []}
        try:
            for p in sorted(SHM.iterdir()):
                try:
                    sz = p.stat().st_size >> 20
                except Exception:
                    sz = None
                if p.name not in before and re.match(r"(torch_|psm_|vllm|ple|nccl|sem\.mp-|cuda\.shm)", p.name, re.I):
                    try:
                        p.unlink() if not p.is_dir() else shutil.rmtree(p)
                        out["removed"].append([p.name, sz])
                    except Exception as e:
                        out["kept"].append([p.name, sz, repr(e)[:80]])
                else:
                    out["kept"].append([p.name, sz])
        except Exception as e:
            out["error"] = repr(e)[:200]
        out["host_after"] = host_mem()
        out["removed"], out["kept"] = out["removed"][:60], out["kept"][:60]
        return out


    class MServer(L.Server):
        """Merlin passes --shutdown-timeout 60 and the PLE transport unlinks its /dev/shm storages only on a graceful
        teardown: SIGTERM, wait 75 s, then E23's kill (SIGTERM + 40 s + SIGKILL of the whole session)."""
        def kill(self):
            if self.proc is not None and self.proc.poll() is None:
                try:
                    os.killpg(self.proc.pid, 15) if hasattr(os, "killpg") else self.proc.terminate()
                except Exception:
                    pass
                try:
                    self.proc.wait(timeout=75)
                except Exception:
                    pass
            super().kill()


    def boot_gate():
        """Merlin's pin leaves ~0.9 GiB free per card: every boot needs near-empty GPUs (< 150 MiB, not E23's 1024)."""
        g = L.wait_gpu_release(300, fake=bool(FAKE), gpus="0,1,2,3", free_mib=150)
        return {"ok": g, "gpus": L.gpu_mem(), "host": host_mem()}       # callers launch only on ok is True


    CKPT = TMP / "fn_merlin"
    SHA = {"thread": None, "ok": None, "bad": [], "sec": None}


    def merge_ckpt():
        """Symlink the 5 parts + 10 PLE shards into one directory; names and sizes now, sha256 in a background thread."""
        SHA.update(thread=None, ok=None, bad=[], sec=None)        # a stale result never gates a new merge
        shutil.rmtree(CKPT, ignore_errors=True)
        CKPT.mkdir(parents=True)
        expected = {}
        for k, (d, man) in PARTS.items():
            for n, (size, sha) in man["files"].items():
                expected[n] = (d / man.get("model_subdir", ".") / n, size, sha)
        for n, (size, sha) in PLE_EXPECTED.items():
            expected[n] = (PLE_DIR / n, size, sha)
        bad = []
        for n, (src, size, sha) in sorted(expected.items()):
            if not src.is_file():
                bad.append(f"missing {n}")
                continue
            if not FAKE and src.stat().st_size != size:
                bad.append(f"{n}: {src.stat().st_size} bytes, expected {size}")
            try:
                (CKPT / n).symlink_to(src)
            except OSError:
                if not FAKE:
                    raise
                shutil.copyfile(src, CKPT / n)               # local Windows harness only (no symlink privilege)
        idx = json.loads((CKPT / "model.safetensors.index.json").read_text())
        need = set(idx["weight_map"].values())
        bad += [f"index needs {n}, not merged" for n in sorted(need - set(expected))]
        cfg = json.loads((CKPT / "config.json").read_text())
        if (cfg.get("text_config") or {}).get("ple_embedding_dtype") != "float8_e4m3fn":
            bad.append("config.json: text_config.ple_embedding_dtype is not float8_e4m3fn")
        rec = {"files": len(expected), "index_files": len(need), "bad": bad[:20], "ok": not bad}

        def hash_all():
            t = time.time()
            import concurrent.futures as CF

            def one(item):
                n, (src, size, sha) = item
                if FAKE:
                    return n, True
                with open(src, "rb") as fh:
                    return n, hashlib.file_digest(fh, "sha256").hexdigest() == sha
            with CF.ThreadPoolExecutor(6) as ex:
                res = list(ex.map(one, sorted(expected.items())))
            SHA.update(ok=all(ok for _, ok in res), bad=[n for n, ok in res if not ok], sec=round(time.time() - t, 1))
            R["setup"]["sha256"] = {k: SHA[k] for k in ("ok", "bad", "sec")}
            save()
        if rec["ok"]:
            SHA["thread"] = threading.Thread(target=hash_all, daemon=True)
            SHA["thread"].start()
        return rec


    def sha_gate(timeout):
        """The first launch waits for the full sha256 check (Merlin itself never hashes shards)."""
        th = SHA["thread"]
        if th is not None:
            th.join(max(1, timeout))
        if th is None or th.is_alive():
            return False, "sha256 check not finished"
        return bool(SHA["ok"]), ("ok" if SHA["ok"] else f"sha256 mismatch: {SHA['bad'][:5]}")


    def prefetch_bg(paths, tag):
        """rev 3: warm the page cache of a cold 17-30 GB /kaggle/input checkpoint in the background (many readers)."""
        def go():
            R["setup"]["prefetch_" + tag] = L.prefetch([p for p in paths if p]) if not FAKE else {"fake": True}
            save()
        th = threading.Thread(target=go, daemon=True)
        th.start()
        return th


    MERLIN_ENG = None


    def merlin_install():
        """P2 payload (.bin = a tar Kaggle does not unpack) -> install_merlin_offline.sh (UV_OFFLINE); payload deleted after;
        a failure is cached so later Merlin steps fail fast (rev 3)."""
        global MERLIN_ENG
        if MERLIN_ENG is not None:
            if MERLIN_ENG.get("failed"):
                raise RuntimeError("Merlin install failed earlier: " + MERLIN_ENG["failed"])
            return MERLIN_ENG
        if not MERLIN_OK or MERLIN_PAY is None:
            MERLIN_ENG = {"failed": "Merlin checkpoint / env not attached or incomplete"}
            raise RuntimeError(MERLIN_ENG["failed"])
        if FAKE:
            MERLIN_ENG = {"fake": True}
            return MERLIN_ENG
        try:
            pay_root = TMP / "merlin_pay"
            shutil.rmtree(pay_root, ignore_errors=True)
            pay_root.mkdir()
            t = time.time()
            with tarfile.open(MERLIN_PAY) as tf:
                tf.extractall(pay_root, filter="data")
            R["setup"]["merlin_extract_sec"] = round(time.time() - t, 1)
            pay = pay_root / "merlin_offline"
            shutil.rmtree(TMP / "merlin_off", ignore_errors=True)
            rc, txt = run("install_merlin", f"bash {pay}/install_merlin_offline.sh {pay} {TMP}/merlin_off", timeout=5400)
            kv = dict(re.findall(r"^(MERLIN_[A-Z]+)=(.*)$", txt, re.M))
            shutil.rmtree(pay_root, ignore_errors=True)
            if rc or "INSTALL OK" not in txt:
                raise RuntimeError("Merlin offline install failed (logs/install_merlin.log)")
            sys.path.insert(0, kv["MERLIN_TREE"] + "/tools/merlin")
            import launch as ML
            site = subprocess.run([kv["MERLIN_VENV"] + "/bin/python", "-c", "import sysconfig;print(sysconfig.get_paths()['purelib'])"],
                                  capture_output=True, text=True).stdout.strip()
            MERLIN_ENG = {"kv": kv, "ML": ML, "cuda_home": site + "/nvidia/cu13"}
            return MERLIN_ENG
        except Exception as e:
            MERLIN_ENG = {"failed": f"{type(e).__name__}: {e}"[:300]}
            raise


    MERLIN_CC = {"mode": "gcc13"}       # rev 3c: Merlin README:229 / install-env.sh: FlashInfer JIT at first start needs GCC >= 13



    KV_FP8, KV_BF16 = 2479838700, 2464415744      # Merlin's own L4 pins (23,034 MiB cards; preflight.kv_bytes_for_vram, 150 / 79 blocks)
    PROFILE = "fn-quad-24g-sm89"
    XHIGH = json.dumps({"enable_thinking": True, "reasoning_effort": "xhigh"})
    HOST_PHASE = {}


    def merlin_fn_server(name, kv, port, kv_bytes):
        """Merlin's launch.build() for Flash-Next on the L4 profile: KV pin lowered for 22.49 GiB cards, the checkpoint's own
        chat template at xhigh (Merlin passes medium otherwise), Merlin's host_phase checks recorded, E23's env overrides."""
        eng = merlin_install()
        extra = ["--served-model-name", "q27", "--max-model-len", str(MAX_LEN), "--port", str(port),
                 "--default-chat-template-kwargs", XHIGH] + list(NB1_EXTRA.get(name) or [])   # E25 NB1: per-boot flags (last wins)
        if FAKE:
            return MServer(name, [sys.executable, FAKE, str(CKPT) + "-w4a16", "--tensor-parallel-size", "2", "--max-num-seqs",
                                  "8" if kv == "fp8" else "3", "--port", str(port), "--max-model-len", str(MAX_LEN),
                                  "--kv-cache-memory-bytes", str(kv_bytes)] + list(NB1_EXTRA.get(name) or []),   # E25 NB1 (fake only)
                           {**os.environ, **(NB1_ENV.get(name) or {})}, port, LOGS)
        kvv = eng["kv"]
        gcc_bin = str(Path(kvv["MERLIN_CC"]).parent) if kvv.get("MERLIN_CC") else ""
        base = {k: v for k, v in os.environ.items() if k not in ("PYTHONPATH", "CUDA_PATH", "CUDA_HOME", "LD_PRELOAD", "CC", "CXX")}
        base.update(GPUS="0,1,2,3", PORT=str(port), KV_BYTES=str(kv_bytes), P2P="off",
                    VENV=kvv["MERLIN_VENV"], TREE=kvv["MERLIN_TREE"], CHAT_TEMPLATE="", WARM="0", CACHE_ROOT=f"{TMP}/merlin-cache",
                    PATH=f"{kvv['MERLIN_VENV']}/bin:{gcc_bin}:{eng['cuda_home']}/bin:{os.environ.get('PATH', '')}",
                    CUDA_HOME=eng["cuda_home"])
        if kv == "fp8":
            base["SCALES"] = str(CKPT / "qsa_kv_scales_262k.json")
        plan = eng["ML"].build("flash-next", PROFILE, str(CKPT), base, extra=extra, kv=kv, checkpoint="flash-next", status="untested")
        try:                                               # audits: tree products, venv, checkpoint marker, PLE dtype, toolchain,
            eng["ML"].host_phase(plan)                     # scales file: a failure stops this boot before any server starts
            HOST_PHASE[name] = "ok"
        except BaseException as e:
            HOST_PHASE[name] = f"{type(e).__name__}: {e}"[:600]
            R["setup"].setdefault("host_phase_error", {})[name] = HOST_PHASE[name]
            save()
            raise RuntimeError("MERLIN_HOST_PHASE_FAILED: " + HOST_PHASE[name])
        env = dict(plan.env)
        env.update(LD_PRELOAD=kvv["MERLIN_SHIM"], CUDA_HOME=eng["cuda_home"], VLLM_USE_RUST_FRONTEND="0", HF_HUB_OFFLINE="1",
                   TRANSFORMERS_OFFLINE="1", LIBRARY_PATH=f"{SHIM}:{os.environ.get('LIBRARY_PATH', '')}",
                   PATH=base["PATH"], VLLM_CACHE_ROOT=f"{TMP}/merlin-cache", TRITON_CACHE_DIR=f"{TMP}/merlin-triton",
                   FLASHINFER_WORKSPACE_BASE=f"{TMP}/merlin-fi", CUDA_DEVICE_ORDER="PCI_BUS_ID", VLLM_PLE_OFFLOAD_READY_TIMEOUT="3600")
        for k in ("CC", "CXX", "CUDAHOSTCXX"):
            env.pop(k, None)
        if MERLIN_CC["mode"] == "gcc13" and kvv.get("MERLIN_CC") and kvv.get("MERLIN_CXX"):
            env.update(CC=kvv["MERLIN_CC"], CXX=kvv["MERLIN_CXX"], CUDAHOSTCXX=kvv["MERLIN_CXX"])
            lib13 = Path(kvv["MERLIN_CC"]).parents[1] / "lib"
            if (lib13 / "libstdc++.so.6").exists():
                env["LD_LIBRARY_PATH"] = f"{lib13}:{env.get('LD_LIBRARY_PATH', '')}"
        try:                                               # Merlin's own scheme: PORT 8000..8355 -> 29500+d / 30000+100d
            mp, vp = eng["ML"].distributed_ports(str(port))
            env.update(MASTER_PORT=str(mp), VLLM_PORT=str(vp))
        except Exception:
            env.update(MASTER_PORT=str(29500 + port - 8000), VLLM_PORT=str(30000 + 100 * (port - 8000)))
        env.update(NB1_ENV.get(name) or {})              # E25 NB1: after build(), which strips every MERLIN_* variable
        argv = plan.argv()
        HELP[name] = L.help_check("merlin", argv[:argv.index("serve") + 1], env, argv)
        R["setup"].setdefault("merlin_plans", {})[name] = {"argv_tail": argv[-60:], "status": plan.status, "host_phase": HOST_PHASE[name],
                                                           "env_keys": {k: env[k] for k in sorted(env) if k.startswith(("VLLM_", "NCCL_", "KV_", "P2P", "SCALES"))}}
        save()
        return MServer(name, argv, env, port, LOGS)


    STOCK = None


    def stock_install():
        """Fallback only: stock vLLM 0.32 venv (E18 / E23 installer) with the -lcuda shim on LIBRARY_PATH (RC1's sampler crash)."""
        global STOCK
        if STOCK is not None:
            return STOCK
        if FAKE:
            STOCK = {"vllm": [sys.executable, FAKE], "env": dict(os.environ)}
            return STOCK
        rc, txt = run("install_stock", f"{sys.executable} {WHEELHOUSE} {TMP}/vllm-venv", timeout=2400)
        kv = dict(l.split("=", 1) for l in txt.splitlines() if l.startswith(("VENV_PYTHON=", "CUDA_HOME=")))
        if rc or "CUDA_HOME" not in kv:
            raise RuntimeError("stock vLLM 0.32 install failed (logs/install_stock.log)")
        env = {k: v for k, v in os.environ.items() if k not in ("PYTHONPATH", "CUDA_PATH", "LD_PRELOAD")}
        env.update(CUDA_HOME=kv["CUDA_HOME"], PATH=f"{TMP}/vllm-venv/bin:{kv['CUDA_HOME']}/bin:{env.get('PATH', '')}",
                   LIBRARY_PATH=f"{SHIM}:{env.get('LIBRARY_PATH', '')}", HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1",
                   VLLM_NO_USAGE_STATS="1", VLLM_CACHE_ROOT=f"{TMP}/vllm-cache", CUDA_DEVICE_ORDER="PCI_BUS_ID",
                   PYTORCH_CUDA_ALLOC_CONF="expandable_segments:True")
        STOCK = {"vllm": [f"{TMP}/vllm-venv/bin/vllm", "serve"], "env": env}
        return STOCK


    def stock_fn_server(name, port):
        eng = stock_install()
        flags = [str(INTEL), "--served-model-name", "q27", "--host", "127.0.0.1", "--port", str(port),
                 "--tensor-parallel-size", "4", "--enable-expert-parallel", "--max-model-len", "32768", "--max-num-seqs", "4",
                 "--max-num-batched-tokens", "4096", "--gpu-memory-utilization", "0.88", "--disable-custom-all-reduce",
                 "--language-model-only", "--engram-config", json.dumps({"cpu_offload": True}), "--load-format", "safetensors",
                 "--dtype", "bfloat16", "--kv-cache-dtype", "fp8_e4m3", "--default-chat-template-kwargs", XHIGH]
        # diagnostic only: RC1 had a 30,208-token BF16 pool at TP4; no MTP here, so prefix caching (default ON) is unaffected
        if FAKE:
            flags = [str(INTEL) + "-w4a16", "--tensor-parallel-size", "4", "--max-num-seqs", "4", "--port", str(port), "--max-model-len", "32768"]
        return L.Server(name, list(eng["vllm"]) + flags, eng["env"], port, LOGS)
    save()


if not RERUN:
    # ==================================================================== CELL 2b — E25 klee100: fixkeys overlay, model dir, K6, digests (NEW)
    import base64 as _b64
    import lzma as _lzma
    K1 = R.setdefault("k100", {})
    K100_EMB = json.loads("{\"k100load_lib.py\": [\"d10c54e5fb8beede0dd61cff36a5b696cac5f71d402502999f477dd3246cc3bb\", \"{Wp48S^xk9=GL@E0stWa8~^|S5YJf5;6#EKLtOw7Xbna~Q3<Lo$NONZq)WnKr<cv&>X!>&Bo-1*GJ5f{&H?@_x7}G^%0MlKB@w5R+I+zdtaqMS)cJ1Dp~1L7Eza7UWuRfHa5QrM<EIu!_@gqY0@t}ds96uIkR~{@L?CLXfk2kr<a_+QBE-QvRAv4c3q(d#I645@1q5LOr!W@-EX%1y;4#3U1{{{~x+Z&+W0S#74?A-2$~3=PPzU$HB{(!hj4kE8K`Vl9O{JD)?cD4LPwljP*CoXWu;kNj>8%T{$nc$x32S~Kr!K?yL2MCli(AsIZYafEn%s5h&jL;$YFvedz>#}M?4K><hQy0`;M)w=)IvBl4rI+7Fzo~qP^kYAF3}gf{3emH$q>I!B}hCsTE<ym1W}bjbwUmXVB7alfuKMOIg=Rfq$wfF`)CV7<hSH(!gKg(bQ>;cJ5$M@FI0QXx5M{o%2(A?MEakL*%YDIH@<H`NIJy&s6*{nvJBb0og9=_;7&ml`0e!ycR7CZcI^R@{m~u`%B3Dk4k#lz<Mrd1<t5Y=qgRIMTT^MR`X1Evf7;6{<B(b}h5XpR{PNlRwW#b-NWLfNUgpC4>TX)5#BcT!1zp0>4t>*X0bw>W`E_Vtp5P_)2aumX)Tdt(50c{tXGCQc@8}m?5|mZB6pN~M8+^L-Y%8b2;f-tiykf>~!`vMmdIR_l)q{g1@CS<q(eidRi<JUcqb(fwLI!&xJ4WMLEV}!;dZaDFEbwP4@tO$w9=MA&m-^Cfw?w}(i&v-T>dFZdAcY^ikd{v|-;QfL=$(3|*2sUIq4F9V^qQ?&x!I~NZ;fei=i1MXc2Xym<{s0S^SmSVD(cRvQhTT-qD3<%+0Qjg29|<v8HZ#Kww#t4L)rYTjlxu;Q%|9t-Z63df8DuNrgwO3)2t=2m%h>9dJFM6U&z5(@)A$GQp#G?;$e29(vN0D!_VC+CvBmrF_R^q78`3~gIy^Y?<o#zE_#QMnA;61PdVoPxNI2VQ*P=cCbj8?!a~u_vYLTV$b~X&Gp&yjld#@xT)Zb3;>Ca3co1=xNw`>)E)-5*W+8P?ufq1=M0$vWN?cXH(di~IXarLm;h<9;>AoT#tijt&B8rdRHdx{Kw=P&XGe1+HC4@efOlh;i)?Mi;fV@v(vvI4l$zvK>{%$cjTM}GPTGU+uC!5}g@{1@J+3qVHkDL&dc)y>UmH#ZNCea=x9zkEloIsDG{FActB%TccEx#bW4<|DJTuLw6)&fPP?;>T<nb0t~r4(6p<i|`;*?|3u<E@POMr*sNR~eFLMi(`;uT|yf5dv!+fTj67ZeaD;j8!A_$&qOC*+D7(qJda|zz`U?+z)-!T|_h*F-J?DOh(pz;80aH))G4&bp=lheYYQPR<p!*X~mAVn=F}YSw1h!eL`N_>6_R^eKRi(%N=FAExI)W0%&3~7=;u&A59Ed@`1AwB)}UWU0PT{!VvGsn2IQ|#PA~e|AD}7wNq9z)#J9iI0c&<<w=_O9>1DzB2He}a4N_Yy@ic{B^!E+BW2hnGz^gk7;Q+>ggo?Ryz@mL4k)44M=?GgnM}i&1YTu3nXqJgaa(a9+iWCZ#37@S_|y1uj%zi&^@b6><RRrEJ>qeL&0QIATRly<lyetE6|2!g75l}le`tr~ynT#Fywu*;+{xFah8z`595t@5V#n44XS8VQx5$mgo_6(UhO{TB2o&7;(3a6UQH*H-=-FGl1sTvan@QxbuNlup%rz2VgASU|)OKSl12!LH#?8Uu?C`fHVc7l%UVja+zx_wRTm%mf>s-Lz&aEf0J%zo0nxIp@XA_*!uFE63a4vn!k=)UU=Dv77V0%2xlxL#zd0v*Tt?-HUP&9<7jMjif0$`Cm%!{mgY0=>8V(}Bo@#p`=RnfOq=DdvK5NbTx5A!w8z5y^EV~tynS&~CNFJg;7#Cuo5?dFKcgn9Cd`Ml!y?gZ85(aByqG%S7oWnnhAMuSa--;GPE{`MT6!;Jkt%(*E}boGJzVsNy1pRy>o<qzWhk7#+Wb_g@~=t3@gt(_oeQ^u>Z%>9KS?=+`UVm%WTlJ3v|-b{PE3UK_kd<gvXFgu&gVwl@x)#vJE+VISX5n}}9fWD^!;6q`}2DW7<!|Gxl*pz6(wn@rKs-55bW?}f3+>NZjz78uOrOUV(vk4uQJU7_^A(d<5^imXMU?y@!c#!J~76*PjTgI2Wbo_#Yv?5(ZSbYUejcnIU`|at)K5KGVK4}(j=p0ABY(5U5wC_=R{L`DBxMIYCvIB-@Suvwu<skqZK7P}3kP@XS0O+&rC1RTIn5oM}_H$i!OlopE7j{xy88n)W?s?BahOH@!>d!id3ClI2J<7#Yj$(6ynhj=erwr@a?L7G<7HV5syhHt+B1sb3f_ei0N?kxPRj8EWQd><-?>H<mkDT#|qu+mHQ+*b^-Ee&QcPgkhb_~LyqRnUO+_HzHjeE~aS>`|_U$cl~b|VALb*Bb*jf-xDM7A)AL3qiOi=2W5Vo@~6Zb0?LKiC<P{<f1TfNtRM6U()?0N1fBdjQ|Da+OhqS$Ca>C4XLNKtK4T-|U=3*}d?5EK|6P&S5Bns^Y){x9mVEHG3fQH&teqZtQMn_zm05)OY>;061w-V*Xo%;D(8!z7UZACpB&`ot&p6A0*WYm<61z!6^jv5dD0!{~NO)!CySf*5(UX&<&F_Z(|prpmUNRdAKBo6yX<|%xhgEGFu3wZDw&p<EP%RJYd!u4ZkAkG1jUSDC!|e1mM(L`GkE23QDKs5FX+>39R`OZ`CuAICz-<2!N2=3>;kmR<~-n_{aMvi~x(V>3A>D<%3LlI7Js9i1`{f?k&Nnnog?6nhyWKEOJDZFq6Z7(>;LZ+W&>~Lsp6z9MtrH?z*C4LFc6D&T;UT%=Dn&VXQ8R7Kz)@^1oAVTTA+j=oe!c>0ky6?+_;@ng`x-M->C95zPGp+!gAxB2<yns1fqEV6L=gK0W~agiXxa4i;vJcE-a{F2<azzz!~Dp-uo2I&1GkL~xlMf|W$#44WjkP>0agc}n(!;MhNzDIoq-u#P;e^nMcG2Cf(<f(6dBu(S}CInBe?H3^lwtt8NG*DS!ISbG)DacefPW4#fE2t(c<D4TinyGb8n&5GtY4^!h7P0VD68woD@nY|M!*n@xO_sJP=`(Hai(tpW-zXeAFA3m;34>16f;}^7+IH%FGMD^?1;P*O|bR0&3FCEo9BHJ-O;o5k)ZK55Le0@Q9>Y^iT6I{B<7%~z}pxV5XYI9_~8vQ;17{5@s%Ihexx~e_8sm;~0Z@vgI+Cy``{LZ-7l&!<4voogPR*?@KA_{F6b@i3nzBeZGB2c>76mtPEv&WSW_L+Ll7s((+%6)Nxz^b&(SMfZm)p>g#<B;`{Vg&A1pGfTz<EP<5c^RUpeueUBD$b{2t~FGS2Ulh6=-n1DSBYjcE?o$`BC+_9Yx#zQ!)fglW5Arq>E>nWLzgwnBp6^V@3usc6fE2_FOkdXArjH#^&Z(hD31TfPp5>!b2>Z{m0@QyU%E6RfcUeUUARoLl?%lJZe^zr1kUR}NIp#Dh%3=<8x;qR-2FjYZs6k!w%HD3{4yUz0LyM8CK=)6t1#Zi4U$S+FB%B0)V%|imXb5i(DL?i?Q(7B07~;Jh6_}!(euyG8eNASe(t?htpC&F(Qx`#EM_Ji1wvPzC=rFHzm@UJV_H#q<oNB5<dj)o9~TML0QE)p6~k#Oj^K5xY4B2*X%4adNIu&=G^Y(>BKZ;GyRnGQeM93lKa6%voq(no@`fXhE@A?J2$@M=5J{V2U$!lA$x&mNeY2c>UWH31S77Bzwqn<e9yWhj^f*yvg%fl2jI1u}Wti^^FV<T>=uyR=of{oobIq|{#~`3K<dkA1=K(2wr$&4MDR#Xooa7^LSlvdeikQN)+x_c$zDHBcxX_PEo9ZP=8Usq5reqr;maj{spa}YiM*UN6(T2z(&duLhm#tz8Rf`W*%NnO_6Zimx1-R+zMPRR;F|s2!*T_K*r^TEh`^0Q4ZdozW`qK05>;xDjB&0dHJ25yd&P27AxWXhK;JVpg8&nK^Zp#y(d9iaPvWlQmGa-k5W?YqJE$|7+X*m4Nt!qbc$nF+DMGRim=}f9B@%B+`JCKf?{Hmxws88-tYMFA%m`2ZZL^Asoi0(pD@-mK@cZ(Ivc$X3iP5ABtG|MJH6}Bf8^&jqBd@#>7SZsT%ZXXkLz*}6)&W3b9;G)}=cJ>XUr+du%+w5{^B9lXc-*yGQHbD^%^w4M+r^sEGfO5Mip*F=h`JvVsDe<@1Kadc2IZvfqHb7n36R{!PA2nAM4Yha0)#55zin;MzIUVsx(HCn&SG4WV<0KG|?<-g{NK~sZMxcmEhm<@Hu{Zh4A8VUEWbRawwkK*p;f%Eql}e6_<K}@<h5JGtl!6VPF9NDFJEOLAmnDku=^WZVBcRfrUbJ+qQ<1GtkfEtZqi3%*yQ(s63iK>na>G~xf?&+ADow*|uCVX&JgJwUO(Hg4K4pkY?e1aY&Q^F$Eu`1q46)JYwS5lrl)cuvz+6WqLb3PVUF>~%RH+26WrjLJ048#fAixe6@S?0X_ar;%VM;urOkYl6&ooP-91QVg=;stxLSl3Um-ec`0?CBg)Ye>wrx;y-?!C(8L*RFb`4)?#)c6rJ9DP9(14SOv@+CBh5%4*14eSWYKOZ*vI(_soD16B=;3hVGIAy&E=TfFn)(HRbPYANtYRRJ9nHgm~Qj2Q!FR<(9{ZB<7bbnA>*{U5$dZ4u^zM9uNCk@t&pJR`v#O>s+yQxa;kwa9UvsZ(K0!19y0GKPNF`v!=xT8n#ZRyOe=5|7<?Sw&cSpXC5xtj<}rYECDM5pyzm4`FSxuRfOION^YbauQ3?en)kxj$O3&GON>@HerTh`-5W#Z@-_TS-|cexAew_8MREb&THP*5q-2wyPAMHS1$($;kxr&^m?r!v_HX3E2cQ43anGO1!)Gt0fMdxLBk)ND)Tl^VBf#%r`)pR7IV<UOHOn{vY9=H6yFJH+hy1T}j8z+2;>V1il|;_|>zpC?yJkrKeTQy|$c!HeX&_$w{40W9o{;MmcK8^e&^05MS5Srgwu%ohO}#=MXgLFjep`*{>Rcb8+zXJrCyFTN|BF7Q#<Phs_m($WRlPXbqB_4dYQ|;njrfk4&RFI??&1z^?2bUmKK$!yMT%>5rFPKCfjQ3XG@bf~#8l#w=C7NJYNOg9wv$j$Oz&6)a5{u*)th&n7EE4*|lZYxUnNp|sbDEO2lk6a_XHontS=L!bAPJObTAMOean*2gDhd%a5A$HV^{{DOz|6JMJmYu=F&m4SA>j}VRObsO(Nrt_6dTQ_P@)QNhvbPwr>os9Z^9}VgpYFomx7_}+Qo_@dSNbQeURYD1v+v0$bzOy&n$+of7p38DLv$37BTqC7`h^*E!A*A9Htm*CUsEa(r<Pg!~&Q{mH-Fwd_oqiiX9(vGltG)VUpI`-Sfk<}H3&Gkqz`t{VN+D#c9=V^4FAv7-;gx}#Y47U%{|wOcWpQm8+~18w^5%?GtVIzcHQc#Nvi(T_kev329aM5_Dpa?rbT`R!_Pd10L!8n|lnP>+ee;N-V*UOnA}O+78uRa$_8I>y*Yo_~08(VBnD2fIkj_=98H|Q?K}ibyJ3&A51EiRuA110zM39;A%Mr*|tY<%ai><^Bl4(hTWIqQQb5ap!x`Q0HHVR6vnD>l9^otn=E&MvfQchgIQGU1Z9)~Wum>6T@dVz_-D=Oip+%f|pjQ$5wnbKcQ?<XgtFQMk#R}a#)7?ur_m3i*u?bztC&J-OTT_x;CgB=?_gO}%Tuw)5K!cD-^OsU~pETI<B>L_+{OQ{}1u55eVJL_eP?cKmoCZYcJcLXlgEXS5qKAr43UL0_CJ#&`+Av)Nn_9~Di-ke*#%zWcQ$&-M-7yhLo5tk~#Pnw5^B%+Ok=cS+5HP3B)<na%}3RPkB4(hTPP@4};F?}v^%x^+R$Z$B6G)_%N(jAuRMylG)_p#xI=o8by?=hD%j~Y@`BTI?dv7gnh=$OVI+kBSq1tJ?cKx3v<0uLGH@!~fP5>3#lh$ZKPx$OZ!Z%y$}r9>{dl^j;jB+*@>cLJ*IJpY}jA@MclEl1(~+0%TY3-zO1r6V4J6;3-c>k*#aHL7z{K3TjVFpe>Ax7o~%mcYf@BmnFd%R)F>0jPa?2H}W>6ksGM7f+N4FJs~-rm1F*MXv;yB955f)~1mF6AR<jKE<FnW3;;^jy%X4$>_?|G6N3g@avJ*4Q>k0tTM=m$j5)9Ed!6t7J&k^MRgpsN;KLL*3nQ<aMFSN(ZkszH&mOT)F@`LIFSA+-X!9VUkyJXCf;%;)f4XlzEJNNQCh7CU;E|?+N@KNNlbwBAL1ABDHRHsy#$kHvP>wQZSG?;5?K4m`M@nUufexi$LMt+)Qys5u)Cn%gN3q3!H+a~xX&7^$*kJ$<PYxuk?o1N6!p@o(@f>wI560!y=yl{Z9>E>X76@jLfs0cBgLSZ><EFf@(xhcBXS_BIrpIr{oq>?t*|Y@z88LOAq0tQ&+QW-HXo0=PFG_w_48v-n`VbFbJR$A;oxi|isUbfEud%}spK1x9Y=#W=QGc&*Fg303C&7UHA3MrPH043KVo*OLN`~-kC3If8D7zN6vu<x;P!?NpUNIXnA5Wq%LaRpC8$lFv6G*$O=IQoY2VZmOZAim>aMbgOsOVm(M|{?Z(r61N=Br$3VNNgT>cca$Z$ic$DUptKnKy9oaJqpr!n5+Bx<>l#IXkxj>(tFXWF@IuiU^@8&xzCatWTSyNZa!E~RcT(!Z0_?xmzF<noCjI40GMdQG6CN!@92R~)i8R``8E^J`ySO94DAaWbXcMNG{3kZy~MksWp5T5o6bVWKIOf=20G70{W-MA%)*2`<%HWu_f?6$UB4XI7MnXKa9^`EISJ(aD0ivpp(wzDvbgSvne?ev|5-N4V5f%0nh52+?4aUNAP-AKl5{<S6zwphdo?rt+BUYml(Tj{M|#4{lp(v{tmYsdtdLaM#n(Ys0T1RP|>A{WtkhquQ@5M6H+TZsaa0Qbnb5bfxf8$EN>1Kp_<8^s1Z7W=~*9)<+AO5c!E=o;0?PEWLv#ud~-fO8L|+O34|(%?Mmz1Gsm{eknrA#9k6wuY&X@k9%PdSp7&VmhwEgOdIC9ql<XWTKcc*w;zILd4Q(HV~bUp+d=aj)<Cfhla=;dR`%=eSP_%hRUNpXIXgNhs1C+wS)DuYd=`V=(Pf(yXVqRtcc@f~UM+rxLVRbjkv~{iWv&m4<F)d|vKVFjWH(UF1a_6DQxDYCK1wG2{*Ua%53Mt_C^;@wg&I}MfswcP#s_lS#ZNSKxK^-2siG;4+UyGJgO98fCZNnbT;-Ap?Kn=Cx=594f!ZE%|7=@d@DZ!#T-ryC=r+WCt$eeEflk3O@h(B(&w{aO2yMZpF5zP~X01zoS&Hde6~j~@+~U2V3BLdU`wz6@>IxwulY9U;hJ{r0&NZCrCD{vJ6`7#4Vq#ySKst(UWuQ`$lB5+D-9P{}ToGldH5_bdamwcT^V_mVD>$<y{`upzb4r82c%y5PEi?nW+xsd!Ro<hY(HlQ~oM@DL8Mqd(e~ZjPb7p$XevHqj3MBvlrfZ;)h(_fK00G}FgNXqE+2h|<vBYQl0ssI200dcD\"], \"k100kit_core.py\": [\"db19969dcd6be4da263271904f4bdb598cef237a307a9b31960ce2723bcb63ef\", \"{Wp48S^xk9=GL@E0stWa8~^|S5YJf5;Rx+Wn_U1AXbna~Q3<Lo$NONZq)Sj`J;pN0V2$UzMgFW8HdaH=y2%hY|8d=QL0_Akt1}oU6ucrz>W1*tIAZMnMd$v}F~(xZFGOXhQ*2fnJkhKRuAVGVsQzy63qLCRhuh$xM&8&dh0ZZldaSU03GbRV1F=Q;PP)@Y+G+zI#cMdsUOjr^R7|xTO_SMPanSQoD2aC3$^3c|GIZ`T4U+GCqgpYfXdk{c>ByD@fwm({y9bK@zr63t=XXIeR|`@HTZbxn$u>j6x(srPI=hB`hievGL@|wW>=6~TU^>I4w5Wn98*O7LT8QVGh84cdh&ZoD{>`jAo6byv$I&vM=6Hs#2}LIgW>88LI7!??n6L?(j`gA!aqG8!v*%h4y4fVz>wKmmC#$N!ccgtEPq9?-ef8jwMBf@DSA(y0g%a>wJyiK5K|B4>y8Jdo78V_c<TV-*)?L@$-39IV<u2Uax4}>5l>Qr;GcE{6YU_s8r@^HSp1E(k?%~ao-7|BPLySkSrq>RgLD@>=VWzeSaDXfR?yZ^|{jV(YVWxyfr#2MTVMN%qEmM8$68B}{DmuW7HiqM~A*g1Re-OUqp|XuDu2-)2D8sj3Z=H-}7A5A5ymtdTqQrzZ0%*EX76RT*DxTzk1FF-QF$|j%StH|H7i;zLfE(Z*yA0!cvp*Z}mP>gOZ}fF^Z5R9~XG2BDj0XE2Q^@GgpWUS0Xr}>5qpo9C&1M#<;9T)@?mPC9S7+UyGN?*hK{G&vx_2fWQI~9aq6ctP>$=jkmGsP$1t9oiOW;4O!3gT~^<z|@QAo17c-!)0OwDpB;m=tr9<cmdx-@`9lJSH@Pz^I>cf)a`FJy^%E{x-A4`!Ae$)xeJ<N4J#2l-{Y8C>#4us){Z9rpozzG6KawN~KiHxKWk%1byDs|+hv&2j@Gi+6Ko!GoJh#Lek)z8qI5Vpk-cuGo*+ivI$w^u_NsgN=UzI?r{#`QAKP=Kba{%FB>ZKFutaZ#r{GX)*_Cj2wF<VVYTlvE!G1QF#Y#$_|6rH~&eAdX))Cc!_t&z#ttqiN@C(f~OL`>K2ZQt!0hopTGeVsKOh&!&43V8{~0mvZYOT;L;7LxY&Ywt&ab&S^eu63N84eS520SMncM{U2b@GZfGd*5uxT)O1>`N8!u<k_R_23rC7pxq+t!Z9BMazr+;=9Stb3HE<a*O7qR7m<s$})T$^1rWzC)~;}|PsS_u|N)aYU9@kln<!$`21=%bQ?=V!Sag#Og|FuVx-{ZXJ#sZ(V~CNck*0WS!2GW$lRsT6BEevkcaMBa#~YUB!}zj(!a^||Mya8yR=yS9qB!_cajLMtJ`<_#T?>1z6TK2s#G*YHJIfVP&7Ph*H*i*0k_S?aq6c#xlny)wI>7G*#_Vhr9RBtUUWlbS4!b8Wym_gY-K7mGe9=U~m$0VLXV16__ITKwF+$@2sVZgJ+3#hIs-_7FoE+Xc!n{7Lha3?qSeCJDR7%hARH=$2;zSbC8=GDOiv7h%+;sFnT=k2XdpEB`XT=Fb<7Fjt-8C-e9#6^;Pkof)S4{E$4>C~d#Rz?Po3{Dcn{4hSiGv4i2oA^+v)Md-oHXB4JL;pC{_a0V)At3yfLR|0Q10KGb_?`K~`<qfWcd7*LO7&<YoRj8QFJ4f~wWS?RewL4E{l|B(ILTDzw=MJ=aB8uQM`I#DhdM((~!kDncQj!N_h+Jszab;aGn5rzMn9nUY8Zu>0TI2PTCSsZuQu1e=x9T(;xt{84?fI-Y=TG!365O~37bd}&KH{BWj3d5VuQAKvzuYA5(^T+m8qXZ}1Z{hVPgON)#*qdaL~HSWP|X0`$v)H|u@C6&+ZV5bY<;G&S|E?3Vd<p;-^RV?ITA(>lK0OB-GKX<-%)Ib%w7~=FJ8&F-c6>EVW(D*xZ)9;-$Dgj>E{%;MA}_h!B&Y@ef$fP>IS;>2o01l$0`A?-X85C841f@2e;W}U3O`C=DNo>%xtEm2{ME_*s)UJ!n<mq^oy*80Z-rU<I`Gb1a$u5;r>H@|CZ~Z#n|xYOhT>33gVY8mvM>b`CzsoiNzj%tn&c~4eiqZT#9Iq+px<L!}5BX*sRzp=4U~Dg<F7;mak5?sBSXEs6Wjl#!UNAToPgZFF+lZ5iOaU$L*P9DV)fnT+vC2cXBiOrd>{vSvuz(k0wj`pGzJzJ!%)dZT{vN2aI-6>{}LlV~!$ijG}pFWt)$XvfMJ@S~mq;M1sW^W`q@;syjqJd5XGKeN?Xsn0*+BVv|XcbLgF(8Vn798^o)I2vcRpI-syR&*7Bis4j{;jW(c_To9{VUCOGCUx{OM@uw2~TsE?@5g8T=fq?|baTpc$sOHmlBRP~OlXI{DbV!a!vehxyhfYqR1Q|?sdeQp;Xo^*qd4OUNW3P%m$VUTJoZW45xyhu*#V54!;jRGG(SMi3Su6xM-iRk@w^%d^+37$Yh`Cz*4CKu}b|w77LgVD@+Ih7?9XSDJlk@%Hyf(jDD!@@WnDrq|dwF=O*J)?TTp#oK37!uu-@ZMA0yp|HuHsK~)5gi~44nn9=;c+hyFi3t$7n45`QV8it?{(>lhO*^FmK6Z*%25PhSkqSgO)?SYFq-~(}_zWVep|liWHUQO;iWWC1Kr?C$FDMy@=?m9e`M1!l8dq;FJP@>MAp6%{a->7oc_JpEMVp`;{6(&;o>68*5(6JL-=)4-$J?zRa!4ueA>Pt==jZR(nrkoy(&bjzfi4jp9)R@DRt_TgrdUA2FFjw*`15CF?igFU@@YSgQRxLRCuY&qzW^KB5oqr-+R~jwM_DziwR&4m=2qC_?KoFX@ypE{42fb(61MSau5KRK+l2zDa;ThcxXVn9_U184FNvq!YkIhMT5~0d*q`KE>Zk4{xI~TphW$awOTW1S5_Oc7*BotK6~sS#Aaanlh#TTJrWdubsDp(u>y1o6{(CX5mMYw(78jg;oyQo$LUI@nb3vG~;4PFpX(NrSReJ*DH$FLg9udSY-8=Wx@O+#Gpm_5DE`7W$ifX+Om~v2ev#s_;gQQP)yC+DWppOoyBqomV6mm3s=^YKCBhB{2&VEFLYjZ?ix58^U+4ewK6DD4R0(Ynt1e7jk^EpHl3MR<x!Vo?iwT4ZNi1PpVXP*1-0^<P9X`o3}+K|^m{GGhkEo3#Fm^R@%cl=bi0)5@k8Gh<s2;A&qZ~+yUvyHMB-waI=r^i8f{n0rjS9=QZZ<wWhzDZT0n<%n>*4c&gRYbCKY!593M-|m-SjXjw~uz7+`FhY7@Qb83S?fJKA#KY&`Qfu^|ZZy?0hNrA_zjv8W4gnN3LZso{~42h9m1_*ZYd$eF0KgTGzM$BTkcR1rdp$P0s5BU#X^-}eC**M1u91cQ!7rh~k$t6^3UnnER)93+{X{_18?bCb3jSxf#W_v0QY#w}Hv={@^0lko@jCf;t%NxZMr8!+hR`0XF7MlBC199JAj{T9!jdG|GKN6??Jv(>Fg0t85tOoeX_B&_9D$nU|-*;lBtE7HiFO-;*k*C`^8>z-Az00!Nn>P1Q{Xf#MJrfej%4`<!U-DG<<OXGid2Ub_hJeWOCSO>wME)7Nih9z`*5PJU;{kx<j`g-@wH<}=JR}m=Pqm+bji)=&?)N(k=lGW7#I4&_#VTrv<`$e`zw4wO_Y$fQx*&*cEnF{8df@oD4`ysU7aYJ4=7^8HFK*s`D>H~XClXeDxIHaVd89q-Sq@+Xyk#mgDp6_w4XoQT=NZmOVNK>|Hn)C`nIGkD4C$=mNmT@DJUxA2#+LA7*e!xUx7?6zJ8s+>2gLIcJ6iY+M36*w#uBl0-A&Ek10jUF{9CoL+iM@!Eyl8uS_zk7!w>v-5XB!Y(p~P;dSU0k?HwEvH4js2gIHt^1RJN_QfQ6Ny_ca<QZ_*asMY)fapW1|LvOQCa&zJu@%MU$?Y5UGHJG?r5yXt%;geC&&CyxNNTyt@(2||^(*DanYH^hAN_UFmEu!D@~E2W}Q!hYVTOILGc={`XufV%%?xYZslWaP+viP%WaqFwmR8~tSaW?h@2!?x>(j_e6B)k06!KhMCnN2ztzJ5n%PF(#(dvk~aQ>|SjszkhqW^-V-nd~@(jB0~TW9A-spROZrF%Fqpc7(`4a5Xw@6F@K<9P%`%S`!Ac)w8&Xa!cgMkDEQ{&S|F+*&EAY**3&ifiid@=UW^7vS!Jo%HUs@S<*?!GlPuqB3E-MtzW6=s%mUB@%5d&DIC&`~ZyT3*Z+r(HxCUCpbw`?o4B7)p!xu`aX2ePqP|&~dMb1kj)M72EQf{Bq^-(t~XhgNpkoozLn(I?MVKMB*C8iMy)A1yLoDAre9QGXBsuF;&eD>d5=}L848k(j)vBdLfN(<|~6|^4NnuG3`P~-C4yQu_!zD#<Yz<`5O`h^_S;}^3p0CwPchhA^=CYb!Y;-vx}jV~hoTa+Vy^8f#iPTBK9IR_9P4~OdQ_>D@O9sE@`Hq7^F;XG+PAq7io?k(s+IRHeeXpJ(!H}Crc;kYQbczQhK+t9~C1Znjqhyu{7#{eIY;mg*++9FSeZh@;>&}a20IyFJmUPu)w8M7>QFBN#8SQF9Ba9w9}co>OgT3S4(;F_>F_8#O$ybym)e{Na^jMg!5041>AM+Oo2kq1fma!l1*>Ki(w!6keJ<NnB77fPL{O-j10#sK>APiB096wr5s0I7uK>zEmNM{M+BCm10BNKzu6pr|c3EcnV7^Lwc+m6N5J!NFb(q5d08#8Gc;aCn@{<?YliQ8=aGvkA{5%6`TajE>Xq`qC}*1?*1HA8}6<&}Z_Or)G(i$S-W4lJynq+;_eyPinT9(f$spUrGdiQW;`glrqsa^JJ})X|6YhVCR5Mjhn*B8E-JLQ~_>H$z>oiSY&Qi;pcc=g<j8-3Ek1{Pokupyq!T;1hNgNd{igy-=?)~bsjhUT=m}e6T(Db`nAF6FYjz`k$4@2^M<`2uqoafR*34Nr&f}e<RC>MdDGH#%eryKP6c<X>-upP$__{8F@2Xgm-{WcTSO_b3#>+|SX~ju@SdPTHer<ttDL!R!stL|c+1vgISkBCiOj}PZY_)?6uRZ9-|iysZN*=y6F*NYI|K-~VQs_?1s2{^T2o2|vk90*#Fa>-EB_zxQVy6fI;0EJ%Bl^l6``yea#3DD%}zO!e(#vI{|OpECeLB66kXq&pp$Uw0Ir%fZr?f?Hi!LW0n;+fdc^P-vr_OTZn^-u3}$i!mo1UAKWDvUYz-k*hCZG0W_he2fu7|t@o++r@iL51CyPc2mSOK_-ondZw~9!AreFO{Y8V7a06{)@OO&ipeIqcULa=(J2RV#<W9|a~)C+F+uC3Vm4XX6I#z2XngieQ_V;%t-Oz3*UPk@0*@QSC}j+Hl%uEvOrg`SDN!h}d49ACpIR#_<+ntG3I-}wMn@ma@AgevLS_4kcf_j@jeh!$lWOss%g)<TWE@&TvZj3?|!EaY2uY3>5tKCg6*oE#f0vNz}h&z4uiAfEb)eb18*GZ9$Z0x;8hnTjdwHJNFjfM^p{G5`TKxj^ce9x4Oe7VU*m@Vz^^>E1~tR{FUqn6KZLQ;#;Vc)>~YFexb6tz>3GIjPs`>T2U@u%$1@3`gf852A?%&_xHt>$+@tu_jpNEg&-GlBTQ`;N!~0-1ZtvG6|B}fgS!)qdw!^`Y6p;_L23yYBrN@d74<JWG$LJ^vN2Sk1kg1WG?F(<?M*@tTTVR?I&75JxZT$>zyx#J|@UzlH?nrinwYCTH(k)@!*gE<d;?=l8V7*i`_1YM38Bqs_f*OIr=Dt4=h`(`jp@uLSSrf$H4CSfUCkOH`*11u`A!+Vx*D!HX?r%I?#Qnj-^wd@**2RCeA!!urCEOA(S`NQ7tO~b@^hcA=#+nC_(<!HE(z+PIbtGVS4ET3m&ak9?2gAN{5*CzZT47Y?fQWAp~wH1Q2ySo8Dw=4D3KneBg;CTKGlUu!dl`8*e<Wo0h3hhj7i})ye36D?yugeQ9Y7LJ1LiclM;)LzlSN$!rX@R>!w`!&NAq@DCd_nts;FA7m}ms8xOT$>z7*60jOdcaa&@#5KI_{r*{)!pxpU1%%9m@9S6+Q{Vdt+Nv%Tfuh{04m(^yIW~1(UZY}Fe`k25&dI`r)!}S25Hqi`M4zcx6!vEoIz;~e&o1v)P59V~7Qqe-M}~E=rrs%gmnqKGxj#)Bo9X$a8t2$B{QrFa?<j_@EPO3maME!qCcSk2F-+}=pZbqh>86E&<%Hnc`>Y>R{KJ8lidy&fYN+O<8Q|Z<u4l%Z01}FwxR)cWR@*xS+cZ0JKC!jCHq74+zA!-^t0amK8@wO}8I!USY@hH_R_Aea(tX{Anp`44N=gmQk5mmMBfOAnK+}n!7F+9MVkz~-u|8E*x(h`1SYA2d(i>W(xKY_)BUHVb%Ap>Jm3V~2<!|ila=9bncH1X?_H6W5&|o|c{N9)XqezwX%Ojtrf9^_YubZ=l$9yXy+cC%Y)Jf8%We<2@hDTzf)UonKZBCBo8Z;|38C{WRTV7OLg}0@DaTpKK2Cc7aMWnzaS}Ku=%*5ai=)saZ*)*cMk-m2@Uka2#;<3-Ru{Hbte1^m`7hJBYAme?mTh8QZ%Y-rw;eV!mcJ_Cu8W2n;fd_hde}gRHK?BLTBw8S7*IGcxYDOT=v<R|=$Kzsibi}pmjq*SG(b@NhvXlC{b0-0e;Lc+E+AdRseFxeooB}4F8iMxGDs5i=eHd(jxhIZjvwNZ_r5DRcmqk^a7y>FZ9mpRM{~T@CZ4s}`e8{I_FglT!q#4+qR83Xphlx=S&vPuQkq`iB6HZwoQ;Eps4{`0UF3Oss7$mS{c&Dvj+8IpQT9K;#MFno+76_BX(ktaCi}?|pa}Pb*w@ka{+Ev$rbLlt-QD;hushx00#ww{VzK`WWGyiCfd1{vmHWSxH?#8hTTBRuEW3LX4?PE(kdX{j=@<~Sf8V->5kiZ9U3GFW0N!nJ3lkEoWz4KZ7grZ*T7?7yhlr<>6rKDI03ITt*i@*0I)2v`qt@Ofk58imA+l`1o7}^DciJ-8+5&LBz%~4J33e)(m_RoM?5}ljMNvaB?<d1fQ)Nxne56?MlkC%UKxe<MJ?2q5w6XUH6u0x32u-Q#3V&3GNHy+8@AKrtSTZ)ot?CoI@BW`6fhzC|@ZFXq@=5lsq&CJtPMNwmj2;0P<WgFj8;9-%ihzZ}H7v`B|LtRKW*`|_1quY(o0|e*>K?>CxV}59YHFR&HduMGrLFZ>z$+nP}fdg<Rf;S{nY6R_6ry<GF0?a5Q@Y?+1nzZ0kDFhBz;9U=E_H#uTCLj&x!Y))*eN-vTQZ_;n%u)jMe1|!G7_E?2D?0<TIdXZ|&@}vyJbkEyMm<N@%z!RUu}~T=B4HwRAyh=Kd$qn%&tChL+!XGa9atYUuI{bsCBeb98#pugEQZ@04kH5fbYTwWOeCpXQOO(m;={g>-no-=Lzlp=3piUf4(O@%G$T{}p>TZlvOgz61z7_u^B>pp&>#p4vG|7&+&I@<aXuAKQ*-{^a5}~d0hHWDma@Z@q=1VEvf@WY<Q`HEIa{j4`6zBP(Vm)No0(}L^QFy+v|@d$AdGL<SCheiZ7ZZb-ip0)ludIT9n@AEdlU4E-l1CWF;8<Xhh_g-4`vTpU=9xoeb%)7*D~ZK7I+nWv(Ok$J(0WaKeX&XRGBx8wdpI+^<uNfrU%wE%)48bq{=k^tn{1XExGc%3N7qwE!a_gKMp0!cFgpYg?_*hWfNUL$rV6vV4hy46@xVdl@8%>O+Tp5R+S7`reP4gx?#`q??GQbb{d!?oe4?gpHaHZ0ZND{&K`E}lsV3BufekyKjG&65FvkBH+%#A{bBNzIFJoNfHq=$f9wmMr85n_^gsqc2-3}$(nkmXr<_;)sh-V^VAw8qdH&uEU(sVXh8$*zU=ij0stuyQ&q=$h--fqZ=|x2|<6*&|`1_bew4HfJDR0xLtGFepEQ|8J@`9EXC>;34_hOd?^J$B@m!#jeC{#87Y2KLYzus^?q@Ub-uVo!_HoD|zX<pUPo+ek#ydx3NdkNy+!TZOz`vi1^2oM_;VWatLNihHt-W8f7_%!mT%7MkB3p66<VR+>BQ$=Q;A*~0O<3(?IlakiM5!e1tx}v6*L`?8AsEl1apq^|yvuTJpr(R6ticpn7Df+>?2_5yv_pfDT?ViRvOk_E7w~2CQgg_r(Xfhd4icP4&_(To6uqWLO`F5*MNF?e&7OTAFgWEGIXb+{ZjGqrBwSHLP+3dbWd}ScWlZ_+n%BLQZ`kOdW_Jg{N)WEEaB9zj7)2z45rc(-sU)DliGhLbYW}+wTXX|IIh$bbQ(i-;{AyXY1GH|O5_?|gGA4vz;;h~?J_*PitxZVdZaWU7v<RQO`ud@KuJ6(NK?~V)Mt8X@V>39x%)`c{Rd9^*?w0f}hLCRha|E?dBnnTXS*lSMG<cs2@-=+RwW*=;ot6a0OUb0DUpkucQ4b~m?#}5_AThdNLv6tqChyjT9Jbdp2xt(pq3LSK;H>HD@d{lxyg(Nm>+&%&z1VaVG?D<LMvye|jaZZ_ib<llAEm>9&U6drxsp__iF-T3<s!^R_f{YVMDm9a`k)KU;Jy02i?a4d+`y8)sbTBVMVsWcfIZVJb_>qkS`{latlz~!1Kb9y#-FYjrBh01OmO@SurfPxtXYZ*G$NhjJ>z4m?`aLHN)IxjJco#FoP7=CZ65Cfu(QQR#UUp?g?~gElyF>Od&bXf)nC#FG9HcNF-6UqQkuxBStCIsZZE!GnYW|C3s%lFRrV-V{o7e0isvHqL(JH!*#K4h%Q4IUAo9#Zid;%e_8OFKtr1tOfkq~hgmv5-HZv{zDBe#u;B3!aoY%gliJiRH^z5;nBTp#hMV=5?&wo(B!W^qIh2!A}|frscs00bHm*AUHx%jzM;Y`hTmQg}5tf~MR3e@VYs6|6?@Skc5ZKUk^XQh|UmL$J+DmK*8TEH|o}Nx8Vp>U_%}B`2gyfnnL|a(yYT3nFYikLmKda9G&RwK~YijjvbubFI7&wAL#mlb+hNMd|I$Z7{n`P-G@~dA3tWtlpvhqFs!*SOY+x{%gdJZrvL{!EixaHF>bSiu%KZ>rU$(TXAw*79++7{5wL^+2N+iwew8dzM#1?mS;A4$^VA+qRb$naxYb3z_Btzj13FBWUpY*+{ErSgJ~df+<z{lVRHd2<8ud6luT{}i%zTH%~k2jZiGRkr#-8Q52+$?7Lu61MJLe-OZ)HX+H!eac3+M0Ohm;T>E!Kg5xUC+CqBXT`5WQ^M*b}6^LMqe>-gQe$LX*kyJs>?rn8nUgG~g0GJZZSP+R+iJ`FOOSLV#{WA_bQ$*mF=6F(9IS&QdWjbf2oT`+<SVHJQvPcmjtjHaku7Eb`Sm-8x><LLOy!R?LVBTI!Jv=022R8~8o9K~DI$Qj;0M;9c@Bnavp(dXL2S&H8^t)l`IS>oIpaz`OIsbm`*%+U7Jr2#c&@$a;<jx!ypE&-qrNq_`$1BiMl0E^FJPh6=giD*=rmwD?EN<Ol_2L!@pktnM#uhu-r|M+kg!3+@y@xH~E!F3p|qVfk2J=s1SxA_VZef3MX+xNAnKEZ$z_7XXxAMX3PPq`f8r}{r~Q^&j0k4~B{1-cs7=<}E|rO@-eOzC<8#rYqN7Vt5voj3Dut&P)JE#QM*b9J8Iu<LOAXGrdUGjT0FHQs#dEGOLJP>Nmm?1(f}=~GDUCFJxqnRI7dO+*g`O6sURj=v|W^4P3#cEyhkso$ikG~rs9OBi8%WQ7t`>P+xt>-TqcM=~JmR>86FG-3+#{y~_|7{fgh>(0W8jbfF(>uOJXeM>0T+;2uKkPNfbCDyYBj0`lbnQ%gX$GL}!%T)Rp_kXm|bqe7Ibas2QU`%h-ZYo<#raPd_XYns}LI&a6mS50#Z-BR>ra$qsQR10*|IE5G#`_N&*k8~3Q2M~6e}$uSecejv)Q-T9vO4yIDeU~)W~;kCYw9aPuXh81zDan*jpAT~DlnkrcU7f2VglQY(;YO=Cb6|A`hUPsK}a>>;*yC5Y@(uq8;f!V4ibBJgRLZ5Z{x1m`qNAd*(<xH!JR-aXg{DXj9DW4$Rx+|rbx(9Wou1nCrI%!jQTTP=zXuL&^2$Yn-|^8p0w!Y1a(vLtG^_|dpSVdTzSOT$Rna7TSGxs32z9LK_S6IH+(c?*mTFS<qO+eEwdu~KlyK}mgxXKk(4QkaQMwU9x+p#BS6FRt~pA$L|O-(7}#4@NU6Ms6@Fu~BhCZJ+IBt3NiiW#HE)$O-h4y6C$(T*Oe(6MBAIY?Jcg1q-^Klr#_|O=H)xkJR+6m}<@gUWtpKp4a5l-h`;hb&@!K3&5AfQs2dFo*O*oIX>`<J~=~$nfmtFBvuU1bWU^#r;qAK&3sV6IN&rpiB9NK)<7~Fz-wkUsBe6$rCcIzaU*f#s-89}6gfj<5;Ufu49lG;QF0Dg9>=*3=CqecBa{XzNlLCzji5>n%vo6d+N=t6~7k=bl=2B(xijc2&!H#g}zy}M3}KvB#4un7wRV~H4EH^Hq=j_+=Pbeo9=*^*>9e8}GSR){h*|Lr<$*_2P`>T`RApzuSUO2z^Ffle6Gz+iuSI9(U5S`Y|OkTT>CTvfz+A|D)IPm=vu+Q#A%)I=Ak@tgo~3nvjgR=H;>=olX5LY8Ht)U=^SG#xJv3n>nlfN6qtPVHUUToGRy(2C&w-+J$b*Q<kOPu1JCJ|#=Y8+Q-b;yAw8eX4#N{y?+Isn8+y4nry^4F#YEdttHp;BTK=WanBhJBtD!Ird{hoaw$wS>#~27};ZDwNrxU!IM+aR2#)!rlL57F!_1kl$Ye#)@9O4Wh|gwbZWkuG6@f-Iru6tMjnWiN8aVQI#bzoKn^E215&AArjV=0op5Hs`fd?AKw0suaB@AOu4^x-@rqdW)2Fx()h44og%?UAnF~#2Xz?I{UUN?-;-swPFKF}UkpkJP8c^&ZHhj;;J;`upF`mSQ4;2l>?0arS1G(y$jEjX;Cst`Hxgh+pkUUa~@qd>IW0;`Wn1m3Gu%OFnqA?vBr}np*Qcqxkyx8EdF<IIn>=&Z2B4CZsu!ixzrBZ@Q)ky#i;GZ0K_BYO)YL-XrlnBF&_pWsBhX?&9@)HQSR(CzpH_qncVD-<zJZlx8gwUGVi2{+My2B;B><8~)7P;sp-A<#lTC3BwqIhsHzGz8(6`Q2XbmUB2Cd}%OD1FxqXTvNY&vvyL2qDMwKYwqi!m*=NOqto-_p5sKu(kqzkaIwr{jN^$zDyjf&QK)P;D>@<5WdimaB!9gLjGZkIEg;rGS#~Se9Q1Zp8hxW8-l%Jk?3w77^wwhJDZgYvdyc6>{L>hE$R<dhzv(fcO{hu2}V<}d}_){qoV$fM(PUS1q_8EbAaFcF>b7mdE7`gL{-D+w#&;G2&mYw=|zrld#BJP=Wj0z2Rc>PlbkX^7ZcMU4}*lonrh?{u}bR|K^TPKgdtIeEZInT`ABiJz;KNdNl`H*ImB@CDETLT*nHRGRl8cYWV(CyMvd|#^KV1yUV}5TTA0<?|80^;Y>dbdnZA5>e}INK0@jh1HmO)&2CqXr@@6-61U=~h`)gVCkB6mx5KU6HvNGze-VU|h@4?MPswvejG+gCEUrhbdaq$d*<C!YzR1fwjXP;~dPOrJI@${)%zYbrj7)slIuphqN2oVWq)~sW@+o~RRT?>`=Y8^o&XV;FTGeggjA#TyY_?zX!Qm!yU)qbE9?A(CrO;t?GqW53uy1P+oy1)4@#}4;Piv=#djJy?*#@ru4Sm<H_zbVWV?!ao^cW{|CI`r;LxA!jtEq0K_86k+zMiPvX&E65zv@#`_gI7ERTC$B4!Q=BoRph!d+W)$SgsKn2-^_29(oOaCxi!lSB%0E!-hr0?6euZ5<w!uuiTA8)A0eQ5z|;I-bS35RzbkOz&xwZw0bMV(QqwBK`3Wu*0F0sA(@;qfMkMi(kWU?Q=qeP_zZUJlLCQol*@^c8CFvO?3w!=?!m><~you|30y7HKrn<6TdVOn>D0=>aY;ITq)$J#I2e-SS8giWsPpgc+vq>Ab8G-2^;jfNLn%NTJi^j@Bt?Ez_pNy!OpCkS^cFQATE<{d1^C`R`P&Q$z(xT4h#HWXM3O@ApZa>=~9fc!e9=nE^IuqqNM0W$%$O_=~teEX26qe39N9Xjxo_#o9x^`BxKoN{`bOrv-d>w1c(eMo04Z^3>UTk<k{uH7=DP|4542XfeA2}0H1BE794Yp$8hj=7|VQ|*s{20TUD<12QKcC#Z<oLr=o(OG}JW~n<1}>dT4eURyZ<J~W!}C^#d+X=<K{ld=g<*}V0Qg~7+)2z|cT%eep~`D~u@}n6IyH`;hZwW)UxRKJ;4EuIU?ahU_x()P6e_#t?o`s1($uj?k~EDeDv{J8{1B2^%f%PBWj@#MXX4(xn!)Hcb}FNoDal^2!^AbUFp@e%L^C@RxB?aKx*ke{MZQmMjmrR^yPly@K0d<Q7l-8FdRGEbAwH_~{_1){F^9%&J+BR*|F3@b_<S>Uru12{d>QP#jt!PDms0BN@D-c#<_S#@dTz+Zxdvea^4A=GLo$m%1APs}!=J7e%E*b1;`&P_Z5!LtnFCaid;Vsdn;01E9M#7xJo-H!+a?`EOeL{46>Ay4EkHDa$$g*5#0(R6!jcpwb2{mLKepUvG$ImDFHmFFmcnlg<PNzCs*2h(RTpP(LF0}n(Oc}7^W@U#mZ6~v;bT@I)97$4Ucj{yy^Y{vQIZ!et;-)RX0T2twJbtS3y0W(La<|;qUPcfx#ZL;{`_RuQZw`I#XVrmSAlZ1Q&E%&#F)M**ZjN>lGgx7etW;4J91VNRtBhqR$qGMRV+gwMG|;ddbmSggA>fcO-zIaEEv>{EOfNjJS?@GII$@UX%36|N$mS14El*g7zroGqH43UXhWAg&9)$F_()=CYDsP!;=lZbMs0IV-#d>x5XEI7Zb;Oj>96mz@WthzI^_gQgva=mt!5|T(axm`S(UJ{%GdJ|-Oi$ga*$muiB8OjeU<D9;MlN7lG{a_M7f@fd>v)fkg1tfHW2BZZ<I*@G-e{>{GR<MG}w&%n|2J<KiQoARVYKY-dltTZonxSY3#u1-uIqgNRP&bvUO565%U?WoT&t^+3x@`K&fe)6$BBuLU!y1j!KLm18eEWC?L>I4hR|*VeOh!*d16CNxJk#p&E?C3d3>)BRAX8Cpko{hCVbo-_n+1I#hYZca{5AwA^~zY>4U{@5B7gxeM<#G#(TDKy5$8){Tyk-ZprciEaPZo{JUmqHCJSuw6L<JFgfXn5n)MvS<?bd*edU&M;&@xcBhSx7P~EX{1<E$m<Ha3;P}W-kF7jYQnl>o2WfJLm8wKs`Z#Ca`$x7Nv0yOi6&8c#$$bcnNIv%7a@5UH^{L<uMQ;GBtTm-j8N{c_Rco}5t~5($sGqe;beOjqFt0AtlVX<akT=EV&4dQ>bNf+j%NyFC8>i~OGvgIDKH7-?x{k}`(c+{oGfV=dYXu#GiG*C3aMbQceq7S+$R#w=}{RP7gX#G*$dnPwS@Me)-&rIE(e+h7))Ks!ZCtReAHATysJss?@SB^D?vB&%E<~yvP|tg#?!ZmU6lngvvQC1s;1Axd6rYqbx*PfYQ9ymN^XWX$=r#|6dUb6YrUqG?v_su<n1s$+N!|l&;{JVh!t#Ps)mD%hHGq)6WM`N^?*N=J?Z+quE;=~2{`+z-d87S6=~2ZaSDn<MFXsc!ygBYFW+||l?z1Q28r+aaL1t6roT-Vn@j7nTa-n>u-UvIES`;<cPK{fm}p-Or?fUdS2`nCD>h&P=LaXD(R%{4i%Pnu4IWY5c9b5de+t$#wqjdPtdJcowe(IKz$y{e9VLIWY30vKdjs1%CZ=EnmdOkG6mpO70e}7g`{pf^v#y#RXDm?%t^Y>?oo|At@M%7`VnVwxl76a!zKGU<uB)_!+%HuIy9joKAhaZI{<9QG_^2VFj_37cf2h$D_NMOpDyjxV_i_pE$3_xv-}{1Q5YkNaUCb5b>#gK$2K~^1aI@?+@5wxLKTxtb`w77tVa`0th!p^L@Irwq65tt@guyG(Hl($<pG%r7<t&C_i>1##IWR(=h^lI8jmz+^@g+;JSPi6Er=^*z1d)E2M|E{IAeFQ%D>LX%!aL80nT(zwQsmo_w6IXvVODSI;?L;SmH{+g25`>79%gNl8jhm1nUs23gQKfrvmD+BjfRS}Ll`<B<9rwG2cpI=rsu!?6*1H@$M9YUYH}Zk^Y9z5jk6>)bS(np`>XV70>@2{{Z6OatGc-Km`m3TnQ^W-N?oI<C_A2YsV9YVyQ$d~t-+_PQoE44AU8zii$wBj<BCMwiC52X6D9OGm_H&jT6%C4^c@O1&q})WP<RqiPOwhxF`Re2uUdR%R|wsNKg_pnFATiX!*&f-=n5zy&B;XyBR026#kNp?ts|}P%&Xq|0EPbNXw@RegHxT9G&deaIyv^9UzDC;9Vh<T7yKzpyoE6c0|0s&DR(yslAr(Nq;SCr_p>5p1*vpqy<NvJqpA#i?Eu|}7L1zss@=_Qi-Fy69Dr<;-WxKQxVTY7!gm{CynxsA_c%;>8H;$zby{&T0^XWRFcaiWgqk{h^i!X~POz?9xBj=SyXcI;#mf<l|Cr35F_A!Qfd)LbG?}3mx9qZ;^!&z06=y@iU)4=&Z^x#feV29I+0m^^h+%lX$GPO6J`Rs2Od~bEo$$@vh2(Sa4%NTn-qH{fnXYB(^VnWQzrQ$xgg3xdSii5M7aMQ{HHa6<geJ@@02jwa?+NoQJ9zS%&~<0V1s*fZtt8#0_pTj07t(bUEhO-OCf)jLn^ggfD`Uc?QR~CRk;eszhOm@HX}AVv(;;lDjgCbK>4IUficzVZOU;VL`(B)AYhRa&1Yj%;2v1f{g$?f>2kar73R&Mcec6H762x6vo(9D-hT^i-<Z1KZ4~7BAT1TMb-KpG>s#Vl`N)IdPlg<^RG&+JLQuI{utK!)mMoHJ&^whkLOlah-KW;WwG;AcaMN!TqlWPvjbvlXXeXSzZJ}VEq6Md2AE9iHUR`sCGOoE{|`3h@8P~#BFxh}hN>-L_#(<;Kd75S_zzF+xgiTyGinmz(b{5PUt925BR<>;h2p4xl4<Nxre(_Og?rPLTtB=J00K$Z!BKly60q=FyR5tGok?lvWO$dEn-H~NR<wWDU)fTRp=W2ZY*(CeAmH$$dK^*9L;8HiqTxpFd>!+S;lg)nV@1Ktxgy+b4h25P`z@F%_tgc;uw4<7RJ06~s0)nNP%JE+Ne7p~O=91gxjB8<p;^=(-7XI&`$ivmAa^tCmvQB8>tvg0MR5_U?z4+vpje)EFk;H(1^0(zPYm?E!nIn?8<%TFz9B$-d9=ed(qz+I7rc&BzpF_|YAPbJ2>dLfT@d-0!&tPr;UW>>eJO~N<CHO2IU=N_aBkpn8C^6VnRTWOeSaNo2!MgxDKJ$Sk62!-VzX5UAAT8;Sv&Z5=bHIE*buObfGd(%}js{m&9j0?m-w5H$^(MqTUnLpt;g!5^;s$)Ru1#l<%K@lagRg<By_9UL{<ka4S4v(aW4=nICR#BwEHkW?%OA5oV1H9SP;?QnN`x9!xN}QjiE^D=@*PXxZex)L_Cr2fxjj93-FlTFg4>;K08DG+1L&gZ>qrkE*CC9jppa!T$PbnAH5Ps&Up8VdcJ&3RF$fd1QYUH2-aG8%U5Vs5R74TI(Eu0$C?$(pu{%KC~(hYQ-zf|V{KtSNV#Ieu%WP2s`y|R7Fw!)?hf$WZ+NFn8+A{j<;dz$+648xQMm?|B#MK}J08@M}53UU>63Fh)Aa-J;Jm;@Q03#cvShFCq8O5sd8<TXq+JMI1Ih{<=kAO@9+UI=U_XsZrfzYc{k$h)4BBukF!luca1E@eux?RU9$bPnjvT$<~ouG&?PNm}bs6ABOUFAaS2qLJA*z2IBWQl48_nBRb)9#j|>b(Jz{KXVbtiQ<2UxVTUqTOA;E8&8$a7-|%)E{sVsPmTpsNQt1o0ewfjJ16YmmUqZALo+T?llsN;;!(7XT39z)Li0pqxNM!)1Ws!8v>GYas>qRZ2{dhrZ@9?U&8W4=J2sw^0dKI8IPHQ9MUQBvmkQbxCk4Y&4~p|mhxj4NZ#l0uDiU<%#v}<_8y^sCD;1Xo?*HjS%&BM;0U2m>I)*HqyMmlhE^J($b6-2BXo`qN5>NxTQLTLDZ=mPQ&n2$q%NqON{CwE+la6fw;B~`FyJdFlFXJUb{s+g}fCegEdk?H#CM3IX!%jsAJR3FZSxls;qY1U4doAVJ`uEn>Wub9-G7;j)maPq}vWeLPlCx*zmzXpVwTvVAe~;d#3aT!>S3>$e0eq}taV9R>IJA;PU7qeCj(3Xx2F$^<8r5x4Boq~NShx+zosQjz{1UYx*DpjwFNSNRwhaDL`E>!}53$O(i$!E+a&UN+XwtGD{J~WuyAk>volbs2;>r4pb=wGqg1(*Tl+_2@`_eHzQ%#r})gC>CbR+EBa7eFgiiPf#*seB_wUW?%AF>4lZRWU2AATh#JR4qi@wX#aj-ODXqDZ0{xT)@pW|&!WTTD;ui_9n`(Y+V%)N>|dV~&N<P-{YAT)WEFCDB~SoTr4uOucrOIC6;sDc;&lm6yE?Xh;j-OB#nAZW5g?sSBZeT=yv~(WgqYHKYt*-UXZM^3rS$lXx~RkRe-?K0{2U+hU=Fvevg+T?;wrU<g%k^x(so`gFLdq(@!9mHY?x^_k<Yh3_hOdBL*<R0{c@Yny?AKyP`~3)%VG{^3DLv;)THSLW?mZZ@=Ib!W3i$ac&H#(XJ?TV+u-4={a>9t2uHTR`_+v>0D5gX`bM#jm9_H;}nFAad&@@{=waB!9wrBKGd$uy1ix6P>pNJ(u?V7o7gE7kAjr=#x<PvRZ7ADgxMsNO*quRMdUIqIaSEWf+e8LO|l`_-ebgn6G<mf*$8DJ2Ph^sCs1_c+YRQsi2qKe*gOP;`Qc3M=AKrS}t!;IL9=Of9q<MG&+4^S>_GwFIjrs2s&g|*A%L;2_hr|Us$a4TN0lPzga6QbxHzR*fEWKQio!UZvc^06?qX(F3C%qkshd<wfiYrTo=qqCx%75IcTLl5LBBuSuqW&=ki0jZ~W=@l=3ba7lJ7lw_0r|%1J*FG8%EhRnW}!&Z<-4B}xvseMO=miRqY#5a-O3>`*p1$q^x=5e5h40HUCjjLRw~Vj`Ew2y>gj4pYncw^1)TzLXNN-f6OlTVItfUJ|euW?H-tskQaoX!5mp)B78#%_hY0?2_2;1pYL8p-e-|LJ|pqbBeU!2QDHmT}XiX40w@_qhd(dA6O2^->@_M1N^swKK~O53RWt@r^TVy?OhGzeE=(_<h{Jnm{rfZB(=`XOte43DE>d1@{Ix}jdB4O@WQ(A`pJ<Bn5sKPS6n;VeT9?7*3>%w*`W(|`^lwt93T;STaPC*2|nd%?_LcHKd<X@{Y~IhvsxB7PZgT7f@yEIW!oxMdQO~|lQlmP+IoEBiY#OA`C>W<g_;p449{$&gKf$MwrkQbFE~9#Zy)f_gh^Ac%}VXfc$C*^>PKakDdeMJvi2=)ou=Q{ws!LWy*TkdPv9#mfBYK498m;Y{`<t+-*=j3a#Mc$bx1wR5_z6UBO{5rS-jD?!yZ_e;JLTpkbAO8#778Qmglf%#V<|x1j2|Zt)@e|r>JeaFTm@A%lSh3^M>}KgB9vD3sV(KULq~MHHv4T1mGNw1DB6|kxO1Eh&=WjeTv%QT8r(yj2buJ_y<wY-il-w1^@uPKcPcpg{J@Q(Y;I$T;S>w(UmRU89Ms1oKs&AL@|n6xc9OSbIQc+JClZpy2*s+rclk(2`NFOc}mG=)T+k(Ir$-ir|b;=C*;hlW3{o8c!CF+A{$MnCBh6Q04eUS9n77;XLNkC;m{fEWh*;5W*wIie?a5{#oC2b;+^k8{F(=ZSikX<S9pE9e&S*C`BLG2;M9Xa2PX~CK~3`}O&)UVA%pv1A>vBRiCUZ4^tcoDQ*@k);)Lv05(&8S(n8Y2k?J0QCHm_tz=}2`5f|8_Z;A^?tltNVRwJ5ZnoSCeHi3fZD4942sG9yxZ6x7o9F2qY;*9pIsxFr1rY_P?Y;H~m_FM=`Q?I=NSRssUHFw+}25uRJ3}+_)^G_U7D~<;->$A}btEUyLq>e84vm@Z>A&^MO^5pW0ao+6?g;}l34Sn=VZrC<1Q%he^He+`g6WW>~wS_F`KEA9Yi2abP^c7{*p#c@}FLG!cEv2%9AT@4~JDhSznPkqMx1pB<yLt{?KAq2LRF~ziICx+!DZ_iV4ME|NJB5G#^k;zyYtRMEX<_@4CvCb)Q%*63kt#DrvhAoL8YFTpFQXF}%7+^0R)7~aD0GFM+Vdkc_3uc4UNu!@Ii(_VMec&z1nv^$(L-|-ktyf^TlpxUYrxmaU~prk|5M#%)RaC8YO66BQWs?=*p?p%f<VrT;{8pJg=&y&phhIW{B~yHXk?ep<`t%^oB8f&n9MzIS2JUp=P>F@O&_WL`x%3{MF?he9PhwEn^tQ>1Kj(7H%QfdqrA^CR-Pa$Vwb7pG}xuMb9!s<`Mb@-pTbz*H-*j{bM-NUjHXt!)Eo6QWrl`@c)@b6p4YY^<7ts)Ga$1R{3@0RpjaUy059u+cx<y3U@|r&lX%mE8uVh+!GYR|-zIyBsy=9d5TxDUFCAH>k5p@Xj?a~H-LKf@2g40C06)@kEf|i%?^$G6<PK6CCMQUS-M6DuZ(u-Url4>6>lqHvYJud{#x1F7s*&ero?38i_A8|eHfpi)v=)02&PfL8)&jZetQLXU{0fYRkFTnhY9Ny04_HeEZlzF)c;BtJ#Fp%ip(=!kevryLph1-?E*)T`kfSg?tqJjouTwoQD+pOElV;@dp1KpZySi23cgF09UY%0Rg&6gJR@QkSLlE1K7eW^O4f)j};D`rrCo7Tuv3Sw>&vjI9CA>kY=9QiqAY`FUAk0;d?8h9kf4=`NlfausR@+#hT2-eItk6&opkF`VVGBL?xG(k0`bA4PqW?DmqB`;A02*beDraBkqU7ylEgeT~lNjxDvZ@R*e4$~#bn%B~$G{^v`rxMlx^)<1>)R&9X2+Gu3?)2JqZnMuR$!EC!lxq(BPl`<V$pSR!%-MqU)ir+WQEm&AsKljI6Lqwux2o&SQcfT7n`N_((p%UL_WLyNgpqA;SS|&sqSS?qP`q2C$@&V<PTg#Ij9*gIqR~|<FyAVv!Ja@X>#e*CEKK2rRmE{J+9Bj6c07=(STfOhq?dt#V=1B1ifU@zn&#004XXzie~rw{st@!-7bvq6=)w)Ow{c!-D^h3wfKz0QCOT3S9~AFY0<pVX=$Nr7U6$yKbk;+m6E2QFhZ9B6XK0MYkiU=-RA6{07!zl`EzmyjUaE)$6#juC}MGviO8BsBoL3J@mp;q0Mw#&&gFk#4`+?1d6io5gLC7kkSmEjZl7;?8r_Xb13Z#TaRDf}3&XVzOe$mQOcXLK)GkEuYbsP7#G>hP)#3R0AM?$H3#)!$*BeCC^a}y1T*S;=10%6uRl^DmXw>j-!PE9MkaIT}c6`fsNnlsdZ_zCW)i}@$ist)xcIkeL*pb1@)R*Y=DQ8%=M0Ot6Q;i?RrcIEeFtyZMHQ&L4iiS1ke8UWQL^65MV%uler8;)CvBNODSeHJ82qp|M?V?8X;dFkraxxk)S^OKOxZT1R1Yw{|2~_-*tOk9~6c=+8a|$>Q5K2>u8i*5ouSfzhs@yDN*s<=0lPl+Y8(a1sXjN7m8LvIhOx<Y;imJn9`Xp@H7g#iW%o5uEG#Dw)DX%J^krq5m5{hf8ZZ0R1?7e&x6gpn1wUYO;@k4WFgMqAPwFfYep;bKWR<KNqV4w*nPxR`-<+D@NM|3yKeA1H+TmSB2Y$2hN1M=8*G<o<eOB=Y4@kafBe19xyLC)#s<Bso2>{5R$c)wA%-5$FEVKf2LmtfPnu+W6=r&`i+_L&7LdY0fzjB-=Q@6S1Bg|||i>(WmOP?#6s+N@(&icqHHDS_*$>}>Cp|0fE4FqchiLSEhg8;#9?X&QD0S#4c~W?YX#@5=@MK&EJsog{e00Thei?lu+ZQCh`)*jI&7eP6K!#dHOC2wQ8K5@l%VQaajCZa}%(wRo!`tO3op0aJPzc|Bc#_x}$O1zqkwD#$}yd#kD9v`x$W0u^9Lx5%<8Z$8=&&Dwf~^-?YvwzATVOBv<{7ATXkEUvNJH^(qvRnM;vo&xTyj?azBHYlGmxkAlb{La<AEPn;f#5g4>=C6+2W}Q7$;LHgH06wSezj4MEN@cAQ@u<#;ASSA;1pb7AL2qKBx((b6G10F;XEr=F!%o@|s6TNNMI8EU2X^+QltcbA83e2v)obX!Vps2zEbrp>IH(wEDY8^4113}^$)>;zM~-W<Fo@Tj7IKO(+GR1Vq-VjD+%SBoQ^W%QYA5e+*-8y%iOQ>cWtBpvSpw9)K$1WWnkZlR*MrI49yWX#7Gl3PU{Q2{#T*2Q*y$}I0G5EgP;fy>OdKOf+4VrXL8ZYz;?)J`lJ*S`@h0d!MmS`a)0~2(9O1+<VnC^u=G37~4cyo{WWb4oWS|*2Aqze8yhK}c;4|U8a@5`Qho)pwwE??SKEgOVj}~tK<WI)MTxB@sl6JHWTkrhC>yzbHLL&KmcQfMXEEwS_q_LBP<L2RT=5J?}Wn)KK0!pSSb#I7#vF&?VO1WBdl3SdQUZHw+k&Nhya^@)>GZwp;BcIN7RkJN^C3xI0X5d)|vCE?o<QJ_V#+Q#q>o4^wvMuXL)57((CKP>hHY|WbX?P>?w6Y5^vcX-_3Yo(35|5{L?XPe(9bjk}9EGG#J;(W?K!}w(DXkB7?ZFa;Kj(U=115%ElQr%HfCqxc=9&<C86&T)41Wo9yD4yNM_9I(J-Y!hrQ9qk(#BXjH*JGc)y#FMGQ6Kystu@E+kn%RaDWv~a9r#35O7>7iUnjo@{XO-m-o-o5g3ALMHv>3>E<rXGKujbNofx9&#nKhPss;0i}?3fZ!r+?Le634#woNX5XcFfqo&>Ywg1(1P<r^C8)R&(WLlE}aq0eW@mhEv#~{UmA<g^PdEeXr8D|6agU>61--^yBm2GtK7lIrrkkd`jul@D;DvwsbMsYQ)LtaL_r1nMGG!#P8%ESo3bt30Z??ULlbS+<Pa|C94s>DQ;Y=bqNghA~Vq>s`EPhho5riGZW)Z?>T$sHxHvnQ7F&)f=k%#~z7KrfFM0xkH~l2FOiphzoh(2SiC&QEHLS{=s^-0kl-(<DV&VWGJvklK9jqS?;$`1aWx53p|xj>;P%o6*VjRj79a)i7DPi$42!1~Cv&zQ?oQY(4t@^nv@*+??Can0Ru)pJN$ll^0B7VD<DhTHvW;3X0iVsPS*przWX*2QTd`)Sp#AeBMLAW4-M253$Mb0}Xx9M<m>R8EI%0{7gs>3yu-K73EEUp!FSfSFFB5ndKuI+@NyuJa0>XSPD`g4g2s*I)n4olKag4B~+AUKRVdk;K3zBj>t9S04Rsg9JlZ*u~WG&i`H2{w%X7IaxFOhXZ45!O=mUU>hz&-t&7LcJ0!F3A@@9!%|cMJkS_IlHmHvzGRezro46YT@=jNmaESj*rvPJpOYeJ1wmM+Q|F@&+I1RX}?bQ2FWzYPGOZ9~zDbh9Zj4iVqOnO=-uY}WoGd!ukSJNR0cHu4~iJD}x6NR}jpEE`5-~`}dezHVm?|{+_Gb_i}Ooi%&W7$By9I=RaIgX@;4F8q_iRT)5XwN;A*_a(gW;jlI*7}V`{aWOX+(y93KgD%dWf-*mxIVU}oU^lidNmDj=ySb=|4=-NqWF`aV}Vd2iytU><iYg2u<12qcOIa5e%K_H%vTx?Xl1wIB()eADQul_2&sw7lDQ&-vwQpm>j_z8-sDh(`V8O7%ynP1XTormY}BVJJKXhXD_+3<AQkrB8df4KtJ#%Hx|Zqdu$uL!V1#PNR;?rh6)O5B$b19(q-xj8E)7$*)C;`!NMg@ehCX0p6}c5q<^QI-h;*iERN9$X@%c0~Cqhf4ve$n$m*Rrd6h(`Kw}NMGl_Gb1HdcuU7%Dv1Gl3G4Zm1B6h_{MNh;HaV%}52nVkLZ8$F*nBo*c|UxQhKV@ZF({6A<9`6SgquPyMP@;<iIY90Wt+rX)NrtMPj784<$Hr>4t^gw)eb1;2>@|K@?*sw3}^olsz?edfjfQ2fV*2Sq@}9u1u0AOr+#P+ac(Qd^@nIz_su-faeaivh_260hR|$G=^I3nt%F5u$0Ds^a$X-k!Xmu<dE=9s~<dF6zhT;a_U%nEX_n$oN(Xc~eNC&D~_?_)oHgcme(lz$23jCFMU|^h-T)2yr%{Onk~g;SvX1Q_ngpC`&h_I{QpEjx-I3aN+yWecQ;oX$gm&BSx3P?I1M82HSsr!zkCrQNDgph&e1&yG)aA(UTfeWGJ0o6Eqz)?rsq|{Z_AJLTN^(2Gq2mb|w<TcQxZUC)~+3u7QWY6&Q~uR=|VYu$YHjv;Zn2@G1K5Z!X<iP2a#OC=@P%sLytiNT#?Rr)^yOD6ltx+xC4(Dbi!7QLCR5M`)evYl_D;?Aa{Hw=F4sZl$jqC%zj<);>SSX7vRX0N}@)^JJyY!T<Nc6_Q3o+#$Y~lCPsV6^F=@%B-Yv5u#h}2GSqa2$OIUS1G;~j?0!QzaSESj6;i->V`&&kautGDN&}}6ZzdS{q!-R^_(*{FyC#b5mDZf0v<;gOBSf+ZVzRhHRQY^>j|Rr>r|6(dPwgIP|009|G0w<fW&PyCg}n6%jKT$Ry-0U^htE9q>2C%Jr+@r0BAST=S!lF)jhRqQ_G43m5p|Mu%q!XcHN}#7DkpJs=Ob_p}IE5M;Kcr<{4BZS%B~Rhg_sgZS3SYBhhbsVG;_ddzT(i&^Kh<kG_OTA@?LI5D(hgx^Q29fJwF$L;o#6HO!y_V>k3}DJP}0Scq4Z*T#MoNUcVE;bD8p$AyBNSUQd#u>%)a4UFf_Ya5a9*`I{vG~}g5g9HOm#Ohtjo?t<J!lubEVG1c|rOVv3j@SKPHYZG!p8kkUDZoC3k7CX>asKTHD$B-|!BgArd6*o4_mf)ljRyqo{}n%`-uIE`_S;z2_SuGODw-WZE<^G+ZI9G<Ckw&BsY2bCUmjfr`{Q7|x;J!~dvJK>DpN?|QGdbSd(Y=mYV{*ZfL`9)lA9y*<M4{z30#@k)^DCPYlL&m;BVZ$1p2n-_h5Q#e!i7F;q<|V1_|;xKrSMxwBBx`KG0O9g6ax+o*X8LV)zfv*+rkYy03OryXJa;zd713q#kTwczf4oXeF-t`*;3z25c4bxB5k8E*PF`?C--E3CxY0;W9Y11AsKFS$}~)>%XM^^;2cM0M;TaoyvjSENU3;|FCFBv^hhgQB`&TSR<X7&U`ZMx;}*Rq~IIys_~V3$BL-BbZ>`dpjD|6o69Sje+)I-<Iic9B=v;yer8>6>{tJtCOK4k@UTkxO^b)Nn)UdRjJ3&N8)|jpsWKC*mQqYF=L0>y9^W!?1Af{Xhs4(&A$h=fpdsnFRr>bwy6-4Wj*$5c`h`3IFjUdvt6WYJ%Pf{TA9A`B0rY6tM==*gY!P*~1kk#Vpd&VavU>_BF~iQOT#D!3seUb7ESkOSO%+TOzdmqz8uRP@f{Q+RefkX(DbDZ(f$Nc)T{m&)@0~<D9a3crrGZtqGYWQ{BRFi-UNn^Cqj<z2ai3o6RhU8Fb`Ytzc5rw3t7XNdJ<wiL*QsAVgtb_lC8;1DBme*aa7q+O^Pr^)00Fm=0q&6mJsb;MvBYQl0ssI200dcD\"], \"tables/klee100.json\": [\"aaa3e10450befb7231a41e878755968f41fe4b85064e674543a90d9a535866b4\", \"{Wp48S^xk9=GL@E0stWa8~^|S5YJf5;XdaOBV7PJh>Av(LHPGsxMSJ<{m0{pSZ{joAJeMN!RqDBUUP%4yJJOi^>=-N!_W&#6j-lH!X(gB(py-AgCr7h^5j0*Zli2j)}FIXFU>o1#Ne<gS5Tbl#jq(0TLL(e$cIv}1u(+h9Eq7et6Tf0w@%Az5}g)f3sFsH4=6J-K*(b0vGc8Ey86?+@mHBRP%Pz?J!7AU?`A9?LxcfE)Q^m1)P3Z7L|m*L_%Wo_$$O%?a!Y(boJinM9;A)ISy5}fJ<RDj8$QiyRSd**>KA;~SdfD#IcPY-&)ZnBX48)3kI{fk2R$1`Hw<~cnXY8P>^M6Itog~nFKxSP@+;_EG3nmMUn#=9Dkjw)d>FtC;4qRa)r7q(O;tV-^GrolSy>#t-0L_+dRc_>T_{&73*#Gq4i@r16~PCsyt3oD^=@r0naNSxdAd2Au4z&ryBw=&2bsb9vY<pCKd4>>F`P@Vh%JZb*h5E!6V^?ak0&KCpKG2MyH>R0nUU`C<t7RT7l)zLHL9w^;Gd3sAs~b%a2I*g?k?}IxK6tRCp_~U3YGx+-4d+zFc^%@E^7abWXlwyeI2>p>cw-@CL3b7F5a_Aw=l+jNDthg+aU9%g6?W=%nVR`qKq*%#_~C>1K>Ol7H6Ftaj+?%bP*WaNgWZ~c49m$HCdL=7M<GWsk6<|3{SK!3(3A3NGl!E!}Ib1TC(_h3*7Qw1?r%#!I5`@Sgqkw@_+tXQe>(jFp!`$61gjpb%&d=ngEHjThwC|L_s&r3;JTHOiV)czWf=xUNXZBHot9la_>=O8|;1M!2cPhlbI(FnO_btEq#vPbISkI!51RTzgf7`GmfNHkWnd)uZ;E1Jm0{^sT>|%VM^_$6Jk%5<eHOM=oaX`5ueD0D=OzV$0~()wQgx_SEK4=<fJC%#|aU7c+YlS_{3F;M7yJ+1{$Gep>n;TnQeMY&9FT{Z3W+n_4$$J9NBz^*fl}>f}?x%vLPnKxplt8jjF6hR{m%L<J^k2`>YgzvXCvpJ2oZs?h#Vy<f7;Ukl*i|y9nu(d^!DVG_0UILM!hg`o;`-7fTnj1AWwyTiUeU2Mr?>Z1adMJyIqld(5B6<<UdQTMRjEIIE~2XY}an80bCKYSVDavB#5y@9<0}pW0rz92ti-T*;=!OJtD`t4{v_NSvNm0~_AvoV_b|${#xS%L~*bD8hNBPPb*Ac&?R9;Ze`wtmefqsL%myW1^3&Oy3)^GAa5i-^UXCnMy?L6Rv943Nr@)Ofu(eZAYSIJe{+J@IXZM!xC65z-ppzropm2OM_<q-EU3x`j&<0i=scP0OzRjv;R&+X}rw+oMUurjoGCV`u(`SK7;mvSZdIr87pzvRQV|)*R?{*BRDBA3B_0ZYV$Q1p&S!A6GPR4yQ)2ct_JZ=L4b7CbKw;Xle28kijQg@%D<L`jd0%lQQV|S@19`Dy<Cv#I}3q%y<}>!cT--x<KL%2h??J>L$6M%tg>SEwRZ9npw9~OlU7P1677<;oJQ65pmj{JxR7F_KBBu-Fji8KV}wZDSXXe0V>7p4TSp0BO%T~!cMH8=j=ax*s7Vzy$qp_mNT!`hnl-J<4O4VtV=TFh(x0@i#0AzSrnnR(ucgIZI48x_0_osd>dyz<n4W>Fob7q9i8Cyjt2nb+nuwd-P8`S!W_|Z@YdkL|J&DB#sB*5=7BU+B;?<^yy+tyBd<usz+y)&7Z!GHDg#iYSCLsxF=Z;Myh0U<rwMld*)fFjftOg)=6h%Evf@7C(rGrHc`coQFSbT=pu+Pa|c3c9>V?VGjW|k5zAFteD(8Rnrx^=>z$U9hEvyb0Jdf3!b!U+NbVKXP<{9Aan6B$XL)X*_r!6rfz&;Qd=#By%5O@<z6)b=&$Ma=>Y&;9)y_c22l(gwZqMfvSN>M$2yWc%Y8XEAf`_z47<?46KYD|2@2@=Kqa8ELj6@wg2C`<<P=m5I(58YO&SD6%K*+yUvFAsJ=@Yrz4f7R6*Sd939=zPv4ZN3&JIj&D0H_<d@4iG$qmgXfih%lIpeb_YhrnJvWpg1GEYj<5=exzSvp^EAj(sQBVPNy+xRu!T??$=z*GUJ`s;|IYcd<#_)4DgRzo8*m&VgU8^4^~r^(9{>p)6h^rRH=yJWJ_e+l<1hTifFZ2?LOdaM={?h5&}pv*ArsJYPE^<6dP|9M@{z=ZtLlZJ%-NWgeKT#p70AaR+N@m->FBM*RJ9shsvS)%#yH?RL&_315@ArU97?EE^gGWBhEKOy^UW7?a11C}Fq9Dt=u4bsQ~WcY(9{-vb%rNk=zx9c(*t?u>8~dL1o9k6B(X(9r>FXR#Bd7gGL6%;D@Q*(ke4{Eyw=$TMT;^(p>LY%rW0*ZXq@XU|4e94j$~V_a2zpU+3N)BQR<2|4A26?_h06)=PrhbZVJ_1P2bIb<8arx^+@ps#|B3E5iT)rcS=`VLl$p;>Tw%38F!tql<*~RnELNX#KX9SplGAI;TbQhBwc-Bs!^Al@N?N|U0y^abcxOy37dtnQEGNPuT7)e6Kux-PQ~KgO-`HXG1LY!0lKKPgKqHqb^H%F%AkV-a>3;I<4tNW%GXIyLy}aQeI>$&&+29|?1>2iEinsGC%9;o5>}a-bTr$3V!G<U2^LnoCi>i-bevM)H&KfrnWdVpN{({fEj_bb50i^NR*;R}tyVmOeDCXwj7ux9mB-rlv4Y(#^<da!CK52*%<S?$&9nnKhAaP7w8@~QdU~jyFQm5Q4nNsH4fnFpfX79D6hBP9@?*v41gPy`k)=F6F)9aR<67<ar6SZ*%OO&??|xEgq5+FP;|TI%YToUF2G_#^p?a@`8b6{#xH%@tzMC{<q7*{ylC$*wqdyD-TqSBzX7t}rIrYuY^z`Q1aiYtbnws=3t4+EsY8XE%lU0W9|N1oF5*yCz*QRwK*-H;Sp0}b)qE%3EB`@y$&RW0LirY`Fb-9TUw?6s|PtTp+_N@epk{OE&;$_#mZeUz3&(^b+U!Z9>*X?|rJC`G-p1P~*jomqMJNlkWuif?Rd2xG3hJQQ)nFZqNRO@1-(0wqpDUGVG=}uCm;0JNQ>@yiPWew<UtU~h^hi`TN-0Hj8lPPGacTNt=QK<B|qlrQ4gg8Pu&MaP(ZH5u=aHD4{a5{SPr^X&VAQ#6OTYvhrA%vdSDRb$pBmBm8$q|qLGk$bq2yXb2AqqQNW+MB|#QmEg<x7mB|Llm&L}v6PQ1o_hT@`>>Q?lE%0?o}wRW+ifdn<mEIhWmYa{XZ3yZ%q;#?0KUS_GmoCMM@$1d{7|tYW`1(|%nW6$9~iO4FUOGw;j#L?#+VQA$4#0T6Oj7|bS0v{v)n)^z|iQ`QRDc0nN2i;PkpGA_!xU(G{asVu57045rqluNTsC@2B#uGfwuu|w|(ey7@RbWGd=#3YgYGxIpib!s)9uW%R;6W=p;p#Lr+FkcyCcUGY|1A03In4F5LklS~g{gTc1i`m&th3GwKl!L52FnpSouG0SA4CVgGAC(cFsI##k`=-GcvNgzKX(qClBDbEep*Whr(0c_v|G_m(mXAa?a%1l-Hl{*1Yg4Jc-b|V&a5m`AOxGWh*=WvM9IbZ7_QRZJrq{(tdpwup#}g??EBJ5%H&)6-_H>_*WLGkkq?DW<KH6g&6@G|#WU4?*vj{c+VF#f|TL?4x-X?Cqg!O*+eJx0kgI_B+T-2xR{+q~4U+7hDT+}fFAWBc>(u;TqB_OV~7QY#bV6n>Lkc1YO4NpfJR!@~xFXGo6&WVOMg{^+|n(Pk*&z=ePfHn3>iS56t%LKHP5GgU^i9bX*2UFxfJ9Y@9W20g1noi@KuSyu{#d$OdhCLS^#otm3=!ftETfK6Ks=CToMo#rH`#&9I%^~efM`B?p^w~r8LDB2GMHcV(+&+uR+FIH|Jav(1%R}7F|3CKunX-AfOu<zDGKr7a8e#+1$3|N{G2)G?NxIiJRzu?hA*7f{s5X#oMLPIv@uEwDcQip;wZM2MgYeq=v1P12YXhW|dJ-UO?2(P`cgO5LO;M9hATvm`s7S6f+N%<lt0`jfovu&KqkeVBLf~icpn8`!+&T(^J7ir#n=Diu?AS$$HnMY&_ME^n@*?kFhZy656j9%4>6CruUrhx#63koRgmbnD0INq=(o)iNK$rf&IaD3z&0($pJ7%URM#Venkb+{Gr4{ue@e+LmJG9OAsaP8ZTF{Lo2#VoluTik%#BWmLJdy3lO^R4*ldjw%6Vl*J9|3!7L5Lb<t1A7LOP8xLYWBzta<b0!!Gu4$hF5&~czVF7;76v0@ESOCM+)WD>^_o6xIu6u2m%sgFR~I_2<xTY$@6_xy^+m~yV6Teu;~{c2UYY0o##nWc%wH3+NAg7IjPOGH5k*5C{#Ua8ej8m>vCmK^qm5h2K}=C(_p|Gd`7%8Q4YAVo54YiHDsLIFSH*F3fKoMt0T`vZk&nt%dP-#hvM)g`w6|58`f4VBfPirz6R;-W=iL4Lx2P6YC*RF(8Yzm&wWe1X#ysbNP=v$Qes8-__hKC=4=7LE|*oR6x@AX(GyqnlPFLE7Lsikr}!g<SC9*|k~;9JnTxGP!Ko|P*izt;ESVxX6dSk#XXPLGn#@Sh8JuHNxF5%;{76oYAWG=s_41pFQAl*ntk4hlmNo#ErfZd>I1Y4SPr2Bq8(x`y1Sd*qRBL6mTjnBMO$eMs&E>T3FtMgw^cII)u=~%k{+2MS6|<o8;sROt^7s0K>gr<(>&CO!!UQfq4D2e13VZ&|-X1pG)w;g_Qw=WPw$pFg&ufAI=Y%r%dEfT|f1`C&El3SDViiwiuY|E(1ylo=E(BVsE)uDNg*VVjq`fQ6dxVbtrNh@@A|ghE>A9InWg*1_G`juU(a#Pm-go-0+}8lFG|jM$I<~5ji9E*gy7)BYdI-Q(lShj*L~HFr=32hE^J8PEO3CDrW8jdmKlQ@obxTUk%vPlM%0t;({QXB@SK2i8zX#_}=L?vpW+ZZH8t(>3i8j?Vb>APX(?vH%5N05FKOl^Xb{=Yo*AUx%@uF{r{ye`j2I1CsqY0FjtJH-=jU>Xi0-|jhr$iUh<n<qC5?E>p%b$6GoT#BJ9%A|cr1`@bV(17b`qbonFbzwY6HahBfZv$DqF3;-{5gEzD<?_P-qiKZsq}D~m_fxP&zq`YrK%>G6s{ib%k7Om@rynHI@}OqIFXp_sTW)L!$)hNwiXkFxm9!&@v9F-7H=G95s6`h@QGD60`=i0Ao7eZ%CN%f7c49L&O_62fA)k(P#vMh+79px66Ao0E*^N17_=jVL=gc!n|uHOLUf;{%*H#h00F-s==}r$DHgLMvBYQl0ssI200dcD\"], \"tables/merlin.json\": [\"cbcc4bdb7670bebfb08abd9335ce25a24dd1938a2d1cd7cf7171677b42b16839\", \"{Wp48S^xk9=GL@E0stWa8~^|S5YJf5;bU<U?p**qh>Av(LHPGsxMD4xF@wkU0^eyl@}#b6`FYwT5mm1da<I&#d`ljBUTr!wk4a(Jz3r=Jb}B9hKoFL5uF*&TY*(aEWsP_aKP+{E9}Nc6ztnRx@>@i#DAUoVbAaH|>nO_sCMX#7dFwVLo@N66ZH$(3UFJa`mjaUo9nEkjcjz0`d3o$#q37)=wZVxEfs#6l#&{ir9cJdt#kXyxUusx1=6-b8(zO$tcu(?wJDkj-l)iY6=n0h#@yUuEsZXA7HGS-7d!?J!&)&jWZQs0BRUVXv8+7t+7d`E{L(@n6AMtZv<?%E44)H*-A6|Qrfv@8G&vG|&o6JAlBmO%$Lux`DfvG&SJ{*}&!YFHU?wcP6)_#y@+WS9gU{)&NcVVQmkZX3Fh^+Q+N?*4`o+<%B{$T=DAW#1=fzU)fqh{zjjKCyPkCuZ3*nBQ*`Nqq04l4t<F<8PIu6ssyz9?ro?Z?u<#r+~@1D6Ijjxw7Ky|E2gWan<wB-1nKka=6@-)N(J{+Ccn0VAY-zbeO%SVPcnP^zk__dFr3q6@DS&7%2<A8VKuui`EWuvCjo#HMnnFUs&W>)h<dz2vo*ckBw#*h+<q;Vk8DVb>x>mB+6I|H|ZG{u)pt7h_<h@evP)a8^A-V$>%za%7(<Mn1bgK4l)BVG$UheA}TDr&^1ZKzh5bhsm@FpcZ(FfXjRGCqvR4`3Ny%QG$%myHXD-k~ekVt|-F9KCp|6^JCuy#9m$aMo$UBfd7k>$zd$+SbLg5`JAe1h`K4s@#35jt3=Y8Uo#w0(`)UM0Jotr^-llSMB^5`BtWtxrO;uW9DIcE!8PVw0DkO5QnW-v>%O<WCjox#LhDSyn!iWw7wUA(JP4X5T}4cK_sJzhLu1Fm@Y-y#5_aS<a>%zglaBOZ<@dqn`es6nLAo0=U+7e(&YYoMhDWn9T(?@?jO~Pn>K3vIlcGesujtnylMXmfoE5=}#}~LZc3`Z6tDj|TAoTa?<9Dm2ju>Cy!+?4gv%N=(4t`NZhH4r!L>$ld9;*y*K)Xx3mp}%0@kZ;x^#!v6aArD{TMmZ2Y+rU`GIi1l&F&Tazhyc0cEObW(D{WBf6lJqA0p?&8^T)6xw+C%#0%<(S(pmdGphl`&6OY%kCQHmQu`|2c%sgpAbd;3nNZJQ5a6KPLj!x@%;Z(t%#g~Ss5$rAc7aZE5Is+S4Xo(7#2Zx?=D1WWPoRf7)OI78s*|5gi;&OjT53B$QGR861U@3?1dRY5IdybjS9T!c_wP(OC5~gRXA{<wbMvzf)2n$<(rM5s!5s1+rYm<OELzO^3dFE0k2<1M;=8%0l|yzDDSd!K@<~=93zT+#QPBf)<>}lOp3A5jo~++QFU?--dw$HF=Nc+|E5l%QIFI#RE{_MP>iX6}21iR<!BSI<3|3x+!)Red<{M?hlYTFx5^HNgeq{oq@D+{>3n{|i!$&jAugM=!BeXG~M60jhX^L{`UH&JuQc_0Wh&i+^SDN3oe;$X$syfPMxCTILB^iR$7sW84a9N19jzHl0@rM48^||Sa-KCCl$#!j=bsFw$0Zn_(IT3hLsoVWYoTfF7si{8a{Z$)_Z{rkMZy^s)73myxe6I2MwH|`aQ;tBq$V0iFiZw*Bm6FvG?M$jO9frDn&}Elf6?a2xZBg{8oDA~6WxnHxn%Y;CGlz|U^-={7DWFOQqZD7eo8W_6cPAdHcWbM*cwCWU(W1NauSI~~R^KQN4i!|t#4FwwzTXb#%AChTmVL;WhrU~asN?XA>U5FAyl3iI&t|9I-sNigM%dcG6S&Ui2Ic??Qt&w}Is*}hu4iU~Ma#KUnJhrN;NwdP4exvV^Zh(#ZCx1tvt33#X(#y_E7O5kG1s45g?$uaiWVFB!D&3YyzIrmxuwl!9IzoPMht;m7z-#CUSk%kLQp!fY`)!kqOA~<#wQ3be3PG-szu$xU6}#c4Si*DP6UGuwF1bM-0tC7q&v#{wEvDO0<4#|iB*w%nv^{Hr&yyFyx4fGdM2yKVVqiwE5|9|mNmU7jG)q&VH1GaA0uopDT-H%+8AUSl-hBd0;gn;q#OuQGLY?JhOQVMj{ppPLK;g70}1W~RQ3e*{bD*n^Dnkgw724b;*%}>2>+uSy|sOcRa)fT{cR}!A&YRab%qG?;&?PDMHtQ`^)p4+zPuEB(U)GaY$um^`c<`uY&%%@Y}M#qvfsiOz!qhO{YP-a0K)BMRgGFtlUo+Qt8%~&jVxgN1mBg11k)B2SI=g@S|{0B1cI`u2B&WU_xlO$j9V6n{PTjAn0X3-e9nhIV5sHa80ItYcPS<br5J`CM-wA0t+WaXJ)uM@&lFueRVMMd4_GRvJnPD+vUzD%Dpn?eBnbfDC>`Z#H=yVZf8V%srwzD?SD6(zx@|F4eq3Oh8&<lomBaLn>Y^I<y4GgCzLgX1#;*5>iogkqu`RmX271py)NJJ5PjNYXcVuI!rpCC$Kr`)GO!J6X))AAGn9WT$!cz;b?0y9_e5UGEX+8W)KKlP6xLXToN%8@Xib0IB(q5^nD=xDlhwolnv`zot9lJ9{2?e=|o(LwiYYKaiYrLVx?>QXYdg+8y!Mw6f#K(oT9GV5p+TOkJA8L=MAoec4C(%d44RKQawq8eCPNJZt!5tq|YlAQMofbB+!C+QcOlW3I$e<o5e!^KpP!sBmyL%E17u&~};IjX+pUATtk}Cu!!s5Tgo!Vct6!!4%&7&2kqb1=JZ_JN)T23yTf)^@um9QNQ53Cs1CwbiGepYL;Hf6T*nZWa1tmkjUW^3|glx27`qZFhLQ@tTCw})li!pf@c4|M>8q$<VfK|CK=$-?5no)*8G!=J&=_=Fd?HsKNM{;ys?hEF8MKkuGEm36V{#gAY)4pfm|F}{(#^YKb3Fv81TyRsX@(GdlB;$B-`_c$WoxAhBo9+-exMZ;DM)&I%{x?tc`D!@qV$$GR=0|+$^LJG6n8t?=mBkB4A(rQsM-k^=>6Wv7W$766ItTAtxG-B=T&@5*JUN25kk7a@f)IRg&d>ejjm%o#|$lJn|<)sA@cpnZ|53m#V)5|BNL?Cxv3xh*vHj0c~ct`mMHWW&2$<SZY(-VL4IW_|NW<FGn_=RTyZ*X-T_{8qbMh?6~XbX*57>*xU!yGHM>x*LZO8@G85kd%jgOdD(`w8r}by9tPplmLL`w<~a8%Ph>5X>DPAG;+Tpgi~#F`RWg6s-YY`YCgh3_Rx24&aUH>*TzF{9fD95{&{<;_mm63W=6|RDM%g<b+MbQOG)XU1W)rw)ej|kcnw@FknFGkjRe9Xj|VF)|64>op{O40FaI>f(|#ZF}-R@Chc8=NE1!`rCdB<Zwe#C?$|Wo{ZNdr2-s?yqh+J5{Y~8{CA+SIUQ~NeMf0aS3rtKdfckL>vkMzye@d)drrq%PXb^UL6o;p5>^MVVSH~`q`6PH*^BzXyJ?2g#Ib_7FzW1CZG*C>degPe6xwum}Yx*7@43Wjqkl_CY7%!}fHGMTb5c&(X$XFeKxVx_PflF(+CAlkXi0%Wz*?TYY-uLZu@NplFws;!aQnjt<1k6{4#fOKxXe6>#LatGV@9w<xjXo)RtdqLCOukfwv(LtUw7EJt|9QuWKOM`%v#IFI&^yO9-cpLg|3shyQ-{c-r>@;HiEh~O;#N9s{0BOR4XI0Aty7`9*1G*^e7$D6a(cKHo~#dt!$qt?<++4(01p;+1w~>3l@9({B_42RzB^7s{J%NbSM}&mMrxnPAi@5A!$WV<PwOy^m<QzAAFpFd*JbIvcS+$B(4!U&pWj55epi2>KjDT41X@CQoWQo`8$qkap)+P=|JobkfSm7&Dx4opwB9uJ4eNk@wborXD8$s4n&yWhaV{#xLb%$7&vP;nyA{eL19CFxGSPq7-_zVz)vH2mN$YdL6Jra!!OCnK+x+9qiBw#h#PNVO6cW6%m;b8|g(UCwn`aMB-;u!1gwReQbn_OtGY#j;b(rQ#kV3t<3e3@nf!W0Zl``4^w#Z>OEy=b_M5s;+Awi0B1`e_iink)kf3=$MR;C4P-Ra%6wRZ{};Y9C6VC+i~{A&AiFJ^9v)Bn~XF-~E`D2s8rhC&VgG-pBDK0EM>-?QeqJ^Z_Rt1Vx|-5sI3u=FmkX>aSMLsO$AZgopBa9SDA+7G@&Ze!X6mE!l=kkDzygw5quACZeL+{UpMN#ZfsRCRJll$*69UUw0#m?vzXST9I>));-rgj|q*^BDfjZf<wFuRlK{M1_6gj%{68?Xaq^3oz{O;UP{QcdoTmqB;YK7@)chTD47=L;)M;hosFXd|ToJ%U*9={b?xKUE7?N<GH@f4EKF+gZZ)1kY3AsGpspN4!75p5b<bPA$Jcz0)nrJz4mxfck1Tv#?u)A%-jw7_y$J<MnO17d}1#eldZ^u=$nwbj1Uv*BxSqY-Mr93xNGQtotPYx+;__@(6?`6vFEMZ7CEV-I6}>ZEyh^dkcditD~AFac%JgN3p!Tmd-YRQyb-C=68$ceW`BXPNc^XJ++cKQZ_-O6kMQeJ<9&Ojxig$oEw-83UP`r-rLlXnQ)SWT=hp|wFOJ`OCHvB5hZYKAjxvP9jtd^i1<y%0jl!n?CJK!=TgZcTNDej%p<ZYFxys2Lm_#ME^GW|DljPibg+~b%hYvMs4?54r<TLq}G%kGXzh&UsHsfUnQz*b6n3{?biEz3E5y?PPE2i5~t=qdl93G=^+l+Sln9N1{`t=e;S$R0;=p)7Z1f6JZ94GT2W}nZ_`jzs}35@g*(;<l*eLNrd=kOaG(;7KJweHAkx3INS;&eDd&cmF`XdihHazMR#4loLRi)wZ-53ywbx_Ej&wO2Nh8ix<=o&{I^E*Cs+GKWEKJ?h^e!*K}WgbJY-wlU>`ICabty1>0uQe^e<AU{pDio|ENi)_=@S+0dA7_O$L0l{NdZ&xIAWQ|(N@&B8NNtok1k|U*`*9oQT0hi>R?nqc}%Sk7*i3p~5>iz~J3vyTnh<VbwwI?%OxTg61Z0I;~JY&jgE>ug}mgk6_Tq-~~SA7}h{<!ch_>aCQY8}<G&lu9`M}IamcL?ZUd=^mpn>ptvPZvxaI~XqTpSmy@s4!vw-C7SMuxDJ0L&@pR#E=1tC_&g>I2o3+v}l~9Rxjx1VKfADrWFwlR@{Bj^G2!5Rk(E692<lxr^Y3^YMfQ=bd~v@U1(J7ISaR=*Ho?D=P|!?L=^um5gWWd27(X=*^?c;Qlj56Ns7Bq{*XNJfY0c0y+}*#8~KRyI?%K1S^uD`L2(Nbu7P{ml1Q%fXroe0y-;c{Yiyde7;(2X^%ad0#Ah2luG#;M!qxR*w0-iTV^dnjn!X;DGj{o6gsx9%H!prrGgagun%)z*Lo9$a73EzEo2H2QOKy>FMoa#bJ0@Tww8bS_O;C%n?jWQ03ixgeI%6s)--m$eE?!HPRwA~Yr*c%@u0>T>czc}5u<h2NXm3TY51dG+n(V(|27_@OGo!|wUK@n3W5p&KNZUqIF`HRo5DY@FBRKq+pycY*^b+Ty1dK*Q9*tB<g_6d6c7TU6=S}=8Tk^Ihy7$$zyu`-Qnv-G+4ovNz`5I0z!KF$LIjI~b(g6|ktde-4P#j6-6AS|V05GUJ*f8&XZnkZF?L0Y!@&12M>+dIPBjqTv&UW`x0pZ`~Y)JE7qOAmDj5zoah~zN3XeZ^JyisWhWy+_OyMx=k;;|dP?v^90XkKPvbde!Ab?gEWgfUO=5rpe-)wMwx6oC9VA*uHySc+%YeXzs^v&LAh|MOt3itgU}RLM>m2!{#%qL`X5Vo|3c5X+up((3ff_S_#^YR?6()YAu>^KCdbBc-VwX|BVIAtkk8S|3k+M1+kjnzJ4_MfS3xmH@jmf5(Qhqt)(;DM?hMZSX@+$z*|>FgGDM6l5Uxr?I7h(lQ)W9P=bhfxoUG2`jL!=PLHGA$Z6FM-*d$a{|!DxFWseiWFdM)v$DjZpkupW2cq0N=CgT1n9Sik4vmWq&hH@w}B0Z|9|Gv+31~C8oDqLx)4G20V5j-JSwzdm)SJ#z<D%-5y`UMT$Kv!5@vO5+Y?D5S{?wc!UoU?Gd&7NCvsLyY0}d+sBE7tMm|9bemN%|JF#*mWQW8B&Ewc=UL$x&bm{CBaw(Rlnkb_+j>Q+tQM?MTW$+V00>+*ef#uLAH*L~CvcQ#WP+gyZ!b&BL)FBDjx>@u20e5kY?f?J)$ZkJA16;S*00D|7^2P-KT=~WJvBYQl0ssI200dcD\"], \"klee100_shard_digests.json\": [\"b50690a074a884298771cc408238dad9fd881bddbbac89372616114a65e1ae50\", \"{Wp48S^xk9=GL@E0stWa8~^|S5YJf5;4*#)LtOwpf`9=dPR$DjSGJY0zHgir&3ec7CWe`}d6UI_R)sdVsxjMHBN)`lt3E!%OjX1T@SAXcg3-57126~QPc3;iZa?TFj+#Tl>4V`!-5!38cj~Q*qtbiOD&odseSNY6#9#5C`I|&xS}YAH9U)twLXuawF3mKD29nPUfJ%gbIWS1WQe7mP7gJc3$VzWDSyE{m1kJs&4YqxpRfaqpXe9KJpC$J~gfAlj<SNH$Fp=)#0bTL|#-;)7%Tt@W5Ay>}wPU)4yn5m?i+i;ZbZnzpp?+VjZ_^|1Ek!syz=A$YrXOi%&v!Em{bTUKc%QIL2=8yX8(FK<zj1U!$}Jf(H$(D|{71PEGF&5$7#GAyR=G-|<F50>$D+GviNjJuuwcY3pyDjZdUwg%oK~Kj73v&_&qJxnT0UpQOHGyW*@WErbbLD~o-w|Lf;Sq#_m!n8q@Y3do0v01%!#g;HMb!V!Yj3bplW~A>kul__>nN)tJZ8#n(ETiPT(9O%uwyGZObxU+z>kfTUrJfN-{ctuOPUrcvRj<9>a~F6q)LPw6>q_{ikcDB;Lam;LQu!qyi>sY|rinZT7fYJ6M;!bfou(Y=!CM>X8l(GWC<#g{Y`=N?~xJdX~(VmbZsa!X|v=LK7&V+~|3kxw2`cMjs5!!9u%m1&f-@Zfg=PfwoPX^B{e#S=!Z=r{1ydpu~glq!O6Qu>w~HF$x)cb|<aqc%YC1eqfA41fhXYOSMR8Yx8F=;KY`|9z}stqw>`-o-D8I?!|JZEC<BEIkG-fDs}+fgsWB?#NujQT}IWiND=N$SuFsn;wbPqZh#XOHdf)$b)9&nY~f899+1}C$Pv{q<iP4w9y*7Se8j_OVN+(3{u)w9)-;L@{naF^*0iYYwjYz=tf|j&Oy+iaYNcT(SHd<VVjPmQ6Sd2QgE-BtQ%@#n%MSrBB|F0Zx%ZFCg?L$bX3$ey9^eGYYOn5u0*F#f7uIn!LRQu=Jbfa%qOg=R8*hyOb>5bl?@Dud;%PUfaf93xupOV&got+Dj3=RSU>SFLx_<5v72e11ak)7HXylXmn;3M~bki={&<ohWl660{0ZonykE{)z$@p%034E(51^&L)v0MEzj~IroJr92S(D}SXmnu*%oXs+KKQHo#tS-XlLLE)(6L<}uVS_GB7nb?uE`YXoh;CKX+!BLev$5kk*HilRZJs2u<25O>Eh*ghS#M;L%d)dOYc;X8;N#@@Q&9u(3&6-=D6*oDDZmlM-r+E?J2722nOj&f)h!Itre{PKjGPst5)ASrDRLjD%n~_r-BMb>k(!t8)P!Qrz2`+zam<lYq$doE^eyl2#SeDx3`;wN-3Qja74)bh6WV0r9m=lzQu^+=t~^~9bZcN_>aApQRL}E+-ev=riFYof*p(v0B3X))V*3onD>IQPs$OUH3N~a0o<?C~yVc75JT|7UwcUn*)Nkq2S?r$%3<;mhP^Y5$(G;9<4mbM45G)(S$rU9%ukTC0G6Co;JEgH`<7T10xn{+rsS)0%`Vl?l-yO8y1U7_;D1t)SByhkB(-ktU^bw`(@UT}!{baXBO^AD%vr$v~=xP9J(6h1DGG4BRLuwf7tBi6E_%z<l@D{~^BK8%(%iJxtQgs&X1DYc<pvmdaDo7Q{7K`?Q*JND2O~$VB&ksUA*POlg14?|h9xQ~0s_ttkzn5<&@h`$+J;=*TN;Z^t>Rg5e=(w962MuP!m5{dM+=yFEAR^p#T|JAW+Jyxq4AHsrQXq*irvjmApk;_vQ=a4RYFlF-t+&v1`Cn74mlkiY*%}5T%`ai_58r8-*wc`L%s%x+yp}_7xbE2d!WuQbqSZ%yBBW=*uP->Wd9Uc%oYEhoT#_V*U%>4wg}Wy3Hw8(p8uBv8@8KCFf&79gN#&(!dJ)|jRm`&GE2?F>0-NrUJ<ufU$YrAujG9ypv!pzX7&5E$I<Ap}V<GoN)Fwt?a`^DD!L+W;E-a!knT$*Da9UNTs!k=FSkTZ?HkVlv-P*0fgox;v(ukz1Sf!l{emWYu#p$J#hwczcDf5nKPOXG==T79Waq~HYQsW61TpZ8aI4gQdr%O+?_0pi8CK|tFa8817xREYoAv{&~pay7uc<=HH->RmssKS|V)6e?E1LS*HJ5@}P&l{>z*?^f?ylXWX2yU51YZ_;{I}JQtmh-a$e(J=BVw2!q%7KdSd#7lIOQ=z7kY@HTlWRw1o2rfM25QX6sN^PebpN7W7yyiT30qGmW}93KUGYeV?qUQf|IQSP24O2}7xb=h5G2jI_|8ol_N7|#qHK^)MNdeva7g$_ApnsUN_dD?I4@s+67i4mV(v@_Ut>fNagvb?6?b|-ozKhICEJu}E$Jq0Ann`4PQRo;X^A23gTJML1noS~a4?=#2S62OqgL{V|4a>#Hf>1Bl7(6tMa56V5HnUQDx~t{g(Hq%)mYpSZ@}6(Q<T8$WHbM_gZb&fu3U9VSK8-f;*bz;aCV1RYB48AmIsc|b(5Uq$|Pk_gtMQr6cUA!|J=PS;cp?;wn8X@3YV=$3)oi4Lh4`lW@v{gNsVV`n|~=E76Q(~zuMfAJcol(z%g71uzs)~(U>ctV7`RpZYYHC=%IX9Zvd=BThW7Mg)8ZT4`&2o(pICA0T+V0_eL^^@lbYui#|8U(K?*${G`mePD&cdMZA{qmgctI{x5}Tn~sxi#nY2rujVxjJ-L4N3#$xf8vp<R`)RC4?2^%700G|+|6~9FsE7v9vBYQl0ssI200dcD\"]}")       # build-time files [sha256, lzma + b85]: k100load_lib.py, the v2 kit's core + tables, digests
    K100_PIN = json.loads("{\"klee100_config_sha256\": \"fb17316df83cc1cf6cb4f5336fefb33566102cfeda16d1e9fc89ae1a4c61b9ce\", \"klee100_index_sha256\": \"873191b509904c7007ee9a791ecc18a939afbf11797e1549c0e3279bf31cefd4\", \"klee100_tokenizer_sha256\": \"06b9509352d2af50381ab2247e083b80d32d5c0aba91c272ca9ff729b6a0e523\", \"overlay_sha256\": {\"config.json\": \"c78d48f36421925a0fdb1c75aafe667c8d4e554d4431faa8f87f8924f09b9e27\", \"quantization_config.json\": \"e55659bc3c7cf29c668fafa45804dec879eb24ff5ab1e25eaa587ca462f2ed35\", \"model.safetensors.index.json\": \"c21d8c98821febdbab08331a4e55cb34c8e56bf4b902f5f45f1a047536213872\", \"FIXKEYS_DIFF.json\": \"70d06119bbea99b1db466fc026b0f4fb584a50b196f05fe2bc9e48595d6d8ab1\"}, \"digests_sha256\": \"b50690a074a884298771cc408238dad9fd881bddbbac89372616114a65e1ae50\", \"ref_sha256\": {\"A_2k_fresh.npz\": \"ea5c2a5a68d50e2e4abe7bd42595599775b867e817bb37b045ee0e0d3a24fe55\", \"A_2k_repeat.npz\": \"ea5c2a5a68d50e2e4abe7bd42595599775b867e817bb37b045ee0e0d3a24fe55\", \"A_40k_fresh.npz\": \"0254ad67ffd27d7e5952c894e9ba6a4b098ae91785b550d008bddd31e9ada1b9\", \"A_40k_repeat.npz\": \"0254ad67ffd27d7e5952c894e9ba6a4b098ae91785b550d008bddd31e9ada1b9\", \"A_8k_fresh.npz\": \"e3332ec70a40ab4377c6815d384fcfbade455a451404d5293c4a5e9d6c6cfe21\", \"A_8k_repeat.npz\": \"e3332ec70a40ab4377c6815d384fcfbade455a451404d5293c4a5e9d6c6cfe21\", \"A_90k_fresh.npz\": \"30c5800f6fa6e1d8cd3848f21ed1ebfa3b24e2b0207ca1553e9dfbdd0e520b35\", \"A_90k_repeat.npz\": \"30c5800f6fa6e1d8cd3848f21ed1ebfa3b24e2b0207ca1553e9dfbdd0e520b35\", \"A_dec2k_cached.npz\": \"da9098138876abc1e321d51eeaff6ffae270fca0d0d79db9dff4fb96e9e81463\", \"A_dec2k_cold.npz\": \"da9098138876abc1e321d51eeaff6ffae270fca0d0d79db9dff4fb96e9e81463\", \"A_dec40k_cached.npz\": \"062fcaebb2e31f489f97e057639d62195414e7a64660f5243abb275eaff15e76\", \"A_dec40k_cold.npz\": \"062fcaebb2e31f489f97e057639d62195414e7a64660f5243abb275eaff15e76\", \"A_dec8k_cached.npz\": \"bf9fbfb9904fe44b8dda56b6fba3b0c5f2ebb8f0e1ca463b4012f5bfac91edff\", \"A_dec8k_cold.npz\": \"bf9fbfb9904fe44b8dda56b6fba3b0c5f2ebb8f0e1ca463b4012f5bfac91edff\", \"A_sc2k_tf.npz\": \"4c0885ce1deeb48da3178843d4a29bf44944be71e4c097246b4d6eaf5d666902\", \"A_sc40k_tf.npz\": \"1e6f07a49cee93c57470c177834633a614c7ccaa8e2a6a22d42459b1cfc45994\", \"A_sc8k_tf.npz\": \"446eec9e4554172bde0fd73f96812ad2e06b779b61adeaca6eb5fb79246319da\", \"C_2k_fresh.npz\": \"ea5c2a5a68d50e2e4abe7bd42595599775b867e817bb37b045ee0e0d3a24fe55\", \"C_2k_repeat.npz\": \"ea5c2a5a68d50e2e4abe7bd42595599775b867e817bb37b045ee0e0d3a24fe55\", \"C_40k_fresh.npz\": \"0254ad67ffd27d7e5952c894e9ba6a4b098ae91785b550d008bddd31e9ada1b9\", \"C_40k_repeat.npz\": \"0254ad67ffd27d7e5952c894e9ba6a4b098ae91785b550d008bddd31e9ada1b9\", \"C_8k_fresh.npz\": \"e3332ec70a40ab4377c6815d384fcfbade455a451404d5293c4a5e9d6c6cfe21\", \"C_8k_repeat.npz\": \"e3332ec70a40ab4377c6815d384fcfbade455a451404d5293c4a5e9d6c6cfe21\", \"nb0_reference.json\": \"e1e7429678abd83315313bd2f095ce1da5e5aab333013f31a801c60e7ece51a7\"}, \"kit_v2_notebook_sha256\": \"b39db932e2227ab697b7fded01354440d80bb907c52cc99ef5a84a98a6df407b\", \"kit_core_sha256\": \"db19969dcd6be4da263271904f4bdb598cef237a307a9b31960ce2723bcb63ef\", \"lib_sha256\": \"d10c54e5fb8beede0dd61cff36a5b696cac5f71d402502999f477dd3246cc3bb\", \"mtp_tensor_bytes\": 1425540096, \"nb0_builder_sha256\": \"166b5afd7f6d2a052c9496885b358fbc86f397816ca829ad3081cf21f7de65de\", \"nb1_builder_sha256\": \"15a926ad5e23055602a625009dee6a07cce3426972b8e92017e9f0e7c7bc288d\"}")       # build-time facts: v2 overlay shas, klee100 input shas, the NB0 reference SHA256SUMS
    EMB = TMP / "k100_emb"
    _emb_ok = {}
    for _n, (_want, _blob) in K100_EMB.items():
        _raw = _lzma.decompress(_b64.b85decode(_blob))
        _emb_ok[_n] = hashlib.sha256(_raw).hexdigest() == _want
        (EMB / _n).parent.mkdir(parents=True, exist_ok=True)
        (EMB / _n).write_bytes(_raw)
    K1["embedded_sha_ok"] = _emb_ok
    if not all(_emb_ok.values()):
        raise RuntimeError("K100_EMBEDDED_SHA_MISMATCH: " + json.dumps(_emb_ok))
    sys.path.insert(0, str(EMB))
    import k100load_lib as KL                # E25 klee100 pure helpers (unit-tested: merge / K6 / digests / pin ladder / labels)
    import k100kit_core as KC                # the klee100 CPU kit v2's own core (fixkeys / graft / write_overlay)
    CKPT = TMP / "fn_klee100"                # E25 klee100: rebinds RC2's merged-checkpoint path (CELL 2)
    OVERLAY = TMP / "k100_fixkeys_overlay"
    DIGESTS = json.loads((EMB / "klee100_shard_digests.json").read_text())
    K100_SHA_THREADS = int(os.environ.get("K100_SHA_THREADS") or min(8, max(2, os.cpu_count() or 4)))


    def st_header(p):
        with open(p, "rb") as fh:
            n = struct.unpack("<Q", fh.read(8))[0]
            return json.loads(fh.read(n))


    def k100_overlay():
        """The fixkeys overlay regenerated by the v2 kit's own code (Kit.fixkeys / graft / write_overlay) from the MOUNTED
        klee100 config.json (sha pinned) and the kit's compact tensor tables; the three files must equal the v2 kit artifact
        byte for byte. Cross-checks: the mounted index (sha pinned) weight_map == the klee100 table; the mounted FP8 PLE
        shard headers == Merlin's PLE entries the graft writes into the index."""
        rec = {}
        raw = (K100_DIR / "config.json").read_bytes()
        rec["config_sha256"] = hashlib.sha256(raw).hexdigest()
        rec["config_sha_ok"] = rec["config_sha256"] == K100_PIN["klee100_config_sha256"]
        iraw = (K100_DIR / "model.safetensors.index.json").read_bytes()
        rec["index_sha256"] = hashlib.sha256(iraw).hexdigest()
        rec["index_sha_ok"] = rec["index_sha256"] == K100_PIN["klee100_index_sha256"]
        tabs, enc = {}, {}
        for who in ("klee100", "merlin"):
            enc[who] = json.loads((EMB / f"tables/{who}.json").read_text())
            tabs[who] = KC.expand_table(enc[who])
            rec[f"table_{who}_ok"] = KC.canon_sha(tabs[who]) == enc[who]["canon_sha256"] and len(tabs[who]) == enc[who]["n_tensors"]
        rec["mounted_index_equals_table"] = json.loads(iraw)["weight_map"] == {n: v[2] for n, v in tabs["klee100"].items()}
        ple = {n: v for n, v in tabs["merlin"].items() if n.startswith(KC.PLE_PFX + "ngram_embedding.")}
        bad = []
        for f in sorted({v[2] for v in ple.values()}):
            try:
                h = st_header(PLE_DIR / f)
                got = {n: (v["dtype"], tuple(v["shape"]), f) for n, v in h.items() if n != "__metadata__"}
                if got != {n: v for n, v in ple.items() if v[2] == f}:
                    bad.append(f)
            except Exception as e:
                bad.append(f"{f}: {e!r}"[:120])
        rec["ple_headers_equal_graft"], rec["ple_header_mismatch"] = not bad, bad
        kit = KC.Kit.__new__(KC.Kit)
        kit.R, kit.log, kit.tabs, kit.enc_klee100 = {"artifacts": {}}, log, tabs, enc["klee100"]
        kit.kcfg_raw, kit.kcfg = raw, json.loads(raw)
        cfg_fix, diff = kit.fixkeys()
        idx, _tab, chk = kit.graft()
        files = kit.write_overlay(OVERLAY, cfg_fix, diff, idx)
        rec.update(graft={k: v for k, v in chk.items() if k != "files"}, diff_problems=diff["problems"], files=files,
                   equal_v2_artifact={n: files[n]["sha256"] == K100_PIN["overlay_sha256"][n] for n in KL.OVERLAY_FILES})
        rec["ok"] = bool(rec["config_sha_ok"] and rec["index_sha_ok"] and rec["table_klee100_ok"] and rec["table_merlin_ok"]
                         and rec["mounted_index_equals_table"] and rec["ple_headers_equal_graft"] and chk["ok"] and not diff["problems"]
                         and all(rec["equal_v2_artifact"].values()))
        shutil.copyfile(OVERLAY / "FIXKEYS_DIFF.json", OUT / "FIXKEYS_DIFF.json")
        return rec


    def mirror_compare(plan):
        """KAGGLE_MIRROR_MANIFEST.json (the uploader's streaming hashes) vs the trusted digest manifest, for every planned file
        it lists (recorded; the streaming sha256 below is the gate)."""
        try:
            raw = (K100_DIR / "KAGGLE_MIRROR_MANIFEST.json").read_bytes()
            mm = json.loads(raw)
        except Exception as e:
            return {"error": repr(e)[:200]}
        want, found = {n: s for n, _, _, s, _ in plan}, {}

        def walk(o):
            if isinstance(o, dict):
                for k, v in o.items():
                    if k in want and isinstance(v, dict) and isinstance(v.get("sha256"), str):
                        found[k] = v["sha256"]
                    walk(v)
            elif isinstance(o, list):
                for v in o:
                    walk(v)
        walk(mm)
        return {"sha256": hashlib.sha256(raw).hexdigest(), "listed": len(found), "agree": sum(found[k] == want[k] for k in found),
                "disagree": sorted(k for k in found if found[k] != want[k])}


    def merge_ckpt():
        """E25 klee100 (rebinds RC2's merge; same contract): the fixkeys overlay (regenerated, sha-checked), one model dir of
        symlinks (every klee100 file + the 10 FP8 PLE shards) + the overlay files, K6 (every indexed shard resolves), then the
        streaming sha256 of every used file vs the trusted HF LFS digest manifest in a background thread (sha_gate waits for
        it before the first launch). Fail closed: any miss -> ok False, no boot."""
        SHA.update(thread=None, ok=None, bad=[], sec=None)
        rec = {"dir": str(CKPT)}
        try:
            rec["overlay"] = k100_overlay()
        except Exception as e:
            rec["overlay"] = {"ok": False, "error": f"{type(e).__name__}: {e}"[:600], "tb": traceback.format_exc()[-1500:]}
        if not rec["overlay"].get("ok"):
            return dict(rec, ok=False, bad=["FIXKEYS_OVERLAY"],
                        why="FIXKEYS_OVERLAY: " + json.dumps({k: v for k, v in rec["overlay"].items() if k not in ("files", "tb")}, default=str)[:600])
        md = KL.build_model_dir(CKPT, K100_DIR, PLE_DIR, OVERLAY, sorted(PLE_EXPECTED))
        rec["model_dir"] = {k: (len(v) if k in ("klee100_links", "ple_links") else v) for k, v in md.items()}
        rec["k6"] = k6 = KL.k6_check(CKPT)
        plan = KL.digest_plan(DIGESTS, K100_DIR, PLE_DIR)
        rec["digest_plan"] = {"files": len(plan), "gb": round(sum(x[2] for x in plan) / 1e9, 2), "threads": K100_SHA_THREADS,
                              "names": [x[0] for x in plan]}
        ple_d = {f: [v["size"], v["sha256"]] for f, v in DIGESTS["repos"]["merlin_fp8_ple"]["shards"].items()}
        rec["ple_expected_equals_digests"] = ple_d == {k: list(v) for k, v in PLE_EXPECTED.items()}
        rec["digest_manifest_sha_ok"] = hashlib.sha256((EMB / "klee100_shard_digests.json").read_bytes()).hexdigest() == K100_PIN["digests_sha256"]
        rec["mirror_manifest"] = mirror_compare(plan)
        bad = ([] if md["ok"] else ["MODEL_DIR: " + "; ".join(md["errors"][:3])]) + ([] if k6["ok"] else [k6["why"]])
        if not rec["ple_expected_equals_digests"]:
            bad.append("PLE_EXPECTED (RC2) != the digest manifest's FP8 PLE shards")
        if not rec["digest_manifest_sha_ok"]:
            bad.append("digest manifest sha")
        rec.update(ok=not bad, bad=bad, why="; ".join(bad) or None)

        def hash_all():
            res = KL.verify_digests(plan, threads=K100_SHA_THREADS, log=log)
            SHA.update(ok=res["ok"], bad=res["bad"], sec=res["sec"])
            K1["digests"] = res
            R["setup"]["sha256"] = {k: res[k] for k in ("ok", "bad", "n_planned", "n_checked", "gb", "sec", "gb_per_s", "threads")}
            save()
        if rec["ok"]:
            SHA["thread"] = threading.Thread(target=hash_all, daemon=True)
            SHA["thread"].start()
        return rec
    save()


if not RERUN:
    # ==================================================================== CELL 3 — prompts (Flash-Next tokenizer + its own template at xhigh)
    R["sections"]["A0"] = {}
    _t = time.time()
    R["sections"]["A0"]["host"] = host_facts()
    R["sections"]["A0"]["merge"] = merge_ckpt() if MERLIN_OK else {"ok": False, "why": "Merlin inputs missing", "inputs": R["inputs"]}
    R["sections"]["A0"]["host_mem"] = host_mem()
    log("A0 host", json.dumps(R["sections"]["A0"]["host"])[:1200])
    log("A0 merge", json.dumps(R["sections"]["A0"]["merge"])[:800])
    save()
    TOKDIR = TMP / "fn_tok"
    shutil.rmtree(TOKDIR, ignore_errors=True)
    TOKDIR.mkdir()
    # the Merlin checkpoint's tokenizer when the merge is OK; otherwise the Intel (stock fallback) checkpoint's own
    MERLIN_PROMPTS = bool(R["sections"]["A0"]["merge"].get("ok")) and (CKPT / "tokenizer.json").exists()
    _src = CKPT if MERLIN_PROMPTS else (K100_DIR or INTEL)   # E25 klee100: the mount's own tokenizer when the merge failed
    if _src is None or not (_src / "tokenizer.json").exists():
        raise FileNotFoundError("no tokenizer: the Merlin merge failed and the Intel fallback checkpoint is not attached")
    for _n in ("tokenizer.json", "tokenizer_config.json", "chat_template.jinja"):
        if (_src / _n).exists():
            shutil.copyfile(_src / _n, TOKDIR / _n)
    from tokenizers import Tokenizer
    from transformers import AutoTokenizer
    TOK = Tokenizer.from_file(str(TOKDIR / "tokenizer.json"))
    _HF = AutoTokenizer.from_pretrained(str(TOKDIR))
    _tpl = ((TOKDIR / "chat_template.jinja").read_text() if (TOKDIR / "chat_template.jinja").exists()
            else json.loads((TOKDIR / "tokenizer_config.json").read_text())["chat_template"])
    _tasks = json.load(open(ARC))
    _ids = sorted(_tasks)


    def _grid(g):
        return "\n".join("".join(str(v) for v in row) for row in g)


    def _task_text(k):
        t = _tasks[k]
        parts = [f"## Task {k}"]
        for i, ex in enumerate(t["train"]):
            parts.append(f"Example {i + 1} input:\n{_grid(ex['input'])}\nExample {i + 1} output:\n{_grid(ex['output'])}")
        for ex in t["test"]:
            parts.append(f"Test input:\n{_grid(ex['input'])}")
        return "\n\n".join(parts)


    _INTRO = "Find the transformation rule of each ARC task below and solve the test inputs.\n\n"
    _PH = "E13_BODY"


    def _render(effort):
        return _HF.apply_chat_template([{"role": "user", "content": _INTRO + _PH}], tokenize=False, add_generation_prompt=True,
                                       enable_thinking=True, reasoning_effort=effort, chat_template=_tpl)


    _RX, _RM = _render("xhigh"), _render("medium")
    assert _RX.count(_PH) == 1
    _head_txt, _tail_txt = _RX.split(_PH)
    _HEAD = TOK.encode(_head_txt, add_special_tokens=False).ids
    _TAIL = TOK.encode(_tail_txt, add_special_tokens=False).ids
    TPL_MSG = [{"role": "user", "content": _INTRO + _task_text(_ids[0])}]
    TPL_IDS = TOK.encode(_HF.apply_chat_template(TPL_MSG, tokenize=False, add_generation_prompt=True, enable_thinking=True,
                                                 reasoning_effort="xhigh", chat_template=_tpl), add_special_tokens=False).ids
    R["prompt_render"] = {"head_text": _head_txt[-600:], "tail_text": _tail_txt, "head_tokens": len(_HEAD), "tail_tokens": len(_TAIL),
                          "xhigh_differs_from_medium": _RX != _RM, "xhigh_sentence": "xhigh" in _head_txt,
                          "template_sha256": hashlib.sha256(_tpl.encode()).hexdigest(),
                          "tokenizer_json_sha256": hashlib.sha256((TOKDIR / "tokenizer.json").read_bytes()).hexdigest()}
    _TASK_IDS = {k: TOK.encode(_task_text(k) + "\n\n", add_special_tokens=False).ids for k in _ids}


    def prompt(band, variant):
        body, i = [], (variant * 7) % len(_ids)
        need = band - len(_HEAD) - len(_TAIL)
        while len(body) < need:
            body += _TASK_IDS[_ids[i % len(_ids)]]
            i += 1
        return _HEAD + body[:need] + _TAIL


    TOK_SHA = "06b9509352d2af50381ab2247e083b80d32d5c0aba91c272ca9ff729b6a0e523"   # E25 klee100: klee100@600715b3 tokenizer.json (HF LFS; ids checked vs NB0 in CELL 7)
    TPL_SHA = "c3cf9e34abf4f9e36c2d72165aa9c132d3e2a725b6c2586aaa3a8af9d7a81041"   # = the 27B FP8 chat_template.jinja
    R["prompt_render"]["source"] = "merlin" if MERLIN_PROMPTS else "intel_fallback"
    R["prompt_render"]["hashes_ok"] = (R["prompt_render"]["tokenizer_json_sha256"] == TOK_SHA and
                                       R["prompt_render"]["template_sha256"] == TPL_SHA)
    if MERLIN_PROMPTS:                    # the pinned hashes belong to the Merlin checkpoint only (Intel's are recorded)
        assert R["prompt_render"]["hashes_ok"], "Flash-Next tokenizer / template differ from the pinned Merlin checkpoint"
    assert R["prompt_render"]["xhigh_sentence"] and R["prompt_render"]["xhigh_differs_from_medium"], "xhigh render missing"
    BANDS = {"2k": 2048, "8k": 8192, "40k": 40000, "90k": 90000, "116k": 116000}
    NSTREAM = 8
    PROMPTS = {b: [prompt(n, v) for v in range(NSTREAM)] for b, n in BANDS.items()}
    MAX_NEW = {b: MAX_LEN - n - 512 for b, n in BANDS.items()}
    ORACLE_P = [PROMPTS["2k"][0], PROMPTS["2k"][1], PROMPTS["8k"][2]]
    LONG_P = [PROMPTS["40k"][3]]
    TF_P = {"40k": PROMPTS["40k"][5]}
    R["prompts"] = {b: {"n": len(p), "len": len(p[0])} for b, p in PROMPTS.items()}
    log("prompts", json.dumps(R["prompts"]), "| render", json.dumps({k: v for k, v in R["prompt_render"].items() if "text" not in k}))
    save()


if not RERUN:
    # ==================================================================== CELL 4 — the step runner (E23, verbatim)
    HELP = HELP if "HELP" in globals() else {}
    WIN = float(os.environ.get("E23_WIN_SEC") or 90.0)   # 120 s FULL windows
    EST_SCALE = float(os.environ.get("E23_EST_SCALE") or 1.0) if FAKE else 1.0   # local harness only: walk the whole order
    SM_TF = MODE == "SMOKE"                                            # SMOKE teacher-forced: the 40k row only
    ROWS = {}            # oracle greedy rows by key (same weights)
    TF = {}              # teacher-forced rows by key
    NTOK = 128 if MODE == "FULL" else 64
    LIVE = {"rec": None}                 # rev 3c: windows land in the step record before every save (a hard kill keeps them)
    COMPILE_ERR = re.compile(r"ninja: build stopped|Error building extension|error: command '.*(nvcc|g\+\+|gcc|c\+\+)' failed|"
                             r"GLIBCXX_[0-9.]+' not found|unsupported GNU version|fatal error: ")
    OOM_ERR = re.compile(r"OutOfMemoryError|CUDA out of memory|out of memory")
    XID = re.compile(r"NVRM: Xid|\bXid \d+|CUDA error: an illegal memory access|illegal memory access was encountered|"
                     r"unspecified launch failure|CUDA error: misaligned address")       # rev 3e: device faults, not any CUDA error


    def keep_after_error(rec, e):
        """E25 NB1 R2: an exception after the measurements (post-processing) keeps the whole record + postprocess_error /
        postprocess_tb. A clean boot (status None / NOT_RUN / DONE / TF_OOM, correctness CLEAN, quality PASS) keeps its status
        (None / NOT_RUN -> DONE), so its dependent boots still run; any other record -> POSTPROCESS_ERROR (status_before kept).
        R2 audit N1-3: postprocess_ok False; whether the dependents run is decided by core_measurements_complete (core_check)."""
        rec["postprocess_ok"] = False
        rec["postprocess_error"] = f"{type(e).__name__}: {e}"[:800]
        rec["postprocess_tb"] = traceback.format_exc()[-2500:]
        if (rec.get("status") in (None, "NOT_RUN", "DONE", "TF_OOM") and rec.get("correctness") == "CLEAN"
                and rec.get("quality_gate") == "PASS"):
            if rec.get("status") in (None, "NOT_RUN"):
                rec["status"] = "DONE"
        else:
            rec["status_before_postprocess"] = rec.get("status")
            rec["status"] = "POSTPROCESS_ERROR"
        return rec


    def step(sec, name, est_min, fn):
        """One measured step: skipped when the budget cannot hold it, recorded on any exception, never PASS by default."""
        rec = R["sections"].setdefault(sec, {}).setdefault(name, {"status": "NOT_RUN"})
        R["order"].append(f"{sec}/{name}")
        if ABORT["why"]:
            rec.update(status="SKIPPED_ABORT", why=ABORT["why"])
            log("---", sec, name, "SKIPPED_ABORT")
            save()
            return rec
        if left() < est_min * EST_SCALE * 60 + 300:
            rec.update(status="SKIPPED_BUDGET", left_min=round(left() / 60, 1), est_min=est_min)
            log("---", sec, name, "SKIPPED_BUDGET", f"(est {est_min} min, left {left() / 60:.0f} min)")
            save()
            return rec
        LIVE["rec"] = rec
        LIVE["out"] = None                       # E25 NB1 R2: the body's record once it returned (set by watched() / run_boot())
        t = time.time()
        log(">>>", sec, name, f"(est {est_min} min, left {left() / 60:.0f} min)")
        out = None                               # E25 NB1 R2
        try:
            out = fn() or {}
            rec.update(out)
            if rec.get("status") in (None, "NOT_RUN"):
                rec["status"] = "DONE"
        except Exception as e:
            part = out if isinstance(out, dict) and out else LIVE.get("out")   # E25 NB1 R2: never discard what the body produced
            if isinstance(part, dict) and part:                               # E25 NB1 R2
                rec.update(part)                                              # E25 NB1 R2
                keep_after_error(rec, e)                                      # E25 NB1 R2: clean -> DONE + postprocess_error
            else:                                                             # E25 NB1 R2
                rec.update(status="ERROR", error=f"{type(e).__name__}: {e}"[:800], tb=traceback.format_exc()[-2500:])
        rec["sec"] = round(time.time() - t, 1)
        LIVE["rec"] = None
        LIVE["out"] = None                       # E25 NB1 R2
        if ABORT["why"] and rec["status"] in ("DONE", "SERVER_DIED", "LAUNCH_FAILED", "BODY_ERROR"):
            rec["status"] = "PARTIAL_HARD_STOP"
        log("<<<", sec, name, rec.get("status"), f"{rec['sec']:.0f}s")
        save()
        return rec


    def with_servers(servers, timeout, body):
        """Start, wait ready, record facts + memory, run body(servers), always kill; then the GPU-release gate on these
        servers' GPUs only; abort the lab if they stay held."""
        out = {"servers": {}}
        timeout = max(60, min(timeout, left() - 120))
        try:
            for s in servers:
                s.start()
            for s in servers:
                ok, why = s.wait_ready(timeout)
                out["servers"][s.name] = {"ready": ok, "why": why, **s.facts(), "argv_tail": s.argv[-44:], "gpus": s.gpus,
                                          "help_check": HELP.get(s.name)}
                if not ok:
                    out["status"] = "LAUNCH_FAILED"
                    out["servers"][s.name]["log_tail"] = s.log()[-4000:]
                    _xl = [l for l in (s.log() or "").splitlines() if XID.search(l)][:8]   # rev 3e/3f: start-up / capture faults
                    out["servers"][s.name].update(xid=bool(_xl), xid_lines=_xl)
                    return out
            mem0 = L.gpu_mem()
            for s in servers:
                out["servers"][s.name].update(gpu_mem_after_ready=mem0, host_rss_mb=s.rss_mb())
            try:                             # rev 3: an exception in the body keeps everything measured so far
                out.update(body(servers) or {})
            except Exception as e:
                out.update(status="BODY_ERROR", body_error=f"{type(e).__name__}: {e}"[:800], body_tb=traceback.format_exc()[-2000:])
            for s in servers:
                out["servers"][s.name].update(s.facts(), gpu_mem_end=L.gpu_mem(), host_rss_mb_end=s.rss_mb(),
                                              alive_after_body=s.alive(), rc=None if s.alive() else s.proc.returncode,
                                              xid_lines=[l for l in (s.log() or "").splitlines() if XID.search(l)][:8])
                out["servers"][s.name]["xid"] = bool(out["servers"][s.name]["xid_lines"])
                if not s.alive():
                    out["status"] = "SERVER_DIED"
                    out["servers"][s.name]["log_tail"] = s.log()[-4000:]
            return out
        finally:
            for s in servers:
                s.kill()
            gpus = ",".join(sorted({g for s in servers for g in s.gpus.split(",")}))
            rel = L.wait_gpu_release(180, fake=bool(FAKE), gpus=gpus)
            if rel is False:                 # rev 3c: one more kill + 300 s before the lab aborts
                for s in servers:
                    s.kill()
                rel = L.wait_gpu_release(300, fake=bool(FAKE), gpus=gpus)
            if rel is None and NVSMI_OK:     # nvidia-smi worked at start: a failure now is not "released"
                rel = False
            out["gpu_released"] = rel
            if rel is False:
                ABORT["why"] = f"GPUs {gpus} still held after {[s.name for s in servers]}"
                out["status"] = "FAIL_GPU_RELEASE"


    def oracle(port, key=None, refs=()):
        """Greedy rows (2k, 2k, 8k) + one 40k row; saved under `key` (a target-only oracle) or compared with ROWS[ref]."""
        rows = L.greedy(port, ORACLE_P + LONG_P, n_tok=NTOK, timeout=max(120, min(900, left() / 6)))
        clean = all(not r.get("error") and r.get("tokens") and not L.degenerate(r.get("text")) for r in rows)
        if key and clean:            # rev 3d: an errored / empty / garbage reference is never stored (consumers: NO_ORACLE)
            ROWS[key] = rows
        elif key:
            R["errors"].append(f"oracle {key}: reference not stored (error / empty / garbage row)")
        res = {"garbage": [L.degenerate(r["text"]) for r in rows], "errors": [r["error"] for r in rows],
               "text_head": [r["text"][:120] for r in rows]}
        if not FAKE:                 # rev 3h: chat-path render vs the production xhigh render (recorded per arm)
            res["template_probe"] = L.template_probe(port, TPL_MSG, TPL_IDS)
        for ref in refs:
            res["vs_" + ref] = L.compare(ROWS.get(ref), rows) if ROWS.get(ref) else {"status": "INCONCLUSIVE_NO_ORACLE"}
        return res


    def tforced(port, key=None, ref=None):
        """Teacher-forced 40k / 90k prompt logprobs (last 256 positions); saved under `key` or compared with TF[ref].
        rev 3c: on stock vLLM only on its own short launch (prompt logprobs = chunk x 248k-vocab logits: OOM at 0.90)."""
        rows = {b: L.teacher_forced(port, ids) for b, ids in TF_P.items() if not (SM_TF and b != "40k")}
        if key and L.tf_complete(rows):                                 # rev 3e: complete references only
            TF[key] = rows
        elif key:
            R["errors"].append(f"teacher-forced {key}: reference not stored (incomplete band)")
        if ref:
            return {b: L.compare_tf((TF.get(ref) or {}).get(b), rows[b]) for b in rows}
        return {b: {"n": (rows[b] or {}).get("n"), "error": (rows[b] or {}).get("error")} for b in rows}


    def levels(port, band, lv, server=None, **kw):
        """rev 3c: the guard includes admission (prefill) time; a band stops once KV-bound (the fit is recorded); a dead
        server stops the band; every window is written into the live step record before save()."""
        out, fit = {}, None
        for n in lv:
            k = f"{band}@{n}"
            need = WIN + 90 + min(3600, n * BANDS[band] / 1500)
            if ABORT["why"] or left() < need + 120:
                out[k] = {"status": "SKIPPED_BUDGET", "need_sec": round(need)}
            elif fit is not None:
                out[k] = {"status": "SKIPPED_KV_BOUND", "streams_fit": fit}
            elif server is not None and not server.alive():
                out[k] = {"status": "SKIPPED_SERVER_DEAD"}
            else:
                try:                         # rev 3: one failing level never loses the others
                    out[k] = L.steady(port, PROMPTS[band], n, secs=WIN, max_new=MAX_NEW[band], **kw)
                except Exception as e:
                    out[k] = {"status": "ERROR", "error": f"{type(e).__name__}: {e}"[:300]}
                rm = out[k].get("running_max")
                if out[k].get("status") == "CAPACITY_LIMITED" or (rm is not None and 0 < rm < n and
                                                                  str(out[k].get("status")).startswith("INCONCLUSIVE")):
                    fit = rm
            if LIVE["rec"] is not None:
                LIVE["rec"].setdefault("live_windows", {})[k] = out[k]
            save()
        return out
    save()


if not RERUN:
    # ==================================================================== CELL 5 — the arms
    LADDER = [1, 2, 4, 5]                    # 40k: 8 streams would need 8 x (10 + 7) blocks of 4096 > 149 FP8 blocks (preempts)
    TEMP = 0.6                               # production sampling (Merlin's --override-generation-config is T 1.0)
    E23_TF_SCALE = {"tp4_vs_tp1_layout": 0.0772, "nvfp4_vs_bf16_kv": 0.3787}   # E23 SMOKE rev3g mean |d logprob|, for scale
    PREFILL = {"tok_s": 700.0, "measured": False}
    OOM_STEP = 268435456                     # Merlin's note: lower KV_BYTES in 0.25 GiB steps if the boot OOMs
    # Pre-run capacity (Merlin's rule: blocks per request = ceil(L / 4096) + 7; FP8 149 usable blocks, BF16 ~78)
    R["capacity_plan"] = {
        "fp8": {"pool_blocks": 149, "40k@5": 5 * (math.ceil(130560 / 4096) + 7), "8k@8": 8 * (math.ceil(32000 / 4096) + 7),
                "90k@4": 4 * (math.ceil(131072 / 4096) + 7), "116k@3": 3 * (math.ceil(131072 / 4096) + 7),
                "116k@4": 4 * (math.ceil(131072 / 4096) + 7),
                "note": "blocks if every stream grew to max length; the ladder windows are 90 s, so real use is far lower; "
                        "90k@4 and 116k@4 are capacity-limit probes"},
        "bf16": {"pool_blocks": 78, "40k@3": 3 * (math.ceil(130560 / 4096) + 7)},
        "long_rows": "1 natural xhigh ARC row (max 120,000 new) + 1 forced 60,000-token row, temperature 0.6, run CONCURRENTLY "
                     "(concurrency 2): not a single-stream latency number",
    }
    R["correctness_meaning"] = ("Both Merlin boots run MTP K3: CLEAN = BF16_MTP3 vs FP8_MTP3 parity plus probes / sampled / greedy "
                                "evidence; it is NOT target-only (MTP off) correctness. A production GO needs an MTP-off oracle and "
                                "a forced-rejection test.")
    CLEAN = ("EXACT", "NEAR_TIE")


    def _windows(o):
        """Every steady window of a step record (levels dicts + steady_multi replicas)."""
        out = []
        for v in (o.get("steady") or {}).values():
            if isinstance(v, dict):
                out.append(v)
        for k in ("40k", "90k"):
            for r in ((o.get(k) or {}).get("replicas") or []) if isinstance(o.get(k), dict) else []:
                if isinstance(r, dict):
                    out.append(r)
        return out


    def oracle_gate(o, need=(), extra=()):
        """None when clean; otherwise the NO_GO / INCONCLUSIVE status. `need` = refs that must compare clean; `extra` =
        further comparison dicts (replica greedy, 90k greedy) that must compare clean too. rev 3e (audits B-O1, C-F2):
        garbage under load in any window and failed arithmetic probes (real servers; the fake has no chat) are NO_GO too."""
        orc = o.get("oracle") or {}
        if any(orc.get("errors") or []):
            return "NO_GO_ORACLE_REQUEST_ERROR"
        if any(orc.get("garbage") or []):
            return "NO_GO_ORACLE_GARBAGE"
        if any(w.get("status") == "FAIL_GARBAGE_UNDER_LOAD" for w in _windows(o)):
            return "NO_GO_GARBAGE_UNDER_LOAD"
        if not FAKE and isinstance(o.get("probes"), dict) and o["probes"].get("ok") is False:
            return "NO_GO_SHORT_PROBE"
        sts = [(orc.get("vs_" + k) or {}).get("status") for k in need] + [(x or {}).get("status") for x in extra]
        if any(s == "FAIL_HIGH_MARGIN" for s in sts):
            return "NO_GO_ORACLE"
        if any(s not in CLEAN for s in sts):
            return "INCONCLUSIVE_NO_ORACLE" if any(s in (None, "INCONCLUSIVE_NO_ORACLE") for s in sts) else "INCONCLUSIVE_ORACLE"
        return None


    def gated(o, need=(), extra=()):
        g = oracle_gate(o, need, extra)
        o["correctness"] = g or "CLEAN"
        if g and o.get("status") in (None, "DONE"):
            o["status"] = g
        return o




    def _finite(x):
        return isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x)


    _compare_e23, _compare_tf_e23 = L.compare, L.compare_tf


    def _compare_rc2(ref, cand):
        """Final audit H2: a non-finite margin on either side makes the comparison INCONCLUSIVE before any token logic
        (E23's compare read a NaN reference margin as NEAR_TIE)."""
        for rows in (ref or [], cand or []):
            for r in rows:
                if any(m is not None and not _finite(m) for m in (r.get("margins") or [])):
                    return {"status": "INCONCLUSIVE_NONFINITE"}
        return _compare_e23(ref, cand)


    def _compare_tf_rc2(ref, cand):
        """Final audit H2: a non-finite teacher-forced logprob is never MEASURED."""
        for side in (ref, cand):
            for p in ((side or {}).get("positions") or []):
                if p and p[0] is not None and not _finite(p[0]):
                    return {"status": "INCONCLUSIVE_NONFINITE"}
        return _compare_tf_e23(ref, cand)


    L.compare, L.compare_tf = _compare_rc2, _compare_tf_rc2


    def short_gate_failed(o):
        """Final audit H1: a failed probe (real servers; the fake has no chat) or a failed / garbage sampled request stops
        the boot's body at once; gated() then gives the NO_GO verdict."""
        p, s = o.get("probes") or {}, o.get("sampled") or {}
        return (p.get("ok") is not True and not FAKE) or s.get("ok") is not True or bool(s.get("garbage"))


    def oracle_ok(orc):
        return bool(orc) and orc.get("complete") is True and not any(orc.get("errors") or []) and not any(orc.get("garbage") or [])


    def _windows(o):
        """Every load window of a record: the ladder AND the long census (audit: census_long was not gated)."""
        out = []
        for key in ("steady", "census_long"):
            for v in (o.get(key) or {}).values():
                if isinstance(v, dict):
                    out.append(v)
        return out


    def evidence_gate(o, expected_rows, require_sampled=True):
        """Fail-closed evidence (three pre-GPU audits): probes, the sampled path and a COMPLETE oracle are mandatory;
        a missing piece is never CLEAN. expected_rows None = no oracle in this arm (diagnostic arms)."""
        pr = o.get("probes")
        if not isinstance(pr, dict):
            return "INCONCLUSIVE_PROBES_MISSING"
        if pr.get("ok") is not True and not FAKE:          # the fake server has no chat endpoint (E23 rule)
            return "NO_GO_SHORT_PROBE"
        if require_sampled:
            sm = o.get("sampled")
            if not isinstance(sm, dict):
                return "INCONCLUSIVE_NO_SAMPLED_TEST"
            if sm.get("ok") is not True or sm.get("garbage"):
                return "NO_GO_SAMPLED_PATH"
        if expected_rows is None:
            return None
        orc = o.get("oracle")
        if not isinstance(orc, dict):
            return "INCONCLUSIVE_NO_ORACLE"
        if any(orc.get("errors") or []):
            return "NO_GO_ORACLE_REQUEST_ERROR"
        if any(orc.get("garbage") or []):
            return "NO_GO_ORACLE_GARBAGE"
        if orc.get("row_count") != expected_rows or orc.get("complete") is not True:
            return "INCONCLUSIVE_ORACLE_INCOMPLETE"
        return None


    _gated_e23 = gated


    def gated(o, need=(), extra=(), expected_rows=4, require_sampled=True):
        g = evidence_gate(o, expected_rows, require_sampled)
        if g:
            o["correctness"] = g
            if o.get("status") in (None, "DONE"):
                o["status"] = g
            return o
        return _gated_e23(o, need, extra)


    def oracle(port, key=None, refs=(), prompts=None):
        """E23's oracle plus completeness: every expected row present, no error, exactly NTOK tokens (greedy rows run with
        ignore_eos, so a short row is a defect); a reference is stored only when complete and garbage-free."""
        prompts = list(prompts) if prompts is not None else ORACLE_P + LONG_P
        rows = L.greedy(port, prompts, n_tok=NTOK, timeout=max(120, min(900, left() / 6)))
        garbage = [L.degenerate(r.get("text")) for r in rows]
        complete = len(rows) == len(prompts) and all(not r.get("error") and len(r.get("tokens") or []) == NTOK for r in rows)
        if key and complete and not any(garbage):
            ROWS[key] = rows
        elif key:
            R["errors"].append(f"oracle {key}: reference not stored (incomplete / error / garbage)")
        res = {"garbage": garbage, "errors": [r.get("error") for r in rows], "text_head": [(r.get("text") or "")[:120] for r in rows],
               "row_count": len(rows), "expected_rows": len(prompts), "tokens": [len(r.get("tokens") or []) for r in rows],
               "complete": complete}
        if not FAKE:
            res["template_probe"] = L.template_probe(port, TPL_MSG, TPL_IDS)
        for ref in refs:
            res["vs_" + ref] = L.compare(ROWS.get(ref), rows) if ROWS.get(ref) else {"status": "INCONCLUSIVE_NO_ORACLE"}
        return res


    def kv_census(s):
        log_t = s.log() or ""
        lines = log_t.splitlines()
        kv = re.findall(r"GPU KV cache size: ([\d,]+) tokens", log_t)
        conc = re.findall(r"Maximum concurrency for ([\d,]+) tokens per request: ([\d.]+)x", log_t)
        pick = lambda rx, n=24: [l[:240] for l in lines if re.search(rx, l, re.I)][:n]
        return {"kv_tokens": [int(x.replace(",", "")) for x in kv][:2], "max_concurrency": conc[:2],
                "scale_lines": pick(r"K/V scale|kv scale|scaling factor|DEFAULT 1\.0|static K/V"),
                "engine_lines": pick(r"WNA16 MoE backend|MarlinExperts|PLE offload|engram|cudagraph_mode|CUDAGraphMode|PIECEWISE"),
                "startup_lines": pick(r"Loading weights took|Model loading took|torch\.compile takes|torch\.compile took|"
                                      r"Graph capturing finished|init engine|PLE.*ready|Available KV cache memory"),
                "oom_lines": [l[:240] for l in lines if OOM_ERR.search(l)][:6], "host_mem": host_mem()}


    def sampled_check(s):
        """RC1 died at its first sampled request (FlashInfer sampling JIT: ld cannot find -lcuda): one short sampled request
        right after ready, then the engine must still be alive."""
        g = L.Stream(s.port, PROMPTS["2k"][1], 64, temperature=TEMP, seed=5)
        g.start()
        g.join(900)
        if g.is_alive():
            g.stop()
            g.join(10)
        r = g.row()
        return {"tokens": len(r["tokens"]), "error": r["error"], "finish": r["finish_reason"], "alive_after": s.alive(),
                "garbage": L.degenerate(r["text"]), "ok": len(r["tokens"]) == 64 and not r["error"] and s.alive()}


    def prefill_probe(port):
        """Time to first token of one cold 40k prompt (1 new token): the measured prefill rate the ladder admission uses."""
        ids = PROMPTS["40k"][7]
        g = L.Stream(port, ids, 1, temperature=0.0)
        g.start()
        g.join(1800)
        if g.is_alive():
            g.stop()
            g.join(10)
        sec = (g.t_first or g.t_end or time.perf_counter()) - (g.t_start or time.perf_counter())
        ok = not g.err and g.t_first is not None
        if ok:
            PREFILL.update(tok_s=round(len(ids) / max(1e-3, sec), 1), measured=True)
        return {"prompt": len(ids), "ttft_sec": round(sec, 1), "tok_s": round(len(ids) / max(1e-3, sec), 1), "error": g.err, "ok": ok}


    def window_garbage(ids, win=2000, min_len=200):
        """Final audit H3: the first garbage 2,000-token window of a row (None if every window is clean). A whole-text check
        would read 100k tokens of healthy reasoning as LOW_VARIETY (unique words < 8 %), so windows are checked one by one."""
        for i in range(0, len(ids), win):
            seg = ids[i:i + win]
            if len(seg) < min_len:
                break
            v = L.degenerate(TOK.decode(seg))
            if v:
                return {"start_token": i, "verdict": v}
        return None


    def long_quality(name, r):
        if not isinstance(r, dict):
            return "MISSING_LONG"
        if r.get("error"):
            return "FAIL_LONG_REQUEST"
        if r.get("window_garbage"):
            return "FAIL_LONG_GARBAGE"
        if name == "forced60k" and not r.get("reached_60k"):
            return "INCOMPLETE_LONG"
        if name == "natural" and r.get("cut_by_cap"):
            return "INCOMPLETE_LONG"
        return "PASS_LONG"


    def long_gate(o):
        """None when the record has no long rows or both rows PASS_LONG; otherwise the verdict for the top-level status.
        Priority: request error > natural garbage > forced garbage (synthetic past its first EOS) > incomplete."""
        lo = o.get("long")
        if not isinstance(lo, dict):
            return None
        q = {n: long_quality(n, lo.get(n)) for n in ("natural", "forced60k")}
        lo["long_quality"] = q
        if "MISSING_LONG" in q.values():
            return "INCONCLUSIVE_LONG_MISSING"
        if "FAIL_LONG_REQUEST" in q.values():
            return "NO_GO_LONG_REQUEST_ERROR"
        if q["natural"] == "FAIL_LONG_GARBAGE":
            return "NO_GO_LONG_GARBAGE"
        if q["forced60k"] == "FAIL_LONG_GARBAGE":
            return "NO_GO_FORCED60K_GARBAGE"
        if "INCOMPLETE_LONG" in q.values():
            return "INCONCLUSIVE_LONG_INCOMPLETE"
        return None


    def long_rows(port, secs_cap=3000):
        """One natural xhigh ARC request (its own stop, up to 120,000 new tokens) and one forced 60,000-token row
        (ignore_eos: 'synthetic' past its first EOS), CONCURRENTLY (concurrency 2). Full text in traces/ + requests.jsonl.
        A row cut by the time cap is incomplete, not a correctness failure."""
        cap = max(60, min(secs_cap, left() - 900))
        jobs = {"natural": L.Stream(port, TPL_IDS, min(120000, MAX_LEN - len(TPL_IDS) - 512), temperature=TEMP, seed=11,
                                    ignore_eos=False),
                "forced60k": L.Stream(port, PROMPTS["8k"][0], 60000, temperature=TEMP, seed=12, ignore_eos=True)}
        t = time.time()
        for g in jobs.values():
            g.start()
        for g in jobs.values():
            g.join(max(1, cap - (time.time() - t)))
        for g in jobs.values():
            if g.is_alive():
                g.stop()
                g.join(10)
        out = {"concurrency": 2, "cap_sec": round(cap)}
        for name, g in jobs.items():
            row = g.row()
            (TRACES / f"long_{port}_{name}.txt").write_text(row["text"])
            ids = row["tokens"]
            n_tok = len(ids)
            sec = (g.t_end or time.perf_counter()) - (g.t_start or time.perf_counter())
            sl = {}
            for k, end in (("to_8k", 8000), ("to_32k", 32000), ("to_60k", 60000), ("to_100k", 100000)):
                sl[k] = L.degenerate(TOK.decode(ids[end - 2000:end])) if n_tok >= end else "NOT_REACHED"
            out[name] = {"tokens": n_tok, "sec": round(sec, 1), "tok_s": round(n_tok / max(1e-6, sec), 1), "error": row["error"],
                         "finish": row["finish_reason"], "garbage": sl, "window_garbage": window_garbage(ids),
                         "think_closed": "</think>" in row["text"], "cut_by_cap": row["finish_reason"] is None,
                         "tail": row["text"][-400:]}
        out["forced60k"]["reached_60k"] = out["forced60k"]["tokens"] >= 60000
        out["forced60k"]["label"] = "synthetic past the first EOS (ignore_eos)"
        try:
            m = {k: v for k, v in L.prom(port).items() if k.startswith(("vllm:spec_decode", "vllm:num_preemptions", "vllm:kv_cache_usage"))}
        except Exception as e:
            m = {"error": repr(e)[:200]}
        acc, drf = m.get(L.ACC), m.get(L.DRF)
        out["metrics_end"] = m
        out["mtp_accept_per_draft"] = round(acc / drf, 3) if acc and drf else None
        return out


    def tf_last(s, key=None, ref=None, aa=False):
        """Teacher-forced 40k LAST in a boot (chunk x 248k-vocab prompt logits can OOM the last PP rank); free memory first.
        How a server death here is classified is decided from its log in merlin_boot (TF_OOM vs TF_SERVER_DIED)."""
        o = {"gpu_before": L.gpu_mem()}
        if key:
            o["ref"] = tforced(s.port, key=key)
            if aa and s.alive():
                o["aa"] = tforced(s.port, ref=key)              # A/A: the same boot, the same prompt (the noise floor)
                TF["aa"] = o["aa"]
        if ref:
            o["vs_" + ref] = tforced(s.port, ref=ref)
            o["aa_" + ref] = TF.get("aa")
            o["e23_scale"] = E23_TF_SCALE
        o["alive_after"] = s.alive()
        return o


    def merlin_boot(name, kv, port, timeout, body, need=(), expected_rows=4, require_sampled=True):
        """Boot gate (ok must be True), one Merlin boot, cleanup of the /dev/shm entries this boot created; a boot OOM
        retries once 0.25 GiB lower. A server death during TF is TF_OOM only with an OOM line and no device fault."""
        kvb = NB1_KV.get(name) or (KV_FP8 if kv == "fp8" else KV_BF16)   # E25 NB1: the B3 pin step
        tries = []
        while True:
            gate = boot_gate()
            if gate["ok"] is not True:
                return {"status": "GPU_NOT_EMPTY", "boot_gate": gate, "tries": tries}
            shm0 = shm_names()
            o = with_servers([merlin_fn_server(name, kv, port, kvb)], timeout, body)
            o.update(kv_bytes=kvb, boot_gate=gate, shm_cleanup=shm_cleanup(shm0))
            srv = (o.get("servers") or {}).get(name) or {}
            oom = o.get("status") == "LAUNCH_FAILED" and bool(OOM_ERR.search(srv.get("log_tail") or ""))
            tries.append({"kv_bytes": kvb, "status": o.get("status"), "oom": oom})
            if not oom or len(tries) > 1 or left() < timeout + 900:
                break
            kvb -= OOM_STEP
            log("boot OOM:", name, "retry with KV_BYTES", kvb)
        o["tries"] = tries
        if o.get("tf_died") and o.get("status") == "SERVER_DIED":
            srv = (o.get("servers") or {}).get(name) or {}
            if OOM_ERR.search(srv.get("log_tail") or "") and not srv.get("xid"):
                o["status"] = "TF_OOM"
                o["status_note"] = "the server died of OOM in the teacher-forced call (run last); everything before it is valid"
            else:
                o["status"] = "TF_SERVER_DIED"
                o["status_note"] = "the server died in the teacher-forced call without an OOM line (or with a device fault)"
        g = gated(o, need=need, expected_rows=expected_rows, require_sampled=require_sampled)
        if g.get("status") == "TF_OOM" and g.get("correctness") != "CLEAN":
            g["status"] = g["correctness"]
        lg = long_gate(g)                                  # final audit H3: the long rows have their own verdict
        g["long_verdict"] = lg or ("PASS_LONG" if isinstance(g.get("long"), dict) else None)
        if lg and g.get("status") in ("DONE", "TF_OOM"):
            g["status"] = lg
        return g


    def arm_bf16():
        def body(ss):
            s = ss[0]
            p = s.port
            o = {"census": kv_census(s), "probes": L.chat_probes(p), "sampled": sampled_check(s)}
            if short_gate_failed(o):
                o.update(early_stop="SHORT_CORRECTNESS_GATE_FAILED", census_end=kv_census(s))
                return o
            o["prefill"] = prefill_probe(p)
            o["oracle"] = oracle(p, key="bf16")
            o["census_end"] = kv_census(s)
            if not oracle_ok(o["oracle"]):
                o["early_stop"] = "ORACLE_INCOMPLETE"          # no reference: the TF A/A would measure nothing usable
                return o
            o["tf"] = tf_last(s, key="bf16", aa=True)
            o["tf_died"] = not o["tf"]["alive_after"]
            return o
        ok, why = sha_gate(min(1500, left() - 900))
        R["setup"]["sha_gate"] = {"ok": ok, "why": why}
        if not ok:
            return {"status": "SKIPPED_SHA_GATE", "why": why}
        return merlin_boot("merlin_bf16", "bf16", 8000, 45 * 60, body)


    def fp8_gate(o):
        vs = (o["oracle"].get("vs_bf16") or {}).get("status")
        if (o.get("sampled") or {}).get("ok") is not True:
            return "FAIL_SAMPLED"
        if (o.get("probes") or {}).get("ok") is not True and not FAKE:
            return "FAIL_PROBES"
        if any(o["oracle"].get("errors") or []) or any(o["oracle"].get("garbage") or []) or vs == "FAIL_HIGH_MARGIN":
            return "FAIL"
        if o["oracle"].get("complete") is True and vs in CLEAN:
            return "PASS"
        return "INCONCLUSIVE"


    def arm_fp8():
        def body(ss):
            s = ss[0]
            p = s.port
            o = {"census": kv_census(s), "probes": L.chat_probes(p), "sampled": sampled_check(s)}
            if short_gate_failed(o):
                o.update(early_stop="SHORT_CORRECTNESS_GATE_FAILED", census_end=kv_census(s),
                         fp8_gate="FAIL_SAMPLED" if (o["sampled"] or {}).get("ok") is not True else "FAIL_PROBES")
                return o
            if not PREFILL["measured"]:
                o["prefill"] = prefill_probe(p)
            o["oracle"] = oracle(p, refs=("bf16",))
            o["fp8_gate"] = fp8_gate(o)
            if o["fp8_gate"] == "PASS":                      # load tests only on a PASS (audits: INCONCLUSIVE never runs them)
                kw = {"server": s, "temperature": TEMP, "prefill_tok_s": PREFILL["tok_s"]}
                o["steady"] = levels(p, "40k", LADDER, **kw)
                o["steady"].update(levels(p, "8k", [8], **kw))
                o["census_long"] = {**levels(p, "90k", [3, 4], **kw), **levels(p, "116k", [3, 4], **kw)}
                o["long"] = long_rows(p)
            else:
                o["load_tests_skipped"] = f"FP8 comparison gate: {o['fp8_gate']}"
                o["status"] = "NO_GO_FP8_KV" if o["fp8_gate"].startswith("FAIL") else "INCONCLUSIVE_FP8_KV"
            o["census_end"] = kv_census(s)
            if o["fp8_gate"] == "PASS" or os.environ.get("RC2_TF_ON_FP8_FAIL") == "1":   # default: fail fast
                o["tf"] = tf_last(s, ref="bf16")
                o["tf_died"] = not o["tf"]["alive_after"]
            return o
        return merlin_boot("merlin_fp8", "fp8", 8001, 40 * 60, body, need=("bf16",))


    def arm_bf16_load():
        """Only when FP8 fails: the ladder, the census and the long rows on BF16 KV (seqs 3). DIAGNOSTIC_ONLY: this arm
        has no oracle of its own (the A1 boot is the BF16 reference)."""
        def body(ss):
            s = ss[0]
            p = s.port
            o = {"census": kv_census(s), "probes": L.chat_probes(p), "sampled": sampled_check(s)}
            if short_gate_failed(o):
                o["early_stop"] = "SHORT_CORRECTNESS_GATE_FAILED"
            else:
                kw = {"server": s, "temperature": TEMP, "prefill_tok_s": PREFILL["tok_s"]}
                o["steady"] = levels(p, "40k", [1, 2, 3], **kw)
                o["census_long"] = levels(p, "116k", [1, 2], **kw)
                o["long"] = long_rows(p)
            o["census_end"] = kv_census(s)
            o["certification"] = "DIAGNOSTIC_ONLY"
            return o
        return merlin_boot("merlin_bf16_load", "bf16", 8002, 30 * 60, body, expected_rows=None)


    def arm_stock():
        """Fallback when Merlin cannot serve: stock vLLM 0.32 + Intel W4A16 (RC1's correct engine), -lcuda shim, FP8 KV."""
        if INTEL is None or WHEELHOUSE is None:
            return {"status": "FALLBACK_UNAVAILABLE", "why": f"intel={INTEL} wheelhouse={WHEELHOUSE}"}

        def body(ss):
            s = ss[0]
            p = s.port
            o = {"census": kv_census(s), "probes": L.chat_probes(p), "sampled": sampled_check(s)}
            if short_gate_failed(o):
                o["early_stop"] = "SHORT_CORRECTNESS_GATE_FAILED"
                return o
            o["oracle"] = oracle(p, key="stock", prompts=ORACLE_P)          # 2k / 2k / 8k (32k max length: no 40k row)
            if oracle_ok(o["oracle"]):
                o["steady"] = levels(p, "8k", [1, 2, 3], server=s, temperature=TEMP)
            return o
        gate = boot_gate()
        if gate["ok"] is not True:
            return {"status": "GPU_NOT_EMPTY", "boot_gate": gate}
        shm0 = shm_names()
        o = gated(with_servers([stock_fn_server("stock_fn", 8003)], 40 * 60, body), expected_rows=len(ORACLE_P))
        o.update(boot_gate=gate, shm_cleanup=shm_cleanup(shm0))
        return o


    save()


if not RERUN:
    # ==================================================================== CELL 6 — reused tools, verbatim (NB0 CELL 6, NB1 CELL 6 / 7)
    import statistics
    import textwrap
    import numpy as np
    import urllib.request as UR
    import urllib.error as UE
    from collections import Counter
    R.pop("capacity_plan", None)          # RC2-only records written by RC2's CELL 5 definitions
    R.pop("correctness_meaning", None)
    RC2_REF = json.loads("{\"fp8\": {\"argv_tail\": [\"127.0.0.1\", \"--port\", \"8001\", \"--tensor-parallel-size\", \"2\", \"--pipeline-parallel-size\", \"2\", \"--enable-expert-parallel\", \"--disable-custom-all-reduce\", \"--speculative-config\", \"{\\\"method\\\":\\\"mtp\\\",\\\"num_speculative_tokens\\\":3,\\\"draft_sample_method\\\":\\\"probabilistic\\\"}\", \"--max-model-len\", \"262144\", \"--max-num-seqs\", \"8\", \"--max-num-batched-tokens\", \"1024\", \"--gpu-memory-utilization\", \"0.96\", \"--kv-cache-memory-bytes\", \"2479838700\", \"--kv-cache-dtype\", \"fp8_e4m3\", \"--limit-mm-per-prompt\", \"{\\\"image\\\":42,\\\"video\\\":0}\", \"--mm-processor-cache-gb\", \"0\", \"--mm-processor-kwargs\", \"{\\\"size\\\":{\\\"longest_edge\\\":8388608,\\\"shortest_edge\\\":65536}}\", \"--compilation-config\", \"{\\\"cudagraph_mode\\\":\\\"FULL_AND_PIECEWISE\\\",\\\"cudagraph_capture_sizes\\\":[1,2,3,4,6,8,12,16,24,32]}\", \"--enable-prefix-caching\", \"--mamba-cache-mode\", \"align\", \"--enable-prompt-tokens-details\", \"--no-enable-flashinfer-autotune\", \"--enable-auto-tool-choice\", \"--tool-call-parser\", \"qwen3_coder\", \"--reasoning-parser\", \"qwen3\", \"--override-generation-config\", \"{\\\"temperature\\\":1.0,\\\"top_p\\\":0.95,\\\"top_k\\\":20,\\\"min_p\\\":0.0,\\\"presence_penalty\\\":0.0,\\\"repetition_penalty\\\":1.0}\", \"--default-chat-template-kwargs\", \"{\\\"enable_thinking\\\": true, \\\"reasoning_effort\\\": \\\"medium\\\"}\", \"--shutdown-timeout\", \"60\", \"--block-size\", \"4096\", \"--use-replayssm\", \"--prefix-match-unit\", \"64\", \"--served-model-name\", \"q27\", \"--max-model-len\", \"131072\", \"--port\", \"8001\", \"--default-chat-template-kwargs\", \"{\\\"enable_thinking\\\": true, \\\"reasoning_effort\\\": \\\"xhigh\\\"}\"], \"env\": {\"KV_BYTES\": \"2479838700\", \"NCCL_P2P_DISABLE\": \"1\", \"NCCL_VERSION\": \"2.25.1-1\", \"P2P\": \"off\", \"SCALES\": \"/tmp/fn_merlin/qsa_kv_scales_262k.json\", \"VLLM_CACHE_ROOT\": \"/tmp/merlin-cache\", \"VLLM_E2_GUARD_MODE\": \"warn\", \"VLLM_E2_PLE_EARLY_REQUEST\": \"1\", \"VLLM_E2_PLE_FAST_IDS\": \"1\", \"VLLM_E2_QSA_LOGITS_GRANULE_MB\": \"256\", \"VLLM_HOST_EMBED_TABLE\": \"1\", \"VLLM_MEMORY_PROFILER_ESTIMATE_CUDAGRAPHS\": \"0\", \"VLLM_PLE_OFFLOAD_HOME_DEVICE\": \"0\", \"VLLM_PLE_OFFLOAD_READY_TIMEOUT\": \"3600\", \"VLLM_PORT\": \"30100\", \"VLLM_PP_LAYER_PARTITION\": \"25,23\", \"VLLM_QSA_KV_SCALES\": \"/tmp/fn_merlin/qsa_kv_scales_262k.json\", \"VLLM_SKIP_P2P_CHECK\": \"1\", \"VLLM_SPARSE_INDEXER_MAX_LOGITS_MB\": \"256\", \"VLLM_USE_BREAKABLE_CUDAGRAPH\": \"0\", \"VLLM_USE_RUST_FRONTEND\": \"0\", \"VLLM_USE_V2_MODEL_RUNNER\": \"1\"}, \"kv_bytes\": 2479838700, \"kv_tokens\": 513940, \"seqs\": 8}, \"bf16\": {\"argv_tail\": [\"127.0.0.1\", \"--port\", \"8000\", \"--tensor-parallel-size\", \"2\", \"--pipeline-parallel-size\", \"2\", \"--enable-expert-parallel\", \"--disable-custom-all-reduce\", \"--speculative-config\", \"{\\\"method\\\":\\\"mtp\\\",\\\"num_speculative_tokens\\\":3,\\\"draft_sample_method\\\":\\\"probabilistic\\\"}\", \"--max-model-len\", \"262144\", \"--max-num-seqs\", \"3\", \"--max-num-batched-tokens\", \"1024\", \"--gpu-memory-utilization\", \"0.96\", \"--kv-cache-memory-bytes\", \"2464415744\", \"--kv-cache-dtype\", \"bfloat16\", \"--limit-mm-per-prompt\", \"{\\\"image\\\":42,\\\"video\\\":0}\", \"--mm-processor-cache-gb\", \"0\", \"--mm-processor-kwargs\", \"{\\\"size\\\":{\\\"longest_edge\\\":8388608,\\\"shortest_edge\\\":65536}}\", \"--compilation-config\", \"{\\\"cudagraph_mode\\\":\\\"FULL_AND_PIECEWISE\\\",\\\"cudagraph_capture_sizes\\\":[1,2,3,4,6,8,12]}\", \"--enable-prefix-caching\", \"--mamba-cache-mode\", \"align\", \"--enable-prompt-tokens-details\", \"--no-enable-flashinfer-autotune\", \"--enable-auto-tool-choice\", \"--tool-call-parser\", \"qwen3_coder\", \"--reasoning-parser\", \"qwen3\", \"--override-generation-config\", \"{\\\"temperature\\\":1.0,\\\"top_p\\\":0.95,\\\"top_k\\\":20,\\\"min_p\\\":0.0,\\\"presence_penalty\\\":0.0,\\\"repetition_penalty\\\":1.0}\", \"--default-chat-template-kwargs\", \"{\\\"enable_thinking\\\": true, \\\"reasoning_effort\\\": \\\"medium\\\"}\", \"--shutdown-timeout\", \"60\", \"--block-size\", \"4096\", \"--use-replayssm\", \"--prefix-match-unit\", \"64\", \"--served-model-name\", \"q27\", \"--max-model-len\", \"131072\", \"--port\", \"8000\", \"--default-chat-template-kwargs\", \"{\\\"enable_thinking\\\": true, \\\"reasoning_effort\\\": \\\"xhigh\\\"}\"], \"env\": {\"KV_BYTES\": \"2464415744\", \"NCCL_P2P_DISABLE\": \"1\", \"NCCL_VERSION\": \"2.25.1-1\", \"P2P\": \"off\", \"VLLM_CACHE_ROOT\": \"/tmp/merlin-cache\", \"VLLM_E2_GUARD_MODE\": \"warn\", \"VLLM_E2_PLE_EARLY_REQUEST\": \"1\", \"VLLM_E2_PLE_FAST_IDS\": \"1\", \"VLLM_E2_QSA_LOGITS_GRANULE_MB\": \"256\", \"VLLM_HOST_EMBED_TABLE\": \"1\", \"VLLM_MEMORY_PROFILER_ESTIMATE_CUDAGRAPHS\": \"0\", \"VLLM_PLE_OFFLOAD_HOME_DEVICE\": \"0\", \"VLLM_PLE_OFFLOAD_READY_TIMEOUT\": \"3600\", \"VLLM_PORT\": \"30000\", \"VLLM_PP_LAYER_PARTITION\": \"25,23\", \"VLLM_SKIP_P2P_CHECK\": \"1\", \"VLLM_SPARSE_INDEXER_MAX_LOGITS_MB\": \"256\", \"VLLM_USE_BREAKABLE_CUDAGRAPH\": \"0\", \"VLLM_USE_RUST_FRONTEND\": \"0\", \"VLLM_USE_V2_MODEL_RUNNER\": \"1\"}, \"kv_bytes\": 2464415744, \"kv_tokens\": 269042, \"seqs\": 3}, \"tf40k\": {\"fp8_vs_bf16\": {\"status\": \"MEASURED\", \"n\": 256, \"mean_abs_dlogprob\": 1.8764, \"p99_abs_dlogprob\": 5.464, \"max_abs_dlogprob\": 7.15, \"rank1_agreement\": 0.3672, \"forced_token_rank1_both_or_neither\": 0.457}, \"bf16_aa\": {\"status\": \"MEASURED\", \"n\": 256, \"mean_abs_dlogprob\": 0.0, \"p99_abs_dlogprob\": 0.0, \"max_abs_dlogprob\": 0.0, \"rank1_agreement\": 1.0, \"forced_token_rank1_both_or_neither\": 1.0}}, \"oracle_rows\": {\"rc2_bf16\": [{\"text\": \"We need solve ARC task. Need infer transformation from examples. User gives Task 0934a4d8 with Example 1 input/output, Example 2 input/output, Example 3 input only? Need solve test inputs? They provided Example 3 input: 194499276 maybe incomplete? Need output? Need find transformation rule and solve test inputs. We need analyze.\\n\\nWe have ARC tasks represented as strings of digits? Example 1 input is 31 rows? Let's count. Example 1 input lines:\\n1 3533665414\", \"tokens\": [1596, 1144, 11290, 67964, 3274, 13, 14235, 22846, 17454, 494, 9989, 13, 2570, 6486, 5261, 220, 15, 24, 18, 19, 64, 19, 67, 23, 440, 12996, 220, 16, 1879, 45447, 11, 12996, 220, 17, 1879, 45447, 11, 12996, 220, 18, 1879, 1132, 30, 14235, 11290, 1228, 10804, 30, 2302, 3766, 12996, 220, 18, 1879, 25, 220, 16, 24, 19, 19, 24, 24, 17, 22, 21, 6970, 31084, 30, 14235, 2468, 30, 14235, 1423, 17454, 5728, 321, 11290, 1228, 10804, 13, 1165, 1144, 22903, 13, 271, 1596, 599, 67964, 8806, 14807, 430, 8796, 314, 17955, 30, 12996, 220, 16, 1879, 369, 220, 18, 16, 6761, 30, 6558, 579, 1698, 13, 12996, 220, 16, 1879, 4965, 25, 198, 16, 220, 18, 20, 18, 18, 21, 21, 20, 19, 16, 19], \"margins\": [11.375, 10.75, 0.25, 3.5, 0.125, 1.75, 2.375, 0.625, 4.375, 0.125, 4.125, 1.375, 0.125, 1.0, 1.25, 4.875, 8.6875, 10.375, 10.375, 9.6875, 8.25, 10.1875, 14.0, 10.4375, 0.125, 0.875, 1.25, 8.375, 3.875, 1.0, 3.75, 7.375, 3.75, 12.0, 2.625, 8.375, 6.75, 2.5, 8.75, 10.5, 6.625, 0.125, 0.375, 0.5, 0.75, 8.25, 4.125, 1.0, 1.0, 0.125, 0.25, 4.625, 6.375, 9.25, 2.875, 0.375, 4.125, 4.25, 10.9375, 11.5625, 10.625, 10.5625, 9.5625, 11.5, 10.6875, 0.5, 2.25, 4.875, 2.125, 1.25, 0.125, 0.5, 0.625, 0.625, 4.25, 1.125, 2.875, 3.125, 3.125, 4.125, 0.75, 1.375, 1.75, 0.75, 1.0, 4.25, 1.5, 0.5, 1.125, 0.625, 4.625, 1.625, 0.25, 4.5, 1.0, 0.0, 1.25, 8.5, 5.0, 1.125, 2.75, 3.375, 0.625, 0.125, 1.125, 1.875, 7.25, 1.875, 2.125, 0.25, 0.875, 6.25, 1.875, 1.625, 2.625, 2.875, 2.125, 2.375, 8.125, 10.9375, 10.0625, 9.0625, 9.875, 9.375, 11.25, 11.375, 11.875, 12.9375], \"error\": null, \"prompt_sha\": \"8df9ed2c640ef5bd\", \"prompt_len\": 2048, \"finish_reason\": \"length\"}, {\"text\": \"We need solve ARC tasks. Need infer transformation rules from examples and apply to test inputs. We have two tasks: 1818057f and 195c6913. Need output transformed test grids. Need analyze carefully.\\n\\nWe need produce final answer likely grids. Need infer rules.\\n\\nTask 1818057f:\\nExamples: inputs/outputs with colors 2,4,8. Output changes some 4s to 8? Let's inspect.\\n\\nExample1 input 10x12? rows:\\n1 22224\", \"tokens\": [1596, 1144, 11290, 67964, 8806, 13, 14235, 22846, 17454, 5426, 494, 9989, 321, 3668, 310, 1228, 10804, 13, 1165, 599, 1330, 8806, 25, 220, 16, 23, 16, 23, 15, 20, 22, 69, 321, 220, 16, 24, 20, 66, 21, 24, 16, 18, 13, 14235, 2468, 22773, 1228, 54455, 13, 14235, 22903, 15060, 13, 271, 1596, 1144, 7936, 1534, 4087, 4222, 54455, 13, 14235, 22846, 5426, 13, 271, 6065, 220, 16, 23, 16, 23, 15, 20, 22, 69, 25, 198, 39044, 25, 10804, 14, 39652, 440, 7736, 220, 17, 11, 19, 11, 23, 13, 8984, 4203, 1010, 220, 19, 82, 310, 220, 23, 30, 6558, 579, 23331, 13, 271, 12929, 16, 1879, 220, 16, 15, 87, 16, 17, 30, 6761, 25, 198, 16, 220, 17, 17, 17, 17, 19], \"margins\": [11.875, 11.375, 0.75, 3.375, 2.625, 3.0, 3.25, 0.5, 3.125, 0.25, 0.625, 4.75, 1.125, 3.25, 2.0, 5.5, 0.875, 3.75, 0.375, 0.5, 1.375, 6.5, 1.125, 2.25, 12.625, 12.0625, 11.3125, 12.9375, 12.4375, 8.875, 10.8125, 10.75, 1.75, 7.375, 13.5625, 13.875, 11.6875, 11.25, 10.75, 12.375, 12.375, 10.75, 2.25, 2.25, 1.625, 0.875, 1.0, 0.375, 0.875, 1.375, 0.125, 1.875, 6.5, 1.5, 1.0, 1.375, 1.0, 4.75, 4.625, 1.75, 1.0, 1.625, 0.875, 0.625, 0.25, 3.5, 1.0, 1.25, 4.625, 11.625, 5.75, 11.125, 12.3125, 10.8125, 10.9375, 11.0, 11.8125, 0.125, 0.0, 2.625, 0.375, 0.25, 0.875, 7.875, 0.75, 0.875, 1.875, 8.125, 0.75, 7.375, 2.875, 3.875, 2.125, 0.25, 2.0, 3.25, 2.625, 0.625, 2.625, 2.125, 10.75, 10.625, 0.75, 1.75, 7.5, 2.75, 6.375, 0.25, 1.75, 1.375, 0.75, 3.25, 8.375, 4.625, 3.75, 4.375, 2.625, 1.5, 0.25, 0.5, 5.375, 1.375, 0.5, 9.75, 4.625, 12.625, 11.4375, 8.375], \"error\": null, \"prompt_sha\": \"8750743e9dcadca9\", \"prompt_len\": 2048, \"finish_reason\": \"length\"}, {\"text\": \"We need solve ARC tasks. Need find transformation rule for each task and solve test inputs. We have multiple tasks: 247ef758, 269e22fb, 271d71e2, 28a6681f, 291dc1e1. Need output transformed grids for test inputs. Need infer rules from examples. Need be careful. We need produce final answer likely grids. Need analyze each task.\\n\\nWe need parse tasks. There are two test inputs for 247ef758? It says Test input: ...\", \"tokens\": [1596, 1144, 11290, 67964, 8806, 13, 14235, 1423, 17454, 5728, 364, 1754, 3274, 321, 11290, 1228, 10804, 13, 1165, 599, 5081, 8806, 25, 220, 17, 19, 22, 797, 22, 20, 23, 11, 220, 17, 21, 24, 68, 17, 17, 10481, 11, 220, 17, 22, 16, 67, 22, 16, 68, 17, 11, 220, 17, 23, 64, 21, 21, 23, 16, 69, 11, 220, 17, 24, 16, 7385, 16, 68, 16, 13, 14235, 2468, 22773, 54455, 364, 1228, 10804, 13, 14235, 22846, 5426, 494, 9989, 13, 14235, 381, 16097, 13, 1165, 1144, 7936, 1534, 4087, 4222, 54455, 13, 14235, 22903, 1754, 3274, 13, 271, 1596, 1144, 4563, 8806, 13, 2532, 513, 1330, 1228, 10804, 364, 220, 17, 19, 22, 797, 22, 20, 23, 30, 1049, 2640, 3284, 1879, 25, 2423], \"margins\": [11.75, 9.875, 1.125, 1.25, 3.875, 2.0, 2.875, 0.375, 5.25, 0.875, 1.5, 5.625, 0.875, 3.0, 2.875, 3.125, 7.75, 6.75, 0.5, 0.5, 1.5, 5.625, 1.375, 3.0, 11.75, 13.375, 12.625, 11.3125, 12.0, 13.5, 12.625, 0.625, 8.4375, 11.625, 11.0, 12.5625, 10.5625, 11.0, 10.375, 8.375, 7.375, 9.75, 11.5625, 9.125, 10.0, 9.75, 9.4375, 10.3125, 10.4375, 9.0, 8.1875, 9.4375, 12.625, 9.75, 11.0, 11.3125, 10.9375, 9.625, 9.5625, 10.0, 8.1875, 7.625, 12.375, 11.125, 11.375, 10.625, 10.25, 10.375, 10.0, 2.5, 3.0, 2.125, 0.125, 0.125, 1.875, 0.125, 4.125, 3.125, 2.0, 0.75, 3.0, 0.75, 8.75, 4.125, 0.125, 1.25, 3.875, 2.75, 0.125, 0.25, 0.625, 3.875, 1.625, 1.875, 0.75, 1.0, 0.375, 2.375, 2.125, 0.5, 0.5, 2.5, 1.875, 0.125, 0.75, 0.375, 3.625, 0.125, 1.375, 0.0, 4.125, 7.375, 2.5, 0.375, 12.75, 6.75, 12.375, 4.625, 8.75, 12.1875, 10.25, 2.0, 0.625, 0.25, 1.125, 7.625, 1.75, 2.125], \"error\": null, \"prompt_sha\": \"fc63e297d382cd8f\", \"prompt_len\": 8192, \"finish_reason\": \"length\"}, {\"text\": \"We need solve ARC tasks. Need find transformation rule for each task and solve test inputs. We need output likely transformed grids. Need analyze many tasks. Need be careful. We have multiple tasks with examples and test inputs. Need infer rules.\\n\\nWe need produce final answer with transformed test inputs for each task. There are tasks: 2c181942, 2d0172a1 (two test inputs?), 31f7f899, 332f06d7, 35ab12c3, 36a08778\", \"tokens\": [1596, 1144, 11290, 67964, 8806, 13, 14235, 1423, 17454, 5728, 364, 1754, 3274, 321, 11290, 1228, 10804, 13, 1165, 1144, 2468, 4222, 22773, 54455, 13, 14235, 22903, 1599, 8806, 13, 14235, 381, 16097, 13, 1165, 599, 5081, 8806, 440, 9989, 321, 1228, 10804, 13, 14235, 22846, 5426, 13, 271, 1596, 1144, 7936, 1534, 4087, 440, 22773, 1228, 10804, 364, 1754, 3274, 13, 2532, 513, 8806, 25, 220, 17, 66, 16, 23, 16, 24, 19, 17, 11, 220, 17, 67, 15, 16, 22, 17, 64, 16, 318, 19186, 1228, 10804, 66926, 220, 18, 16, 69, 22, 69, 23, 24, 24, 11, 220, 18, 18, 17, 69, 15, 21, 67, 22, 11, 220, 18, 20, 365, 16, 17, 66, 18, 11, 220, 18, 21, 64, 15, 23, 22, 22, 23], \"margins\": [10.125, 11.5, 1.125, 0.25, 3.5, 2.125, 2.625, 0.5, 5.25, 1.0, 1.75, 5.75, 0.375, 2.375, 3.625, 4.25, 6.625, 7.375, 0.25, 0.125, 1.25, 0.5, 0.25, 2.0, 0.5, 1.625, 1.0, 1.0, 4.375, 2.875, 0.75, 2.125, 4.125, 4.0, 0.375, 0.5, 1.625, 3.875, 0.375, 2.125, 2.125, 2.125, 2.875, 1.625, 2.875, 1.125, 0.75, 1.375, 0.125, 1.625, 2.25, 1.0, 2.875, 2.5, 3.0, 0.125, 1.125, 0.75, 1.25, 2.375, 1.75, 1.625, 0.625, 3.0, 0.125, 4.5, 0.5, 11.625, 10.625, 12.0625, 13.0625, 9.5625, 10.9375, 10.375, 10.875, 1.0, 6.5, 9.8125, 10.25, 11.9375, 13.5, 12.3125, 11.625, 11.25, 11.25, 0.375, 2.5, 4.125, 7.25, 0.625, 5.375, 9.75, 9.625, 12.4375, 11.25, 10.4375, 9.0, 11.4375, 10.8125, 3.25, 8.375, 11.875, 7.375, 11.5, 11.0, 10.5625, 8.8125, 10.875, 10.375, 5.625, 10.125, 13.125, 8.625, 7.375, 11.1875, 10.5, 10.25, 10.9375, 5.25, 9.75, 10.1875, 7.25, 11.4375, 12.0, 8.9375, 11.0625, 9.5, 10.3125], \"error\": null, \"prompt_sha\": \"49b3958bb234d4fd\", \"prompt_len\": 40000, \"finish_reason\": \"length\"}], \"rc2_fp8\": [{\"text\": \"We need solve ARC task. Need infer transformation from examples. User gives Task 0934a4d8. Example 1 input 30x30? output 9x4? Example 2 input 30x30? output 4x5? Example 3 input: \\\"194499276\\\" only one row? Maybe truncated? Need find transformation rule and solve test inputs. But only one test input? It says Example 3 input: 194499276. Maybe that's the test input? Need output. Need infer from\", \"tokens\": [1596, 1144, 11290, 67964, 3274, 13, 14235, 22846, 17454, 494, 9989, 13, 2570, 6486, 5261, 220, 15, 24, 18, 19, 64, 19, 67, 23, 13, 12996, 220, 16, 1879, 220, 18, 15, 87, 18, 15, 30, 2468, 220, 24, 87, 19, 30, 12996, 220, 17, 1879, 220, 18, 15, 87, 18, 15, 30, 2468, 220, 19, 87, 20, 30, 12996, 220, 18, 1879, 25, 328, 16, 24, 19, 19, 24, 24, 17, 22, 21, 1, 1132, 799, 2713, 30, 10380, 57739, 30, 14235, 1423, 17454, 5728, 321, 11290, 1228, 10804, 13, 1921, 1132, 799, 1228, 1879, 30, 1049, 2640, 12996, 220, 18, 1879, 25, 220, 16, 24, 19, 19, 24, 24, 17, 22, 21, 13, 10380, 421, 579, 279, 1228, 1879, 30, 14235, 2468, 13, 14235, 22846, 494], \"margins\": [11.5, 11.25, 0.25, 3.625, 0.375, 2.25, 2.25, 0.875, 4.125, 0.25, 4.25, 1.25, 0.125, 1.0, 1.75, 4.625, 9.0, 9.9375, 10.375, 9.5, 8.875, 10.6875, 14.0, 10.625, 0.125, 0.75, 0.875, 7.5, 4.5, 1.25, 3.5, 0.75, 0.0, 1.75, 4.0, 2.625, 1.25, 9.375, 5.5, 4.25, 2.0, 0.25, 2.625, 0.875, 8.875, 3.75, 4.375, 5.75, 5.5, 4.25, 3.5, 5.5, 0.0, 8.0, 7.25, 7.375, 4.625, 5.875, 1.5, 3.75, 4.875, 9.125, 6.75, 0.25, 0.625, 8.25, 8.25, 12.3125, 11.5, 10.3125, 11.0, 10.1875, 11.625, 9.875, 4.375, 2.25, 0.375, 1.0, 4.875, 0.0, 0.25, 5.75, 2.125, 0.0, 0.25, 2.375, 2.875, 6.75, 9.125, 5.125, 1.875, 0.75, 2.375, 0.0, 0.875, 1.875, 2.125, 0.75, 2.25, 1.625, 9.1875, 7.125, 9.125, 5.625, 1.125, 7.9375, 7.0625, 10.375, 11.375, 10.8125, 10.5625, 11.1875, 11.5, 11.625, 1.0, 1.625, 1.375, 2.625, 0.5, 2.375, 1.75, 2.625, 2.0, 2.625, 0.125, 1.5, 0.25, 1.5], \"error\": null, \"prompt_sha\": \"8df9ed2c640ef5bd\", \"prompt_len\": 2048, \"finish_reason\": \"length\"}, {\"text\": \"We need solve ARC tasks. Need infer transformation rules from examples and apply to test inputs. We have two tasks: 1818057f and 195c6913. Need output transformed test grids. Need analyze carefully.\\n\\nWe need produce final answer likely grids. Need infer rules.\\n\\nTask 1818057f examples:\\nInput/output grids with colors 2,4,8. Output changes some 4s to 8? Let's inspect.\\n\\nExample1 10x12? Input rows:\\n1 222244\", \"tokens\": [1596, 1144, 11290, 67964, 8806, 13, 14235, 22846, 17454, 5426, 494, 9989, 321, 3668, 310, 1228, 10804, 13, 1165, 599, 1330, 8806, 25, 220, 16, 23, 16, 23, 15, 20, 22, 69, 321, 220, 16, 24, 20, 66, 21, 24, 16, 18, 13, 14235, 2468, 22773, 1228, 54455, 13, 14235, 22903, 15060, 13, 271, 1596, 1144, 7936, 1534, 4087, 4222, 54455, 13, 14235, 22846, 5426, 13, 271, 6065, 220, 16, 23, 16, 23, 15, 20, 22, 69, 9989, 25, 198, 2425, 45447, 54455, 440, 7736, 220, 17, 11, 19, 11, 23, 13, 8984, 4203, 1010, 220, 19, 82, 310, 220, 23, 30, 6558, 579, 23331, 13, 271, 12929, 16, 220, 16, 15, 87, 16, 17, 30, 5396, 6761, 25, 198, 16, 220, 17, 17, 17, 17, 19, 19], \"margins\": [11.875, 11.75, 0.5, 3.125, 2.625, 3.0, 3.125, 0.5, 3.0, 0.5, 0.625, 4.875, 1.0, 3.25, 2.0, 5.625, 0.625, 3.875, 0.375, 0.75, 1.375, 6.75, 1.375, 2.125, 12.8125, 11.9375, 11.6875, 13.1875, 12.0625, 8.4375, 10.3125, 10.5, 1.625, 7.25, 13.5625, 12.625, 10.5625, 9.375, 12.0, 12.6875, 11.3125, 11.0625, 2.0, 2.375, 1.625, 0.875, 1.0, 0.125, 0.5, 1.25, 0.125, 1.875, 6.625, 1.625, 1.5, 1.5, 1.0, 4.75, 4.625, 2.0, 0.875, 1.5, 1.0, 0.625, 0.5, 3.375, 1.0, 1.125, 4.5, 12.375, 5.625, 11.125, 12.625, 10.0625, 9.875, 10.125, 11.625, 0.125, 1.375, 0.5, 1.0, 0.75, 0.375, 1.25, 1.0, 1.75, 7.75, 0.75, 7.75, 2.375, 3.625, 1.625, 0.25, 2.0, 3.5, 2.75, 1.125, 2.25, 2.375, 10.8125, 10.75, 0.75, 1.875, 7.5, 2.75, 5.25, 0.25, 2.125, 1.25, 0.0, 7.125, 3.625, 5.5, 4.5, 2.0, 1.5, 0.75, 0.875, 0.0, 6.375, 1.0, 0.75, 10.0, 4.75, 12.625, 11.5625, 8.375, 11.4375], \"error\": null, \"prompt_sha\": \"8750743e9dcadca9\", \"prompt_len\": 2048, \"finish_reason\": \"length\"}, {\"text\": \"We need solve ARC tasks. Need find transformation rule for each task and solve test inputs. We have multiple tasks: 247ef758, 269e22fb, 271d71e2, 28a6681f, 291dc1e1. Need output transformed test inputs. Need infer rules from examples. Need be careful. We can analyze each.\\n\\nWe need produce final answer likely grids for each test input. Need determine exact transformations.\\n\\nLet's parse tasks.\\n\\nTask 247ef758: examples show\", \"tokens\": [1596, 1144, 11290, 67964, 8806, 13, 14235, 1423, 17454, 5728, 364, 1754, 3274, 321, 11290, 1228, 10804, 13, 1165, 599, 5081, 8806, 25, 220, 17, 19, 22, 797, 22, 20, 23, 11, 220, 17, 21, 24, 68, 17, 17, 10481, 11, 220, 17, 22, 16, 67, 22, 16, 68, 17, 11, 220, 17, 23, 64, 21, 21, 23, 16, 69, 11, 220, 17, 24, 16, 7385, 16, 68, 16, 13, 14235, 2468, 22773, 1228, 10804, 13, 14235, 22846, 5426, 494, 9989, 13, 14235, 381, 16097, 13, 1165, 628, 22903, 1754, 13, 271, 1596, 1144, 7936, 1534, 4087, 4222, 54455, 364, 1754, 1228, 1879, 13, 14235, 7995, 4581, 51192, 13, 271, 9764, 579, 4563, 8806, 13, 271, 6065, 220, 17, 19, 22, 797, 22, 20, 23, 25, 9989, 1420], \"margins\": [11.875, 9.75, 1.25, 1.5, 3.625, 2.125, 3.0, 0.125, 5.25, 0.875, 1.625, 5.5, 0.875, 3.125, 2.875, 2.875, 8.5, 7.125, 0.375, 0.375, 1.875, 5.375, 1.625, 3.0, 12.125, 13.3125, 12.9375, 11.8125, 11.8125, 13.5, 12.5, 0.375, 8.875, 11.6875, 10.9375, 12.25, 11.0625, 10.6875, 10.375, 8.3125, 7.375, 10.4375, 11.1875, 9.0, 9.8125, 10.125, 10.25, 10.8125, 10.125, 9.3125, 8.0625, 9.5, 12.4375, 10.4375, 11.0, 11.1875, 11.1875, 9.6875, 10.375, 9.0, 7.75, 7.625, 12.875, 10.8125, 11.375, 9.625, 10.625, 11.0625, 9.875, 2.375, 2.875, 2.125, 0.125, 0.0, 0.875, 0.75, 2.0, 0.625, 3.125, 0.875, 8.375, 3.875, 0.125, 1.25, 4.125, 2.875, 0.375, 0.125, 0.5, 0.125, 0.875, 1.375, 2.5, 2.25, 0.75, 4.0, 1.75, 2.0, 0.875, 0.625, 1.125, 3.375, 4.25, 3.75, 0.875, 0.125, 0.5, 0.875, 6.25, 1.5, 3.125, 10.25, 2.625, 2.25, 3.25, 3.625, 3.625, 6.75, 10.375, 7.625, 12.5, 11.75, 11.25, 11.875, 13.4375, 1.5, 0.0, 0.25], \"error\": null, \"prompt_sha\": \"fc63e297d382cd8f\", \"prompt_len\": 8192, \"finish_reason\": \"length\"}, {\"text\": \"We need solve ARC tasks. Need find transformation rule for each task and solve test inputs. We have multiple tasks with examples and test inputs. Need output transformed grids likely. Need infer rules. This is complex. Need analyze each task carefully. Need produce final answer with outputs for each test input. Need be accurate.\\n\\nWe have tasks:\\n2c181942 (one test input)\\n2d0172a1 (two test inputs? It lists Test input twice)\\n31f7f899 (one test)\\n332f06d7 (one test)\", \"tokens\": [1596, 1144, 11290, 67964, 8806, 13, 14235, 1423, 17454, 5728, 364, 1754, 3274, 321, 11290, 1228, 10804, 13, 1165, 599, 5081, 8806, 440, 9989, 321, 1228, 10804, 13, 14235, 2468, 22773, 54455, 4222, 13, 14235, 22846, 5426, 13, 1061, 369, 6150, 13, 14235, 22903, 1754, 3274, 15060, 13, 14235, 7936, 1534, 4087, 440, 15796, 364, 1754, 1228, 1879, 13, 14235, 381, 12995, 13, 271, 1596, 599, 8806, 25, 198, 17, 66, 16, 23, 16, 24, 19, 17, 318, 588, 1228, 1879, 8, 198, 17, 67, 15, 16, 22, 17, 64, 16, 318, 19186, 1228, 10804, 30, 1049, 11140, 3284, 1879, 10598, 8, 198, 18, 16, 69, 22, 69, 23, 24, 24, 318, 588, 1228, 8, 198, 18, 18, 17, 69, 15, 21, 67, 22, 318, 588, 1228, 8], \"margins\": [10.0, 11.25, 1.0, 0.625, 3.375, 2.5, 2.875, 0.375, 5.125, 0.875, 1.75, 5.875, 0.375, 2.875, 3.625, 4.125, 6.375, 7.5, 0.25, 0.0, 0.25, 6.25, 0.25, 3.75, 2.0, 2.625, 3.125, 2.875, 4.125, 2.75, 0.5, 1.375, 0.625, 0.5, 1.875, 0.125, 1.375, 0.25, 0.0, 9.625, 0.125, 1.375, 1.0, 0.625, 3.125, 4.125, 0.25, 1.875, 0.125, 0.875, 3.875, 1.5, 2.75, 0.0, 2.5, 0.875, 3.0, 4.75, 1.25, 1.0, 0.125, 1.75, 10.625, 1.875, 2.625, 0.125, 3.0, 3.5, 1.125, 0.25, 10.5, 13.375, 13.3125, 12.0625, 10.375, 9.625, 11.0, 0.125, 1.625, 7.5, 1.0, 3.5, 7.75, 7.0, 10.375, 13.0625, 13.1875, 12.0, 11.1875, 11.875, 11.1875, 7.125, 5.75, 5.25, 8.5, 0.625, 0.75, 0.75, 1.375, 7.375, 0.75, 0.0, 4.375, 8.9375, 9.875, 12.8125, 11.8125, 10.6875, 10.1875, 10.5625, 12.125, 4.625, 5.25, 1.125, 0.0, 10.875, 11.6875, 6.875, 13.0, 11.125, 12.0, 10.0625, 11.375, 10.5, 9.25, 9.0, 2.625, 5.25], \"error\": null, \"prompt_sha\": \"49b3958bb234d4fd\", \"prompt_len\": 40000, \"finish_reason\": \"length\"}]}, \"prompt_shas\": {\"8750743e9dcadca9\": 2048, \"cfc35f3fcb1e4c3c\": 40000, \"8df9ed2c640ef5bd\": 2048, \"fc63e297d382cd8f\": 8192, \"49b3958bb234d4fd\": 40000, \"23e0dd6cf518ffd6\": 40000, \"860a315bad6a77cd\": 40000, \"d9b32f9b8dccc17e\": 40000, \"cde642a1f2a6c19b\": 40000, \"f4212f34e7a2cc3a\": 8192, \"452f4eeeffdffcba\": 8192, \"cabba475611f1ca9\": 8192, \"b3074e57ef93918d\": 8192, \"e5f0513c6123c379\": 8192, \"5c55ca1649204598\": 8192, \"2395ccdb274f065a\": 8192, \"29ccfbd3ae41464d\": 90000, \"6d6f401b8828e42d\": 90000, \"0fc6beedaad76444\": 90000, \"44546bcef138a34a\": 90000, \"057ef8fde4806648\": 116000, \"6e42532a0cbaf769\": 116000, \"eced77cf1dce0ac9\": 116000, \"f581c9630300ae10\": 116000, \"d445d5b5d3d7c21c\": 4894}}")      # NB0's build-time RC2 facts: argv tails / env / pins / TF anchor / oracle rows / prompt shas
    # the globals the picked NB0 / NB1 functions read (NB0 CELL 6 values; NB1 CELL 6 values)
    NB0 = {"topk": int(os.environ.get("NB0_TF_TOPK") or 5), "sc_tok": int(os.environ.get("NB0_SC_TOKENS") or 256),
           "tf_variant": 5, "sc_variant": {"2k": 6, "8k": 7, "40k": 6}, "tf_bands": ["2k", "8k", "40k", "90k"], "sc_bands": ["2k", "8k", "40k"],
           "last": 256, "boot_watchdog_sec": 1800.0, "ready_sec": 1500.0, "host_floor_mib": (69 + 4) * 1024}
    SCREEN = {"rank1_min": 0.90, "mean_max": 0.15}       # NB0 (external audit 2): conservative screening, not a published limit
    TRIAGE = {"mean_max": 1.0, "rank1_min": 0.5}         # NB0 (external audit 3): severe-discrepancy triage
    RAW_DIR = OUT / "tf_raw"
    RAW_DIR.mkdir(exist_ok=True)
    NB0_REQ = TRACES / "k100_requests.jsonl"       # every non-streaming request (teacher-forced, decode) with its full text
    TFR, SCR, LOADMON, WD, SIDS, DROP = {}, {}, {}, {}, set(), set()
    PROC = Path(os.environ.get("NB0_PROC", "/proc"))
    CG = Path(os.environ.get("NB0_CGROUP", "/sys/fs/cgroup"))
    HOSTMEM = OUT / "hostmem"
    HOSTMEM.mkdir(exist_ok=True)
    BLOCK, PP, GEN_RATE = 4096, 2, 45.0           # NB1: block size, pipeline stages (one engine step = one micro-batch), window growth
    RAM_NEED_MIB = (69 + 4) * 1024                 # Merlin's ~69 GiB resident floor + 4 GiB margin (NB1 host_ram_gate)
    EXT_FLAG = ["--worker-extension-cls", "nb1_worker_ext.NB1WorkerExt"]
    DIAG_ENV = {"VLLM_SERVER_DEV_MODE": "1"}      # /collective_rpc (read-only extension) + /reset_prefix_cache; 127.0.0.1 only


    def flags(argv):
        """--flag -> value, the LAST occurrence wins (argparse); a flag followed by another flag is a switch (True)."""
        out = {}
        for i, a in enumerate(argv):
            if isinstance(a, str) and a.startswith("--"):
                nxt = argv[i + 1] if i + 1 < len(argv) else None
                out[a] = nxt if (nxt is not None and not str(nxt).startswith("--")) else True
        return out


    ENV_KEYS = ("VLLM_", "NCCL_", "KV_", "P2P", "SCALES", "NB0_")


    def _set_value(a, flag, value):
        idx = [i for i, x in enumerate(a) if x == flag]
        if len(idx) != 1:
            raise ValueError(f"{flag} occurs {len(idx)} times in the Merlin argv (expected 1)")
        a[idx[0] + 1] = value


    def nb0_argv(argv, boot):
        """Merlin's argv with this boot's edits. MTP off = the same command without --speculative-config (Merlin
        models/flash-next/CHANGELOG.md: "the no-MTP line is the same command without --speculative-config"; launch.py:441/452
        always emits it, R.MTP_K = 3 has no env knob). seqs / captures: the value of the existing flag (no new flags)."""
        a = [str(x) for x in argv]
        if not boot["mtp"]:
            idx = [i for i, x in enumerate(a) if x == "--speculative-config"]
            if len(idx) != 1:
                raise ValueError(f"--speculative-config occurs {len(idx)} times (expected 1)")
            del a[idx[0]:idx[0] + 2]
        if boot.get("seqs"):
            _set_value(a, "--max-num-seqs", str(boot["seqs"]))
        if boot.get("captures"):
            _set_value(a, "--compilation-config", boot["captures"])
        if "--enable-prefix-caching" not in a:
            raise ValueError("prefix caching must stay on in every NB0 boot")
        return a


    def config_diff(argv, env, kv_bytes, ref="fp8"):
        """Flag / env / KV-pin diff of a boot vs RC2's recorded plan (last occurrence wins on both sides)."""
        rf, cf = flags(RC2_REF[ref]["argv_tail"]), flags(argv)      # RC2's tail starts at --host's value (127.0.0.1)
        head = set(flags(argv[:-len(RC2_REF[ref]["argv_tail"]) + 2])) - set(rf)   # Merlin flags before RC2's recorded window
        fl = {k: [rf.get(k), cf.get(k)] for k in sorted(set(rf) | set(cf))
              if k not in ("--port", "--host") and k not in head and rf.get(k) != cf.get(k)}
        renv = RC2_REF[ref]["env"]
        cenv = {k: v for k, v in env.items() if k.startswith(ENV_KEYS)}
        skip = ("VLLM_PORT", "MASTER_PORT", "NCCL_VERSION")
        ev = {k: [renv.get(k), cenv.get(k)] for k in sorted(set(renv) | set(cenv)) if k not in skip and renv.get(k) != cenv.get(k)}
        out = {"flags": fl, "env": ev}
        if kv_bytes != RC2_REF[ref]["kv_bytes"]:
            out["kv_bytes"] = [RC2_REF[ref]["kv_bytes"], kv_bytes]
        return out


    def cg_snapshot(full=True):
        """cgroup v2 memory files (MiB for sizes). avail_mib = max - (current - inactive_file), Merlin's own rule."""
        o, kv = {}, {}
        for n in ("memory.current", "memory.max", "memory.peak"):
            try:
                o[n] = (CG / n).read_text().strip()
            except Exception:
                pass
        try:
            st = (CG / "memory.stat").read_text()
            kv = dict(l.split() for l in st.splitlines() if len(l.split()) == 2)
            o["stat_mib"] = {k: int(kv[k]) >> 20 for k in ("anon", "file", "active_file", "inactive_file", "shmem", "file_mapped",
                                                           "file_dirty", "file_writeback") if k in kv}
            o["stat_count"] = {k: int(kv[k]) for k in ("pgmajfault", "workingset_refault_file", "pgscan", "pgsteal") if k in kv}
            if full:
                o["memory.stat"] = st[:6000]
        except Exception:
            pass
        for n in ("memory.events", "memory.pressure"):
            try:
                o[n] = (CG / n).read_text().strip()[:800]
            except Exception:
                pass
        try:
            mx = o.get("memory.max")
            if mx and mx != "max":
                o["avail_mib"] = (int(mx) - (int(o["memory.current"]) - int(kv.get("inactive_file", 0)))) >> 20
        except Exception:
            pass
        return o


    def _pids():
        try:
            return [int(p.name) for p in PROC.iterdir() if p.name.isdigit()]
        except Exception:
            return None


    def _stat(pid):
        try:
            t = (PROC / str(pid) / "stat").read_text()
        except Exception:
            return None
        i = t.rfind(")")
        f = t[i + 2:].split()
        try:
            return {"pid": pid, "comm": t[t.find("(") + 1:i], "state": f[0], "ppid": int(f[1]), "session": int(f[3]),
                    "minflt": int(f[7]), "majflt": int(f[9]), "utime": int(f[11]), "stime": int(f[12]), "rss_pages": int(f[21])}
        except Exception:
            return None


    def _io(pid):
        try:
            return {k: int(v) for k, v in (l.split(": ") for l in (PROC / str(pid) / "io").read_text().splitlines())
                    if k in ("rchar", "read_bytes", "syscr")}
        except Exception:
            return {}


    def session_procs(sids):
        out = []
        for pid in _pids() or []:
            st = _stat(pid)
            if st and st["session"] in sids and st["state"] != "Z":
                st.update(_io(pid))
                out.append(st)
        return out


    def _roles(text):
        return {int(p): n for n, p in re.findall(r"\((\w+) pid=(\d+)\)", text or "")}


    def load_monitor(s, key, deadline):
        """Every 5 s from launch to ready: cgroup current / avail / stat / pressure and every process of the server session
        (majflt, minflt, rchar, read_bytes, rss, cpu) -> logs/load_monitor_<boot>.jsonl + a per-process summary."""
        path = LOGS / f"load_monitor_{key}.jsonl"
        while s.proc is None and time.time() < deadline:
            time.sleep(0.5)
        if s.proc is None:
            return
        sid = s.proc.pid
        SIDS.add(sid)
        tck = os.sysconf("SC_CLK_TCK") if hasattr(os, "sysconf") else 100
        t0, first, last, n = time.time(), {}, {}, 0
        peak = {"cg_current_mib_max": None, "avail_mib_min": None, "pressure_full_avg10_max": None}
        while s.alive() and s.ready_sec is None and time.time() < deadline:
            cg = cg_snapshot(False)
            ps = session_procs({sid})
            try:
                with open(path, "a") as fh:
                    fh.write(json.dumps({"t": round(time.time() - t0, 1), "current": cg.get("memory.current"),
                                         "avail_mib": cg.get("avail_mib"), "stat_mib": cg.get("stat_mib"),
                                         "stat_count": cg.get("stat_count"), "pressure": cg.get("memory.pressure"),
                                         "procs": ps}) + "\n")
            except Exception:
                pass
            for p in ps:
                first.setdefault(p["pid"], p)
                last[p["pid"]] = p
            try:
                c = int(cg["memory.current"]) >> 20
                peak["cg_current_mib_max"] = max(peak["cg_current_mib_max"] or 0, c)
            except Exception:
                pass
            if cg.get("avail_mib") is not None:
                peak["avail_mib_min"] = min(x for x in (peak["avail_mib_min"], cg["avail_mib"]) if x is not None)
            m = re.search(r"full avg10=([\d.]+)", cg.get("memory.pressure") or "")
            if m:
                peak["pressure_full_avg10_max"] = max(peak["pressure_full_avg10_max"] or 0.0, float(m.group(1)))
            n += 1
            time.sleep(0.5 if FAKE else 5)
        roles = _roles(s.log())
        per = {}
        for pid, a in first.items():
            z = last[pid]
            per[str(pid)] = {"role": roles.get(pid, a["comm"]), "majflt": z["majflt"] - a["majflt"],
                             "minflt": z["minflt"] - a["minflt"],
                             "read_gib": round((z.get("read_bytes", 0) - a.get("read_bytes", 0)) / 2 ** 30, 2),
                             "rchar_gib": round((z.get("rchar", 0) - a.get("rchar", 0)) / 2 ** 30, 2),
                             "rss_gib_end": round(z["rss_pages"] * 4096 / 2 ** 30, 2),
                             "cpu_s": round((z["utime"] + z["stime"] - a["utime"] - a["stime"]) / tck, 1)}
        loads = re.findall(r"\((\w+) pid=(\d+)\)[^\n]*Model loading took ([\d.]+) GiB memory and ([\d.]+) seconds", s.log() or "")
        LOADMON[key] = {"samples": n, "ready_sec": s.ready_sec, "alive": s.alive(), "per_process": per, "peak": peak,
                        "model_loading": [[w, int(p), float(g), float(sec)] for w, p, g, sec in loads], "file": path.name}


    def _post(port, body, timeout=1800):
        t = time.perf_counter()
        try:
            r = json.loads(UR.urlopen(UR.Request(f"http://127.0.0.1:{port}/v1/completions", data=json.dumps(body).encode(),
                                                 headers={"Content-Type": "application/json"}), timeout=timeout).read())
            return r, None, round(time.perf_counter() - t, 2)
        except UE.HTTPError as e:
            try:
                msg = e.read().decode("utf-8", "replace")[:400]
            except Exception:
                msg = ""
            return None, f"HTTP {e.code}: {msg}", round(time.perf_counter() - t, 2)
        except Exception as e:
            return None, repr(e)[:300], round(time.perf_counter() - t, 2)


    def _req_log(rec):
        try:
            with _SAVE_LOCK, open(NB0_REQ, "a") as fh:
                fh.write(json.dumps(rec, default=str) + "\n")
        except Exception:
            pass


    def ids_sha(ids):
        return hashlib.sha256(json.dumps([int(x) for x in ids]).encode()).hexdigest()


    def _cached(r):
        return (((r or {}).get("usage") or {}).get("prompt_tokens_details") or {}).get("cached_tokens")


    def pl_arrays(pl, ids, k):
        """Every prompt position p >= 1 of an OpenAI prompt_logprobs list: the actual token's logprob and rank, the unique
        rank-1 id (E23's rule: an ambiguous rank 1 is -1), the best logprob, the top-k ids / logprobs by rank. NaN is kept
        (a non-finite value is never data); a missing position is valid=False."""
        n = len(ids)
        a = {"ids": np.asarray(ids, np.int32), "lp": np.full(n, np.nan, np.float32), "rank": np.full(n, -1, np.int32),
             "top1": np.full(n, -1, np.int32), "top1_lp": np.full(n, np.nan, np.float32),
             "topk_ids": np.full((n, k), -1, np.int32), "topk_lp": np.full((n, k), np.nan, np.float32), "valid": np.zeros(n, bool)}
        amb = 0
        for pos in range(1, n):
            d = pl[pos] if pos < len(pl) else None
            if not isinstance(d, dict):
                continue
            e = d.get(str(ids[pos])) or d.get(f"token_id:{ids[pos]}")
            if not isinstance(e, dict):
                continue
            a["valid"][pos] = True
            v = e.get("logprob")
            a["lp"][pos] = float(v) if isinstance(v, (int, float)) else np.nan
            a["rank"][pos] = int(e.get("rank") or -1)
            ent = []
            for kk, vv in d.items():
                if isinstance(vv, dict) and isinstance(vv.get("logprob"), (int, float)):
                    t = L._tok_id(kk)
                    if isinstance(t, int):
                        ent.append((vv.get("rank") or 10 ** 9, -vv["logprob"], t, vv["logprob"]))
            ent.sort()
            r1 = [x for x in ent if x[0] == 1]
            if len(r1) == 1:
                a["top1"][pos] = r1[0][2]
            else:
                amb += 1
            if ent:
                a["top1_lp"][pos] = max(x[3] for x in ent)
            for j, x in enumerate([x for x in ent if x[0] <= k][:k]):
                a["topk_ids"][pos, j], a["topk_lp"][pos, j] = x[2], x[3]
        a["top1_ambiguous"] = amb
        return a


    def e23_rows(a, last=256):
        """The same per-position rows E23's teacher_forced() keeps ([logprob, rank, rank-1 id]) for the last `last` positions,
        so RC2's compare_tf (with its non-finite guard) computes the RC2-comparable metric."""
        n, out = len(a["ids"]), []
        for pos in range(max(1, n - last), n):
            if not a["valid"][pos]:
                out.append(None)
                continue
            out.append([float(a["lp"][pos]), int(a["rank"][pos]), int(a["top1"][pos]) if a["top1"][pos] >= 0 else None])
        return {"positions": out, "n": len(out)}


    def tf_request(key, port, ids, band, run, k=None):
        """One teacher-forced request (max_tokens 1, T 0, prompt_logprobs k, ids as ids). k > 1 refused by Merlin's prompt-
        scoring budget (prompt_logprobs.py validate) -> retried with k 1 = RC2's value, recorded. Raw arrays -> tf_raw/*.npz."""
        k = k or NB0["topk"]
        body = {"model": "q27", "prompt": [int(x) for x in ids], "max_tokens": 1, "temperature": 0, "prompt_logprobs": k,
                "return_tokens_as_token_ids": True}
        r, err, sec = _post(port, body)
        note = None
        if err and k > 1 and "prompt-scoring tensor bound" in err:
            note = f"prompt_logprobs {k} refused ({err[:160]}); retried with 1 (RC2's value)"
            k = body["prompt_logprobs"] = 1
            r, err, sec = _post(port, body)
        meta = {"boot": key, "band": band, "run": run, "k": k, "note": note, "sec": sec, "error": err, "prompt_len": len(ids),
                "prompt_sha256": ids_sha(ids), "cached_tokens": _cached(r), "t": round(time.time() - T_START, 1)}
        arr = None
        if r is not None:
            try:
                ch = r["choices"][0]
                pl = ch.get("prompt_logprobs") or []
                meta.update(prompt_logprobs_len=len(pl), gen_token_ids=ch.get("token_ids"), gen_text=ch.get("text"))
                arr = pl_arrays(pl, ids, k)
                vv = arr["valid"]
                meta.update(valid=int(vv.sum()), expected=len(ids) - 1, nonfinite=int((~np.isfinite(arr["lp"][vv])).sum()),
                            top1_ambiguous=arr["top1_ambiguous"])
                f = RAW_DIR / f"{key}_{band}_{run}.npz"
                np.savez_compressed(f, **{x: arr[x] for x in ("ids", "lp", "rank", "top1", "top1_lp", "topk_ids", "topk_lp", "valid")})
                meta["raw"] = f.name
            except Exception as e:
                meta["error"] = meta["error"] or f"PARSE {type(e).__name__}: {e}"[:300]
                arr = None
        _req_log({**meta, "kind": "teacher_forced", "body": {kk: v for kk, v in body.items() if kk != "prompt"}})
        return {"meta": meta, "arr": arr}


    def decode(key, port, ids, n, band, run):
        """Greedy decode (T 0, ignore_eos, logprobs k): tokens, chosen-token logprobs, rank-1 id / logprob, rank-2 logprob."""
        body = {"model": "q27", "prompt": [int(x) for x in ids], "max_tokens": n, "temperature": 0, "logprobs": NB0["topk"],
                "return_tokens_as_token_ids": True, "return_token_ids": True, "ignore_eos": True}
        r, err, sec = _post(port, body, timeout=900)
        meta = {"boot": key, "band": band, "run": run, "sec": sec, "error": err, "prompt_len": len(ids), "prompt_sha256": ids_sha(ids),
                "cached_tokens": _cached(r), "t": round(time.time() - T_START, 1)}
        toks, lps, t1, t1lp, t2lp = [], [], [], [], []
        if r is not None:
            try:
                ch = r["choices"][0]
                lp = ch.get("logprobs") or {}
                toks = ch.get("token_ids") or [L._tok_id(t) for t in (lp.get("tokens") or [])]
                lps = [x if isinstance(x, (int, float)) else float("nan") for x in (lp.get("token_logprobs") or [])]
                for top in lp.get("top_logprobs") or []:
                    it = sorted(((v, L._tok_id(kk)) for kk, v in (top or {}).items() if isinstance(v, (int, float))), reverse=True)
                    t1.append(it[0][1] if it and isinstance(it[0][1], int) else -1)
                    t1lp.append(it[0][0] if it else float("nan"))
                    t2lp.append(it[1][0] if len(it) > 1 else float("nan"))
                meta.update(tokens=len(toks), finish=ch.get("finish_reason"), text=ch.get("text"))
                if any(not isinstance(x, int) or isinstance(x, bool) for x in toks):
                    meta["error"] = "INVALID_TOKEN_IDS"
                elif len(toks) != n or len(lps) != n or len(t1) != n:
                    meta["error"] = f"INCOMPLETE_DECODE tokens {len(toks)} logprobs {len(lps)} top {len(t1)} of {n}"
            except Exception as e:
                meta["error"] = meta["error"] or f"PARSE {type(e).__name__}: {e}"[:300]
        out = {"meta": meta, "tok": [int(x) for x in toks if isinstance(x, int)], "lp": np.asarray(lps, np.float64),
               "top1": np.asarray(t1, np.int64), "top1_lp": np.asarray(t1lp, np.float64), "top2_lp": np.asarray(t2lp, np.float64)}
        if not meta["error"]:
            f = RAW_DIR / f"{key}_dec{band}_{run}.npz"
            np.savez_compressed(f, ids=np.asarray(ids, np.int32), tok=np.asarray(out["tok"], np.int32), lp=out["lp"],
                                top1=out["top1"], top1_lp=out["top1_lp"], top2_lp=out["top2_lp"])
            meta["raw"] = f.name
        _req_log({**meta, "kind": "decode", "body": {kk: v for kk, v in body.items() if kk != "prompt"}})
        return out


    def cmp_last256(ra, rb):
        if not ra or not rb or ra.get("arr") is None or rb.get("arr") is None:
            return {"status": "INCONCLUSIVE_MISSING_TF"}
        if ra["meta"]["prompt_sha256"] != rb["meta"]["prompt_sha256"]:
            return {"status": "INCONCLUSIVE_PROMPT_MISMATCH"}
        return L.compare_tf(e23_rows(ra["arr"], NB0["last"]), e23_rows(rb["arr"], NB0["last"]))


    def chunk_check(pos, d, edge=8):
        """|dlogprob| at the first / last `edge` positions of each 1024-token scheduler chunk (--max-num-batched-tokens) and
        each 256-row prompt-logprob chunk (VLLM_MERLIN_PROMPT_LOGPROBS_CHUNK_SIZE) vs mid-chunk."""
        out = {}
        for unit in (1024, 256):
            off = pos % unit
            e = (off < edge) | (off >= unit - edge)
            if e.any() and (~e).any():
                me, mm = float(d[e].mean()), float(d[~e].mean())
                out[str(unit)] = {"edge_mean": round(me, 4), "mid_mean": round(mm, 4), "edge_n": int(e.sum()),
                                  "localised": bool(me > 3 * mm + 0.05)}
        return out


    def cmp_full(a, b, bins=True):
        """Every prompt position: mean / p99 / max |dlogprob|, rank-1 agreement, 4096-token bins (does it grow with context?),
        the first 256-position window over the screening mean, chunk-edge localisation."""
        if a["ids"].shape != b["ids"].shape or not np.array_equal(a["ids"], b["ids"]):
            return {"status": "INCONCLUSIVE_PROMPT_MISMATCH"}
        va, vb = a["valid"] & np.isfinite(a["lp"]), b["valid"] & np.isfinite(b["lp"])
        if (a["valid"] & ~np.isfinite(a["lp"])).any() or (b["valid"] & ~np.isfinite(b["lp"])).any():
            return {"status": "INCONCLUSIVE_NONFINITE"}
        pos = np.nonzero(va & vb)[0]
        n = len(a["ids"])
        if not len(pos):
            return {"status": "INCONCLUSIVE_NO_VALID"}
        d = np.abs(a["lp"][pos].astype(np.float64) - b["lp"][pos].astype(np.float64))
        t1 = (a["top1"][pos] == b["top1"][pos]) & (a["top1"][pos] >= 0)
        ds = np.sort(d)
        out = {"status": "MEASURED" if len(pos) == n - 1 else "PARTIAL", "n": int(len(pos)), "expected": n - 1,
               "mean_abs_dlogprob": round(float(d.mean()), 4), "p99_abs_dlogprob": round(float(ds[min(len(ds) - 1, int(round(0.99 * (len(ds) - 1))))]), 3),
               "max_abs_dlogprob": round(float(d.max()), 3), "rank1_agreement": round(float(t1.mean()), 4)}
        if bins:
            bl = []
            for lo in range(0, n, 4096):
                m = (pos >= lo) & (pos < lo + 4096)
                if m.any():
                    bl.append([lo, int(m.sum()), round(float(d[m].mean()), 4), round(float(t1[m].mean()), 4)])
            out["bins_4096"] = bl                        # [start, n, mean |dlogprob|, rank-1 agreement]
            if len(d) >= 256:
                cs = np.convolve(d, np.ones(256) / 256, "valid")
                idx = np.nonzero(cs > SCREEN["mean_max"])[0]
                out["first_window_over_screen_mean"] = int(pos[idx[0]]) if len(idx) else None
            out["chunk"] = chunk_check(pos, d)
        return out


    def shift_check(a, b, window=2048, shifts=(-2, -1, 0, 1, 2)):
        """Alignment test on the last `window` positions: reference rank-1 id at p vs candidate rank-1 id at p + s. A shifted
        agreement >= 0.9 that beats s = 0 by > 0.2 = a position-alignment artefact."""
        n = min(len(a["top1"]), len(b["top1"]))
        i0 = np.arange(max(1, n - window), n)
        res = {}
        for s in shifts:
            j = i0 + s
            m = (j >= 1) & (j < n)
            i, j = i0[m], j[m]
            v = a["valid"][i] & b["valid"][j] & (a["top1"][i] >= 0) & (b["top1"][j] >= 0)
            if not v.any():
                res[str(s)] = None
                continue
            dl = np.abs(a["top1_lp"][i][v].astype(np.float64) - b["top1_lp"][j][v].astype(np.float64))
            res[str(s)] = {"n": int(v.sum()), "top1_agree": round(float((a["top1"][i][v] == b["top1"][j][v]).mean()), 4),
                           "top1_lp_mean_abs_d": round(float(np.nanmean(dl)), 4) if np.isfinite(dl).any() else None}
        ok = {k: x for k, x in res.items() if x}
        best = max(ok, key=lambda k: (ok[k]["top1_agree"], k == "0")) if ok else None
        a0 = (ok.get("0") or {}).get("top1_agree")
        art = bool(best and best != "0" and ok[best]["top1_agree"] >= 0.9 and (a0 is None or ok[best]["top1_agree"] > a0 + 0.2))
        return {"shifts": res, "best_shift": int(best) if best is not None else None, "alignment_artefact": art}


    def screen(c):
        if not isinstance(c, dict) or c.get("status") != "MEASURED":
            return "INCONCLUSIVE"
        m, r1 = c.get("mean_abs_dlogprob"), c.get("rank1_agreement")
        if not (_finite(m) and _finite(r1)):
            return "INCONCLUSIVE_NONFINITE"
        return "DIVERGENT" if (r1 < SCREEN["rank1_min"] or m > SCREEN["mean_max"]) else "CLEAN"


    def decode_compare(ref, cand):
        """Greedy rows token for token: first divergence, the reference's top-1 - top-2 margin there (E23's 0.5 rule:
        FAIL_HIGH_MARGIN at or above, NEAR_TIE below), mean |dlogprob| over the common prefix."""
        if not ref or not cand or ref["meta"].get("error") or cand["meta"].get("error") or not ref["tok"] or not cand["tok"]:
            return {"status": "INCONCLUSIVE_MISSING"}
        x, y = ref["tok"], cand["tok"]
        d = next((i for i in range(min(len(x), len(y))) if x[i] != y[i]), None)
        c = len(x) if d is None else d
        dl = np.abs(ref["lp"][:c] - cand["lp"][:c]) if c else np.zeros(0)
        if not np.isfinite(dl).all() or (d is not None and not math.isfinite(float(ref["top1_lp"][d] - ref["top2_lp"][d]))):
            return {"status": "INCONCLUSIVE_NONFINITE", "first_diff": d}
        out = {"n": len(x), "first_diff": d, "common_prefix_mean_abs_dlogprob": round(float(dl.mean()), 4) if c else None,
               "common_prefix_max_abs_dlogprob": round(float(dl.max()), 4) if c else None}
        if d is None:
            out["status"] = "EXACT" if len(x) == len(y) else "INCONCLUSIVE_LENGTH"
        else:
            m = float(ref["top1_lp"][d] - ref["top2_lp"][d])
            out.update(ref_margin_at_diff=round(m, 4), status="FAIL_HIGH_MARGIN" if m >= L.FAIL_MARGIN else "NEAR_TIE")
        return out


    def sc_compare(dec, tf, P):
        """Decode-vs-prompt-logprob self-consistency on ONE boot: the greedy decode's chosen-token logprob at step i vs the
        teacher-forced logprob of the same token at position P + i (prompt + those tokens), rank-1 ids, +-2 shift."""
        if not dec or dec["meta"].get("error") or not tf or tf.get("arr") is None:
            return {"status": "INCONCLUSIVE_MISSING"}
        a, n = tf["arr"], len(dec["tok"])
        if n == 0:                                             # A-4: nothing decoded, nothing to compare (no IndexError)
            return {"status": "INCONCLUSIVE_EMPTY_DECODE"}
        pos = np.arange(P, P + n)
        if pos[-1] >= len(a["ids"]):                           # the TF prompt does not cover every decoded position
            return {"status": "INCONCLUSIVE_TF_TOO_SHORT", "need_len": int(P + n), "tf_len": int(len(a["ids"]))}
        if not np.array_equal(a["ids"][pos], np.asarray(dec["tok"], np.int32)):
            return {"status": "INCONCLUSIVE_PROMPT_MISMATCH"}
        dl, tl, v = dec["lp"], a["lp"][pos].astype(np.float64), a["valid"][pos]
        if not np.isfinite(dl).all() or not np.isfinite(tl[v]).all():
            return {"status": "INCONCLUSIVE_NONFINITE"}
        if not v.all():
            return {"status": "INCONCLUSIVE_INCOMPLETE_TF", "valid": int(v.sum()), "expected": n}
        d = np.sort(np.abs(dl - tl))
        r1 = float((dec["top1"] == a["top1"][pos]).mean())
        sh = {}
        for s in (-2, -1, 0, 1, 2):
            j = pos + s
            m = (j >= 1) & (j < len(a["ids"]))
            if m.any():
                sh[str(s)] = round(float((dec["top1"][m] == a["top1"][j[m]]).mean()), 4)
        out = {"status": "MEASURED", "n": n, "mean_abs_dlogprob": round(float(d.mean()), 4),
               "p99_abs_dlogprob": round(float(d[min(n - 1, int(round(0.99 * (n - 1))))]), 3), "max_abs_dlogprob": round(float(d[-1]), 3),
               "rank1_agreement": round(r1, 4), "greedy_self_top1": round(float((np.asarray(dec["tok"]) == dec["top1"]).mean()), 4),
               "shift_top1_agree": sh}
        out["screen"] = screen(out)
        return out


    TF_EST = {"2k": 15, "8k": 25, "40k": 60, "90k": 150}


    SC_EST = {"2k": 40, "8k": 60, "40k": 120}


    def tf_suite(key, s, bands):
        out = {}
        for band in bands:
            ids = PROMPTS[band][NB0["tf_variant"]]
            rec = TFR.setdefault(key, {}).setdefault(band, {})
            o = {"prompt_len": len(ids), "prompt_sha256": ids_sha(ids), "variant": NB0["tf_variant"]}
            if band == "90k" and f"{key}_90k" in DROP:
                o["status"] = "SKIPPED_BUDGET_PRIORITY"
                o["why"] = "lead rule: under budget pressure the MTP-off BF16 boot's 90k band is dropped first"
                out[band] = o
                continue
            for run in ("fresh", "repeat"):
                if not s.alive():
                    o[run] = {"status": "SKIPPED_SERVER_DEAD"}
                elif key in WD or ABORT["why"] or left() < TF_EST[band] + 240:
                    o[run] = {"status": "SKIPPED_BUDGET"}
                else:
                    rec[run] = tf_request(key, s.port, ids, band, run)
                    o[run] = rec[run]["meta"]
            o["aa"] = cmp_last256(rec.get("fresh"), rec.get("repeat"))
            out[band] = o
            save()
        return out


    def sc_suite(key, s):
        out = {}
        for band in NB0["sc_bands"]:
            ids = PROMPTS[band][NB0["sc_variant"][band]]
            if not s.alive():
                out[band] = {"status": "SKIPPED_SERVER_DEAD"}
                continue
            if key in WD or ABORT["why"] or left() < SC_EST[band] + 240:
                out[band] = {"status": "SKIPPED_BUDGET"}
                continue
            cold = decode(key, s.port, ids, NB0["sc_tok"], band, "cold")
            cached = decode(key, s.port, ids, NB0["sc_tok"], band, "cached")
            tf = tf_request(key, s.port, list(ids) + list(cold["tok"]), "sc" + band, "tf") if not cold["meta"].get("error") else None
            SCR.setdefault(key, {})[band] = {"cold": cold, "cached": cached, "tf": tf, "P": len(ids)}
            out[band] = {"cold": cold["meta"], "cached": cached["meta"], "tf": (tf or {}).get("meta"),
                         "decode_vs_tf": sc_compare(cold, tf, len(ids)), "cold_vs_cached": decode_compare(cold, cached),
                         "cold_was_cold": cold["meta"].get("cached_tokens") in (0, None)}
            save()
        return out


    def psha(ids):
        return hashlib.sha256(json.dumps(list(ids)).encode()).hexdigest()


    P60490 = "# vLLM PR #60490 (issue #60489) rebased onto Merlin v3.0.0 (commit ad42e37feb7611c4ffd24017bf20a7e2dc94c6e5,\n# tree 07c16a79d077f1e06c19d0eea84efd64f0b63540 = the tree the Kaggle payload installs, install_merlin.log).\n# Same code as upstream; only the import context differs (Merlin's import block). One marker comment added.\n# pre-patch sha256  a23d5f90507ad5185f8b8e8d6ba13ae0cb53b2506264fdfbbf6a60b1171dc653\n# post-patch sha256 88fe0a8f4dd2ef90fc6aefb5771b5b48e40c0b1d575039283c52aeca19b8bd6b\n--- a/vllm/models/qwen4_exp/nvidia/qsa.py\n+++ b/vllm/models/qwen4_exp/nvidia/qsa.py\n@@ -18,8 +18,9 @@\n from torch import nn\n from transformers import Qwen4ExpTextConfig\n \n+import vllm.envs as envs\n from vllm.compilation.breakable_cudagraph import eager_break_during_capture\n-from vllm.config import VllmConfig\n+from vllm.config import VllmConfig, get_current_vllm_config_or_none\n from vllm.config.cache import CacheConfig, CacheDType\n from vllm.distributed import get_tensor_model_parallel_world_size\n from vllm.forward_context import get_forward_context\n@@ -45,6 +46,7 @@\n )\n from vllm.platforms import current_platform\n from vllm.platforms.interface import DeviceCapability\n+from vllm.utils.math_utils import cdiv\n from vllm.utils.torch_utils import (\n     LayerNameType,\n     _encode_layer_name,\n@@ -75,6 +77,7 @@\n from . import model\n from .indexer_qsa import QSAIndexer\n from .ops.qsa import qsa_e4m3_uses_native_cast\n+from .ops.qsa_indexer import _TOPK_WORKSPACE_BYTES\n \n logger = init_logger(__name__)\n \n@@ -782,6 +785,31 @@\n         if isinstance(metadata, list):\n             metadata = metadata[0]\n         if not isinstance(metadata, dict):\n+            # E25 NB1: backport of vLLM PR #60490 (issue #60489).\n+            # Profiling/dummy run: the indexer allocates its selection scratch\n+            # on demand, so touch its peak here for the memory profiler (as\n+            # sparse_attn_indexer does): the prefill logits budget or the\n+            # worst-case decode logits [decode tokens, compressed columns],\n+            # plus the top-k workspace.\n+            logits_bytes = envs.VLLM_SPARSE_INDEXER_MAX_LOGITS_MB * 1024 * 1024\n+            cfg = get_current_vllm_config_or_none()\n+            if cfg is not None:\n+                spec = cfg.speculative_config\n+                num_spec = spec.num_speculative_tokens if spec is not None else 0\n+                decode_tokens = min(\n+                    cfg.scheduler_config.max_num_seqs * (num_spec + 1),\n+                    cfg.scheduler_config.max_num_batched_tokens,\n+                )\n+                block_size = cfg.cache_config.block_size\n+                columns = cdiv(cfg.model_config.max_model_len, block_size) * cdiv(\n+                    block_size, self.indexer.compress_ratio\n+                )\n+                logits_bytes = max(logits_bytes, decode_tokens * columns * 4)\n+            _ = torch.empty(\n+                logits_bytes + _TOPK_WORKSPACE_BYTES,\n+                dtype=torch.uint8,\n+                device=output.device,\n+            )\n             output.zero_()\n             return\n         main_metadata = cast(FlashAttentionMetadata, metadata[self.layer_name])\n"


    P60490_REL = "vllm/models/qwen4_exp/nvidia/qsa.py"


    P60490_PRE, P60490_POST = "a23d5f90507ad5185f8b8e8d6ba13ae0cb53b2506264fdfbbf6a60b1171dc653", "88fe0a8f4dd2ef90fc6aefb5771b5b48e40c0b1d575039283c52aeca19b8bd6b"


    P60490_MARKER = "# E25 NB1: backport of vLLM PR #60490 (issue #60489)."


    NB1_EXT_SRC = "\"\"\"E25 NB1 worker extension (read-only): reached through POST /collective_rpc {\"method\": \"nb1_cache_info\"} with\nVLLM_SERVER_DEV_MODE=1 and --worker-extension-cls nb1_worker_ext.NB1WorkerExt. Reports the ACTUAL cache tensors bound\nto every attention / Mamba layer (dtype, shape, bytes), the KV cache specs (padded vs unpadded Mamba page bytes), the\nphysical block count and this rank's free memory. It never raises: every part returns its error text instead.\"\"\"\nimport json\nimport math\n\n\ndef _t(x):\n    try:\n        import torch\n        if isinstance(x, torch.Tensor):\n            return {\"dtype\": str(x.dtype).replace(\"torch.\", \"\"), \"shape\": list(x.shape), \"bytes\": int(x.numel() * x.element_size())}\n    except Exception:\n        pass\n    return None\n\n\ndef _flat(kc):\n    if _t(kc):\n        return [kc]\n    if isinstance(kc, (list, tuple)):\n        if kc and isinstance(kc[0], (list, tuple)) and not _t(kc[0]):\n            kc = kc[0]                              # one entry per virtual engine\n        return [x for x in kc if _t(x)]\n    return []\n\n\n_RT = {\"on\": False, \"installed\": False, \"rows\": [], \"passes\": 0, \"calls\": 0, \"max_steps\": 200, \"bytes\": 0, \"errors\": [],\n       \"first\": None, \"skipped_capturing\": 0, \"skipped_prefill\": 0}\n_RT_MAX_BYTES = 16 << 20\n_RT_DECODE_MAX_ROWS = 128          # a decode / verify micro-batch: requests x (1 + K) tokens; prefill chunks are larger\n\n\ndef _rt_layer(name):\n    import re as _r\n    m = _r.search(r\"layers\\.(\\d+)\", str(name))\n    return int(m.group(1)) if m else -1\n\n\ndef _rt_wrap(orig):\n    def select_experts(self, hidden_states, router_logits, *a, **k):\n        out = orig(self, hidden_states, router_logits, *a, **k)\n        if _RT[\"on\"] and _RT[\"passes\"] < 2 * _RT[\"max_steps\"] and _RT[\"bytes\"] < _RT_MAX_BYTES:\n            try:\n                import torch\n                if torch.cuda.is_current_stream_capturing():\n                    _RT[\"skipped_capturing\"] += 1\n                else:\n                    ids = out[1]\n                    lay = _rt_layer(getattr(self, \"nb1_layer\", None))\n                    if _RT[\"first\"] is None:\n                        _RT[\"first\"] = lay\n                    n = int(ids.shape[0])\n                    if n > _RT_DECODE_MAX_ROWS:\n                        _RT[\"skipped_prefill\"] += 1\n                    else:\n                        if lay == _RT[\"first\"]:\n                            _RT[\"passes\"] += 1     # one pass of a micro-batch through this stage's first MoE layer\n                        keep = ids.to(torch.int16).cpu().numpy().reshape(n, -1)\n                        _RT[\"rows\"].append((lay, max(0, _RT[\"passes\"] - 1), n, keep))\n                        _RT[\"bytes\"] += keep.nbytes\n                        _RT[\"calls\"] += 1\n            except Exception as e:\n                if len(_RT[\"errors\"]) < 5:\n                    _RT[\"errors\"].append(repr(e)[:160])\n        return out\n    return select_experts\n\n\nclass NB1WorkerExt:\n    def nb1_routing(self, action, arg=\"\"):\n        \"\"\"Router top-k expert ids, ONLY between 'start' and 'stop' (the profiling window): FusedMoERouter.select_experts is\n        wrapped once at class level; every decode / verify-sized call (<= 128 token rows) that runs in Python (not during\n        a CUDA-graph capture) keeps its ids (int16) with the layer index and the pass index (counted at this stage's first\n        MoE layer; NB1 maps pass -> step = pass // 2, mb_index = pass % 2 under PP2); <= max_steps steps, <= 16 MiB per\n        rank. FULL-graph replays run no Python, so graph-replayed decode steps are NOT recorded (vLLM's\n        --enable-return-routed-experts writes the ids from inside the graph; it changes the forward graph and memory, so it\n        is not used on a measured boot). 'stop' writes the rank's part file <arg>_rank<r>.npz.\"\"\"\n        out = {\"action\": action}\n        try:\n            import torch.distributed as dist\n            rank = dist.get_rank() if dist.is_initialized() else 0\n            out[\"rank\"] = rank\n            if action == \"start\":\n                from vllm.model_executor.layers.fused_moe.router.fused_moe_router import FusedMoERouter\n                if not _RT[\"installed\"]:\n                    FusedMoERouter.select_experts = _rt_wrap(FusedMoERouter.select_experts)\n                    _RT[\"installed\"] = True\n                    model = getattr(getattr(self, \"model_runner\", None), \"model\", None)\n                    named = 0\n                    if model is not None:\n                        for name, mod in model.named_modules():\n                            for attr in (\"router\", \"_router\"):\n                                r = getattr(mod, attr, None)\n                                if isinstance(r, FusedMoERouter):\n                                    r.nb1_layer = name\n                                    named += 1\n                    out[\"routers_named\"] = named\n                _RT.update(on=True, rows=[], passes=0, calls=0, bytes=0, errors=[], first=None, skipped_capturing=0,\n                           skipped_prefill=0, max_steps=int(arg or 200))\n                return out\n            _RT[\"on\"] = False\n            out.update(passes=_RT[\"passes\"], calls=_RT[\"calls\"], bytes=_RT[\"bytes\"], errors=_RT[\"errors\"],\n                       skipped_capturing=_RT[\"skipped_capturing\"], skipped_prefill=_RT[\"skipped_prefill\"])\n            if action == \"stop\" and arg and _RT[\"rows\"]:\n                import numpy as np\n                rows = _RT[\"rows\"]\n                offs, o_ = [], 0\n                for r in rows:\n                    offs.append(o_)\n                    o_ += r[2]\n                path = f\"{arg}_rank{rank}.npz\"\n                np.savez_compressed(path, ids=np.concatenate([r[3] for r in rows], axis=0), layer=np.array([r[0] for r in rows]),\n                                    pass_index=np.array([r[1] for r in rows]), mb_size=np.array([r[2] for r in rows]),\n                                    offset=np.array(offs), rank=np.array([rank]))\n                out[\"path\"] = path\n            _RT[\"rows\"] = []\n        except Exception as e:\n            out[\"error\"] = repr(e)[:300]\n        return out\n\n    def nb1_cache_info(self):\n        out = {}\n        try:\n            import torch.distributed as dist\n            out[\"rank\"] = dist.get_rank() if dist.is_initialized() else None\n        except Exception as e:\n            out[\"rank_error\"] = repr(e)[:120]\n        try:\n            ctx = self.vllm_config.compilation_config.static_forward_context\n            sig = {}\n            for name, mod in ctx.items():\n                ts = [_t(x) for x in _flat(getattr(mod, \"kv_cache\", None))]\n                if not ts:\n                    continue\n                key = type(mod).__name__ + \"|\" + json.dumps([(x[\"dtype\"], x[\"shape\"]) for x in ts])\n                g = sig.setdefault(key, {\"module\": type(mod).__name__, \"tensors\": ts, \"layers\": 0, \"example\": name})\n                g[\"layers\"] += 1\n            out[\"cache_tensors\"] = list(sig.values())[:40]\n        except Exception as e:\n            out[\"cache_tensors_error\"] = repr(e)[:300]\n        try:\n            agg = {}\n            for name, sp in self.get_kv_cache_spec().items():\n                d = {\"type\": type(sp).__name__}\n                for k in (\"block_size\", \"page_size_bytes\", \"page_size_padded\", \"dtype\", \"num_kv_heads\", \"head_size\", \"mamba_type\"):\n                    try:\n                        v = getattr(sp, k, None)\n                        d[k] = v if isinstance(v, (int, float, str, bool, type(None))) else str(v)\n                    except Exception as e:\n                        d[k] = \"ERR \" + repr(e)[:60]\n                shapes, dtypes = getattr(sp, \"shapes\", None), getattr(sp, \"dtypes\", None)\n                if shapes and dtypes:\n                    try:\n                        d[\"state_dtypes\"] = [str(x).replace(\"torch.\", \"\") for x in dtypes]\n                        d[\"state_shapes\"] = [list(s) for s in shapes]\n                        d[\"unpadded_page_bytes\"] = int(sum(math.prod(s) * x.itemsize for s, x in zip(shapes, dtypes)))\n                    except Exception as e:\n                        d[\"unpadded_error\"] = repr(e)[:80]\n                key = json.dumps(d, sort_keys=True, default=str)\n                a = agg.setdefault(key, dict(d, layers=0, example=name))\n                a[\"layers\"] += 1\n            out[\"kv_cache_specs\"] = list(agg.values())[:40]\n        except Exception as e:\n            out[\"kv_cache_specs_error\"] = repr(e)[:300]\n        try:\n            out[\"num_gpu_blocks\"] = getattr(self.cache_config, \"num_gpu_blocks\", None)\n            out[\"mamba_page_size_padded\"] = getattr(self.cache_config, \"mamba_page_size_padded\", None)\n            out[\"mamba_ssm_cache_dtype\"] = str(getattr(self.cache_config, \"mamba_ssm_cache_dtype\", None))\n            out[\"cache_block_size\"] = getattr(self.cache_config, \"block_size\", None)\n        except Exception as e:\n            out[\"cache_config_error\"] = repr(e)[:200]\n        try:\n            for obj in (getattr(self, \"model_runner\", None), self):\n                cfg = getattr(obj, \"kv_cache_config\", None)\n                if cfg is not None:\n                    out[\"kv_cache_config\"] = {\n                        \"num_blocks\": getattr(cfg, \"num_blocks\", None),\n                        \"groups\": [{\"spec\": type(g.kv_cache_spec).__name__, \"layers\": len(g.layer_names),\n                                    \"block_size\": getattr(g.kv_cache_spec, \"block_size\", None),\n                                    \"page_size_bytes\": getattr(g.kv_cache_spec, \"page_size_bytes\", None)}\n                                   for g in getattr(cfg, \"kv_cache_groups\", [])][:16],\n                        \"tensors\": [{\"size\": getattr(t, \"size\", None), \"shared_by\": len(getattr(t, \"shared_by\", None) or [])}\n                                    for t in getattr(cfg, \"kv_cache_tensors\", [])][:24]}\n                    break\n        except Exception as e:\n            out[\"kv_cache_config_error\"] = repr(e)[:300]\n        try:\n            import torch\n            fr, tot = torch.cuda.mem_get_info()\n            out[\"mem\"] = {\"free_mib\": fr >> 20, \"total_mib\": tot >> 20, \"allocated_mib\": torch.cuda.memory_allocated() >> 20,\n                          \"reserved_mib\": torch.cuda.memory_reserved() >> 20, \"max_allocated_mib\": torch.cuda.max_memory_allocated() >> 20}\n        except Exception as e:\n            out[\"mem_error\"] = repr(e)[:200]\n        return out\n"


    def apply_unified(text, patch):
        """Strict unified-diff applier (no fuzz, no offset): every context / removed line must match at its stated line,
        else ValueError. Lines before the first hunk (comments, ---/+++ headers) are ignored."""
        src = text.splitlines(True)
        hunks, cur = [], None
        for ln in patch.splitlines(True):
            if ln.startswith("@@"):
                m = re.match(r"@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@", ln)
                if not m:
                    raise ValueError("bad hunk header: " + ln[:80])
                cur = [int(m.group(1)), int(m.group(2) or 1), []]
                hunks.append(cur)
            elif cur is not None and ln[:1] in (" ", "-", "+"):
                cur[2].append(ln)
            elif cur is not None and ln.startswith("\\"):
                raise ValueError("'No newline at end of file' hunks are not supported")
        if not hunks:
            raise ValueError("patch has no hunks")
        out, pos = [], 0
        for start, n_old, body in hunks:
            i = start - 1
            if i < pos:
                raise ValueError(f"overlapping hunk at line {start}")
            out += src[pos:i]
            old_seen = 0
            for ln in body:
                tag, s = ln[0], ln[1:]
                if tag in " -":
                    if i >= len(src) or src[i] != s:
                        raise ValueError(f"context mismatch at line {i + 1}: {s[:60]!r}")
                    i += 1
                    old_seen += 1
                if tag in " +":
                    out.append(s)
            if old_seen != n_old:
                raise ValueError(f"hunk at line {start}: {old_seen} old lines, header says {n_old}")
            pos = i
        return "".join(out + src[pos:])


    def apply_60490():
        """After merlin_install, before B1: patch the installed tree's qsa.py (pre-sha must be Merlin ad42e37's), verify the
        post-sha, the marker, a py_compile with the Merlin venv and that `vllm` resolves to the tree; write the read-only
        worker extension next to the tree's vllm/ (on the server's PYTHONPATH). Any miss raises: no boot is started."""
        if FAKE:
            tree = os.environ.get("NB1_FAKE_TREE")
            if not tree:
                raise RuntimeError("PATCH_60490_NO_TREE: NB1_FAKE_TREE is not set (local harness)")
            tree, py = Path(tree), sys.executable
        else:
            eng = merlin_install()
            tree, py = Path(eng["kv"]["MERLIN_TREE"]), eng["kv"]["MERLIN_VENV"] + "/bin/python"
        f = tree / P60490_REL
        raw = f.read_bytes()
        h0 = hashlib.sha256(raw).hexdigest()
        rec = {"file": str(f), "sha_before": h0, "pre_expected": P60490_PRE, "post_expected": P60490_POST}
        if h0 == P60490_POST:
            rec["applied"] = "already_applied"
        elif h0 != P60490_PRE:
            raise RuntimeError(f"PATCH_60490_PRE_SHA_MISMATCH: {h0} (expected Merlin ad42e37 {P60490_PRE})")
        else:
            new = apply_unified(raw.decode("utf-8"), P60490).encode("utf-8")
            if hashlib.sha256(new).hexdigest() != P60490_POST:
                raise RuntimeError("PATCH_60490_POST_SHA_MISMATCH: " + hashlib.sha256(new).hexdigest())
            tmp = f.with_name(f.name + ".nb1tmp")
            tmp.write_bytes(new)
            os.replace(tmp, f)
            rec["applied"] = "applied"
        for pyc in (f.parent / "__pycache__").glob("qsa.*.pyc"):
            pyc.unlink()
        data = f.read_bytes()
        rec.update(sha_after=hashlib.sha256(data).hexdigest(), marker=P60490_MARKER.encode() in data)
        ext = tree / "nb1_worker_ext.py"
        ext.write_text(NB1_EXT_SRC)
        rec["worker_ext"] = {"file": str(ext), "sha256": hashlib.sha256(ext.read_bytes()).hexdigest()}
        cp = subprocess.run([py, "-c", "import py_compile, sys\nfor f in sys.argv[1:]: py_compile.compile(f, doraise=True)", str(f), str(ext)],
                            capture_output=True, text=True, timeout=300)
        rec["py_compile"] = {"rc": cp.returncode, "err": cp.stderr[-400:]}
        origin_ok = True
        if not FAKE:
            envp = {k: v for k, v in os.environ.items() if k != "PYTHONPATH"}
            envp["PYTHONPATH"] = str(tree)            # what Merlin's build() exports for the server
            cp2 = subprocess.run([py, "-c", "import importlib.util as u; print(u.find_spec('vllm').origin); print(u.find_spec('nb1_worker_ext').origin)"],
                                 capture_output=True, text=True, timeout=300, env=envp)
            rec["vllm_origin"] = cp2.stdout.strip()[-400:]
            origin_ok = all(l.startswith(str(tree)) for l in cp2.stdout.strip().splitlines()[-2:]) and len(cp2.stdout.strip().splitlines()) >= 2
        if rec["sha_after"] != P60490_POST or not rec["marker"] or cp.returncode or not origin_ok:
            raise RuntimeError("PATCH_60490_VERIFY_FAILED: " + json.dumps({k: rec.get(k) for k in ("sha_after", "marker", "py_compile", "vllm_origin")})[:600])
        rec["ok"] = True
        rec["forward_test"] = "B1's greedy oracle vs RC2's recorded FP8 rows (unpatched RC2 FP8; B1 adds text-only): B1 oracle.vs_rc2_fp8"
        return rec


    def cgroup_snapshot(tag):
        """memory.current / stat / events / pressure (first 12 kB each) to hostmem/<tag>.txt; key numbers returned."""
        rec, txt = {"tag": tag}, []
        for n in ("memory.current", "memory.stat", "memory.events", "memory.pressure"):
            try:
                s = (Path("/sys/fs/cgroup") / n).read_text()[:12000]
            except Exception:
                continue
            txt.append(f"--- {n} ---\n{s}")
            if n == "memory.current":
                rec["current_mib"] = int(s.strip()) >> 20
            elif n == "memory.events":
                rec["events"] = {a: int(b) for a, b in (l.split() for l in s.splitlines() if len(l.split()) == 2)}
            elif n == "memory.pressure":
                rec["pressure"] = s.strip().splitlines()[:2]
        try:
            (HOSTMEM / f"{tag}.txt").write_text("\n".join(txt))
        except Exception:
            pass
        rec["host_mem"] = host_mem()
        return rec


    ENGINE_RX = re.compile(r"vllm|PleOffload|ple_offload|EngineCore|merlin_off/venv", re.I)


    def engine_procs():
        """Processes of an engine (vLLM server, workers, PLE offload) other than this notebook; None off Linux."""
        if not Path("/proc/self/stat").exists():
            return None
        me, out = os.getpid(), []
        for d in Path("/proc").glob("[0-9]*"):
            try:
                pid = int(d.name)
                if pid == me:
                    continue
                cmd = (d / "cmdline").read_bytes().replace(b"\0", b" ").decode(errors="replace")
                if ENGINE_RX.search(cmd) and "py_compile" not in cmd:
                    out.append([pid, cmd[:160]])
            except Exception:
                pass
        return out


    def clear_engine_procs():
        left0 = engine_procs()
        rec = {"found": left0}
        if left0:
            for pid, _ in left0:
                try:
                    os.kill(pid, 9)
                except Exception:
                    pass
            time.sleep(10)
            rec["after_kill"] = engine_procs()
        rec["ok"] = not (rec.get("after_kill") if left0 else left0)
        return rec


    def drop_page_cache():
        """posix_fadvise(DONTNEED) on every checkpoint file (merged dir symlinks resolved + the Model mounts); only after the
        previous server is dead (never on the pinned PLE pages of a live server). A measured attempt, not an assumed fix."""
        if not hasattr(os, "posix_fadvise"):
            return {"available": False}
        t, seen, n, b, err = time.time(), set(), 0, 0, 0
        roots = [CKPT] + [v[0] for v in PARTS.values() if v] + ([PLE_DIR] if PLE_DIR else [])
        for root in roots:
            for dp, _, fns in os.walk(str(root)):
                for x in fns:
                    p = os.path.realpath(os.path.join(dp, x))
                    if p in seen:
                        continue
                    seen.add(p)
                    try:
                        fd = os.open(p, os.O_RDONLY)
                        try:
                            os.posix_fadvise(fd, 0, 0, os.POSIX_FADV_DONTNEED)
                            b += os.fstat(fd).st_size
                            n += 1
                        finally:
                            os.close(fd)
                    except OSError:
                        err += 1
        return {"available": True, "files": n, "gib": round(b / 2 ** 30, 1), "errors": err, "sec": round(time.time() - t, 1)}


    def host_ram_gate(tag):
        before = cgroup_snapshot(tag + "_before_drop")
        drops, tries = [drop_page_cache()], 0
        after = host_mem()
        while True:
            av = after.get("avail_mib", after.get("MemAvailable_mib"))
            if av is None:
                ok = bool(FAKE)               # local harness only; on Kaggle an unreadable host is never "enough"
                why = "no cgroup / meminfo reading" + (" (local harness: skipped)" if FAKE else ": HOST_RAM_GATE fails closed")
                break
            if av >= RAM_NEED_MIB:
                ok, why = True, f"avail {av} MiB >= {RAM_NEED_MIB}"
                break
            if FAKE:                          # local / CPU-kit harness only (a 30 GiB CPU box): recorded, never enforced
                ok, why = True, f"avail {av} MiB < {RAM_NEED_MIB} MiB (local harness: recorded, not enforced)"
                break
            tries += 1
            if tries > 3:
                ok, why = False, f"HOST_RAM_GATE: avail {av} MiB < {RAM_NEED_MIB} MiB after {tries} page-cache drops"
                break
            time.sleep(20)
            drops.append(drop_page_cache())
            after = host_mem()
        return {"ok": ok, "why": why, "need_mib": RAM_NEED_MIB, "before": before, "after_drop": cgroup_snapshot(tag + "_after_drop"),
                "drops": drops}


    _boot_gate_rc2, _shm_cleanup_rc2 = boot_gate, shm_cleanup


    BOOT = {"deadline": None, "fired": None, "tag": "boot"}


    def boot_gate():
        """RC2's GPU release gate (< 150 MiB per card), the previous engine's processes gone, then the host-RAM gate."""
        g = _boot_gate_rc2()
        if g.get("ok") is not True:
            return g
        g["engine_procs"] = clear_engine_procs()
        if not g["engine_procs"]["ok"]:
            g["ok"], g["why"] = False, "ENGINE_PROCS_LEFT: " + json.dumps(g["engine_procs"].get("after_kill"))[:300]
            return g
        h = host_ram_gate(BOOT["tag"])
        g["host_ram"] = h
        if not h["ok"]:
            g["ok"], g["why"] = False, h["why"]
        return g


    def shm_cleanup(before):
        """RC2's /dev/shm cleanup (this boot's torch_/psm_/vllm/ple/nccl/sem.mp-/cuda.shm entries) + the loky semaphores the
        RC2 log reported leaked at shutdown (sem.loky-*), only when created during this boot."""
        out = _shm_cleanup_rc2(before)
        out["removed_loky"] = []
        try:
            for p in sorted(SHM.iterdir()):
                if p.name not in before and re.match(r"sem\.loky-", p.name):
                    try:
                        p.unlink()
                        out["removed_loky"].append(p.name)
                    except Exception:
                        pass
        except Exception:
            pass
        return out


    def boot_left():
        d = BOOT["deadline"]
        return min(left(), (d - time.time()) if d else float("inf"))


    def due(sec):
        return boot_left() > sec and not ABORT["why"]


    def watched(body, cap_sec, name):
        """The boot body gets `cap_sec`; every step checks due(); at cap + 300 s the server is killed (hard backstop)."""
        def b(ss):
            BOOT.update(deadline=time.time() + cap_sec, fired=None)

            def fire():
                BOOT["fired"] = name
                for x in ss:
                    try:
                        x.kill()
                    except Exception:
                        pass
            tm = threading.Timer(cap_sec + 300, fire)
            tm.daemon = True
            tm.start()
            try:
                o = body(ss)
                LIVE["out"] = o if isinstance(o, dict) else None   # R2: step() keeps it if anything after the body raises
            finally:
                tm.cancel()
                BOOT["deadline"] = None
            if BOOT["fired"]:
                o["boot_watchdog"] = f"FIRED after {cap_sec + 300:.0f} s: server killed"
            return o
        return b


    def _pick(t, rx, n=6):
        return [l.strip()[:300] for l in t.splitlines() if re.search(rx, l)][:n]


    def server_caps(t, argv=()):
        na = next((l for l in t.splitlines() if "non-default args:" in l), "")
        caps = {"source": "log" if na else "argv"}
        for k in ("max_num_seqs", "max_num_batched_tokens", "block_size", "max_model_len", "kv_cache_memory_bytes", "num_speculative_tokens"):
            m = re.search(rf"'{k}': (\d+)", na)
            caps[k] = int(m.group(1)) if m else None
        for k in ("kv_cache_dtype", "mamba_ssm_cache_dtype", "mamba_cache_mode", "worker_extension_cls"):
            m = re.search(rf"'{k}': '([^']+)'", na)
            caps[k] = m.group(1) if m else None
        m = re.search(r"'language_model_only': (True|False)", na)
        caps["language_model_only"] = m.group(1) == "True" if m else False
        m = re.search(r"'cudagraph_capture_sizes': \[([\d, ]+)\]", na)
        caps["capture_sizes"] = [int(x) for x in m.group(1).split(",")] if m else None
        m = re.findall(r"Setting attention block size to (\d+) tokens", t)
        if m:
            caps["block_size"] = int(m[-1])
        if not na:                                     # fallback (the E23 fake has no args line): the argv, last wins
            a = [str(x) for x in argv]
            for flag, key in (("--max-num-seqs", "max_num_seqs"), ("--block-size", "block_size")):
                idx = [i for i, x in enumerate(a) if x == flag]
                if idx and idx[-1] + 1 < len(a):
                    caps[key] = int(a[idx[-1] + 1])
        caps["block_size"] = caps.get("block_size") or BLOCK
        sizes = caps.get("capture_sizes") or []
        k = caps.get("num_speculative_tokens") or 3
        caps["captures_cover_seqs_x_1pk"] = bool(sizes) and caps.get("max_num_seqs") is not None and max(sizes) >= caps["max_num_seqs"] * (1 + k)
        return caps


    def pool_facts(t):
        f = {}
        m = re.findall(r"GPU KV cache size: ([\d,]+) tokens", t)
        f["kv_tokens"] = int(m[-1].replace(",", "")) if m else None
        m = re.findall(r"Maximum concurrency for ([\d,]+) tokens per request: ([\d.]+)x", t)
        f["max_concurrency"] = float(m[-1][1]) if m else None
        f["max_concurrency_tokens"] = int(m[-1][0].replace(",", "")) if m else None     # R2: M of the line (F_log)
        m = re.findall(r"Padding mamba page size by ([\d.]+)%", t)
        f["mamba_pad_pct"] = float(m[-1]) if m else None
        f["min_block_for_mamba"] = math.ceil(BLOCK / (1 + f["mamba_pad_pct"] / 100)) if m else None
        f["kv_group_sizes"] = (re.findall(r"kv cache group sizes \(([^)]*)\)", t) or [None])[-1]
        f["side_cache_layout"] = _pick(t, r"Side-cache layout", 2)
        f["initial_free_reserved_gib"] = [[float(a), float(b)] for a, b in re.findall(r"Initial free memory ([\d.]+) GiB, reserved ([\d.]+) GiB", t)][:4]
        f["model_load_gib_sec"] = [[float(a), float(b)] for a, b in re.findall(r"Model loading took ([\d.]+) GiB memory and ([\d.]+) seconds", t)][:4]
        f["graph_capture_sec_gib"] = [[int(a), float(b)] for a, b in re.findall(r"Graph capturing finished in (\d+) secs, took ([\d.]+) GiB", t)][:4]
        f["rank_load_gib"] = {int(p) * 2 + int(q): float(g) for p, q, g in re.findall(
            r"\(Worker_PP(\d)_TP(\d)\S*(?: pid=\d+)?\) INFO [^\n]*?Model loading took ([\d.]+) GiB memory", t)}
        f["rank_load_sec"] = {int(p) * 2 + int(q): float(g) for p, q, g in re.findall(
            r"\(Worker_PP(\d)_TP(\d)\S*(?: pid=\d+)?\) INFO [^\n]*?Model loading took [\d.]+ GiB memory and ([\d.]+) seconds", t)}
        f["rank_graph_gib"] = {int(p) * 2 + int(q): float(g) for p, q, g in re.findall(
            r"\(Worker_PP(\d)_TP(\d)\S*(?: pid=\d+)?\) INFO [^\n]*?Graph capturing finished in \d+ secs, took ([\d.]+) GiB", t)}
        f["ssm_dtype_lines"] = _pick(t, r"mamba_ssm_dtype|mamba-ssm-cache-dtype")
        f["gdn_fallback_lines"] = _pick(t, r"Falling back to the Triton GDN spec decode path")
        f["share_workspace_lines"] = _pick(t, r"MERLIN_SHARE_DRAFT_WORKSPACE")
        f["mm_warmup_lines"] = _pick(t, r"Multi-modal warmup completed")
        f["host_ram_lines"] = _pick(t, r"host memory available now|Cgroup memory preflight|Skipping auto-prefetch", 6)
        f["sched_warn_lines"] = _pick(t, r"max_num_scheduled_tokens", 2)
        f["oom_lines"] = _pick(t, r"OutOfMemoryError|CUDA out of memory", 4)
        f["static_scale_lines"] = _pick(t, r"applied static K/V scales", 8)
        f["default_scale_lines"] = _pick(t, r"DEFAULT 1\.0|no static calibration", 4)    # audit 2: the MTP layer's QSA FP8 KV
        f["ext_lines"] = _pick(t, r"Injected .*NB1WorkerExt|nb1_worker_ext", 2)
        f["shm_leak_lines"] = _pick(t, r"leaked (semaphore|shared_memory) objects", 4)
        return f


    def graph_facts(t):
        caps = sorted({(a, int(c)) for a, b, c in re.findall(r"Capturing CUDA graphs \((\w+)\):\s*100%\|[^|]*\|\s*(\d+)/(\d+)", t)})
        return {"captured": caps, "resolved_modes": _pick(t, r"resolved cudagraph modes before capture", 8),
                "draft_identity": _pick(t, r"e2-identity\[.*role=draft", 4), "recoverssm_commit": _pick(t, r"\[recoverssm-commit\]"),
                "recoverssm_path": _pick(t, r"RecoverSSM path taken", 4), "jit": jit_kernels(t)}


    def jit_kernels(t):
        return re.findall(r"JIT compilation during inference: (\w+)", t)


    def rpc_cache_info(port):
        """The read-only worker extension over /collective_rpc (dev mode): actual cache tensor dtypes, specs, free memory."""
        body = {"method": "nb1_cache_info", "timeout": 120}
        try:
            r = json.loads(L.U.urlopen(L.U.Request(f"http://127.0.0.1:{port}/collective_rpc", data=json.dumps(body).encode(),
                                                   headers={"Content-Type": "application/json"}), timeout=180).read())
            res = r.get("results") or []
        except Exception as e:
            return {"error": repr(e)[:300]}
        out = {"ranks": res}
        dts = sorted({x["dtype"] for w in res if isinstance(w, dict) for g in (w.get("cache_tensors") or [])
                      if "mamba" in g.get("module", "").lower() or "gdn" in g.get("module", "").lower() or "linear" in g.get("module", "").lower()
                      for x in g.get("tensors") or []})
        out["recurrent_tensor_dtypes"] = dts
        out["num_gpu_blocks"] = sorted({w.get("num_gpu_blocks") for w in res if isinstance(w, dict)} - {None})
        out["free_mib_per_rank"] = [((w or {}).get("mem") or {}).get("free_mib") for w in res if isinstance(w, dict)]
        pads = []
        for w in res:
            for s in ((w or {}).get("kv_cache_specs") or []) if isinstance(w, dict) else []:
                if s.get("unpadded_page_bytes") and s.get("page_size_bytes"):
                    pads.append({"rank": w.get("rank"), "type": s.get("type"), "layers": s.get("layers"), "state_dtypes": s.get("state_dtypes"),
                                 "padded": s["page_size_bytes"], "unpadded": s["unpadded_page_bytes"],
                                 "pad_pct": round(100 * (s["page_size_bytes"] - s["unpadded_page_bytes"]) / s["unpadded_page_bytes"], 2)})
        out["mamba_padding"] = pads[:16]
        return out


    def rpc(port, method, *args, timeout=120):
        """POST /collective_rpc (dev mode): a worker method by name with string args; the per-rank results or the error."""
        body = {"method": method, "args": [str(a) for a in args], "timeout": timeout}
        try:
            r = json.loads(L.U.urlopen(L.U.Request(f"http://127.0.0.1:{port}/collective_rpc", data=json.dumps(body).encode(),
                                                   headers={"Content-Type": "application/json"}), timeout=timeout + 60).read())
            return {"results": r.get("results")}
        except Exception as e:
            return {"error": repr(e)[:300]}


    def free_per_card(rec, name):
        """MiB free per card = total - the highest used reading of this boot (after ready, end, every window peak)."""
        srv = ((rec or {}).get("servers") or {}).get(name) or {}
        rows = [r for r in (srv.get("gpu_mem_after_ready"), srv.get("gpu_mem_end")) if r]
        if not rows:
            return None
        tot = {i: t for row in rows for i, _, t in row}
        used = {i: max(u for row in rows for j, u, _ in row if j == i) for i in tot}
        st = (rec or {}).get("steady")             # R2: nb1_ladder's steady holds "_plan" (list), "_fit" (dict), "_seqs_cap" (int)
        ws = list(st.values()) if isinstance(st, dict) else []
        for w in ws + [(rec or {}).get("profile")]:
            if not isinstance(w, dict):            # R2: only window dicts carry gpu_mem_peak_mib
                continue
            pk = w.get("gpu_mem_peak_mib")
            for i, u in enumerate(pk if isinstance(pk, list) else []):
                if i in used and isinstance(u, (int, float)):
                    used[i] = max(used[i], u)
        return [tot[i] - used[i] for i in sorted(tot)]


    def free_after_ready(rec, name):
        srv = ((rec or {}).get("servers") or {}).get(name) or {}
        row = srv.get("gpu_mem_after_ready")
        return [t - u for _, u, t in row] if row else None


    def kvu(port):
        return L.prom(port).get(L.KVU)


    def pool_blocks_from_usage(us):
        vals = sorted({round(u, 9) for u in us if isinstance(u, (int, float)) and 0 < u < 1})
        if len(vals) < 2:
            return None
        for p in range(20, 3001):
            if all(abs(u * p - round(u * p)) < 0.02 for u in vals):
                return p
        return None


    def reset_cache(port):
        """POST /reset_prefix_cache (dev mode): the 'caches cleared' state of the audits; fails while requests run."""
        try:
            r = L.U.urlopen(L.U.Request(f"http://127.0.0.1:{port}/reset_prefix_cache", data=b"", method="POST"), timeout=120).read()
            return {"ok": True, "body": r[:200].decode(errors="replace")}
        except Exception as e:
            return {"ok": False, "error": repr(e)[:200]}


    def _hits(port):
        try:
            return L.prom(port).get("vllm:prefix_cache_hits_total", 0.0)
        except Exception:
            return None


    def n_fit(P, F, B, band, idle_blocks=0, seqs=None, n_prompts=None):
        """Streams of `band` whose final length (prompt + ~(admission + window + 60 s) x GEN_RATE) all fit in the pool."""
        if P is None or F is None:
            return None
        L0 = BANDS[band]
        final = L0 + (L0 * 8 / max(1.0, PREFILL["tok_s"]) + WIN + 60) * GEN_RATE
        n = int((P - idle_blocks) // (math.ceil(final / B) + F))
        for cap in (seqs, n_prompts):
            if cap:
                n = min(n, cap)
        return max(0, n)


    def admission_test(port, s, band="90k", n=5, max_new=4096):
        """Fresh-cache admission of n distinct long prompts (audit 2: 90k x 5 before any pin change). Reset the cache, start
        n streams, wait until every one has its first token (admission + cold prefill, ~450k tokens: Merlin's cost-aware
        admission may hold a cold miss up to 120 s), then: a resident snapshot (running == n, waiting 0, no preemption, blocks)
        and a short decode window measured on the counters while all n stay resident. max_new 4096 keeps 5 x (ceil(94,096 /
        4096) + 6) = 145 of 149 blocks: the streams cannot outgrow the pool (a lab steady window cannot be used: the first
        stream would finish its max_new inside it, since the cold prefills are staggered by ~20 s each)."""
        if not due(240 + n * BANDS[band] / max(2000.0, PREFILL["tok_s"])):
            return {"status": "SKIPPED_BOOT_BUDGET"}
        if not L.wait_idle(port, 120):
            return {"status": "INCONCLUSIVE_NOT_IDLE"}
        rec = {"band": band, "n": n, "max_new": max_new, "reset": reset_cache(port)}
        time.sleep(1)
        rec["idle_usage"] = kvu(port)
        m0, l0, t0 = L.prom(port), _req_lines(), time.time()
        ss = [L.Stream(port, PROMPTS[band][i], max_new, temperature=TEMP, seed=500 + i, ignore_eos=True) for i in range(n)]
        for g in ss:
            g.start()
        try:
            limit = max(420.0, 180.0 + n * BANDS[band] / max(1000.0, PREFILL["tok_s"]))
            while time.time() - t0 < limit:
                time.sleep(2)
                if all(g.t_first for g in ss) or any(not g.is_alive() for g in ss):
                    break
            m1 = L.prom(port)
            rec.update(admission_sec=round(time.time() - t0, 1), first_token=[round(g.t_first - g.t_start, 1) if g.t_first else None for g in ss],
                       snapshot={"running": m1.get(L.RUN), "waiting": m1.get(L.WAIT), "usage": m1.get(L.KVU),
                                 "tokens": [len(PROMPTS[band][i]) + len(g.tokens) for i, g in enumerate(ss)]},
                       preemptions=m1.get(L.PREEMPT, 0) - m0.get(L.PREEMPT, 0),
                       prefill_uncached_tok_s=round(((m1.get(L.PROMPT, 0) - m0.get(L.PROMPT, 0)) - (m1.get("vllm:prefix_cache_hits_total", 0)
                                                     - m0.get("vllm:prefix_cache_hits_total", 0))) / max(1e-3, time.time() - t0), 1))
            rec["all_resident"] = (all(g.t_first for g in ss) and rec["snapshot"]["running"] == n and not rec["snapshot"]["waiting"]
                                   and not rec["preemptions"])
            if rec["all_resident"]:
                secs = min(20.0, WIN)
                g0, w0, runs = L.prom(port), time.time(), []
                while time.time() - w0 < secs:
                    time.sleep(min(2.0, secs))
                    runs.append(L.prom(port).get(L.RUN))
                g1 = L.prom(port)
                dt = time.time() - w0
                steps = g1.get(L.ITER, 0) - g0.get(L.ITER, 0)
                rec["window"] = {"sec": round(dt, 1), "tok_s": round((g1.get(L.GEN, 0) - g0.get(L.GEN, 0)) / dt, 1), "running_min": min(runs or [0]),
                                 "running_max": max(runs or [0]), "tick_ms": round(dt * 1000 / steps, 1) if steps else None,
                                 "preemptions": g1.get(L.PREEMPT, 0) - g0.get(L.PREEMPT, 0)}
                if rec["window"]["tick_ms"]:
                    rec["window"]["cycle_ms"] = round(PP * rec["window"]["tick_ms"], 1)
                rec["status"] = ("ALL_RESIDENT" if rec["window"]["running_min"] == n and not rec["window"]["preemptions"]
                                 else "INCONCLUSIVE_RUNNING_CHANGED")
            else:
                rec["status"] = "NOT_ALL_RESIDENT"
        finally:
            for g in ss:
                g.stop()
            for g in ss:
                g.join(10)
            rec["stream_errors"] = sorted({g.err for g in ss if g.err})[:3]
        rec["ttft_per_request"] = _ttfts(port, l0)
        return rec


    def residency_bound(P, F, band, max_new=0, seqs=None):
        """Arithmetic bound: running requests of total context band + max_new that fit P blocks at F fixed blocks each."""
        if not P or F is None:
            return None
        n = int(P // (math.ceil((BANDS[band] + max_new) / BLOCK) + F))
        return min(n, seqs) if seqs else n


    F_MAX_BLOCKS = 40


    def _f_valid(F):
        return isinstance(F, (int, float)) and not isinstance(F, bool) and math.isfinite(F) and 0 <= F <= F_MAX_BLOCKS


    def f_from_log(o, P):
        """R2: F_log = P / X - ceil(M / B) from this boot's line 'GPU KV cache size: N tokens, Maximum concurrency for M tokens
        per request: X x' (X = N / M when N is there: the printed X has 2 decimals); F = ceil(F_log - 0.05) like
        nb5_lib.capacity_plan (RC2 / B1: 149 x 131,072 / 513,940 - 32 = 5.999 -> 6)."""
        pool = o.get("pool") or {}
        N, X, M = pool.get("kv_tokens"), pool.get("max_concurrency"), pool.get("max_concurrency_tokens")
        B = (o.get("caps") or {}).get("block_size") or BLOCK
        if not (isinstance(M, int) and M > 0 and ((isinstance(N, int) and N > 0) or (isinstance(X, (int, float)) and X > 0))):
            return {"ok": False, "why": f"no max-concurrency line in this boot's log (N {N}, M {M}, X {X})"}
        xx = N / M if isinstance(N, int) and N > 0 else float(X)
        f_log = P / xx - math.ceil(M / B)
        F = max(0, int(math.ceil(f_log - 0.05)))
        ok = math.isfinite(f_log) and -0.05 <= f_log <= F_MAX_BLOCKS
        return {"ok": ok, "F": F if ok else None, "F_log": round(f_log, 3), "kv_tokens": N, "max_concurrency": X, "tokens_per_request": M,
                "block_size": B, "x_used": round(xx, 5), "why": None if ok else f"F_log {f_log:.3f} outside 0..{F_MAX_BLOCKS}"}


    def nb1_complete(port, ids, max_new, temperature=0.0, seed=None, logprobs=0, timeout=1800):
        """Non-streaming /v1/completions with token ids: ids, usage, cached tokens (--enable-prompt-tokens-details) and, with
        logprobs, the chosen-token logprobs + top-1/top-2 margins. Every request is saved in traces/requests.jsonl."""
        body = {"model": "q27", "prompt": list(ids), "max_tokens": int(max_new), "temperature": temperature,
                "top_p": 0.95 if temperature else 1.0, "ignore_eos": True, "return_token_ids": True}
        if temperature:
            body["top_k"] = 20
        if seed is not None:
            body["seed"] = int(seed)
        if logprobs:
            body["logprobs"] = int(logprobs)
            body["return_tokens_as_token_ids"] = True
        t = time.time()
        try:
            r = json.loads(L.U.urlopen(L.U.Request(f"http://127.0.0.1:{port}/v1/completions", data=json.dumps(body).encode(),
                                                   headers={"Content-Type": "application/json"}), timeout=timeout).read())
            ch = r["choices"][0]
            u = r.get("usage") or {}
            out = {"ids": list(ch.get("token_ids") or []), "text": ch.get("text") or "", "usage": u, "error": None,
                   "cached": (u.get("prompt_tokens_details") or {}).get("cached_tokens")}
            lp = ch.get("logprobs") or {}
            if logprobs:
                out["lps"] = list(lp.get("token_logprobs") or [])
                out["margins"] = []
                for top in lp.get("top_logprobs") or []:
                    v = sorted((x for x in (top or {}).values() if isinstance(x, (int, float))), reverse=True)
                    out["margins"].append(round(v[0] - v[1], 4) if len(v) >= 2 else None)
        except Exception as e:
            out = {"ids": [], "text": "", "usage": None, "cached": None, "error": repr(e)[:300]}
        out["sec"] = round(time.time() - t, 2)
        try:
            with _SAVE_LOCK, open(REQ_LOG, "a") as fh:
                fh.write(json.dumps({"kind": "nb1_complete", "port": port, "prompt_len": len(ids), "max_new": max_new,
                                     "prompt_sha": psha(ids)[:16], "text": out["text"], "tokens": out["ids"], "lps": out.get("lps"),
                                     "usage": out["usage"], "error": out["error"], "sec": out["sec"], "t": time.time()}) + "\n")
        except Exception:
            pass
        return out


    def lp_compare(a, b):
        """Greedy rows a (reference) vs b: first differing token, the reference's top-1 - top-2 margin there (L.FAIL_MARGIN),
        mean / max |delta chosen-token logprob| over the identical prefix."""
        if not a or not b or a.get("error") or b.get("error") or not a.get("ids") or not b.get("ids"):
            return {"status": "INCONCLUSIVE"}
        x, y = a["ids"], b["ids"]
        d = next((i for i in range(min(len(x), len(y))) if x[i] != y[i]), None)
        la, lb = a.get("lps") or [], b.get("lps") or []
        k = d if d is not None else min(len(x), len(y))
        dl = [abs(p - q) for p, q in zip(la[:k], lb[:k]) if isinstance(p, (int, float)) and isinstance(q, (int, float))]
        if d is None:
            st, m = ("EXACT" if len(x) == len(y) else "INCONCLUSIVE"), None
        else:
            mm = a.get("margins") or []
            m = mm[d] if d < len(mm) else None
            st = "INCONCLUSIVE" if m is None else ("FAIL_HIGH_MARGIN" if m >= L.FAIL_MARGIN else "NEAR_TIE")
        return {"status": st, "first_diff": d, "ref_margin": m, "mean_abs_dlogprob_prefix": round(statistics.mean(dl), 5) if dl else None,
                "max_abs_dlogprob_prefix": round(max(dl), 5) if dl else None, "tokens": [len(x), len(y)],
                "cached": [a.get("cached"), b.get("cached")]}


    def warmup(port, n, secs=None):
        """Multi-stream 2k decode, ramped 1 -> n streams, excluded from every metric: compiles the kernels RC2 saw compiled
        during inference (_fill_num_accepted_kernel, _causal_conv1d_update_kernel, _gdn_recoverssm_verify_kernel,
        _ple_conv_kernel, _ple_conv_writeback_kernel) before any measured window."""
        secs = secs or (45.0 if not FAKE else 4.0)
        srv = next((x for x in list(L.LIVE) if x.port == port), None)
        j0 = jit_kernels(srv.log()) if srv else []
        ss, t0 = [], time.time()
        try:
            for i in range(n):
                g = L.Stream(port, PROMPTS["2k"][i % len(PROMPTS["2k"])], 4096, temperature=TEMP, seed=900 + i, ignore_eos=True)
                g.start()
                ss.append(g)
                time.sleep(min(3.0, secs / max(1, 2 * n)))
            while time.time() - t0 < secs:
                time.sleep(1)
        finally:
            for g in ss:
                g.stop()
            for g in ss:
                g.join(10)
        L.wait_idle(port, 60)
        j1 = jit_kernels(srv.log()) if srv else []
        return {"streams": n, "sec": round(time.time() - t0, 1), "jit_before": j0, "jit_compiled_in_warmup": j1[len(j0):],
                "errors": sorted({g.err for g in ss if g.err})[:3]}


    def accept_pos(port):
        try:
            txt = L.U.urlopen(f"http://127.0.0.1:{port}/metrics", timeout=15).read().decode("utf-8", "replace")
        except Exception:
            return None
        pos = {}
        for m in re.finditer(r"^vllm:spec_decode_num_accepted_tokens_per_pos_total\{([^}]*)\}\s+(\S+)", txt, re.M):
            p = re.search(r'position="(\d+)"', m.group(1))
            if p:
                pos[int(p.group(1))] = pos.get(int(p.group(1)), 0.0) + float(m.group(2))
        return {"pos": pos, "drafts": L.prom(port).get(L.DRF, 0.0)}


    def _prefill_done(r, n):
        tail = ((r.get("admission") or {}).get("tail") or [])
        t = tail[-1] if tail else None
        return bool(t) and t[1] == n and t[2] == 0 and t[3] >= n


    def _req_lines():
        try:
            with open(REQ_LOG) as fh:
                return sum(1 for _ in fh)
        except Exception:
            return 0


    def _ttfts(port, start_line):
        out = []
        try:
            with open(REQ_LOG) as fh:
                for i, l in enumerate(fh):
                    if i >= start_line:
                        r = json.loads(l)
                        if r.get("port") == port and r.get("ttft") is not None:
                            out.append(r["ttft"])
        except Exception:
            pass
        return out


    def _counters(port):
        try:
            m = L.prom(port)
            return m.get(L.PROMPT, 0.0), m.get("vllm:prefix_cache_hits_total", 0.0)
        except Exception:
            return None, None


    def window(port, s, band, n, max_new=None, secs=None):
        """One steady window, timed only after every stream finished admission + prefill (the lab's settle needs all running
        streams to have emitted and be gaining, then an explicit check of the last admission sample; Merlin's cost-aware
        admission may hold a cold miss up to 120 s, inside the lab's >= 420 s admission limit); a window with prefill inside is
        retried once. Recorded: tick_ms (one engine step = one micro-batch of C/2 requests under PP2) AND cycle_ms (= PP x
        tick, the per-request advance time), per-request TTFT, uncached prefill tok/s (prompt minus prefix-hit tokens),
        retained (idle) blocks before the window, per-position acceptance."""
        retained_before = None
        if L.wait_idle(port, 60):
            retained_before = kvu(port)
        def run():
            if max_new is None:                 # RC2 / E23 levels(): MAX_NEW[band], WIN, the budget / KV-bound guards
                return levels(port, band, [n], server=s, temperature=TEMP, prefill_tok_s=PREFILL["tok_s"]).get(f"{band}@{n}") or {}
            return L.steady(port, PROMPTS[band], n, secs=secs or WIN, max_new=max_new, temperature=TEMP, prefill_tok_s=PREFILL["tok_s"])
        a0, c0, l0 = accept_pos(port), _counters(port), _req_lines()
        r = run()
        if r.get("status") == "INCONCLUSIVE_PREFILL_IN_WINDOW" and due(WIN + 120 + n * BANDS[band] / max(500.0, PREFILL["tok_s"])):
            c0, l0 = _counters(port), _req_lines()
            r = dict(run(), retried_after="INCONCLUSIVE_PREFILL_IN_WINDOW")
        a1, c1 = accept_pos(port), _counters(port)
        r["prefill_done_before_window"] = _prefill_done(r, n)
        r["running_eq_level"] = r.get("running_min") == r.get("running_max") == n
        if r.get("status") == "STEADY" and not (r["running_eq_level"] and r["prefill_done_before_window"]):
            r["status"] = "INCONCLUSIVE_RUNNING_NE_LEVEL" if not r["running_eq_level"] else "INCONCLUSIVE_PREFILL_NOT_DONE"
        if r.get("step_ms"):
            r["tick_ms"] = r["step_ms"]
            r["cycle_ms"] = round(PP * r["step_ms"], 1)
            r["requests_per_tick"] = round(n / PP, 2)
            r["microbatches_per_s"] = round(1000.0 / r["step_ms"], 2)
            r["wall_clock_tok_s"] = r.get("tok_s")
            r["tick_note"] = ("tick_ms = step_ms = one PP tick (one completed micro-batch of C/2 requests); cycle_ms = 2 ticks = the "
                              "per-request advance time; microbatches_per_s = completed micro-batches per second; wall_clock_tok_s = "
                              "generated tokens / window seconds")
        adm = (r.get("admission") or {}).get("sec")
        if None not in (c0[0], c1[0]) and adm:
            unc = (c1[0] - c0[0]) - (c1[1] - c0[1])
            r["prefill_uncached_tokens"] = int(unc)
            r["prefill_tok_s_uncached"] = round(unc / adm, 1)
            r["prefill_note"] = "admission.prefill_tok_s counts cached prompt tokens; prefill_tok_s_uncached does not (incl. a retry)"
        r["ttft_per_request"] = _ttfts(port, l0)
        if retained_before is not None:
            r["retained_usage_before"] = retained_before
        if a0 and a1 and a1["drafts"] > a0["drafts"]:
            r["accept_rate_per_position_incl_admission"] = {p: round((a1["pos"].get(p, 0) - a0["pos"].get(p, 0)) / (a1["drafts"] - a0["drafts"]), 3)
                                                            for p in sorted(a1["pos"])}
        return r


    def free_valid(fr):
        """R2 audit N1-3: a valid per-rank free memory reading = 4 finite numbers in 0..24,576 MiB (one L4 card)."""
        return (isinstance(fr, list) and len(fr) == 4 and all(isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x)
                                                              and 0 <= x <= 24576 for x in fr))
    save()


if not RERUN:
    # ==================================================================== CELL 7 — E25 klee100: boots, pin ladder, TF vs W4, analysis (NEW)
    K100 = {"ready_sec": float(os.environ.get("K100_READY_SEC") or 1500), "fracs": (0.9, 0.8, 0.7), "safety_mib": 1024,
            "mtp_reserve_mib": 1448, "k2_min_free_mib": 512, "long_max_new": 8192, "long_cap_sec": 900,
            "seqs_k": 8, "seqs_k2": 16, "admission_max_new": 4096, "n_cap": 16}
    K1["params"] = dict(K100, mtp_reserve_basis="klee100 MTP tensors / TP2 per PP1 card (680 MiB) + 768 MiB draft workspace / "
                                                "graphs (NB0 B -> D on the W4 PP1 cards: +1,004 MiB at seqs 8; NB2 SMOKE seqs 16 graphs 0.52 GiB)",
                        safety_basis="1 GiB beyond the K0 peak (after a 90k teacher-forced request): NB1's 0.5 GiB rule + 0.5 GiB")
    KV_DEFAULT = KV_BF16                           # 2,464,415,744 B: Merlin's own L4 BF16 pin (RC2 BF16, NB0 A / C)
    FP8_CAPTURES = flags(RC2_REF["fp8"]["argv_tail"])["--compilation-config"]      # NB0 boot A: RC2 FP8's capture list (to 32)
    CAPTURE_HI = [1, 2, 3, 4, 6, 8, 12, 16, 24, 32, 40, 48, 64]                     # NB1: Merlin capture_sizes_for(16, K=3)
    COMPILE_HI = json.dumps({"cudagraph_mode": "FULL_AND_PIECEWISE", "cudagraph_capture_sizes": CAPTURE_HI})
    CAPS_LIST = {FP8_CAPTURES: [1, 2, 3, 4, 6, 8, 12, 16, 24, 32], COMPILE_HI: CAPTURE_HI}
    PORTS = {"K0": 8020, "K": 8021, "K2": 8022}
    CAP_MIN = {"K0": 12, "K": 24, "K2": 34}        # boot body caps (watched: the server is killed at cap + 5 min)
    EST_MIN = {"K0": 17, "K": 30, "K2": 40}        # step(): body + load (~7 min) + release; skipped when the budget cannot hold it
    FP8_BLOCK_BYTES = 2479838700 / 150             # RC2 FP8 block (the kit's Gate D unit: 463 blocks = its estimate)
    RC2_WINDOWS = {"rc2_fp8_8k@8": {"tok_s": 261.8, "tick_ms": 48.2, "mal": 3.154}, "rc2_fp8_40k@5": {"tok_s": 190.5},
                   "nb1_b1_fp8_8k@8": {"tok_s": 280.0, "tick_ms": 45.1}, "nb1_b1_fp8_40k@8": {"tok_s": 248.6},
                   "note": "W4 Merlin, FP8 KV, MTP K3 (RC2 / NB1 B1): no BF16-KV load window exists for W4"}
    K1BOOTS, REF, GATES, RECS = {}, {}, {}, {}      # RECS: the boot records by role (K0 / K / K2), not saved twice
    # prompts (RC2's prompt(); distinct variants share no prefix block): 16 x 40k, 16 x 60k (variants 16-31, cold vs the 40k
    # window), one 120k (variant 40)
    PROMPTS["40k"] += [prompt(BANDS["40k"], v) for v in range(len(PROMPTS["40k"]), 16)]
    BANDS["60k"], BANDS["120k"] = 60000, 120000
    PROMPTS["60k"] = [prompt(BANDS["60k"], v) for v in range(16, 32)]
    PROMPTS["120k"] = [prompt(BANDS["120k"], 40)]
    MAX_NEW.update({"60k": MAX_LEN - BANDS["60k"] - 512, "120k": MAX_LEN - BANDS["120k"] - 512})
    R["prompts"] = {b: {"n": len(p), "len": len(p[0])} for b, p in PROMPTS.items()}


    def k1_boot(key, name, mtp, seqs, captures, kv_bytes, title):
        b = {"key": key, "name": name, "kv": "bf16", "mtp": mtp, "seqs": seqs, "captures": captures, "port": PORTS[key],
             "kv_bytes": int(kv_bytes), "title": title}
        K1BOOTS[name] = b
        NB1_EXTRA[name], NB1_ENV[name], NB1_KV[name] = list(EXT_FLAG), dict(DIAG_ENV), int(kv_bytes)
        return b


    _merlin_fn_server_nb1 = merlin_fn_server       # RC2 CELL 2 (launch.build + host_phase) with NB1's per-boot hooks


    def merlin_fn_server(name, kv, port, kv_bytes):
        """E25 klee100: K6 before every launch (one missing indexed shard -> no server is started), RC2's Merlin plan, NB0's
        argv edits (MTP off = the same command without --speculative-config; seqs / captures = the existing flags' values),
        the plan + config diff vs RC2 BF16 recorded, NB0's load monitor (launch -> ready)."""
        b = K1BOOTS[name]
        k6 = KL.k6_check(CKPT)
        K1.setdefault("k6_before_launch", {})[name] = {k: k6.get(k) for k in ("ok", "why", "index_files", "missing")}
        if not k6["ok"]:
            save()
            raise RuntimeError("K6_INDEXED_SHARD_MISSING before launch: " + str(k6["why"]))
        s = _merlin_fn_server_nb1(name, kv, port, kv_bytes)
        s.argv = nb0_argv(s.argv, b)
        R["setup"].setdefault("k100_plans", {})[name] = {
            "boot": b["key"], "title": b["title"], "argv_tail": s.argv[-64:], "kv_bytes": kv_bytes,
            "env": {k: s.env[k] for k in sorted(s.env) if k.startswith(ENV_KEYS + ("MERLIN_",))},
            "diff_vs_rc2_bf16": config_diff(s.argv, s.env, kv_bytes, "bf16")}
        save()
        if not os.environ.get("RC2_CPU_KIT"):
            deadline = time.time() + max(120, min(K100["ready_sec"] + 120, left() - 240))
            threading.Thread(target=load_monitor, args=(s, b["key"], deadline), daemon=True).start()
        return s


    class GpuSampler(threading.Thread):
        """nvidia-smi every `every` s while a boot body runs: the highest used MiB per card (a transient between readings)."""
        def __init__(self, every=2.0):
            super().__init__(daemon=True)
            self.every, self.ev, self.max, self.tot, self.n = every, threading.Event(), {}, {}, 0

        def run(self):
            while not self.ev.is_set():
                for i, u, t in (L.gpu_mem() or []):
                    self.max[i], self.tot[i] = max(self.max.get(i, 0), u), t
                self.n += 1
                self.ev.wait(self.every)

        def rows(self):
            return [[i, self.max[i], self.tot[i]] for i in sorted(self.max)]


    def k100_facts(s, b, o):
        """Config read-back from the server's own log + the worker extension: KV dtype, seqs, pin, spec (MTP on / off),
        captures, prefix caching, quantization, model dir; per-rank memory; pool; humming / method / PLE lines.
        config_ok only when every check holds (else CONFIG_MISMATCH: the boot stops)."""
        t = s.log() or ""
        o["caps"], o["pool"], o["graphs"] = server_caps(t, s.argv), pool_facts(t), graph_facts(t)
        o["workers"] = rpc_cache_info(s.port)
        lines = t.splitlines()
        nd = next((l for l in lines if "non-default args:" in l), "")
        eng = next((l for l in lines if "Initializing a V1 LLM engine" in l), "")
        g = lambda rx, txt: (re.search(rx, txt) or [None, None])[1]
        f = {"kv_cache_dtype": g(r"'kv_cache_dtype': '(\w+)'", nd), "engine_kv": g(r"kv_cache_dtype=(\w+)", eng),
             "max_num_seqs": g(r"'max_num_seqs': (\d+)", nd), "kv_cache_memory_bytes": g(r"'kv_cache_memory_bytes': (\d+)", nd),
             "argv_kv_bytes": flags(s.argv).get("--kv-cache-memory-bytes"), "spec_in_args": "'speculative_config':" in nd,
             "spec_k_args": g(r"'num_speculative_tokens': (\d+)", nd), "engine_spec": g(r"speculative_config=(None|SpeculativeConfig\([^)]*\))", eng),
             "quantization": g(r"quantization=([\w\-]+)", eng), "dtype": g(r"dtype=torch\.(\w+)", eng), "model": g(r"'model': '([^']+)'", nd),
             "captures": o["caps"].get("capture_sizes"), "prefix_caching": "'enable_prefix_caching': True" in nd,
             "mtp_off_warning": bool(re.search(r"needs speculative decoding; num_speculative_tokens=0", t)),
             "engine_line": eng[:2000]}
        es = f["engine_spec"] or ""
        ck = {"kv_bfloat16_args": f["kv_cache_dtype"] == "bfloat16", "kv_bfloat16_engine": f["engine_kv"] == "bfloat16",
              "seqs": f["max_num_seqs"] == str(b["seqs"]), "prefix_caching": f["prefix_caching"], "dtype_bf16": f["dtype"] == "bfloat16",
              "pin": f["kv_cache_memory_bytes"] is not None and f["kv_cache_memory_bytes"] == str(f["argv_kv_bytes"]),
              "quantized": f["quantization"] not in (None, "None"), "captures": f["captures"] == CAPS_LIST.get(b["captures"]),
              "model_dir": f["model"] == str(CKPT),
              "mtp": ((f["spec_in_args"] and f["spec_k_args"] == "3" and es.startswith("SpeculativeConfig") and "num_spec_tokens=3" in es)
                      if b["mtp"] else (not f["spec_in_args"] and es == "None" and f["mtp_off_warning"]))}
        f["checks"] = ck
        f["humming_lines"] = _pick(t, r"(?i)humming", 60)
        f["method_lines"] = _pick(t, r"Using \w+ for \w+|Using \w+(MoE)?Method|MoE backend|WNA16|MarlinExperts|INC|auto.?round", 40)
        f["unquantized_lines"] = _pick(t, r"Unquantized(FusedMoE|Linear)Method|falling back to unquantized", 10)
        f["ple_lines"] = _pick(t, r"(?i)PLE offload|Fp8Embedding|ple_embedding_dtype|PLE.*ready", 12)
        f["nan_lines"] = _pick(t, r"(?i)\bnan\b|non-finite|inf detected", 10)
        f["traceback_lines"] = _pick(t, r"Traceback|Error:", 12)
        o["readback"] = f
        o["config_ok"] = all(ck.values())
        pl = o["pool"]
        o["memory_census"] = {"rank_load_gib": pl.get("rank_load_gib"), "rank_load_sec": pl.get("rank_load_sec"),
                              "rank_graph_gib": pl.get("rank_graph_gib"), "initial_free_reserved_gib": pl.get("initial_free_reserved_gib"),
                              "workers_mem": [[w.get("rank"), w.get("mem")] for w in ((o["workers"] or {}).get("ranks") or []) if isinstance(w, dict)],
                              "kv_tokens": pl.get("kv_tokens"), "max_concurrency": [pl.get("max_concurrency_tokens"), pl.get("max_concurrency")]}
        return o


    def warmup_gauge(port, n):
        """NB1's warm-up (excluded from every metric) with the kv_cache_usage gauge sampled every 0.5 s: the usage
        denominators give the pool in blocks (pool_blocks_from_usage), the cross-check of the worker num_gpu_blocks."""
        us, ev = [], threading.Event()

        def samp():
            while not ev.is_set():
                try:
                    us.append(kvu(port))
                except Exception:
                    pass
                ev.wait(0.5)
        th = threading.Thread(target=samp, daemon=True)
        th.start()
        try:
            w = warmup(port, n)
        finally:
            ev.set()
            th.join(5)
        w["kv_usage_samples"] = len(us)
        return w, us


    def k100_capacity(o, us, kv_bytes):
        """This boot's pool P (worker num_gpu_blocks - 1, cross-checked with the gauge), F from the max-concurrency line
        (f_from_log), bytes per block, the FP8-equivalent of the pin vs the kit's 463-block estimate, the stream counts."""
        wb = sorted({x - 1 for x in ((o.get("workers") or {}).get("num_gpu_blocks") or []) if isinstance(x, int) and not isinstance(x, bool) and x > 1})
        pg = pool_blocks_from_usage(us or [])
        P = wb[0] if len(wb) == 1 else pg
        chk = ("MATCH" if len(wb) == 1 and pg == wb[0] else "WORKER_ONLY" if len(wb) == 1 and pg is None else
               "GAUGE_ONLY" if not wb and pg else "MISMATCH" if len(wb) == 1 and pg else "UNKNOWN")
        fl = f_from_log(o, P) if P else {"ok": False, "why": "pool unknown"}
        F = fl.get("F") if fl.get("ok") else None
        seqs = (o.get("caps") or {}).get("max_num_seqs")
        out = {"pool_blocks": P, "worker_usable_blocks": wb, "gauge_pool_blocks": pg, "pool_check": chk, "F_log": fl, "F": F,
               "kv_bytes": kv_bytes, "bytes_per_block": round(kv_bytes / P) if P else None, "kv_tokens": (o.get("pool") or {}).get("kv_tokens"),
               "fp8_equivalent_blocks_of_pin": round(kv_bytes / FP8_BLOCK_BYTES, 1),
               "kit_estimate": {"fp8_blocks": 463, "kv_bytes_equiv": int(463 * FP8_BLOCK_BYTES),
                                "note": "kit Gate D: RC2's 149 FP8 blocks + the bytes freed by the low-bit experts on the binding stage, "
                                        "all given to KV (MTP on); this pin leaves the safety / MTP reserve / 1 - frac unused"},
               "max_num_seqs": seqs}
        if P and F is not None:
            out["n40"] = n_fit(P, F, BLOCK, "40k", 0, seqs, len(PROMPTS["40k"]))
            out["n64"] = residency_bound(P, F, "60k", max_new=K100["admission_max_new"], seqs=seqs)
            out["resident_bound"] = {L_: P // (math.ceil(L_ / BLOCK) + F) for L_ in (40000, 64096, 90000, 120000)}
        return out


    def long_prefill(port):
        """One ~120k-token request (RC2 prompt(120000, 40)), temperature 0.6, its own stop or the cap (8,192 new tokens /
        900 s); TTFT = the prefill, the 2,000-token garbage-window check over the generated ids, NaN margins (logprobs 2).
        A row ended by a cap is incomplete, never a failure by itself; garbage / a request error / NaN is a failure."""
        ids = PROMPTS["120k"][0]
        n = min(K100["long_max_new"], MAX_LEN - len(ids) - 512)
        cap = max(120, min(K100["long_cap_sec"], boot_left() - 240))
        g = L.Stream(port, ids, n, temperature=TEMP, seed=17, logprobs=2, ignore_eos=False)
        g.start()
        g.join(cap)
        if g.is_alive():
            g.stop()
            g.join(10)
        row = g.row()
        (TRACES / f"long120k_{port}.txt").write_text(row["text"])
        toks = row["tokens"]
        ttft = (g.t_first - g.t_start) if g.t_first and g.t_start else None
        dec = (g.t_end - g.t_first) if g.t_end and g.t_first else None
        wg = window_garbage(toks)
        nonfin = sum(1 for m in row["margins"] if m is not None and not (isinstance(m, (int, float)) and math.isfinite(m)))
        out = {"prompt_tokens": len(ids), "prompt_sha256": ids_sha(ids), "max_new": n, "cap_sec": round(cap), "tokens": len(toks),
               "finish": row["finish_reason"], "error": row["error"], "ttft_sec": round(ttft, 1) if ttft else None,
               "prefill_tok_s": round(len(ids) / ttft, 1) if ttft else None, "decode_tok_s": round(len(toks) / dec, 1) if dec else None,
               "window_garbage": wg, "tail_garbage": L.degenerate(TOK.decode(toks[-2000:])) if len(toks) >= 200 else None,
               "think_closed": "</think>" in row["text"], "nonfinite_margins": nonfin, "tail": row["text"][-400:]}
        out["verdict"] = ("FAIL_LONG_REQUEST" if row["error"] else "FAIL_LONG_NONFINITE" if nonfin else
                          "FAIL_LONG_GARBAGE" if (wg or out["tail_garbage"]) else
                          "FINISHED_NATURALLY_CLEAN" if row["finish_reason"] == "stop" else
                          "CAPPED_BY_TOKENS_CLEAN" if row["finish_reason"] == "length" else "CAPPED_BY_TIME_CLEAN")
        return out


    def tf_gate(tf):
        """NaN / request error in any teacher-forced request of this boot -> the fail-fast label (else None)."""
        for band, x in (tf or {}).items():
            for run in ("fresh", "repeat"):
                m = (x or {}).get(run) or {}
                if m.get("error"):
                    return f"NO_GO_TF_REQUEST_ERROR ({band} {run}: {str(m['error'])[:80]})"
                if m.get("nonfinite"):
                    return f"NO_GO_TF_NONFINITE ({band} {run}: {m['nonfinite']} positions)"
        return None


    def _start(s, b, o):
        o.update(census=kv_census(s), probes=L.chat_probes(s.port), sampled=sampled_check(s))
        k100_facts(s, b, o)
        o["gpu_after_ready"] = L.gpu_mem()
        if short_gate_failed(o):
            o["early_stop"] = "SHORT_CORRECTNESS_GATE_FAILED"
            return False
        if o["config_ok"] is not True:
            o.update(early_stop="CONFIG_MISMATCH", status="CONFIG_MISMATCH",
                     config_mismatch=[k for k, v in o["readback"]["checks"].items() if not v])
            return False
        return True


    def _finish(s, o, smp):
        smp.ev.set()
        try:
            o["gpu_end"], o["gpu_peak_rows"], o["gpu_samples"] = L.gpu_mem(), smp.rows(), smp.n
            o["census_end"] = kv_census(s)
            o["workers_end"] = rpc_cache_info(s.port) if s.alive() else {"error": "server dead"}
            o["free_mib_by_card"] = KL.free_by_card([o.get("gpu_after_ready"), o.get("gpu_end"), o.get("gpu_peak_rows")])
            o["tf_died"] = not s.alive()
        except Exception as e:
            o["finish_error"] = f"{type(e).__name__}: {e}"[:300]
        return o


    def _oracle_gate(o, s, key, refs):
        o["oracle"] = oracle(s.port, key=key, refs=refs)
        if not oracle_ok(o["oracle"]):
            o["early_stop"] = "ORACLE_INCOMPLETE_OR_GARBAGE"
            return False
        return True


    def _tf_stop(o, tf):
        g = tf_gate(tf)
        if g:
            o.update(early_stop=g, status=g.split(" ")[0])
        return bool(g)


    def k_body(b, fn):
        """A boot body: the GPU sampler, the shared short gates (_start), fn(s, o) and the closing census (_finish). An
        exception inside keeps everything measured so far (status BODY_ERROR on the record)."""
        def body(ss):
            s, o, smp = ss[0], {}, GpuSampler()
            smp.start()
            try:
                if _start(s, b, o):
                    fn(s, o)
            except Exception as e:
                o.update(status="BODY_ERROR", body_error=f"{type(e).__name__}: {e}"[:800], body_tb=traceback.format_exc()[-2500:])
            finally:
                _finish(s, o, smp)
            return o
        return body


    def body_k0(b):
        """K0 probe at Merlin's BF16 pin (MTP off): fail fast on the short gates, then the memory peaks the pin ladder needs
        (warm-up, a cold 40k prefill, a 90k teacher-forced request)."""
        def fn(s, o):
            if not _oracle_gate(o, s, "k0", ("rc2_bf16",)):
                return
            o["warmup"], us = warmup_gauge(s.port, 8)
            o["capacity"] = k100_capacity(o, us, b["kv_bytes"])
            o["prefill"] = prefill_probe(s.port)
            o["tf"] = tf_suite("K0", s, ["90k"])
            _tf_stop(o, o["tf"])
        return k_body(b, fn)


    def body_k(b):
        """K: the correctness suite at the ladder pin (MTP off)."""
        def fn(s, o):
            if not _oracle_gate(o, s, "k", ("k0", "rc2_bf16")):
                return
            o["warmup"], us = warmup_gauge(s.port, 8)
            o["capacity"] = k100_capacity(o, us, b["kv_bytes"])
            o["tf"] = tf_suite("K", s, ["2k", "8k", "40k"])
            if _tf_stop(o, o["tf"]):
                return
            o["sc"] = sc_suite("K", s)
            if s.alive() and due(420):
                o["long_120k"] = long_prefill(s.port)
            else:
                o["long_120k"] = {"verdict": "SKIPPED_BOOT_BUDGET" if s.alive() else "SKIPPED_SERVER_DEAD"}
            o["tf"].update(tf_suite("K", s, ["90k"]))         # the largest prompt-logits request last (NB0 / RC2 rule)
            if not _tf_stop(o, o["tf"]) and str(o["long_120k"].get("verdict", "")).startswith("FAIL"):
                o["status"] = "NO_GO_" + o["long_120k"]["verdict"]
        return k_body(b, fn)


    def body_k2(b):
        """K2: MTP K3 at the same pin: read-back, oracle, TF 40k vs C (before the load windows: the comparison survives a
        tight budget), warm-up, pool / F, 8k@8, 40k@N, the 64k admission."""
        def fn(s, o):
            if not _oracle_gate(o, s, "k2", ("k", "rc2_bf16")):
                return
            o["tf"] = tf_suite("K2", s, ["40k"])
            if _tf_stop(o, o["tf"]):
                return
            o["warmup"], us = warmup_gauge(s.port, 8)
            cap = o["capacity"] = k100_capacity(o, us, b["kv_bytes"])
            n40 = cap["n40"] if isinstance(cap.get("n40"), int) else 8
            n40 = min(n40, K100["n_cap"], len(PROMPTS["40k"]))
            n64 = min(cap.get("n64") or 0, K100["n_cap"], len(PROMPTS["60k"]))
            o["levels"] = {"n40": n40, "n64": n64, "n40_source": "measured pool + F (n_fit)" if isinstance(cap.get("n40"), int)
                           else "RC2 level 8 (pool / F not measured)"}
            o["steady"] = {"8k@8": window(s.port, s, "8k", 8)}
            if n40 >= 1:
                o["steady"][f"40k@{n40}"] = window(s.port, s, "40k", n40)
            if n64 >= 1:
                o["admission_64k"] = admission_test(s.port, s, band="60k", n=n64, max_new=K100["admission_max_new"])
            else:
                o["admission_64k"] = {"status": "SKIPPED_NO_FIT", "n64": n64}
        return k_body(b, fn)


    def run_k(b, body):
        """One klee100 boot through RC2's merlin_boot (boot gate: GPU empty, engine processes gone, page cache dropped,
        Merlin's host-RAM rule; one OOM retry 0.25 GiB lower; evidence + oracle gates) with NB1's per-boot cap."""
        BOOT["tag"] = b["name"]
        WD.pop(b["key"], None)
        o = merlin_boot(b["name"], "bf16", b["port"], K100["ready_sec"], watched(body, CAP_MIN[b["key"]] * 60, b["name"]),
                        need=(), expected_rows=4)
        LIVE["out"] = o
        try:
            why = str((o.get("boot_gate") or {}).get("why") or "")
            if o.get("status") == "GPU_NOT_EMPTY" and why.startswith(("HOST_RAM", "ENGINE_PROCS")):
                o["status"] = "HOST_RAM_GATE_FAILED" if why.startswith("HOST_RAM") else "ENGINE_PROCS_LEFT"
            o.update(boot=b["key"], title=b["title"], plan=(R["setup"].get("k100_plans") or {}).get(b["name"]),
                     load_monitor=LOADMON.get(b["key"]), planned_kv_bytes=b["kv_bytes"])
            srv = (o.get("servers") or {}).get(b["name"]) or {}
            o["free_mib_by_card_all"] = KL.free_by_card([srv.get("gpu_mem_after_ready"), srv.get("gpu_mem_end"),
                                                         o.get("gpu_after_ready"), o.get("gpu_end"), o.get("gpu_peak_rows")])
            o["oom_at_launch"] = any(t.get("oom") for t in (o.get("tries") or []))
        except Exception as e:
            keep_after_error(o, e)
        return o


    def ref_load():
        """NB0's W4 reference (dataset q27-e25-nb0-tf-ref): every file's sha256 vs the build-time SHA256SUMS, each array's
        ids sha vs NB0's recorded prompt sha; loaded as NB0 TF records (TFR['A'] / TFR['C']) and decode rows (SCR['A'])."""
        out = {"dir": str(REF_DIR), "ok": False}
        if REF_DIR is None:
            out["why"] = "the dataset q27-e25-nb0-tf-ref is not attached"
            return out
        bad = []
        for n, want in K100_PIN["ref_sha256"].items():
            p = REF_DIR / n
            if not p.is_file():
                bad.append(f"missing {n}")
            elif hashlib.sha256(p.read_bytes()).hexdigest() != want:
                bad.append(f"sha256 {n}")
        if bad:
            return dict(out, bad=bad, why=f"{len(bad)} reference files missing / changed")
        meta = json.loads((REF_DIR / "nb0_reference.json").read_text())
        for key, bands in meta["tf"].items():
            for band, rec in bands.items():
                for run in ("fresh", "repeat"):
                    z = np.load(REF_DIR / rec[run]["file"])
                    arr = {k: z[k] for k in z.files}
                    if ids_sha(arr["ids"]) != rec["prompt_sha256"]:
                        bad.append(f"ids {rec[run]['file']}")
                    TFR.setdefault(key, {}).setdefault(band, {})[run] = {
                        "meta": {"boot": key, "band": band, "run": run, "k": rec[run]["k"], "prompt_len": rec["prompt_len"],
                                 "prompt_sha256": rec["prompt_sha256"], "error": None, "source": "NB0 (dataset)"}, "arr": arr}
        for band, rec in meta["sc"]["A"].items():
            z = np.load(REF_DIR / rec["cold"])
            SCR.setdefault("A", {})[band] = {"P": rec["prompt_len"], "ids": z["ids"], "cold": {
                "meta": {"error": None, "prompt_sha256": rec["prompt_sha256"], "source": "NB0 (dataset)"}, "tok": [int(x) for x in z["tok"]],
                "lp": z["lp"].astype(np.float64), "top1": z["top1"].astype(np.int64), "top1_lp": z["top1_lp"].astype(np.float64),
                "top2_lp": z["top2_lp"].astype(np.float64)}}
        REF["meta"] = meta
        return dict(out, ok=not bad, bad=bad, why="; ".join(bad) or None, files=len(K100_PIN["ref_sha256"]),
                    source=meta.get("source"), missing=meta.get("missing"))


    def prompt_identity():
        """The prompts the klee100 boots send = NB0's (ids sha). The klee100 tokenizer.json differs in bytes from Merlin's (its
        BPE merges are serialised differently), so the rendered ids are compared; a mismatch puts NB0's exact ids in place
        (the comparison needs identical token sequences, and the reference ids are what A / C saw)."""
        out = {"tf": {}, "sc": {}}
        for band in NB0["tf_bands"]:
            ref = ((TFR.get("A") or {}).get(band) or {}).get("fresh")
            mine = PROMPTS[band][NB0["tf_variant"]]
            same = bool(ref) and ids_sha(mine) == ref["meta"]["prompt_sha256"]
            if ref and not same:
                PROMPTS[band][NB0["tf_variant"]] = [int(x) for x in ref["arr"]["ids"]]
            out["tf"][band] = {"rendered_equals_nb0": same, "used": "rendered" if same else ("nb0_ids" if ref else "rendered_no_reference")}
        for band, v in NB0["sc_variant"].items():
            ref = (SCR.get("A") or {}).get(band)
            mine = PROMPTS[band][v]
            same = bool(ref) and ids_sha(mine) == ref["cold"]["meta"]["prompt_sha256"]
            if ref and not same:
                PROMPTS[band][v] = [int(x) for x in ref["ids"]]
            out["sc"][band] = {"rendered_equals_nb0": same, "used": "rendered" if same else ("nb0_ids" if ref else "rendered_no_reference")}
        osha = [psha(p)[:16] for p in ORACLE_P + LONG_P]            # RC2's own prompt_sha formula (16 hex)
        out["rc2_oracle_prompts_match"] = {k: [r["prompt_sha"] for r in v] == osha for k, v in RC2_REF["oracle_rows"].items()}
        for k, v in RC2_REF["oracle_rows"].items():                  # RC2's recorded W4 rows: references only for identical prompts
            if out["rc2_oracle_prompts_match"][k]:
                ROWS[k] = [{"text": r["text"], "tokens": r["tokens"], "margins": r["margins"], "error": r["error"]} for r in v]
        out["all_rendered_equal_nb0"] = all(x["rendered_equals_nb0"] for d in (out["tf"], out["sc"]) for x in d.values())
        return out


    def _arr(key, band, run="fresh"):
        x = ((TFR.get(key) or {}).get(band) or {}).get(run)
        return x if x and x.get("arr") is not None else None


    def cmp_pair(ref, cand, y=None):
        if not ref or not cand:
            return {"status": "INCONCLUSIVE_MISSING_TF", "label_full": "INCONCLUSIVE_MISSING", "label_last256": "INCONCLUSIVE_MISSING"}
        lst, ful = cmp_last256(ref, cand), cmp_full(ref["arr"], cand["arr"])
        e = {"last256": lst, "full": ful, "shift": shift_check(ref["arr"], cand["arr"]),
             "label_full": KL.tf_label(ful), "label_last256": KL.tf_label(lst)}
        if y is not None:
            e["yardstick_full"] = KL.yardstick(ful, (y or {}).get("full"))
            e["yardstick_last256"] = KL.yardstick(lst, (y or {}).get("last256"))
        return e


    def k100_analysis():
        """TF divergence of klee100 vs W4 (NB0 A / C) per band with NB0's A/A floor and its FP8-vs-BF16 yardstick, klee100's
        own A/A, MTP on vs off and cross-boot determinism, self-consistency and greedy-decode parity vs A, capacity, speed."""
        meta = REF.get("meta") or {}
        Y = (meta.get("yardstick") or {})
        pairs, perb = Y.get("pairs") or {}, Y.get("per_boot") or {}
        yb = lambda pk, band: ((pairs.get(pk) or {}).get("bands") or {}).get(band)
        an = {"reference": {k: K1.get("reference", {}).get(k) for k in ("ok", "why", "bad", "missing")},
              "prompt_identity": K1.get("prompt_identity"), "tf_k_vs_A": {}, "thresholds": {"screen": KL.SCREEN, "triage": KL.TRIAGE}}
        for band in NB0["tf_bands"]:
            e = cmp_pair(_arr("A", band), _arr("K", band), yb("AB", band))
            kf, kr = _arr("K", band), _arr("K", band, "repeat")
            e["noise_floor"] = {"nb0_A_aa_last256": ((perb.get("A") or {}).get("aa") or {}).get(band),
                                "nb0_A_aa_full": ((perb.get("A") or {}).get("aa_full") or {}).get(band),
                                "k_aa_last256": cmp_last256(kf, kr) if kf and kr else None,
                                "k_aa_full": cmp_full(kf["arr"], kr["arr"], bins=False) if kf and kr else None,
                                "nb0_cross_request_2k_prefix": ((perb.get("A") or {}).get("prefix_consistency") or {}).get("2k~8k")}
            an["tf_k_vs_A"][band] = e
        an["tf_reading"] = KL.tf_reading(an["tf_k_vs_A"])
        an["tf_k2_vs_C_40k"] = cmp_pair(_arr("C", "40k"), _arr("K2", "40k"), yb("CD", "40k"))
        an["tf_k2_vs_k_40k_mtp_effect"] = dict(cmp_pair(_arr("K", "40k"), _arr("K2", "40k")), nb0_AC_40k=yb("AC", "40k"))
        k0, k = _arr("K0", "90k"), _arr("K", "90k")
        an["tf_k0_vs_k_90k_cross_boot"] = cmp_full(k0["arr"], k["arr"], bins=False) if k0 and k else {"status": "INCONCLUSIVE_MISSING_TF"}
        sc = {}
        for band in NB0["sc_bands"]:
            a, x = (SCR.get("A") or {}).get(band), (SCR.get("K") or {}).get(band)
            r = {"nb0_A_decode_vs_tf": ((perb.get("A") or {}).get("sc") or {}).get(band)}
            if x:
                r["k_decode_vs_tf"] = sc_compare(x["cold"], x["tf"], x["P"])
                r["k_cold_vs_cached"] = decode_compare(x["cold"], x["cached"])
                same_prompt = a is not None and x["cold"]["meta"].get("prompt_sha256") == a["cold"]["meta"]["prompt_sha256"]
                r["greedy_vs_A"] = decode_compare(a["cold"], x["cold"]) if same_prompt else {"status": "INCONCLUSIVE_PROMPT_MISMATCH"}
            sc[band] = r
        an["self_consistency"] = sc
        an["capacity"] = {k: (RECS.get(k) or {}).get("capacity") for k in ("K0", "K", "K2")}
        an["memory_census"] = {k: dict((RECS.get(k) or {}).get("memory_census") or {}, free_mib_by_card=(RECS.get(k) or {}).get("free_mib_by_card_all"),
                                       kv_bytes=(RECS.get(k) or {}).get("kv_bytes")) for k in ("K0", "K", "K2")}
        k2 = RECS.get("K2") or {}
        an["speed"] = {"windows": {w: {x: (v or {}).get(x) for x in ("status", "tok_s", "gen_tokens", "running_min", "running_max",
                                                                     "running_eq_level", "step_ms", "tick_ms", "cycle_ms", "mean_acceptance_length",
                                                                     "accept_per_draft", "accept_rate_per_position_incl_admission", "preemptions",
                                                                     "kv_usage_max", "prefill_tok_s_uncached")}
                                   for w, v in (k2.get("steady") or {}).items()},
                       "admission_64k": {x: (k2.get("admission_64k") or {}).get(x) for x in ("status", "n", "all_resident", "admission_sec",
                                                                                              "preemptions", "snapshot", "window")},
                       "long_120k": {x: ((RECS.get("K") or {}).get("long_120k") or {}).get(x) for x in
                                     ("verdict", "tokens", "finish", "ttft_sec", "prefill_tok_s", "decode_tok_s", "window_garbage")},
                       "references": RC2_WINDOWS}
        return an


    def boot_summary(o):
        o = o or {}
        return {k: o.get(k) for k in ("status", "correctness", "config_ok", "early_stop", "config_mismatch", "kv_bytes", "tries",
                                      "oom_at_launch", "error", "status_note", "postprocess_error")}


    REF.update(ok=False)
    K1["reference"] = ref_load()
    K1["prompt_identity"] = prompt_identity()
    log("K100 reference", json.dumps({k: K1["reference"].get(k) for k in ("ok", "why", "files")}), "| prompts",
        json.dumps({k: v for k, v in K1["prompt_identity"].items() if k != "sc"})[:600])
    save()


if not RERUN:
    # ==================================================================== CELL 8 — E25 klee100 main: gates, K0 -> pin ladder -> K -> K2, report
    if not RERUN and not os.environ.get("RC2_UNIT"):
        m = R["sections"]["A0"]["merge"]
        GATES["INPUTS"] = (bool(MERLIN_OK), None if MERLIN_OK else json.dumps(R["inputs"])[:400])
        GATES["OVERLAY_MERGE_K6"] = (m.get("ok") is True, m.get("why") or m.get("bad"))
        K_REC, K2_REC = None, None
        if all(ok for ok, _ in GATES.values()):
            rec = step("A0", "merlin_install", 10, lambda: {"install": (lambda e: {"ok": True, "tree": e["kv"].get("MERLIN_TREE")})(merlin_install())})
            GATES["MERLIN_INSTALL"] = (rec.get("status") == "DONE", rec.get("error"))
        if all(ok for ok, _ in GATES.values()):
            rec = step("A0", "patch_60490", 3, apply_60490)
            GATES["PATCH_60490"] = (rec.get("status") == "DONE" and rec.get("ok") is True, rec.get("error"))
        if all(ok for ok, _ in GATES.values()):
            ok, why = sha_gate(min(2400, max(60, left() - 3600)))
            R["setup"]["sha_gate"] = {"ok": ok, "why": why}
            GATES["DIGESTS_K7_K3"] = (ok, why)
            save()
        if all(ok for ok, _ in GATES.values()):
            b0 = k1_boot("K0", "k100_K0_probe_bf16_mtp0", False, K100["seqs_k"], FP8_CAPTURES, KV_DEFAULT,
                         "K0 probe: klee100, BF16 KV, MTP off, Merlin's BF16 pin, seqs 8 + FP8 captures (= NB0 A's config)")
            r0 = step("K", b0["name"], EST_MIN["K0"], lambda: run_k(b0, body_k0(b0)))
            RECS["K0"] = r0
            GATES["BOOT_K0_PROBE"] = (KL.boot_clean(r0), {k: r0.get(k) for k in ("status", "correctness", "early_stop", "config_mismatch", "error")})
            save()
        if all(ok for ok, _ in GATES.values()):
            lad = KL.pin_ladder(r0.get("free_mib_by_card_all") or r0.get("free_mib_by_card"), KV_DEFAULT, K100["fracs"],
                                K100["safety_mib"], K100["mtp_reserve_mib"])
            K1["pin_ladder"] = lad
            log("K100 pin ladder", json.dumps({k: lad.get(k) for k in ("ok", "steps", "headroom_mib_per_card", "binding_card", "why")}))
            steps_ = lad["steps"] or [{"frac": None, "kv_bytes": KV_DEFAULT, "gib": round(KV_DEFAULT / 2 ** 30, 3), "note": "no ladder gain: default pin"}]
            tries = []
            for st in steps_:
                b = k1_boot("K", f"k100_K_bf16_mtp0_pin{int(round(st['kv_bytes'] / 2 ** 30 * 100))}", False, K100["seqs_k"], FP8_CAPTURES,
                            st["kv_bytes"], f"K: klee100, BF16 KV, MTP off, pin {st['gib']} GiB (frac {st['frac']} of the K0 headroom)")
                r = step("K", b["name"], EST_MIN["K"], lambda b=b: run_k(b, body_k(b)))
                tries.append({"name": b["name"], "pin": st, "status": r.get("status"), "oom_at_launch": r.get("oom_at_launch"),
                              "kv_bytes_used": r.get("kv_bytes")})
                K_REC = r
                if not (r.get("status") == "LAUNCH_FAILED" and r.get("oom_at_launch")):
                    break
                log("K launch OOM at", st["gib"], "GiB: next ladder step")
            K1["k_tries"], RECS["K"] = tries, K_REC
            save()
            k_tf_oom = K_REC.get("status") == "TF_OOM" and K_REC.get("correctness") == "CLEAN"
            if KL.boot_clean(K_REC) or k_tf_oom:
                lower = None
                if k_tf_oom:                       # K's teacher-forced call died of OOM: K2 takes the next lower step (else Merlin's pin)
                    lower = next((x["kv_bytes"] for x in steps_ if x["kv_bytes"] < (K_REC.get("kv_bytes") or 0)), KV_DEFAULT)
                pin2 = KL.k2_pin_from_k(K_REC.get("free_mib_by_card_all") or K_REC.get("free_mib_by_card"), K_REC.get("kv_bytes"),
                                         K100["mtp_reserve_mib"], K100["k2_min_free_mib"], KV_DEFAULT, lower_pin=lower)
                K1["k2_pin"] = pin2
                b2 = k1_boot("K2", f"k100_K2_bf16_mtp3_pin{int(round(pin2['kv_bytes'] / 2 ** 30 * 100))}", True, K100["seqs_k2"], COMPILE_HI,
                             pin2["kv_bytes"], f"K2: klee100, BF16 KV, MTP K3, seqs 16 + captures to 64, pin {pin2['gib']} GiB ({pin2['rule']})")
                est2 = min(EST_MIN["K2"], max(24, int(left() / 60) - 6))     # K2 shrinks to the budget left (its body checks due())
                CAP_MIN["K2"] = est2 - 8
                K1["k2_budget_min"] = {"est": est2, "body_cap": CAP_MIN["K2"]}
                K2_REC = step("K2", b2["name"], est2, lambda: run_k(b2, body_k2(b2)))
                RECS["K2"] = K2_REC
            else:
                RECS["K2"] = K2_REC = {"status": "SKIPPED_DEPENDENCY", "why": f"boot K not clean: {boot_summary(K_REC)}"}
            save()
        try:
            R["analysis"] = an = k100_analysis()
        except Exception as e:
            R["analysis"] = an = {"error": f"{type(e).__name__}: {e}"[:600], "tb": traceback.format_exc()[-2500:]}
        FINAL = KL.final_label(GATES, K_REC, K2_REC, an.get("tf_reading"))
        R["minutes"] = round((time.time() - T_START) / 60, 1)
        R["host_phase"] = HOST_PHASE
        verdict = {"label": FINAL, "gates": {k: {"ok": v[0], "why": v[1]} for k, v in GATES.items()},
                   "boots": {"K0": boot_summary(RECS.get("K0")), "K": boot_summary(K_REC), "K2": boot_summary(K2_REC)},
                   "k_tries": K1.get("k_tries"), "pin_ladder": K1.get("pin_ladder"), "k2_pin": K1.get("k2_pin"),
                   "tf_reading": an.get("tf_reading"),
                   "tf_k_vs_A": {b: {x: (e or {}).get(x) for x in ("label_full", "label_last256", "yardstick_full")} | {
                       "full": {y: ((e or {}).get("full") or {}).get(y) for y in ("status", "mean_abs_dlogprob", "p99_abs_dlogprob", "rank1_agreement")},
                       "last256": {y: ((e or {}).get("last256") or {}).get(y) for y in ("status", "mean_abs_dlogprob", "p99_abs_dlogprob", "rank1_agreement")}}
                       for b, e in (an.get("tf_k_vs_A") or {}).items()},
                   "tf_k2_vs_C_40k": {x: (an.get("tf_k2_vs_C_40k") or {}).get(x) for x in ("label_full", "label_last256", "yardstick_full")},
                   "capacity": an.get("capacity"), "speed": an.get("speed"), "minutes": R["minutes"], "abort": ABORT["why"],
                   "accuracy": "NOT_TESTED: an ARC accuracy run is a separate step"}
        R["verdict"] = verdict
        save()
        (OUT / "k100_verdict.json").write_text(json.dumps(verdict, indent=1, default=str))
        write_fallback_submission()
        print(json.dumps(verdict, default=str)[:12000])
        print(f"@@K100 {FINAL['label']}@@", flush=True)
