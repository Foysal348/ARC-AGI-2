"""E25 klee100 load test: quick unit tests (seconds; local and in the Kaggle units kit, Py3.12).

  T1 model dir + K6           build_model_dir / k6_check: complete dir OK; one FP8 PLE link removed -> K6 fails; a dangling
                              link, the BF16 PLE shard in the index, a config without the FP8 PLE dtype -> fail
  T2 K6 before launch         the notebook's own merlin_fn_server (picked from the export) raises K6 before the RC2 / NB1
                              server function is called when one indexed shard is missing; calls it when complete
  T3 digests                  digest_plan on the real v2 manifest (23 files, the BF16 PLE shard excluded); verify_digests:
                              OK / one flipped byte / size / missing / threads
  T4 pin ladder + K2 pin      pin_ladder arithmetic (safety, PP1 reserve, fracs, align, min gain, fail closed), free_by_card,
                              k2_pin_from_k (same / lowered / floor / TF_OOM lower step)
  T5 TF comparison            NB0's own cmp_last256 / cmp_full / shift_check (picked from the export) + the lab's compare_tf on
                              NB0's REAL arrays: A/A = 0; A vs B (FP8 KV) reproduces NB0's recorded numbers when the local
                              NB0 output is present; synthetic shifts; prompt mismatch / NaN -> INCONCLUSIVE
  T6 labels                   tf_label / yardstick / tf_reading / final_label (never an accuracy PASS)
  T7 capacity + argv          the export's k100_capacity (RC2 FP8 numbers: P 149 MATCH, F 6), NB0's nb0_argv on RC2's argv
  T8 build facts              the embedded PIN = the dataset SHA256SUMS + the v2 overlay shas; notebook < 400 kB; RERUN guard
Run: python k100load_unit_tests.py   (env K100_TEST_* override the paths; prints 'N/M PASS')
"""
import ast
import hashlib
import json
import math
import os
import re
import runpy
import shutil
import statistics
import sys
import tempfile
import traceback
import types
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import k100load_lib as KL  # noqa: E402

EXPORT = Path(os.environ.get("K100_TEST_EXPORT") or HERE / "k100load_code_export.py")
REF = Path(os.environ.get("K100_TEST_REF") or r"D:/ARC AGI 2/_scratch/push_e25/ds_e25_nb0_tf_ref")
LAB = Path(os.environ.get("K100_TEST_LAB") or r"D:/ARC AGI 2/experiments/Experiment 23 - Six levers vLLM 0.32 (planned)/src/e23_lab.py")
DIGESTS = Path(os.environ.get("K100_TEST_DIGESTS") or r"D:/ARC AGI 2/_scratch/e25_kits_out_klee_v2/q27-e25-klee100-cpu-kit/klee100_shard_digests.json")
NB0_RAW = Path(os.environ.get("K100_TEST_NB0_RAW") or r"D:/ARC AGI 2/_scratch/e25_gpu_out/q27-xhigh-e25-nb0-fp8-quality/nb0/tf_raw")
NB_PATH = Path(os.environ.get("K100_TEST_NB") or HERE.parent / "Q27-XHIGH-E25_KLEE100_LOAD.ipynb")
TMP = Path(tempfile.mkdtemp(prefix="k100u_"))
RES = []


def check(name, cond, info=""):
    RES.append((name, bool(cond)))
    print(("PASS " if cond else "FAIL ") + name + ("" if cond else f"  | {info}"), flush=True)


def run(name, fn):
    try:
        fn()
    except Exception as e:
        RES.append((name, False))
        print(f"FAIL {name} raised {type(e).__name__}: {e}\n{traceback.format_exc()[-1500:]}", flush=True)


def sha(b):
    return hashlib.sha256(b).hexdigest()


# ---------------------------------------------------------------- export helpers: definitions inside `if not RERUN:` blocks
EXPORT_SRC = EXPORT.read_text(encoding="utf-8")
_TREE = ast.parse(EXPORT_SRC)


def defs(name):
    """Every (def / class / assignment) node defining `name` at module level or one level inside an `if` block."""
    out = []
    for node in _TREE.body:
        for n in ([node] + (node.body if isinstance(node, ast.If) else [])):
            if isinstance(n, (ast.FunctionDef, ast.ClassDef)) and n.name == name:
                out.append(n)
            elif isinstance(n, ast.Assign) and name in {x.id for t in n.targets for x in ast.walk(t) if isinstance(x, ast.Name)}:
                out.append(n)
    return out


def src_of(name, which=-1):
    d = defs(name)
    assert d, f"{name} not in the export"
    return textwrap_dedent(ast.get_source_segment(EXPORT_SRC, d[which]))


def textwrap_dedent(s):
    import textwrap
    first = s.splitlines()[0]
    ind = len(first) - len(first.lstrip())
    return textwrap.dedent((" " * ind) + s) if ind == 0 else textwrap.dedent(s)


def load(names, ns, which=None):
    for n in names:
        code = src_of(n, (which or {}).get(n, -1))
        exec(compile(code, f"<export {n}>", "exec"), ns)
    return ns


def lab():
    return types.SimpleNamespace(**runpy.run_path(str(LAB), run_name="e23_lab_test"))


# ======================================================================================== T1 model dir + K6
def mk_fake():
    base = TMP / "t1"
    shutil.rmtree(base, ignore_errors=True)
    k, p, o = base / "k100", base / "ple", base / "ovl"
    for d in (k, p, o):
        d.mkdir(parents=True)
    for n in ("model-00002-of-00011.safetensors", "mtp-model-00001-of-00002.safetensors", "tokenizer.json", "KAGGLE_MIRROR_MANIFEST.json"):
        (k / n).write_bytes(n.encode() * 3)
    (k / "config.json").write_text(json.dumps({"text_config": {}}))                      # the published config (replaced)
    (k / "model.safetensors.index.json").write_text(json.dumps({"weight_map": {"x": "model-00001-of-00011.safetensors"}}))
    for n in ("model-plefp8-00000.safetensors", "model-plefp8-00001.safetensors"):
        (p / n).write_bytes(n.encode())
    (o / "config.json").write_text(json.dumps({"text_config": {"ple_embedding_dtype": "float8_e4m3fn"}}))
    (o / "quantization_config.json").write_text("{}")
    (o / "model.safetensors.index.json").write_text(json.dumps({"weight_map": {
        "a": "model-00002-of-00011.safetensors", "b": "mtp-model-00001-of-00002.safetensors",
        "c": "model-plefp8-00000.safetensors", "d": "model-plefp8-00001.safetensors"}}))
    return base, k, p, o


def _link():
    """os.symlink when this host allows it (Linux / Kaggle), else a copy (a Windows host without the privilege)."""
    t = TMP / "linkprobe"
    try:
        (TMP / "linksrc").write_text("x")
        os.symlink(str(TMP / "linksrc"), str(t))
        return os.symlink, True
    except OSError:
        return (lambda a, b: shutil.copyfile(a, b)), False


LINK, SYMLINKS = _link()


def t1():
    base, k, p, o = mk_fake()
    d = base / "ckpt"
    md = KL.build_model_dir(d, k, p, o, ["model-plefp8-00000.safetensors", "model-plefp8-00001.safetensors"], link=LINK)
    check("T1 build_model_dir ok", md["ok"] and len(md["ple_links"]) == 2 and len(md["klee100_links"]) == 4, md)
    check("T1 overlay replaces the published config / index",
          json.loads((d / "config.json").read_text())["text_config"].get("ple_embedding_dtype") == "float8_e4m3fn"
          and "c" in json.loads((d / "model.safetensors.index.json").read_text())["weight_map"])
    k6 = KL.k6_check(d)
    check("T1 K6 complete dir ok", k6["ok"] and k6["index_files"] == 4 and not k6["missing"], k6)
    (d / "model-plefp8-00001.safetensors").unlink()
    k6 = KL.k6_check(d)
    check("T1 K6 one PLE link removed -> fail", not k6["ok"] and k6["missing"] == ["model-plefp8-00001.safetensors"]
          and k6["why"].startswith("K6_INDEXED_SHARD_MISSING"), k6)
    if SYMLINKS:
        md = KL.build_model_dir(d, k, p, o, ["model-plefp8-00000.safetensors", "model-plefp8-00001.safetensors"], link=LINK)
        (p / "model-plefp8-00000.safetensors").rename(p / "gone")
        k6 = KL.k6_check(d)
        check("T1 K6 dangling symlink -> missing", not k6["ok"] and "model-plefp8-00000.safetensors" in k6["missing"], k6)
        (p / "gone").rename(p / "model-plefp8-00000.safetensors")
    else:
        check("T1 K6 dangling symlink (host has no symlink privilege: copy mode)", True)
    md = KL.build_model_dir(d, k, p, o, ["model-plefp8-00000.safetensors", "model-plefp8-00001.safetensors"], link=LINK)
    idx = json.loads((d / "model.safetensors.index.json").read_text())
    idx["weight_map"]["e"] = "model-00001-of-00011.safetensors"
    (d / "model.safetensors.index.json").write_text(json.dumps(idx))
    (d / "model-00001-of-00011.safetensors").write_bytes(b"x")
    k6 = KL.k6_check(d)
    check("T1 K6 index naming the BF16 PLE shard -> fail", not k6["ok"] and k6["bf16_ple_referenced"], k6)
    md = KL.build_model_dir(d, k, p, o, ["model-plefp8-00000.safetensors", "model-plefp8-00001.safetensors"], link=LINK)
    (d / "config.json").write_text(json.dumps({"text_config": {}}))
    k6 = KL.k6_check(d)
    check("T1 K6 config without the FP8 PLE dtype -> fail", not k6["ok"] and "ple_embedding_dtype" in k6["why"], k6)
    md = KL.build_model_dir(d, k, p, o, ["model-plefp8-00000.safetensors", "model-plefp8-00009.safetensors"], link=LINK)
    check("T1 build_model_dir missing PLE source -> not ok", not md["ok"] and any("00009" in e for e in md["errors"]), md)
    check("T1 rebuild removes stale entries", not (d / "model-00001-of-00011.safetensors").exists())


# ======================================================================================== T2 K6 before launch (the export's code)
def t2():
    base, k, p, o = mk_fake()
    d = base / "ckpt2"
    KL.build_model_dir(d, k, p, o, ["model-plefp8-00000.safetensors", "model-plefp8-00001.safetensors"], link=LINK)
    calls = []

    class S:
        argv = ["vllm", "serve", "--speculative-config", "{}", "--max-num-seqs", "3", "--compilation-config", "{}",
                "--enable-prefix-caching", "--kv-cache-memory-bytes", "123"]
        env = {"VLLM_X": "1"}
    ns = {"KL": KL, "CKPT": d, "K1": {}, "K1BOOTS": {"n": {"key": "K0", "name": "n", "mtp": False, "seqs": 8, "captures": "{\"c\":1}",
                                                          "title": "t"}},
          "save": lambda: None, "R": {"setup": {}}, "os": os, "time": __import__("time"), "threading": __import__("threading"),
          "json": json, "ENV_KEYS": ("VLLM_",), "K100": {"ready_sec": 10}, "left": lambda: 1e6,
          "config_diff": lambda *a: {"stub": True}, "load_monitor": lambda *a: None,
          "_merlin_fn_server_nb1": lambda *a: (calls.append(a), S())[1]}
    os.environ["RC2_CPU_KIT"] = "1"
    load(["flags", "_set_value", "nb0_argv"], ns)
    load(["merlin_fn_server"], ns)                     # the LAST definition = CELL 7's K6-guarded rebinding
    s = ns["merlin_fn_server"]("n", "bf16", 8020, 123)
    check("T2 complete dir: server function called once, MTP off removes --speculative-config, seqs 8",
          len(calls) == 1 and "--speculative-config" not in s.argv and s.argv[s.argv.index("--max-num-seqs") + 1] == "8"
          and s.argv[s.argv.index("--compilation-config") + 1] == "{\"c\":1}", s.argv)
    (d / "model-plefp8-00000.safetensors").unlink()
    try:
        ns["merlin_fn_server"]("n", "bf16", 8020, 123)
        raised = None
    except RuntimeError as e:
        raised = str(e)
    check("T2 one PLE link removed: K6 raises before launch, server function NOT called",
          raised is not None and raised.startswith("K6_INDEXED_SHARD_MISSING") and len(calls) == 1, raised)
    check("T2 K6 recorded per boot", ns["K1"]["k6_before_launch"]["n"]["ok"] is False)


# ======================================================================================== T3 digests
def t3():
    man = json.loads(DIGESTS.read_text())
    plan = KL.digest_plan(man, "/k", "/p")
    names = [x[0] for x in plan]
    check("T3 real manifest plan: 12 klee100 shards + tokenizer.json + 10 FP8 PLE, BF16 PLE excluded",
          len(plan) == 23 and KL.BF16_PLE_SHARD not in names and "tokenizer.json" in names
          and sum(n.startswith("model-plefp8-") for n in names) == 10, names)
    check("T3 plan bytes ~101.8 GB (50.6 klee100 + 51.2 FP8 PLE)", 101e9 < sum(x[2] for x in plan) < 103e9, sum(x[2] for x in plan))
    d = TMP / "t3"
    d.mkdir(exist_ok=True)
    files = {}
    for i in range(5):
        b = os.urandom(3_000_000 + i)
        (d / f"f{i}").write_bytes(b)
        files[f"f{i}"] = b
    fake = [(n, str(d / n), len(b), sha(b), "t") for n, b in files.items()]
    r = KL.verify_digests(fake, threads=3)
    check("T3 verify all OK", r["ok"] and r["n_checked"] == 5 and not r["bad"], r)
    b = bytearray(files["f2"])
    b[12345] ^= 1
    (d / "f2").write_bytes(bytes(b))
    r = KL.verify_digests(fake, threads=3)
    check("T3 one flipped byte -> mismatch", not r["ok"] and r["bad"] == ["f2"] and "sha256" in r["files"]["f2"]["why"], r["files"]["f2"])
    (d / "f2").write_bytes(files["f2"] + b"x")
    r = KL.verify_digests(fake, threads=3)
    check("T3 size difference -> fail before hashing", not r["ok"] and r["files"]["f2"]["why"].startswith("size"), r["files"]["f2"])
    (d / "f2").unlink()
    r = KL.verify_digests(fake, threads=3)
    check("T3 missing file -> fail", not r["ok"] and r["files"]["f2"]["why"] == "missing")
    check("T3 empty plan -> not ok", KL.verify_digests([], threads=2)["ok"] is False)


# ======================================================================================== T4 pin ladder + K2 pin
def t4():
    MiB, base = 2 ** 20, 2464415744
    free = {0: 7000.0, 1: 7010.0, 2: 6800.0, 3: 6810.0}
    lad = KL.pin_ladder(free, base, (0.9, 0.8, 0.7), 1024, 1192)
    head = {0: 7000 - 1024, 1: 7010 - 1024, 2: 6800 - 1024 - 1192, 3: 6810 - 1024 - 1192}
    want = [int((base + int(f * min(head.values()) * MiB)) // (2 * MiB) * (2 * MiB)) for f in (0.9, 0.8, 0.7)]
    check("T4 ladder: min headroom on PP1 (reserve) card 2", lad["ok"] and lad["binding_card"] == 2
          and lad["headroom_min_mib"] == min(head.values()), lad)
    check("T4 ladder steps exact + descending + 2 MiB aligned", [s["kv_bytes"] for s in lad["steps"]] == want
          and all(s["kv_bytes"] % (2 * MiB) == 0 for s in lad["steps"]) and want[0] > want[1] > want[2] > base, lad["steps"])
    check("T4 ladder: missing card -> fail closed", not KL.pin_ladder({0: 7000, 1: 7000, 2: 7000}, base)["ok"])
    check("T4 ladder: NaN -> fail closed", not KL.pin_ladder({0: 7000, 1: float("nan"), 2: 7000, 3: 7000}, base)["ok"])
    small = KL.pin_ladder({0: 1300, 1: 1300, 2: 2600, 3: 2600}, base, safety_mib=1024, reserve_mib_pp1=1192)
    check("T4 ladder: headroom < min gain -> no steps", not small["ok"] and small["steps"] == [], small)
    check("T4 stage_of_card", [KL.stage_of_card(i) for i in range(4)] == [0, 0, 1, 1])
    fb = KL.free_by_card([[[0, 100, 23034], [1, 200, 23034]], None, [[0, 300, 23034], [1, 50, 23034]]])
    check("T4 free_by_card takes the highest use", fb == {0: 23034 - 300, 1: 23034 - 200}, fb)
    pin = want[0]
    ok = KL.k2_pin_from_k({0: 2000, 1: 2000, 2: 2000, 3: 2000}, pin, 1192, 512, base)
    check("T4 k2 pin: K free covers the reserve -> same pin", ok["kv_bytes"] == pin and ok["rule"] == "SAME_PIN_AS_K", ok)
    lo = KL.k2_pin_from_k({0: 2000, 1: 2000, 2: 1500, 3: 1600}, pin, 1192, 512, base)
    check("T4 k2 pin: deficit 204 MiB on card 2 -> lowered by >= 204 MiB, aligned",
          lo["rule"].startswith("LOWERED") and pin - lo["kv_bytes"] >= 204 * MiB and pin - lo["kv_bytes"] < 207 * MiB
          and lo["kv_bytes"] % (2 * MiB) == 0, lo)
    fl = KL.k2_pin_from_k({0: 0, 1: 0, 2: 0, 3: 0}, base + 10 * MiB, 1192, 512, base)
    check("T4 k2 pin: never below the floor", fl["kv_bytes"] == base, fl)
    tf = KL.k2_pin_from_k({0: 2000, 1: 2000, 2: 2000, 3: 2000}, pin, 1192, 512, base, lower_pin=want[1])
    check("T4 k2 pin: K TF_OOM -> the next lower step", tf["kv_bytes"] == want[1] and tf["rule"].startswith("K_TF_OOM"), tf)


# ======================================================================================== T5 TF comparison (NB0's own code)
def tf_ns():
    ns = {"np": np, "math": math, "json": json, "hashlib": hashlib, "statistics": statistics, "L": lab(),
          "NB0": {"last": 256}, "SCREEN": KL.SCREEN}
    load(["_finite", "ids_sha", "e23_rows", "cmp_last256", "chunk_check", "cmp_full", "shift_check", "screen"], ns)
    return ns


def rec(path, ns):
    z = np.load(path)
    a = {k: z[k] for k in z.files}
    return {"meta": {"prompt_sha256": ns["ids_sha"](a["ids"])}, "arr": a}


def t5():
    ns = tf_ns()
    meta = json.loads((REF / "nb0_reference.json").read_text())
    for band in ("2k", "8k", "40k", "90k"):
        f, r = rec(REF / f"A_{band}_fresh.npz", ns), rec(REF / f"A_{band}_repeat.npz", ns)
        full, last = ns["cmp_full"](f["arr"], r["arr"]), ns["cmp_last256"](f, r)
        check(f"T5 A/A {band}: 0 / 1.0 (NB0's recorded A/A) -> LOWBIT_TF_CLOSE",
              full["mean_abs_dlogprob"] == 0 and full["rank1_agreement"] == 1.0 and last["status"] == "MEASURED"
              and KL.tf_label(full) == "LOWBIT_TF_CLOSE" and f["meta"]["prompt_sha256"] == meta["tf"]["A"][band]["prompt_sha256"],
              (full.get("mean_abs_dlogprob"), full.get("rank1_agreement"), last.get("status")))
    a40 = rec(REF / "A_40k_fresh.npz", ns)
    c40 = rec(REF / "C_40k_fresh.npz", ns)
    ac = ns["cmp_full"](a40["arr"], c40["arr"])
    check("T5 A vs C at 40k = 0 (NB0's AC)", ac["mean_abs_dlogprob"] == 0 and ac["rank1_agreement"] == 1.0, ac)
    yAB = meta["yardstick"]["pairs"]["AB"]["bands"]
    if (NB0_RAW / "B_40k_fresh.npz").is_file():
        for band in ("2k", "8k", "40k", "90k"):
            b = rec(NB0_RAW / f"B_{band}_fresh.npz", ns)
            a = rec(REF / f"A_{band}_fresh.npz", ns)
            full, last = ns["cmp_full"](a["arr"], b["arr"]), ns["cmp_last256"](a, b)
            yf, yl = yAB[band]["full"], yAB[band]["last256"]
            check(f"T5 A vs B (FP8 KV) {band} reproduces NB0's recorded full + last256",
                  all(full[k] == yf[k] for k in ("mean_abs_dlogprob", "p99_abs_dlogprob", "rank1_agreement"))
                  and all(last[k] == yl[k] for k in ("mean_abs_dlogprob", "p99_abs_dlogprob", "rank1_agreement")),
                  ({k: full[k] for k in ("mean_abs_dlogprob", "rank1_agreement")}, yf))
        b40 = rec(NB0_RAW / "B_40k_fresh.npz", ns)
        full = ns["cmp_full"](a40["arr"], b40["arr"])
        check("T5 the FP8-KV 40k divergence labels DIVERGENT (full) / SEVERE (last256 rank-1 0.367)",
              KL.tf_label(full) == "LOWBIT_TF_DIVERGENT" and KL.tf_label(ns["cmp_last256"](a40, b40)) == "LOWBIT_TF_DIVERGENT_SEVERE")
    else:
        check("T5 A vs B reproduction (local NB0 output not present: skipped)", True)
    syn = {k: v.copy() for k, v in a40["arr"].items()}
    syn["lp"] = syn["lp"] + np.float32(0.05)
    full = ns["cmp_full"](a40["arr"], syn)
    check("T5 synthetic +0.05 logprob -> mean 0.05, CLOSE", abs(full["mean_abs_dlogprob"] - 0.05) < 1e-3 and KL.tf_label(full) == "LOWBIT_TF_CLOSE", full)
    syn2 = {k: v.copy() for k, v in a40["arr"].items()}
    idx = np.arange(1, len(syn2["top1"]))[::5]
    syn2["top1"][idx] = syn2["top1"][idx] + 1
    full = ns["cmp_full"](a40["arr"], syn2)
    check("T5 synthetic rank-1 changed on 20 % -> DIVERGENT", 0.79 < full["rank1_agreement"] < 0.81 and KL.tf_label(full) == "LOWBIT_TF_DIVERGENT", full)
    syn3 = {k: v.copy() for k, v in a40["arr"].items()}
    syn3["ids"][100] += 1
    check("T5 different prompt ids -> INCONCLUSIVE_PROMPT_MISMATCH", ns["cmp_full"](a40["arr"], syn3)["status"] == "INCONCLUSIVE_PROMPT_MISMATCH"
          and KL.tf_label(ns["cmp_full"](a40["arr"], syn3)) == "INCONCLUSIVE_PROMPT_MISMATCH")
    syn4 = {k: v.copy() for k, v in a40["arr"].items()}
    syn4["lp"][500] = np.nan
    check("T5 NaN in a valid position -> INCONCLUSIVE_NONFINITE", ns["cmp_full"](a40["arr"], syn4)["status"] == "INCONCLUSIVE_NONFINITE")
    sh = ns["shift_check"](a40["arr"], a40["arr"])
    check("T5 shift check: identical arrays best shift 0, no artefact", sh["best_shift"] == 0 and not sh["alignment_artefact"], sh)


# ======================================================================================== T6 labels
def t6():
    L_ = KL.tf_label
    check("T6 tf_label edges", L_({"status": "MEASURED", "mean_abs_dlogprob": 0.15, "rank1_agreement": 0.90}) == "LOWBIT_TF_CLOSE"
          and L_({"status": "MEASURED", "mean_abs_dlogprob": 0.151, "rank1_agreement": 0.95}) == "LOWBIT_TF_DIVERGENT"
          and L_({"status": "MEASURED", "mean_abs_dlogprob": 0.10, "rank1_agreement": 0.899}) == "LOWBIT_TF_DIVERGENT"
          and L_({"status": "MEASURED", "mean_abs_dlogprob": 1.01, "rank1_agreement": 0.95}) == "LOWBIT_TF_DIVERGENT_SEVERE"
          and L_({"status": "MEASURED", "mean_abs_dlogprob": 0.2, "rank1_agreement": 0.49}) == "LOWBIT_TF_DIVERGENT_SEVERE"
          and L_({"status": "MEASURED", "mean_abs_dlogprob": float("nan"), "rank1_agreement": 0.9}) == "INCONCLUSIVE_NONFINITE"
          and L_(None) == "INCONCLUSIVE_MISSING" and L_({"status": "INCONCLUSIVE_MISSING_TF"}) == "INCONCLUSIVE_MISSING_TF")
    y = {"mean_abs_dlogprob": 0.93, "rank1_agreement": 0.75, "p99_abs_dlogprob": 6.2}
    check("T6 yardstick BELOW / ABOVE / MIXED / INCONCLUSIVE",
          KL.yardstick({"mean_abs_dlogprob": 0.3, "rank1_agreement": 0.9}, y)["vs_nb0_fp8_kv"] == "BELOW_NB0_FP8_KV"
          and KL.yardstick({"mean_abs_dlogprob": 1.3, "rank1_agreement": 0.6}, y)["vs_nb0_fp8_kv"] == "ABOVE_NB0_FP8_KV"
          and KL.yardstick({"mean_abs_dlogprob": 0.3, "rank1_agreement": 0.6}, y)["vs_nb0_fp8_kv"] == "MIXED"
          and KL.yardstick({"status": "INCONCLUSIVE"}, y)["vs_nb0_fp8_kv"] == "INCONCLUSIVE")
    r = KL.tf_reading({"2k": {"label_full": "LOWBIT_TF_CLOSE"}, "8k": {"label_full": "LOWBIT_TF_DIVERGENT"},
                       "40k": {"label_full": "LOWBIT_TF_CLOSE"}, "90k": {"label_full": "INCONCLUSIVE_MISSING"}})
    check("T6 tf_reading = worst measured band, incomplete listed", r["reading"] == "LOWBIT_TF_DIVERGENT" and r["worst_band"] == "8k"
          and r["incomplete"] == ["90k"], r)
    check("T6 tf_reading nothing measured", KL.tf_reading({"2k": {"label_full": "INCONCLUSIVE_MISSING"}})["reading"] == "TF_NOT_MEASURED")
    clean = {"status": "DONE", "correctness": "CLEAN", "config_ok": True}
    tfr = {"reading": "LOWBIT_TF_DIVERGENT"}
    f1 = KL.final_label({"INPUTS": (True, None), "DIGESTS_K7_K3": (False, "sha256 mismatch")}, clean, clean, tfr)
    f2 = KL.final_label({"INPUTS": (True, None)}, {"status": "TF_OOM", "correctness": "CLEAN", "config_ok": True}, clean, tfr)
    f3 = KL.final_label({"INPUTS": (True, None)}, clean, {"status": "NO_GO_GARBAGE_UNDER_LOAD", "correctness": "NO_GO_GARBAGE_UNDER_LOAD"}, tfr)
    f4 = KL.final_label({"INPUTS": (True, None)}, clean, clean, tfr)
    f5 = KL.final_label({"INPUTS": (True, None)}, {"status": "CONFIG_MISMATCH", "correctness": "INCONCLUSIVE_NO_ORACLE"}, None, tfr)
    check("T6 final label: the first failing gate", f1["label"] == "FAIL_DIGESTS_K7_K3", f1)
    check("T6 final label: K not clean", f2["label"] == "FAIL_BOOT_K_TF_OOM" and f5["label"] == "FAIL_BOOT_K_CONFIG_MISMATCH", (f2, f5))
    check("T6 final label: K2 failing -> MTP off only", f3["label"] == "GPU_LOAD_PASS_MTP_OFF_ONLY + LOWBIT_TF_DIVERGENT", f3)
    check("T6 final label: all clean", f4["label"] == "GPU_LOAD_PASS + LOWBIT_TF_DIVERGENT", f4)
    check("T6 never an accuracy PASS", all("PASS" not in x["accuracy"] and "ACCURACY" not in x["label"] for x in (f1, f2, f3, f4, f5)))


# ======================================================================================== T7 capacity + argv (the export's code)
def t7():
    ns = {"math": math, "re": re, "json": json, "statistics": statistics, "BLOCK": 4096, "F_MAX_BLOCKS": 40, "WIN": 90.0,
          "GEN_RATE": 45.0, "PREFILL": {"tok_s": 2000.0}, "BANDS": {"40k": 40000, "60k": 60000}, "K100": {"admission_max_new": 4096},
          "PROMPTS": {"40k": [0] * 16, "60k": [0] * 16}, "FP8_BLOCK_BYTES": 2479838700 / 150}
    load(["_f_valid", "f_from_log", "pool_blocks_from_usage", "n_fit", "residency_bound", "k100_capacity"], ns)
    o = {"pool": {"kv_tokens": 513940, "max_concurrency": 3.92, "max_concurrency_tokens": 131072},
         "caps": {"block_size": 4096, "max_num_seqs": 16}, "workers": {"num_gpu_blocks": [150, 150, 150, 150]}}
    us = [k / 149 for k in (3, 17, 40, 41, 77)]
    cap = ns["k100_capacity"](o, us, 2479838700)
    check("T7 capacity on RC2 FP8 numbers: P 149 MATCH, F 6 (NB1's B1 / RC2 rule)",
          cap["pool_blocks"] == 149 and cap["pool_check"] == "MATCH" and cap["F"] == 6, cap)
    check("T7 capacity: n40 / n64 / fp8 equivalence", isinstance(cap["n40"], int) and cap["n64"] == 149 // (16 + 6)
          and abs(cap["fp8_equivalent_blocks_of_pin"] - 150.0) < 0.01, cap)
    cap2 = ns["k100_capacity"](dict(o, workers={"error": "x"}), [], 2479838700)
    check("T7 capacity: no pool reading -> F None, no stream counts", cap2["pool_blocks"] is None and cap2["F"] is None and "n40" not in cap2, cap2)
    ref = json.loads(json.loads(re.search(r'RC2_REF = json\.loads\((".*?")\)\s', EXPORT_SRC).group(1)))
    ns2 = {}
    load(["flags", "_set_value", "nb0_argv"], ns2)
    a = list(ref["bf16"]["argv_tail"])
    off = ns2["nb0_argv"](a, {"mtp": False, "seqs": 8, "captures": "CAPS"})
    on = ns2["nb0_argv"](a, {"mtp": True, "seqs": 16, "captures": "HI"})
    check("T7 nb0_argv on RC2's real BF16 argv: MTP off / seqs / captures",
          "--speculative-config" not in off and ns2["flags"](off)["--max-num-seqs"] == "8" and ns2["flags"](off)["--compilation-config"] == "CAPS"
          and "--speculative-config" in on and ns2["flags"](on)["--max-num-seqs"] == "16" and ns2["flags"](on)["--kv-cache-dtype"] == "bfloat16")
    try:
        ns2["nb0_argv"](a + ["--max-num-seqs", "4"], {"mtp": True, "seqs": 16, "captures": None})
        dup = False
    except ValueError:
        dup = True
    check("T7 nb0_argv refuses a duplicated flag", dup)


# ======================================================================================== T8 build facts
def t8():
    pin = json.loads(json.loads(re.search(r'K100_PIN = json\.loads\((".*?")\)\s', EXPORT_SRC).group(1)))
    sums = json.loads((REF / "SHA256SUMS.json").read_text())
    check("T8 embedded reference shas == the dataset SHA256SUMS", pin["ref_sha256"] == sums)
    check("T8 dataset files match SHA256SUMS", all(sha((REF / n).read_bytes()) == s for n, s in sums.items()))
    check("T8 embedded overlay shas = the v2 artifact", pin["overlay_sha256"]["config.json"].startswith("c78d48f3")
          and pin["overlay_sha256"]["model.safetensors.index.json"].startswith("c21d8c98")
          and pin["overlay_sha256"]["quantization_config.json"].startswith("e55659bc"))
    check("T8 klee100 input shas", pin["klee100_config_sha256"].startswith("fb17316d") and pin["klee100_index_sha256"].startswith("873191b5"))
    check("T8 digests sha = the v2 kit artifact", pin["digests_sha256"] == sha(DIGESTS.read_bytes()))
    if NB_PATH.is_file():
        nb = NB_PATH.read_bytes()
        check("T8 notebook < 400 kB, export == cells", len(nb) < 400_000 and "\n\n".join(
            "".join(c["source"]) for c in json.loads(nb)["cells"] if c["cell_type"] == "code") == EXPORT_SRC, len(nb))
        cells = ["".join(c["source"]) for c in json.loads(nb)["cells"] if c["cell_type"] == "code"]
    else:                                     # the Kaggle units kit carries the export only (the cells joined by blank lines)
        check("T8 notebook file not in this kit: the export's cells are checked", True)
        cells = [c if i == 0 else "if not RERUN:\n" + c for i, c in enumerate(EXPORT_SRC.split("\n\nif not RERUN:\n"))]
    check("T8 RERUN guard: cells 2-9 under `if not RERUN:`, cell 1 writes the fallback", len(cells) == 9 and all(
        c.startswith("if not RERUN:\n") for c in cells[1:]) and "write_fallback_submission()" in cells[0], len(cells))
    check("T8 main only without RC2_UNIT", 'if not RERUN and not os.environ.get("RC2_UNIT"):' in cells[-1])
    check("T8 no FP8 KV in any klee100 boot", '"kv": "bf16"' in EXPORT_SRC and 'run_k(b0' in EXPORT_SRC and "fp8_e4m3" not in src_of("k1_boot"))


for n, f in (("T1", t1), ("T2", t2), ("T3", t3), ("T4", t4), ("T5", t5), ("T6", t6), ("T7", t7), ("T8", t8)):
    run(n, f)
shutil.rmtree(TMP, ignore_errors=True)
ok = sum(1 for _, v in RES if v)
print(f"{ok}/{len(RES)} PASS", flush=True)
sys.exit(0 if ok == len(RES) else 1)
