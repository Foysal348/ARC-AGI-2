# Pre-GPU audit: E26 K100 QUALITY (klee100 low-bit Flash-Next, 15 ARC-AGI-2 tasks), 2026-11-01

All files are flat; read every file before answering. Prefixes:
- `NB__`: the notebook under audit and its build;
- `PAYLOAD__`: the new dataset files;
- `BASE__`: the proven notebooks it is built from;
- `CTX__`: measured results and raw output.

Start with one line: **GO / NO-GO**. Then report ONLY blockers:
- wrong raw data;
- a mid-run crash or hang;
- wasted GPU time;
- a misleading verdict or score;
- a broken submission in the competition's hidden rerun.

For each blocker give file:function/line, a concrete scenario, evidence (a reproduction or exact lines) and a minimal fix. Non-blocking notes go in a short list at the end.

## What the notebook does
`NB__Q27-XHIGH-E26_K100_QUALITY.ipynb` (sha 4506a71f, 387,539 B) runs 30 eval tasks: first NB5 QUALITY's 15 (same order, same Duck config, for a paired comparison), then 15 new ones chosen by the user to be the most informative:
- `hard_long` (10): 3dc255db, 7491f3cf, d59b0160, 35ab12c3, e8686506, 7666fa5d, 898e7135, edb79dae, 2d0172a1, 8e5c0c38. Each needs long reasoning: 27B Duck R3K2 used the whole 50,000-token attempt 1 and failed, but ARC Prize Qwen3.8-27B xhigh solved it.
- `sometimes_new` (5): 136b0064, db0c5428, 800d221b, a395ee82, 20270e3b. 27B solved these, but not easily.

The only engine difference from NB5 is the checkpoint, klee100:
- routed experts W3 g128 (layers 0-11, 36-47) and W2 g64 (layers 12-35);
- MTP W4;
- an FP8 PLE graft and fixkeys.

It is served by Merlin v3.0.0 (a vLLM 0.32 fork), TP2×PP2+EP, FP8 E4M3 QSA KV with static scales, MTP K3, on Kaggle 4×L4.

**The question:** does klee100 keep ARC accuracy? Reference: NB5 W4 FP8 solved 13/15, with 18/20 queries.

**Why it matters:** klee100 is about 2-2.5× faster and has a 2.24× bigger KV pool (`CTX__E26_K3ONLY_GPU_v2`). But its teacher-forced rank-1 agreement against W4 is only 0.51-0.65.

## Design (builder `NB__build_e26_k100_quality.py`; readable code in `NB__e26_k100q_code_export.py`)
- **Built from NB6** (`BASE__build_e25_nb6.py`, notebook 87afcc84, the proven submission notebook). The user's proven eval + private format is NB6's verbatim:
  - CELL 0 = E18 R2's cell 0;
  - commit = the eval subset, scored;
  - rerun = every test task in ORDER2 with E15B's writer;
  - E18 R2's server ladder and fast kill;
  - no sha gate in the rerun.
- **The klee100 pieces** (model merge / fixkeys / K6 / digests / scales sidecar / worker extension with the method map) are cut verbatim from `BASE__Q27-XHIGH-E25_KLEE100_LOAD_K3ONLY.ipynb` (7773e63f). That notebook booted on GPU with method map PASS.
- **One phase, `Q_K100_FP8_K3`:** NB5QUALITY_R2's row key for key:
  - the 15 tasks / order / seed 20261005;
  - 2 × 104k attempts, no stage 3;
  - a 6,600 s window (NB5: 4,050 s; the user's decision for 30 tasks), now with a 150-min budget (HARD_STOP at 145 min) plus an absolute deadman at 150 min;
  - variant A, FP8, MTP K3, #60490, `MERLIN_SHARE_DRAFT_WORKSPACE=1`.
- **Pin ladder:** 7,933,526,016 → 6,859,784,192 → 5,270,142,976 → 3,553,580,524 → 2,479,838,700 B.
  - max-num-seqs per rung = the workers by NB5's rule `floor(pool / (ceil(65536/4096) + F))`: 21 / 18 / 14 / 9 / 6.
  - Captures go to 84.
- **Gates before solving:** OVERLAY_MERGE_K6, the K7/K3 digests (commit), the worker extension, the scales sidecar, the config read-back, the method map gate_ok, STATIC_SCALES_APPLIED, and the probes. On failure: a NO_GO verdict, and CELL 0's fallback submission stays.
- **Report:** `NB__k100q_report.py`, `build_quality_report`.
  - It is tested to reproduce NB5's own FP8 record exactly when fed NB5's inputs (`NB__k100q_report_tests.py`, 50/50).
  - Output: a paired table (klee100 vs W4 per task / attempt / tokens), McNemar, deltas, and per-task finish times.
- **Payloads:** the klee100 blobs, `nb1_worker_ext` and `nb5_lib` are in the new dataset file `PAYLOAD__k100q_payload_emb.json` (sha fd92a814). It is sha-checked at load. This dataset version is staged, not pushed yet.
- **Hard stop:** 170 min (plan 157; about 135 expected). The tokens are tight: about 2.9M generated tokens need about 442 tok/s over the window, against a measured 431-562.
- **Report scope:** the W4 comparison (paired, McNemar, delta, the attempt-1 table) is restricted to NB5's 15. The 30-task klee100 summary is reported by group, with 27B R3K2 and ARC Prize columns for the new 15 (`NB__k100q_ref27b.json`). An independent reviewer found this scope blocker in the first build, and it is fixed and tested (`NB__REVIEW_internal.md`).
- **Tests:** unit tests 145/145, report tests 56/56 (`NB__e26_k100q_unit_tests.py`). The CPU kits are being built (NB6-style units / e2e-commit / e2e-rerun / real).

## Known risks (please judge)
1. **Preemption.** 21 workers × 104k attempts against a pool of 479 blocks (resident bound 13 at 120k): preemption could happen. Is it handled safely?
2. **No in-run pin step-down.** An OOM after the phase starts leads to NB5's relaunch at the base pin. Is that the right pin for klee100?
3. **Accuracy comparability.** The window is 6,600 s vs NB5's 4,050 s, and klee100 runs 21 workers vs W4's 9. Is the attempt-1 comparison on the old 15 still strictly fair?
4. **Self-nondeterminism.** klee100's fresh-vs-repeat teacher-forced rank-1 agreement is 0.86-0.95, while W4 is exactly 1.0. Does this break the seeded comparison or any gate?

## Questions
1. Is the proven format intact? Check CELL 0, the rerun path and the writer against `BASE__` and E18 R2.
2. Do the boot argv and env match the K3_ONLY boot that worked?
3. Does the Duck phase match NB5's FP8 phase exactly, except for the documented deviations (listed in `NB__DEVIATIONS.md`)?
4. Can the report mis-score?
5. GO / NO-GO for the GPU run.

## Fixes since the previous audit rounds (all were validated in the code first; the failure was reproduced before each fix)
- **A. Score-source mismatch.** When the run-report score and the score recomputed from the generated attempts disagree, errors gets SCORE_SOURCE_MISMATCH and the score is None. A `score_sources` label is added.
- **B. Failed phase.** A phase that is not DONE, or has an error, gets the status INCOMPLETE_PHASE. The report is kept for forensics only.
- **C. Missing query.** `nq = len(golds)`: a missing query counts as wrong, so 1 of 2 is 50 %. Tasks without gold are no longer in the denominator.
- **D. Relaunch.** The relaunch restores the exact booted config (pin bytes, seqs, captures, lever env) from `NB5_ACTIVE_BOOT`. NB6 itself is unchanged.
- **E. Matched window.** A new `paired_at_matched_4050s` block counts a klee100 attempt only if it ended at or before 4,050 s after the window start. The full-window pairing is labelled PAIRED_TASK_OUTCOME_DIFFERENT_WINDOWS. INCONCLUSIVE_NO_TIMING is used when the timing is missing.
- **F. Canonical units.** The units recomputed from gold + generated attempts are canonical. The run-report units are cross-checked (UNIT_RECORD_MISMATCH). Validity errors are added: MISSING_GOLD / MISSING_GENERATED / QUERY_COUNT_MISMATCH / INVALID_ATTEMPTS.
- **Final status order:** SKIPPED_RERUN, NO_PHASE_RUN, INCOMPLETE_PHASE, MISSING_RUN_REPORT, INVALID_MISSING_GOLD, INCONCLUSIVE_SCORE_MISMATCH, INVALID_QUALITY_REPORT, VALID.
- **Admit deadline (checked, not a risk).** ADMIT / DRAIN_DEADLINE are never read in cells 3-9, and a unit test enforces this. The window ends at min(start + 6,600 s, HARD_STOP − 180 s); a shortened window raises WINDOW SHORTENED.

## Kept on purpose (please do not re-raise without new evidence)
- **Rerun gates stay non-fatal.** This is NB5 / NB6's proven rule. In the hidden rerun, stopping only leaves the identity fallback (about zero score), so continuing can never be worse.
- **Workers stay at NB5's rule** (21 on rung 1). Preemptions and fresh-prefill tokens are reported in the CELL 9 K100 SUMMARY line.

The CPU kits (5) are now included as `KIT__*.ipynb`. They have not run on Kaggle yet: they need the staged dataset version first.

## Added in this revision: Q-defer (deferred PP receive)
- **Evidence:** the NB4S GPU run, `CTX__E25_NB4S_GPU_v1_2026-11-01.md` (on W4, 8 streams):
  - +21.1 % at 8k@8 and +19.8 % at 40k@8;
  - oracle EXACT;
  - stage-0 stall 19.8 → 0.035 ms;
  - read-back ENGAGED (exec share 0.965, fallback 0).
- **Implementation (`k100_setup`):**
  - `NB__nb4_ppack.py` (sha 8dadf076; identical to the tested NB4S file) is applied to the Merlin tree after the install, with pre / post shas of `pp_utils.py`, `model_runner.py` and `gpu_worker.py`.
  - `NB4_PPDEFER=1` is set only if the patch is verified.
  - If the apply fails, it reverts and continues without the patch (never fatal).
  - The relaunch keeps the env.
  - The read-back is recorded, never fatal.
  - `nb4_ppack.py` and `k100q_report.py` are now sha-pinned files of the staged dataset version, not embedded.
- **Comparison label:** "klee100 + Q-defer vs W4 (NB5 ran WITHOUT Q-defer)". Q-defer changes timing, not outputs, so the attempt-1 accuracy comparison stays valid.
- **Unverified:** Q-defer on klee100's humming low-bit experts, and at 21 streams. NB4S tested W4 at 8 streams.
- **Real kit:** applies the patch on the real installed Merlin tree, checks the post shas, reverts to the exact pre shas and re-applies. Every launch env has `NB4_PPDEFER=1`.

## Fixed after the three-notebook audit (G, H)
- **G. Partial-patch recovery.**
  - The three files are snapshotted before the apply.
  - On any failure they are restored in REVERSE dependency order (gpu_worker, model_runner, pp_utils), each atomically: sha checked, stale pyc dropped, then py_compile.
  - The restore stops at the first failing file, so the patched set always stays a prefix of [pp_utils, model_runner, gpu_worker]. That is consistent, because patched model_runner calls `pp_handler.flush_deferred_receive`, which exists only in patched pp_utils.
  - With `NB4_PPDEFER` unset, patched files behave identically to the originals. So the run continues (never raises; in the rerun a stop only leaves the identity fallback).
  - Statuses: APPLY_FAILED_RESTORED / _RESTORE_INCOMPLETE_CONSISTENT / _INCONSISTENT / _NOT_TOUCHED / _RESTORE_ERROR.
- **H. Short window.** `paired_at_matched_4050s` is INCONCLUSIVE_SHORT_WINDOW when the klee100 window `actual_sec` is missing or below 4,048 s. The full-window counts are kept.

## Fixed after audit rev 7 / round 6 (I, J)
- **I. Unverified Q-defer tree.**
  - The tree is trusted only if one of these holds:
    - status APPLIED and all three files at their post-shas;
    - all three files at Merlin's pre-shas, not applied, and no failed restore `py_compile`.
  - Anything else is unverified: an incomplete or inconsistent restore, a restore or `py_compile` error, a mixed or unknown tree.
  - In commit, an unverified tree raises `NO_GO_K100_QDEFER_TREE_UNVERIFIED` before any boot. The gate sits outside the broad try, so it cannot be swallowed, and CELL 0's fallback submission stays.
  - In the rerun, the same case is recorded loudly and the run continues without `NB4_PPDEFER`. This is the same rule as the k100 gates (the proven rule: a stop in the hidden rerun only leaves the identity fallback).
  - The trusted shas (`K100_QD_SHAS`) come from `nb4_ppack.PATCHES`, so the check works without the lib.
- **J. Accept time for the matched 4,050-s cutoff.**
  - Duck records `t` when verification starts (`arc2_duck.py:2505`) and `verify_sec` (:2554); the accept time is `t + verify_sec`.
  - The cutoff uses ACCEPT_TIME, or else REQUEST_END_PLUS_VERIFY. A deciding untimed attempt gives `INCONCLUSIVE_ACCEPT_TIME`.
  - On the real NB5 data the result is OK, with ACCEPT_TIME for every exact attempt.
- **Dataset:** the staged dataset version is now PUBLISHED on Kaggle (`foysalemonshanto/q27-e25-nb0-tf-ref`, 31 files). The pinned files: `nb4_ppack.py` 8dadf076, `k100q_report.py` 359629ec, `k100q_payload_emb.json` fd92a814.
- **CPU kits:** the 5 kits are running on Kaggle now (account esfersami50). The GPU run will use the same account.

## Added in this revision (sha 4506a71f): a 150-minute budget and a hard deadman (user request: max 2 h 30 min, must stop)
- **Budget:** 150 min with a 5-min hard margin. HARD_STOP is at T0 + 145 min, which is also when the server watchdog kills the live servers. The solve end is capped at HARD_STOP − 180 s. The window is still 6,600 s and is shortened only by a late boot (flagged WINDOW SHORTENED).
- **Deadman, commit only:**
  - It is the first code of CELL 1; CELL 0, which writes the fallback `submission.json`, runs before it.
  - It is a daemon thread that fires at T0 + 9,000 s. When it fires, it:
    1. writes the marker with `os.write` to fd 1 / fd 2 and to `/kaggle/working/k100q_deadman.txt` (with fsync);
    2. SIGKILLs every child via psutil, `os.killpg` on the server process groups, or `pkill -9 -f vllm`;
    3. calls `os._exit(0)`.
  - The rerun (RERUN_PROD, 717 min) has no deadman.
- **Tests:**
  - the placement and daemon flag;
  - the fire time;
  - the rerun has no deadman;
  - a real fire in a child process kills a dummy process group, writes the marker and exits 0.
- **The kit-only defects from the last Kaggle kit round are fixed. None of them was a notebook bug:**
  - `dataset-metadata.json` is not mounted by Kaggle, so it is excluded from the sha sets;
  - the e2e lever-env compare now allows the notebook's own `VLLM_SERVER_DEV_MODE`;
  - the speculative-config JSON is now parsed instead of string-matched;
  - the probe file `argparse.py` was shadowing the stdlib `argparse` and is renamed to `r6_argparse` (this caused the torch circular-import error and the method-map probe failure).
- The e2e kits now also check the deadman: armed, daemon, fire time, not fired during the run; and no deadman in the rerun.
