# Audit: klee100 compatibility CPU kit

Read `README.md`, the kit code in `build/` (k100kit_core / real / main + builder) and the inputs.

Answer:
1. Do the manifests and gates really prove, fail-closed, that every klee100 tensor is loaded into the right Merlin module with
   the right method? List any way a wrong bit-width, a wrong group size, a dropped tensor or a silent BF16 fallback could still
   pass.
2. Is the fixkeys overlay complete and correct (layer keys, MTP remap, block_name_to_quantize, PLE dtype, index graft)? Does
   anything in the author's patch need to be replicated that config cannot express?
3. Is the PLE graft safe? Look at the row mapping, the scales and the numeric comparison method.
4. Is the memory estimate (Gate D) sound enough to plan a GPU load test, and what must the GPU test measure?
5. Any blocker for running the kit on Kaggle: file:line, scenario, fix.
Output: `VERDICT: GO` (the kit is a valid gate) or `VERDICT: NO-GO`, then the blocker list, then the after-the-run list.
