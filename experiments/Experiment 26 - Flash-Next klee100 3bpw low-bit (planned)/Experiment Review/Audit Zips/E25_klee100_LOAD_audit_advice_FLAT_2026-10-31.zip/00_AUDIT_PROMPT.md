# Audit + advice request: E25 klee100 GPU load test notebook (2026-10-31)

All files in this zip are flat (no folders). Read every file before answering.

## Context
- **Competition:** Kaggle ARC-AGI-2. The hardware is 4×L4 (24 GB each, sm_89, PCIe, no P2P). The model is Qwen3.8-Flash-Next: 125B parameters, 6B active, 48 layers (36 GDN + 12 QSA), 512 experts top-10, hyper-connections, and a PLE table.
- **Engine:** Merlin v3.0.0, a vLLM 0.32 fork, running TP2×PP2+EP with MTP K3.
- **Target:** a whole-run average of 1500 tok/s. See `PLAN_1500.md`.
- **Current base (RC2):** the Intel-style W4 checkpoint with FP8 QSA KV. Its pool is 513,940 tokens (149 usable 4096-blocks, F = 6 fixed blocks per request). It reaches 259 tok/s at 8 streams.
- **Capacity is the binding term.** E23 FULL on the 27B shows throughput still rising up to 24 streams. FP8 QSA KV also diverges from BF16 on Flash-Next (NB0).
- **klee100 checkpoint** (`klee100/Qwen3.8-Flash-Next-AutoRound-3bpw-MTP`, rev 600715b3), with this layout:
  - routed experts W3 g128 on layers 0-11 / 36-47 and W2 g64 on layers 12-35;
  - MTP experts W4 g128;
  - main projections W8 GPTQ.
- **Why klee100:**
  - NB3 measured synthetic humming W2 at 0.60-0.70× and W3 at 0.84-0.98× of Marlin W4 MoE time.
  - The estimated pool is 463 blocks instead of 149.
- **Loading it needs a config-only "fixkeys" overlay** plus Merlin's FP8 PLE shards grafted into the index. See `FIXKEYS_DIFF.json`, `k100kit_core.py` (`fixkeys()`, `graft()`) and `E25_klee100_cpu_kit_v1_2026-10-31.md`. The CPU kit v2 result is ALL OK / CPU_COMPATIBILITY_PASS.
- **The Kaggle Model** `foysalemonshanto/qwen38-flash-next-klee100-3bpw-mtp/PyTorch/autoround-3bpw-mtp-nople/1` holds 33 files, 50.68 GB, with sizes equal to HF.

## The notebook: `Q27-XHIGH-E25_KLEE100_LOAD.ipynb`
sha256 78b94c49…, 376 kB (the limit is about 400 kB). Builder: `build_e25_klee100_load.py`. Pure helpers: `k100load_lib.py`. Unit tests: `k100load_unit_tests.py` (68/68 PASS locally). Code export: `k100load_code_export.py`.

**Steps:**
1. **Prepare the files.** Regenerate the overlay (the sha must equal the v2 artifact). Build the model dir from symlinks (K6 index check). Stream the sha256 of 23 files, 101.8 GB, in parallel with the install (K7 + K3). Apply the #60490 backport. Run NB1's page-cache drop and host-RAM gate.
2. **Boot K0 (probe):** BF16 pin 2,464,415,744, MTP off, seqs 8. It runs read-back, probes, a short oracle, a 40k prefill and a 90k TF, and measures free memory per card.
3. **Pin ladder:** pin = base + 0.9 / 0.8 / 0.7 × min-card (free − 1 GiB − MTP reserve 1448 MiB on the PP1 cards). An OOM moves to the next step.
4. **Boot K (BF16 KV, MTP off, ladder pin):**
   - memory and pool (blocks, F);
   - oracle;
   - teacher-forced comparison at 2k / 8k / 40k / 90k on NB0's exact ids against the W4 BF16 reference (`nb0_reference.json`; dataset `q27-e25-nb0-tf-ref`);
   - self-consistency and greedy parity;
   - one 120k-token request.
5. **Boot K2 (MTP K3, seqs 16, captures to 64):** oracle vs K, TF 40k vs reference C, the 8k@8 and 40k@N windows (per-position acceptance, tick ms), and the admission of N 64k contexts.
6. **Labels:**
   - per TF band: LOWBIT_TF_CLOSE / DIVERGENT / DIVERGENT_SEVERE;
   - final: `GPU_LOAD_PASS + <worst band>`, `GPU_LOAD_PASS_MTP_OFF_ONLY`, or `FAIL_<gate>`;
   - accuracy is always NOT_TESTED.
7. **Budget:** about 75-85 min; hard stop 120 min.

**CPU kits** (`q27-e25-k100load-kit-real.ipynb`, `q27-e25-k100load-kit-units.ipynb`) were pushed to Kaggle and are still running. Results are not included yet.

**Known risks** (from the builder):
- klee100's tokenizer.json (06b95093) differs in bytes from Merlin's (0997f410). The notebook checks the rendered ids by sha and falls back to NB0's ids.
- The 8k@8 window runs at temperature 0.6 and may trip the garbage gate. One rare loop event happened in an NB2 SMOKE run and was not reproduced in two diagnostic runs.
- The author's README says "an arithmetic consistency issue remains" and gives no detail.
- Warnings recorded but not gated:
  - F16 checkpoint scales are cast to BF16 (up to 0.39 % change);
  - W8 GPTQ on the fused QSA qkv+indexer has never run in Merlin;
  - the QSA KV-scale sidecar has not been validated for klee100.

## Part A: audit (blockers first)
A blocker means wrong raw data, a mid-run crash, or wasted GPU time. Labels and wording can be fixed later. For each finding, give: file, function or line, a concrete failure scenario, severity (BLOCKER / HIGH / MED / LOW), and a minimal fix.

Check in particular:
1. Can the boot fail or OOM because of the pin ladder arithmetic, the 1448 MiB MTP reserve, #60490 headroom, the humming workspace, or graph capture with captures to 64? Is K0's free-memory reading valid with an explicit `--kv-cache-memory-bytes`?
2. Does every step survive a failure in an earlier step (keep_after_error, budget shrink, graceful kill, GPU release < 150 MiB, /dev/shm cleanup), so that partial data is always saved?
3. Is the overlay and graft correct for Merlin: 48 expert layer keys, MTP layer 0 → 48 remap, `block_name_to_quantize`, `ple_embedding_dtype`, 128 BF16 PLE tensors replaced by 129 FP8 tensors? Is anything missing that only a GPU construction would reveal (humming objects, W8 `create_weights`)?
4. Is the TF comparison valid against NB0's reference: the same ids, positions, top-k, valid masks, and A/A floor? Is any threshold misapplied?
5. Is the time budget realistic: model load 327-433 s per worker on RC2, a cold install, the sha of 101.8 GB, three boots? What gets cut first under budget pressure?
6. Are the CPU kits enough to catch notebook-level crashes before the GPU run?
7. Are all raw traces and logs saved (full thinking, TF arrays, server logs, memory monitor)?

## Part B: advice (separate from the audit)
1. If klee100 loads and TF is CLOSE or DIVERGENT, what is the fastest path from here to a 1500 tok/s whole-run average on 4×L4? Rank the next 2-3 GPU experiments by expected gain per GPU-hour. Candidates:
   - 20-32 resident streams;
   - K3 vs K4;
   - humming T16 tile tuning (humming is 6-20 % slower than Marlin on the same W4 weights; T16 is its worst point);
   - the P5 world-2 all-reduce;
   - FULL graph coverage;
   - the RecoverSSM commit graph;
   - FP8 vs BF16 KV on klee100.
2. Which ARC accuracy check is the minimum before klee100 becomes a production candidate? The NB5 QUALITY design is a paired run on 15 tasks × 2 at 104k. Is that enough, or what would you change?
3. What could the "arithmetic consistency issue" be, how would we detect it in this notebook, and does any extra probe belong in this run?
4. If the load fails, which fallback has the best chance: another low-bit checkpoint (for example Haberstroh int2), FP8 QSA scale calibration on W4, or something else?
5. Anything in `PLAN_1500.md` you think is wrong or missing for the klee100 path.

Keep the two parts separate. Start Part A with a one-line GO / NO-GO verdict for a GPU run.
