# E25 klee100 compatibility CPU kit — audit bundle (2026-10-31)

## Goal
Decide on CPU, fail-closed, whether the low-bit checkpoint klee100/Qwen3.8-Flash-Next-AutoRound-3bpw-MTP can be loaded
correctly by Merlin v3.0.0 (vLLM 0.32 fork) on 4×L4 TP2×PP2+EP. The layout is:
- routed experts W3 g128 on layers 0-11 and 36-47, W2 g64 on layers 12-35;
- MTP experts W4 g128;
- main projections W8;
- BF16 sensitive paths.
It is loaded with a config-only "fixkeys" overlay and Merlin's FP8 PLE table grafted in. The reason: NB3 measured humming W2 at
0.60-0.70× and W3 at 0.84-0.98× of Marlin W4 MoE time. The estimate is 463 KV blocks instead of today's 149.

## Kit (folder `kit/`)
`q27-e25-klee100-cpu-kit.ipynb`, sha b39db932…, 348 kB (v2), one cell. Private, no GPU, no internet, pinned image.
- Inputs: dataset `foysalemonshanto/q27-e25-klee100-layers-0-12` (real layer-0 / layer-12 expert tensors); Models
  e23-merlin-env, merlin p1, FP8 PLE overlay.
- Embedded data, sha-checked: lossless tensor tables of both checkpoints (227,702 / 227,569 tensors), configs, 262 klee100 BF16
  PLE rows, Merlin source facts, author-patch facts, `EMBEDDED_FILES.json`.
- Pushed to Kaggle CPU (foysalemonshanto); results pending, to be added.

Three manifests and four gates (any missing / unexpected / unmapped item = NOT OK; no silent fallback accepted):
- **M1, module map:** 1,019 Merlin modules with class, quant config, TP rule, PP stage (25/23) and checkpoint keys.
- **M2, quantization map:** Merlin's own resolution in the Merlin venv, with the platform patched to CUDA (8, 9); a static mirror
  is kept as a labelled fallback.
- **M3, weight coverage:** keys, GPTQ shapes, dtypes; a negative rename test must give `NO_GO_UNMAPPED_WEIGHT`.
- **Gate A, quant:** all 396 quant modules resolve to the intended bits / group / method. It also checks the Merlin W4 control
  (48/48 → CT WNA16) and that the installed source is identical to the audited tree.
- **Gate B, PLE provenance:** table layout and hash buffers; numerics on 262 rows; row-order negative test; the grafted index has
  no BF16 PLE shard.
- **Gate C, MTP:** 4,651 tensors, remap layer 0 → `mtp.layers.48`, 2.607 B parameters, shared lm_head, W4 / W8 resolution.
- **Gate D, memory (ESTIMATE):** per-rank weights calibrated to RC2 within +0.14 / +0.17 GiB; klee100 ~11.97 / 12.03 GiB per
  rank. KV 463 blocks (534 with pin headroom); streams 68k 20 / 90k 16 / 120k 12.

## Local check (no Kaggle mounts / Merlin venv)
```
inputs ok; fixkeys 48 layer keys, 1553 MTP keys, no problems; graft ok
M3 OK 0/0; layout ok; negative NO_GO_UNMAPPED_WEIGHT
A static: fixkeys 0 bad, as published 28 bad, negative ok
probe layers 0 and 12 ok
B: source LOCAL_HF_ROWS_NOT_MOUNT, cos_min 0.99951, rel 0.0586, permuted negative fails
D: 463 / 534 blocks
```
The local verdict is `NOT OK: M1_MODULE_MAP, M3_WEIGHT_COVERAGE, GATE_A_QUANT_REAL, GATE_B_PLE, GATE_C_MTP`. This is expected:
those parts need the real Merlin code and the mounted overlay.

Findings so far:
- klee100 as published breaks in Merlin:
  - 24 W3 layers fall back to W2 g64;
  - MTP experts and attention resolve to Unquantized;
  - the PLE raises `NotImplementedError` at model init.
- fixkeys fixes all of it statically.
- The FP8 PLE overlay is the same base table: 97.6 % of codes equal round(BF16 / scale), the rest differ by ±1 code. It was
  quantized from a higher-precision copy (albucino@c6af9fee).

## fixkeys overlay (written by the kit to `/kaggle/working/fixkeys_overlay/`, with `FIXKEYS_DIFF.json`)
1. 48 layer keys `language_model.model.layers.N.mlp.experts` with the right bits / group.
2. 1,552 `mtp.layers.0.*` entries copied as `mtp.layers.48.*`, plus `mtp.layers.48.mlp.experts` W4 g128 sym.
3. `block_name_to_quantize` + `mtp.layers`.
4. `text_config.ple_embedding_dtype = float8_e4m3fn`.
5. The index swaps the 128 BF16 PLE tensors for the FP8 ones in `model-plefp8-00000..9`.

## Author's patch (folder `inputs/author_patch/`, repo commit c7fe762c)
Config can express its mixed-bit override, its MTP remap and the PLE type, and fixkeys does all three. It cannot express the SSD
PLE offload (metadata-only loading, async reads, graph host breaks), and that is not needed in Merlin, which has its own
pinned-host PLE pull.

## Warnings (recorded, not gated)
- F16 checkpoint scales are cast to BF16: up to 0.39 % relative change on 80-87 % of the scales.
- About 50 % of the scales are negative. That is AutoRound's full-range symmetric scheme and is valid.
- W8 GPTQ on the fused QSA qkv+indexer has never run in Merlin before.
- The QSA KV-scale sidecar has not been validated for klee100.
- Config differences from Merlin's: `layer_types` is `qwen_sparse_attention` where Merlin has `full_attention`, plus
  `norm_topk_prob` and `seed`.

## Files
`kit/` (notebook, metadata, embedded-files list), `build/` (builder + kit modules), `inputs/` (klee100 reports, model card,
author patch), `docs/` (structural-track feasibility, NB3 humming results, batch list), `00_AUDIT_PROMPT.md`.

## v2 result (Kaggle, folder `kit_result_v2/`)
`@@KIT klee100 ALL OK@@`, label CPU_COMPATIBILITY_PASS (eligible for a GPU load attempt; not a load or accuracy test). Details in `docs/E25_klee100_cpu_kit_v1_2026-10-31.md` (v2 section): 48/48 MoE resolution, 0 construction errors (48 humming objects GPU-only), expert-id negatives fail closed, full PLE shard sha OK, shard digest manifest written.
