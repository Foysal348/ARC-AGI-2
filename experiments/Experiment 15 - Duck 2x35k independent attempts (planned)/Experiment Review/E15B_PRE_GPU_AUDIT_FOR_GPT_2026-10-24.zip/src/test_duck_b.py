"""Unit tests for the E15B Duck package (Experiment 15 Notes/02). Run: python test_duck_b.py
The package is DUCK_B_PKG (an extracted package dir) or, locally, assembled from the Exp 12 vendor tree + src/duck_b."""
import json
import os
import shutil
import sys
import tempfile
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
E12_DUCK = Path(r"D:/ARC AGI 2/experiments/Experiment 12 - Duck REPL agent for ARC-AGI-2 (planned)/duck_arc2")
TASKS = Path(r"D:/ARC AGI 2/experiments/Experiment 10 - Q27-XHIGH Poetiq Code-Verify attempt_2 (planned)/Experiment Review/"
             r"E10_ORDER2_EVAL120_RESULTS_FOR_GPT/data/arc-agi_evaluation_challenges.json")


def _package() -> Path:
    if os.environ.get("DUCK_B_PKG"):
        return Path(os.environ["DUCK_B_PKG"])
    d = Path(tempfile.mkdtemp(prefix="duck_b_"))
    shutil.copytree(E12_DUCK / "vendor", d / "vendor", ignore=shutil.ignore_patterns("__pycache__"))
    shutil.copy(HERE / "duck_b" / "arc2_duck.py", d / "arc2_duck.py")
    for n in ("tool_agent.py", "python_tool_sandbox.py"):
        shutil.copy(HERE / "duck_b" / n, d / "vendor" / "inference" / "agent" / n)
    return d


PKG = _package()
sys.path[:0] = [str(PKG), str(PKG / "vendor")]
os.environ.update({"E12_ARC2_REV6": "1", "E12_ARC2_REV5": "1", "E12_B_MODE": "1", "E12_B_ATTEMPT_TOKENS": "35000",
                   "E12_B_RESERVE": "4096", "E12_DUCK_CONTEXT_WINDOW": "100000"})
import arc2_duck as A                                    # noqa: E402
os.environ.update(A.duck_env("http://127.0.0.1:9/v1", "fake-model", 16))
TA, DP, RUN, WRS = A._import_duck()
FAILS, SKIPS = [], []
# Duck's sandbox needs Linux (rlimits, process groups); on Windows it reports "Sandbox process could not start" for the
# unchanged upstream file too. Sandbox-dependent checks are SKIPPED there and must pass on the Kaggle CPU kit.
LINUX = os.name == "posix"


def check(name, cond, detail="", sandbox=False):
    if sandbox and not LINUX:
        print("SKIP " + name + "  [needs the Linux sandbox: Kaggle CPU kit]", flush=True)
        SKIPS.append(name)
        return
    print(("PASS " if cond else "FAIL ") + name + ("" if cond else f"  [{detail}]"), flush=True)
    if not cond:
        FAILS.append(name)


def _task():
    if TASKS.is_file():
        d = json.loads(TASKS.read_text())
        return d[sorted(d)[0]]
    return {"train": [{"input": [[1, 0], [0, 1]], "output": [[0, 1], [1, 0]]}] * 2, "test": [{"input": [[1, 1], [0, 0]]}]}


TASK = _task()
STATE0 = {"current_frame": None, "history": [], "valid_actions": [], "last_action_call_result": {}}


def _sandbox(code):
    return RUN(code=code, timeout_seconds=20, initial_state=STATE0,
               action_handler=lambda a, stale_after=None: {"action_result": {}, "state": {}}, kept_functions=[],
               retain_imports=True)


# ---------------------------------------------------------------- 1. sandbox (#14)
r = _sandbox("import sys\nsys.setrecursionlimit(5000)\nprint(sys.getrecursionlimit(), sys.maxsize > 0)")
check("sandbox: sys shim setrecursionlimit", (r.get("stdout") or "").strip() == "5000 True", r, sandbox=True)
r = _sandbox("import sys\nsys.setrecursionlimit(10**9)\nprint(sys.getrecursionlimit())")
check("sandbox: setrecursionlimit is capped at 20000", (r.get("stdout") or "").strip() == "20000", r, sandbox=True)
r = _sandbox("import sys\nprint(hasattr(sys, 'modules'), hasattr(sys, 'exit'))")
check("sandbox: sys shim exposes no modules / exit", (r.get("stdout") or "").strip() == "False False", r, sandbox=True)
r = _sandbox("import time\nt = time.time()\nprint(t > 0)")
check("sandbox: time allowed", (r.get("stdout") or "").strip() == "True", r, sandbox=True)
r = _sandbox("import numpy")
check("sandbox: numpy message", "pure Python lists" in (r.get("error") or ""), r, sandbox=True)
r = _sandbox("def inspect_pair(i):\n    return i\nimport inspect_pair")
check("sandbox: helper-import message", "already defined" in (r.get("error") or ""), r, sandbox=True)
r = _sandbox("import os")
check("sandbox: os still blocked", "not allowed" in (r.get("error") or ""), r, sandbox=True)
os.environ["ARC2_SANDBOX_SYS_SHIM"] = "0"
r = _sandbox("import sys")
check("sandbox: flag off -> sys blocked as before", "not allowed" in (r.get("error") or ""), r, sandbox=True)
os.environ["ARC2_SANDBOX_SYS_SHIM"] = "1"

# ---------------------------------------------------------------- 2. regex (#13)
R = A._autocheck_re()
for n, want in (("trans", True), ("trans2", True), ("trans_v", True), ("candidate_rule", True), ("transform", True),
                ("solve_task", True), ("rule_alt", True), ("transpose", False), ("translate", False), ("helper", False)):
    check(f"regex: {n} -> {want}", bool(R.match(n)) == want)
check("regex: trans(grid) is one-grid", A._r6_single_grid_arg("def trans(grid):\n    return grid"))
check("regex: trans(x, y) is not one-grid", not A._r6_single_grid_arg("def trans(x, y):\n    return x"))

# ---------------------------------------------------------------- 3. reasoning-code harvest (#50)
txt = ("I think the rule is a flip.\n```python\ndef helper(g):\n    return g[::-1]\n```\nThen:\n"
       "def transform(grid):\n    return helper(grid)\n\nThat should work.\nprint(transform(x))\n")
src, names = A.b_harvest_source([txt])
check("harvest: fenced + unfenced blocks", "def helper" in src and "def transform" in src, src)
check("harvest: names = [transform]", names == ["transform"], names)
check("harvest: no top-level calls kept", "print(" not in src, src)
src2, names2 = A.b_harvest_source(["def transform(a, b):\n    return a\n"])
check("harvest: two-arg transform not a candidate", names2 == [], names2)
src3, names3 = A.b_harvest_source(["no code here"])
check("harvest: no code", src3 == "" and names3 == [])

# ---------------------------------------------------------------- 4. prompt edits (#12, #13, #14, #22, #48)
p = A.arc2_system_prompt_r6(TASK, DP, 3072, view="facts")
check("prompt: tool contract", "Python functions inside it, not tools" in p)
check("prompt: bounded search", "Bound any search" in p)
check("prompt: budget 35,000", "about 35,000 generated tokens" in p)
check("prompt: autocheck names", "`candidate...`, `trans`" in p)
check("prompt: imports incl. time and sys subset", "time, and `sys` (only setrecursionlimit" in p)
os.environ["E12_B_MODE"] = "0"
p0 = A.arc2_system_prompt_r6(TASK, DP, 3072, view="facts")
check("prompt: B off -> unchanged rev 6 prompt", "Python functions inside it, not tools" not in p0)
os.environ["E12_B_MODE"] = "1"
for old, _new in A.B_PROMPT_EDITS:
    check("prompt edit matches once: " + old[:40], p0.count(old) == 1, p0.count(old))

# ---------------------------------------------------------------- 5. caps / budget / commit (#4, #5, #48)
Agent = A.make_agent_class()
ag = Agent(task=TASK, task_id="t0", branch=0, view="facts", model="fake-model", base_url="http://127.0.0.1:9/v1",
           provider="vllm")
check("agent: B mode on", ag._arc2_b and ag._arc2_b_budget == 35000 and ag._arc2_b_reserve == 4096)
for gen, want_cap in ((0, 30904), (20000, 10904), (30000, 5000), (30905, 4095), (34900, 256)):
    ag._session_generated_tokens = gen
    try:
        cur = ag.generated_tokens
    except Exception:
        cur = None
    if cur != gen:                                   # generated_tokens is derived; set what it reads
        for attr in ("_generated_tokens", "_session_generated_tokens"):
            setattr(ag, attr, gen)
    cap = ag._arc2_apply_cap()
    check(f"cap at {gen}: {want_cap}", cap == want_cap and ag._reply_reserve_tokens == cap
          and ag._context_budget_tokens == 100000 - cap - ag._request_safety_margin_tokens,
          (cap, ag._context_budget_tokens, ag.generated_tokens))
for attr in ("_generated_tokens", "_session_generated_tokens"):
    setattr(ag, attr, 31000)
check("commit zone at 31,000 (left 4,000 <= 5,120)", ag._arc2_b_in_commit())
ag._resume_after_yield, ag._resume_reason = True, "yield_bare"
op = ag._arc2_r6_opener()
check("commit opener text", "almost spent" in op and "4,000" in op, op)
check("commit event recorded", ag.arc2_b_events["commit_at_tokens"] == 31000 and ag.arc2_b_events["commit_via"] == "opener")
ag2 = Agent(task=TASK, task_id="t0", branch=1, view="facts", model="fake-model", base_url="http://127.0.0.1:9/v1",
            provider="vllm")
ag2._resume_after_yield = False
check("first opener carries the budget", "35,000 generated tokens" in ag2._arc2_r6_opener())

# ---------------------------------------------------------------- 6. submit as a tool (#11)
d = Path(tempfile.mkdtemp(prefix="duck_b_state_"))
sp = d / TA.RUNTIME_STATE_FILENAME
WRS(sp, current_frame=None, history=[])
ag3 = Agent(task=TASK, task_id="t1", branch=0, view="facts", model="fake-model", base_url="http://127.0.0.1:9/v1",
            provider="vllm")
res = ag3._dispatch_tool(sp, "check", {"transform": "transform"})
body = json.loads(res.content)
check("check-as-tool routed to python", "not a tool" in body.get("harness_note_tool", "") and ag3.arc2_b_events["submit_tool_routed"] == 1, body)
res = ag3._dispatch_tool(sp, "python", {"code": "def transform(grid):\n    return [row[:] for row in grid]\nprint('ok')"})
check("python tool still works", "ok" in json.loads(res.content).get("stdout", ""), res.content[:300], sandbox=True)
check("defined_functions inventory", "transform" in json.loads(res.content).get("defined_functions", []), res.content[:400], sandbox=True)
res = ag3._dispatch_tool(sp, "submit", {"code": "submit(transform)"})
check("submit-as-tool routed (code arg)", ag3.arc2_b_events["submit_tool_routed"] == 2 and "submission" in json.loads(res.content),
      res.content[:300], sandbox=True)
res = ag3._dispatch_tool(sp, "fly", {})
check("other unknown tools unchanged", "Unknown tool: fly" in res.content)

# ---------------------------------------------------------------- 7. turn rollback fix (#10): a 2-call reply past the yield
def _fake_reply(n_calls=2, completion=2600):
    calls = [{"id": f"c{i}", "type": "function",
              "function": {"name": "python", "arguments": json.dumps({"code": f"v{i} = {i}\nprint('call {i}')"})}}
             for i in range(n_calls)]
    return TA._ChatCompletionResult(message={"role": "assistant", "content": "", "reasoning_content": "think " * 50,
                                             "tool_calls": calls}, finish_reason="tool_calls",
                                    usage={"prompt_tokens": 5000, "completion_tokens": completion,
                                           "total_tokens": 5000 + completion})


def _run_turn(flag: str):
    os.environ["ARC3_YIELD_AFTER_BATCH"] = flag
    dd = Path(tempfile.mkdtemp(prefix="duck_b_turn_"))
    st = dd / TA.RUNTIME_STATE_FILENAME
    WRS(st, current_frame=None, history=[])
    a = Agent(task=TASK, task_id="t2", branch=0, view="facts", model="fake-model", base_url="http://127.0.0.1:9/v1",
              provider="vllm")
    a._arc2_deadline = time.monotonic() + 120
    replies = iter([_fake_reply()])
    orig = TA.ToolAgent._chat_completion
    TA.ToolAgent._chat_completion = lambda self, messages, **kw: next(replies)
    try:
        a.analyze(st, 0, valid_actions=[], step_env=None, transcript_path=dd / "transcript.txt", analysis_step=1,
                  request_timeout_seconds=60, should_stop=lambda: False)
    finally:
        TA.ToolAgent._chat_completion = orig
    hist = a._history_messages or []
    tools = [m for m in hist if isinstance(m, dict) and m.get("role") == "tool"]
    return len(tools), (dd / "transcript.txt").read_text(encoding="utf-8", errors="replace") if (dd / "transcript.txt").exists() else ""


n_on, tx_on = _run_turn("1")
n_off, tx_off = _run_turn("0")
check("rollback fix ON: both tool results kept in history", n_on == 2, (n_on, tx_on[-600:]))
check("rollback fix OFF: upstream rollback (history discarded)", n_off == 0, (n_off, tx_off[-600:]))
check("rollback fix ON: second call executed", "call 1" in tx_on, tx_on[-400:])

print("\n%d FAIL" % len(FAILS) if FAILS else "\nALL PASS", flush=True)
sys.exit(1 if FAILS else 0)
