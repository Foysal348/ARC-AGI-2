# E15B pre-GPU audit pack: config B (2 × 35k independent Duck attempts, 16 real streams)

**Date:** 2026-10-24.

**Competition:** Kaggle ARC Prize 2026 ARC-AGI-2. Qwen3.8-27B on 4× L4; 12 h; 240 hidden tasks.

**Base:** E14S, the submitted Duck notebook (LB 22.78; EVAL120 at the hidden per-task share: 25.83 % task-normalized).

**The user's fixed design (do not redesign it):**
- 2 independent attempts per task, 35,000 generated tokens each;
- attempt 1 on every task first, then attempt 2;
- 16 real streams;
- no server-queue waiting.

## What to audit

Find **bugs that would break or silently weaken this run**, in order of impact. For each finding:
- the file and line;
- the failure scenario;
- the fix.

Please do not propose new solver designs; those are listed as held items in `Notes/02` and `Notes/03`.

1. **Scheduler** (`src/duck_b/arc2_duck.py`, `solve_all_r6` with `first_exposure_tokens=None`, `fair_share=False`, `b1_view="facts"`, `max_generated_tokens=35000`, `min_admit_sec=600`):
   - Does attempt 2 always start as a fresh agent only after every attempt 1 has started?
   - Can any attempt pause or be chunked?
   - Can a worker die, deadlock or leak the running count (the new `worker()` wrapper)?
2. **Budget and commit turn** (`_arc2_apply_cap`, `_arc2_b_in_commit`, `_arc2_r6_opener`, the tool-result `harness_note`):
   - cap = remaining − 4,096 while remaining > 5,120, then the remaining tokens;
   - reply reserve = cap;
   - context budget = 100,000 − cap − 512.

   Is there any path where an attempt ends without the commit message, gets trimmed, or overshoots 35k by more than one request?
3. **Turn rollback fix** (`tool_agent.py`, `ARC3_YIELD_AFTER_BATCH`): after a yield, the remaining calls of the reply run before yielding.
   - Any history inconsistency?
   - Is running a `submit` that comes after the yield correct?
   - What about deadline stops?
4. **Sandbox patch** (`python_tool_sandbox.py`, `ARC2_SANDBOX_SYS_SHIM`):
   - Is the sys shim safe (no escape)?
   - Is the recursion cap 20,000 safe against a C-stack overflow in the child?
   - Is `time` acceptable?
   - Is the helper-import message correct when `globals` is the runtime dict?
5. **submit / check called as tools** (`_dispatch_tool`): argument shapes seen in transcripts:
   - `{"code": "submit(transform)"}`;
   - `{"transform": "transform"}`;
   - `{"transform": ""}`.
6. **Reasoning-code harvest** (`b_code_blocks`, `b_harvest_source`, `arc2_b_reasoning_harvest`, called from `BranchSession.run`): safety, time bound, double counting, interaction with the host verification.
7. **Engine at 16 streams** (notebook CELL 1 / CELL 5):
   - `--min-free-slots-delay 1`, mrr 17, graphs 1..17, mamba 68, `SGL_KV_PER_REQUEST` 50,000;
   - the capacity gate;
   - the 12-stream fallback on a failed launch / OOM / failed gate (`e11_next`, `e11_bring_up`: globals, flags, gate re-run).

   Can the client end up offering 16 while the server runs 13? Can the fallback leave inconsistent globals?
8. **Notebook wiring** (`Experiment Review/diffs/notebook_E14S_to_E15B_EVAL120G4B.diff`):
   - every setting applied once;
   - the fixed 100k window;
   - the `b_summary`;
   - the payload names / sha;
   - the dual mode (commit = eval subset + score; rerun = all hidden tasks).
9. **The open items in Notes/03** (watchdog #15, self-test #17, rule-library fallback #20, timeouts #24 / #27, candidate fields #31): which of them are blockers for a 45-min GPU smoke, and which are blockers for the hidden run?

## Files

| Path | What |
|---|---|
| `notebooks/Q27-XHIGH-E15B_SUBMIT_2X35K_S16_DUCK_SGLANG.ipynb` | commit = 45-min smoke (profile E15B), rerun = hidden |
| `notebooks/Q27-XHIGH-E15B_EVAL120G4B_2X35K_S16_DUCK_SGLANG.ipynb` | commit = EVAL120 at the hidden share |
| `build/build_e15b.py` | builder (runs build_e14.py in memory and patches with `once`) |
| `src/duck_b/arc2_duck.py`, `tool_agent.py`, `python_tool_sandbox.py` | the 3 changed package files |
| `diffs/*.diff` | changes vs the E14S base files and notebook |
| `src/test_duck_b.py`, `test_duck_b_windows_output.txt` | unit tests (sandbox ones SKIP on Windows: the upstream sandbox does not start on Windows) |
| `notes/01`, `notes/02`, `notes/03` | fix list rev 1, rev 2 (current), build record / status |
| `context/` | Exp 14 Notes/43 (merged fix list) and the EVAL120 analyses A / B / C |

**Constraints:**
- No Kaggle push, run or submit without the user's go.
- Kaggle CPU kit (Linux, Py3.12) before any GPU run.
- Then a 45-min GPU smoke before EVAL120.
