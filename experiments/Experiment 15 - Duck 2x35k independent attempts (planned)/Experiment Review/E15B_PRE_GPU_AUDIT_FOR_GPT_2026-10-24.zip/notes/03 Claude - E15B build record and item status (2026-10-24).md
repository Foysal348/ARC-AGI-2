# 03 — E15B build record: what was built, what is not done, what needs Linux/Kaggle

**Date:** 2026-10-24.

**User instruction:** "build it first, then the audit". Do not commit yet. Nothing was pushed, run or committed (git or Kaggle).

## Outputs

| File | sha256 (first 16) | Size |
|---|---|---|
| `Experiment Notebooks/Q27-XHIGH-E15B_SUBMIT_2X35K_S16_DUCK_SGLANG.ipynb` (commit = 45-min smoke at 16 streams, profile E15B; rerun = all hidden tasks) | `e5978049f82859d0` | 238 kB (< 400 kB) |
| `Experiment Notebooks/Q27-XHIGH-E15B_EVAL120G4B_2X35K_S16_DUCK_SGLANG.ipynb` (commit = 120 eval tasks at the hidden per-task share) | `03d9cc50361971a2` | 238 kB |
| `Experiment Notebooks/Build/payload/q27x_e15b_duck_57a6442d39e0.bin` (the B Duck package) | `57a6442d39e0…` | 215 kB |
| `Experiment Notebooks/Build/payload/q27x_e14_modules_55c1eb7911c6.bin` (unchanged E14 modules) | `55c1eb7911c6…` | 58 kB |
| `Experiment Notebooks/Build/payload/dataset-metadata.json` (id `esfersami50/q27-e15b-payload`, not uploaded) | | |

**Builder:** `Experiment Notebooks/Build/build_e15b.py`.
- It executes `build_e14.py` (E14S) in memory, which runs the E12 builder in memory. It writes nothing into Exp 12 or Exp 14; the E14 notebooks keep their PUSHED shas (checked).
- **Duck package:** the E14S package with 3 files replaced from `src/duck_b/`:

  | File | Line ending | sha | Diff |
  |---|---|---|---|
  | `arc2_duck.py` | LF | 758bddb5 → 9c51b87a | 399 lines |
  | `vendor/inference/agent/tool_agent.py` | CRLF, as upstream | 485ef8a9 → f7454201 | 28 lines |
  | `vendor/inference/agent/python_tool_sandbox.py` | CRLF | c2208578 → d29d807e | 62 lines |

- **Diffs:** `Experiment Review/diffs/` (including notebook E14S → E15B, cell by cell).

**Tests:** `src/test_duck_b.py`.
- On Windows: ALL PASS, with 11 sandbox-dependent checks SKIPPED. The Duck sandbox does not start on Windows even for the unchanged upstream file, so those checks must run on the Kaggle CPU kit (Linux, Py3.12).
- Output: `Experiment Review/test_duck_b_windows_output.txt`.

## Item status (Notes/02 numbering)

| # | Item | Status | Where |
|---|---|---|---|
| 1 | Two independent attempts (attempt 2 = new agent, facts view, unseeded sampling) | **done** | `E12_R6_B1_VIEW` = facts, `E12_BRANCHES` 2; Duck sends no seed (verified) |
| 2 | Attempt 1 on all tasks first | **done** (existing: stage 2 waits for every stage-1 start) | `solve_all_r6` |
| 3 | 35k per attempt, no pause / chunks / resumes | **done** | `E12_MAX_GEN` 35000 (`E12_B_ATTEMPT_TOKENS` asserted equal); `E12_R6_FIRST_EXPOSURE` 0; fair share 0 |
| 4 | No 12k / 24k / 32k caps | **done** | `_arc2_apply_cap`: cap = remaining − 4,096, then the remaining tokens (tested) |
| 5 | No trim inside an attempt | **done** | reserve = cap; fixed window 100,000 (#46); context budget = window − cap − 512 (tested) |
| 6 / 49 | `min_admit_sec` | **done**: 600 s | `E12_R6_MIN_ADMIT_SEC` |
| 7 | a1 / a2 assembly | **partly done.** Distinct verified outputs from both attempts come through the existing `select_attempts_r5`. **The partial-program a2 fallback is NOT implemented.** | — |
| 8 | End-of-attempt harvest | **done** (existing autocheck + the check harvest) + #50 | — |
| 9 | xhigh | **done** (default effort, no `--effort`) | — |
| 10 | Turn rollback | **done**: `ARC3_YIELD_AFTER_BATCH=1` finishes the reply's remaining calls, then yields. Fake-reply test: ON keeps 2/2 tool results; OFF reproduces the upstream rollback (0). | tool_agent.py |
| 11 | submit / check as tools → python | **done** (routing tested; the actual run needs the Linux sandbox) | `_dispatch_tool` |
| 12 | Tool contract in the prompt | **done** (tested) | `B_PROMPT_EDITS` |
| 13 | Autocheck names (candidate, trans, trans<n>, trans_*; not transpose / translate) | **done** (tested) | `_R6_AUTOCHECK_RE_B` |
| 14 | Sandbox: sys shim (setrecursionlimit capped at 20,000, getrecursionlimit, maxsize, stdout), time, import messages | **built; tests need Linux** | python_tool_sandbox.py |
| 15 | **Server watchdog (relaunch if SGLang dies mid-run)** | **NOT implemented.** A safe design needs the scheduler to pause while the server is down; today, branches would fail after 10 consecutive errors. | open |
| 16 | Launch fallback: 16 → 12 streams on a failed / OOM launch or a failed capacity gate (delayer stays off) | **done** (not tested on GPU) | `e11_next`, `e11_bring_up` |
| 17 | **Sandbox self-test on a fixed task** | **NOT done** (still the first test task) | open |
| 18 | Worker restarts on an error; running count always released | **done** | `solve_all_r6` |
| 19 | Attempt-2 order (progress → nothing → verified) | **done** (existing `rank()` class order; D2 = yes by default) | — |
| 20 | **CPU rule-library fallback** | **NOT implemented** | open |
| 21 | Defined-functions inventory in tool results | **done** | `_run_python_tool` |
| 22 | Bounded-search guidance | **done** (prompt only; no pre-check helper) | — |
| 23 | No `overfit_flags` selection | **unchanged** (used only for stage-2 ordering inside class 2, not selection) | — |
| 24 | **pip / venv timeouts** | **NOT done** | open |
| 25 | Keep the payload `.bin` until the hidden run ends | process | — |
| 26 | `submission.json` once | **kept as is on purpose:** the per-branch atomic write protects against a crash | — |
| 27 | **Staging copy abort on timeout** | **NOT done** | open |
| 28 | Labels | **partly** (variant, payload, arm label; markdown rewritten) | — |
| 29 | Per-attempt record | **done**: `b_events` (commit_at / via / requests / tool_call, submit_tool_routed, reasoning_harvest, end_tokens), `b_budget` | branch_result.json |
| 30 | B-risk metric | **done** in `E12_RUN["b_summary"]` (`at_budget_with_progress`); the attempt-2 recovery is computed offline | CELL 6 |
| 31 | **Candidate fields** (written / retained / executed / timeout …) | **NOT done** (the existing first_transform / first_check only) | open |
| 32-35 | **Deadline-cut tokens, retract counter, accepted vs harvested, effective effort** | **NOT done** (existing report) | open |
| 36 | Delayer off (`--min-free-slots-delay 1`) | **done** | `E14_SUBMIT_ARM` |
| 37 | 16 streams: mrr 17, graphs 1..17, mamba 68 | **done** | CELL 1, CELL 5 |
| 38 | Gates allow 16 | **done**: `SGL_KV_PER_REQUEST` 70k → 50k (865k / 50k = 17); mamba 68 / 4 = 17; graphs ≤ 16 = 16; preflight at 16 | CELL 1 / 5 |
| 39 | Real-concurrency check | **done**: mean server running and queue > 0 share from the 30-s gauges; a warning if mean < streams − 0.5 | `b_summary` |
| 40 / 41 | KV fit, READY time with graphs 1..17 | **to be measured in the smoke** | — |
| 42 | Engine block in the report | **partly** (gauges only; no server-log histogram) | — |
| 43 | Harness + Kaggle CPU kit | **NOT done**: the harness needs an E15B mode (it asserts E14S flags); the CPU kit is a Kaggle push (needs the go) | next |
| 44 | Smoke profile | **built**: profile E15B = 45 min, 15-min window, 16 G4B tasks | not run |
| 45 | Fair share off | **done** | — |
| 46 | Fixed window | **done** | — |
| 47 | Request timeout 3,000 s | **done** | — |
| 48 | Commit turn | **done**:<br>• budget in the prompt and the first opener;<br>• at remaining ≤ 5,120 the opener or tool result says "almost spent: write `transform` + `check(transform)` now";<br>• that request gets the remaining tokens.<br>**Thinking stays ON** (turning it off changes the system prompt in the stock Qwen template, so the whole context would be prefilled again; tool_agent.py L1149-1167). | `R6_TEXT_B` |
| 50 | Reasoning-code harvest | **done** (extraction tested; the run needs the Linux sandbox) | `arc2_b_reasoning_harvest` |
| 51 | **Yield 2,048** | **unchanged** (harmless after #10) | — |
| 52 | No new scheduler | **done** | — |
| 53 | **Retract / preempt = 0 check** | **NOT automated** (read the server log after the smoke) | open |
| 54 | **Deadline harvest of cut attempts** | **NOT verified** | open |
| 55 | < 400 kB, traces saved, facts cap | < 400 kB **yes**; transcripts **yes**; facts cap **not rechecked** | — |

## Known risks for the audit

1. **The commit turn may not produce code.** With thinking on and ≈ 4-5k tokens, xhigh can spend the turn thinking. #50 harvests code written in that thinking. Measured by `commit_with_tool_call`.
2. **Startup time and memory at 16 streams are unmeasured:**
   - graphs 1..17;
   - mamba 68 costs ≈ 0.55 GB / GPU;
   - the headroom gate is ≥ 1.0 GB (it was 1.78 at 13);
   - the fallbacks cover a failure, but they cost a relaunch (≈ 10-20 min).
3. **The per-stream rate drops at 16** (≈ 26-30 tok/s). One 35k attempt ≈ 20-22 min; the request timeout is 3,000 s.
4. **#15 (watchdog) is not built.** If SGLang dies mid-run, the remaining attempts fail.
5. **Attempt 2 also runs on accepted tasks (D2 default yes),** last in the queue, in class order.
