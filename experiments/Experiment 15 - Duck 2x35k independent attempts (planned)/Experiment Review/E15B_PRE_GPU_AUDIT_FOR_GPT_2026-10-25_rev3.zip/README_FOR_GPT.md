# E15B pre-GPU audit pack (rev 3): config B, 2 × 35k independent Duck attempts, 16 real streams

**Date:** 2026-10-25. Rev 3 = the rev 2 build plus the changes adopted from two AI fix proposals.

| File | What |
|---|---|
| `notes/04` | AI proposal 1, verbatim |
| `notes/06` | AI proposal 2, verbatim |
| `notes/05` | Proposal 1 compared item by item |
| `notes/07` | Final adopt list A1-A7 and the checks behind it |

**Competition:** Kaggle ARC Prize 2026 ARC-AGI-2. Qwen3.8-27B on 4× L4; 12 h; 240 hidden tasks.

**Base:** E14S, the submitted Duck notebook (LB 22.78; EVAL120 at the hidden per-task share: 25.83 % task-normalized).

**The user's fixed design (do not redesign it):**
- 2 independent attempts per task, 35,000 generated tokens each;
- attempt 1 on every task first, then attempt 2. Decided 2026-10-25 (D-A): attempt 2 starts once every attempt 1 has **started**; each task's attempt 2 is queued when its own attempt 1 ends. Not a finish barrier.
- 16 real streams;
- no server-queue waiting.

## What changed in rev 3 (`diffs/rev2_to_rev3.diff`)

| ID | Change | Where |
|---|---|---|
| A1 | Real concurrency | `_e15b_server_log_summary`: `running_hist_queue_gt0`, the running histogram of the decode lines with queue > 0. `b_summary`: `server_running_mean_client_full` and `server_at_streams_share_client_full`, from the 30-s gauges in which every client stream was busy. On the real E14 G4B log, `running_hist_queue_gt0` = {11: 210}: the old 11-of-12 problem, shown directly. |
| A2 | Per-attempt correctness in the eval score | `report["eval_b_attempts"]`: b0 / b1 host-accepted correct, b1-only, b0 at budget with partial progress → rescued by b1; per-task rows |
| A3 | Startup split from the server log | `server_log.startup`: weight-load seconds per model, each CUDA graph capture (sec / mem / avail after), KV tokens, log start → ready |
| A4 | KV gate decided on a stale sample | `kv_stale_checks` counted in `solve_all_r6` |
| A5 | `min_admit_sec` | 600 → 300 |
| A6 | Rule library inside its own `try` in `select_attempts_r5` | **A risk found:** `_rl_color_map` ran outside the per-rule `try`. An exception there made `build_submission` fall back to the test inputs for the whole task, losing its program candidates. **Measured:** eval 0/120 tasks fire a rule; training 24/1,000 fire, 23 right. |
| A7 | The watchdog limits (poll 10 s, health-fail 180 s, min left 20 min) are env-overridable, same defaults | The harness can now inject faults: (a) **kill** the server mid-solve → one relaunch, the solve continues; (b) **slow** (replies longer than the health-fail window) → no relaunch |

**Also in rev 3: three independent agent audits (`notes/agent audits/`, triage in `notes/08`).** Taken:

| Auditor | Finding | Change |
|---|---|---|
| 1 | F1 | The partial test runs before the harvest; the harvest restores the retained functions when it accepts nothing |
| 1 | F2 | The commit text also follows a rejected submit; the harvest never marks a commit |
| 1 | F3 | The sandbox timeout is clamped to the deadline + grace |
| 2 | F1 | No per-branch `submission.json` rewrite after the solve end (≈ 480 rewrites, 2-4.5 min against the 12-h limit); the rule outputs are cached per task |
| 2 | F2 / F8 | Watchdog liveness = server-log growth; `/health` only when the log is silent (the post-relaunch prefill storm is not read as a hung server) |
| 2 | F3 | After an OOM / RuntimeError, or on the 2nd relaunch → the 12-stream flags; a failed relaunch retries once |
| 2 | F4 | RERUN: SGLang give-up T0 + 4 h (was 75 min) and 4 launches |
| 2 | F6 | The engine block covers every server log; tokens are counted per server; accept length; gen tok/s per running level |
| 2 + 3 | F7 + R4 | Commit solve window 78 min |
| 3 | R9 | Imports in the reasoning harvest are inside `try` |
| 3 | L41 | An unknown tool with a `code` argument runs as python |
| 3 | L111 | `kill()` also kills the process group of a dead main process |

**Rejected:**
- Auditor 2 **F5** (W1 with the delayer off): W1's buffers are sized for 12 requests with mrr 13, which is the old nodelay crash.

The **commit profile** is now 20 eval tasks with BOTH attempts finishing (user 2026-10-25): the 16 G4B tasks + 16de56c4, 1ae2feb7, 221dfab4, 269e22fb. Window 78 min, budget 100 min.

**Checked and NOT changed (see notes/07):**
- The 100k window is below the server context length (155,648).
- SGLang 0.5.21's `/health` is a 1-token generation check that passes on any detokenizer output within 20 s. Non-streaming requests emit an output every 50 tokens, so long replies never look like a dead server.

## State

- `notes/03` gives every item's status and evidence.
- `test_outputs/verify_items_output.txt`: items 1-55 + A1-A7 against both built notebooks. Result: ALL CODE ITEMS PRESENT.
- **Unit tests:** 67/67.
- **CPU harness** (fake SGLang): see `test_outputs/harness_*.log`.
- **Not yet done:** the Kaggle CPU kit (Linux, Py3.12) and the 45-min GPU smoke (both need the user's go).

## What to audit

Find **bugs that would break or silently weaken this run**, ranked by impact. For each finding:
- the file and line;
- the failure scenario;
- the fix.

Please do not propose new solver designs.

0. **The audit fixes above** (`diffs/rev2_to_rev3.diff`): are they correct, and did they break anything?
1. **Scheduler** (`src/duck_b/arc2_duck.py` `solve_all_r6` with `first_exposure_tokens=None`, `fair_share=False`, `b1_view="facts"`, `max_generated_tokens=35000`, `min_admit_sec=300`, `join_grace_sec=90`; the `worker()` wrapper):
   - pauses or chunks;
   - attempt-2 timing;
   - deadlock;
   - a leaked running count.
2. **Budget and commit turn** (`_arc2_apply_cap`, `_arc2_b_in_commit`, `_arc2_r6_opener`, the tool-result `harness_note`):
   - cap = remaining − 4,096 while remaining > 5,120, then the remaining tokens;
   - context budget = 100,000 − cap − 512.
3. **End of an attempt:**
   - the reasoning-code harvest;
   - the partial-program test run;
   - the 30-s grace after the deadline;
   - the 90-s join grace.
4. **Server watchdog** (notebook CELL 6 `_e15b_watchdog`; `arc2_duck.SERVER_DOWN` and the wait in `BranchSession.run`). Specifically: a request that fails between the server's death and the next watchdog poll (≤ 10 s) is counted as an ordinary failure (Duck: 3 retries × 5 s, branch backoff 10 s, 10 failures allowed). Is that budget always enough?
5. **Turn rollback fix** (`tool_agent.py`, `ARC3_YIELD_AFTER_BATCH`) and **submit / check as tools** (`_dispatch_tool`).
6. **Sandbox patch** (`python_tool_sandbox.py`, `ARC2_SANDBOX_SYS_SHIM`).
7. **Selection** (`select_attempts_r5` + `rule_library_outputs`, A6).
8. **Engine at 16 streams** (CELL 1 / CELL 5):
   - `--min-free-slots-delay 1`, mrr 17, graphs 1..17, mamba 68, `SGL_KV_PER_REQUEST` 50,000;
   - the capacity gate;
   - the fallbacks.
9. **Notebook wiring** (`diffs/notebook_E14S_to_E15B_EVAL120G4B.diff`, `diffs/rev2_to_rev3.diff`): every setting applied once; the new report fields (A1-A4) cannot raise into the solver; the dual mode.
10. **The harness and the tests:** do they test what they claim (including the A7 fault runs)? What important case is missing?

## Files

| Path | What |
|---|---|
| `notebooks/…SUBMIT…ipynb` | commit = 20 eval tasks, both attempts (profile E15B, 100 min), rerun = hidden |
| `notebooks/…EVAL120G4B…ipynb` | commit = EVAL120 at the hidden share |
| `build/build_e15b.py` | builder (runs build_e14.py in memory and patches with `once`) |
| `src/duck_b/*.py` | the 3 changed package files |
| `src/test_duck_b.py`, `src/verify_items.py`, `src/harness/harness_e15b_nb.py` | tests, item verifier, CPU harness (env `E15B_FAULT=kill\|slow` for A7) |
| `diffs/*.diff` | vs the E14S / Exp 12 bases, and `rev2_to_rev3.diff` |
| `test_outputs/` | unit tests, item verifier, harness logs (commit, rerun, eval120, fault kill, fault kill2, fault slow) |
| `notes/01-08` | fix lists, build record, the two AI proposals, comparison, adopt list, rev 3 decisions + audit triage |
| `notes/agent audits/` | the three independent agent audit reports (Duck package; notebook / engine; regression ledger of 135 past issues) |
| `context/` | Exp 14 Notes/43 and the EVAL120 analyses A / B / C |
