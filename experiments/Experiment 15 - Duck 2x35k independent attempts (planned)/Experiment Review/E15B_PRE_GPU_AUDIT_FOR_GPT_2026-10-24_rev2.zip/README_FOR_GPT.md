# E15B pre-GPU audit pack (rev 2): config B, 2 × 35k independent Duck attempts, 16 real streams

**Date:** 2026-10-24.

**Competition:** Kaggle ARC Prize 2026 ARC-AGI-2. Qwen3.8-27B on 4× L4; 12 h; 240 hidden tasks.

**Base:** E14S, the submitted Duck notebook (LB 22.78; EVAL120 at the hidden per-task share: 25.83 % task-normalized).

**The user's fixed design (do not redesign it):**
- 2 independent attempts per task, 35,000 generated tokens each;
- attempt 1 on every task first, then attempt 2;
- 16 real streams;
- no server-queue waiting.

**State of this pack:**
- All 55 items of the fix list (`notes/02`) are built.
- `notes/03` gives each item's status and evidence.
- `test_outputs/verify_items_output.txt` checks every item against the built notebook and package.
- **Tests:**
  - unit tests 64/64;
  - CPU harness with a fake SGLang: commit 23/23, rerun 25/25, eval120 27/27.
- **Not yet done:** the Kaggle CPU kit (Linux, Py3.12) and the 45-min GPU smoke (both need the user's go).

## What to audit

Find **bugs that would break or silently weaken this run**, ranked by impact. For each finding:
- the file and line;
- the failure scenario;
- the fix.

Please do not propose new solver designs.

1. **Scheduler** (`src/duck_b/arc2_duck.py` `solve_all_r6` with `first_exposure_tokens=None`, `fair_share=False`, `b1_view="facts"`, `max_generated_tokens=35000`, `min_admit_sec=600`, `join_grace_sec=90`; the `worker()` wrapper):
   - pauses or chunks;
   - attempt-2 timing;
   - deadlock;
   - a leaked running count.
2. **Budget and commit turn** (`_arc2_apply_cap`, `_arc2_b_in_commit`, `_arc2_r6_opener`, the tool-result `harness_note`):
   - cap = remaining − 4,096 while remaining > 5,120, then the remaining tokens;
   - reserve = cap;
   - context budget = 100,000 − cap − 512.

   Can an attempt be trimmed, miss the commit message, or overshoot?
3. **The end of an attempt** (`BranchSession.run` tail):
   - the reasoning-code harvest (`b_code_blocks`, `b_harvest_source`, `arc2_b_reasoning_harvest`);
   - the partial-program test run (`arc2_b_partial_test`);
   - the 30-s grace after the deadline (`_arc2_verify_grace` in `_verify_submission`);
   - the 90-s join grace.

   Safety, double counting, frozen-record races.
4. **Server watchdog** (notebook CELL 6 `_e15b_watchdog`; `arc2_duck.SERVER_DOWN` and the wait in `BranchSession.run`):
   - races with the solver;
   - the relaunch command / env reuse;
   - GPU freeing;
   - what happens if the relaunch fails;
   - the interaction with the priority gate and the request timeouts.
5. **Turn rollback fix** (`tool_agent.py`, `ARC3_YIELD_AFTER_BATCH`) and **submit / check as tools** (`_dispatch_tool`).
6. **Sandbox patch** (`python_tool_sandbox.py`, `ARC2_SANDBOX_SYS_SHIM`): sys shim escape risk, the recursion cap of 20,000, `time`, the helper-import message.
7. **Selection** (`select_attempts_r5` + `rule_library_outputs`): the rules are only used after every program candidate. Can a rule ever displace a host-verified program or a partial program? Are the rules correct?
8. **Engine at 16 streams** (notebook CELL 1 / CELL 5):
   - `--min-free-slots-delay 1`, mrr 17, graphs 1..17, mamba 68, `SGL_KV_PER_REQUEST` 50,000;
   - the capacity gate;
   - the fallback order: any failed 16-stream launch → 12 streams (delayer still off) → diagnosed OOM / lazy / prefill → W1;
   - the gate fallback (`e11_bring_up` re-launch);
   - global consistency (`SGL_MAX_RUNNING` / `SGL_SERVER_MAX_RUNNING`).
9. **Notebook wiring** (`diffs/notebook_E14S_to_E15B_EVAL120G4B.diff`):
   - every setting applied once;
   - the fixed 100k window;
   - `b_summary` (concurrency, `server_log` block, watchdog, server-side tokens, effort, candidate stages);
   - the payload names / sha;
   - the staging deadline;
   - the timeouts;
   - the fixed self-test / tokenizer-probe tasks;
   - the dual mode (commit = eval subset + score; rerun = all hidden tasks).
10. **The harness and the tests:** do they test what they claim? What important case is missing?

## Files

| Path | What |
|---|---|
| `notebooks/…SUBMIT…ipynb` | commit = 45-min smoke (profile E15B), rerun = hidden |
| `notebooks/…EVAL120G4B…ipynb` | commit = EVAL120 at the hidden share |
| `build/build_e15b.py` | builder (runs build_e14.py in memory and patches with `once`) |
| `src/duck_b/*.py` | the 3 changed package files |
| `src/test_duck_b.py`, `src/verify_items.py`, `src/harness/harness_e15b_nb.py` | tests, item verifier, CPU harness |
| `diffs/*.diff` | changes vs the E14S base files and notebook |
| `test_outputs/` | unit tests, item verifier, the three harness logs |
| `notes/01-03` | fix list rev 1, rev 2 (current), build record and status |
| `context/` | Exp 14 Notes/43 (merged fix list) and the EVAL120 analyses A / B / C |
