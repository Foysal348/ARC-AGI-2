# E15B deep-analysis pack: two GPU commit runs, 45K30K vs 40K35K (2026-10-25)

## What this is

**Competition:** Kaggle ARC Prize 2026, ARC-AGI-2.
- Hardware: 4 × L4 24 GB, offline, 12 h per submission.
- Hidden test: 240 tasks, about the same difficulty as the public evaluation set.
- The score is pass@2 per test query, normalised per task.

**Model:** Qwen3.8-27B, RedHat INT4 W4A16 (g128), with a BF16 DFlash2 drafter (6 draft tokens).
- Engine: SGLang 0.5.21, TP4.
- KV: fp8_e4m3, 852,152 tokens.
- Mamba state fp16; `--min-free-slots-delay 1`; max running 17; CUDA graphs 1..17.

**Agent: "Duck" REPL tool agent (ARC-2 adapter `arc2_duck.py`).**
- The model thinks (xhigh, `preserve_thinking`) and calls a `python` tool.
- In the tool it writes `transform(grid)` and calls `check(transform)` on the train pairs.
- A host verifier accepts a train-exact program; the program's test output becomes an answer.

**Experiment 15 = "config B":**
- Every task gets **2 independent attempts**: attempt 2 is a fresh sample, not a resume.
- **Attempt 1 of every task starts before any attempt 2.**
- 16 concurrent streams.
- **Per-attempt token budgets** (thinking included):
  - each request may use the remaining budget minus a 4,096-token commit reserve;
  - inside the reserve, a "commit turn" asks for the best `transform` + `check` now.
- **Endings of an attempt:**
  - an accepted program;
  - the end-of-attempt reasoning harvest: code blocks in the thinking, verified;
  - a partial program (best train accuracy) as a fallback answer.

**The commit run (Kaggle "commit"):** 20 fixed evaluation tasks (32 test queries), both attempts.
- 16 tasks from an earlier "G4B" hard set, plus 4 tasks solved in 1-2 of 3 earlier EVAL120 runs.
- The same notebook in RERUN mode (the competition submission) solves all 240 hidden tasks.

## The two runs (same code = rev 3g, same tasks, same engine; only the budgets differ)

| | **45K30K** (attempt 1 45k, attempt 2 30k) | **40K35K** (attempt 1 40k, attempt 2 35k) |
|---|---|---|
| notebook | `notebooks/ran_on_gpu/..._45K30K_...` sha `5d8069b9` | `..._40K35K_...` sha `560ed8b8` |
| account | esfersami50 | foysalemonshanto (version v1, scriptVersionId 361956451) |
| **queries hit** | **19 / 32** (pass1 17, pass2 2) | **11 / 32** |
| **tasks hit / task-norm** | **13 / 20, 65.0 %** | **7 / 20, 37.5 %** |
| attempt 1 correct / attempt 2 correct / both / attempt-2-only | 11 / 8 / 6 / 2 | 6 / 7 / 6 / 1 |
| attempts at budget | 16 | 21 |
| commit turns (with a tool call) | 24 (18) | 26 (20) |
| tool calls cut at the request cap (code lost) | 6 | 5 |
| attempts that never wrote a candidate | 8 | 5 |
| mean generated tokens: attempt 1 / attempt 2 | 32,982 / 24,818 | 31,186 / 28,053 |
| stream-seconds per task | 2,116 | 2,154 |
| READY / solve start / solve end (s) | 542 / 804 / 3,802 | 532 / 701 / 3,758 |
| generated tokens total | 1,155,991 | 1,184,773 |
| prefix cache hit | 94.0 % | 92.9 % |
| gen tok/s p50 at 16 running | 451 | 469 |
| queue > 0 / retract / OOM / relaunch | 0 / 0 / 0 / 0 | 0 / 0 / 0 / 0 |
| selection loss (a correct program existed, no hit) | 0 | 0 |

**Claude's reading** (to be checked, not taken as given):
- **Attempt-1 accepted-correct solves at or below 35.9k tokens: 6 in both runs.**
- **The whole gap is attempt-1 solves at 36-45k** (45K30K: 135a2760, 9aaea919, 247ef758, 269e22fb, f931b4a8).
  - Two of them were accepted in the commit turn at ~41.7k.
  - In 40K35K, four of the same tasks wrote a transform at 36.8-39.7k with no accept before the 40k end.
- Attempt 2 at 35k did not make up for it.
- n = 20 and sampling is at T = 1.0, so this is noisy.

The pending competition submission is the 40K35K notebook. The proposed next one is the rev 3h 45K30K notebook.

## Known findings so far

(`docs/Notes/11`; the earlier stopped run is in `docs/Notes/10`)

| # | Finding | Status |
|---|---|---|
| F1 | A tool call cut at the request cap loses its code: Duck drops the malformed call. | Fixed in rev 3h: the code is kept, complete leading definitions are harvested, sandbox + host verifier. |
| F2 | 6 of 24 (6 of 26) commit turns made no tool call: the model thought through the whole 4,096 reserve. | Open. `enable_thinking: false` changes the system header (the reasoning-effort line), so the prefix cache misses (~45-55k tokens prefilled again per commit turn). |
| F3 | The provisional "write a transform" nudge is delivered only at a request boundary (a tool result or an opener), which arrives 6-12k tokens late. | rev 3h scales the nudge to the budget: 0.69 × budget. It reaches a 30k attempt only if a tool call falls in [20,700, 24,880). An on-time nudge needs a request split (= a pause). Not done: the long uninterrupted thinking rule. |
| F4 | 8 tiny requests (cap 256-700) after the commit turn. | Waste, not changed. |
| F5 | The branch record's `accepted` / `branches_accepted` miss harvest-accepted attempts (e.g. 136b0064 b1). | Reporting only. |
| F6 | Branch `sec` ≈ 2,895-2,954 for every attempt 1. | Reporting; the real durations are `e12_run.rev6_scheduler.durations` and `runs[].sec`. |
| F7 | `E15B WARNING: mean server running 14.17` comes from the end tail. | Reporting; client-full mean 15.6. |
| F8 | KV peak full_token_usage 0.71. 16 × ~55-60k contexts > 852k is possible if all are long at once. | Watch. |

## Questions for the deep analysis

1. **Is the 45K30K vs 40K35K gap real or noise?** Use the per-attempt token positions in the transcripts (first `transform`, first `check`, accept time, commit turn), not only the summary counts. Which budget pair maximises the expected hidden score?
   - Candidates: 45K30K, 40K35K, 50K45K, others.
   - Time window: about 11.6 h of solve time after ~13.4 min of startup and the margins.
   - The measured cost is ~36.6 stream-seconds per 1k generated tokens at 16 streams.
2. **Read every transcript** (`results/*/q27x/duck/<task>_b<k>/transcript.txt`; the full thinking is saved). Find agent, prompt, tool or verifier bugs that metrics do not show:
   - wrong tool results;
   - retained-function or sandbox problems;
   - verifier mistakes;
   - prompts that mislead;
   - wasted requests;
   - cases where the harvest or partial test should have produced an answer.
3. **F2 (commit turn without a tool call):** a fix that keeps the prefix cache. For example: a prefilled assistant `</think>`, a thinking-budget processor that works with DFlash speculative decoding in SGLang 0.5.21, or a different commit protocol.
4. **Accepted-but-test-wrong programs:** 6 of 24 and some of 19. Can an overfit or generalisation signal visible in the data rank the two attempts' answers better?
5. **Attempts that never wrote a candidate** (8 / 5): what were they doing? Can anything that does not interrupt long thinking help?
6. **Review the rev 3g → rev 3h diff:** `payload_source/arc2_duck_rev3g_to_rev3h.diff` plus `notebooks/Build/build_e15b.py`. Look for regressions.
7. **Throughput:**
   - 16 streams give ~451-469 tok/s;
   - target-verify CUDA graph capture takes ~383-403 s of startup;
   - accept length p50 3.8-3.9.
   - Is there any safe gain?

## Layout

| Path | Contents |
|---|---|
| `notebooks/ran_on_gpu/` | The exact notebooks of the two runs (rev 3g). |
| `notebooks/next_rev3h_not_run/` | The rev 3h builds (sha `9ee0aa4e` 45K30K, `a7837609` 40K35K). CPU kit on Kaggle: ALL OK (`results/cpu_kit_run4_rev3h`). |
| `notebooks/Build/build_e15b.py` | The builder. The notebooks patch an E14S base notebook; the Duck code comes from the payload dataset. |
| `payload_source/duck_rev3g_ran/` | Sources of the Duck package `q27x_e15b_duck_b20804213563.bin` that the two runs loaded (`arc2_duck.py` + the vendored Duck files). |
| `payload_source/duck_rev3h_next/` | rev 3h (`85a805b5d8bb`). |
| `payload_source/e14_modules/` | The E14 load-path / SGLang patch modules. |
| `results/45K30K_.../`, `results/40K35K_..._v1/` | Everything the runs wrote. |
| `results/2X35K_rev3_..._stopped_41min/` | The earlier 2 × 35k run, stopped by the user at 41 min: partial. |
| `docs/` | The Experiment 15 README and all Notes (01-11). |

**What each run folder holds:**

| File | Contents |
|---|---|
| `q27-xhigh-...log` | Kaggle kernel log (JSON lines) |
| `kernel_log.txt` | The same, flattened |
| `q27x/e12_run_report.json` | Per-attempt records `branches`, `eval_unit_records`, `eval_b_attempts`, scheduler gauges, engine caps |
| `q27x/e12_generated_attempts.json` | All candidate answers |
| `q27x/sglang_server_try0.log` | The full SGLang log (decode lines every 40 iterations) |
| `q27x/duck/<task>_b<k>/` | `transcript.txt` (all prompts, the full thinking, tool calls and results), `branch_result.json`, `prompts/prompt.log` |
| `submission.json` | The commit's submission |

`per_branch_table.py` prints the per-attempt table.
