# E15P audit pack — the Poetiq S60 solver (S1-60K method) on the E15B Duck engine

Date: 2026-10-25. Project: Kaggle ARC Prize 2026 ARC-AGI-2, Qwen3.8-27B, 4 x L4 24 GB, SGLang 0.5.21, RedHat INT4
W4A16 + BF16 DFlash2 drafter, offline, 12-h rerun on 240 hidden tasks.

## Why this notebook

- Poetiq S1-60K (vLLM FP8, 12 streams) is our best LB, 34.58. On eval it solves much more than it does on the LB:
  - Poetiq R5 EVAL120: task-norm 48.6 %, LB 21.39;
  - LB / eval about 0.44 for Poetiq vs 1.06 for direct 49k.
- Coverage (throughput within 12 h) binds.
- The E15B Duck engine is our fastest SGLang serving setup: 16 real streams, ~430-520 tok/s aggregate decode measured in the Duck EVAL120 runs (2026-10-25).
- E15P = Poetiq unchanged + that engine.

## Files

| File | sha256 / note |
|---|---|
| `Q27-XHIGH-E15P_EVAL120_S60_S16_POETIQ_SGLANG.ipynb` | daf483ed126d71e0dcee1a80884197570a7b176ed60cda7d8dbe5f325f24f5b2 — the notebook to audit |
| `sources/Q27-XHIGH-E15B_EVAL120_50K45K_S16_R3K1_DUCK_SGLANG.ipynb` | 6baa9361c0e08666cca4835f677a6fb4dab7d45949a52cc75543a5384929ba25 — engine source (pushed Duck run) |
| `sources/Q27-XHIGH-v1_4_4_E11_05_S60_SGLANG_INT4_DFLASH2_EVAL120_6H.ipynb` | 3af4660a10a9a133bdf03aae685c980e4c9ab7134821f2c276b337e71732057c — Poetiq source (S60 = S1-60K on SGLang, 12 streams) |
| `build/build_e15p.py` | builder: composes the notebook from the two sources |
| `harness/harness_e15p_nb.py`, `harness/e15p_fake_server.py`, `harness/make_e15p_fake_server.py` | CPU harness + fake SGLang server |
| `harness/logs/e15p_{commit,kvgate,drain,rerun}.log` | harness runs (all PASS) |
| `diffs/*.diff` | every changed cell vs its source; the engine vs the E11-05 S60 engine |
| `notes/18 ... E15P ....md` | the build note (cell map, engine differences, KV estimate, harness results) |

## Cell map (10 code cells)

| # | Cell | Source | Identical? |
|---|---|---|---|
| 0 | mode + fallback submission | R3K1 cell 0 | yes |
| 1 | config | R3K1 cell 1 | edited (see `diffs/cell1_config_R3K1_to_E15P.diff`) |
| 2 | E14 facts / phase record / staging | R3K1 cell 2 | edited (variant name, Duck payload entry removed) |
| 3 | install | R3K1 cell 3 | yes |
| 4 | task order | R3K1 cell 5 = S60 cell 3 | yes |
| 5 | Poetiq donor | S60 cell 4 | yes |
| 6 | engine (SGLang launch, capacity gate, /generate streaming shim) | R3K1 cell 6 | yes, plus a header comment |
| 7 | Poetiq scheduler | S60 cell 7 | yes |
| 8 | Poetiq report | S60 cell 8 | yes |
| 9 | E14 report + bundle | R3K1 cell 11 | yes |

**Dropped from R3K1:**
- the Duck package;
- the E14 measurement cells 5b / 6b (run only with the E14A profile);
- the Duck solver and report.

**Dropped from S60:**
- its own engine cell (12 streams);
- the vLLM FP8 fallback cell.

The E15B engine has its own 12-stream / W1 relaunches instead. It has no vLLM fallback: if SGLang never comes up, the submission is the identity fallback.

**Equality checks (computed when this pack was built):** {"cell 0 = R3K1 cell 0": true, "cell 3 (install) = R3K1 cell 3": true, "cell 4 (task order) = R3K1 = S60": true, "cell 5 (Poetiq donor) = S60 cell 4": true, "cell 7 (Poetiq scheduler) = S60 cell 7": true, "cell 8 (Poetiq report) = S60 cell 8": true, "cell 9 (E14 7b) = R3K1 cell 11": true}

## Config changes vs the sources

- **Duck block removed** from CELL 1. `E12_MAMBA_TRACK_64 = False` stays, because the engine cell reads it.
- **New default profile `E15PEVAL120`:** 120 eval tasks, 6.0 h, margins as the S60 EVAL120 6H profile. The commit is scored; the rerun = all hidden tasks (profile RERUN_ALL).
- **S60 values carried in** (R3K1's CELL 1 had the E11-06 P1 values):
  - `SGL_DRAIN_MARGIN_SEC` 12 min (was 8);
  - `POETIQ_MAX_SOLUTIONS` 5 (was 2);
  - `POETIQ_SHUFFLE` 1 (was 0).
- **`SGL_KV_PER_REQUEST` 50k** (E15B), so the capacity gate gives `min(16, mamba // slots, max verify-graph bs, KV // 50k)` = 16. S60 used 70k → 12.
- **Unchanged Poetiq values:**
  - THINK_BUDGET 60,000 (the user's floor: no request below 60k);
  - 1 expert, 10 iterations, temperature 1.0, top_k 20;
  - ORDER2 + cells order for iteration 1;
  - the KV admission gate = min(E10 0.95 / 12, SGL 0.85 / 10) = no new request when KV > 0.85 and ≥ 10 running.

## Engine differences (E11-05 S60 → E15P)

| Setting | E11-05 S60 | E15P |
|---|---|---|
| Client streams / `--max-running-requests` | 12 / 13 | 16 / 17 |
| CUDA graphs | `--cuda-graph-max-bs-decode 12` | `--cuda-graph-bs-decode 1..17` |
| DFlash draft tokens | 8 | 6 |
| Mamba cache | 56 | 68 |
| `--min-free-slots-delay` | default | 1 (off) |
| `--schedule-policy` | default | lpm |
| Chat parsers (qwen3 / qwen3_coder), `preserve_thinking` chat kwarg, `--enable-cache-report` | no | yes |
| Model copy to /dev/shm (ranged parallel readers) | no | yes |
| E14 backports of SGLang PRs 44401 + 41872 | no | yes |
| Stall-based readiness wait | no | yes |
| Launch fallbacks | lazy / oom → vLLM FP8 | 16 → 12 streams → diagnosed → W1 (width 8) |

Poetiq calls `/generate` with `input_ids` (no chat template on the server), streaming, `no_stop_trim`, `skip_special_tokens` False. The chat parsers and the chat-template kwargs should not touch it. **Please verify this against SGLang 0.5.21.**

## KV at 16 Poetiq streams (our estimate; please check)

Past Poetiq SGLang runs at 12 running, on an 881k-token KV pool:

| Run | Final context per request: mean | p90 | max | Prompt p50 | KV max | KV mean |
|---|---|---|---|---|---|---|
| E11-05 EVAL30 | 58.4k | 67.4k | 75.7k | 8.6k | 0.59 | 0.43 |
| E11-06 P1-60K | 61.0k | 73.1k | 76.1k | 9.9k | 0.72 | 0.41 |

- **Scaling:** × 16 / 12 gives a KV peak of 0.79-0.96. The 0.85 admission gate holds new work at the peak.
- **Retraction:** running requests can still grow, so SGLang retraction is possible. None was seen in the 12-stream runs.
- **Duck:** the Duck 50K45K run peaked at 0.81 with 16 streams.
- **Earlier evidence (vLLM FP8):** a 2026-10-17 vLLM FP8 study (D66 / L66) saw 66 preemptions at 16 slots vs 0 at 12. That was a different engine and different contexts.

## Harness (CPU, no GPU)

**What is real and what is fake:**
- Runs all 10 real cells against a fake SGLang server.
- The fake's launch log, `/metrics` and decode lines come from the E14 fake.
- Poetiq streaming in the fake: thinking + `</think>` + a python block + EOS, a forced close, aborts.
- Only the sandbox verifier is faked (MARK markers). The real sandbox self-test fails on Windows (no `os.geteuid`); Kaggle is Linux.

**Modes and results:**

| Mode | What it runs | Checks |
|---|---|---|
| commit | 120 eval tasks | 24 / 24 |
| kvgate | 20 tasks, server reports KV 0.97 | 16 / 16 |
| drain | 8 tasks, 2 never close | 18 / 18 |
| rerun | 8 test tasks | 18 / 18 |

**What the checks cover:**
- the flags, concurrency 16 and real 16 in flight;
- max_new 60,000 on every phase-1 request;
- ORDER2, and iteration 1 everywhere before any iteration 2;
- thinking saved;
- the forced close is exact;
- drain: abort, then answer, then verify; no admission after the drain;
- the KV gate holds at 10;
- the rerun submission;
- payload: only the E14 modules zip is needed;
- staging;
- the phase record.

**Not done yet:** the Kaggle CPU kit (pinned image, Python 3.12) and any GPU run.

## What we ask you to audit

1. Composition: does any kept cell still depend on a dropped Duck cell? Look for names, files, env vars, and import order.
2. Does the E15B engine serve Poetiq's streaming `/generate` exactly like the E11 engine did? Check:
   - the parsers;
   - lpm;
   - `--incremental-streaming-output`;
   - the abort path;
   - finish reasons;
   - stop ids;
   - `cached_tokens`.
3. Is 16 Poetiq streams safe on KV, mamba and graphs? Is the 0.85 gate enough, or should `SGL_KV_PER_REQUEST`, the gate or the stream count change?
4. Is DFlash width 6 right for Poetiq's long single-shot thinking? It was chosen on Duck's request pattern.
5. Time: 6-h commit on 120 tasks. In the rerun, is every hidden task reached by iteration 1? Projection: S1-60K iteration 1 on EVAL120 = 7.18 M generated tokens.
6. Anything in the Poetiq cells that assumed 12 streams or vLLM, for example:
   - sandbox workers (4);
   - verification throughput at 16;
   - the E10 KV gate minimum;
   - the drain behaviour.
7. Failure paths: SGLang never ready (no vLLM fallback now), a server death mid-run, the hard stop.

Please report each finding with severity, evidence (file / line or cell / line) and a concrete fix.
