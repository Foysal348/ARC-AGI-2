# Audit request: E23 "six levers" GPU notebooks, rev 3e (Qwen3.8-27B on Kaggle 4x L4, vLLM 0.32)

## Rev 3d and 3e changes (read this first)
**Rev 3d** applies the 20-item priority list from four GPT audits of rev 3c (`reviews/gpt4_rev3c/REV3C_GPT4_PRIORITY_FIX_LIST_2026-10-30.md`).

**Rev 3e** fixes what four independent agent reviews found in rev 3d (`reviews/agents_rev3d/`):
- coverage A and B;
- new bugs C and D.

Decisions taken, and why:
- **FULL is 690 min (11.5 h of the 12 h session).** This is the user's decision. An "8 h hard stop" belongs to an old rev 1 text and does not apply.
- **EAGLE pin `0.32.0rc1.dev283+eagle.5`.** The EAGLE-4 CHANGELOG 0.1.4 (2026-10-28) pins vLLM `+eagle.5` for eagle-harness 0.1.4. `+eagle.4` belongs to 0.1.3. The licence was accepted by the user.
- **The NVFP4 gate is calibrated on BF16 KV.** An FP8-vs-FP8 A/A is exactly 0 on a deterministic engine, so it cannot set a tolerance. The new reference is a BF16-KV (`kv auto`) teacher-forced run. FP8 KV (production) and NVFP4 KV are both measured against it. NVFP4 passes when it is not much worse than FP8 KV:
  - mean |Δ| ≤ max(3×FP8, 0.02);
  - p99 ≤ max(3×FP8, 0.2);
  - rank-1 ≥ FP8 − 0.02.

  This is a screening policy, not an accuracy proof.
- **GPU faults taint the arm only.** A fault line marks that arm NO_GO_GPU_FAULT. Later arms carry a label and still run, so the risky arms (compiled PP4, FULL graphs, cutedsl) cannot void the A/A fill.

What else changed:
- **Correctness gate:** it also fails on garbage-under-load windows and on failed chat probes (real servers only).
- **Budget:** the FULL step estimates add up to 651 min, and the builder asserts the sum is ≤ 670. SMOKE_A has 135 min and SMOKE_B 215.
- **Merlin sha:** checked before every Merlin step. The install overlaps the hash. A mismatch fails every Merlin step; a hash still running when the step starts is labelled UNVERIFIED.
- **EAGLE:** it falls through on LAUNCH_FAILED, SERVER_DIED, BODY_ERROR and NO_GO, within a shared 40-min window.
- **G0 control:**
  - G arms are voided only if G0 (PIECEWISE pinned) reads FULL. Without a G0 result the verdict carries an UNCONTROLLED label.
  - A downgrade counts only when the mode falls to PIECEWISE or NONE; the 0.32 wording is matched.
  - The profile settle limit is about 1540 s, and accepted tokens are required in the profile window.
- **P4/P5 and prefetch:** P4 and the prefetch do not start after a P5 release abort. A P4 shape with no result gives SHAPE_NO_RESULT, not "synthetic".
- **Clean references only** (including `merlin_90k` and teacher-forced references). The kit hash is a hard stop only for runs that use P4/P5.
- **Tests:** `src/harness/gate_tests.py` holds 65 injected-fault cases on the real gate functions; they run in Kaggle CPU kit p1.
- **CPU kit rev 3e:** p1, p2, p3 and p4 are all ALL OK (`kaggle_cpu_kit/rev3e/`, `CONSOLIDATED_VERDICT.json`). p4 is the real Merlin offline install with the GCC 13/11 FlashInfer JIT probe.
- **Kernels:** `kernels_dataset/q27_e23_kernels_manifest.json` holds the hashes of the P4/P5 `.so` files and benches. The binaries live in the Kaggle dataset `q27-e23-sm89-kernels`.

Please check:
1. Is any fix in the two lists missing or wrong?
2. Did a new bug come in?
3. Is the BF16-calibrated NVFP4 gate a sound screen?
4. Are the GPU-fault labelling rules sound?

## Rev 3c changes (rev 3 → 3b → 3c)
Rev 3c folds in a second round of five independent audits (`audit5_rev3b/*.md` in this zip).

**3b**
- The 120k band prompt is now 116k tokens, which leaves 14.5k new tokens. The window context is about 117-121k.
- Kaggle CPU kit v1 found two problems, now fixed:
  - the Merlin env model variation is `v1`, not `default`;
  - a missing tmp directory in the kit itself.
- Kit v2: ALL OK.

**3c: correctness of the measurement**
- **Teacher-forced prompt logprobs (four audits found this).** On stock vLLM 0.32 they materialize chunk × 248k-vocab logits, which runs out of memory at 0.90. They now run on their own short launches:
  - FP8-KV reference and NVFP4;
  - `spec 0, seqs 2, max-num-batched-tokens 512, mem 0.80`;
  - the same settings on both sides.

  On Merlin (whose fork budgets this memory) the call stays, as the last call of a step.
- **Trace verdict.** Only `cat == "user_annotation"` forward ranges count. Kineto's `gpu_user_annotation` copies have no launches and turned every verdict into EAGER. The rank-0 trace is now kept in OUT.
- **Garbage detector.** Only alphabetic words count: `[A-Za-z]{3,}`, more than 60 words, fewer than 8 % unique. ARC grid dumps flagged 25-31 % of real outputs before. Now: 0 of 384 E19 rows, and 0 of 7,146 windows over 400 real thinking traces.
- **compare().** An errored or empty candidate row is INCONCLUSIVE, not FAIL_HIGH_MARGIN.
- **Teacher-forced lookup.** It never falls back to another token's logprob.
- **steady().**
  - `barrier.abort()` on an early exit.
  - Stalls are counted only for streams that were decoding at the window start.
  - The metrics read inside the window is in a try (5 misses give INCONCLUSIVE_METRICS_LOST).

**3c: time and plan**
- Estimates are realistic.
- The plan's unneeded levels are trimmed: G1-G3 no longer run 90k; NVFP4 target-only is correctness plus one census level; mtp0 runs 90k [12, 20] and no 120k.
- The INT4 control comes right after mtp0 (it is also PP4's oracle).
- PP4 runs compiled first, and eager only if compiled fails. It now runs after the six sections and before a greedy A/A fill. The A/A fill relaunches only configurations whose main run completed.
- The per-level guard includes admission (prefill) time.
- A band stops once it is KV-bound and records how many streams fit.
- A dead server stops its levels.
- Windows are written into a live step record before every save.
- **SMOKE_A** adds the Merlin TP1 x4 replica smoke (40k), a 90k greedy row, and Merlin teacher-forced rows.
- **SMOKE_B**:
  - mtp0 runs the oracle only;
  - NVFP4 SMOKE runs 120k@8;
  - kvauto and EAGLE are gated together;
  - the budget is 175 min.

**3c: robustness**
- **Merlin compiler.** Merlin serves with the payload's GCC 13 (README:229 says FlashInfer compiles at first start and needs GCC ≥ 13) plus its libstdc++. On a compile error in the log it retries once with the system GCC. On a TP1 OOM or launch failure it falls back to the profile defaults, never after the hard stop.
- **SMOKE_A without Merlin.** SMOKE_A fails in cell 1 if the Merlin checkpoint or env is missing.
- **P4 / P5.** Both run with Popen + killpg on timeout and `--timeout-per-shape`. The GPU-3 release check after P4 is now acted on. P5 runs before the checkpoint prefetch.
- **GPU gate.** It re-kills and waits another 300 s before aborting. An nvidia-smi failure after a good start counts as "not released".
- **#60532 patch.** The patch call is inside the try, and the revert is checked against the sha recorded before patching.
- **EAGLE.** Prefix caching ON first; prefix OFF only on a failed launch, labelled confounded.
- **Small fixes.**
  - `CUDA_DEVICE_ORDER=PCI_BUS_ID`;
  - a missing INT4 checkpoint gives SKIPPED;
  - skipped steps are printed;
  - the 4-GPU count is checked at start.
- **Kernel metadata.** The three GPU notebooks get kernel-metadata under `build/gpu_kernels/` (with `e23-merlin-env/Other/v1/1`).
- **CPU kit v3** runs the real Merlin offline install, plus these probes:
  - a GCC 13 vs GCC 11 C++20 CUDA compile + dlopen;
  - a FlashInfer JIT build inside the Merlin venv;
  - `launch.build()` with the notebook's arguments.

  Its verdict now fails on any errored step.

Note: the rev 3 text below is kept for context. Where it disagrees with this section, this section wins.

## Your role
You are an independent auditor. Read every file in this zip and find real defects before we spend GPU time on these notebooks. Rank each finding as BLOCKER, HIGH, MEDIUM or LOW. For each one, give:
- the file and line;
- the exact failure scenario;
- the evidence: a vLLM 0.32.0 source line URL or a doc quote;
- a concrete fix.

Then list what you verified as correct. Do not pad the report. Rev 1 has already been reviewed by five validation agents. Rev 3 includes all of their findings (listed below), so focus on what is still wrong.

## Context
- **Platform.** Kaggle ARC Prize 2026 (ARC-AGI-2) on 4x NVIDIA L4 (sm_89, 24 GB each, PCIe, no P2P). Offline GPU sessions of 12 h. Image: Ubuntu 22.04, glibc 2.35, Python 3.12, GCC 11.
- **Model.** Qwen3.8-27B, a hybrid of Gated-DeltaNet and full attention, with an MTP head.
- **Thinking budget.** Thinking runs up to 120k tokens, so every engine launch uses `--max-model-len 131072`. Context bands are 2k / 8k / 40k / 90k / 120k, and `max_new = 131072 - band - 512`.
- **Throughput goal.** The goal is 1500+ tok/s aggregate decode. Today we get about 311 tok/s over a whole run (vLLM 0.19, FP8, MTP3, 16-18 streams). The E22 synthetic 40k numbers on vLLM 0.32 are 414-439 tok/s.

### The six experiments
These follow the user's plan; DESIGN.md has the table.
1. **TP1x4 / PP4 with Merlin W4A16.**
   - Merlin is a vLLM 0.32 fork that serves one full model per L4.
   - Sequence: one L4 load plus a memory census → greedy oracle at 8k/40k/90k → 2 replicas → 4 replicas → matched throughput vs Merlin TP4.
   - The TP1xPP4 branch runs on stock vLLM, eager first and then compiled. It comes last because of #63505.
2. **Four-rank host-staged all-reduce (P5).** A standalone bench: oracle, 4-rank reduction, CUDA-graph capture. INT8 is a separate arm.
3. **FULL-graph speculative verification.** Each arm is compared with mtp0 and must show trace proof.
   - G0: FlashInfer PIECEWISE (pinned).
   - G1: TRITON_ATTN with FULL_AND_PIECEWISE.
   - G2: TRITON_ATTN with FULL_DECODE_ONLY.
   - G3: FlashInfer plus a runtime backport of PR #60532.
4. **SM89 CUTLASS block-FP8 GEMM (P4).** The kernel from PR #61224 against Marlin FP8, on the real layer shapes. It is a standalone bench on GPU 3 while Merlin TP1 runs on GPU 0.
5. **NVFP4 KV.** FP8 control → NVFP4 target-only → NVFP4 + MTP3 → 90k/120k census → more streams → matched throughput, with a teacher-forced comparison vs fp8_mtp0.
6. **MTP OFF / K1 / K3** at 8/12/16/20 streams.

An INT4 (RedHat W4A16, MTP3, 20 streams) control runs in FULL. EAGLE-4 is a SMOKE-only feasibility step, run in its own env with the vLLM fork `0.32.0rc1.dev283+eagle.5`. It has a BF16-KV (auto) MTP0 oracle.

### Variants (identical code; only the two baked lines MODE/PART differ)
| Notebook | MODE / PART | Budget | Content |
|---|---|---|---|
| `Q27-XHIGH-E23_SIX_LEVERS_SMOKE_A.ipynb` | SMOKE / A | 120 min | Merlin block: P5, TP1 + P4, TP4 |
| `Q27-XHIGH-E23_SIX_LEVERS_SMOKE_B.ipynb` | SMOKE / B | 150 min | Stock block: mtp0, mtp3/G0, G3, nvfp4, EAGLE, PP4 |
| `Q27-XHIGH-E23_SIX_LEVERS_FULL.ipynb` | FULL / ALL | **690 min** (11.5 h of the 12 h session) | Everything. A/A repeats fill the time while more than 120 min is left, then PP4 eager, then compiled (last). |

SMOKE_A and SMOKE_B are meant to run in parallel on two accounts. Windows are 30 s in SMOKE and 120 s in FULL.

## Rev 3 changes (rev 1 → rev 3; the findings of 5 validation agents)
- **Plan fidelity.**
  - SMOKE split into A/B.
  - A per-GPU release gate.
  - The P4 thread is joined.
  - A watchdog hard stop.
  - G0 pinned to PIECEWISE; the G arms are compared with mtp0.
  - The #1 memory census and replicas.
  - TP4 90k at 8 streams.
  - An INT4 control.
  - The NVFP4 arms are skipped on an NVFP4 NO_GO.
  - Step time is reported.
  - PP4 is included.
- **Measurement (`steady`).**
  - Admission is progress-based. The cap is `max(420, 120 + level*plen/700)` s.
  - Settled means:
    - no preemption;
    - every running request has emitted and is still gaining tokens;
    - and waiting == 0 or a KV plateau held for 30 s.
  - A Barrier aligns the replica windows.
  - The idle gate runs at entry.
  - STEADY requires running min == max == level. Otherwise the status is CAPACITY_LIMITED or INCONCLUSIVE_*.
  - Garbage under load fails the window.
  - Token-id logprobs are used (`return_tokens_as_token_ids`).
  - Stream errors are snapshotted before the stop.
- **Profiler and trace.**
  - The profiler runs only after settle, with `delay_iterations` / `max_iterations` and `ignore_frontend`.
  - The verdict is per forward, from the gpu_model_runner annotations (`VLLM_CUSTOM_SCOPES_FOR_PROFILING=1`), with a CUPTI-correlation fallback.
  - Kernel categories are an ordered list, attention before gdn.
- **Robustness.**
  - Port TIME_WAIT: a connect-based check plus a 90 s wait.
  - kill() always ends with a group SIGKILL.
  - Merlin `-lcuda` stub shim.
  - The TP1 / TP4 configuration falls back to profile defaults on LAUNCH_FAILED.
  - Prefetch.
  - A RERUN guard: a competition rerun writes only a fallback submission, with no exception.
  - Install failures are cached.
  - EAGLE runs in its own env.
  - The stock install rc is checked.
  - The #60532 patch has a backup, a dry-run and a sha-verified restore; it ABORTs if the revert fails.
  - Kit sha256 check against the dataset manifest; checkpoint identity hashes.
  - SERVER_DIED (alive_after_body / rc), BODY_ERROR, ERROR_REPLICA, and a try/except per level.
  - Stale bench JSON is deleted.
- **Engine.**
  - System GCC at serve time (GCC 13 only for the Merlin install).
  - Per-replica ports, MASTER_PORT / VLLM_PORT, TRITON / FlashInfer caches.
  - `KV_TP1 = 8055029760`; TP1 seqs 4 with capture [1,2,5,10,15,20]; TP4 seqs 24 with capture up to 120.

## Files
- `notebook/`: the 3 generated notebooks, 114 kB each.
- `build/build_e23_notebook.py`: the builder. Cell code is in MD0 and CELL1..CELL6.
- `build/build_cpu_kit_e23.py`: the Kaggle CPU kit. It runs all 3 notebooks against a fake vLLM server with the real /kaggle/input mounts, plus lab unit tests on Linux and a competition-RERUN check.
- `src/e23_lab.py`: the lab module, which is embedded into CELL1.
- `design/DESIGN.md` and `design/PREP_KITS_2026-10-29.md`: the plan, and the CPU-verified prep artifacts. Those artifacts are now Kaggle Models / Datasets.
- `prep/`: the offline Merlin install (glibc 2.35 fix = a weak GLIBC_2.38 need plus an LD_PRELOAD shim for `__isoc23_strto*`), and the EAGLE offline env builder.
- `patches/pr60532.diff` (its flashinfer.py hunk is applied at runtime) and `patches/pr61224.diff`, which is built into the P4 kit .so.
- `merlin_ref/`: Merlin `launch.py` and profiles (Apache-2.0).
- `benches/`: the P4 and P5 benches.
- `local_fake_run/`: Windows CPU runs against `fake_vllm_server.py`.
  - SMOKE_A: 7.6 min, all windows STEADY.
  - SMOKE_B: 6.2 min, oracles EXACT. In fake mode PP4 is NO_GO (no chat endpoint), EAGLE is SKIPPED (no artifact) and the trace is NO_TRACE_FILE (no profiler).
  - FULL with a 90-min budget, if it is present.

## Facts already verified (do not re-derive)
**CPU kit, real vLLM 0.32.0 parser.** These were accepted:
- `--profiler-config {profiler: torch, torch_profiler_dir}`;
- `--mamba-ssm-cache-dtype`;
- `--prefix-match-unit`;
- `--enable-mamba-shared-prefix-checkpoint`;
- `use_local_argmax_reduction` (speculative);
- `cudagraph_mode` FULL_AND_PIECEWISE / FULL_DECODE_ONLY.

**vLLM 0.32 facts.**
- `kv-cache-dtype nvfp4` on SM8x is in 0.32.0 (#46963).
- Thinking comes back in `reasoning`.
- `prompt_tokens_total` is counted once, at the first output token.
- `generation_tokens_total` counts accepted + bonus tokens.

**Merlin.** The offline install reports INSTALL OK and ENVIRONMENT VERIFIED on the pinned image, and the engine imports with the shim. `launch.build` resolves the TP1 / TP4 argv and env without host checks.

**EAGLE fork.**
- It installs offline and imports.
- The plugin `eagle_harness` and the CUSTOM attention backend are present.
- 4 launch commands parse.

## What to check
1. **Every launch command: valid and sensible for its engine and version.**
   - stock_flags: FP8 / INT4 / NVFP4 / PP4 / TRITON, compilation-config, profiler-config, max-model-len 131072.
   - merlin_server: overrides as last args, KV_BYTES, capture sizes, env, shim, ports.
   - The EAGLE step.
   - Does each launch fit 24 GB per GPU at max-model-len 131072?
2. **Measurement semantics in vLLM 0.32.**
   - Can the settle rule in `steady` fail, settle too early, or never settle at 90k / 120k with the admission cap?
   - Spec-decode metric names.
   - `kv_cache_usage_perc`.
   - Abort-on-disconnect of stopped streams.
   - Can the trace verdict (graph launches vs kernel launches per forward) prove FULL-graph verification?
3. **Plan fidelity and time.**
   - Every step of the six sequences is present and nothing is extra.
   - SMOKE A/B cover the risky pieces.
   - The time estimates are realistic: stock TP4 starts in 430-545 s, plus the Merlin first-start JIT.
   - Check whether FULL really uses about 11.5 h (A/A loop guard, PP4 last) and stops cleanly before the 12 h limit.
4. **Kaggle robustness.**
   - Input discovery under `/kaggle/input/models/<owner>/<slug>/<framework>/<variation>/<version>`.
   - Disk: the /tmp extracts of 4.3 GB and 4.25 GB, plus the venvs.
   - Process-group cleanup and port reuse.
   - nvidia-smi PIDs and memory.used for the GPU gate.
   - P4 on GPU 3 alongside Merlin TP1 on GPU 0.
   - P5 needing all 4 GPUs and /dev/shm.
   - The rerun guard.
   - Notebook size: the commit limit is < 400 kB.
5. **Plain bugs.** Wrong variables, closures, swallowed exceptions, a failure reported as success, thread leaks, report-table mapping.
