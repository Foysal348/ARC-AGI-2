"""E23 lab: port-parameterized server lifecycle and measurement for the six-lever notebook (stdlib only).

Base: the Exp 14 VMS harness (VServer / VGen: token ids from return_token_ids, [DONE] + finish_reason required, socket
shutdown on stop, top-1/top-2 margins). Adopted from the consolidated v3 notebook (2026-10-29 review):
  - same-weight greedy oracle classified by the oracle's logprob margin at the first differing token
    (EXACT / NEAR_TIE / FAIL_HIGH_MARGIN >= 0.5 / INCONCLUSIVE), never PASS on missing data;
  - steady decode = vllm:generation_tokens_total over a window that starts only after prefill has settled
    (prompt-token counter flat, every running request has emitted), rejected on preemption or prefill inside the window;
  - a GPU-release gate (no compute PIDs on any GPU) after every server;
  - fail-closed statuses.
Changed against the consolidated notebook: distinct ARC prompts per stream (shared-prefix prompts overstate KV
residency), 60 s windows (not 18 s), every server on its own port so TP1 replicas run side by side.
"""
import gzip
import json
import os
import re
import signal
import socket
import statistics
import subprocess
import threading
import time
import urllib.request as U
from pathlib import Path

FAIL_MARGIN = 0.5          # first differing token: oracle top-1 minus top-2 logprob at or above this = real divergence


# ------------------------------------------------------------------ server lifecycle
class Server:
    def __init__(self, name, argv, env, port, log_dir):
        self.name, self.argv, self.env, self.port = name, [str(a) for a in argv], dict(env), int(port)
        self.log_path = Path(log_dir) / f"server_{name}.log"
        self.proc, self.t0, self.ready_sec = None, None, None

    @property
    def url(self):
        return f"http://127.0.0.1:{self.port}"

    def start(self):
        if not port_free(self.port):
            raise RuntimeError(f"PORT_BUSY {self.port}")
        self.log_path.parent.mkdir(parents=True, exist_ok=True)
        self._fh = open(self.log_path, "w", encoding="utf-8")
        self.t0 = time.perf_counter()
        self.proc = subprocess.Popen(self.argv, env=self.env, stdout=self._fh, stderr=subprocess.STDOUT,
                                     start_new_session=True, cwd="/tmp" if os.path.isdir("/tmp") else None)
        return self

    def alive(self):
        return self.proc is not None and self.proc.poll() is None

    def log(self):
        try:
            return self.log_path.read_text(encoding="utf-8", errors="replace")
        except Exception:
            return ""

    def wait_ready(self, timeout):
        while time.perf_counter() - self.t0 < timeout:
            if not self.alive():
                return False, f"exited rc={self.proc.returncode}"
            try:
                U.urlopen(self.url + "/health", timeout=10).read()
                self.ready_sec = round(time.perf_counter() - self.t0, 1)
                return True, f"ready in {self.ready_sec}s"
            except Exception:
                time.sleep(3)
        return False, "startup timeout"

    def kill(self):
        if self.proc is None:
            return
        for sig, wait in ((signal.SIGTERM, 40), (getattr(signal, "SIGKILL", signal.SIGTERM), 60)):
            try:
                os.killpg(self.proc.pid, sig) if hasattr(os, "killpg") else self.proc.kill()
            except Exception:
                pass
            try:
                self.proc.wait(timeout=wait)
                break
            except Exception:
                pass
        try:
            self._fh.close()
        except Exception:
            pass

    def facts(self):
        """What vLLM logged at startup: KV pool, max concurrency, selected kernels, graph mode."""
        t = self.log()
        kv = [int(x.replace(",", "")) for x in re.findall(r"GPU KV cache size: ([\d,]+) tokens", t)]
        mc = re.findall(r"Maximum concurrency for [\d,]+ tokens per request: ([\d.]+)x", t)
        kern = sorted(set(re.findall(r"Selected (\w+Kernel) for", t)))
        graph = sorted(set(re.findall(r"cudagraph_mode[\"'=: ]+([A-Z_]+)", t)))[:6]
        errs = [l[:300] for l in t.splitlines() if re.search(r"Traceback|CUDA error|illegal memory|out of memory|"
                                                               r"RuntimeError|AssertionError", l)][:12]
        return {"kv_tokens": min(kv) if kv else None, "kv_tokens_all": kv, "max_concurrency": float(mc[-1]) if mc else None,
                "kernels": kern, "graph_modes": graph, "error_lines": errs, "ready_sec": self.ready_sec}


def port_free(port):
    s = socket.socket()
    try:
        s.bind(("127.0.0.1", int(port)))
        return True
    except OSError:
        return False
    finally:
        s.close()


def gpu_pids():
    try:
        r = subprocess.run(["nvidia-smi", "--query-compute-apps=pid", "--format=csv,noheader,nounits"],
                           capture_output=True, text=True, timeout=30)
    except Exception:
        return None
    if r.returncode:
        return None
    return sorted({int(x) for x in r.stdout.split() if x.strip().isdigit()})


def gpu_mem():
    try:
        r = subprocess.run(["nvidia-smi", "--query-gpu=index,memory.used,memory.total", "--format=csv,noheader,nounits"],
                           capture_output=True, text=True, timeout=30)
        return [[int(v) for v in l.split(",")] for l in r.stdout.strip().splitlines() if l.strip()]
    except Exception:
        return None


def wait_gpu_release(timeout=180, fake=False):
    """True when no compute process holds any GPU (nvidia-smi); None when nvidia-smi is unavailable (CPU harness)."""
    if fake:
        return True
    end = time.time() + timeout
    while time.time() < end:
        p = gpu_pids()
        if p is None:
            return None
        if not p:
            return True
        time.sleep(3)
    return False


# ------------------------------------------------------------------ metrics
def prom(port):
    txt = U.urlopen(f"http://127.0.0.1:{port}/metrics", timeout=15).read().decode("utf-8", "replace")
    out = {}
    for line in txt.splitlines():
        if not line or line.startswith("#"):
            continue
        m = re.match(r"^([A-Za-z_:][A-Za-z0-9_:]*)(\{[^}]*\})?\s+(\S+)", line)
        if not m:
            continue
        try:
            v = float(m.group(3))
        except ValueError:
            continue
        if v != v:
            continue
        out[m.group(1)] = out.get(m.group(1), 0.0) + v
        out[m.group(1) + "@max"] = max(out.get(m.group(1) + "@max", v), v)
    return out


GEN, PROMPT, RUN, WAIT = ("vllm:generation_tokens_total", "vllm:prompt_tokens_total", "vllm:num_requests_running",
                          "vllm:num_requests_waiting")
PREEMPT, KVU = "vllm:num_preemptions_total", "vllm:kv_cache_usage_perc"
ACC, DRF, DTOK = ("vllm:spec_decode_num_accepted_tokens_total", "vllm:spec_decode_num_drafts_total",
                  "vllm:spec_decode_num_draft_tokens_total")


# ------------------------------------------------------------------ one streaming request (Exp 14 VGen, port-aware)
class Stream(threading.Thread):
    def __init__(self, port, ids, max_new, temperature=1.0, seed=None, logprobs=0, ignore_eos=True, model="q27"):
        super().__init__(daemon=True)
        self.port = int(port)
        self.body = {"model": model, "prompt": list(ids), "max_tokens": int(max_new), "temperature": temperature,
                     "top_p": 0.95 if temperature else 1.0, "stream": True, "ignore_eos": ignore_eos, "return_token_ids": True}
        if temperature:
            self.body["top_k"] = 20
        if seed is not None:
            self.body["seed"] = int(seed)
        if logprobs:
            self.body["logprobs"] = int(logprobs)
        self.text, self.tokens, self.margins = [], [], []
        self.err, self.done_seen, self.finish_reason = None, False, None
        self.t_start = self.t_first = self.t_end = None
        self._resp, self._halt = None, False

    def run(self):
        self.t_start = time.perf_counter()
        try:
            req = U.Request(f"http://127.0.0.1:{self.port}/v1/completions", data=json.dumps(self.body).encode(),
                            method="POST", headers={"Content-Type": "application/json"})
            self._resp = U.urlopen(req, timeout=7200)
            for raw in self._resp:
                if self._halt:
                    break
                line = raw.strip()
                if not line.startswith(b"data:"):
                    continue
                payload = line[5:].strip()
                if payload == b"[DONE]":
                    self.done_seen = True
                    break
                d = json.loads(payload)
                if "error" in d or d.get("object") == "error":
                    self.err = ("stream error: " + json.dumps(d.get("error") or d.get("message") or d))[:300]
                    break
                for c in d.get("choices") or []:
                    self.text.append(c.get("text") or "")
                    ids_ = c.get("token_ids")
                    lp = c.get("logprobs") or {}
                    if ids_ is None:
                        if c.get("text") or lp.get("tokens"):
                            self.err = "MISSING_STREAM_TOKEN_IDS"
                    elif any(not isinstance(v, int) or isinstance(v, bool) for v in ids_):
                        self.err = "INVALID_STREAM_TOKEN_IDS"
                    else:
                        if ids_ and self.t_first is None:
                            self.t_first = time.perf_counter()
                        self.tokens.extend(ids_)
                    for top in lp.get("top_logprobs") or []:
                        vals = sorted((v for v in (top or {}).values() if isinstance(v, (int, float))), reverse=True)
                        self.margins.append(round(vals[0] - vals[1], 4) if len(vals) >= 2 else None)
                    if c.get("finish_reason") is not None:
                        self.finish_reason = c["finish_reason"]
                if self.err:
                    break
        except Exception as e:
            if not self._halt:
                self.err = repr(e)[:300]
        self.t_end = time.perf_counter()
        if not self._halt and not self.err and not (self.done_seen and self.finish_reason):
            self.err = f"INCOMPLETE_SSE done={self.done_seen} finish={self.finish_reason}"

    def stop(self):
        self._halt = True
        try:
            self._resp.fp.raw._sock.shutdown(socket.SHUT_RDWR)
        except Exception:
            pass
        try:
            if self._resp is not None:
                self._resp.close()
        except Exception:
            pass

    def row(self):
        return {"text": "".join(self.text), "tokens": list(self.tokens), "margins": list(self.margins), "error": self.err,
                "done": self.done_seen, "finish_reason": self.finish_reason}


# ------------------------------------------------------------------ correctness
def greedy(port, prompts, n_tok=128, logprobs=2, timeout=900, model="q27"):
    """Greedy rows for the same-weight oracle (one request at a time: batch-size effects stay out of the comparison)."""
    rows = []
    for ids in prompts:
        g = Stream(port, ids, n_tok, temperature=0.0, logprobs=logprobs, ignore_eos=True, model=model)
        g.start()
        g.join(timeout)
        if g.is_alive():
            g.stop()
            g.join(10)
            r = g.row()
            r["error"] = r["error"] or "GREEDY_TIMEOUT"
        else:
            r = g.row()
        rows.append(r)
    return rows


def degenerate(text):
    """Objective garbage checks: empty, a run of one char, '!!!!' (the E3 / E13 garbage), very low variety."""
    t = text or ""
    if not t.strip():
        return "EMPTY"
    if re.search(r"(.)\1{60,}", t, re.S):
        return "REPEATED_CHAR"
    if t.count("!") > 0.5 * max(1, len(t)):
        return "BANG_GARBAGE"
    words = re.findall(r"\w+", t)
    if len(words) > 40 and len(set(words)) < 0.08 * len(words):
        return "LOW_VARIETY"
    return None


def compare(ref, cand):
    """Same-weight oracle (consolidated v3 logic): rows must be complete; at the first differing token the ORACLE's
    top-1 - top-2 logprob margin decides: >= FAIL_MARGIN -> FAIL_HIGH_MARGIN, below -> NEAR_TIE; identical -> EXACT."""
    if not ref or not cand or len(ref) != len(cand):
        return {"status": "INCONCLUSIVE_PAIRS_MISSING"}
    per, worst = [], "EXACT"
    rank = {"EXACT": 0, "NEAR_TIE": 1, "INCONCLUSIVE": 2, "FAIL_HIGH_MARGIN": 3}
    for a, b in zip(ref, cand):
        if a.get("error") or b.get("error") or not a.get("tokens") or not b.get("tokens"):
            st, d, m = "INCONCLUSIVE", None, None
        else:
            x, y = a["tokens"], b["tokens"]
            d = next((i for i in range(min(len(x), len(y))) if x[i] != y[i]), None)
            if d is None:
                st, m = ("EXACT" if len(x) == len(y) else "INCONCLUSIVE"), None
            else:
                mm = a.get("margins") or []
                m = mm[d] if d < len(mm) else None
                st = "INCONCLUSIVE" if m is None else ("FAIL_HIGH_MARGIN" if m >= FAIL_MARGIN else "NEAR_TIE")
        g = degenerate(b.get("text"))
        if g:
            st = "FAIL_HIGH_MARGIN"
        per.append({"first_diff": d, "oracle_margin": m, "status": st, "garbage": g})
        worst = st if rank[st] > rank[worst] else worst
    return {"status": worst, "rows": per}


def chat_probes(port, model="q27", cases=(("Reply with exactly one number: 7 * 6 =", "42"),
                                          ("Reply with exactly one number: 2 + 2 =", "4"),
                                          ("Reply with exactly one number: 9 - 3 =", "6"))):
    """Arithmetic through /v1/chat/completions with thinking off. vLLM 0.32 returns the answer in message.content and
    the thinking in message.reasoning (NOT reasoning_content: the consolidated notebook's blocker)."""
    out = []
    for q, want in cases:
        body = {"model": model, "messages": [{"role": "user", "content": q}], "temperature": 0, "max_tokens": 32,
                "chat_template_kwargs": {"enable_thinking": False}}
        try:
            r = json.loads(U.urlopen(U.Request(f"http://127.0.0.1:{port}/v1/chat/completions", data=json.dumps(body).encode(),
                                               headers={"Content-Type": "application/json"}), timeout=300).read())
            msg = r["choices"][0]["message"]
            got = (msg.get("content") or "").strip()
            out.append({"q": q, "want": want, "content": got[:80], "reasoning_chars": len(msg.get("reasoning") or ""),
                        "ok": re.search(r"(?<!\d)" + want + r"(?!\d)", got) is not None})
        except Exception as e:
            out.append({"q": q, "want": want, "error": repr(e)[:200], "ok": False})
    return {"ok": all(x["ok"] for x in out), "cases": out}


# ------------------------------------------------------------------ steady decode
def steady(port, prompts, level, secs=60.0, admit=420.0, max_new=8192, temperature=1.0, seed=1234, model="q27",
           sample=2.0):
    """`level` distinct prompts, then a decode window that starts only once prefill has settled. Status:
    STEADY / CAPACITY_LIMITED (fewer running than asked: KV) / INCONCLUSIVE_* / FAIL_*; never a made-up number."""
    r = {"level": level, "status": "INCONCLUSIVE_NOT_STARTED", "port": port}
    try:
        p0 = prom(port)
    except Exception as e:
        return {**r, "status": "INCONCLUSIVE_METRICS_UNAVAILABLE", "error": repr(e)[:200]}
    if GEN not in p0 or PROMPT not in p0:
        return {**r, "status": "INCONCLUSIVE_COUNTERS_MISSING"}
    ss = [Stream(port, prompts[i % len(prompts)], max_new, temperature, seed + i, model=model) for i in range(level)]
    for g in ss:
        g.start()
    try:
        t_adm, best, settled, prev_pt, samples = time.perf_counter(), 0, 0, None, []
        flat_since = None
        while time.perf_counter() - t_adm < admit:
            time.sleep(sample)
            try:
                m = prom(port)
            except Exception:
                continue
            run, wait, pt = int(m.get(RUN, 0)), int(m.get(WAIT, 0)), m.get(PROMPT)
            first = sum(g.t_first is not None for g in ss)
            best = max(best, run)
            samples.append([round(time.perf_counter() - t_adm, 1), run, wait, first])
            if all(not g.is_alive() for g in ss):
                return {**r, "status": "INCONCLUSIVE_STREAMS_ENDED_IN_ADMISSION", "errors": [g.err for g in ss if g.err][:3]}
            ok_now = run > 0 and pt == prev_pt and first >= run
            if run >= level and wait == 0 and ok_now:
                settled += 1
            elif run < level and wait > 0 and ok_now:       # KV-bound: the rest wait; accept a plateau held 30 s
                flat_since = flat_since or time.perf_counter()
                settled = settled + 1 if time.perf_counter() - flat_since > 30 else 0
            else:
                settled, flat_since = 0, None
            prev_pt = pt
            if settled >= 3:
                break
        r["admission"] = {"sec": round(time.perf_counter() - t_adm, 1), "best_running": best, "tail": samples[-6:]}
        if settled < 3:
            return {**r, "status": "INCONCLUSIVE_NO_SETTLE"}
        m0, t0 = prom(port), time.perf_counter()
        runs, kvs, mids = [], [], []
        while time.perf_counter() - t0 < secs:
            time.sleep(min(sample, max(0.1, secs - (time.perf_counter() - t0))))
            m = prom(port)
            mids.append(m)
            runs.append(m.get(RUN, 0))
            if KVU in m:
                kvs.append(m[KVU])
        m1, t1 = prom(port), time.perf_counter()
        if sum(g.is_alive() for g in ss) < min(level, best):
            return {**r, "status": "INCONCLUSIVE_STREAMS_ENDED_IN_WINDOW"}
        if any(x.get(PROMPT) != m0.get(PROMPT) for x in mids + [m1]):
            return {**r, "status": "INCONCLUSIVE_PREFILL_IN_WINDOW"}
        if m1.get(PREEMPT, 0) > m0.get(PREEMPT, 0):
            return {**r, "status": "INCONCLUSIVE_PREEMPTION", "preemptions": m1.get(PREEMPT, 0) - m0.get(PREEMPT, 0)}
        gen = m1.get(GEN, 0) - m0.get(GEN, 0)
        if gen <= 0:
            return {**r, "status": "FAIL_NO_DECODE"}
        dt = t1 - t0
        acc, drf, dtk = (m1.get(k, 0) - m0.get(k, 0) for k in (ACC, DRF, DTOK))
        rm = statistics.mean(runs) if runs else 0
        r.update(status="STEADY" if min(runs or [0]) >= level else "CAPACITY_LIMITED",
                 tok_s=round(gen / dt, 1), gen_tokens=int(gen), window_sec=round(dt, 1),
                 running_mean=round(rm, 2), running_min=min(runs or [0]), running_max=max(runs or [0]),
                 tok_s_per_stream=round(gen / dt / rm, 2) if rm else None,
                 accept_per_draft=round(acc / drf, 3) if drf else None,
                 accept_rate=round(acc / dtk, 3) if dtk else None,
                 kv_usage_mean=round(statistics.mean(kvs), 3) if kvs else None, kv_usage_max=max(kvs) if kvs else None,
                 t0=t0, t1=t1)
        if min(runs or [0]) < 0.8 * max(runs or [1]):
            r["status"] = "INCONCLUSIVE_RUNNING_UNSTABLE"
        return r
    finally:
        for g in ss:
            g.stop()
        for g in ss:
            g.join(10)
        r["client_leak"] = any(g.is_alive() for g in ss)
        r["stream_errors"] = sorted({g.err for g in ss if g.err and not g._halt})[:3]
        r["idle_after"] = wait_idle(port)


def steady_multi(jobs, secs=60.0, **kw):
    """Several servers at once (TP1 replicas): jobs = [(port, prompts, level)]. The aggregate counts only when every
    window is STEADY/CAPACITY_LIMITED and the windows overlap for >= 80 % of the shortest."""
    out = [None] * len(jobs)

    def one(i, j):
        out[i] = steady(j[0], j[1], j[2], secs=secs, **kw)
    th = [threading.Thread(target=one, args=(i, j), daemon=True) for i, j in enumerate(jobs)]
    for t in th:
        t.start()
    for t in th:
        t.join()
    good = all(o and o.get("status") in ("STEADY", "CAPACITY_LIMITED") for o in out)
    ov = (min(o["t1"] for o in out) - max(o["t0"] for o in out)) if good else 0
    aligned = good and ov > 0.8 * min(o["window_sec"] for o in out)
    return {"replicas": out, "aligned": aligned, "overlap_sec": round(ov, 1),
            "tok_s": round(sum(o["tok_s"] for o in out), 1) if aligned else None,
            "running_mean": round(sum(o["running_mean"] for o in out), 2) if aligned else None,
            "status": "AGGREGATE_STEADY" if aligned else "INCONCLUSIVE_REPLICA_WINDOWS"}


def wait_idle(port, wait=90.0):
    end, hits = time.perf_counter() + wait, 0
    while time.perf_counter() < end:
        try:
            m = prom(port)
            hits = hits + 1 if m.get(RUN, 0) == 0 and m.get(WAIT, 0) == 0 else 0
        except Exception:
            hits = 0
        if hits >= 3:
            return True
        time.sleep(2)
    return False


# ------------------------------------------------------------------ profiler (FULL-graph proof + per-category time)
CATS = {"nccl_allreduce": ("allreduce", "all_reduce"), "nccl_allgather": ("allgather", "all_gather"), "nccl_other": ("nccl",),
        "gemm_marlin": ("marlin",), "gemm_other": ("gemm", "cutlass", "xmma", "cublas", "sm89_", "ampere_"),
        "gdn_linear_attn": ("gdn", "fla", "chunk_", "recurrent", "gated_delta", "causal_conv", "mamba"),
        "attention": ("flash", "attn", "attention", "paged"), "sampling": ("sampl", "topk", "top_k", "argmax", "softmax")}


def trace_summary(pdir):
    files = sorted(Path(pdir).rglob("*.pt.trace.json*"), key=lambda p: p.stat().st_mtime)
    if not files:
        return {"error": "NO_TRACE_FILE", "listing": [str(p) for p in Path(pdir).rglob("*")][:20]}
    f = next((p for p in files if re.search(r"rank[-_]?0|_0\.", p.name)), files[0])
    with (gzip.open if f.name.endswith(".gz") else open)(f, "rt", encoding="utf-8") as fh:
        tr = json.load(fh)
    ev = tr.get("traceEvents", [])
    kern = [e for e in ev if e.get("ph") == "X" and str(e.get("cat", "")).lower() in ("kernel", "gpu_kernel")]
    rt = [e for e in ev if e.get("ph") == "X" and str(e.get("cat", "")).lower() in ("cuda_runtime", "cuda_driver")]
    graph_launch = sum(1 for e in rt if "GraphLaunch" in str(e.get("name", "")))
    kernel_launch = sum(1 for e in rt if re.search(r"LaunchKernel|cuLaunchKernel", str(e.get("name", ""))))
    per, tot, names = {k: 0.0 for k in list(CATS) + ["other"]}, 0.0, {}
    for e in kern:
        n, d = str(e.get("name", "")).lower(), float(e.get("dur", 0.0))
        tot += d
        names[e.get("name", "")] = names.get(e.get("name", ""), 0.0) + d
        k = next((k for k, pats in CATS.items() if any(p in n for p in pats)), "other")
        per[k] += d
    return {"file": f.name, "files": len(files), "kernels": len(kern), "kernel_us": round(tot),
            "graph_launches": graph_launch, "kernel_launches": kernel_launch,
            "by_category_pct": {k: round(100 * v / tot, 1) for k, v in per.items()} if tot else {},
            "top_kernels_us": dict(sorted(((k, round(v)) for k, v in names.items()), key=lambda x: -x[1])[:25])}


def profile(port, pdir, secs=6.0):
    """POST /start_profile, decode for `secs`, POST /stop_profile (needs --profiler-config at launch), then the summary."""
    rec = {}
    for ep in ("/start_profile", "/stop_profile"):
        try:
            U.urlopen(U.Request(f"http://127.0.0.1:{port}{ep}", data=b"", method="POST"), timeout=900).read()
            rec[ep[1:]] = "ok"
        except Exception as e:
            rec[ep[1:]] = repr(e)[:200]
        if ep == "/start_profile":
            time.sleep(secs)
    time.sleep(20)
    rec["trace"] = trace_summary(pdir)
    return rec


def profiled_load(port, prompts, level, pdir, secs=6.0, settle=240.0, max_new=8192, model="q27"):
    """`level` decoding streams (own window, not the measured one: the profiler slows decode), then profile() once
    running reaches the level (or a 30 s plateau). Needs --profiler-config torch_profiler_dir=pdir at launch."""
    ss = [Stream(port, prompts[i % len(prompts)], max_new, 1.0, 4321 + i, model=model) for i in range(level)]
    for g in ss:
        g.start()
    rec, t0, flat = {"level": level}, time.perf_counter(), None
    try:
        while time.perf_counter() - t0 < settle:
            time.sleep(2)
            try:
                m = prom(port)
            except Exception:
                continue
            run = int(m.get(RUN, 0))
            if run >= level:
                break
            flat = flat or (time.perf_counter() if run > 0 and m.get(WAIT, 0) > 0 else None)
            if flat and time.perf_counter() - flat > 30:
                break
        time.sleep(5)
        rec["running_at_start"] = prom(port).get(RUN)
        rec.update(profile(port, pdir, secs))
        return rec
    finally:
        for g in ss:
            g.stop()
        for g in ss:
            g.join(10)
        rec["idle_after"] = wait_idle(port)
