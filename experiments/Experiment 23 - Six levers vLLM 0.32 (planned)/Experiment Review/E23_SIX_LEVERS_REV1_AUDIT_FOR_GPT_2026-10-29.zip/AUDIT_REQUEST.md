# Audit request: E23 "six levers" GPU notebook (Qwen3.8-27B on Kaggle 4x L4, vLLM 0.32)

## Your role
You are an independent auditor. Read every file in this zip and find real defects before we spend GPU time on this notebook. Rank each finding BLOCKER, HIGH, MEDIUM or LOW, and give for each:
- file:line;
- the exact failure scenario;
- the evidence, as a vLLM 0.32.0 source line URL or a doc quote;
- a concrete fix.

Then list what you verified as correct. Do not pad the report.

## Context
- **Hardware and limits:** Kaggle ARC Prize 2026 (ARC-AGI-2). 4x NVIDIA L4 (sm_89, 24 GB each, PCIe, no P2P). Offline GPU sessions of 12 h.
- **Image:** Ubuntu 22.04, glibc 2.35, Python 3.12, GCC 11.
- **Model:** Qwen3.8-27B, a hybrid of Gated-DeltaNet and full attention, with an MTP head.
- **Goal:** 1500+ tok/s aggregate decode. Today we reach about 311 tok/s whole-run (vLLM 0.19, FP8, MTP3, 16-18 streams). The E22 synthetic 40k numbers on vLLM 0.32 are 414-439.

### The six experiments
The experiments are specified in DESIGN.md. The user's plan is summarised in its table.
1. TP1x4 / PP4. Merlin W4A16, one full model per GPU, using the Merlin fork of vLLM 0.32. PP4 runs on stock vLLM.
2. A 4-rank host-staged all-reduce kernel (P5). This is a standalone bench.
3. FULL-graph speculative verification:
   - G0: FlashInfer PIECEWISE.
   - G1 / G2: TRITON_ATTN with FULL_AND_PIECEWISE / FULL_DECODE_ONLY.
   - G3: FlashInfer plus a backport of PR #60532.
4. The SM89 CUTLASS block-FP8 GEMM from PR #61224 against Marlin FP8 (P4). This is a standalone bench.
5. NVFP4 KV and the number of resident streams at 90k.
6. MTP OFF, K1 and K3 at 8/12/16/20 active streams.

EAGLE-4 is a SMOKE-only feasibility step, using the EAGLE vLLM fork 0.32.0rc1.dev283+eagle.5.

### Modes
- `Q27X_E23_MODE=SMOKE`: about 60-75 min. Each new or risky piece runs once.
- `FULL`: about 6-7 h, with an 8 h hard stop.

## Files
- `notebook/Q27-XHIGH-E23_SIX_LEVERS.ipynb`: the GPU notebook, generated.
- `build/build_e23_notebook.py`: the builder. Cell code is in the strings MD0 and CELL1..CELL6.
- `src/e23_lab.py`: the lab module, embedded into CELL1. It covers:
  - server lifecycle per port;
  - Prometheus parsing;
  - a streaming /v1/completions client using token ids;
  - a same-weight greedy oracle classified by the oracle's top1-top2 logprob margin at the first differing token (FAIL at >= 0.5);
  - a steady decode window that starts after prefill settles and is rejected on prefill or preemption inside it;
  - a multi-replica aggregate;
  - torch-profiler trace parsing, including graph launches vs kernel launches;
  - a GPU-release gate.
- `design/DESIGN.md` and `design/PREP_KITS_2026-10-29.md`: the plan and the CPU-verified prep artifacts. The artifacts are now Kaggle Models / Datasets.
- `prep/install_merlin_offline.sh`, `prep/glibc235_fix.py`, `prep/glibc238_shim.c`, `prep/rehash_products.py`: the offline Merlin install. The glibc 2.35 fix is a weak GLIBC_2.38 need plus an LD_PRELOAD shim for `__isoc23_strto*`.
- `prep/build_p6_kernels.py`: the EAGLE offline env. `install_eagle_offline.sh` is written inside it.
- `patches/pr60532.diff`: only its `vllm/v1/attention/backends/flashinfer.py` hunk is applied at runtime.
- `merlin_ref/launch.py`, `merlin_ref/qwen38-27b.json`: Merlin's launcher and profiles (Apache-2.0). The notebook calls `launch.build("27b", "27b-tp1-sm89-24g" | "27b-tp4-sm89-24g", ckpt, env, extra=[...])`.
- `benches/bench_fp8_gemm.py`, `benches/bench_host_ar.py`: the P4 and P5 benches the notebook calls.
- `local_fake_run/`: a CPU run against a fake vLLM server, end to end in SMOKE mode, 5.8 min. It contains `run.log` and `e23_results.json`.

## Facts already verified (do not re-derive)
**CPU kit, real vLLM 0.32.0 parser.** These were accepted:
- `--profiler-config {profiler: torch, torch_profiler_dir}`;
- `--mamba-ssm-cache-dtype`;
- `--prefix-match-unit`;
- `--enable-mamba-shared-prefix-checkpoint`;
- speculative `use_local_argmax_reduction`;
- cudagraph_mode FULL_AND_PIECEWISE / FULL_DECODE_ONLY.

`kv-cache-dtype nvfp4` on SM8x is in 0.32.0 (#46963).

**vLLM 0.32 reasoning field.** It returns thinking in `reasoning`, not `reasoning_content`.

**Merlin offline install on the pinned image.** It reports INSTALL OK and ENVIRONMENT VERIFIED, and the engine import works with the shim. Merlin's launch.build resolves TP1 / TP4 argv and env without host checks.

**EAGLE fork.**
- It installs offline and imports.
- The plugin entry point is `eagle_harness` and the CUSTOM attention backend exists.
- These 4 commands parse: EAGLE + FP8 target + CUSTOM, + flashinfer_cutedsl, + fp8 KV, and the MTP3 control.

## What to check
1. **Every launch command, valid and sensible for its engine and version:**
   - stock_flags: FP8 / INT4 / NVFP4 / PP4 / TRITON / compilation-config / profiler-config;
   - merlin_server: overrides passed as last args, KV_BYTES, capture sizes, env, shim, CUDA_HOME, GCC 13;
   - the EAGLE step.
2. **Measurement semantics in vLLM 0.32:**
   - when `vllm:prompt_tokens_total` is incremented, and whether the settle rule can fail or settle too early;
   - `generation_tokens_total` with MTP;
   - spec-decode metric names;
   - `kv_cache_usage_perc`;
   - abort-on-disconnect of stopped streams;
   - the trace layout and whether cudaGraphLaunch counts prove FULL-graph verification.
3. **Plan fidelity.** Every step of the six sequences is present; nothing is extra; SMOKE covers the risky pieces; the time estimates are realistic, given server startup of 430-545 s for stock TP4 and the Merlin first-start JIT.
4. **Kaggle robustness:**
   - input discovery under /kaggle/input/models/<owner>/<slug>/<framework>/<variation>/<version>;
   - disk (/tmp extracts of 4.3 GB and 4.25 GB, plus venvs);
   - process-group cleanup and port reuse;
   - nvidia-smi PIDs inside the container for the GPU gate;
   - the P4 bench on GPU 3 while Merlin TP1 runs on GPU 0;
   - the P5 bench needing all 4 GPUs and /dev/shm;
   - the rerun guard;
   - notebook size (commit limit < 400 kB).
5. **Plain bugs:** wrong variables, closures, swallowed exceptions, reporting a failure as success, thread leaks, report-table mapping.
