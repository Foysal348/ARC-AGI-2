# E27 NBDF-K100 FINAL GATED audit: DFlash2 (D3s / D4s) vs MTP K3 (Q) on klee100, Merlin v3.0.0, Kaggle 4 x L4

**Answer GO or NO-GO on the first line. Then BLOCKERS ONLY** (crash, wasted run, wrong measurement, wrong verdict), each with
file:line, why, fix. No style items, no new features (the design is frozen).

This is the GATED build that would be committed to GPU: notebook sha c5c43770eaef2a446ea7ab158dd384fb057e8940ae5eb0413719b5e8e08b1353
(`NB__q27-xhigh-e27-nbdf-k100_GATED.ipynb`, the exact push-folder file, metadata in `PUSH__kernel-metadata.json`).
- The KV gate is now OPEN from the real CPU kit (`KIT__k100_real_report_ALL_OK.json`, ALL_OK, notebook 456c47e6 = the closed
  build this gated one was built from). `VERIFY__nbdf_gate_verify_output.json`: passed, gpu_ready, embedded == facts, per_k and
  per_k_success (D3s / D4s: success, kv_configs_ok, k100_r9_run_ok) all true, notebook file sha == facts, exit 0.
- Earlier audits' items are all fixed: Q failure never skips D arms (round 3, test K6 matrix), draft_load_check parser proven
  against the seam's own emit (K7), no WIN without TF PASS (TF_REQUIRED, INCONCLUSIVE_TF), the gate verifier fails closed (10
  tests), the kit runs the notebook's own launch path (18 steps incl. the --help flag gate).
- Design (unchanged): arms Q (E28 production MTP K3 + Q-defer + I8) -> D3s -> D4s (DFlash2 K3 / K4, SW-1024, BF16 drafter KV),
  seqs 24, pin 7,933,526,016, D OOM -> EMBED_HOST then 256 MiB steps; windows 8k@16 x2, 20k@24, 40k@16, 90k@8, 116k@6;
  Q A/A envelope; TF 2k / 8k / 40k hard gate; real-failure gates only; CELL 0 = E18 R2 verbatim.
- Research reports A / B and the round-3 report are included for context.

**The questions:** (1) with the gate open, can anything other than a real failure of that same arm or the time budget skip /
stop D3s or D4s? (2) can any verdict be wrong (e.g. WIN without real evidence)? (3) anything that would crash the run or
waste the GPU time that the CPU kit cannot see? List each with file:line.
