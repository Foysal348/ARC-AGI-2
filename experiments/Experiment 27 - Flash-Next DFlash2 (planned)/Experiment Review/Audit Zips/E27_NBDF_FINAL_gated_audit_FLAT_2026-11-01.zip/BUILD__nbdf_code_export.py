# ==================================================================== CELL 0 — mode + fallback submission (stdlib only)
import os, sys, json, time, random, hashlib, re, shutil, subprocess, threading, traceback, zipfile, math
from pathlib import Path
from datetime import datetime, timezone
import concurrent.futures as cf

NOTEBOOK_T0 = time.perf_counter()
# S1 (CLOCK): Kaggle's 12 h counts from kernel start; R5's cell 0 began 7 s later. Anchor the clock at the kernel
# process start (capped at 10 min in case the value is odd).
try:
    import psutil as _ps
    _since_kernel_start = max(0.0, min(600.0, time.time() - _ps.Process(os.getpid()).create_time()))
except Exception:
    _since_kernel_start = 0.0
NOTEBOOK_T0 -= _since_kernel_start
RUN_ID = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
RERUN = os.environ.get("KAGGLE_IS_COMPETITION_RERUN", "").strip().lower() in {"1", "true", "yes"}
ARC_ROOT = Path(os.environ.get("Q27X_ARC_ROOT", "/kaggle/input/competitions/arc-prize-2026-arc-agi-2"))
if not ARC_ROOT.exists():
    for _alt in ("/kaggle/input/arc-prize-2026-arc-agi-2",):
        if Path(_alt).exists():
            ARC_ROOT = Path(_alt)
WORKING = Path(os.environ.get("Q27X_WORKING", "/kaggle/working")); WORKING.mkdir(parents=True, exist_ok=True)
OUT = WORKING / "q27x"; OUT.mkdir(parents=True, exist_ok=True)
SUBMISSION_PATH = WORKING / "submission.json"

def _load_json(p):
    with open(p, "r", encoding="utf-8") as f:
        return json.load(f)

test_challenges = _load_json(ARC_ROOT / "arc-agi_test_challenges.json")

def write_json_atomic(path, obj):
    tmp = Path(str(path) + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f)
    os.replace(tmp, path)

def identity_submission(challenges):
    return {tid: [{"attempt_1": q["input"], "attempt_2": q["input"]} for q in task["test"]]
            for tid, task in challenges.items()}

write_json_atomic(SUBMISSION_PATH, identity_submission(test_challenges))
print("MODE:", "COMPETITION RERUN (hidden test)" if RERUN else "COMMIT / INTERACTIVE (evaluation)",
      "| fallback submission.json:", len(test_challenges), "tasks | RUN_ID", RUN_ID,
      "| clock anchored", round(_since_kernel_start, 1), "s before cell 0")


# ==================================================================== CELL 1 — config, inputs, lab module (RC2 verbatim + E25 NB1 / NB4S / NB4T / E27 NBDF marked edits)
import os, sys, json, math, time, re, shutil, subprocess, hashlib, tarfile, threading, traceback
from pathlib import Path
T_START = time.time()
MODE = "FULL"
RERUN = os.environ.get("KAGGLE_IS_COMPETITION_RERUN", "").strip().lower() in {"1", "true", "yes"}
FAKE = os.environ.get("E23_FAKE_SERVER")                          # local CPU harness only
BUDGET = int(os.environ.get("RC2_BUDGET_SEC") or 150 * 60)     # E27 NBDF: hard stop 150 min (user: Q + D4 + D3 guaranteed; D4t if time)
HARD_STOP = T_START + BUDGET
MAX_LEN = 131072                                                  # user 2026-10-29: thinking up to 120k
OUT = Path(os.environ.get("E23_OUT", "/kaggle/working/nbdf"))   # E27 NBDF
OUT.mkdir(parents=True, exist_ok=True)
LOGS = OUT / "logs"
LOGS.mkdir(exist_ok=True)
TRACES = OUT / "traces"                                           # memory rule: the full text of every long generation
TRACES.mkdir(exist_ok=True)
TMP = Path(os.environ.get("E23_TMP", "/tmp"))
INP = Path(os.environ.get("E23_INPUT", "/kaggle/input"))
R = {"what": "E27 NBDF: DFlash2 K4 / K3 / K7 vs MTP K3 on the Q-defer base, 8k-116k (Flash-Next W4 on Merlin)",   # E27 NBDF
      "budget_min": BUDGET // 60, "max_len": MAX_LEN,
     "start_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "setup": {}, "sections": {}, "errors": [], "order": []}
_SAVE_LOCK = threading.Lock()
NB1_EXTRA, NB1_ENV, NB1_KV = {}, {}, {}   # E25 NB1: per-boot trailing vllm flags, env and KV pin (filled by the boot plan)

# ---- E27 NBDF (user 2026-11-01; the E26 K100Q pattern): the commit's ABSOLUTE DEADMAN, 5 min after the 150-min hard stop. A
# daemon thread sleeps until NOTEBOOK_T0 + NBDF_DEADMAN_SEC, then: one marker line (stdout fd + stderr fd +
# /kaggle/working/nbdf_deadman.txt), SIGKILL every child (psutil tree; else os.killpg on the live servers' groups + pkill -9 -f
# vllm), os._exit(0). No lock, no main thread, no cell. The competition rerun has no deadman (CELL 0 wrote its submission).
NBDF_DEADMAN_SEC = 9300
NBDF_DEADMAN = {"armed": False, "fire_pc": None}


def nbdf_deadman(t_fire_pc, marker, poll=5.0, use_psutil=True):
    """Sleep until perf_counter >= t_fire_pc, then the marker, SIGKILL every child process (group), os._exit(0)."""
    while True:
        d = t_fire_pc - time.perf_counter()
        if d <= 0:
            break
        time.sleep(min(poll, d))
    line = f"@@NBDF_DEADMAN_FIRED@@ t={round(time.perf_counter() - NOTEBOOK_T0, 1)}s pid={os.getpid()}\n"
    for fd in (1, 2):
        try:
            os.write(fd, line.encode())
        except Exception:
            pass
    try:
        with open(marker, "a", encoding="utf-8") as f:
            f.write(line)
            f.flush()
            os.fsync(f.fileno())
    except Exception:
        pass
    killed = False
    if use_psutil:
        try:
            import psutil
            for c in psutil.Process(os.getpid()).children(recursive=True):
                try:
                    c.kill()
                except Exception:
                    pass
            killed = True
        except Exception:
            killed = False
    lab = globals().get("L")
    for s in list(getattr(lab, "LIVE", None) or []):
        pid = getattr(getattr(s, "proc", None), "pid", None)
        if pid and hasattr(os, "killpg"):
            try:
                os.killpg(int(pid), 9)                    # e23_lab.Server starts each server in its own session (pgid = pid)
            except Exception:
                pass
    if not killed:
        try:
            subprocess.run(["pkill", "-9", "-f", "vllm"], timeout=10)
        except Exception:
            pass
    os._exit(0)


if not RERUN and not os.environ.get("RC2_UNIT"):
    NBDF_DEADMAN.update(fire_pc=NOTEBOOK_T0 + NBDF_DEADMAN_SEC, marker=str(WORKING / "nbdf_deadman.txt"))
    NBDF_DEADMAN["thread"] = threading.Thread(target=nbdf_deadman, args=(NBDF_DEADMAN["fire_pc"], NBDF_DEADMAN["marker"]),
                                              daemon=True, name="nbdf_deadman")
    NBDF_DEADMAN["thread"].start()
    NBDF_DEADMAN["armed"] = True
    print(f"NBDF DEADMAN armed: fires at +{NBDF_DEADMAN_SEC / 60:.0f} min after the notebook start (in "
          f"{round((NBDF_DEADMAN['fire_pc'] - time.perf_counter()) / 60, 1)} min)", flush=True)


def save():
    with _SAVE_LOCK:
        tmp = OUT / "nbdf_results.json.tmp"                      # E27 NBDF
        tmp.write_text(json.dumps(R, indent=1, default=str))
        tmp.replace(OUT / "nbdf_results.json")                   # E27 NBDF


def left():
    return HARD_STOP - time.time()


def log(*a):
    print(f"[{(time.time() - T_START) / 60:6.1f} min]", *a, flush=True)


COMP = INP / "competitions" / "arc-prize-2026-arc-agi-2"


def write_fallback_submission():
    """E25 NB4T: the proven E18 R2 format (CELL 0's writer): the identity submission of every test task (attempt_1 =
    attempt_2 = the test input), written atomically to CELL 0's SUBMISSION_PATH; never a [[0]] placeholder."""
    write_json_atomic(SUBMISSION_PATH, identity_submission(test_challenges))


if RERUN:                                                         # E25 NB4T: CELL 0 already wrote the identity file
    print("E27 NBDF DFlash2: competition rerun -> CELL 0's identity fallback submission.json only (E18 R2 format)")   # E27 NBDF
else:
    LAB_SRC = "\"\"\"E23 lab, rev 3: port-parameterized server lifecycle and measurement for the six-lever notebook (stdlib only).\n\nBase: the Exp 14 VMS harness (VServer / VGen: token ids from return_token_ids, [DONE] + finish_reason required, socket\nshutdown on stop, top-1/top-2 margins, garbage checks on every window). Adopted from the consolidated v3 notebook:\nsame-weight greedy oracle classified by the oracle's logprob margin at the first differing token, a steady decode window\nthat starts only after prefill settled, a GPU-release gate, fail-closed statuses, checkpoint identity, a runtime\n--help flag check, KV + GPU memory samples.\nrev 3 (validation agents 2026-10-29, measurement + robustness):\n  - port check by connect (a TIME_WAIT socket of the previous server is not \"busy\"), with a 90 s wait;\n  - kill(): SIGKILL the whole session after SIGTERM, even when the leader already exited;\n  - steady(): idle gate at entry, admission cap from the prefill to do (700 tok/s assumed), settle needs no preemption\n    and every running stream gaining tokens; in the window: stalled streams, a changing running/waiting set (KV-bound),\n    preemptions and prefills make it INCONCLUSIVE (numbers kept); garbage under load fails it; steps from the\n    vllm:iteration_tokens_total histogram count; replicas measured in one shared window (barrier);\n  - profiled_load(): settle as steady(), bounded profile (delay / max iterations), with_stack off, frontend ignored;\n  - trace_summary(): categories on the kernel base name (attention before GDN: \"fla\" is inside \"flashinfer\"), per-forward\n    graph / kernel launch counts inside the gpu_model_runner forward ranges (VLLM_CUSTOM_SCOPES_FOR_PROFILING=1) and the\n    CUPTI correlation fallback -> FULL / PIECEWISE / EAGER / UNKNOWN; startup cudagraph lines parsed explicitly;\n  - teacher_forced(): prompt logprobs of the last N positions of a long prompt (NVFP4 vs FP8 KV at 40k / 90k);\n  - logprobs keyed by token id (return_tokens_as_token_ids); stop() race closed; compare() flags garbage only when the\n    oracle itself is clean.\n\"\"\"\nimport gzip\nimport hashlib\nimport json\nimport os\nimport re\nimport signal\nimport socket\nimport statistics\nimport subprocess\nimport threading\nimport time\nimport urllib.request as U\nfrom pathlib import Path\n\nFAIL_MARGIN = 0.5          # first differing token: oracle top-1 minus top-2 logprob at or above this = real divergence\nLIVE = set()               # every running Server, for the hard-stop watchdog\n\n\n# ------------------------------------------------------------------ server lifecycle\ndef port_listening(port):\n    \"\"\"True when something accepts connections on 127.0.0.1:port (TIME_WAIT leftovers do not).\"\"\"\n    s = socket.socket()\n    s.settimeout(1.0)\n    try:\n        s.connect((\"127.0.0.1\", int(port)))\n        return True\n    except OSError:\n        return False\n    finally:\n        s.close()\n\n\nclass Server:\n    def __init__(self, name, argv, env, port, log_dir, gpus=\"0,1,2,3\"):\n        self.name, self.argv, self.env, self.port = name, [str(a) for a in argv], dict(env), int(port)\n        self.gpus = str(gpus)\n        self.log_path = Path(log_dir) / f\"server_{name}.log\"\n        self.proc, self.t0, self.ready_sec = None, None, None\n\n    @property\n    def url(self):\n        return f\"http://127.0.0.1:{self.port}\"\n\n    def start(self):\n        end = time.time() + 90\n        while port_listening(self.port):\n            if time.time() > end:\n                raise RuntimeError(f\"PORT_BUSY {self.port} (a listener is still there)\")\n            time.sleep(3)\n        self.log_path.parent.mkdir(parents=True, exist_ok=True)\n        self._fh = open(self.log_path, \"w\", encoding=\"utf-8\")\n        self.t0 = time.perf_counter()\n        self.proc = subprocess.Popen(self.argv, env=self.env, stdout=self._fh, stderr=subprocess.STDOUT,\n                                     start_new_session=True, cwd=\"/tmp\" if os.path.isdir(\"/tmp\") else None)\n        LIVE.add(self)\n        return self\n\n    def alive(self):\n        return self.proc is not None and self.proc.poll() is None\n\n    def log(self):\n        try:\n            return self.log_path.read_text(encoding=\"utf-8\", errors=\"replace\")\n        except Exception:\n            return \"\"\n\n    def rss_mb(self):\n        \"\"\"Host RAM of the server's whole session (engine + workers), MB; None off Linux.\"\"\"\n        try:\n            r = subprocess.run([\"ps\", \"-o\", \"rss=\", \"--sid\", str(self.proc.pid)], capture_output=True, text=True, timeout=20)\n            return round(sum(int(x) for x in r.stdout.split() if x.isdigit()) / 1024, 1)\n        except Exception:\n            return None\n\n    def wait_ready(self, timeout):\n        while time.perf_counter() - self.t0 < timeout:\n            if not self.alive():\n                return False, f\"exited rc={self.proc.returncode}\"\n            try:\n                U.urlopen(self.url + \"/health\", timeout=10).read()\n                self.ready_sec = round(time.perf_counter() - self.t0, 1)\n                return True, f\"ready in {self.ready_sec}s\"\n            except Exception:\n                time.sleep(3)\n        return False, \"startup timeout\"\n\n    def kill(self):\n        if self.proc is None:\n            return\n        pg = self.proc.pid\n        try:\n            os.killpg(pg, signal.SIGTERM) if hasattr(os, \"killpg\") else self.proc.terminate()\n        except Exception:\n            pass\n        try:\n            self.proc.wait(timeout=40)\n        except Exception:\n            pass\n        # rev 3: the leader may exit while EngineCore / workers of the session still hold GPUs: always SIGKILL the group\n        try:\n            os.killpg(pg, signal.SIGKILL) if hasattr(os, \"killpg\") else self.proc.kill()\n        except Exception:\n            pass\n        try:\n            self.proc.wait(timeout=30)\n        except Exception:\n            pass\n        try:\n            self._fh.close()\n        except Exception:\n            pass\n        LIVE.discard(self)\n\n    def facts(self):\n        \"\"\"What vLLM logged at startup: KV pool, max concurrency, selected kernels, graph mode, backend, KV dtype.\"\"\"\n        t = self.log()\n        kv = [int(x.replace(\",\", \"\")) for x in re.findall(r\"GPU KV cache size: ([\\d,]+) tokens\", t)]\n        mc = re.findall(r\"Maximum concurrency for [\\d,]+ tokens per request: ([\\d.]+)x\", t)\n        kern = sorted(set(re.findall(r\"Selected (\\w+Kernel) for\", t)))\n        errs = [l[:300] for l in t.splitlines() if re.search(r\"Traceback|CUDA error|illegal memory|out of memory|\"\n                                                               r\"RuntimeError|AssertionError\", l)][:12]\n        pick = lambda pat, n=8: [l.strip()[:240] for l in t.splitlines() if re.search(pat, l, re.I)][:n]\n        # rev 3 (measurement H5): the decisive startup evidence for the graph mode actually used with spec decode\n        downgrade = pick(r\"not supported with spec-decode.*setting cudagraph_mode|setting cudagraph_mode\\s*=|\"\n                         r\"[Oo]verriding cudagraph_mode to\", 4)       # rev 3e: + the 0.32 wording\n        capture = sorted(set(re.findall(r\"Capturing CUDA graphs \\(([^)]+)\\)\", t)))\n        configured = sorted(set(re.findall(r\"CUDAGraphMode\\.(\\w+)\", t)))\n        return {\"kv_tokens\": min(kv) if kv else None, \"kv_tokens_all\": kv, \"max_concurrency\": float(mc[-1]) if mc else None,\n                \"kernels\": kern, \"error_lines\": errs, \"ready_sec\": self.ready_sec,\n                \"graph_capture_modes\": capture, \"graph_downgrade_lines\": downgrade, \"cudagraph_modes_logged\": configured,\n                \"backend_lines\": pick(r\"attention backend|Using \\w+ backend|backend=|AttentionBackend\"),\n                \"kv_dtype_lines\": pick(r\"kv_cache_dtype|kv cache dtype|nvfp4\"),\n                \"host_embed_lines\": pick(r\"host[- _]?(resident|embed)|HOST_EMBED|embed.*(cpu|host)\", 6)}\n\n\ndef gpu_pids(gpus=None):\n    \"\"\"Compute PIDs on all GPUs, or only on the GPU indices in `gpus` (a bench on another GPU must not fail the release\n    gate of a server that used GPU 0 only). None when nvidia-smi is unavailable.\"\"\"\n    try:\n        a = subprocess.run([\"nvidia-smi\", \"--query-compute-apps=pid,gpu_uuid\", \"--format=csv,noheader,nounits\"],\n                           capture_output=True, text=True, timeout=30)\n        g = subprocess.run([\"nvidia-smi\", \"--query-gpu=index,uuid\", \"--format=csv,noheader,nounits\"],\n                           capture_output=True, text=True, timeout=30)\n    except Exception:\n        return None\n    if a.returncode or g.returncode:\n        return None\n    idx = {u.strip(): int(i) for i, u in (l.split(\",\", 1) for l in g.stdout.strip().splitlines() if \",\" in l)}\n    want = None if gpus is None else {int(x) for x in str(gpus).split(\",\") if str(x).strip() != \"\"}\n    out = set()\n    for l in a.stdout.strip().splitlines():\n        if \",\" not in l:\n            continue\n        pid, uuid = (x.strip() for x in l.split(\",\", 1))\n        if pid.isdigit() and (want is None or idx.get(uuid) in want):\n            out.add(int(pid))\n    return sorted(out)\n\n\ndef gpu_mem():\n    try:\n        r = subprocess.run([\"nvidia-smi\", \"--query-gpu=index,memory.used,memory.total\", \"--format=csv,noheader,nounits\"],\n                           capture_output=True, text=True, timeout=30)\n        return [[int(v) for v in l.split(\",\")] for l in r.stdout.strip().splitlines() if l.strip()]\n    except Exception:\n        return None\n\n\ndef wait_gpu_release(timeout=180, fake=False, gpus=None, free_mib=1024):\n    \"\"\"True when the GPUs in `gpus` (all when None) hold no compute PID AND use < free_mib MiB each (rev 3: compute-app\n    PIDs are often invisible inside Kaggle containers; memory.used is the proven E18 gate); None without nvidia-smi.\"\"\"\n    if fake:\n        return True\n    want = None if gpus is None else {int(x) for x in str(gpus).split(\",\") if str(x).strip() != \"\"}\n    end = time.time() + timeout\n    while time.time() < end:\n        p, mem = gpu_pids(gpus), gpu_mem()\n        if p is None or mem is None:\n            return None\n        used = [m[1] for m in mem if want is None or m[0] in want]\n        if not p and all(u < free_mib for u in used):\n            return True\n        time.sleep(3)\n    return False\n\n\ndef identity(model_dir):\n    \"\"\"Checkpoint identity: sha256 of config / tokenizer / index files (an oracle is only compared with the same weights).\"\"\"\n    root = Path(model_dir)\n    files = [p for n in (\"config.json\", \"tokenizer.json\", \"tokenizer_config.json\", \"generation_config.json\")\n             for p in [root / n] if p.is_file()] + sorted(root.glob(\"*.safetensors.index.json\"))\n    h = hashlib.sha256()\n    for p in files:\n        h.update(p.name.encode())\n        h.update(hashlib.sha256(p.read_bytes()).digest())\n    return {\"dir\": str(root), \"files\": [p.name for p in files], \"sha256\": h.hexdigest()[:16]}\n\n\n_HELP = {}\n\n\ndef help_check(key, argv_prefix, env, flags, timeout=300):\n    \"\"\"The engine's own `serve --help=all` (run once per engine `key`, cached) must list every flag of THIS launch\n    (rev 3: every launch is checked, not only the first); returns the missing ones.\"\"\"\n    if key not in _HELP:\n        try:\n            r = subprocess.run(list(argv_prefix) + [\"--help=all\"], capture_output=True, text=True, timeout=timeout, env=env)\n            _HELP[key] = r.stdout + r.stderr\n        except Exception as e:\n            _HELP[key] = \"ERROR \" + repr(e)[:200]\n    txt = _HELP[key]\n    if len(txt) < 2000:\n        return {\"ran\": False, \"error\": \"help output too short or failed\", \"tail\": txt[-400:]}\n    want = sorted({f for f in flags if isinstance(f, str) and f.startswith(\"--\")})\n    return {\"ran\": True, \"missing\": [f for f in want if f not in txt]}\n\n\ndef start_watchdog(hard_stop_epoch, on_fire):\n    \"\"\"A real hard stop: at `hard_stop_epoch` every live Server is killed and on_fire() is called.\"\"\"\n    def run():\n        while time.time() < hard_stop_epoch:\n            time.sleep(5)\n        try:\n            on_fire()\n        finally:\n            for s in list(LIVE):\n                try:\n                    s.kill()\n                except Exception:\n                    pass\n    t = threading.Thread(target=run, daemon=True, name=\"e23-watchdog\")\n    t.start()\n    return t\n\n\ndef prefetch(paths, threads=16, chunk=16 << 20):\n    \"\"\"Read files once with many readers (page cache warm-up of a cold /kaggle/input mount); returns bytes and seconds.\"\"\"\n    files = [p for root in paths for p in sorted(Path(root).rglob(\"*\")) if p.is_file()]\n    t0, done, lock = time.time(), [0], threading.Lock()\n\n    def worker(fs):\n        for p in fs:\n            try:\n                with open(p, \"rb\") as f:\n                    while True:\n                        b = f.read(chunk)\n                        if not b:\n                            break\n                        with lock:\n                            done[0] += len(b)\n            except Exception:\n                pass\n    big = sorted(files, key=lambda p: -p.stat().st_size)\n    parts = [big[i::threads] for i in range(threads)]\n    ths = [threading.Thread(target=worker, args=(x,), daemon=True) for x in parts if x]\n    for t in ths:\n        t.start()\n    for t in ths:\n        t.join()\n    dt = time.time() - t0\n    return {\"files\": len(files), \"bytes\": done[0], \"sec\": round(dt, 1), \"MBps\": round(done[0] / 1e6 / max(dt, 1e-3), 1)}\n\n\n# ------------------------------------------------------------------ metrics\ndef prom(port):\n    txt = U.urlopen(f\"http://127.0.0.1:{port}/metrics\", timeout=15).read().decode(\"utf-8\", \"replace\")\n    out = {}\n    for line in txt.splitlines():\n        if not line or line.startswith(\"#\"):\n            continue\n        m = re.match(r\"^([A-Za-z_:][A-Za-z0-9_:]*)(\\{[^}]*\\})?\\s+(\\S+)\", line)\n        if not m:\n            continue\n        try:\n            v = float(m.group(3))\n        except ValueError:\n            continue\n        if v != v:\n            continue\n        out[m.group(1)] = out.get(m.group(1), 0.0) + v\n        out[m.group(1) + \"@max\"] = max(out.get(m.group(1) + \"@max\", v), v)\n    return out\n\n\nGEN, PROMPT, RUN, WAIT = (\"vllm:generation_tokens_total\", \"vllm:prompt_tokens_total\", \"vllm:num_requests_running\",\n                          \"vllm:num_requests_waiting\")\nPREEMPT, KVU, ITER = \"vllm:num_preemptions_total\", \"vllm:kv_cache_usage_perc\", \"vllm:iteration_tokens_total_count\"\nACC, DRF, DTOK = (\"vllm:spec_decode_num_accepted_tokens_total\", \"vllm:spec_decode_num_drafts_total\",\n                  \"vllm:spec_decode_num_draft_tokens_total\")\n\n\n# ------------------------------------------------------------------ one streaming request (Exp 14 VGen, port-aware)\nclass Stream(threading.Thread):\n    def __init__(self, port, ids, max_new, temperature=1.0, seed=None, logprobs=0, ignore_eos=True, model=\"q27\"):\n        super().__init__(daemon=True)\n        self.port = int(port)\n        self.body = {\"model\": model, \"prompt\": list(ids), \"max_tokens\": int(max_new), \"temperature\": temperature,\n                     \"top_p\": 0.95 if temperature else 1.0, \"stream\": True, \"ignore_eos\": ignore_eos, \"return_token_ids\": True}\n        if temperature:\n            self.body[\"top_k\"] = 20\n        if seed is not None:\n            self.body[\"seed\"] = int(seed)\n        if logprobs:\n            self.body[\"logprobs\"] = int(logprobs)\n            self.body[\"return_tokens_as_token_ids\"] = True      # rev 3: logprob keys by id (no string collisions)\n        self.text, self.tokens, self.margins = [], [], []\n        self.err, self.done_seen, self.finish_reason = None, False, None\n        self.t_start = self.t_first = self.t_end = None\n        self._resp, self._halt = None, False\n\n    def run(self):\n        self.t_start = time.perf_counter()\n        try:\n            req = U.Request(f\"http://127.0.0.1:{self.port}/v1/completions\", data=json.dumps(self.body).encode(),\n                            method=\"POST\", headers={\"Content-Type\": \"application/json\"})\n            self._resp = U.urlopen(req, timeout=7200)\n            for raw in self._resp:\n                if self._halt:\n                    break\n                line = raw.strip()\n                if not line.startswith(b\"data:\"):\n                    continue\n                payload = line[5:].strip()\n                if payload == b\"[DONE]\":\n                    self.done_seen = True\n                    break\n                d = json.loads(payload)\n                if \"error\" in d or d.get(\"object\") == \"error\":\n                    self.err = (\"stream error: \" + json.dumps(d.get(\"error\") or d.get(\"message\") or d))[:300]\n                    break\n                for c in d.get(\"choices\") or []:\n                    self.text.append(c.get(\"text\") or \"\")\n                    ids_ = c.get(\"token_ids\")\n                    lp = c.get(\"logprobs\") or {}\n                    if ids_ is None:\n                        if c.get(\"text\") or lp.get(\"tokens\"):\n                            self.err = \"MISSING_STREAM_TOKEN_IDS\"\n                    elif any(not isinstance(v, int) or isinstance(v, bool) for v in ids_):\n                        self.err = \"INVALID_STREAM_TOKEN_IDS\"\n                    else:\n                        if ids_ and self.t_first is None:\n                            self.t_first = time.perf_counter()\n                        self.tokens.extend(ids_)\n                    for top in lp.get(\"top_logprobs\") or []:\n                        vals = sorted((v for v in (top or {}).values() if isinstance(v, (int, float))), reverse=True)\n                        self.margins.append(round(vals[0] - vals[1], 4) if len(vals) >= 2 else None)\n                    if c.get(\"finish_reason\") is not None:\n                        self.finish_reason = c[\"finish_reason\"]\n                if self.err:\n                    break\n        except Exception as e:\n            if not self._halt:\n                self.err = repr(e)[:300]\n        finally:                         # rev 3: a stop() before the response existed still closes the socket here\n            try:\n                if self._resp is not None:\n                    self._resp.close()\n            except Exception:\n                pass\n        self.t_end = time.perf_counter()\n        if not self._halt and not self.err and not (self.done_seen and self.finish_reason):\n            self.err = f\"INCOMPLETE_SSE done={self.done_seen} finish={self.finish_reason}\"\n\n    def stop(self):\n        self._halt = True\n        try:\n            self._resp.fp.raw._sock.shutdown(socket.SHUT_RDWR)\n        except Exception:\n            pass\n        try:\n            if self._resp is not None:\n                self._resp.close()\n        except Exception:\n            pass\n\n    def row(self):\n        return {\"text\": \"\".join(self.text), \"tokens\": list(self.tokens), \"margins\": list(self.margins), \"error\": self.err,\n                \"done\": self.done_seen, \"finish_reason\": self.finish_reason}\n\n\n# ------------------------------------------------------------------ correctness\ndef greedy(port, prompts, n_tok=128, logprobs=2, timeout=900, model=\"q27\"):\n    \"\"\"Greedy rows for the same-weight oracle (one request at a time: batch-size effects stay out of the comparison).\"\"\"\n    rows = []\n    for ids in prompts:\n        g = Stream(port, ids, n_tok, temperature=0.0, logprobs=logprobs, ignore_eos=True, model=model)\n        g.start()\n        g.join(timeout)\n        if g.is_alive():\n            g.stop()\n            g.join(10)\n            r = g.row()\n            r[\"error\"] = r[\"error\"] or \"GREEDY_TIMEOUT\"\n        else:\n            r = g.row()\n        rows.append(r)\n    return rows\n\n\ndef degenerate(text):\n    \"\"\"Objective garbage checks: empty, a run of one char, '!!!!' (the E3 / E13 garbage), very low variety.\"\"\"\n    t = text or \"\"\n    if not t.strip():\n        return \"EMPTY\"\n    if re.search(r\"(\\S)\\1{200,}\", t, re.S):      # rev 3: grid rows / separators are not garbage\n        return \"REPEATED_CHAR\"\n    if t.count(\"!\") > 0.5 * max(1, len(t)):\n        return \"BANG_GARBAGE\"\n    words = re.findall(r\"[A-Za-z]{3,}\", t)            # rev 3c: words only; ARC grid dumps (digits) are not garbage\n    if len(words) > 60 and len(set(words)) < 0.08 * len(words):\n        return \"LOW_VARIETY\"\n    return None\n\n\ndef compare(ref, cand):\n    \"\"\"Same-weight oracle: at the first differing token the ORACLE's top-1 - top-2 logprob margin decides:\n    >= FAIL_MARGIN -> FAIL_HIGH_MARGIN, below -> NEAR_TIE; identical -> EXACT; missing data -> INCONCLUSIVE.\"\"\"\n    if not ref or not cand or len(ref) != len(cand):\n        return {\"status\": \"INCONCLUSIVE_PAIRS_MISSING\"}\n    per, worst = [], \"EXACT\"\n    rank = {\"EXACT\": 0, \"NEAR_TIE\": 1, \"INCONCLUSIVE\": 2, \"FAIL_HIGH_MARGIN\": 3}\n    for a, b in zip(ref, cand):\n        if a.get(\"error\") or b.get(\"error\") or not a.get(\"tokens\") or not b.get(\"tokens\"):\n            st, d, m = \"INCONCLUSIVE\", None, None\n        else:\n            x, y = a[\"tokens\"], b[\"tokens\"]\n            d = next((i for i in range(min(len(x), len(y))) if x[i] != y[i]), None)\n            if d is None:\n                st, m = (\"EXACT\" if len(x) == len(y) else \"INCONCLUSIVE\"), None\n            else:\n                mm = a.get(\"margins\") or []\n                m = mm[d] if d < len(mm) else None\n                st = \"INCONCLUSIVE\" if m is None else (\"FAIL_HIGH_MARGIN\" if m >= FAIL_MARGIN else \"NEAR_TIE\")\n        g = degenerate(b.get(\"text\")) if (b.get(\"tokens\") and not b.get(\"error\")) else None\n        if g and degenerate(a.get(\"text\")) is None:           # rev 3c: a request error is not corruption\n            st = \"FAIL_HIGH_MARGIN\"\n        per.append({\"first_diff\": d, \"oracle_margin\": m, \"status\": st, \"garbage\": g})\n        worst = st if rank[st] > rank[worst] else worst\n    return {\"status\": worst, \"rows\": per}\n\n\ndef chat_probes(port, model=\"q27\", cases=((\"Reply with exactly one number: 7 * 6 =\", \"42\"),\n                                          (\"Reply with exactly one number: 2 + 2 =\", \"4\"),\n                                          (\"Reply with exactly one number: 9 - 3 =\", \"6\")), timeout=300):\n    \"\"\"Arithmetic through /v1/chat/completions with thinking off. vLLM 0.32 returns the answer in message.content and\n    the thinking in message.reasoning (NOT reasoning_content: the consolidated notebook's blocker).\"\"\"\n    out = []\n    for q, want in cases:\n        body = {\"model\": model, \"messages\": [{\"role\": \"user\", \"content\": q}], \"temperature\": 0, \"max_tokens\": 32,\n                \"chat_template_kwargs\": {\"enable_thinking\": False}}\n        try:\n            r = json.loads(U.urlopen(U.Request(f\"http://127.0.0.1:{port}/v1/chat/completions\", data=json.dumps(body).encode(),\n                                               headers={\"Content-Type\": \"application/json\"}), timeout=timeout).read())\n            msg = r[\"choices\"][0][\"message\"]\n            got = (msg.get(\"content\") or \"\").strip()\n            out.append({\"q\": q, \"want\": want, \"content\": got[:80], \"reasoning_chars\": len(msg.get(\"reasoning\") or \"\"),\n                        \"ok\": re.search(r\"(?<!\\d)\" + want + r\"(?!\\d)\", got) is not None})\n        except Exception as e:\n            out.append({\"q\": q, \"want\": want, \"error\": repr(e)[:200], \"ok\": False})\n    return {\"ok\": all(x[\"ok\"] for x in out), \"cases\": out}\n\n\ndef template_probe(port, messages, want_ids, model=\"q27\", timeout=120):\n    \"\"\"rev 3h (three GPT SMOKE audits): what the SERVER's chat path renders for `messages` (its own template and default\n    chat-template kwargs, no per-request kwargs) against the production xhigh render `want_ids`. MATCH / MISMATCH /\n    ERROR; the load requests themselves use pre-rendered ids, so this shows chat-path equivalence only.\"\"\"\n    body = {\"model\": model, \"messages\": messages, \"add_generation_prompt\": True}\n    try:\n        r = json.loads(U.urlopen(U.Request(f\"http://127.0.0.1:{port}/tokenize\", data=json.dumps(body).encode(),\n                                           headers={\"Content-Type\": \"application/json\"}), timeout=timeout).read())\n        got = list(r.get(\"tokens\") or [])\n    except Exception as e:\n        return {\"status\": \"ERROR\", \"error\": repr(e)[:200]}\n    want = list(want_ids)\n    first = next((i for i, (a, b) in enumerate(zip(got, want)) if a != b), None if len(got) == len(want) else min(len(got), len(want)))\n    return {\"status\": \"MATCH\" if got == want else \"MISMATCH\", \"server_tokens\": len(got), \"want_tokens\": len(want),\n            \"first_diff\": first}\n\n\ndef teacher_forced(port, ids, last=256, model=\"q27\", timeout=1800):\n    \"\"\"rev 3 (measurement M3): prompt logprobs of the last `last` positions of a long prompt (one prefill, 1 token out),\n    for a lossy-KV comparison (NVFP4 vs FP8 KV) at the context lengths that matter. Returns per-position\n    [logprob of the actual token, its rank, the engine's own rank-1 token id] or an error. rev 3h (three GPT SMOKE\n    audits): the rank-1 token id is kept, so top-1 agreement compares the two engines' predictions.\"\"\"\n    body = {\"model\": model, \"prompt\": list(ids), \"max_tokens\": 1, \"temperature\": 0, \"prompt_logprobs\": 1,\n            \"return_tokens_as_token_ids\": True}\n    try:\n        r = json.loads(U.urlopen(U.Request(f\"http://127.0.0.1:{port}/v1/completions\", data=json.dumps(body).encode(),\n                                           headers={\"Content-Type\": \"application/json\"}), timeout=timeout).read())\n        pl = r[\"choices\"][0].get(\"prompt_logprobs\") or []\n    except Exception as e:\n        return {\"error\": repr(e)[:300]}\n    out = []\n    for pos in range(max(1, len(ids) - last), len(ids)):\n        d = pl[pos] if pos < len(pl) else None\n        if not isinstance(d, dict):\n            out.append(None)\n            continue\n        e = d.get(str(ids[pos])) or d.get(f\"token_id:{ids[pos]}\")     # rev 3c: no fallback to another token\n        top1 = [_tok_id(k) for k, v in d.items() if isinstance(v, dict) and v.get(\"rank\") == 1]\n        out.append([e.get(\"logprob\"), e.get(\"rank\"), top1[0] if len(top1) == 1 else None] if isinstance(e, dict) else None)\n    return {\"positions\": out, \"n\": len(out)}\n\n\ndef _tok_id(k):\n    \"\"\"A prompt-logprob key ('123' or 'token_id:123') as an int id; anything else stays a tagged string.\"\"\"\n    m = re.fullmatch(r\"(?:token_id:)?(-?\\d+)\", str(k))\n    return int(m.group(1)) if m else \"str:\" + str(k)\n\n\ndef compare_tf(ref, cand):\n    \"\"\"Teacher-forced comparison: mean / max |delta logprob| of the actual tokens and rank-1 agreement. rev 3d (four\n    GPT audits): MEASURED only when EVERY expected position is valid on both sides (1 of 256 used to be MEASURED);\n    MEASURED is a measurement, not a PASS (the caller applies the A/A-derived tolerance).\"\"\"\n    if not ref or not cand or ref.get(\"error\") or cand.get(\"error\"):\n        return {\"status\": \"INCONCLUSIVE\"}\n    a_, b_ = ref.get(\"positions\") or [], cand.get(\"positions\") or []\n    if not a_ or len(a_) != len(b_):\n        return {\"status\": \"INCONCLUSIVE_INCOMPLETE_TF\", \"ref_n\": len(a_), \"cand_n\": len(b_)}\n    if any(not a or not b or a[0] is None or b[0] is None for a, b in zip(a_, b_)):\n        return {\"status\": \"INCONCLUSIVE_INCOMPLETE_TF\", \"valid\": sum(1 for a, b in zip(a_, b_) if a and b and a[0] is not None\n                                                                     and b[0] is not None), \"expected\": len(a_)}\n    pairs = list(zip(a_, b_))\n    if any(len(a) < 3 or len(b) < 3 or a[2] is None or b[2] is None for a, b in pairs):\n        return {\"status\": \"INCONCLUSIVE_TOP1_MISSING\", \"expected\": len(pairs),\n                \"with_top1\": sum(1 for a, b in pairs if len(a) >= 3 and len(b) >= 3 and a[2] is not None and b[2] is not None)}\n    d = sorted(abs(a[0] - b[0]) for a, b in pairs)\n    # rev 3h (three GPT SMOKE audits): top-1 agreement = both engines predict the same rank-1 token id. rev 3d-3g counted\n    # \"the forced token is rank 1 on both sides or on neither\", which reads 1.0 for ranks 2 vs 3.\n    r1 = sum(1 for a, b in pairs if a[2] == b[2]) / len(pairs)\n    both = sum(1 for a, b in pairs if (a[1] == 1) == (b[1] == 1)) / len(pairs)\n    p99 = d[min(len(d) - 1, int(round(0.99 * (len(d) - 1))))]          # rev 3e: robust to one outlier position\n    return {\"status\": \"MEASURED\", \"n\": len(pairs), \"mean_abs_dlogprob\": round(statistics.mean(d), 4),\n            \"p99_abs_dlogprob\": round(p99, 3), \"max_abs_dlogprob\": round(d[-1], 3), \"rank1_agreement\": round(r1, 4),\n            \"forced_token_rank1_both_or_neither\": round(both, 4)}\n\n\ndef tf_complete(rows):\n    \"\"\"rev 3e: a teacher-forced row set counts as a reference only when every position of every band is valid\n    (rev 3h: including the rank-1 token id).\"\"\"\n    return bool(rows) and all(isinstance(r, dict) and not r.get(\"error\") and r.get(\"positions\") and\n                              all(p and p[0] is not None and len(p) >= 3 and p[2] is not None for p in r[\"positions\"])\n                              for r in rows.values())\n\n\n# ------------------------------------------------------------------ steady decode\ndef steady(port, prompts, level, secs=60.0, admit=None, max_new=8192, temperature=1.0, seed=1234, model=\"q27\",\n           sample=2.0, prefill_tok_s=700.0, gpu_sample=True, barrier=None):\n    \"\"\"`level` distinct prompts, then a decode window that starts only once prefill has settled. Status:\n    STEADY / CAPACITY_LIMITED (fewer running than asked: KV) / INCONCLUSIVE_* / FAIL_*; numbers are kept on an\n    INCONCLUSIVE window so a KV census survives; never a made-up number. `barrier` (steady_multi) starts every replica's\n    window at the same moment.\"\"\"\n    plen = len(prompts[0]) if prompts else 0\n    admit = admit or max(420.0, 120.0 + level * plen / prefill_tok_s)\n    r = {\"level\": level, \"status\": \"INCONCLUSIVE_NOT_STARTED\", \"port\": port, \"prompt_tokens\": plen, \"max_new\": max_new,\n         \"admit_limit_sec\": round(admit)}\n    if not wait_idle(port, 60):\n        r[\"status\"] = \"INCONCLUSIVE_NOT_IDLE_AT_START\"\n        if barrier:\n            barrier.abort()\n        return r\n    try:\n        p0 = prom(port)\n    except Exception as e:\n        r.update(status=\"INCONCLUSIVE_METRICS_UNAVAILABLE\", error=repr(e)[:200])\n        if barrier:\n            barrier.abort()\n        return r\n    if GEN not in p0 or PROMPT not in p0:\n        r[\"status\"] = \"INCONCLUSIVE_COUNTERS_MISSING\"\n        if barrier:\n            barrier.abort()\n        return r\n    ss = [Stream(port, prompts[i % len(prompts)], max_new, temperature, seed + i, model=model) for i in range(level)]\n    for g in ss:\n        g.start()\n    try:\n        t_adm, best, settled, prev, samples, flat_since = time.perf_counter(), 0, 0, None, [], None\n        last_tok = [0] * len(ss)\n        while time.perf_counter() - t_adm < admit:\n            time.sleep(sample)\n            if all(not g.is_alive() for g in ss):          # rev 3: checked before the metrics read (a dead server)\n                r.update(status=\"INCONCLUSIVE_STREAMS_ENDED_IN_ADMISSION\", errors=[g.err for g in ss if g.err][:3])\n                if barrier:\n                    barrier.abort()                       # rev 3c: the other replicas must not wait for this one\n                return r\n            try:\n                m = prom(port)\n            except Exception:\n                continue\n            run, wait, pt, pre = int(m.get(RUN, 0)), int(m.get(WAIT, 0)), m.get(PROMPT), m.get(PREEMPT, 0)\n            now_tok = [len(g.tokens) for g in ss]\n            first = sum(g.t_first is not None for g in ss)\n            gaining = sum(1 for a, b in zip(last_tok, now_tok) if b > a)\n            last_tok = now_tok\n            best = max(best, run)\n            samples.append([round(time.perf_counter() - t_adm, 1), run, wait, first, gaining])\n            # rev 3: no preemption in the sample, every running request emitted and is gaining tokens\n            calm = run > 0 and prev is not None and pt == prev[0] and pre == prev[1] and first >= run and gaining >= run\n            if calm and run >= level and wait == 0:\n                settled += 1\n            elif calm and run < level and wait > 0:       # KV-bound: the rest wait; accept a plateau held 30 s\n                flat_since = flat_since or time.perf_counter()\n                settled = settled + 1 if time.perf_counter() - flat_since > 30 else 0\n            else:\n                settled, flat_since = 0, None\n            prev = (pt, pre)\n            if settled >= 3:\n                break\n        r[\"admission\"] = {\"sec\": round(time.perf_counter() - t_adm, 1), \"best_running\": best, \"tail\": samples[-6:],\n                          \"prefill_tok_s\": round((prom(port).get(PROMPT, 0) - p0.get(PROMPT, 0)) /\n                                                 max(1e-3, time.perf_counter() - t_adm), 1)}\n        if settled < 3:\n            r[\"status\"] = \"INCONCLUSIVE_NO_SETTLE\"\n            if barrier:\n                barrier.abort()\n            return r\n        if barrier:\n            try:\n                barrier.wait(timeout=max(60.0, admit))\n            except threading.BrokenBarrierError:\n                r[\"status\"] = \"INCONCLUSIVE_REPLICA_BARRIER\"\n                return r\n        m0, t0 = prom(port), time.perf_counter()\n        runs, waits, kvs, mids, gmem, stalls = [], [], [], [], [], [0] * len(ss)\n        last_tok, track, misses = [len(g.tokens) for g in ss], None, 0\n        while time.perf_counter() - t0 < secs:\n            time.sleep(min(sample, max(0.1, secs - (time.perf_counter() - t0))))\n            try:\n                m = prom(port)\n            except Exception:                              # rev 3c: one failed metrics read is not a crash\n                misses += 1\n                if misses >= 5:\n                    break\n                continue\n            mids.append(m)\n            runs.append(m.get(RUN, 0))\n            waits.append(m.get(WAIT, 0))\n            if KVU in m:\n                kvs.append(m[KVU])\n            now_tok = [len(g.tokens) for g in ss]\n            if track is None:                              # rev 3c: only streams decoding at window start can stall\n                track = {i for i in range(len(ss)) if now_tok[i] > last_tok[i]}\n            for i, g in enumerate(ss):\n                if i in track and g.is_alive():\n                    stalls[i] = stalls[i] + 1 if now_tok[i] <= last_tok[i] else 0\n            last_tok = now_tok\n            if any(x >= 3 for x in stalls):\n                break\n            if gpu_sample and len(mids) % 5 == 1:\n                g_ = gpu_mem()\n                if g_:\n                    gmem.append(g_)\n        m1, t1 = prom(port), time.perf_counter()\n        gen = m1.get(GEN, 0) - m0.get(GEN, 0)\n        dt = t1 - t0\n        acc, drf, dtk, it = (m1.get(k, 0) - m0.get(k, 0) for k in (ACC, DRF, DTOK, ITER))\n        rm = statistics.mean(runs) if runs else 0\n        steps = it if it else ((drf / rm) if (drf and rm) else ((gen / rm) if rm else 0))\n        r.update(tok_s=round(gen / dt, 1) if dt else None, gen_tokens=int(gen), window_sec=round(dt, 1),\n                 running_mean=round(rm, 2), running_min=min(runs or [0]), running_max=max(runs or [0]),\n                 waiting_min=min(waits or [0]), waiting_max=max(waits or [0]),\n                 tok_s_per_stream=round(gen / dt / rm, 2) if rm and dt else None,\n                 accept_per_draft=round(acc / drf, 3) if drf else None,\n                 mean_acceptance_length=round(1 + acc / drf, 3) if drf else None,\n                 accept_rate=round(acc / dtk, 3) if dtk else None,\n                 steps=int(steps), steps_source=\"iteration_histogram\" if it else \"estimate\",\n                 step_ms=round(dt * 1000 / steps, 1) if steps else None,\n                 tokens_per_step=round(gen / steps, 2) if steps else None,\n                 kv_usage_mean=round(statistics.mean(kvs), 3) if kvs else None, kv_usage_max=max(kvs) if kvs else None,\n                 gpu_mem_peak_mib=[max(row[i][1] for row in gmem if len(row) > i) for i in range(max(map(len, gmem)))] if gmem else None,\n                 preemptions=m1.get(PREEMPT, 0) - m0.get(PREEMPT, 0), t0=t0, t1=t1)\n        if misses >= 5:\n            r[\"status\"] = \"INCONCLUSIVE_METRICS_LOST\"\n        elif any(x >= 3 for x in stalls):\n            r[\"status\"] = \"INCONCLUSIVE_STALLED_STREAM\"\n        elif sum(g.is_alive() for g in ss) < min(level, best):\n            r[\"status\"] = \"INCONCLUSIVE_STREAMS_ENDED_IN_WINDOW\"\n        elif any(x.get(PROMPT) != m0.get(PROMPT) for x in mids + [m1]):\n            r[\"status\"] = \"INCONCLUSIVE_PREFILL_IN_WINDOW\"\n        elif r[\"preemptions\"] > 0:\n            r[\"status\"] = \"INCONCLUSIVE_PREEMPTION\"\n        elif gen <= 0:\n            r[\"status\"] = \"FAIL_NO_DECODE\"\n        elif min(runs or [0]) < level and (len(set(runs)) > 1 or len(set(waits)) > 1):\n            r[\"status\"] = \"INCONCLUSIVE_RUNNING_SET_CHANGED\"      # KV-bound window must hold one fixed set\n        elif min(runs or [0]) < 0.8 * max(runs or [1]):\n            r[\"status\"] = \"INCONCLUSIVE_RUNNING_UNSTABLE\"\n        else:\n            r[\"status\"] = (\"STEADY\" if min(runs or [0]) == max(runs or [0]) == level else\n                           \"CAPACITY_LIMITED\" if max(runs or [0]) < level else \"INCONCLUSIVE_RUNNING_ABOVE_LEVEL\")\n        return r\n    finally:\n        errs = sorted({g.err for g in ss if g.err})[:3]           # rev 3: snapshot before stop() sets _halt\n        for g in ss:\n            g.stop()\n        for g in ss:\n            g.join(10)\n        r[\"client_leak\"] = any(g.is_alive() for g in ss)\n        r[\"stream_errors\"] = errs\n        gb = [degenerate(\"\".join(g.text)[-4000:]) if g.tokens else None for g in ss]\n        r[\"garbage\"] = {\"streams\": len(ss), \"with_output\": sum(1 for g in ss if g.tokens),\n                        \"garbage\": [x for x in gb if x], \"sample_tail\": \"\".join(ss[0].text)[-200:] if ss and ss[0].tokens else \"\"}\n        if r[\"garbage\"][\"garbage\"] and r.get(\"status\") in (\"STEADY\", \"CAPACITY_LIMITED\"):\n            r[\"status\"] = \"FAIL_GARBAGE_UNDER_LOAD\"\n        r[\"idle_after\"] = wait_idle(port)\n\n\ndef steady_multi(jobs, secs=60.0, **kw):\n    \"\"\"Several servers at once (TP1 replicas): jobs = [(port, prompts, level)]; one shared window (barrier). The aggregate\n    counts only when every window is STEADY / CAPACITY_LIMITED and the windows overlap >= 80 % of the shortest.\"\"\"\n    out = [None] * len(jobs)\n    bar = threading.Barrier(len(jobs))\n\n    def one(i, j):\n        try:\n            out[i] = steady(j[0], j[1], j[2], secs=secs, barrier=bar, **kw)\n        except Exception as e:          # rev 3: a dead replica is recorded, not printed to stderr only\n            out[i] = {\"status\": \"ERROR_REPLICA\", \"error\": f\"{type(e).__name__}: {e}\"[:300], \"port\": j[0]}\n            try:\n                bar.abort()\n            except Exception:\n                pass\n    th = [threading.Thread(target=one, args=(i, j), daemon=True) for i, j in enumerate(jobs)]\n    for t in th:\n        t.start()\n    for t in th:\n        t.join()\n    good = all(o and o.get(\"status\") in (\"STEADY\", \"CAPACITY_LIMITED\") for o in out)\n    ov = (min(o[\"t1\"] for o in out) - max(o[\"t0\"] for o in out)) if good else 0\n    aligned = good and ov > 0.8 * min(o[\"window_sec\"] for o in out)\n    return {\"replicas\": out, \"aligned\": aligned, \"overlap_sec\": round(ov, 1),\n            \"tok_s\": round(sum(o[\"tok_s\"] for o in out), 1) if aligned else None,\n            \"running_mean\": round(sum(o[\"running_mean\"] for o in out), 2) if aligned else None,\n            \"status\": \"AGGREGATE_STEADY\" if aligned else \"INCONCLUSIVE_REPLICA_WINDOWS\"}\n\n\ndef wait_idle(port, wait=90.0):\n    end, hits = time.perf_counter() + wait, 0\n    while time.perf_counter() < end:\n        try:\n            m = prom(port)\n            hits = hits + 1 if m.get(RUN, 0) == 0 and m.get(WAIT, 0) == 0 else 0\n        except Exception:\n            hits = 0\n        if hits >= 3:\n            return True\n        time.sleep(2)\n    return False\n\n\n# ------------------------------------------------------------------ profiler (FULL-graph proof + per-category time)\n# rev 3: matched on the kernel BASE name, attention before GDN (\"fla\" is a substring of \"flashinfer\"), real 0.32 GDN names\nCATS = [(\"nccl\", (\"nccl\", \"allreduce\", \"all_reduce\", \"allgather\", \"all_gather\")),\n        (\"attention\", (\"flashinfer\", \"flash_fwd\", \"unified_attention\", \"paged\", \"attn\", \"attention\", \"batchdecode\", \"batchprefill\",\n                   \"reshape_and_cache\")),\n        (\"gdn_linear_attn\", (\"gdn\", \"delta_rule\", \"chunk_\", \"recurrent\", \"causal_conv\", \"l2norm\", \"solve_tril\", \"merge_16x16\",\n                             \"recompute_w_u\", \"kkt\", \"cumsum\", \"post_conv\", \"layer_norm_gated\", \"gated_delta\")),\n        (\"gemm_marlin\", (\"marlin\",)),\n        (\"gemm_other\", (\"gemm\", \"cutlass\", \"xmma\", \"cublas\", \"sm89_\", \"ampere_\", \"sm80_\")),\n        (\"sampling\", (\"sampl\", \"topk\", \"top_k\", \"argmax\", \"softmax\", \"rejection\"))]\n\n\ndef _cat(name):\n    # rev 3h: \"void (anonymous namespace)::gdn_decode_post_conv_mtp_kernel<...>(...)\" used to reduce to \"void \" -> other\n    s = re.sub(r\"\\(anonymous namespace\\)::\", \"\", str(name))\n    s = re.sub(r\"^\\s*void\\s+\", \"\", s)\n    base = s.split(\"<\")[0].split(\"(\")[0].lower()\n    return next((k for k, pats in CATS if any(p in base for p in pats)), \"other\")\n\n\nCOMPUTE_CATS = (\"nccl\", \"attention\", \"gdn_linear_attn\", \"gemm_marlin\", \"gemm_other\")\n# rev 3h: vLLM 0.32 marks each model execution as execute_context_N(N)_generation_N(N) (no gpu_model_runner range)\nSCOPE_RE = re.compile(r\"^execute_context_\\d+\\(\\d+\\)_generation_\\d+\\(\\d+\\)$\")\n\n\ndef _is_scope(e):\n    n = str(e.get(\"name\", \"\"))\n    return SCOPE_RE.match(n) is not None or (\"forward\" in n.lower() and \"gpu_model_runner\" in n.lower())\n\n\ndef _scope_kind(g, compute_eager, unresolved):\n    \"\"\"FULL = graph-launched with no eager model compute (attention / GDN / GEMM / NCCL) inside the execution scope;\n    eager input-preparation kernels are counted apart and allowed. Unresolved eager launches never read FULL.\"\"\"\n    if g == 0:\n        return \"EAGER\"\n    if compute_eager:\n        return \"PIECEWISE\"\n    if unresolved:\n        return \"PIECEWISE\" if g > 1 else \"MIXED\"\n    return \"FULL\"\n\n\ndef trace_summary(pdir):\n    files = sorted(Path(pdir).rglob(\"*.pt.trace.json*\"), key=lambda p: p.stat().st_mtime)\n    if not files:\n        return {\"error\": \"NO_TRACE_FILE\", \"listing\": [str(p) for p in Path(pdir).rglob(\"*\")][:20]}\n    f = next((p for p in files if re.search(r\"rank0\\.|rank[-_]?0[._]|tp0_\", p.name)), files[0])\n    with (gzip.open if f.name.endswith(\".gz\") else open)(f, \"rt\", encoding=\"utf-8\") as fh:\n        tr = json.load(fh)\n    ev = tr.get(\"traceEvents\", [])\n    kern = [e for e in ev if e.get(\"ph\") == \"X\" and str(e.get(\"cat\", \"\")).lower() in (\"kernel\", \"gpu_kernel\")]\n    rt = [e for e in ev if e.get(\"ph\") == \"X\" and str(e.get(\"cat\", \"\")).lower() in (\"cuda_runtime\", \"cuda_driver\")]\n    is_graph = lambda e: \"GraphLaunch\" in str(e.get(\"name\", \"\"))\n    is_kl = lambda e: re.search(r\"LaunchKernel|cuLaunchKernel\", str(e.get(\"name\", \"\"))) is not None\n    # per-scope counts inside the execution annotations (rev 3h: execute_context_*_generation_*; the older\n    # gpu_model_runner forward ranges still count). rev 3c: user_annotation only, not the gpu_user_annotation copies.\n    fw = sorted([e for e in ev if e.get(\"ph\") == \"X\" and str(e.get(\"cat\", \"\")) == \"user_annotation\" and _is_scope(e)],\n                key=lambda e: e.get(\"ts\", 0))\n    kname = {(e.get(\"args\") or {}).get(\"correlation\"): str(e.get(\"name\", \"\")) for e in kern\n             if (e.get(\"args\") or {}).get(\"correlation\") is not None}\n    per_fw, aux = [], {}\n    for a in fw[:400]:\n        lo, hi, tid = a.get(\"ts\", 0), a.get(\"ts\", 0) + a.get(\"dur\", 0), a.get(\"tid\")\n        inside = [e for e in rt if e.get(\"tid\") == tid and lo <= e.get(\"ts\", -1) <= hi]\n        kls = [e for e in inside if is_kl(e)]\n        ce = un = 0\n        for e in kls:\n            kn = kname.get((e.get(\"args\") or {}).get(\"correlation\"))\n            if kn is None:\n                un += 1\n            elif _cat(kn) in COMPUTE_CATS:\n                ce += 1\n            else:\n                b = re.sub(r\"^\\s*void\\s+\", \"\", re.sub(r\"\\(anonymous namespace\\)::\", \"\", kn)).split(\"<\")[0].split(\"(\")[0][:60]\n                aux[b] = aux.get(b, 0) + 1\n        per_fw.append([sum(1 for e in inside if is_graph(e)), len(kls), ce, un])\n    corr = {(e.get(\"args\") or {}).get(\"correlation\"): str(e.get(\"name\", \"\")) for e in rt\n            if (e.get(\"args\") or {}).get(\"correlation\") is not None}\n    per, tot, names = {k: 0.0 for k, _ in CATS + [(\"other\", ())]}, 0.0, {}\n    src = {k: {\"graph\": 0, \"eager\": 0, \"unknown\": 0} for k in per}\n    for e in kern:\n        d = float(e.get(\"dur\", 0.0))\n        tot += d\n        names[e.get(\"name\", \"\")] = names.get(e.get(\"name\", \"\"), 0.0) + d\n        k = _cat(e.get(\"name\", \"\"))\n        per[k] += d\n        launcher = corr.get((e.get(\"args\") or {}).get(\"correlation\"))\n        src[k][\"graph\" if launcher and \"GraphLaunch\" in launcher else (\"eager\" if launcher else \"unknown\")] += 1\n    tot_k = sum(v[\"graph\"] + v[\"eager\"] for v in src.values())\n    eager_share = round(sum(v[\"eager\"] for v in src.values()) / tot_k, 3) if tot_k else None\n    fw_g = statistics.median([x[0] for x in per_fw]) if per_fw else None\n    fw_k = statistics.median([x[1] for x in per_fw]) if per_fw else None\n    kinds_l = [_scope_kind(g, ce, un) for g, k, ce, un in per_fw]\n    if per_fw:                   # rev 3f (GPT rev 3e audit: 2 FULL + 1 EAGER forwards read FULL by the median)\n        kinds = set(kinds_l)\n        verdict = kinds.pop() if len(kinds) == 1 else \"MIXED\"       # every scope must agree\n        basis = \"per_scope_annotation (all scopes; eager input-prep kernels allowed, eager model compute is not)\"\n    elif tot_k:                  # rev 3d (GPT-2 reproduced FULL with 0 forwards): CUPTI alone never proves FULL\n        att = src[\"attention\"]\n        hint = (\"FULL\" if att[\"eager\"] == 0 and (eager_share or 0) < 0.05 else\n                \"PIECEWISE\" if att[\"eager\"] > 0 and any(v[\"graph\"] for v in src.values()) else\n                \"EAGER\" if not any(v[\"graph\"] for v in src.values()) else \"MIXED\")\n        verdict, basis = \"UNPROVEN\", f\"no forward annotations (cupti hint: {hint})\"\n    else:\n        verdict, basis = \"UNKNOWN\", \"none\"\n    return {\"file\": f.name, \"files\": len(files), \"kernels\": len(kern), \"kernel_us_sum\": round(tot),\n            \"graph_launches\": sum(1 for e in rt if is_graph(e)), \"kernel_launches\": sum(1 for e in rt if is_kl(e)),\n            \"forwards\": len(per_fw), \"forward_kinds\": {k_: kinds_l.count(k_) for k_ in (\"FULL\", \"PIECEWISE\", \"EAGER\", \"MIXED\")},\n            \"per_forward_median_graph_launches\": fw_g, \"per_forward_median_kernel_launches\": fw_k,\n            \"per_forward_median_compute_eager\": statistics.median([x[2] for x in per_fw]) if per_fw else None,\n            \"per_forward_unresolved_eager\": sum(x[3] for x in per_fw),\n            \"scope_names\": sorted({str(a.get(\"name\", \"\")) for a in fw})[:5],\n            \"aux_eager_kernels_in_scopes\": dict(sorted(aux.items(), key=lambda x: -x[1])[:20]),\n            \"launch_source\": src, \"eager_kernel_share\": eager_share, \"graph_verdict\": verdict, \"verdict_basis\": basis,\n            \"by_category_pct\": {k: round(100 * v / tot, 1) for k, v in per.items()} if tot else {},\n            \"top_kernels_us\": dict(sorted(((k, round(v)) for k, v in names.items()), key=lambda x: -x[1])[:25]),\n            \"note\": \"kernel time sums overlapping streams; NCCL time includes rank-skew waiting\"}\n\n\ndef profile(port, pdir, secs=6.0, delay_iters=20, max_iters=40):\n    \"\"\"POST /start_profile (bounded by iterations; falls back to a bare POST), decode, POST /stop_profile, summary.\"\"\"\n    rec = {}\n    try:\n        U.urlopen(U.Request(f\"http://127.0.0.1:{port}/start_profile\", method=\"POST\",\n                            data=json.dumps({\"delay_iterations\": delay_iters, \"max_iterations\": max_iters}).encode(),\n                            headers={\"Content-Type\": \"application/json\"}), timeout=900).read()\n        rec[\"start_profile\"] = \"ok_bounded\"\n    except Exception as e:\n        rec[\"start_profile_bounded_error\"] = repr(e)[:200]\n        try:\n            U.urlopen(U.Request(f\"http://127.0.0.1:{port}/start_profile\", data=b\"\", method=\"POST\"), timeout=900).read()\n            rec[\"start_profile\"] = \"ok\"\n        except Exception as e2:\n            rec[\"start_profile\"] = repr(e2)[:200]\n    time.sleep(secs)\n    try:\n        U.urlopen(U.Request(f\"http://127.0.0.1:{port}/stop_profile\", data=b\"\", method=\"POST\"), timeout=900).read()\n        rec[\"stop_profile\"] = \"ok\"\n    except Exception as e:\n        rec[\"stop_profile\"] = repr(e)[:200]\n    time.sleep(20)\n    try:\n        rec[\"trace\"] = trace_summary(pdir)\n    except Exception as e:\n        rec[\"trace\"] = {\"error\": f\"TRACE_PARSE {type(e).__name__}: {e}\"[:300]}\n    return rec\n\n\ndef profiled_load(port, prompts, level, pdir, secs=6.0, max_new=8192, model=\"q27\", prefill_tok_s=700.0, spec=False):\n    \"\"\"`level` decoding streams (own window: the profiler slows decode), profile() only after prefill settled exactly\n    as in steady() (prompt counter + preemptions flat, every running request emitted and gaining tokens). rev 3d: no\n    profile when unsettled; the profile window must be decode-only (prompt counter flat) and, with `spec`, show\n    speculative drafts (else the trace cannot speak for multi-token verification).\"\"\"\n    plen = len(prompts[0]) if prompts else 0\n    settle = max(300.0, 120.0 + level * plen / prefill_tok_s)\n    ss = [Stream(port, prompts[i % len(prompts)], max_new, 1.0, 4321 + i, model=model) for i in range(level)]\n    for g in ss:\n        g.start()\n    rec, t0, flat, ok, prev, last_tok = {\"level\": level}, time.perf_counter(), None, 0, None, [0] * level\n    try:\n        while time.perf_counter() - t0 < settle:\n            time.sleep(2)\n            try:\n                m = prom(port)\n            except Exception:\n                continue\n            run, wait, pt, pre = int(m.get(RUN, 0)), int(m.get(WAIT, 0)), m.get(PROMPT), m.get(PREEMPT, 0)\n            now_tok = [len(g.tokens) for g in ss]\n            gaining = sum(1 for a, b in zip(last_tok, now_tok) if b > a)\n            last_tok = now_tok\n            first = sum(g.t_first is not None for g in ss)\n            calm = run > 0 and prev is not None and (pt, pre) == prev and first >= run and gaining >= run\n            if calm and run >= level and wait == 0:\n                ok += 1\n            elif calm and wait > 0:\n                flat = flat or time.perf_counter()\n                ok = ok + 1 if time.perf_counter() - flat > 30 else 0\n            else:\n                ok, flat = 0, None\n            prev = (pt, pre)\n            if ok >= 3:\n                break\n        rec[\"settled\"] = ok >= 3\n        if not rec[\"settled\"]:\n            rec[\"status\"] = \"INCONCLUSIVE_PREFILL_NOT_SETTLED\"\n            return rec\n        try:\n            m0 = prom(port)\n            rec[\"running_at_start\"] = m0.get(RUN)\n        except Exception:\n            m0 = {}\n        rec.update(profile(port, pdir, secs))\n        try:\n            m1 = prom(port)\n        except Exception:\n            m1 = {}\n        rec[\"window_deltas\"] = {\"prompt_tokens\": m1.get(PROMPT, 0) - m0.get(PROMPT, 0), \"drafts\": m1.get(DRF, 0) - m0.get(DRF, 0),\n                                \"accepted\": m1.get(ACC, 0) - m0.get(ACC, 0), \"generated\": m1.get(GEN, 0) - m0.get(GEN, 0)}\n        if not m0 or not m1:\n            rec[\"status\"] = \"INCONCLUSIVE_METRICS_UNAVAILABLE\"\n        elif rec[\"window_deltas\"][\"prompt_tokens\"]:\n            rec[\"status\"] = \"INCONCLUSIVE_PREFILL_IN_PROFILE\"\n        elif spec and not (rec[\"window_deltas\"][\"drafts\"] and rec[\"window_deltas\"][\"accepted\"]):\n            rec[\"status\"] = \"INCONCLUSIVE_NO_SPEC_DECODE\"            # rev 3e: drafts AND accepted tokens in the window\n        return rec\n    finally:\n        for g in ss:\n            g.stop()\n        for g in ss:\n            g.join(10)\n        rec[\"idle_after\"] = wait_idle(port)\n"
    (TMP / "e23_lab.py").write_text(LAB_SRC)
    sys.path.insert(0, str(TMP))
    import e23_lab as L
    REQ_LOG = TRACES / "requests.jsonl"                           # memory rule: the full text of EVERY request
    _stream_run = L.Stream.run

    def _traced_run(self):
        try:
            _stream_run(self)
        finally:
            if not self.err and any(m is not None and not (isinstance(m, (int, float)) and math.isfinite(m))
                                    for m in self.margins):
                self.err = "NONFINITE_LOGPROB"           # final audit H2: NaN / Inf logprobs are never data
            try:
                r = self.row()
                pr = self.body.get("prompt") or []
                r.update(port=self.port, sampling={k: v for k, v in self.body.items() if k != "prompt"}, prompt_len=len(pr),
                         prompt_sha=hashlib.sha256(json.dumps(pr).encode()).hexdigest()[:16],
                         ttft=round(self.t_first - self.t_start, 2) if self.t_first and self.t_start else None,
                         sec=round(self.t_end - self.t_start, 2) if self.t_end and self.t_start else None, t=time.time())
                with _SAVE_LOCK, open(REQ_LOG, "a") as fh:
                    fh.write(json.dumps(r) + "\n")
            except Exception:
                pass
    L.Stream.run = _traced_run
    PLE_EXPECTED = json.loads(r"""{"model-plefp8-00000.safetensors": [5200027199, "dc2e845b7edd35bda92834fba3626bf7d199e28d6aceac99fee654aade390cfd"], "model-plefp8-00001.safetensors": [5200027202, "899eaa0716e28594468a1389ee58cb065c23907f1270de3831f5ecb0a4f82d56"], "model-plefp8-00002.safetensors": [5200027198, "06fd8a11abf0419a669f89397b8d70dd6ff42d401e6b2a037c65e49704faaf71"], "model-plefp8-00003.safetensors": [5200027189, "c6aaa1fc08e84eced3c8151ac8679ed943888eba0fcef2556963693430f95bd9"], "model-plefp8-00004.safetensors": [5200027190, "d94e97c96d3ea09208614da016960f3f4b429f47a044c898a51b493f42f74ba2"], "model-plefp8-00005.safetensors": [5200027190, "03d5d4792e14a4ab55bae50bb459624b01786f818bbcfcaed1a5d0235af484c6"], "model-plefp8-00006.safetensors": [5200027190, "586cccbc12383021bc9bc02f206d9b19fbd1672373ed9a5d91e3b0ce34c2418f"], "model-plefp8-00007.safetensors": [5200027190, "c4a23bcc10f3cde6b633e82c282a9a518e3a64d433628283e1bc592c94cf3d6c"], "model-plefp8-00008.safetensors": [5200027190, "2dc8098c0d020bff277c9cf499a6b908e17836b70a5f949dfa24793371c9a87e"], "model-plefp8-00009.safetensors": [4400023163, "61de98b89bb79f386795787d7a76827a26f1e292c26edbb0a1b613da455f5a9c"]}""")                     # 10 FP8 PLE shards: [size, sha256]
    # exact Kaggle mount paths (foysalemonshanto Models, checked through the API 2026-10-31; no recursive search)
    MD = INP / "models" / "foysalemonshanto"
    PART_DIRS = {1: MD / "qwen3-8-flash-next-w4a16-merlin-p1/transformers/default/1",
                 2: MD / "qwen3-8-flash-next-w4a16-merlin-p2/transformers/default/1",
                 3: MD / "qwen3-8-flash-next-w4a16-merlin-p3/transformers/default/1",
                 4: MD / "qwen3-8-flash-next-w4a16-merlin-p4/transformers/default/1",
                 5: MD / "qwen3-8-flash-next-w4a16-merlin-p5/transformers/default/1"}
    PARTS = {}
    for k, d in PART_DIRS.items():                                  # the five checkpoint parts (Models from the kernel outputs)
        mf = d / f"q27_fn_merlin_part{k}_manifest.json"
        PARTS[k] = (d, json.loads(mf.read_text())) if mf.is_file() else None
    PLE_DIR = MD / "qwen38-flash-next-fp8ple-overlay/pytorch/albucino-fp8ple/1"      # our FP8 PLE overlay = albucino's shards
    PLE_DIR = PLE_DIR if (PLE_DIR / "model-plefp8-00000.safetensors").is_file() else None
    MERLIN_PAY = MD / "e23-merlin-env/other/v1/1/merlin_offline_tar.bin"
    MERLIN_PAY = MERLIN_PAY if MERLIN_PAY.is_file() else None
    INTEL = INP / "models/dfranzen/intel-qwen3.8-flash-next-w4a16-autoround/transformers/default/1"
    INTEL = INTEL if (INTEL / "config.json").is_file() else None
    WHEELHOUSE = INP / "datasets/foysalemonshanto/vllm-0-32-0-cu13-wheelhouse/install_wheelhouse.py"
    WHEELHOUSE = WHEELHOUSE if WHEELHOUSE.is_file() else None
    ARC = COMP / "arc-agi_evaluation_challenges.json"
    if not ARC.is_file():
        raise FileNotFoundError(f"{ARC}: attach the competition data")
    MERLIN_OK = all(PARTS.values()) and PLE_DIR is not None and MERLIN_PAY is not None
    R["inputs"] = {"parts": {k: (str(v[0]) if v else None) for k, v in PARTS.items()}, "ple_dir": str(PLE_DIR),
                   "merlin_pay": str(MERLIN_PAY), "intel": str(INTEL), "wheelhouse": str(WHEELHOUSE), "arc": str(ARC),
                   "merlin_inputs_ok": MERLIN_OK}
    ABORT = {"why": None}
    NVSMI_OK = bool(L.gpu_mem()) and not FAKE
    R["setup"]["gpus_at_start"] = L.gpu_mem()
    if not FAKE and not os.environ.get("RC2_CPU_KIT") and len(R["setup"]["gpus_at_start"] or []) != 4:   # CPU kit: no GPUs
        R["errors"].append(f"expected 4 GPUs, nvidia-smi shows {R['setup']['gpus_at_start']}")
        save()
        raise RuntimeError("GPU_PREFLIGHT_FAILED: " + repr(R["setup"]["gpus_at_start"]))
    L.start_watchdog(HARD_STOP, lambda: ABORT.update(why="HARD_STOP reached: watchdog killed live servers"))
    log("RC2 | budget", BUDGET // 60, "min |", json.dumps(R["inputs"])[:900])
    save()


if not RERUN:
    # ==================================================================== CELL 2 — host facts, checkpoint merge, engines
    def run(name, cmd, timeout=3600, env=None):
        t = time.time()
        try:
            with open(LOGS / f"{name}.log", "w") as f:
                r = subprocess.run(["bash", "-c", "set -o pipefail; " + cmd], stdout=f, stderr=subprocess.STDOUT, timeout=timeout,
                                   env={**os.environ, **(env or {})})
            rc = r.returncode
        except subprocess.TimeoutExpired:
            rc = -9
        txt = (LOGS / f"{name}.log").read_text(errors="replace")
        R["setup"][name] = {"rc": rc, "sec": round(time.time() - t, 1), "tail": txt[-1500:]}
        log(name, "rc", rc, f"{time.time() - t:.0f}s")
        save()
        return rc, txt


    SHIM = TMP / "e23_libcuda"          # FlashInfer JIT links -lcuda; Kaggle has only libcuda.so.1
    SHIM.mkdir(exist_ok=True)
    for d in ("/usr/local/nvidia/lib64", "/usr/lib/x86_64-linux-gnu", "/usr/local/cuda/compat", "/usr/lib64"):
        c = sorted(Path(d).glob("libcuda.so.1")) if Path(d).is_dir() else []
        if c and not (SHIM / "libcuda.so").exists():
            (SHIM / "libcuda.so").symlink_to(c[0])


    def host_facts():
        """A0: what the Kaggle box gives us (glibc, driver, GPUs, PCIe, peer access, cgroup memory, /dev/shm, disk)."""
        f = {}
        for k, cmd in (("glibc", "ldd --version | head -1"), ("uname", "uname -a"),
                       ("nvidia_smi", "nvidia-smi --query-gpu=name,compute_cap,driver_version,memory.total,pcie.link.gen.max,pcie.link.width.max --format=csv,noheader"),
                       ("cuda_version", "nvidia-smi | grep -o 'CUDA Version: [0-9.]*'"), ("shm", "df -h /dev/shm | tail -1"),
                       ("tmp_disk", f"df -h {TMP} | tail -1"), ("nproc", "nproc"),
                       ("cgroup_max", "cat /sys/fs/cgroup/memory.max 2>/dev/null || cat /sys/fs/cgroup/memory/memory.limit_in_bytes"),
                       ("cgroup_cur", "cat /sys/fs/cgroup/memory.current 2>/dev/null || cat /sys/fs/cgroup/memory/memory.usage_in_bytes"),
                       ("meminfo", "grep -E 'MemTotal|MemAvailable' /proc/meminfo"), ("ulimit_l", "ulimit -l"),
                       ("omp", "echo OMP_NUM_THREADS=$OMP_NUM_THREADS"), ("topo", "nvidia-smi topo -m; nvidia-smi topo -p2p r"),
                       ("pcie_now", "nvidia-smi --query-gpu=index,pcie.link.gen.current,pcie.link.width.current,power.limit --format=csv,noheader")):
            try:
                f[k] = subprocess.run(["bash", "-c", cmd], capture_output=True, text=True, timeout=60).stdout.strip()[:600]
            except Exception as e:
                f[k] = repr(e)[:200]
        try:
            import torch
            n = torch.cuda.device_count()
            f["peer_access"] = [[torch.cuda.can_device_access_peer(i, j) if i != j else None for j in range(n)] for i in range(n)]
        except Exception as e:
            f["peer_access"] = repr(e)[:200]
        return f


    def host_mem():
        """MiB. avail_mib = max - (current - inactive_file), Merlin's own rule (RC1's guard counted page cache as used and
        skipped arm 3 with MemAvailable 55 GB); /dev/shm counts against the cgroup."""
        out = {}
        try:
            cur = int(Path("/sys/fs/cgroup/memory.current").read_text())
            mx = Path("/sys/fs/cgroup/memory.max").read_text().strip()
            st = dict(l.split() for l in Path("/sys/fs/cgroup/memory.stat").read_text().splitlines() if len(l.split()) == 2)
            out.update(cgroup_cur_mib=cur >> 20, cgroup_max_mib=None if mx == "max" else int(mx) >> 20,
                       **{k + "_mib": int(st[k]) >> 20 for k in ("anon", "file", "shmem", "inactive_file") if k in st})
            if mx != "max":
                out["avail_mib"] = (int(mx) - (cur - int(st.get("inactive_file", 0)))) >> 20
        except Exception:
            pass
        try:
            for l in open("/proc/meminfo"):
                if l.startswith(("MemAvailable", "MemTotal")):
                    out[l.split(":")[0] + "_mib"] = int(l.split()[1]) >> 10
        except Exception:
            pass
        try:
            out["dev_shm_used_mib"] = shutil.disk_usage("/dev/shm").used >> 20
        except Exception:
            pass
        return out


    TELEMETRY = OUT / "telemetry.jsonl"


    def _telemetry():
        """Host RAM + GPU memory every 10 s for the whole run (Merlin's floor ~69 GiB inside a ~173 GiB cgroup)."""
        while True:
            try:
                with open(TELEMETRY, "a") as fh:
                    fh.write(json.dumps({"t": round(time.time() - T_START, 1), "host": host_mem(), "gpu": L.gpu_mem()}) + "\n")
            except Exception:
                pass
            time.sleep(10)


    threading.Thread(target=_telemetry, daemon=True).start()


    SHM = Path(os.environ.get("RC2_SHM", "/dev/shm"))


    def shm_names():
        try:
            return {p.name for p in SHM.iterdir()}
        except Exception:
            return set()


    def shm_cleanup(before):
        """After a boot's server is dead: only /dev/shm entries that appeared during THIS boot (absent from `before`) and
        match the engine's prefixes are unlinked; everything else is recorded, never touched."""
        out = {"host_before": host_mem(), "removed": [], "kept": []}
        try:
            for p in sorted(SHM.iterdir()):
                try:
                    sz = p.stat().st_size >> 20
                except Exception:
                    sz = None
                if p.name not in before and re.match(r"(torch_|psm_|vllm|ple|nccl|sem\.mp-|cuda\.shm)", p.name, re.I):
                    try:
                        p.unlink() if not p.is_dir() else shutil.rmtree(p)
                        out["removed"].append([p.name, sz])
                    except Exception as e:
                        out["kept"].append([p.name, sz, repr(e)[:80]])
                else:
                    out["kept"].append([p.name, sz])
        except Exception as e:
            out["error"] = repr(e)[:200]
        out["host_after"] = host_mem()
        out["removed"], out["kept"] = out["removed"][:60], out["kept"][:60]
        return out


    class MServer(L.Server):
        """Merlin passes --shutdown-timeout 60 and the PLE transport unlinks its /dev/shm storages only on a graceful
        teardown: SIGTERM, wait 75 s, then E23's kill (SIGTERM + 40 s + SIGKILL of the whole session)."""
        def kill(self):
            if self.proc is not None and self.proc.poll() is None:
                try:
                    os.killpg(self.proc.pid, 15) if hasattr(os, "killpg") else self.proc.terminate()
                except Exception:
                    pass
                try:
                    self.proc.wait(timeout=75)
                except Exception:
                    pass
            super().kill()


    def boot_gate():
        """Merlin's pin leaves ~0.9 GiB free per card: every boot needs near-empty GPUs (< 150 MiB, not E23's 1024)."""
        g = L.wait_gpu_release(300, fake=bool(FAKE), gpus="0,1,2,3", free_mib=150)
        return {"ok": g, "gpus": L.gpu_mem(), "host": host_mem()}       # callers launch only on ok is True


    CKPT = TMP / "fn_merlin"
    SHA = {"thread": None, "ok": None, "bad": [], "sec": None}


    def merge_ckpt():
        """Symlink the 5 parts + 10 PLE shards into one directory; names and sizes now, sha256 in a background thread."""
        SHA.update(thread=None, ok=None, bad=[], sec=None)        # a stale result never gates a new merge
        shutil.rmtree(CKPT, ignore_errors=True)
        CKPT.mkdir(parents=True)
        expected = {}
        for k, (d, man) in PARTS.items():
            for n, (size, sha) in man["files"].items():
                expected[n] = (d / man.get("model_subdir", ".") / n, size, sha)
        for n, (size, sha) in PLE_EXPECTED.items():
            expected[n] = (PLE_DIR / n, size, sha)
        bad = []
        for n, (src, size, sha) in sorted(expected.items()):
            if not src.is_file():
                bad.append(f"missing {n}")
                continue
            if not FAKE and src.stat().st_size != size:
                bad.append(f"{n}: {src.stat().st_size} bytes, expected {size}")
            try:
                (CKPT / n).symlink_to(src)
            except OSError:
                if not FAKE:
                    raise
                shutil.copyfile(src, CKPT / n)               # local Windows harness only (no symlink privilege)
        idx = json.loads((CKPT / "model.safetensors.index.json").read_text())
        need = set(idx["weight_map"].values())
        bad += [f"index needs {n}, not merged" for n in sorted(need - set(expected))]
        cfg = json.loads((CKPT / "config.json").read_text())
        if (cfg.get("text_config") or {}).get("ple_embedding_dtype") != "float8_e4m3fn":
            bad.append("config.json: text_config.ple_embedding_dtype is not float8_e4m3fn")
        rec = {"files": len(expected), "index_files": len(need), "bad": bad[:20], "ok": not bad}

        def hash_all():
            t = time.time()
            import concurrent.futures as CF

            def one(item):
                n, (src, size, sha) = item
                if FAKE:
                    return n, True
                with open(src, "rb") as fh:
                    return n, hashlib.file_digest(fh, "sha256").hexdigest() == sha
            with CF.ThreadPoolExecutor(6) as ex:
                res = list(ex.map(one, sorted(expected.items())))
            SHA.update(ok=all(ok for _, ok in res), bad=[n for n, ok in res if not ok], sec=round(time.time() - t, 1))
            R["setup"]["sha256"] = {k: SHA[k] for k in ("ok", "bad", "sec")}
            save()
        if rec["ok"]:
            SHA["thread"] = threading.Thread(target=hash_all, daemon=True)
            SHA["thread"].start()
        return rec


    def sha_gate(timeout):
        """The first launch waits for the full sha256 check (Merlin itself never hashes shards)."""
        th = SHA["thread"]
        if th is not None:
            th.join(max(1, timeout))
        if th is None or th.is_alive():
            return False, "sha256 check not finished"
        return bool(SHA["ok"]), ("ok" if SHA["ok"] else f"sha256 mismatch: {SHA['bad'][:5]}")


    def prefetch_bg(paths, tag):
        """rev 3: warm the page cache of a cold 17-30 GB /kaggle/input checkpoint in the background (many readers)."""
        def go():
            R["setup"]["prefetch_" + tag] = L.prefetch([p for p in paths if p]) if not FAKE else {"fake": True}
            save()
        th = threading.Thread(target=go, daemon=True)
        th.start()
        return th


    MERLIN_ENG = None


    def merlin_install():
        """P2 payload (.bin = a tar Kaggle does not unpack) -> install_merlin_offline.sh (UV_OFFLINE); payload deleted after;
        a failure is cached so later Merlin steps fail fast (rev 3)."""
        global MERLIN_ENG
        if MERLIN_ENG is not None:
            if MERLIN_ENG.get("failed"):
                raise RuntimeError("Merlin install failed earlier: " + MERLIN_ENG["failed"])
            return MERLIN_ENG
        if not MERLIN_OK or MERLIN_PAY is None:
            MERLIN_ENG = {"failed": "Merlin checkpoint / env not attached or incomplete"}
            raise RuntimeError(MERLIN_ENG["failed"])
        if FAKE:
            MERLIN_ENG = {"fake": True}
            return MERLIN_ENG
        try:
            pay_root = TMP / "merlin_pay"
            shutil.rmtree(pay_root, ignore_errors=True)
            pay_root.mkdir()
            t = time.time()
            with tarfile.open(MERLIN_PAY) as tf:
                tf.extractall(pay_root, filter="data")
            R["setup"]["merlin_extract_sec"] = round(time.time() - t, 1)
            pay = pay_root / "merlin_offline"
            shutil.rmtree(TMP / "merlin_off", ignore_errors=True)
            rc, txt = run("install_merlin", f"bash {pay}/install_merlin_offline.sh {pay} {TMP}/merlin_off", timeout=5400)
            kv = dict(re.findall(r"^(MERLIN_[A-Z]+)=(.*)$", txt, re.M))
            shutil.rmtree(pay_root, ignore_errors=True)
            if rc or "INSTALL OK" not in txt:
                raise RuntimeError("Merlin offline install failed (logs/install_merlin.log)")
            sys.path.insert(0, kv["MERLIN_TREE"] + "/tools/merlin")
            import launch as ML
            site = subprocess.run([kv["MERLIN_VENV"] + "/bin/python", "-c", "import sysconfig;print(sysconfig.get_paths()['purelib'])"],
                                  capture_output=True, text=True).stdout.strip()
            MERLIN_ENG = {"kv": kv, "ML": ML, "cuda_home": site + "/nvidia/cu13"}
            return MERLIN_ENG
        except Exception as e:
            MERLIN_ENG = {"failed": f"{type(e).__name__}: {e}"[:300]}
            raise


    MERLIN_CC = {"mode": "gcc13"}       # rev 3c: Merlin README:229 / install-env.sh: FlashInfer JIT at first start needs GCC >= 13



    KV_FP8, KV_BF16 = 2479838700, 2464415744      # Merlin's own L4 pins (23,034 MiB cards; preflight.kv_bytes_for_vram, 150 / 79 blocks)
    PROFILE = "fn-quad-24g-sm89"
    XHIGH = json.dumps({"enable_thinking": True, "reasoning_effort": "xhigh"})
    HOST_PHASE = {}


    def merlin_fn_server(name, kv, port, kv_bytes):
        """Merlin's launch.build() for Flash-Next on the L4 profile: KV pin lowered for 22.49 GiB cards, the checkpoint's own
        chat template at xhigh (Merlin passes medium otherwise), Merlin's host_phase checks recorded, E23's env overrides."""
        eng = merlin_install()
        extra = ["--served-model-name", "q27", "--max-model-len", str(MAX_LEN), "--port", str(port),
                 "--default-chat-template-kwargs", XHIGH] + list(NB1_EXTRA.get(name) or [])   # E25 NB1: per-boot flags (last wins)
        if FAKE:
            return MServer(name, [sys.executable, FAKE, str(CKPT) + "-w4a16", "--tensor-parallel-size", "2", "--max-num-seqs",
                                  "8" if kv == "fp8" else "3", "--port", str(port), "--max-model-len", str(MAX_LEN),
                                  "--kv-cache-memory-bytes", str(kv_bytes)] + list(NB1_EXTRA.get(name) or []),   # E25 NB1 (fake only)
                           {**os.environ, **(NB1_ENV.get(name) or {})}, port, LOGS)
        kvv = eng["kv"]
        gcc_bin = str(Path(kvv["MERLIN_CC"]).parent) if kvv.get("MERLIN_CC") else ""
        base = {k: v for k, v in os.environ.items() if k not in ("PYTHONPATH", "CUDA_PATH", "CUDA_HOME", "LD_PRELOAD", "CC", "CXX")}
        base.update(GPUS="0,1,2,3", PORT=str(port), KV_BYTES=str(kv_bytes), P2P="off",
                    VENV=kvv["MERLIN_VENV"], TREE=kvv["MERLIN_TREE"], CHAT_TEMPLATE="", WARM="0", CACHE_ROOT=f"{TMP}/merlin-cache",
                    PATH=f"{kvv['MERLIN_VENV']}/bin:{gcc_bin}:{eng['cuda_home']}/bin:{os.environ.get('PATH', '')}",
                    CUDA_HOME=eng["cuda_home"])
        if kv == "fp8":
            base["SCALES"] = str(CKPT / "qsa_kv_scales_262k.json")
        base.update((globals().get("NB4T_BUILD_ENV") or {}).get(name) or {})   # E25 NB4T: launcher knobs (DRAFT_HEAD) into build()
        plan = eng["ML"].build("flash-next", PROFILE, str(CKPT), base, extra=extra, kv=kv, checkpoint="flash-next", status="untested")
        try:                                               # audits: tree products, venv, checkpoint marker, PLE dtype, toolchain,
            eng["ML"].host_phase(plan)                     # scales file: a failure stops this boot before any server starts
            HOST_PHASE[name] = "ok"
        except BaseException as e:
            HOST_PHASE[name] = f"{type(e).__name__}: {e}"[:600]
            R["setup"].setdefault("host_phase_error", {})[name] = HOST_PHASE[name]
            save()
            raise RuntimeError("MERLIN_HOST_PHASE_FAILED: " + HOST_PHASE[name])
        env = dict(plan.env)
        env.update(LD_PRELOAD=kvv["MERLIN_SHIM"], CUDA_HOME=eng["cuda_home"], VLLM_USE_RUST_FRONTEND="0", HF_HUB_OFFLINE="1",
                   TRANSFORMERS_OFFLINE="1", LIBRARY_PATH=f"{SHIM}:{os.environ.get('LIBRARY_PATH', '')}",
                   PATH=base["PATH"], VLLM_CACHE_ROOT=f"{TMP}/merlin-cache", TRITON_CACHE_DIR=f"{TMP}/merlin-triton",
                   FLASHINFER_WORKSPACE_BASE=f"{TMP}/merlin-fi", CUDA_DEVICE_ORDER="PCI_BUS_ID", VLLM_PLE_OFFLOAD_READY_TIMEOUT="3600")
        for k in ("CC", "CXX", "CUDAHOSTCXX"):
            env.pop(k, None)
        if MERLIN_CC["mode"] == "gcc13" and kvv.get("MERLIN_CC") and kvv.get("MERLIN_CXX"):
            env.update(CC=kvv["MERLIN_CC"], CXX=kvv["MERLIN_CXX"], CUDAHOSTCXX=kvv["MERLIN_CXX"])
            lib13 = Path(kvv["MERLIN_CC"]).parents[1] / "lib"
            if (lib13 / "libstdc++.so.6").exists():
                env["LD_LIBRARY_PATH"] = f"{lib13}:{env.get('LD_LIBRARY_PATH', '')}"
        try:                                               # Merlin's own scheme: PORT 8000..8355 -> 29500+d / 30000+100d
            mp, vp = eng["ML"].distributed_ports(str(port))
            env.update(MASTER_PORT=str(mp), VLLM_PORT=str(vp))
        except Exception:
            env.update(MASTER_PORT=str(29500 + port - 8000), VLLM_PORT=str(30000 + 100 * (port - 8000)))
        env.update(NB1_ENV.get(name) or {})              # E25 NB1: after build(), which strips every MERLIN_* variable
        argv = plan.argv()
        HELP[name] = L.help_check("merlin", argv[:argv.index("serve") + 1], env, argv)
        R["setup"].setdefault("merlin_plans", {})[name] = {"argv_tail": argv[-60:], "status": plan.status, "host_phase": HOST_PHASE[name],
                                                           "env_keys": {k: env[k] for k in sorted(env) if k.startswith(("VLLM_", "NCCL_", "KV_", "P2P", "SCALES", "CUDA_DEVICE_MAX_CONNECTIONS", "DRAFT_HEAD", "DFLASH_"))}}   # E25 NB4S / NB4T / E27 NBDF
        save()
        return MServer(name, argv, env, port, LOGS)


    STOCK = None


    def stock_install():
        """Fallback only: stock vLLM 0.32 venv (E18 / E23 installer) with the -lcuda shim on LIBRARY_PATH (RC1's sampler crash)."""
        global STOCK
        if STOCK is not None:
            return STOCK
        if FAKE:
            STOCK = {"vllm": [sys.executable, FAKE], "env": dict(os.environ)}
            return STOCK
        rc, txt = run("install_stock", f"{sys.executable} {WHEELHOUSE} {TMP}/vllm-venv", timeout=2400)
        kv = dict(l.split("=", 1) for l in txt.splitlines() if l.startswith(("VENV_PYTHON=", "CUDA_HOME=")))
        if rc or "CUDA_HOME" not in kv:
            raise RuntimeError("stock vLLM 0.32 install failed (logs/install_stock.log)")
        env = {k: v for k, v in os.environ.items() if k not in ("PYTHONPATH", "CUDA_PATH", "LD_PRELOAD")}
        env.update(CUDA_HOME=kv["CUDA_HOME"], PATH=f"{TMP}/vllm-venv/bin:{kv['CUDA_HOME']}/bin:{env.get('PATH', '')}",
                   LIBRARY_PATH=f"{SHIM}:{env.get('LIBRARY_PATH', '')}", HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1",
                   VLLM_NO_USAGE_STATS="1", VLLM_CACHE_ROOT=f"{TMP}/vllm-cache", CUDA_DEVICE_ORDER="PCI_BUS_ID",
                   PYTORCH_CUDA_ALLOC_CONF="expandable_segments:True")
        STOCK = {"vllm": [f"{TMP}/vllm-venv/bin/vllm", "serve"], "env": env}
        return STOCK


    def stock_fn_server(name, port):
        eng = stock_install()
        flags = [str(INTEL), "--served-model-name", "q27", "--host", "127.0.0.1", "--port", str(port),
                 "--tensor-parallel-size", "4", "--enable-expert-parallel", "--max-model-len", "32768", "--max-num-seqs", "4",
                 "--max-num-batched-tokens", "4096", "--gpu-memory-utilization", "0.88", "--disable-custom-all-reduce",
                 "--language-model-only", "--engram-config", json.dumps({"cpu_offload": True}), "--load-format", "safetensors",
                 "--dtype", "bfloat16", "--kv-cache-dtype", "fp8_e4m3", "--default-chat-template-kwargs", XHIGH]
        # diagnostic only: RC1 had a 30,208-token BF16 pool at TP4; no MTP here, so prefix caching (default ON) is unaffected
        if FAKE:
            flags = [str(INTEL) + "-w4a16", "--tensor-parallel-size", "4", "--max-num-seqs", "4", "--port", str(port), "--max-model-len", "32768"]
        return L.Server(name, list(eng["vllm"]) + flags, eng["env"], port, LOGS)
    save()


if not RERUN:
    # ==================================================================== CELL 3 — prompts (Flash-Next tokenizer + its own template at xhigh)
    R["sections"]["A0"] = {}
    _t = time.time()
    R["sections"]["A0"]["host"] = host_facts()
    R["sections"]["A0"]["merge"] = merge_ckpt() if MERLIN_OK else {"ok": False, "why": "Merlin inputs missing", "inputs": R["inputs"]}
    R["sections"]["A0"]["host_mem"] = host_mem()
    log("A0 host", json.dumps(R["sections"]["A0"]["host"])[:1200])
    log("A0 merge", json.dumps(R["sections"]["A0"]["merge"])[:800])
    save()
    TOKDIR = TMP / "fn_tok"
    shutil.rmtree(TOKDIR, ignore_errors=True)
    TOKDIR.mkdir()
    # the Merlin checkpoint's tokenizer when the merge is OK; otherwise the Intel (stock fallback) checkpoint's own
    MERLIN_PROMPTS = bool(R["sections"]["A0"]["merge"].get("ok")) and (CKPT / "tokenizer.json").exists()
    _src = CKPT if MERLIN_PROMPTS else INTEL
    if _src is None or not (_src / "tokenizer.json").exists():
        raise FileNotFoundError("no tokenizer: the Merlin merge failed and the Intel fallback checkpoint is not attached")
    for _n in ("tokenizer.json", "tokenizer_config.json", "chat_template.jinja"):
        if (_src / _n).exists():
            shutil.copyfile(_src / _n, TOKDIR / _n)
    from tokenizers import Tokenizer
    from transformers import AutoTokenizer
    TOK = Tokenizer.from_file(str(TOKDIR / "tokenizer.json"))
    _HF = AutoTokenizer.from_pretrained(str(TOKDIR))
    _tpl = ((TOKDIR / "chat_template.jinja").read_text() if (TOKDIR / "chat_template.jinja").exists()
            else json.loads((TOKDIR / "tokenizer_config.json").read_text())["chat_template"])
    _tasks = json.load(open(ARC))
    _ids = sorted(_tasks)


    def _grid(g):
        return "\n".join("".join(str(v) for v in row) for row in g)


    def _task_text(k):
        t = _tasks[k]
        parts = [f"## Task {k}"]
        for i, ex in enumerate(t["train"]):
            parts.append(f"Example {i + 1} input:\n{_grid(ex['input'])}\nExample {i + 1} output:\n{_grid(ex['output'])}")
        for ex in t["test"]:
            parts.append(f"Test input:\n{_grid(ex['input'])}")
        return "\n\n".join(parts)


    _INTRO = "Find the transformation rule of each ARC task below and solve the test inputs.\n\n"
    _PH = "E13_BODY"


    def _render(effort):
        return _HF.apply_chat_template([{"role": "user", "content": _INTRO + _PH}], tokenize=False, add_generation_prompt=True,
                                       enable_thinking=True, reasoning_effort=effort, chat_template=_tpl)


    _RX, _RM = _render("xhigh"), _render("medium")
    assert _RX.count(_PH) == 1
    _head_txt, _tail_txt = _RX.split(_PH)
    _HEAD = TOK.encode(_head_txt, add_special_tokens=False).ids
    _TAIL = TOK.encode(_tail_txt, add_special_tokens=False).ids
    TPL_MSG = [{"role": "user", "content": _INTRO + _task_text(_ids[0])}]
    TPL_IDS = TOK.encode(_HF.apply_chat_template(TPL_MSG, tokenize=False, add_generation_prompt=True, enable_thinking=True,
                                                 reasoning_effort="xhigh", chat_template=_tpl), add_special_tokens=False).ids
    R["prompt_render"] = {"head_text": _head_txt[-600:], "tail_text": _tail_txt, "head_tokens": len(_HEAD), "tail_tokens": len(_TAIL),
                          "xhigh_differs_from_medium": _RX != _RM, "xhigh_sentence": "xhigh" in _head_txt,
                          "template_sha256": hashlib.sha256(_tpl.encode()).hexdigest(),
                          "tokenizer_json_sha256": hashlib.sha256((TOKDIR / "tokenizer.json").read_bytes()).hexdigest()}
    _TASK_IDS = {k: TOK.encode(_task_text(k) + "\n\n", add_special_tokens=False).ids for k in _ids}


    def prompt(band, variant):
        body, i = [], (variant * 7) % len(_ids)
        need = band - len(_HEAD) - len(_TAIL)
        while len(body) < need:
            body += _TASK_IDS[_ids[i % len(_ids)]]
            i += 1
        return _HEAD + body[:need] + _TAIL


    TOK_SHA = "0997f410c57a1f4e53b09e4be8f4a172d90edd9564368fb0847030937229b9f3"   # = the 27B Merlin tokenizer.json
    TPL_SHA = "c3cf9e34abf4f9e36c2d72165aa9c132d3e2a725b6c2586aaa3a8af9d7a81041"   # = the 27B FP8 chat_template.jinja
    R["prompt_render"]["source"] = "merlin" if MERLIN_PROMPTS else "intel_fallback"
    R["prompt_render"]["hashes_ok"] = (R["prompt_render"]["tokenizer_json_sha256"] == TOK_SHA and
                                       R["prompt_render"]["template_sha256"] == TPL_SHA)
    if MERLIN_PROMPTS:                    # the pinned hashes belong to the Merlin checkpoint only (Intel's are recorded)
        assert R["prompt_render"]["hashes_ok"], "Flash-Next tokenizer / template differ from the pinned Merlin checkpoint"
    assert R["prompt_render"]["xhigh_sentence"] and R["prompt_render"]["xhigh_differs_from_medium"], "xhigh render missing"
    BANDS = {"2k": 2048, "8k": 8192, "40k": 40000, "90k": 90000, "116k": 116000}
    NSTREAM = 8
    PROMPTS = {b: [prompt(n, v) for v in range(NSTREAM)] for b, n in BANDS.items()}
    MAX_NEW = {b: MAX_LEN - n - 512 for b, n in BANDS.items()}
    ORACLE_P = [PROMPTS["2k"][0], PROMPTS["2k"][1], PROMPTS["8k"][2]]
    LONG_P = [PROMPTS["40k"][3]]
    TF_P = {"40k": PROMPTS["40k"][5]}
    R["prompts"] = {b: {"n": len(p), "len": len(p[0])} for b, p in PROMPTS.items()}
    log("prompts", json.dumps(R["prompts"]), "| render", json.dumps({k: v for k, v in R["prompt_render"].items() if "text" not in k}))
    save()


if not RERUN:
    # ==================================================================== CELL 4 — the step runner (E23, verbatim)
    HELP = HELP if "HELP" in globals() else {}
    WIN = float(os.environ.get("E23_WIN_SEC") or 90.0)   # 120 s FULL windows
    EST_SCALE = float(os.environ.get("E23_EST_SCALE") or 1.0) if FAKE else 1.0   # local harness only: walk the whole order
    SM_TF = MODE == "SMOKE"                                            # SMOKE teacher-forced: the 40k row only
    ROWS = {}            # oracle greedy rows by key (same weights)
    TF = {}              # teacher-forced rows by key
    NTOK = 128 if MODE == "FULL" else 64
    LIVE = {"rec": None}                 # rev 3c: windows land in the step record before every save (a hard kill keeps them)
    COMPILE_ERR = re.compile(r"ninja: build stopped|Error building extension|error: command '.*(nvcc|g\+\+|gcc|c\+\+)' failed|"
                             r"GLIBCXX_[0-9.]+' not found|unsupported GNU version|fatal error: ")
    OOM_ERR = re.compile(r"OutOfMemoryError|CUDA out of memory|out of memory")
    XID = re.compile(r"NVRM: Xid|\bXid \d+|CUDA error: an illegal memory access|illegal memory access was encountered|"
                     r"unspecified launch failure|CUDA error: misaligned address")       # rev 3e: device faults, not any CUDA error


    def keep_after_error(rec, e):
        """E25 NB1 R2: an exception after the measurements (post-processing) keeps the whole record + postprocess_error /
        postprocess_tb. A clean boot (status None / NOT_RUN / DONE / TF_OOM, correctness CLEAN, quality PASS) keeps its status
        (None / NOT_RUN -> DONE), so its dependent boots still run; any other record -> POSTPROCESS_ERROR (status_before kept).
        R2 audit N1-3: postprocess_ok False; whether the dependents run is decided by core_measurements_complete (core_check)."""
        rec["postprocess_ok"] = False
        rec["postprocess_error"] = f"{type(e).__name__}: {e}"[:800]
        rec["postprocess_tb"] = traceback.format_exc()[-2500:]
        if (rec.get("status") in (None, "NOT_RUN", "DONE", "TF_OOM") and rec.get("correctness") == "CLEAN"
                and rec.get("quality_gate") == "PASS"):
            if rec.get("status") in (None, "NOT_RUN"):
                rec["status"] = "DONE"
        else:
            rec["status_before_postprocess"] = rec.get("status")
            rec["status"] = "POSTPROCESS_ERROR"
        return rec


    def step(sec, name, est_min, fn):
        """One measured step: skipped when the budget cannot hold it, recorded on any exception, never PASS by default."""
        rec = R["sections"].setdefault(sec, {}).setdefault(name, {"status": "NOT_RUN"})
        R["order"].append(f"{sec}/{name}")
        if ABORT["why"]:
            rec.update(status="SKIPPED_ABORT", why=ABORT["why"])
            log("---", sec, name, "SKIPPED_ABORT")
            save()
            return rec
        if left() < est_min * EST_SCALE * 60 + 300:
            rec.update(status="SKIPPED_BUDGET", left_min=round(left() / 60, 1), est_min=est_min)
            log("---", sec, name, "SKIPPED_BUDGET", f"(est {est_min} min, left {left() / 60:.0f} min)")
            save()
            return rec
        LIVE["rec"] = rec
        LIVE["out"] = None                       # E25 NB1 R2: the body's record once it returned (set by watched() / run_boot())
        t = time.time()
        log(">>>", sec, name, f"(est {est_min} min, left {left() / 60:.0f} min)")
        out = None                               # E25 NB1 R2
        try:
            out = fn() or {}
            rec.update(out)
            if rec.get("status") in (None, "NOT_RUN"):
                rec["status"] = "DONE"
        except Exception as e:
            part = out if isinstance(out, dict) and out else LIVE.get("out")   # E25 NB1 R2: never discard what the body produced
            if isinstance(part, dict) and part:                               # E25 NB1 R2
                rec.update(part)                                              # E25 NB1 R2
                keep_after_error(rec, e)                                      # E25 NB1 R2: clean -> DONE + postprocess_error
            else:                                                             # E25 NB1 R2
                rec.update(status="ERROR", error=f"{type(e).__name__}: {e}"[:800], tb=traceback.format_exc()[-2500:])
        rec["sec"] = round(time.time() - t, 1)
        LIVE["rec"] = None
        LIVE["out"] = None                       # E25 NB1 R2
        if ABORT["why"] and rec["status"] in ("DONE", "SERVER_DIED", "LAUNCH_FAILED", "BODY_ERROR"):
            rec["status"] = "PARTIAL_HARD_STOP"
        log("<<<", sec, name, rec.get("status"), f"{rec['sec']:.0f}s")
        save()
        return rec


    def with_servers(servers, timeout, body):
        """Start, wait ready, record facts + memory, run body(servers), always kill; then the GPU-release gate on these
        servers' GPUs only; abort the lab if they stay held."""
        out = {"servers": {}}
        timeout = max(60, min(timeout, left() - 120))
        try:
            for s in servers:
                s.start()
            for s in servers:
                ok, why = s.wait_ready(timeout)
                out["servers"][s.name] = {"ready": ok, "why": why, **s.facts(), "argv_tail": s.argv[-44:], "gpus": s.gpus,
                                          "help_check": HELP.get(s.name)}
                if not ok:
                    out["status"] = "LAUNCH_FAILED"
                    out["servers"][s.name]["log_tail"] = s.log()[-4000:]
                    _xl = [l for l in (s.log() or "").splitlines() if XID.search(l)][:8]   # rev 3e/3f: start-up / capture faults
                    out["servers"][s.name].update(xid=bool(_xl), xid_lines=_xl)
                    return out
            mem0 = L.gpu_mem()
            for s in servers:
                out["servers"][s.name].update(gpu_mem_after_ready=mem0, host_rss_mb=s.rss_mb())
            try:                             # rev 3: an exception in the body keeps everything measured so far
                out.update(body(servers) or {})
            except Exception as e:
                out.update(status="BODY_ERROR", body_error=f"{type(e).__name__}: {e}"[:800], body_tb=traceback.format_exc()[-2000:])
            for s in servers:
                out["servers"][s.name].update(s.facts(), gpu_mem_end=L.gpu_mem(), host_rss_mb_end=s.rss_mb(),
                                              alive_after_body=s.alive(), rc=None if s.alive() else s.proc.returncode,
                                              xid_lines=[l for l in (s.log() or "").splitlines() if XID.search(l)][:8])
                out["servers"][s.name]["xid"] = bool(out["servers"][s.name]["xid_lines"])
                if not s.alive():
                    out["status"] = "SERVER_DIED"
                    out["servers"][s.name]["log_tail"] = s.log()[-4000:]
            return out
        finally:
            for s in servers:
                s.kill()
            gpus = ",".join(sorted({g for s in servers for g in s.gpus.split(",")}))
            rel = L.wait_gpu_release(180, fake=bool(FAKE), gpus=gpus)
            if rel is False:                 # rev 3c: one more kill + 300 s before the lab aborts
                for s in servers:
                    s.kill()
                rel = L.wait_gpu_release(300, fake=bool(FAKE), gpus=gpus)
            if rel is None and NVSMI_OK:     # nvidia-smi worked at start: a failure now is not "released"
                rel = False
            out["gpu_released"] = rel
            if rel is False:
                ABORT["why"] = f"GPUs {gpus} still held after {[s.name for s in servers]}"
                out["status"] = "FAIL_GPU_RELEASE"


    def oracle(port, key=None, refs=()):
        """Greedy rows (2k, 2k, 8k) + one 40k row; saved under `key` (a target-only oracle) or compared with ROWS[ref]."""
        rows = L.greedy(port, ORACLE_P + LONG_P, n_tok=NTOK, timeout=max(120, min(900, left() / 6)))
        clean = all(not r.get("error") and r.get("tokens") and not L.degenerate(r.get("text")) for r in rows)
        if key and clean:            # rev 3d: an errored / empty / garbage reference is never stored (consumers: NO_ORACLE)
            ROWS[key] = rows
        elif key:
            R["errors"].append(f"oracle {key}: reference not stored (error / empty / garbage row)")
        res = {"garbage": [L.degenerate(r["text"]) for r in rows], "errors": [r["error"] for r in rows],
               "text_head": [r["text"][:120] for r in rows]}
        if not FAKE:                 # rev 3h: chat-path render vs the production xhigh render (recorded per arm)
            res["template_probe"] = L.template_probe(port, TPL_MSG, TPL_IDS)
        for ref in refs:
            res["vs_" + ref] = L.compare(ROWS.get(ref), rows) if ROWS.get(ref) else {"status": "INCONCLUSIVE_NO_ORACLE"}
        return res


    def tforced(port, key=None, ref=None):
        """Teacher-forced 40k / 90k prompt logprobs (last 256 positions); saved under `key` or compared with TF[ref].
        rev 3c: on stock vLLM only on its own short launch (prompt logprobs = chunk x 248k-vocab logits: OOM at 0.90)."""
        rows = {b: L.teacher_forced(port, ids) for b, ids in TF_P.items() if not (SM_TF and b != "40k")}
        if key and L.tf_complete(rows):                                 # rev 3e: complete references only
            TF[key] = rows
        elif key:
            R["errors"].append(f"teacher-forced {key}: reference not stored (incomplete band)")
        if ref:
            return {b: L.compare_tf((TF.get(ref) or {}).get(b), rows[b]) for b in rows}
        return {b: {"n": (rows[b] or {}).get("n"), "error": (rows[b] or {}).get("error")} for b in rows}


    def levels(port, band, lv, server=None, **kw):
        """rev 3c: the guard includes admission (prefill) time; a band stops once KV-bound (the fit is recorded); a dead
        server stops the band; every window is written into the live step record before save()."""
        out, fit = {}, None
        for n in lv:
            k = f"{band}@{n}"
            need = WIN + 90 + min(3600, n * BANDS[band] / 1500)
            if ABORT["why"] or left() < need + 120:
                out[k] = {"status": "SKIPPED_BUDGET", "need_sec": round(need)}
            elif fit is not None:
                out[k] = {"status": "SKIPPED_KV_BOUND", "streams_fit": fit}
            elif server is not None and not server.alive():
                out[k] = {"status": "SKIPPED_SERVER_DEAD"}
            else:
                try:                         # rev 3: one failing level never loses the others
                    out[k] = L.steady(port, PROMPTS[band], n, secs=WIN, max_new=MAX_NEW[band], **kw)
                except Exception as e:
                    out[k] = {"status": "ERROR", "error": f"{type(e).__name__}: {e}"[:300]}
                rm = out[k].get("running_max")
                if out[k].get("status") == "CAPACITY_LIMITED" or (rm is not None and 0 < rm < n and
                                                                  str(out[k].get("status")).startswith("INCONCLUSIVE")):
                    fit = rm
            if LIVE["rec"] is not None:
                LIVE["rec"].setdefault("live_windows", {})[k] = out[k]
            save()
        return out
    save()


if not RERUN:
    # ==================================================================== CELL 5 — the arms
    LADDER = [1, 2, 4, 5]                    # 40k: 8 streams would need 8 x (10 + 7) blocks of 4096 > 149 FP8 blocks (preempts)
    TEMP = 0.6                               # production sampling (Merlin's --override-generation-config is T 1.0)
    E23_TF_SCALE = {"tp4_vs_tp1_layout": 0.0772, "nvfp4_vs_bf16_kv": 0.3787}   # E23 SMOKE rev3g mean |d logprob|, for scale
    PREFILL = {"tok_s": 700.0, "measured": False}
    OOM_STEP = 268435456                     # Merlin's note: lower KV_BYTES in 0.25 GiB steps if the boot OOMs
    # Pre-run capacity (Merlin's rule: blocks per request = ceil(L / 4096) + 7; FP8 149 usable blocks, BF16 ~78)
    R["capacity_plan"] = {
        "fp8": {"pool_blocks": 149, "40k@5": 5 * (math.ceil(130560 / 4096) + 7), "8k@8": 8 * (math.ceil(32000 / 4096) + 7),
                "90k@4": 4 * (math.ceil(131072 / 4096) + 7), "116k@3": 3 * (math.ceil(131072 / 4096) + 7),
                "116k@4": 4 * (math.ceil(131072 / 4096) + 7),
                "note": "blocks if every stream grew to max length; the ladder windows are 90 s, so real use is far lower; "
                        "90k@4 and 116k@4 are capacity-limit probes"},
        "bf16": {"pool_blocks": 78, "40k@3": 3 * (math.ceil(130560 / 4096) + 7)},
        "long_rows": "1 natural xhigh ARC row (max 120,000 new) + 1 forced 60,000-token row, temperature 0.6, run CONCURRENTLY "
                     "(concurrency 2): not a single-stream latency number",
    }
    R["correctness_meaning"] = ("Both Merlin boots run MTP K3: CLEAN = BF16_MTP3 vs FP8_MTP3 parity plus probes / sampled / greedy "
                                "evidence; it is NOT target-only (MTP off) correctness. A production GO needs an MTP-off oracle and "
                                "a forced-rejection test.")
    CLEAN = ("EXACT", "NEAR_TIE")


    def _windows(o):
        """Every steady window of a step record (levels dicts + steady_multi replicas)."""
        out = []
        for v in (o.get("steady") or {}).values():
            if isinstance(v, dict):
                out.append(v)
        for k in ("40k", "90k"):
            for r in ((o.get(k) or {}).get("replicas") or []) if isinstance(o.get(k), dict) else []:
                if isinstance(r, dict):
                    out.append(r)
        return out


    def oracle_gate(o, need=(), extra=()):
        """None when clean; otherwise the NO_GO / INCONCLUSIVE status. `need` = refs that must compare clean; `extra` =
        further comparison dicts (replica greedy, 90k greedy) that must compare clean too. rev 3e (audits B-O1, C-F2):
        garbage under load in any window and failed arithmetic probes (real servers; the fake has no chat) are NO_GO too."""
        orc = o.get("oracle") or {}
        if any(orc.get("errors") or []):
            return "NO_GO_ORACLE_REQUEST_ERROR"
        if any(orc.get("garbage") or []):
            return "NO_GO_ORACLE_GARBAGE"
        if any(w.get("status") == "FAIL_GARBAGE_UNDER_LOAD" for w in _windows(o)):
            return "NO_GO_GARBAGE_UNDER_LOAD"
        if not FAKE and isinstance(o.get("probes"), dict) and o["probes"].get("ok") is False:
            return "NO_GO_SHORT_PROBE"
        sts = [(orc.get("vs_" + k) or {}).get("status") for k in need] + [(x or {}).get("status") for x in extra]
        if any(s == "FAIL_HIGH_MARGIN" for s in sts):
            return "NO_GO_ORACLE"
        if any(s not in CLEAN for s in sts):
            return "INCONCLUSIVE_NO_ORACLE" if any(s in (None, "INCONCLUSIVE_NO_ORACLE") for s in sts) else "INCONCLUSIVE_ORACLE"
        return None


    def gated(o, need=(), extra=()):
        g = oracle_gate(o, need, extra)
        o["correctness"] = g or "CLEAN"
        if g and o.get("status") in (None, "DONE"):
            o["status"] = g
        return o




    def _finite(x):
        return isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x)


    _compare_e23, _compare_tf_e23 = L.compare, L.compare_tf


    def _compare_rc2(ref, cand):
        """Final audit H2: a non-finite margin on either side makes the comparison INCONCLUSIVE before any token logic
        (E23's compare read a NaN reference margin as NEAR_TIE)."""
        for rows in (ref or [], cand or []):
            for r in rows:
                if any(m is not None and not _finite(m) for m in (r.get("margins") or [])):
                    return {"status": "INCONCLUSIVE_NONFINITE"}
        return _compare_e23(ref, cand)


    def _compare_tf_rc2(ref, cand):
        """Final audit H2: a non-finite teacher-forced logprob is never MEASURED."""
        for side in (ref, cand):
            for p in ((side or {}).get("positions") or []):
                if p and p[0] is not None and not _finite(p[0]):
                    return {"status": "INCONCLUSIVE_NONFINITE"}
        return _compare_tf_e23(ref, cand)


    L.compare, L.compare_tf = _compare_rc2, _compare_tf_rc2


    def short_gate_failed(o):
        """Final audit H1: a failed probe (real servers; the fake has no chat) or a failed / garbage sampled request stops
        the boot's body at once; gated() then gives the NO_GO verdict."""
        p, s = o.get("probes") or {}, o.get("sampled") or {}
        return (p.get("ok") is not True and not FAKE) or s.get("ok") is not True or bool(s.get("garbage"))


    def oracle_ok(orc):
        return bool(orc) and orc.get("complete") is True and not any(orc.get("errors") or []) and not any(orc.get("garbage") or [])


    def _windows(o):
        """Every load window of a record: the ladder AND the long census (audit: census_long was not gated)."""
        out = []
        for key in ("steady", "census_long"):
            for v in (o.get(key) or {}).values():
                if isinstance(v, dict):
                    out.append(v)
        return out


    def evidence_gate(o, expected_rows, require_sampled=True):
        """Fail-closed evidence (three pre-GPU audits): probes, the sampled path and a COMPLETE oracle are mandatory;
        a missing piece is never CLEAN. expected_rows None = no oracle in this arm (diagnostic arms)."""
        pr = o.get("probes")
        if not isinstance(pr, dict):
            return "INCONCLUSIVE_PROBES_MISSING"
        if pr.get("ok") is not True and not FAKE:          # the fake server has no chat endpoint (E23 rule)
            return "NO_GO_SHORT_PROBE"
        if require_sampled:
            sm = o.get("sampled")
            if not isinstance(sm, dict):
                return "INCONCLUSIVE_NO_SAMPLED_TEST"
            if sm.get("ok") is not True or sm.get("garbage"):
                return "NO_GO_SAMPLED_PATH"
        if expected_rows is None:
            return None
        orc = o.get("oracle")
        if not isinstance(orc, dict):
            return "INCONCLUSIVE_NO_ORACLE"
        if any(orc.get("errors") or []):
            return "NO_GO_ORACLE_REQUEST_ERROR"
        if any(orc.get("garbage") or []):
            return "NO_GO_ORACLE_GARBAGE"
        if orc.get("row_count") != expected_rows or orc.get("complete") is not True:
            return "INCONCLUSIVE_ORACLE_INCOMPLETE"
        return None


    _gated_e23 = gated


    def gated(o, need=(), extra=(), expected_rows=4, require_sampled=True):
        g = evidence_gate(o, expected_rows, require_sampled)
        if g:
            o["correctness"] = g
            if o.get("status") in (None, "DONE"):
                o["status"] = g
            return o
        return _gated_e23(o, need, extra)


    def oracle(port, key=None, refs=(), prompts=None):
        """E23's oracle plus completeness: every expected row present, no error, exactly NTOK tokens (greedy rows run with
        ignore_eos, so a short row is a defect); a reference is stored only when complete and garbage-free."""
        prompts = list(prompts) if prompts is not None else ORACLE_P + LONG_P
        rows = L.greedy(port, prompts, n_tok=NTOK, timeout=max(120, min(900, left() / 6)))
        garbage = [L.degenerate(r.get("text")) for r in rows]
        complete = len(rows) == len(prompts) and all(not r.get("error") and len(r.get("tokens") or []) == NTOK for r in rows)
        if key and complete and not any(garbage):
            ROWS[key] = rows
        elif key:
            R["errors"].append(f"oracle {key}: reference not stored (incomplete / error / garbage)")
        res = {"garbage": garbage, "errors": [r.get("error") for r in rows], "text_head": [(r.get("text") or "")[:120] for r in rows],
               "row_count": len(rows), "expected_rows": len(prompts), "tokens": [len(r.get("tokens") or []) for r in rows],
               "complete": complete}
        if not FAKE:
            res["template_probe"] = L.template_probe(port, TPL_MSG, TPL_IDS)
        for ref in refs:
            res["vs_" + ref] = L.compare(ROWS.get(ref), rows) if ROWS.get(ref) else {"status": "INCONCLUSIVE_NO_ORACLE"}
        return res


    def kv_census(s):
        log_t = s.log() or ""
        lines = log_t.splitlines()
        kv = re.findall(r"GPU KV cache size: ([\d,]+) tokens", log_t)
        conc = re.findall(r"Maximum concurrency for ([\d,]+) tokens per request: ([\d.]+)x", log_t)
        pick = lambda rx, n=24: [l[:240] for l in lines if re.search(rx, l, re.I)][:n]
        return {"kv_tokens": [int(x.replace(",", "")) for x in kv][:2], "max_concurrency": conc[:2],
                "scale_lines": pick(r"K/V scale|kv scale|scaling factor|DEFAULT 1\.0|static K/V"),
                "engine_lines": pick(r"WNA16 MoE backend|MarlinExperts|PLE offload|engram|cudagraph_mode|CUDAGraphMode|PIECEWISE"),
                "startup_lines": pick(r"Loading weights took|Model loading took|torch\.compile takes|torch\.compile took|"
                                      r"Graph capturing finished|init engine|PLE.*ready|Available KV cache memory"),
                "oom_lines": [l[:240] for l in lines if OOM_ERR.search(l)][:6], "host_mem": host_mem()}


    def sampled_check(s):
        """RC1 died at its first sampled request (FlashInfer sampling JIT: ld cannot find -lcuda): one short sampled request
        right after ready, then the engine must still be alive."""
        g = L.Stream(s.port, PROMPTS["2k"][1], 64, temperature=TEMP, seed=5)
        g.start()
        g.join(900)
        if g.is_alive():
            g.stop()
            g.join(10)
        r = g.row()
        return {"tokens": len(r["tokens"]), "error": r["error"], "finish": r["finish_reason"], "alive_after": s.alive(),
                "garbage": L.degenerate(r["text"]), "ok": len(r["tokens"]) == 64 and not r["error"] and s.alive()}


    def prefill_probe(port):
        """Time to first token of one cold 40k prompt (1 new token): the measured prefill rate the ladder admission uses."""
        ids = PROMPTS["40k"][7]
        g = L.Stream(port, ids, 1, temperature=0.0)
        g.start()
        g.join(1800)
        if g.is_alive():
            g.stop()
            g.join(10)
        sec = (g.t_first or g.t_end or time.perf_counter()) - (g.t_start or time.perf_counter())
        ok = not g.err and g.t_first is not None
        if ok:
            PREFILL.update(tok_s=round(len(ids) / max(1e-3, sec), 1), measured=True)
        return {"prompt": len(ids), "ttft_sec": round(sec, 1), "tok_s": round(len(ids) / max(1e-3, sec), 1), "error": g.err, "ok": ok}


    def window_garbage(ids, win=2000, min_len=200):
        """Final audit H3: the first garbage 2,000-token window of a row (None if every window is clean). A whole-text check
        would read 100k tokens of healthy reasoning as LOW_VARIETY (unique words < 8 %), so windows are checked one by one."""
        for i in range(0, len(ids), win):
            seg = ids[i:i + win]
            if len(seg) < min_len:
                break
            v = L.degenerate(TOK.decode(seg))
            if v:
                return {"start_token": i, "verdict": v}
        return None


    def long_quality(name, r):
        if not isinstance(r, dict):
            return "MISSING_LONG"
        if r.get("error"):
            return "FAIL_LONG_REQUEST"
        if r.get("window_garbage"):
            return "FAIL_LONG_GARBAGE"
        if name == "forced60k" and not r.get("reached_60k"):
            return "INCOMPLETE_LONG"
        if name == "natural" and r.get("cut_by_cap"):
            return "INCOMPLETE_LONG"
        return "PASS_LONG"


    def long_gate(o):
        """None when the record has no long rows or both rows PASS_LONG; otherwise the verdict for the top-level status.
        Priority: request error > natural garbage > forced garbage (synthetic past its first EOS) > incomplete."""
        lo = o.get("long")
        if not isinstance(lo, dict):
            return None
        q = {n: long_quality(n, lo.get(n)) for n in ("natural", "forced60k")}
        lo["long_quality"] = q
        if "MISSING_LONG" in q.values():
            return "INCONCLUSIVE_LONG_MISSING"
        if "FAIL_LONG_REQUEST" in q.values():
            return "NO_GO_LONG_REQUEST_ERROR"
        if q["natural"] == "FAIL_LONG_GARBAGE":
            return "NO_GO_LONG_GARBAGE"
        if q["forced60k"] == "FAIL_LONG_GARBAGE":
            return "NO_GO_FORCED60K_GARBAGE"
        if "INCOMPLETE_LONG" in q.values():
            return "INCONCLUSIVE_LONG_INCOMPLETE"
        return None


    def long_rows(port, secs_cap=3000):
        """One natural xhigh ARC request (its own stop, up to 120,000 new tokens) and one forced 60,000-token row
        (ignore_eos: 'synthetic' past its first EOS), CONCURRENTLY (concurrency 2). Full text in traces/ + requests.jsonl.
        A row cut by the time cap is incomplete, not a correctness failure."""
        cap = max(60, min(secs_cap, left() - 900))
        jobs = {"natural": L.Stream(port, TPL_IDS, min(120000, MAX_LEN - len(TPL_IDS) - 512), temperature=TEMP, seed=11,
                                    ignore_eos=False),
                "forced60k": L.Stream(port, PROMPTS["8k"][0], 60000, temperature=TEMP, seed=12, ignore_eos=True)}
        t = time.time()
        for g in jobs.values():
            g.start()
        for g in jobs.values():
            g.join(max(1, cap - (time.time() - t)))
        for g in jobs.values():
            if g.is_alive():
                g.stop()
                g.join(10)
        out = {"concurrency": 2, "cap_sec": round(cap)}
        for name, g in jobs.items():
            row = g.row()
            (TRACES / f"long_{port}_{name}.txt").write_text(row["text"])
            ids = row["tokens"]
            n_tok = len(ids)
            sec = (g.t_end or time.perf_counter()) - (g.t_start or time.perf_counter())
            sl = {}
            for k, end in (("to_8k", 8000), ("to_32k", 32000), ("to_60k", 60000), ("to_100k", 100000)):
                sl[k] = L.degenerate(TOK.decode(ids[end - 2000:end])) if n_tok >= end else "NOT_REACHED"
            out[name] = {"tokens": n_tok, "sec": round(sec, 1), "tok_s": round(n_tok / max(1e-6, sec), 1), "error": row["error"],
                         "finish": row["finish_reason"], "garbage": sl, "window_garbage": window_garbage(ids),
                         "think_closed": "</think>" in row["text"], "cut_by_cap": row["finish_reason"] is None,
                         "tail": row["text"][-400:]}
        out["forced60k"]["reached_60k"] = out["forced60k"]["tokens"] >= 60000
        out["forced60k"]["label"] = "synthetic past the first EOS (ignore_eos)"
        try:
            m = {k: v for k, v in L.prom(port).items() if k.startswith(("vllm:spec_decode", "vllm:num_preemptions", "vllm:kv_cache_usage"))}
        except Exception as e:
            m = {"error": repr(e)[:200]}
        acc, drf = m.get(L.ACC), m.get(L.DRF)
        out["metrics_end"] = m
        out["mtp_accept_per_draft"] = round(acc / drf, 3) if acc and drf else None
        return out


    def tf_last(s, key=None, ref=None, aa=False):
        """Teacher-forced 40k LAST in a boot (chunk x 248k-vocab prompt logits can OOM the last PP rank); free memory first.
        How a server death here is classified is decided from its log in merlin_boot (TF_OOM vs TF_SERVER_DIED)."""
        o = {"gpu_before": L.gpu_mem()}
        if key:
            o["ref"] = tforced(s.port, key=key)
            if aa and s.alive():
                o["aa"] = tforced(s.port, ref=key)              # A/A: the same boot, the same prompt (the noise floor)
                TF["aa"] = o["aa"]
        if ref:
            o["vs_" + ref] = tforced(s.port, ref=ref)
            o["aa_" + ref] = TF.get("aa")
            o["e23_scale"] = E23_TF_SCALE
        o["alive_after"] = s.alive()
        return o


    def merlin_boot(name, kv, port, timeout, body, need=(), expected_rows=4, require_sampled=True):
        """Boot gate (ok must be True), one Merlin boot, cleanup of the /dev/shm entries this boot created; a boot OOM
        retries once 0.25 GiB lower. A server death during TF is TF_OOM only with an OOM line and no device fault."""
        kvb = NB1_KV.get(name) or (KV_FP8 if kv == "fp8" else KV_BF16)   # E25 NB1: the B3 pin step
        tries = []
        while True:
            gate = boot_gate()
            if gate["ok"] is not True:
                return {"status": "GPU_NOT_EMPTY", "boot_gate": gate, "tries": tries}
            shm0 = shm_names()
            o = with_servers([merlin_fn_server(name, kv, port, kvb)], timeout, body)
            o.update(kv_bytes=kvb, boot_gate=gate, shm_cleanup=shm_cleanup(shm0))
            srv = (o.get("servers") or {}).get(name) or {}
            oom = o.get("status") == "LAUNCH_FAILED" and bool(OOM_ERR.search(srv.get("log_tail") or ""))
            tries.append({"kv_bytes": kvb, "status": o.get("status"), "oom": oom})
            if not oom or len(tries) > 1 or left() < timeout + 900:
                break
            kvb -= OOM_STEP
            log("boot OOM:", name, "retry with KV_BYTES", kvb)
        o["tries"] = tries
        if o.get("tf_died") and o.get("status") == "SERVER_DIED":
            srv = (o.get("servers") or {}).get(name) or {}
            if OOM_ERR.search(srv.get("log_tail") or "") and not srv.get("xid"):
                o["status"] = "TF_OOM"
                o["status_note"] = "the server died of OOM in the teacher-forced call (run last); everything before it is valid"
            else:
                o["status"] = "TF_SERVER_DIED"
                o["status_note"] = "the server died in the teacher-forced call without an OOM line (or with a device fault)"
        g = gated(o, need=need, expected_rows=expected_rows, require_sampled=require_sampled)
        if g.get("status") == "TF_OOM" and g.get("correctness") != "CLEAN":
            g["status"] = g["correctness"]
        lg = long_gate(g)                                  # final audit H3: the long rows have their own verdict
        g["long_verdict"] = lg or ("PASS_LONG" if isinstance(g.get("long"), dict) else None)
        if lg and g.get("status") in ("DONE", "TF_OOM"):
            g["status"] = lg
        return g


    def arm_bf16():
        def body(ss):
            s = ss[0]
            p = s.port
            o = {"census": kv_census(s), "probes": L.chat_probes(p), "sampled": sampled_check(s)}
            if short_gate_failed(o):
                o.update(early_stop="SHORT_CORRECTNESS_GATE_FAILED", census_end=kv_census(s))
                return o
            o["prefill"] = prefill_probe(p)
            o["oracle"] = oracle(p, key="bf16")
            o["census_end"] = kv_census(s)
            if not oracle_ok(o["oracle"]):
                o["early_stop"] = "ORACLE_INCOMPLETE"          # no reference: the TF A/A would measure nothing usable
                return o
            o["tf"] = tf_last(s, key="bf16", aa=True)
            o["tf_died"] = not o["tf"]["alive_after"]
            return o
        ok, why = sha_gate(min(1500, left() - 900))
        R["setup"]["sha_gate"] = {"ok": ok, "why": why}
        if not ok:
            return {"status": "SKIPPED_SHA_GATE", "why": why}
        return merlin_boot("merlin_bf16", "bf16", 8000, 45 * 60, body)


    def fp8_gate(o):
        vs = (o["oracle"].get("vs_bf16") or {}).get("status")
        if (o.get("sampled") or {}).get("ok") is not True:
            return "FAIL_SAMPLED"
        if (o.get("probes") or {}).get("ok") is not True and not FAKE:
            return "FAIL_PROBES"
        if any(o["oracle"].get("errors") or []) or any(o["oracle"].get("garbage") or []) or vs == "FAIL_HIGH_MARGIN":
            return "FAIL"
        if o["oracle"].get("complete") is True and vs in CLEAN:
            return "PASS"
        return "INCONCLUSIVE"


    def arm_fp8():
        def body(ss):
            s = ss[0]
            p = s.port
            o = {"census": kv_census(s), "probes": L.chat_probes(p), "sampled": sampled_check(s)}
            if short_gate_failed(o):
                o.update(early_stop="SHORT_CORRECTNESS_GATE_FAILED", census_end=kv_census(s),
                         fp8_gate="FAIL_SAMPLED" if (o["sampled"] or {}).get("ok") is not True else "FAIL_PROBES")
                return o
            if not PREFILL["measured"]:
                o["prefill"] = prefill_probe(p)
            o["oracle"] = oracle(p, refs=("bf16",))
            o["fp8_gate"] = fp8_gate(o)
            if o["fp8_gate"] == "PASS":                      # load tests only on a PASS (audits: INCONCLUSIVE never runs them)
                kw = {"server": s, "temperature": TEMP, "prefill_tok_s": PREFILL["tok_s"]}
                o["steady"] = levels(p, "40k", LADDER, **kw)
                o["steady"].update(levels(p, "8k", [8], **kw))
                o["census_long"] = {**levels(p, "90k", [3, 4], **kw), **levels(p, "116k", [3, 4], **kw)}
                o["long"] = long_rows(p)
            else:
                o["load_tests_skipped"] = f"FP8 comparison gate: {o['fp8_gate']}"
                o["status"] = "NO_GO_FP8_KV" if o["fp8_gate"].startswith("FAIL") else "INCONCLUSIVE_FP8_KV"
            o["census_end"] = kv_census(s)
            if o["fp8_gate"] == "PASS" or os.environ.get("RC2_TF_ON_FP8_FAIL") == "1":   # default: fail fast
                o["tf"] = tf_last(s, ref="bf16")
                o["tf_died"] = not o["tf"]["alive_after"]
            return o
        return merlin_boot("merlin_fp8", "fp8", 8001, 40 * 60, body, need=("bf16",))


    def arm_bf16_load():
        """Only when FP8 fails: the ladder, the census and the long rows on BF16 KV (seqs 3). DIAGNOSTIC_ONLY: this arm
        has no oracle of its own (the A1 boot is the BF16 reference)."""
        def body(ss):
            s = ss[0]
            p = s.port
            o = {"census": kv_census(s), "probes": L.chat_probes(p), "sampled": sampled_check(s)}
            if short_gate_failed(o):
                o["early_stop"] = "SHORT_CORRECTNESS_GATE_FAILED"
            else:
                kw = {"server": s, "temperature": TEMP, "prefill_tok_s": PREFILL["tok_s"]}
                o["steady"] = levels(p, "40k", [1, 2, 3], **kw)
                o["census_long"] = levels(p, "116k", [1, 2], **kw)
                o["long"] = long_rows(p)
            o["census_end"] = kv_census(s)
            o["certification"] = "DIAGNOSTIC_ONLY"
            return o
        return merlin_boot("merlin_bf16_load", "bf16", 8002, 30 * 60, body, expected_rows=None)


    def arm_stock():
        """Fallback when Merlin cannot serve: stock vLLM 0.32 + Intel W4A16 (RC1's correct engine), -lcuda shim, FP8 KV."""
        if INTEL is None or WHEELHOUSE is None:
            return {"status": "FALLBACK_UNAVAILABLE", "why": f"intel={INTEL} wheelhouse={WHEELHOUSE}"}

        def body(ss):
            s = ss[0]
            p = s.port
            o = {"census": kv_census(s), "probes": L.chat_probes(p), "sampled": sampled_check(s)}
            if short_gate_failed(o):
                o["early_stop"] = "SHORT_CORRECTNESS_GATE_FAILED"
                return o
            o["oracle"] = oracle(p, key="stock", prompts=ORACLE_P)          # 2k / 2k / 8k (32k max length: no 40k row)
            if oracle_ok(o["oracle"]):
                o["steady"] = levels(p, "8k", [1, 2, 3], server=s, temperature=TEMP)
            return o
        gate = boot_gate()
        if gate["ok"] is not True:
            return {"status": "GPU_NOT_EMPTY", "boot_gate": gate}
        shm0 = shm_names()
        o = gated(with_servers([stock_fn_server("stock_fn", 8003)], 40 * 60, body), expected_rows=len(ORACLE_P))
        o.update(boot_gate=gate, shm_cleanup=shm_cleanup(shm0))
        return o


    save()


if not RERUN:
    # ==================================================================== CELL 6 — E25 NB1: measurement tools (NB1 R2 verbatim; E25 NB4S dropped the unused capacity / prefix / routing / PP2-trace functions: commit_mode, commit_ab, commit_counter_delta, pool_blocks_from_usage, reset_cache, _hits, alloc_sequence, reset_succeeded, fit_alloc, kv_accounting, n_fit, admission_test, residency_bound, residency_capacity, _f_valid, resolve_F, f_from_log, residency_probes, block_layout, nb1_complete, nb1_tf_req, lp_compare, fp8_self_check, nb1_ladder, _prefix_counts, _reuse, prefix_tests, _merge, _clip, _inter, microbatch_costs, pp2_trace, merge_routing, pp2_profile)
    import gzip
    import statistics
    from collections import Counter
    NB1 = R.setdefault("nb1", {})
    SCORECARD = OUT / "lever_scorecard.json"
    TF_RAW = OUT / "tf_raw"
    TF_RAW.mkdir(exist_ok=True)
    HOSTMEM = OUT / "hostmem"
    HOSTMEM.mkdir(exist_ok=True)
    BLOCK = 4096
    PIN_STEPS_GIB = (1.0, 0.75, 0.5)             # B3 pin ladder (addendum 5): the largest step predicted safe first, then down
    PIN_FREE_MIN_MIB = 512                       # a step must leave >= 0.5 GiB free per rank after warm-up + a 90k prefill
    KV_STEP = 512 << 20                          # the smallest step (+0.5 GiB per card)
    RAM_NEED_MIB = (69 + 4) * 1024               # Merlin's ~69 GiB resident floor + 4 GiB margin, on its own rule
    BOOT_READY_SEC = 30 * 60                     # readiness gate per boot
    SEQS_HI = 16
    CAPTURE_HI = [1, 2, 3, 4, 6, 8, 12, 16, 24, 32, 40, 48, 64]   # Merlin registry.capture_sizes_for(16, K=3): seqs x (1 + K)
    COMPILE_HI = json.dumps({"cudagraph_mode": "FULL_AND_PIECEWISE", "cudagraph_capture_sizes": CAPTURE_HI})
    PROF_DIR = TMP / "nb1_profile"
    PROFILER_CFG = json.dumps({"profiler": "torch", "torch_profiler_dir": str(PROF_DIR), "torch_profiler_with_stack": False,
                               "ignore_frontend": True})      # idle unless /start_profile (annotations only while running)
    EXT_FLAG = ["--worker-extension-cls", "nb1_worker_ext.NB1WorkerExt"]
    DIAG_ENV = {"VLLM_SERVER_DEV_MODE": "1"}     # /collective_rpc (read-only extension) + /reset_prefix_cache; 127.0.0.1 only
    NCCL_DIAG = {"NCCL_DEBUG": "INFO", "NCCL_DEBUG_SUBSYS": "INIT,NET"}   # B1 only: the real NCCL transport per group
    COMMIT_GRAPH_ENV = {"VLLM_RECOVERSSM_COMMIT_GRAPH": "graph"}         # B2 boot: commit graphs captured; flipped to eager at once
    RC2_FP8 = json.loads(r"""{"argv_tail": ["127.0.0.1", "--port", "8001", "--tensor-parallel-size", "2", "--pipeline-parallel-size", "2", "--enable-expert-parallel", "--disable-custom-all-reduce", "--speculative-config", "{\"method\":\"mtp\",\"num_speculative_tokens\":3,\"draft_sample_method\":\"probabilistic\"}", "--max-model-len", "262144", "--max-num-seqs", "8", "--max-num-batched-tokens", "1024", "--gpu-memory-utilization", "0.96", "--kv-cache-memory-bytes", "2479838700", "--kv-cache-dtype", "fp8_e4m3", "--limit-mm-per-prompt", "{\"image\":42,\"video\":0}", "--mm-processor-cache-gb", "0", "--mm-processor-kwargs", "{\"size\":{\"longest_edge\":8388608,\"shortest_edge\":65536}}", "--compilation-config", "{\"cudagraph_mode\":\"FULL_AND_PIECEWISE\",\"cudagraph_capture_sizes\":[1,2,3,4,6,8,12,16,24,32]}", "--enable-prefix-caching", "--mamba-cache-mode", "align", "--enable-prompt-tokens-details", "--no-enable-flashinfer-autotune", "--enable-auto-tool-choice", "--tool-call-parser", "qwen3_coder", "--reasoning-parser", "qwen3", "--override-generation-config", "{\"temperature\":1.0,\"top_p\":0.95,\"top_k\":20,\"min_p\":0.0,\"presence_penalty\":0.0,\"repetition_penalty\":1.0}", "--default-chat-template-kwargs", "{\"enable_thinking\": true, \"reasoning_effort\": \"medium\"}", "--shutdown-timeout", "60", "--block-size", "4096", "--use-replayssm", "--prefix-match-unit", "64", "--served-model-name", "q27", "--max-model-len", "131072", "--port", "8001", "--default-chat-template-kwargs", "{\"enable_thinking\": true, \"reasoning_effort\": \"xhigh\"}"], "env": {"KV_BYTES": "2479838700", "NCCL_P2P_DISABLE": "1", "NCCL_VERSION": "2.25.1-1", "P2P": "off", "SCALES": "/tmp/fn_merlin/qsa_kv_scales_262k.json", "VLLM_CACHE_ROOT": "/tmp/merlin-cache", "VLLM_E2_GUARD_MODE": "warn", "VLLM_E2_PLE_EARLY_REQUEST": "1", "VLLM_E2_PLE_FAST_IDS": "1", "VLLM_E2_QSA_LOGITS_GRANULE_MB": "256", "VLLM_HOST_EMBED_TABLE": "1", "VLLM_MEMORY_PROFILER_ESTIMATE_CUDAGRAPHS": "0", "VLLM_PLE_OFFLOAD_HOME_DEVICE": "0", "VLLM_PLE_OFFLOAD_READY_TIMEOUT": "3600", "VLLM_PORT": "30100", "VLLM_PP_LAYER_PARTITION": "25,23", "VLLM_QSA_KV_SCALES": "/tmp/fn_merlin/qsa_kv_scales_262k.json", "VLLM_SKIP_P2P_CHECK": "1", "VLLM_SPARSE_INDEXER_MAX_LOGITS_MB": "256", "VLLM_USE_BREAKABLE_CUDAGRAPH": "0", "VLLM_USE_RUST_FRONTEND": "0", "VLLM_USE_V2_MODEL_RUNNER": "1"}, "kv_bytes": 2479838700, "kv_tokens": 513940, "max_concurrency": 3.92, "pool_blocks": 149, "F_rule": 6, "F_engine": 6, "seqs": 8, "gpu_mem_after_ready": [[0, 20903, 23034], [1, 20903, 23034], [2, 20863, 23034], [3, 21389, 23034]], "gpu_mem_end": [[0, 21427, 23034], [1, 21427, 23034], [2, 21387, 23034], [3, 21401, 23034]], "windows": {"40k@1": {"status": "STEADY", "tok_s": 70.0, "mal": 3.086, "step_ms": 44.1, "running": [1.0, 1.0]}, "40k@2": {"status": "STEADY", "tok_s": 107.4, "mal": 3.251, "step_ms": 30.3, "running": [2.0, 2.0]}, "40k@4": {"status": "STEADY", "tok_s": 161.0, "mal": 3.017, "step_ms": 37.5, "running": [4.0, 4.0]}, "40k@5": {"status": "STEADY", "tok_s": 190.5, "mal": 3.073, "step_ms": 40.3, "running": [5.0, 5.0]}, "8k@8": {"status": "STEADY", "tok_s": 261.8, "mal": 3.154, "step_ms": 48.2, "running": [8.0, 8.0]}, "90k@3": {"status": "INCONCLUSIVE_PREFILL_IN_WINDOW", "tok_s": 48.7, "mal": 2.93, "step_ms": 60.1, "running": [1.0, 3.0]}, "90k@4": {"status": "STEADY", "tok_s": 159.8, "mal": 3.022, "step_ms": 37.8, "running": [4.0, 4.0]}, "116k@3": {"status": "STEADY", "tok_s": 140.5, "mal": 3.223, "step_ms": 34.4, "running": [3.0, 3.0]}, "116k@4": {"status": "STEADY", "tok_s": 160.3, "mal": 3.016, "step_ms": 37.6, "running": [4.0, 4.0]}}, "tf_40k_vs_bf16": {"status": "MEASURED", "n": 256, "mean_abs_dlogprob": 1.8764, "p99_abs_dlogprob": 5.464, "max_abs_dlogprob": 7.15, "rank1_agreement": 0.3672, "forced_token_rank1_both_or_neither": 0.457}, "ready_sec": 999.1, "bf16": {"kv_tokens": 269042, "max_concurrency": 2.05, "pool_blocks": 78, "seqs": 3, "gpu_mem_after_ready": [[0, 20905, 23034], [1, 20905, 23034], [2, 20693, 23034], [3, 20693, 23034]], "gpu_mem_end": [[0, 21425, 23034], [1, 21425, 23034], [2, 21215, 23034], [3, 21215, 23034]], "ready_sec": 411.1}, "rank_load_gib": {"2": 16.87, "1": 17.33, "0": 17.33, "3": 16.87}, "rank_graph_gib": {"0": 0.33, "1": 0.33, "2": 0.43, "3": 0.43}}""")      # RC2's real boots: argv tail, env keys, pool, memory, windows (rc2_results.json)
    RC2_ORACLE = json.loads(r"""{"bf16": [{"text": "We need solve ARC task. Need infer transformation from examples. User gives Task 0934a4d8 with Example 1 input/output, Example 2 input/output, Example 3 input only? Need solve test inputs? They provided Example 3 input: 194499276 maybe incomplete? Need output? Need find transformation rule and solve test inputs. We need analyze.\n\nWe have ARC tasks represented as strings of digits? Example 1 input is 31 rows? Let's count. Example 1 input lines:\n1 3533665414", "tokens": [1596, 1144, 11290, 67964, 3274, 13, 14235, 22846, 17454, 494, 9989, 13, 2570, 6486, 5261, 220, 15, 24, 18, 19, 64, 19, 67, 23, 440, 12996, 220, 16, 1879, 45447, 11, 12996, 220, 17, 1879, 45447, 11, 12996, 220, 18, 1879, 1132, 30, 14235, 11290, 1228, 10804, 30, 2302, 3766, 12996, 220, 18, 1879, 25, 220, 16, 24, 19, 19, 24, 24, 17, 22, 21, 6970, 31084, 30, 14235, 2468, 30, 14235, 1423, 17454, 5728, 321, 11290, 1228, 10804, 13, 1165, 1144, 22903, 13, 271, 1596, 599, 67964, 8806, 14807, 430, 8796, 314, 17955, 30, 12996, 220, 16, 1879, 369, 220, 18, 16, 6761, 30, 6558, 579, 1698, 13, 12996, 220, 16, 1879, 4965, 25, 198, 16, 220, 18, 20, 18, 18, 21, 21, 20, 19, 16, 19], "margins": [11.375, 10.75, 0.25, 3.5, 0.125, 1.75, 2.375, 0.625, 4.375, 0.125, 4.125, 1.375, 0.125, 1.0, 1.25, 4.875, 8.6875, 10.375, 10.375, 9.6875, 8.25, 10.1875, 14.0, 10.4375, 0.125, 0.875, 1.25, 8.375, 3.875, 1.0, 3.75, 7.375, 3.75, 12.0, 2.625, 8.375, 6.75, 2.5, 8.75, 10.5, 6.625, 0.125, 0.375, 0.5, 0.75, 8.25, 4.125, 1.0, 1.0, 0.125, 0.25, 4.625, 6.375, 9.25, 2.875, 0.375, 4.125, 4.25, 10.9375, 11.5625, 10.625, 10.5625, 9.5625, 11.5, 10.6875, 0.5, 2.25, 4.875, 2.125, 1.25, 0.125, 0.5, 0.625, 0.625, 4.25, 1.125, 2.875, 3.125, 3.125, 4.125, 0.75, 1.375, 1.75, 0.75, 1.0, 4.25, 1.5, 0.5, 1.125, 0.625, 4.625, 1.625, 0.25, 4.5, 1.0, 0.0, 1.25, 8.5, 5.0, 1.125, 2.75, 3.375, 0.625, 0.125, 1.125, 1.875, 7.25, 1.875, 2.125, 0.25, 0.875, 6.25, 1.875, 1.625, 2.625, 2.875, 2.125, 2.375, 8.125, 10.9375, 10.0625, 9.0625, 9.875, 9.375, 11.25, 11.375, 11.875, 12.9375], "error": null, "prompt_sha": "8df9ed2c640ef5bd", "prompt_len": 2048, "finish_reason": "length"}, {"text": "We need solve ARC tasks. Need infer transformation rules from examples and apply to test inputs. We have two tasks: 1818057f and 195c6913. Need output transformed test grids. Need analyze carefully.\n\nWe need produce final answer likely grids. Need infer rules.\n\nTask 1818057f:\nExamples: inputs/outputs with colors 2,4,8. Output changes some 4s to 8? Let's inspect.\n\nExample1 input 10x12? rows:\n1 22224", "tokens": [1596, 1144, 11290, 67964, 8806, 13, 14235, 22846, 17454, 5426, 494, 9989, 321, 3668, 310, 1228, 10804, 13, 1165, 599, 1330, 8806, 25, 220, 16, 23, 16, 23, 15, 20, 22, 69, 321, 220, 16, 24, 20, 66, 21, 24, 16, 18, 13, 14235, 2468, 22773, 1228, 54455, 13, 14235, 22903, 15060, 13, 271, 1596, 1144, 7936, 1534, 4087, 4222, 54455, 13, 14235, 22846, 5426, 13, 271, 6065, 220, 16, 23, 16, 23, 15, 20, 22, 69, 25, 198, 39044, 25, 10804, 14, 39652, 440, 7736, 220, 17, 11, 19, 11, 23, 13, 8984, 4203, 1010, 220, 19, 82, 310, 220, 23, 30, 6558, 579, 23331, 13, 271, 12929, 16, 1879, 220, 16, 15, 87, 16, 17, 30, 6761, 25, 198, 16, 220, 17, 17, 17, 17, 19], "margins": [11.875, 11.375, 0.75, 3.375, 2.625, 3.0, 3.25, 0.5, 3.125, 0.25, 0.625, 4.75, 1.125, 3.25, 2.0, 5.5, 0.875, 3.75, 0.375, 0.5, 1.375, 6.5, 1.125, 2.25, 12.625, 12.0625, 11.3125, 12.9375, 12.4375, 8.875, 10.8125, 10.75, 1.75, 7.375, 13.5625, 13.875, 11.6875, 11.25, 10.75, 12.375, 12.375, 10.75, 2.25, 2.25, 1.625, 0.875, 1.0, 0.375, 0.875, 1.375, 0.125, 1.875, 6.5, 1.5, 1.0, 1.375, 1.0, 4.75, 4.625, 1.75, 1.0, 1.625, 0.875, 0.625, 0.25, 3.5, 1.0, 1.25, 4.625, 11.625, 5.75, 11.125, 12.3125, 10.8125, 10.9375, 11.0, 11.8125, 0.125, 0.0, 2.625, 0.375, 0.25, 0.875, 7.875, 0.75, 0.875, 1.875, 8.125, 0.75, 7.375, 2.875, 3.875, 2.125, 0.25, 2.0, 3.25, 2.625, 0.625, 2.625, 2.125, 10.75, 10.625, 0.75, 1.75, 7.5, 2.75, 6.375, 0.25, 1.75, 1.375, 0.75, 3.25, 8.375, 4.625, 3.75, 4.375, 2.625, 1.5, 0.25, 0.5, 5.375, 1.375, 0.5, 9.75, 4.625, 12.625, 11.4375, 8.375], "error": null, "prompt_sha": "8750743e9dcadca9", "prompt_len": 2048, "finish_reason": "length"}, {"text": "We need solve ARC tasks. Need find transformation rule for each task and solve test inputs. We have multiple tasks: 247ef758, 269e22fb, 271d71e2, 28a6681f, 291dc1e1. Need output transformed grids for test inputs. Need infer rules from examples. Need be careful. We need produce final answer likely grids. Need analyze each task.\n\nWe need parse tasks. There are two test inputs for 247ef758? It says Test input: ...", "tokens": [1596, 1144, 11290, 67964, 8806, 13, 14235, 1423, 17454, 5728, 364, 1754, 3274, 321, 11290, 1228, 10804, 13, 1165, 599, 5081, 8806, 25, 220, 17, 19, 22, 797, 22, 20, 23, 11, 220, 17, 21, 24, 68, 17, 17, 10481, 11, 220, 17, 22, 16, 67, 22, 16, 68, 17, 11, 220, 17, 23, 64, 21, 21, 23, 16, 69, 11, 220, 17, 24, 16, 7385, 16, 68, 16, 13, 14235, 2468, 22773, 54455, 364, 1228, 10804, 13, 14235, 22846, 5426, 494, 9989, 13, 14235, 381, 16097, 13, 1165, 1144, 7936, 1534, 4087, 4222, 54455, 13, 14235, 22903, 1754, 3274, 13, 271, 1596, 1144, 4563, 8806, 13, 2532, 513, 1330, 1228, 10804, 364, 220, 17, 19, 22, 797, 22, 20, 23, 30, 1049, 2640, 3284, 1879, 25, 2423], "margins": [11.75, 9.875, 1.125, 1.25, 3.875, 2.0, 2.875, 0.375, 5.25, 0.875, 1.5, 5.625, 0.875, 3.0, 2.875, 3.125, 7.75, 6.75, 0.5, 0.5, 1.5, 5.625, 1.375, 3.0, 11.75, 13.375, 12.625, 11.3125, 12.0, 13.5, 12.625, 0.625, 8.4375, 11.625, 11.0, 12.5625, 10.5625, 11.0, 10.375, 8.375, 7.375, 9.75, 11.5625, 9.125, 10.0, 9.75, 9.4375, 10.3125, 10.4375, 9.0, 8.1875, 9.4375, 12.625, 9.75, 11.0, 11.3125, 10.9375, 9.625, 9.5625, 10.0, 8.1875, 7.625, 12.375, 11.125, 11.375, 10.625, 10.25, 10.375, 10.0, 2.5, 3.0, 2.125, 0.125, 0.125, 1.875, 0.125, 4.125, 3.125, 2.0, 0.75, 3.0, 0.75, 8.75, 4.125, 0.125, 1.25, 3.875, 2.75, 0.125, 0.25, 0.625, 3.875, 1.625, 1.875, 0.75, 1.0, 0.375, 2.375, 2.125, 0.5, 0.5, 2.5, 1.875, 0.125, 0.75, 0.375, 3.625, 0.125, 1.375, 0.0, 4.125, 7.375, 2.5, 0.375, 12.75, 6.75, 12.375, 4.625, 8.75, 12.1875, 10.25, 2.0, 0.625, 0.25, 1.125, 7.625, 1.75, 2.125], "error": null, "prompt_sha": "fc63e297d382cd8f", "prompt_len": 8192, "finish_reason": "length"}, {"text": "We need solve ARC tasks. Need find transformation rule for each task and solve test inputs. We need output likely transformed grids. Need analyze many tasks. Need be careful. We have multiple tasks with examples and test inputs. Need infer rules.\n\nWe need produce final answer with transformed test inputs for each task. There are tasks: 2c181942, 2d0172a1 (two test inputs?), 31f7f899, 332f06d7, 35ab12c3, 36a08778", "tokens": [1596, 1144, 11290, 67964, 8806, 13, 14235, 1423, 17454, 5728, 364, 1754, 3274, 321, 11290, 1228, 10804, 13, 1165, 1144, 2468, 4222, 22773, 54455, 13, 14235, 22903, 1599, 8806, 13, 14235, 381, 16097, 13, 1165, 599, 5081, 8806, 440, 9989, 321, 1228, 10804, 13, 14235, 22846, 5426, 13, 271, 1596, 1144, 7936, 1534, 4087, 440, 22773, 1228, 10804, 364, 1754, 3274, 13, 2532, 513, 8806, 25, 220, 17, 66, 16, 23, 16, 24, 19, 17, 11, 220, 17, 67, 15, 16, 22, 17, 64, 16, 318, 19186, 1228, 10804, 66926, 220, 18, 16, 69, 22, 69, 23, 24, 24, 11, 220, 18, 18, 17, 69, 15, 21, 67, 22, 11, 220, 18, 20, 365, 16, 17, 66, 18, 11, 220, 18, 21, 64, 15, 23, 22, 22, 23], "margins": [10.125, 11.5, 1.125, 0.25, 3.5, 2.125, 2.625, 0.5, 5.25, 1.0, 1.75, 5.75, 0.375, 2.375, 3.625, 4.25, 6.625, 7.375, 0.25, 0.125, 1.25, 0.5, 0.25, 2.0, 0.5, 1.625, 1.0, 1.0, 4.375, 2.875, 0.75, 2.125, 4.125, 4.0, 0.375, 0.5, 1.625, 3.875, 0.375, 2.125, 2.125, 2.125, 2.875, 1.625, 2.875, 1.125, 0.75, 1.375, 0.125, 1.625, 2.25, 1.0, 2.875, 2.5, 3.0, 0.125, 1.125, 0.75, 1.25, 2.375, 1.75, 1.625, 0.625, 3.0, 0.125, 4.5, 0.5, 11.625, 10.625, 12.0625, 13.0625, 9.5625, 10.9375, 10.375, 10.875, 1.0, 6.5, 9.8125, 10.25, 11.9375, 13.5, 12.3125, 11.625, 11.25, 11.25, 0.375, 2.5, 4.125, 7.25, 0.625, 5.375, 9.75, 9.625, 12.4375, 11.25, 10.4375, 9.0, 11.4375, 10.8125, 3.25, 8.375, 11.875, 7.375, 11.5, 11.0, 10.5625, 8.8125, 10.875, 10.375, 5.625, 10.125, 13.125, 8.625, 7.375, 11.1875, 10.5, 10.25, 10.9375, 5.25, 9.75, 10.1875, 7.25, 11.4375, 12.0, 8.9375, 11.0625, 9.5, 10.3125], "error": null, "prompt_sha": "49b3958bb234d4fd", "prompt_len": 40000, "finish_reason": "length"}], "fp8": [{"text": "We need solve ARC task. Need infer transformation from examples. User gives Task 0934a4d8. Example 1 input 30x30? output 9x4? Example 2 input 30x30? output 4x5? Example 3 input: \"194499276\" only one row? Maybe truncated? Need find transformation rule and solve test inputs. But only one test input? It says Example 3 input: 194499276. Maybe that's the test input? Need output. Need infer from", "tokens": [1596, 1144, 11290, 67964, 3274, 13, 14235, 22846, 17454, 494, 9989, 13, 2570, 6486, 5261, 220, 15, 24, 18, 19, 64, 19, 67, 23, 13, 12996, 220, 16, 1879, 220, 18, 15, 87, 18, 15, 30, 2468, 220, 24, 87, 19, 30, 12996, 220, 17, 1879, 220, 18, 15, 87, 18, 15, 30, 2468, 220, 19, 87, 20, 30, 12996, 220, 18, 1879, 25, 328, 16, 24, 19, 19, 24, 24, 17, 22, 21, 1, 1132, 799, 2713, 30, 10380, 57739, 30, 14235, 1423, 17454, 5728, 321, 11290, 1228, 10804, 13, 1921, 1132, 799, 1228, 1879, 30, 1049, 2640, 12996, 220, 18, 1879, 25, 220, 16, 24, 19, 19, 24, 24, 17, 22, 21, 13, 10380, 421, 579, 279, 1228, 1879, 30, 14235, 2468, 13, 14235, 22846, 494], "margins": [11.5, 11.25, 0.25, 3.625, 0.375, 2.25, 2.25, 0.875, 4.125, 0.25, 4.25, 1.25, 0.125, 1.0, 1.75, 4.625, 9.0, 9.9375, 10.375, 9.5, 8.875, 10.6875, 14.0, 10.625, 0.125, 0.75, 0.875, 7.5, 4.5, 1.25, 3.5, 0.75, 0.0, 1.75, 4.0, 2.625, 1.25, 9.375, 5.5, 4.25, 2.0, 0.25, 2.625, 0.875, 8.875, 3.75, 4.375, 5.75, 5.5, 4.25, 3.5, 5.5, 0.0, 8.0, 7.25, 7.375, 4.625, 5.875, 1.5, 3.75, 4.875, 9.125, 6.75, 0.25, 0.625, 8.25, 8.25, 12.3125, 11.5, 10.3125, 11.0, 10.1875, 11.625, 9.875, 4.375, 2.25, 0.375, 1.0, 4.875, 0.0, 0.25, 5.75, 2.125, 0.0, 0.25, 2.375, 2.875, 6.75, 9.125, 5.125, 1.875, 0.75, 2.375, 0.0, 0.875, 1.875, 2.125, 0.75, 2.25, 1.625, 9.1875, 7.125, 9.125, 5.625, 1.125, 7.9375, 7.0625, 10.375, 11.375, 10.8125, 10.5625, 11.1875, 11.5, 11.625, 1.0, 1.625, 1.375, 2.625, 0.5, 2.375, 1.75, 2.625, 2.0, 2.625, 0.125, 1.5, 0.25, 1.5], "error": null, "prompt_sha": "8df9ed2c640ef5bd", "prompt_len": 2048, "finish_reason": "length"}, {"text": "We need solve ARC tasks. Need infer transformation rules from examples and apply to test inputs. We have two tasks: 1818057f and 195c6913. Need output transformed test grids. Need analyze carefully.\n\nWe need produce final answer likely grids. Need infer rules.\n\nTask 1818057f examples:\nInput/output grids with colors 2,4,8. Output changes some 4s to 8? Let's inspect.\n\nExample1 10x12? Input rows:\n1 222244", "tokens": [1596, 1144, 11290, 67964, 8806, 13, 14235, 22846, 17454, 5426, 494, 9989, 321, 3668, 310, 1228, 10804, 13, 1165, 599, 1330, 8806, 25, 220, 16, 23, 16, 23, 15, 20, 22, 69, 321, 220, 16, 24, 20, 66, 21, 24, 16, 18, 13, 14235, 2468, 22773, 1228, 54455, 13, 14235, 22903, 15060, 13, 271, 1596, 1144, 7936, 1534, 4087, 4222, 54455, 13, 14235, 22846, 5426, 13, 271, 6065, 220, 16, 23, 16, 23, 15, 20, 22, 69, 9989, 25, 198, 2425, 45447, 54455, 440, 7736, 220, 17, 11, 19, 11, 23, 13, 8984, 4203, 1010, 220, 19, 82, 310, 220, 23, 30, 6558, 579, 23331, 13, 271, 12929, 16, 220, 16, 15, 87, 16, 17, 30, 5396, 6761, 25, 198, 16, 220, 17, 17, 17, 17, 19, 19], "margins": [11.875, 11.75, 0.5, 3.125, 2.625, 3.0, 3.125, 0.5, 3.0, 0.5, 0.625, 4.875, 1.0, 3.25, 2.0, 5.625, 0.625, 3.875, 0.375, 0.75, 1.375, 6.75, 1.375, 2.125, 12.8125, 11.9375, 11.6875, 13.1875, 12.0625, 8.4375, 10.3125, 10.5, 1.625, 7.25, 13.5625, 12.625, 10.5625, 9.375, 12.0, 12.6875, 11.3125, 11.0625, 2.0, 2.375, 1.625, 0.875, 1.0, 0.125, 0.5, 1.25, 0.125, 1.875, 6.625, 1.625, 1.5, 1.5, 1.0, 4.75, 4.625, 2.0, 0.875, 1.5, 1.0, 0.625, 0.5, 3.375, 1.0, 1.125, 4.5, 12.375, 5.625, 11.125, 12.625, 10.0625, 9.875, 10.125, 11.625, 0.125, 1.375, 0.5, 1.0, 0.75, 0.375, 1.25, 1.0, 1.75, 7.75, 0.75, 7.75, 2.375, 3.625, 1.625, 0.25, 2.0, 3.5, 2.75, 1.125, 2.25, 2.375, 10.8125, 10.75, 0.75, 1.875, 7.5, 2.75, 5.25, 0.25, 2.125, 1.25, 0.0, 7.125, 3.625, 5.5, 4.5, 2.0, 1.5, 0.75, 0.875, 0.0, 6.375, 1.0, 0.75, 10.0, 4.75, 12.625, 11.5625, 8.375, 11.4375], "error": null, "prompt_sha": "8750743e9dcadca9", "prompt_len": 2048, "finish_reason": "length"}, {"text": "We need solve ARC tasks. Need find transformation rule for each task and solve test inputs. We have multiple tasks: 247ef758, 269e22fb, 271d71e2, 28a6681f, 291dc1e1. Need output transformed test inputs. Need infer rules from examples. Need be careful. We can analyze each.\n\nWe need produce final answer likely grids for each test input. Need determine exact transformations.\n\nLet's parse tasks.\n\nTask 247ef758: examples show", "tokens": [1596, 1144, 11290, 67964, 8806, 13, 14235, 1423, 17454, 5728, 364, 1754, 3274, 321, 11290, 1228, 10804, 13, 1165, 599, 5081, 8806, 25, 220, 17, 19, 22, 797, 22, 20, 23, 11, 220, 17, 21, 24, 68, 17, 17, 10481, 11, 220, 17, 22, 16, 67, 22, 16, 68, 17, 11, 220, 17, 23, 64, 21, 21, 23, 16, 69, 11, 220, 17, 24, 16, 7385, 16, 68, 16, 13, 14235, 2468, 22773, 1228, 10804, 13, 14235, 22846, 5426, 494, 9989, 13, 14235, 381, 16097, 13, 1165, 628, 22903, 1754, 13, 271, 1596, 1144, 7936, 1534, 4087, 4222, 54455, 364, 1754, 1228, 1879, 13, 14235, 7995, 4581, 51192, 13, 271, 9764, 579, 4563, 8806, 13, 271, 6065, 220, 17, 19, 22, 797, 22, 20, 23, 25, 9989, 1420], "margins": [11.875, 9.75, 1.25, 1.5, 3.625, 2.125, 3.0, 0.125, 5.25, 0.875, 1.625, 5.5, 0.875, 3.125, 2.875, 2.875, 8.5, 7.125, 0.375, 0.375, 1.875, 5.375, 1.625, 3.0, 12.125, 13.3125, 12.9375, 11.8125, 11.8125, 13.5, 12.5, 0.375, 8.875, 11.6875, 10.9375, 12.25, 11.0625, 10.6875, 10.375, 8.3125, 7.375, 10.4375, 11.1875, 9.0, 9.8125, 10.125, 10.25, 10.8125, 10.125, 9.3125, 8.0625, 9.5, 12.4375, 10.4375, 11.0, 11.1875, 11.1875, 9.6875, 10.375, 9.0, 7.75, 7.625, 12.875, 10.8125, 11.375, 9.625, 10.625, 11.0625, 9.875, 2.375, 2.875, 2.125, 0.125, 0.0, 0.875, 0.75, 2.0, 0.625, 3.125, 0.875, 8.375, 3.875, 0.125, 1.25, 4.125, 2.875, 0.375, 0.125, 0.5, 0.125, 0.875, 1.375, 2.5, 2.25, 0.75, 4.0, 1.75, 2.0, 0.875, 0.625, 1.125, 3.375, 4.25, 3.75, 0.875, 0.125, 0.5, 0.875, 6.25, 1.5, 3.125, 10.25, 2.625, 2.25, 3.25, 3.625, 3.625, 6.75, 10.375, 7.625, 12.5, 11.75, 11.25, 11.875, 13.4375, 1.5, 0.0, 0.25], "error": null, "prompt_sha": "fc63e297d382cd8f", "prompt_len": 8192, "finish_reason": "length"}, {"text": "We need solve ARC tasks. Need find transformation rule for each task and solve test inputs. We have multiple tasks with examples and test inputs. Need output transformed grids likely. Need infer rules. This is complex. Need analyze each task carefully. Need produce final answer with outputs for each test input. Need be accurate.\n\nWe have tasks:\n2c181942 (one test input)\n2d0172a1 (two test inputs? It lists Test input twice)\n31f7f899 (one test)\n332f06d7 (one test)", "tokens": [1596, 1144, 11290, 67964, 8806, 13, 14235, 1423, 17454, 5728, 364, 1754, 3274, 321, 11290, 1228, 10804, 13, 1165, 599, 5081, 8806, 440, 9989, 321, 1228, 10804, 13, 14235, 2468, 22773, 54455, 4222, 13, 14235, 22846, 5426, 13, 1061, 369, 6150, 13, 14235, 22903, 1754, 3274, 15060, 13, 14235, 7936, 1534, 4087, 440, 15796, 364, 1754, 1228, 1879, 13, 14235, 381, 12995, 13, 271, 1596, 599, 8806, 25, 198, 17, 66, 16, 23, 16, 24, 19, 17, 318, 588, 1228, 1879, 8, 198, 17, 67, 15, 16, 22, 17, 64, 16, 318, 19186, 1228, 10804, 30, 1049, 11140, 3284, 1879, 10598, 8, 198, 18, 16, 69, 22, 69, 23, 24, 24, 318, 588, 1228, 8, 198, 18, 18, 17, 69, 15, 21, 67, 22, 318, 588, 1228, 8], "margins": [10.0, 11.25, 1.0, 0.625, 3.375, 2.5, 2.875, 0.375, 5.125, 0.875, 1.75, 5.875, 0.375, 2.875, 3.625, 4.125, 6.375, 7.5, 0.25, 0.0, 0.25, 6.25, 0.25, 3.75, 2.0, 2.625, 3.125, 2.875, 4.125, 2.75, 0.5, 1.375, 0.625, 0.5, 1.875, 0.125, 1.375, 0.25, 0.0, 9.625, 0.125, 1.375, 1.0, 0.625, 3.125, 4.125, 0.25, 1.875, 0.125, 0.875, 3.875, 1.5, 2.75, 0.0, 2.5, 0.875, 3.0, 4.75, 1.25, 1.0, 0.125, 1.75, 10.625, 1.875, 2.625, 0.125, 3.0, 3.5, 1.125, 0.25, 10.5, 13.375, 13.3125, 12.0625, 10.375, 9.625, 11.0, 0.125, 1.625, 7.5, 1.0, 3.5, 7.75, 7.0, 10.375, 13.0625, 13.1875, 12.0, 11.1875, 11.875, 11.1875, 7.125, 5.75, 5.25, 8.5, 0.625, 0.75, 0.75, 1.375, 7.375, 0.75, 0.0, 4.375, 8.9375, 9.875, 12.8125, 11.8125, 10.6875, 10.1875, 10.5625, 12.125, 4.625, 5.25, 1.125, 0.0, 10.875, 11.6875, 6.875, 13.0, 11.125, 12.0, 10.0625, 11.375, 10.5, 9.25, 9.0, 2.625, 5.25], "error": null, "prompt_sha": "49b3958bb234d4fd", "prompt_len": 40000, "finish_reason": "length"}]}""")   # RC2's recorded greedy oracle rows (traces/requests.jsonl), BF16 + FP8
    GEN_RATE = 45.0                              # tok/s per stream used only to project window growth (RC2: 33 at 8, 70 at 1)
    PP = 2                                       # pipeline stages of the profile: one engine step = one micro-batch (C/2 requests)
    TF_BANDS = ("2k", "8k")                      # FP8 self-consistency only (< 2 min); the BF16 / FP8 isolation is NB0's
    TF_P = {b: PROMPTS[b][5] for b in TF_BANDS}  # RC2's TF prompt (variant 5)
    RETENTION_KNOBS = {   # Merlin source (ad42e37), recorded, not changed
        "MAX_GRACE_PINS": "16 finished turns keep their cached prefix referenced (kv_cache_manager.py:735, class constant)",
        "MAX_PINNED_WAITERS": "16 waiting requests' hits pinned until admission (kv_cache_manager.py:940, class constant)",
        "enable_grace_pins": "enable_caching and partial hash hits (prefix-match-unit 64), kv_cache_manager.py:234",
        "VLLM_E2_SCHED_MISS_DEFER_S": "120 s default (merlin/envs.py:40): a cold miss may wait for protected waiters",
        "VLLM_E2_SCHED_COHERENT_YIELD": "on by default (merlin/envs.py:41): need-sized, session-coherent yields",
        "reset": "/reset_prefix_cache (VLLM_SERVER_DEV_MODE=1) drops grace and waiter pins when they alone block the reset "
                 "(kv_cache_manager.py:1107-1113); it fails while requests run"}
    for _b, _n in (("8k", 34), ("40k", 16)):     # distinct prompts (RC2 has 8 per band)
        PROMPTS[_b] += [prompt(BANDS[_b], v) for v in range(len(PROMPTS[_b]), _n)]
    BANDS["60k"] = 60000                         # residency probe band (addendum 7); RC2's PROMPTS bands are unchanged
    PROMPTS["60k"] = [prompt(BANDS["60k"], v) for v in range(8)]
    MAX_NEW["60k"] = MAX_LEN - BANDS["60k"] - 512
    RESIDENCY_BANDS = ("8k", "40k", "60k", "90k", "116k")
    V_CENSUS = {"8k": list(range(24, 32)), "40k": list(range(9, 13))}   # never used by a steady window in the same boot
    V_PREFIX = {"8k": 32, "40k": 8}
    V_ABORT = 33
    SUFFIX_TXT = ("\n</think>\n\nI have a first rule.<|im_end|>\n<|im_start|>user\nCheck the rule on every training pair, "
                  "then give the final test grid." + _tail_txt)
    SUFFIX_IDS = TOK.encode(SUFFIX_TXT, add_special_tokens=False).ids
    R["prompts"] = {b: {"n": len(p), "len": len(p[0])} for b, p in PROMPTS.items()}


    def psha(ids):
        return hashlib.sha256(json.dumps(list(ids)).encode()).hexdigest()


    R["nb1_prompt_sha256"] = {b: psha(TF_P[b]) for b in TF_BANDS}
    _osha = [psha(p)[:16] for p in ORACLE_P + LONG_P]          # RC2's own prompt_sha formula (16 hex)
    NB1["rc2_oracle_prompts_match"] = {k: [r["prompt_sha"] for r in v] == _osha for k, v in RC2_ORACLE.items()}
    for _k, _v in RC2_ORACLE.items():                          # RC2's recorded rows become references only for identical prompts
        if NB1["rc2_oracle_prompts_match"][_k] and not FAKE:    # (the fake server's text differs: it builds its own reference)
            ROWS["rc2_" + _k] = [{"text": r["text"], "tokens": r["tokens"], "margins": r["margins"], "error": r["error"]} for r in _v]
    NB1["retention_knobs"] = RETENTION_KNOBS
    NB1["sampling"] = ("every request passes its own sampling (greedy: temperature 0; load: T 0.6, top_p 0.95, top_k 20; "
                       "Merlin's --override-generation-config is T 1.0)")
    R["capacity_plan"] = {
        "rule": "blocks per running request = ceil(L / 4096) + F, F = 6 (3 mamba groups x 2; RC2 analysis: 149 / 3.92 = 38 = 32 + 6, "
                "live transitions 6.0 / 6.1); a finished session keeps floor(L / 4096) + 3 blocks (up to 16) until re-admitted or yielded",
        "rc2_pool_blocks": {"fp8": 149, "bf16": 78},
        "worst_case_F6": {"8k@8": 8 * (math.ceil((8192 + 8000) / 4096) + 6), "40k@5": 5 * (math.ceil((40000 + 8000) / 4096) + 6),
                          "8k x 8 hold (cold sequence)": 8 * (math.ceil(9000 / 4096) + 6), "40k x 4 hold": 4 * (math.ceil(41000 / 4096) + 6),
                          "90k x 5 admission (max_new 3000)": 5 * (math.ceil(93000 / 4096) + 6), "pool": 149},
        "retention": "every capacity test starts from /reset_prefix_cache (retained sessions released); windows record the idle "
                     "(retained) blocks before them, so running = used - retained",
        "highest_levels": "computed at run time from the measured pool and F, never above max_num_seqs read from the server log",
        "tf": "B1 only: 2k + 8k FP8 self-consistency (teacher-forced A/A + greedy cached-repeat), < 2 min",
        "c3_note": "at BLOCK_SIZE 4096 the attention page is larger than the mamba page (RC2 log: 'Padding mamba page size by "
                   "21.01%'), so bf16 SSM state cannot change the pool's block count; B2 records the smaller minimum block it allows"}

    # ---- trace classifier fix (A7): QSA / Marlin MoE / top-k before the generic patterns; GDN '(anonymous namespace)' is
    # already handled by the lab's rev 3h _cat
    L.CATS = [("nccl_sendrecv", ("sendrecv", "send_recv", "nccldevkernel_send", "nccldevkernel_recv")), L.CATS[0],
              ("recoverssm_commit", ("recoverssm", "commit_", "boundary_fold", "final_fold", "conv_compaction")),
              ("qsa", ("qsa",)), ("moe_marlin", ("marlin_moe", "fused_marlin_moe", "moe_wna16")),
              ("topk", ("persistent_topk", "cooperative_topk"))] + list(L.CATS[1:])
    L.COMPUTE_CATS = tuple(L.COMPUTE_CATS) + ("nccl_sendrecv", "recoverssm_commit", "qsa", "moe_marlin", "topk")

    # ---- RC2 long-row gate, stricter (audit 2): a natural row needs finish == stop and a closed think; forced rows
    # (ignore_eos) are stability tests only. NB1 runs no long rows; the reused gate is fixed for any later reuse.
    _long_quality_rc2, _long_gate_rc2 = long_quality, long_gate


    def long_quality(name, r):
        q = _long_quality_rc2(name, r)
        if q == "PASS_LONG" and name == "natural":
            if r.get("finish") != "stop":
                return "INCOMPLETE_NATURAL_FINISH"
            if r.get("think_closed") is not True:
                return "INCOMPLETE_THINKING"
        return q


    def long_gate(o):
        g = _long_gate_rc2(o)
        lo = o.get("long") if isinstance(o.get("long"), dict) else None
        if lo and isinstance(lo.get("forced60k"), dict):
            lo["forced60k"]["counts_as"] = "stability test only (ignore_eos)"
        if g is None and lo and any(v in ("INCOMPLETE_NATURAL_FINISH", "INCOMPLETE_THINKING") for v in (lo.get("long_quality") or {}).values()):
            return "INCONCLUSIVE_LONG_INCOMPLETE"
        return g


    # ---- the #60490 backport + the worker extension (written before B1)
    P60490 = "# vLLM PR #60490 (issue #60489) rebased onto Merlin v3.0.0 (commit ad42e37feb7611c4ffd24017bf20a7e2dc94c6e5,\n# tree 07c16a79d077f1e06c19d0eea84efd64f0b63540 = the tree the Kaggle payload installs, install_merlin.log).\n# Same code as upstream; only the import context differs (Merlin's import block). One marker comment added.\n# pre-patch sha256  a23d5f90507ad5185f8b8e8d6ba13ae0cb53b2506264fdfbbf6a60b1171dc653\n# post-patch sha256 88fe0a8f4dd2ef90fc6aefb5771b5b48e40c0b1d575039283c52aeca19b8bd6b\n--- a/vllm/models/qwen4_exp/nvidia/qsa.py\n+++ b/vllm/models/qwen4_exp/nvidia/qsa.py\n@@ -18,8 +18,9 @@\n from torch import nn\n from transformers import Qwen4ExpTextConfig\n \n+import vllm.envs as envs\n from vllm.compilation.breakable_cudagraph import eager_break_during_capture\n-from vllm.config import VllmConfig\n+from vllm.config import VllmConfig, get_current_vllm_config_or_none\n from vllm.config.cache import CacheConfig, CacheDType\n from vllm.distributed import get_tensor_model_parallel_world_size\n from vllm.forward_context import get_forward_context\n@@ -45,6 +46,7 @@\n )\n from vllm.platforms import current_platform\n from vllm.platforms.interface import DeviceCapability\n+from vllm.utils.math_utils import cdiv\n from vllm.utils.torch_utils import (\n     LayerNameType,\n     _encode_layer_name,\n@@ -75,6 +77,7 @@\n from . import model\n from .indexer_qsa import QSAIndexer\n from .ops.qsa import qsa_e4m3_uses_native_cast\n+from .ops.qsa_indexer import _TOPK_WORKSPACE_BYTES\n \n logger = init_logger(__name__)\n \n@@ -782,6 +785,31 @@\n         if isinstance(metadata, list):\n             metadata = metadata[0]\n         if not isinstance(metadata, dict):\n+            # E25 NB1: backport of vLLM PR #60490 (issue #60489).\n+            # Profiling/dummy run: the indexer allocates its selection scratch\n+            # on demand, so touch its peak here for the memory profiler (as\n+            # sparse_attn_indexer does): the prefill logits budget or the\n+            # worst-case decode logits [decode tokens, compressed columns],\n+            # plus the top-k workspace.\n+            logits_bytes = envs.VLLM_SPARSE_INDEXER_MAX_LOGITS_MB * 1024 * 1024\n+            cfg = get_current_vllm_config_or_none()\n+            if cfg is not None:\n+                spec = cfg.speculative_config\n+                num_spec = spec.num_speculative_tokens if spec is not None else 0\n+                decode_tokens = min(\n+                    cfg.scheduler_config.max_num_seqs * (num_spec + 1),\n+                    cfg.scheduler_config.max_num_batched_tokens,\n+                )\n+                block_size = cfg.cache_config.block_size\n+                columns = cdiv(cfg.model_config.max_model_len, block_size) * cdiv(\n+                    block_size, self.indexer.compress_ratio\n+                )\n+                logits_bytes = max(logits_bytes, decode_tokens * columns * 4)\n+            _ = torch.empty(\n+                logits_bytes + _TOPK_WORKSPACE_BYTES,\n+                dtype=torch.uint8,\n+                device=output.device,\n+            )\n             output.zero_()\n             return\n         main_metadata = cast(FlashAttentionMetadata, metadata[self.layer_name])\n"
    P60490_REL = "vllm/models/qwen4_exp/nvidia/qsa.py"
    P60490_PRE, P60490_POST = "a23d5f90507ad5185f8b8e8d6ba13ae0cb53b2506264fdfbbf6a60b1171dc653", "88fe0a8f4dd2ef90fc6aefb5771b5b48e40c0b1d575039283c52aeca19b8bd6b"
    P60490_MARKER = "# E25 NB1: backport of vLLM PR #60490 (issue #60489)."
    NB1_EXT_SRC = "\"\"\"E25 NB1 worker extension (read-only): reached through POST /collective_rpc {\"method\": \"nb1_cache_info\"} with\nVLLM_SERVER_DEV_MODE=1 and --worker-extension-cls nb1_worker_ext.NB1WorkerExt. Reports the ACTUAL cache tensors bound\nto every attention / Mamba layer (dtype, shape, bytes), the KV cache specs (padded vs unpadded Mamba page bytes), the\nphysical block count and this rank's free memory. It never raises: every part returns its error text instead.\"\"\"\nimport json\nimport math\n\n\ndef _t(x):\n    try:\n        import torch\n        if isinstance(x, torch.Tensor):\n            return {\"dtype\": str(x.dtype).replace(\"torch.\", \"\"), \"shape\": list(x.shape), \"bytes\": int(x.numel() * x.element_size())}\n    except Exception:\n        pass\n    return None\n\n\ndef _flat(kc):\n    if _t(kc):\n        return [kc]\n    if isinstance(kc, (list, tuple)):\n        if kc and isinstance(kc[0], (list, tuple)) and not _t(kc[0]):\n            kc = kc[0]                              # one entry per virtual engine\n        return [x for x in kc if _t(x)]\n    return []\n\n\n_RT = {\"on\": False, \"installed\": False, \"rows\": [], \"passes\": 0, \"calls\": 0, \"max_steps\": 200, \"bytes\": 0, \"errors\": [],\n       \"first\": None, \"skipped_capturing\": 0, \"skipped_prefill\": 0}\n_RT_MAX_BYTES = 16 << 20\n_RT_DECODE_MAX_ROWS = 128          # a decode / verify micro-batch: requests x (1 + K) tokens; prefill chunks are larger\n\n\ndef _rt_layer(name):\n    import re as _r\n    m = _r.search(r\"layers\\.(\\d+)\", str(name))\n    return int(m.group(1)) if m else -1\n\n\ndef _rt_wrap(orig):\n    def select_experts(self, hidden_states, router_logits, *a, **k):\n        out = orig(self, hidden_states, router_logits, *a, **k)\n        if _RT[\"on\"] and _RT[\"passes\"] < 2 * _RT[\"max_steps\"] and _RT[\"bytes\"] < _RT_MAX_BYTES:\n            try:\n                import torch\n                if torch.cuda.is_current_stream_capturing():\n                    _RT[\"skipped_capturing\"] += 1\n                else:\n                    ids = out[1]\n                    lay = _rt_layer(getattr(self, \"nb1_layer\", None))\n                    if _RT[\"first\"] is None:\n                        _RT[\"first\"] = lay\n                    n = int(ids.shape[0])\n                    if n > _RT_DECODE_MAX_ROWS:\n                        _RT[\"skipped_prefill\"] += 1\n                    else:\n                        if lay == _RT[\"first\"]:\n                            _RT[\"passes\"] += 1     # one pass of a micro-batch through this stage's first MoE layer\n                        keep = ids.to(torch.int16).cpu().numpy().reshape(n, -1)\n                        _RT[\"rows\"].append((lay, max(0, _RT[\"passes\"] - 1), n, keep))\n                        _RT[\"bytes\"] += keep.nbytes\n                        _RT[\"calls\"] += 1\n            except Exception as e:\n                if len(_RT[\"errors\"]) < 5:\n                    _RT[\"errors\"].append(repr(e)[:160])\n        return out\n    return select_experts\n\n\nclass NB1WorkerExt:\n    def nb1_routing(self, action, arg=\"\"):\n        \"\"\"Router top-k expert ids, ONLY between 'start' and 'stop' (the profiling window): FusedMoERouter.select_experts is\n        wrapped once at class level; every decode / verify-sized call (<= 128 token rows) that runs in Python (not during\n        a CUDA-graph capture) keeps its ids (int16) with the layer index and the pass index (counted at this stage's first\n        MoE layer; NB1 maps pass -> step = pass // 2, mb_index = pass % 2 under PP2); <= max_steps steps, <= 16 MiB per\n        rank. FULL-graph replays run no Python, so graph-replayed decode steps are NOT recorded (vLLM's\n        --enable-return-routed-experts writes the ids from inside the graph; it changes the forward graph and memory, so it\n        is not used on a measured boot). 'stop' writes the rank's part file <arg>_rank<r>.npz.\"\"\"\n        out = {\"action\": action}\n        try:\n            import torch.distributed as dist\n            rank = dist.get_rank() if dist.is_initialized() else 0\n            out[\"rank\"] = rank\n            if action == \"start\":\n                from vllm.model_executor.layers.fused_moe.router.fused_moe_router import FusedMoERouter\n                if not _RT[\"installed\"]:\n                    FusedMoERouter.select_experts = _rt_wrap(FusedMoERouter.select_experts)\n                    _RT[\"installed\"] = True\n                    model = getattr(getattr(self, \"model_runner\", None), \"model\", None)\n                    named = 0\n                    if model is not None:\n                        for name, mod in model.named_modules():\n                            for attr in (\"router\", \"_router\"):\n                                r = getattr(mod, attr, None)\n                                if isinstance(r, FusedMoERouter):\n                                    r.nb1_layer = name\n                                    named += 1\n                    out[\"routers_named\"] = named\n                _RT.update(on=True, rows=[], passes=0, calls=0, bytes=0, errors=[], first=None, skipped_capturing=0,\n                           skipped_prefill=0, max_steps=int(arg or 200))\n                return out\n            _RT[\"on\"] = False\n            out.update(passes=_RT[\"passes\"], calls=_RT[\"calls\"], bytes=_RT[\"bytes\"], errors=_RT[\"errors\"],\n                       skipped_capturing=_RT[\"skipped_capturing\"], skipped_prefill=_RT[\"skipped_prefill\"])\n            if action == \"stop\" and arg and _RT[\"rows\"]:\n                import numpy as np\n                rows = _RT[\"rows\"]\n                offs, o_ = [], 0\n                for r in rows:\n                    offs.append(o_)\n                    o_ += r[2]\n                path = f\"{arg}_rank{rank}.npz\"\n                np.savez_compressed(path, ids=np.concatenate([r[3] for r in rows], axis=0), layer=np.array([r[0] for r in rows]),\n                                    pass_index=np.array([r[1] for r in rows]), mb_size=np.array([r[2] for r in rows]),\n                                    offset=np.array(offs), rank=np.array([rank]))\n                out[\"path\"] = path\n            _RT[\"rows\"] = []\n        except Exception as e:\n            out[\"error\"] = repr(e)[:300]\n        return out\n\n    def nb1_cache_info(self):\n        out = {}\n        try:\n            import torch.distributed as dist\n            out[\"rank\"] = dist.get_rank() if dist.is_initialized() else None\n        except Exception as e:\n            out[\"rank_error\"] = repr(e)[:120]\n        try:\n            ctx = self.vllm_config.compilation_config.static_forward_context\n            sig = {}\n            for name, mod in ctx.items():\n                ts = [_t(x) for x in _flat(getattr(mod, \"kv_cache\", None))]\n                if not ts:\n                    continue\n                key = type(mod).__name__ + \"|\" + json.dumps([(x[\"dtype\"], x[\"shape\"]) for x in ts])\n                g = sig.setdefault(key, {\"module\": type(mod).__name__, \"tensors\": ts, \"layers\": 0, \"example\": name})\n                g[\"layers\"] += 1\n            out[\"cache_tensors\"] = list(sig.values())[:40]\n        except Exception as e:\n            out[\"cache_tensors_error\"] = repr(e)[:300]\n        try:\n            agg = {}\n            for name, sp in self.get_kv_cache_spec().items():\n                d = {\"type\": type(sp).__name__}\n                for k in (\"block_size\", \"page_size_bytes\", \"page_size_padded\", \"dtype\", \"num_kv_heads\", \"head_size\", \"mamba_type\"):\n                    try:\n                        v = getattr(sp, k, None)\n                        d[k] = v if isinstance(v, (int, float, str, bool, type(None))) else str(v)\n                    except Exception as e:\n                        d[k] = \"ERR \" + repr(e)[:60]\n                shapes, dtypes = getattr(sp, \"shapes\", None), getattr(sp, \"dtypes\", None)\n                if shapes and dtypes:\n                    try:\n                        d[\"state_dtypes\"] = [str(x).replace(\"torch.\", \"\") for x in dtypes]\n                        d[\"state_shapes\"] = [list(s) for s in shapes]\n                        d[\"unpadded_page_bytes\"] = int(sum(math.prod(s) * x.itemsize for s, x in zip(shapes, dtypes)))\n                    except Exception as e:\n                        d[\"unpadded_error\"] = repr(e)[:80]\n                key = json.dumps(d, sort_keys=True, default=str)\n                a = agg.setdefault(key, dict(d, layers=0, example=name))\n                a[\"layers\"] += 1\n            out[\"kv_cache_specs\"] = list(agg.values())[:40]\n        except Exception as e:\n            out[\"kv_cache_specs_error\"] = repr(e)[:300]\n        try:\n            out[\"num_gpu_blocks\"] = getattr(self.cache_config, \"num_gpu_blocks\", None)\n            out[\"mamba_page_size_padded\"] = getattr(self.cache_config, \"mamba_page_size_padded\", None)\n            out[\"mamba_ssm_cache_dtype\"] = str(getattr(self.cache_config, \"mamba_ssm_cache_dtype\", None))\n            out[\"cache_block_size\"] = getattr(self.cache_config, \"block_size\", None)\n        except Exception as e:\n            out[\"cache_config_error\"] = repr(e)[:200]\n        try:\n            for obj in (getattr(self, \"model_runner\", None), self):\n                cfg = getattr(obj, \"kv_cache_config\", None)\n                if cfg is not None:\n                    out[\"kv_cache_config\"] = {\n                        \"num_blocks\": getattr(cfg, \"num_blocks\", None),\n                        \"groups\": [{\"spec\": type(g.kv_cache_spec).__name__, \"layers\": len(g.layer_names),\n                                    \"block_size\": getattr(g.kv_cache_spec, \"block_size\", None),\n                                    \"page_size_bytes\": getattr(g.kv_cache_spec, \"page_size_bytes\", None)}\n                                   for g in getattr(cfg, \"kv_cache_groups\", [])][:16],\n                        \"tensors\": [{\"size\": getattr(t, \"size\", None), \"shared_by\": len(getattr(t, \"shared_by\", None) or [])}\n                                    for t in getattr(cfg, \"kv_cache_tensors\", [])][:24]}\n                    break\n        except Exception as e:\n            out[\"kv_cache_config_error\"] = repr(e)[:300]\n        try:\n            import torch\n            fr, tot = torch.cuda.mem_get_info()\n            out[\"mem\"] = {\"free_mib\": fr >> 20, \"total_mib\": tot >> 20, \"allocated_mib\": torch.cuda.memory_allocated() >> 20,\n                          \"reserved_mib\": torch.cuda.memory_reserved() >> 20, \"max_allocated_mib\": torch.cuda.max_memory_allocated() >> 20}\n        except Exception as e:\n            out[\"mem_error\"] = repr(e)[:200]\n        return out\n\n\n    def nb4s_env(self, keys=\"\"):\n        \"\"\"E25 NB4S (read-only): this worker's os.environ for the comma-separated `keys` (default CUDA_DEVICE_MAX_CONNECTIONS),\n        all NCCL_* / CUDA_* variables, pid, rank and device. CUDA reads CUDA_DEVICE_MAX_CONNECTIONS at context creation, so\n        the process env (inherited at spawn, before CUDA init) is what is in effect. Never raises.\"\"\"\n        import os as _os\n        out = {\"pid\": _os.getpid()}\n        try:\n            ks = [k for k in str(keys or \"CUDA_DEVICE_MAX_CONNECTIONS\").split(\",\") if k]\n            out[\"env\"] = {k: _os.environ[k] for k in ks if k in _os.environ}\n            out[\"nccl_cuda_env\"] = {k: v for k, v in sorted(_os.environ.items()) if k.startswith((\"NCCL_\", \"CUDA_\"))}\n        except Exception as e:\n            out[\"error\"] = repr(e)[:200]\n        try:\n            import torch.distributed as dist\n            out[\"rank\"] = dist.get_rank() if dist.is_initialized() else None\n        except Exception as e:\n            out[\"rank_error\"] = repr(e)[:120]\n        try:\n            import torch\n            out[\"device\"] = torch.cuda.current_device() if torch.cuda.is_available() else None\n        except Exception as e:\n            out[\"device_error\"] = repr(e)[:120]\n        return out\n"

    def apply_unified(text, patch):
        """Strict unified-diff applier (no fuzz, no offset): every context / removed line must match at its stated line,
        else ValueError. Lines before the first hunk (comments, ---/+++ headers) are ignored."""
        src = text.splitlines(True)
        hunks, cur = [], None
        for ln in patch.splitlines(True):
            if ln.startswith("@@"):
                m = re.match(r"@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@", ln)
                if not m:
                    raise ValueError("bad hunk header: " + ln[:80])
                cur = [int(m.group(1)), int(m.group(2) or 1), []]
                hunks.append(cur)
            elif cur is not None and ln[:1] in (" ", "-", "+"):
                cur[2].append(ln)
            elif cur is not None and ln.startswith("\\"):
                raise ValueError("'No newline at end of file' hunks are not supported")
        if not hunks:
            raise ValueError("patch has no hunks")
        out, pos = [], 0
        for start, n_old, body in hunks:
            i = start - 1
            if i < pos:
                raise ValueError(f"overlapping hunk at line {start}")
            out += src[pos:i]
            old_seen = 0
            for ln in body:
                tag, s = ln[0], ln[1:]
                if tag in " -":
                    if i >= len(src) or src[i] != s:
                        raise ValueError(f"context mismatch at line {i + 1}: {s[:60]!r}")
                    i += 1
                    old_seen += 1
                if tag in " +":
                    out.append(s)
            if old_seen != n_old:
                raise ValueError(f"hunk at line {start}: {old_seen} old lines, header says {n_old}")
            pos = i
        return "".join(out + src[pos:])


    def apply_60490():
        """After merlin_install, before B1: patch the installed tree's qsa.py (pre-sha must be Merlin ad42e37's), verify the
        post-sha, the marker, a py_compile with the Merlin venv and that `vllm` resolves to the tree; write the read-only
        worker extension next to the tree's vllm/ (on the server's PYTHONPATH). Any miss raises: no boot is started."""
        if FAKE:
            tree = os.environ.get("NB1_FAKE_TREE")
            if not tree:
                raise RuntimeError("PATCH_60490_NO_TREE: NB1_FAKE_TREE is not set (local harness)")
            tree, py = Path(tree), sys.executable
        else:
            eng = merlin_install()
            tree, py = Path(eng["kv"]["MERLIN_TREE"]), eng["kv"]["MERLIN_VENV"] + "/bin/python"
        f = tree / P60490_REL
        raw = f.read_bytes()
        h0 = hashlib.sha256(raw).hexdigest()
        rec = {"file": str(f), "sha_before": h0, "pre_expected": P60490_PRE, "post_expected": P60490_POST}
        if h0 == P60490_POST:
            rec["applied"] = "already_applied"
        elif h0 != P60490_PRE:
            raise RuntimeError(f"PATCH_60490_PRE_SHA_MISMATCH: {h0} (expected Merlin ad42e37 {P60490_PRE})")
        else:
            new = apply_unified(raw.decode("utf-8"), P60490).encode("utf-8")
            if hashlib.sha256(new).hexdigest() != P60490_POST:
                raise RuntimeError("PATCH_60490_POST_SHA_MISMATCH: " + hashlib.sha256(new).hexdigest())
            tmp = f.with_name(f.name + ".nb1tmp")
            tmp.write_bytes(new)
            os.replace(tmp, f)
            rec["applied"] = "applied"
        for pyc in (f.parent / "__pycache__").glob("qsa.*.pyc"):
            pyc.unlink()
        data = f.read_bytes()
        rec.update(sha_after=hashlib.sha256(data).hexdigest(), marker=P60490_MARKER.encode() in data)
        ext = tree / "nb1_worker_ext.py"
        ext.write_text(NB1_EXT_SRC)
        rec["worker_ext"] = {"file": str(ext), "sha256": hashlib.sha256(ext.read_bytes()).hexdigest()}
        cp = subprocess.run([py, "-c", "import py_compile, sys\nfor f in sys.argv[1:]: py_compile.compile(f, doraise=True)", str(f), str(ext)],
                            capture_output=True, text=True, timeout=300)
        rec["py_compile"] = {"rc": cp.returncode, "err": cp.stderr[-400:]}
        origin_ok = True
        if not FAKE:
            envp = {k: v for k, v in os.environ.items() if k != "PYTHONPATH"}
            envp["PYTHONPATH"] = str(tree)            # what Merlin's build() exports for the server
            cp2 = subprocess.run([py, "-c", "import importlib.util as u; print(u.find_spec('vllm').origin); print(u.find_spec('nb1_worker_ext').origin)"],
                                 capture_output=True, text=True, timeout=300, env=envp)
            rec["vllm_origin"] = cp2.stdout.strip()[-400:]
            origin_ok = all(l.startswith(str(tree)) for l in cp2.stdout.strip().splitlines()[-2:]) and len(cp2.stdout.strip().splitlines()) >= 2
        if rec["sha_after"] != P60490_POST or not rec["marker"] or cp.returncode or not origin_ok:
            raise RuntimeError("PATCH_60490_VERIFY_FAILED: " + json.dumps({k: rec.get(k) for k in ("sha_after", "marker", "py_compile", "vllm_origin")})[:600])
        rec["ok"] = True
        rec["forward_test"] = "B1's greedy oracle vs RC2's recorded FP8 rows (unpatched RC2 FP8; B1 adds text-only): B1 oracle.vs_rc2_fp8"
        return rec


    # ---- host memory: previous engine gone, our leaked shm removed, page cache dropped (measured), Merlin's rule
    def cgroup_snapshot(tag):
        """memory.current / stat / events / pressure (first 12 kB each) to hostmem/<tag>.txt; key numbers returned."""
        rec, txt = {"tag": tag}, []
        for n in ("memory.current", "memory.stat", "memory.events", "memory.pressure"):
            try:
                s = (Path("/sys/fs/cgroup") / n).read_text()[:12000]
            except Exception:
                continue
            txt.append(f"--- {n} ---\n{s}")
            if n == "memory.current":
                rec["current_mib"] = int(s.strip()) >> 20
            elif n == "memory.events":
                rec["events"] = {a: int(b) for a, b in (l.split() for l in s.splitlines() if len(l.split()) == 2)}
            elif n == "memory.pressure":
                rec["pressure"] = s.strip().splitlines()[:2]
        try:
            (HOSTMEM / f"{tag}.txt").write_text("\n".join(txt))
        except Exception:
            pass
        rec["host_mem"] = host_mem()
        return rec


    ENGINE_RX = re.compile(r"vllm|PleOffload|ple_offload|EngineCore|merlin_off/venv", re.I)


    def engine_procs():
        """Processes of an engine (vLLM server, workers, PLE offload) other than this notebook; None off Linux."""
        if not Path("/proc/self/stat").exists():
            return None
        me, out = os.getpid(), []
        for d in Path("/proc").glob("[0-9]*"):
            try:
                pid = int(d.name)
                if pid == me:
                    continue
                cmd = (d / "cmdline").read_bytes().replace(b"\0", b" ").decode(errors="replace")
                if ENGINE_RX.search(cmd) and "py_compile" not in cmd:
                    out.append([pid, cmd[:160]])
            except Exception:
                pass
        return out


    def clear_engine_procs():
        left0 = engine_procs()
        rec = {"found": left0}
        if left0:
            for pid, _ in left0:
                try:
                    os.kill(pid, 9)
                except Exception:
                    pass
            time.sleep(10)
            rec["after_kill"] = engine_procs()
        rec["ok"] = not (rec.get("after_kill") if left0 else left0)
        return rec


    def drop_page_cache():
        """posix_fadvise(DONTNEED) on every checkpoint file (merged dir symlinks resolved + the Model mounts); only after the
        previous server is dead (never on the pinned PLE pages of a live server). A measured attempt, not an assumed fix."""
        if not hasattr(os, "posix_fadvise"):
            return {"available": False}
        t, seen, n, b, err = time.time(), set(), 0, 0, 0
        roots = [CKPT] + [v[0] for v in PARTS.values() if v] + ([PLE_DIR] if PLE_DIR else [])
        for root in roots:
            for dp, _, fns in os.walk(str(root)):
                for x in fns:
                    p = os.path.realpath(os.path.join(dp, x))
                    if p in seen:
                        continue
                    seen.add(p)
                    try:
                        fd = os.open(p, os.O_RDONLY)
                        try:
                            os.posix_fadvise(fd, 0, 0, os.POSIX_FADV_DONTNEED)
                            b += os.fstat(fd).st_size
                            n += 1
                        finally:
                            os.close(fd)
                    except OSError:
                        err += 1
        return {"available": True, "files": n, "gib": round(b / 2 ** 30, 1), "errors": err, "sec": round(time.time() - t, 1)}


    def host_ram_gate(tag):
        before = cgroup_snapshot(tag + "_before_drop")
        drops, tries = [drop_page_cache()], 0
        after = host_mem()
        while True:
            av = after.get("avail_mib", after.get("MemAvailable_mib"))
            if av is None:
                ok = bool(FAKE)               # local harness only; on Kaggle an unreadable host is never "enough"
                why = "no cgroup / meminfo reading" + (" (local harness: skipped)" if FAKE else ": HOST_RAM_GATE fails closed")
                break
            if av >= RAM_NEED_MIB:
                ok, why = True, f"avail {av} MiB >= {RAM_NEED_MIB}"
                break
            if FAKE:                          # local / CPU-kit harness only (a 30 GiB CPU box): recorded, never enforced
                ok, why = True, f"avail {av} MiB < {RAM_NEED_MIB} MiB (local harness: recorded, not enforced)"
                break
            tries += 1
            if tries > 3:
                ok, why = False, f"HOST_RAM_GATE: avail {av} MiB < {RAM_NEED_MIB} MiB after {tries} page-cache drops"
                break
            time.sleep(20)
            drops.append(drop_page_cache())
            after = host_mem()
        return {"ok": ok, "why": why, "need_mib": RAM_NEED_MIB, "before": before, "after_drop": cgroup_snapshot(tag + "_after_drop"),
                "drops": drops}


    _boot_gate_rc2, _shm_cleanup_rc2 = boot_gate, shm_cleanup
    BOOT = {"deadline": None, "fired": None, "tag": "boot"}


    def boot_gate():
        """RC2's GPU release gate (< 150 MiB per card), the previous engine's processes gone, then the host-RAM gate."""
        g = _boot_gate_rc2()
        if g.get("ok") is not True:
            return g
        g["engine_procs"] = clear_engine_procs()
        if not g["engine_procs"]["ok"]:
            g["ok"], g["why"] = False, "ENGINE_PROCS_LEFT: " + json.dumps(g["engine_procs"].get("after_kill"))[:300]
            return g
        h = host_ram_gate(BOOT["tag"])
        g["host_ram"] = h
        if not h["ok"]:
            g["ok"], g["why"] = False, h["why"]
        return g


    def shm_cleanup(before):
        """RC2's /dev/shm cleanup (this boot's torch_/psm_/vllm/ple/nccl/sem.mp-/cuda.shm entries) + the loky semaphores the
        RC2 log reported leaked at shutdown (sem.loky-*), only when created during this boot."""
        out = _shm_cleanup_rc2(before)
        out["removed_loky"] = []
        try:
            for p in sorted(SHM.iterdir()):
                if p.name not in before and re.match(r"sem\.loky-", p.name):
                    try:
                        p.unlink()
                        out["removed_loky"].append(p.name)
                    except Exception:
                        pass
        except Exception:
            pass
        return out


    class LoadMonitor(threading.Thread):
        """Every 10 s from launch until ready: per process of the server's session, major faults and /proc/<pid>/io
        (rchar, read_bytes) + the cgroup current; a slow worker (RC2: 873 s vs 125 s) becomes diagnosable."""
        def __init__(self, name):
            super().__init__(daemon=True)
            self.sname, self.stop_ev, self.path, self.last = name, threading.Event(), OUT / f"load_monitor_{name}.jsonl", None

        def sample(self, sid):
            rows = []
            for d in Path("/proc").glob("[0-9]*"):
                try:
                    st = (d / "stat").read_text()
                    rp = st.rindex(")")
                    f = st[rp + 2:].split()
                    if int(f[3]) != sid:
                        continue
                    io = dict(l.split(": ", 1) for l in (d / "io").read_text().splitlines() if ": " in l)
                    rows.append([int(d.name), st[st.index("(") + 1:rp][:24], int(f[9]), int(io.get("rchar", 0)) >> 20,
                                 int(io.get("read_bytes", 0)) >> 20])
                except Exception:
                    pass
            return rows

        def run(self):
            while not self.stop_ev.is_set():
                srv = next((x for x in list(L.LIVE) if x.name == self.sname), None)
                if srv is not None and srv.proc is not None and Path("/proc/self/stat").exists():
                    rec = {"t": round(time.time() - T_START, 1), "procs[pid,comm,majflt,rchar_mib,read_mib]": self.sample(srv.proc.pid),
                           "cgroup_mib": (host_mem() or {}).get("cgroup_cur_mib")}
                    self.last = rec
                    try:
                        with open(self.path, "a") as fh:
                            fh.write(json.dumps(rec) + "\n")
                    except Exception:
                        pass
                    if srv.ready_sec is not None:
                        break
                self.stop_ev.wait(10)


    # ---- per-boot watchdog
    def boot_left():
        d = BOOT["deadline"]
        return min(left(), (d - time.time()) if d else float("inf"))


    def due(sec):
        return boot_left() > sec and not ABORT["why"]


    def watched(body, cap_sec, name):
        """The boot body gets `cap_sec`; every step checks due(); at cap + 300 s the server is killed (hard backstop)."""
        def b(ss):
            BOOT.update(deadline=time.time() + cap_sec, fired=None)

            def fire():
                BOOT["fired"] = name
                for x in ss:
                    try:
                        x.kill()
                    except Exception:
                        pass
            tm = threading.Timer(cap_sec + 300, fire)
            tm.daemon = True
            tm.start()
            try:
                o = body(ss)
                LIVE["out"] = o if isinstance(o, dict) else None   # R2: step() keeps it if anything after the body raises
            finally:
                tm.cancel()
                BOOT["deadline"] = None
            if BOOT["fired"]:
                o["boot_watchdog"] = f"FIRED after {cap_sec + 300:.0f} s: server killed"
            return o
        return b


    # ---- server facts read from the log and from the workers
    def _pick(t, rx, n=6):
        return [l.strip()[:300] for l in t.splitlines() if re.search(rx, l)][:n]


    def server_caps(t, argv=()):
        na = next((l for l in t.splitlines() if "non-default args:" in l), "")
        caps = {"source": "log" if na else "argv"}
        for k in ("max_num_seqs", "max_num_batched_tokens", "block_size", "max_model_len", "kv_cache_memory_bytes", "num_speculative_tokens"):
            m = re.search(rf"'{k}': (\d+)", na)
            caps[k] = int(m.group(1)) if m else None
        for k in ("kv_cache_dtype", "mamba_ssm_cache_dtype", "mamba_cache_mode", "worker_extension_cls"):
            m = re.search(rf"'{k}': '([^']+)'", na)
            caps[k] = m.group(1) if m else None
        m = re.search(r"'language_model_only': (True|False)", na)
        caps["language_model_only"] = m.group(1) == "True" if m else False
        m = re.search(r"'cudagraph_capture_sizes': \[([\d, ]+)\]", na)
        caps["capture_sizes"] = [int(x) for x in m.group(1).split(",")] if m else None
        m = re.findall(r"Setting attention block size to (\d+) tokens", t)
        if m:
            caps["block_size"] = int(m[-1])
        if not na:                                     # fallback (the E23 fake has no args line): the argv, last wins
            a = [str(x) for x in argv]
            for flag, key in (("--max-num-seqs", "max_num_seqs"), ("--block-size", "block_size")):
                idx = [i for i, x in enumerate(a) if x == flag]
                if idx and idx[-1] + 1 < len(a):
                    caps[key] = int(a[idx[-1] + 1])
        caps["block_size"] = caps.get("block_size") or BLOCK
        sizes = caps.get("capture_sizes") or []
        k = caps.get("num_speculative_tokens") or 3
        caps["captures_cover_seqs_x_1pk"] = bool(sizes) and caps.get("max_num_seqs") is not None and max(sizes) >= caps["max_num_seqs"] * (1 + k)
        return caps


    def pool_facts(t):
        f = {}
        m = re.findall(r"GPU KV cache size: ([\d,]+) tokens", t)
        f["kv_tokens"] = int(m[-1].replace(",", "")) if m else None
        m = re.findall(r"Maximum concurrency for ([\d,]+) tokens per request: ([\d.]+)x", t)
        f["max_concurrency"] = float(m[-1][1]) if m else None
        f["max_concurrency_tokens"] = int(m[-1][0].replace(",", "")) if m else None     # R2: M of the line (F_log)
        m = re.findall(r"Padding mamba page size by ([\d.]+)%", t)
        f["mamba_pad_pct"] = float(m[-1]) if m else None
        f["min_block_for_mamba"] = math.ceil(BLOCK / (1 + f["mamba_pad_pct"] / 100)) if m else None
        f["kv_group_sizes"] = (re.findall(r"kv cache group sizes \(([^)]*)\)", t) or [None])[-1]
        f["side_cache_layout"] = _pick(t, r"Side-cache layout", 2)
        f["initial_free_reserved_gib"] = [[float(a), float(b)] for a, b in re.findall(r"Initial free memory ([\d.]+) GiB, reserved ([\d.]+) GiB", t)][:4]
        f["model_load_gib_sec"] = [[float(a), float(b)] for a, b in re.findall(r"Model loading took ([\d.]+) GiB memory and ([\d.]+) seconds", t)][:4]
        f["graph_capture_sec_gib"] = [[int(a), float(b)] for a, b in re.findall(r"Graph capturing finished in (\d+) secs, took ([\d.]+) GiB", t)][:4]
        f["rank_load_gib"] = {int(p) * 2 + int(q): float(g) for p, q, g in re.findall(
            r"\(Worker_PP(\d)_TP(\d)\S*(?: pid=\d+)?\) INFO [^\n]*?Model loading took ([\d.]+) GiB memory", t)}
        f["rank_load_sec"] = {int(p) * 2 + int(q): float(g) for p, q, g in re.findall(
            r"\(Worker_PP(\d)_TP(\d)\S*(?: pid=\d+)?\) INFO [^\n]*?Model loading took [\d.]+ GiB memory and ([\d.]+) seconds", t)}
        f["rank_graph_gib"] = {int(p) * 2 + int(q): float(g) for p, q, g in re.findall(
            r"\(Worker_PP(\d)_TP(\d)\S*(?: pid=\d+)?\) INFO [^\n]*?Graph capturing finished in \d+ secs, took ([\d.]+) GiB", t)}
        f["ssm_dtype_lines"] = _pick(t, r"mamba_ssm_dtype|mamba-ssm-cache-dtype")
        f["gdn_fallback_lines"] = _pick(t, r"Falling back to the Triton GDN spec decode path")
        f["share_workspace_lines"] = _pick(t, r"MERLIN_SHARE_DRAFT_WORKSPACE")
        f["mm_warmup_lines"] = _pick(t, r"Multi-modal warmup completed")
        f["host_ram_lines"] = _pick(t, r"host memory available now|Cgroup memory preflight|Skipping auto-prefetch", 6)
        f["sched_warn_lines"] = _pick(t, r"max_num_scheduled_tokens", 2)
        f["oom_lines"] = _pick(t, r"OutOfMemoryError|CUDA out of memory", 4)
        f["static_scale_lines"] = _pick(t, r"applied static K/V scales", 8)
        f["default_scale_lines"] = _pick(t, r"DEFAULT 1\.0|no static calibration", 4)    # audit 2: the MTP layer's QSA FP8 KV
        f["ext_lines"] = _pick(t, r"Injected .*NB1WorkerExt|nb1_worker_ext", 2)
        f["shm_leak_lines"] = _pick(t, r"leaked (semaphore|shared_memory) objects", 4)
        return f


    def graph_facts(t):
        caps = sorted({(a, int(c)) for a, b, c in re.findall(r"Capturing CUDA graphs \((\w+)\):\s*100%\|[^|]*\|\s*(\d+)/(\d+)", t)})
        return {"captured": caps, "resolved_modes": _pick(t, r"resolved cudagraph modes before capture", 8),
                "draft_identity": _pick(t, r"e2-identity\[.*role=draft", 4), "recoverssm_commit": _pick(t, r"\[recoverssm-commit\]"),
                "recoverssm_path": _pick(t, r"RecoverSSM path taken", 4), "jit": jit_kernels(t)}


    def jit_kernels(t):
        return re.findall(r"JIT compilation during inference: (\w+)", t)


    def nccl_transport(t):
        via = Counter(re.findall(r"NCCL INFO Channel \d+/\d+ ?: ?\d+\[\d+\] -> \d+\[\d+\] (?:\[\w+\] )?via (\S+)", t))
        return {"channel_via": dict(via), "net": sorted(set(re.findall(r"NCCL INFO (Using network \w+|NET/\w+ : Using [^\n]{0,60})", t)))[:6],
                "comm_inits": len(re.findall(r"NCCL INFO comm 0x[0-9a-f]+ rank \d+ nranks \d+", t)),
                "pynccl_groups": _pick(t, r"all-reduce backends .* for group", 6),
                "debug_on": "NCCL INFO" in t}


    def rpc_cache_info(port):
        """The read-only worker extension over /collective_rpc (dev mode): actual cache tensor dtypes, specs, free memory."""
        body = {"method": "nb1_cache_info", "timeout": 120}
        try:
            r = json.loads(L.U.urlopen(L.U.Request(f"http://127.0.0.1:{port}/collective_rpc", data=json.dumps(body).encode(),
                                                   headers={"Content-Type": "application/json"}), timeout=180).read())
            res = r.get("results") or []
        except Exception as e:
            return {"error": repr(e)[:300]}
        out = {"ranks": res}
        dts = sorted({x["dtype"] for w in res if isinstance(w, dict) for g in (w.get("cache_tensors") or [])
                      if "mamba" in g.get("module", "").lower() or "gdn" in g.get("module", "").lower() or "linear" in g.get("module", "").lower()
                      for x in g.get("tensors") or []})
        out["recurrent_tensor_dtypes"] = dts
        out["num_gpu_blocks"] = sorted({w.get("num_gpu_blocks") for w in res if isinstance(w, dict)} - {None})
        out["free_mib_per_rank"] = [((w or {}).get("mem") or {}).get("free_mib") for w in res if isinstance(w, dict)]
        pads = []
        for w in res:
            for s in ((w or {}).get("kv_cache_specs") or []) if isinstance(w, dict) else []:
                if s.get("unpadded_page_bytes") and s.get("page_size_bytes"):
                    pads.append({"rank": w.get("rank"), "type": s.get("type"), "layers": s.get("layers"), "state_dtypes": s.get("state_dtypes"),
                                 "padded": s["page_size_bytes"], "unpadded": s["unpadded_page_bytes"],
                                 "pad_pct": round(100 * (s["page_size_bytes"] - s["unpadded_page_bytes"]) / s["unpadded_page_bytes"], 2)})
        out["mamba_padding"] = pads[:16]
        return out


    def rpc(port, method, *args, timeout=120):
        """POST /collective_rpc (dev mode): a worker method by name with string args; the per-rank results or the error."""
        body = {"method": method, "args": [str(a) for a in args], "timeout": timeout}
        try:
            r = json.loads(L.U.urlopen(L.U.Request(f"http://127.0.0.1:{port}/collective_rpc", data=json.dumps(body).encode(),
                                                   headers={"Content-Type": "application/json"}), timeout=timeout + 60).read())
            return {"results": r.get("results")}
        except Exception as e:
            return {"error": repr(e)[:300]}








    def scales_dump():
        """The static QSA K/V scales file (all values) + which layers it covers; the MTP layer is not in it (default 1.0)."""
        p = CKPT / "qsa_kv_scales_262k.json"
        try:
            d = json.loads(p.read_text())
        except Exception as e:
            return {"error": repr(e)[:200]}
        lay = sorted(int(m.group(1)) for k in d for m in [re.search(r"layers\.(\d+)\.", k)] if m)
        ks = [v.get("k_scale") for v in d.values() if isinstance(v, dict)]
        vs = [v.get("v_scale") for v in d.values() if isinstance(v, dict)]
        return {"file": str(p), "sha256": hashlib.sha256(p.read_bytes()).hexdigest(), "values": d, "layers": lay, "n": len(d),
                "k_scale_min_max": [min(ks), max(ks)] if ks else None, "v_scale_min_max": [min(vs), max(vs)] if vs else None,
                "mtp_layer_in_file": any("mtp" in k for k in d)}


    def free_per_card(rec, name):
        """MiB free per card = total - the highest used reading of this boot (after ready, end, every window peak)."""
        srv = ((rec or {}).get("servers") or {}).get(name) or {}
        rows = [r for r in (srv.get("gpu_mem_after_ready"), srv.get("gpu_mem_end")) if r]
        if not rows:
            return None
        tot = {i: t for row in rows for i, _, t in row}
        used = {i: max(u for row in rows for j, u, _ in row if j == i) for i in tot}
        st = (rec or {}).get("steady")             # R2: nb1_ladder's steady holds "_plan" (list), "_fit" (dict), "_seqs_cap" (int)
        ws = list(st.values()) if isinstance(st, dict) else []
        for w in ws + [(rec or {}).get("profile")]:
            if not isinstance(w, dict):            # R2: only window dicts carry gpu_mem_peak_mib
                continue
            pk = w.get("gpu_mem_peak_mib")
            for i, u in enumerate(pk if isinstance(pk, list) else []):
                if i in used and isinstance(u, (int, float)):
                    used[i] = max(used[i], u)
        return [tot[i] - used[i] for i in sorted(tot)]


    def free_after_ready(rec, name):
        srv = ((rec or {}).get("servers") or {}).get(name) or {}
        row = srv.get("gpu_mem_after_ready")
        return [t - u for _, u, t in row] if row else None


    # ---- KV accounting: pool blocks from usage denominators; cold-cache cumulative admission (physical snapshots)
    def kvu(port):
        return L.prom(port).get(L.KVU)
























    F_MAX_BLOCKS = 40                                # R2: a per-request fixed-block F above 40 blocks is not physical here
    FIT_MIN_SAMPLES = 3                              # R2 audit N1-6: a fit is trusted only with >= 3 all-resident snapshots,
    FIT_MAX_RESID_BLOCKS = 2.0                       # a max |residual| <= 2 blocks
    FIT_LOG_TOL_BLOCKS = 1                           # and |ceil(fit F) - log F| <= 1 block
    F_LOG_SOURCE = "server max-concurrency line (this boot)"












    def profiler_tools():
        """ncu / nsys availability (DRAM bytes per stage need a server LAUNCHED under one of them: a separate boot)."""
        out = {}
        cands = ["ncu", "nsys", "/usr/local/cuda/bin/ncu", "/usr/local/cuda/bin/nsys"]
        try:
            eng = MERLIN_ENG if isinstance(MERLIN_ENG, dict) else {}
            if eng.get("cuda_home"):
                cands += [eng["cuda_home"] + "/bin/ncu", eng["cuda_home"] + "/bin/nsys"]
        except Exception:
            pass
        for c in cands:
            path = shutil.which(c) if "/" not in c else (c if os.path.exists(c) else None)
            if path:
                try:
                    v = subprocess.run([path, "--version"], capture_output=True, text=True, timeout=60).stdout.strip()[:200]
                except Exception as e:
                    v = repr(e)[:100]
                out[c] = {"path": path, "version": v}
        return {"found": out, "dram_bytes": "not measured in NB1: ncu / nsys cannot attach to a running vLLM server; DRAM bytes per "
                "stage need a boot launched under ncu (dram__bytes_read.sum on the Marlin MoE + dense kernels) or nsys: NB3 / NB4 item",
                "torch_profiler_window": "the PP2 trace window runs after the ladder, on its own streams; no benchmark window overlaps it"}


    # ---- requests with usage (cached tokens), greedy logprobs and teacher-forced rows with the cache counters








    # ---- JIT warm-up (excluded from every metric) and per-position acceptance
    def warmup(port, n, secs=None):
        """Multi-stream 2k decode, ramped 1 -> n streams, excluded from every metric: compiles the kernels RC2 saw compiled
        during inference (_fill_num_accepted_kernel, _causal_conv1d_update_kernel, _gdn_recoverssm_verify_kernel,
        _ple_conv_kernel, _ple_conv_writeback_kernel) before any measured window."""
        secs = secs or (45.0 if not FAKE else 4.0)
        srv = next((x for x in list(L.LIVE) if x.port == port), None)
        j0 = jit_kernels(srv.log()) if srv else []
        ss, t0 = [], time.time()
        try:
            for i in range(n):
                g = L.Stream(port, PROMPTS["2k"][i % len(PROMPTS["2k"])], 4096, temperature=TEMP, seed=900 + i, ignore_eos=True)
                g.start()
                ss.append(g)
                time.sleep(min(3.0, secs / max(1, 2 * n)))
            while time.time() - t0 < secs:
                time.sleep(1)
        finally:
            for g in ss:
                g.stop()
            for g in ss:
                g.join(10)
        L.wait_idle(port, 60)
        j1 = jit_kernels(srv.log()) if srv else []
        return {"streams": n, "sec": round(time.time() - t0, 1), "jit_before": j0, "jit_compiled_in_warmup": j1[len(j0):],
                "errors": sorted({g.err for g in ss if g.err})[:3]}


    def accept_pos(port):
        try:
            txt = L.U.urlopen(f"http://127.0.0.1:{port}/metrics", timeout=15).read().decode("utf-8", "replace")
        except Exception:
            return None
        pos = {}
        for m in re.finditer(r"^vllm:spec_decode_num_accepted_tokens_per_pos_total\{([^}]*)\}\s+(\S+)", txt, re.M):
            p = re.search(r'position="(\d+)"', m.group(1))
            if p:
                pos[int(p.group(1))] = pos.get(int(p.group(1)), 0.0) + float(m.group(2))
        return {"pos": pos, "drafts": L.prom(port).get(L.DRF, 0.0)}


    def _prefill_done(r, n):
        tail = ((r.get("admission") or {}).get("tail") or [])
        t = tail[-1] if tail else None
        return bool(t) and t[1] == n and t[2] == 0 and t[3] >= n


    def _req_lines():
        try:
            with open(REQ_LOG) as fh:
                return sum(1 for _ in fh)
        except Exception:
            return 0


    def _ttfts(port, start_line):
        out = []
        try:
            with open(REQ_LOG) as fh:
                for i, l in enumerate(fh):
                    if i >= start_line:
                        r = json.loads(l)
                        if r.get("port") == port and r.get("ttft") is not None:
                            out.append(r["ttft"])
        except Exception:
            pass
        return out


    def _counters(port):
        try:
            m = L.prom(port)
            return m.get(L.PROMPT, 0.0), m.get("vllm:prefix_cache_hits_total", 0.0)
        except Exception:
            return None, None


    def window(port, s, band, n, max_new=None, secs=None):
        """One steady window, timed only after every stream finished admission + prefill (the lab's settle needs all running
        streams to have emitted and be gaining, then an explicit check of the last admission sample; Merlin's cost-aware
        admission may hold a cold miss up to 120 s, inside the lab's >= 420 s admission limit); a window with prefill inside is
        retried once. Recorded: tick_ms (one engine step = one micro-batch of C/2 requests under PP2) AND cycle_ms (= PP x
        tick, the per-request advance time), per-request TTFT, uncached prefill tok/s (prompt minus prefix-hit tokens),
        retained (idle) blocks before the window, per-position acceptance."""
        retained_before = None
        if L.wait_idle(port, 60):
            retained_before = kvu(port)
        def run():
            if max_new is None:                 # RC2 / E23 levels(): MAX_NEW[band], WIN, the budget / KV-bound guards
                return levels(port, band, [n], server=s, temperature=TEMP, prefill_tok_s=PREFILL["tok_s"]).get(f"{band}@{n}") or {}
            return L.steady(port, PROMPTS[band], n, secs=secs or WIN, max_new=max_new, temperature=TEMP, prefill_tok_s=PREFILL["tok_s"])
        a0, c0, l0 = accept_pos(port), _counters(port), _req_lines()
        r = run()
        if r.get("status") == "INCONCLUSIVE_PREFILL_IN_WINDOW" and due(WIN + 120 + n * BANDS[band] / max(500.0, PREFILL["tok_s"])):
            c0, l0 = _counters(port), _req_lines()
            r = dict(run(), retried_after="INCONCLUSIVE_PREFILL_IN_WINDOW")
        a1, c1 = accept_pos(port), _counters(port)
        r["prefill_done_before_window"] = _prefill_done(r, n)
        r["running_eq_level"] = r.get("running_min") == r.get("running_max") == n
        if r.get("status") == "STEADY" and not (r["running_eq_level"] and r["prefill_done_before_window"]):
            r["status"] = "INCONCLUSIVE_RUNNING_NE_LEVEL" if not r["running_eq_level"] else "INCONCLUSIVE_PREFILL_NOT_DONE"
        if r.get("step_ms"):
            r["tick_ms"] = r["step_ms"]
            r["cycle_ms"] = round(PP * r["step_ms"], 1)
            r["requests_per_tick"] = round(n / PP, 2)
            r["microbatches_per_s"] = round(1000.0 / r["step_ms"], 2)
            r["wall_clock_tok_s"] = r.get("tok_s")
            r["tick_note"] = ("tick_ms = step_ms = one PP tick (one completed micro-batch of C/2 requests); cycle_ms = 2 ticks = the "
                              "per-request advance time; microbatches_per_s = completed micro-batches per second; wall_clock_tok_s = "
                              "generated tokens / window seconds")
        adm = (r.get("admission") or {}).get("sec")
        if None not in (c0[0], c1[0]) and adm:
            unc = (c1[0] - c0[0]) - (c1[1] - c0[1])
            r["prefill_uncached_tokens"] = int(unc)
            r["prefill_tok_s_uncached"] = round(unc / adm, 1)
            r["prefill_note"] = "admission.prefill_tok_s counts cached prompt tokens; prefill_tok_s_uncached does not (incl. a retry)"
        r["ttft_per_request"] = _ttfts(port, l0)
        if retained_before is not None:
            r["retained_usage_before"] = retained_before
        if a0 and a1 and a1["drafts"] > a0["drafts"]:
            r["accept_rate_per_position_incl_admission"] = {p: round((a1["pos"].get(p, 0) - a0["pos"].get(p, 0)) / (a1["drafts"] - a0["drafts"]), 3)
                                                            for p in sorted(a1["pos"])}
        return r




    # ---- prefix continuation (2-turn replay) and after an abort






    # ---- PP2 trace window: every rank's trace, stage overlap, idle, verify rows per micro-batch
    SCOPE_ROWS = re.compile(r"^execute_context_(\d+)\((\d+)\)_generation_(\d+)\((\d+)\)$")












    CAPTURE_SIZES = None
    ROUTING_FILE = OUT / "nb1_routing_ids.npz"   # NB3 reads it (dataset foysalemonshanto/e25-nb1-routing-ids after a run)






    def quality_gate(o, ref):
        """RC2's fp8_gate with the reference as a parameter (B1 vs RC2's recorded FP8 rows, B2 / B3 vs B1)."""
        vs = ((o.get("oracle") or {}).get("vs_" + ref) or {}).get("status")
        if (o.get("sampled") or {}).get("ok") is not True:
            return "FAIL_SAMPLED"
        if (o.get("probes") or {}).get("ok") is not True and not FAKE:
            return "FAIL_PROBES"
        orc = o.get("oracle") or {}
        if any(orc.get("errors") or []) or any(orc.get("garbage") or []) or vs == "FAIL_HIGH_MARGIN":
            return "FAIL"
        if orc.get("complete") is True and vs in CLEAN:
            return "PASS"
        return "INCONCLUSIVE"


    def flag_map(argv):
        m, a, i = {}, [str(x) for x in argv], 0
        while i < len(a):
            if a[i].startswith("--"):
                k, v = a[i], True
                if i + 1 < len(a) and not a[i + 1].startswith("--"):
                    v = a[i + 1]
                    i += 1
                m[k] = v
            i += 1
        return m


    def config_diff(argv, env, kv_bytes):
        """Effective flags (last occurrence wins) and env vs RC2's real FP8 boot."""
        ref, new = flag_map(RC2_FP8["argv_tail"]), flag_map(argv)
        skip = {"--port", "--served-model-name", "--host"}
        flags = {k: [ref.get(k), new.get(k)] for k in sorted(set(ref) | set(new)) if k not in skip and ref.get(k) != new.get(k)}
        keys = set(RC2_FP8["env"]) | {k for k in env if k.startswith(("VLLM_", "NCCL_", "KV_", "P2P", "SCALES", "MERLIN_"))}
        envd = {k: [RC2_FP8["env"].get(k), env.get(k)] for k in sorted(keys)
                if k not in ("VLLM_PORT", "MASTER_PORT") and RC2_FP8["env"].get(k) != env.get(k)}
        return {"flags": flags, "env": envd, "kv_bytes": [RC2_FP8["kv_bytes"], kv_bytes]}


    def boot_facts(s, o, name):
        t = s.log() or ""
        o["caps"] = server_caps(t, s.argv)
        o["pool"] = pool_facts(t)
        o["graphs"] = graph_facts(t)
        o["nccl"] = nccl_transport(t)
        o["workers"] = rpc_cache_info(s.port)
        o["host_after_ready"] = cgroup_snapshot(name + "_after_ready")
        env = dict((R["setup"].get("merlin_plans") or {}).get(name, {}).get("env_keys") or {})
        env.update(NB1_ENV.get(name) or {})
        o["config_diff"] = config_diff(s.argv, env, NB1_KV.get(name))
        return o
    save()


if not RERUN:
    # ==================================================================== CELL 7 — E27 NBDF: arms Q > D4 > D3 > D7 > D4b (DFlash2 vs MTP K3), long bands (NEW code)
    # The modules and the CELL 7 body are lzma + base85, each sha256-checked here (the readable body = nbdf_code_export.py).
    import importlib, base64, lzma, gzip, types, inspect
    def _unx(b):
        return lzma.decompress(base64.b85decode(b)).decode("utf-8")
    NBDF_LIB_SHA = "086472b4050be828c00f58dac2ccc6a7609cb73658444198e5de47ceeb89a380"                 # nbdf_lib.py (new), nb4t_lib.py (NB4T verbatim), nb4_timeline.py + nb4_ppack.py
    NBDF_LIB_SRC = _unx("{Wp48S^xk9=GL@E0stWa8~^|S5YJf5;kdzn$6WvsXbna~aS1SFih*j!rfewm_Y?31yz*c2z=V$}+l^xG-uzl5b((ZPWK??z?)iv8fk&mx@s6&hE6En58^Xhm$q9Z~pcI1s&~p8O$jyn*9A+JebnsO&rQ@S7jgsWF3~^5JZNbU>`mZz3s<a-ldzd#G_VhylqdARG<qGj)OPQuQdNY4B|H$E(&<M3}-b(pqENbpwx)JOU6Ekwv`M-XFkGe%LONl4IhqJj@T?*@x<<LYU&Rek!hPN3by=WYlQ$Jdhg&>l1B1I!4uY{KZ8Votjv;N|0C3dvIm)2xH$SdYj5FG*9{1I0|VwwNKu9>tby4QP$%D9DjjGj%D{6_sa&lJnf)@N0i$9g@VvyU9iBomm;Y>W{6E_}^V<iU000l7lhCV3taF3t5S$M9_7^5D`=-T=}E0ax$-&+IQ=50EoD(ikP=^Fr%Jr+W4TpHao)eLkI5$R$x&Z2c4@4I5oc_fd0O98?Iz6UC6kfQ|xhzRplKc=s4JucSxW${=rbtPGxgAaWaPo{jt?i)G_0FZOnqu;_duYeIe-{zfI~*%n`!N)YUzHOT<Ivh9%WHX}{IdWZc^inB8kUov){!%ebcXY%aF2npH6szx9unJErRf0P=h0cOImF(?UR9M0)iS5G`4P<&PH`}(3iP>QDKdGjYMG;2z%*LD4x0K37d^llxHNB{riCGrsEg;%JrbT|RN3_n-Ou@f#>c|G8CBC_+<j@i<C+<$X1V^<n;<+nJ(!Pt{pem$f%!{LrXqTysrM;kvH)+oE!bRtcUf@U_zeV}j@@@aJDL!(rRFvwc0n+H`}u&w5&cQ!Qb<;`ntUK*Sh?wlhccX3es3)dZ=)rW}ZYl%l9l-W1ToTM}2`^+rtKiLh(t~q8ryAg&3q;Q-ikulo%_ku}%rANlE%~U!x=v<|e$PSHYuT~1dYuP9t*WBZE9bNRsx-4+=c26<&aJfJAkSlHYQ9!JyKx7TuYn(@Iu2v2VY60jjeVMd?PtgP{YYYS<3Y#_7m>p8(=Te8qU6($;np=}oI40M}@g2sx(W)UZr#}&o){r*M<<EznqCE;v{x>)4NX3A%|A!mqf<dJ{ymjE;Yx)YA;xQPtQS5L9mqP`jT>Z6P1NJE7t$O~5swAwG_~xN`G_yj1wv3qe3i=a!2ZaCvRgZ2fO2^=~2kmlk(La|s04mOWxpR?JLUj;ycp-Bp+Xn7G`Idqleq1neP!Cp)r*anxU}7!+?s?_E{N3HMW$gME2qRg6Gg<ONmuQJm_9m)ut!Pl3+aOPCq915~m&^=3FX>Y$K(~DpQ%9ATxM>P~kkOUFoDv9Gt*>d__gOBr1J@<sZ9+Au>qan&X2^Mh3Vlz(3g$;>J>>NIw&I>-6Rv)nWrMY1FK1L~m>sUYe*^%G8DVOEgknF!B4zEzF0@*Bc8BTGNp!Vf_HxT>FTK8UgdZx<XMO{QE|mvw`=fiUAj2kjZmDf?a1|lh$fU2H=!a4m{qb;o6tIsWSfvw18%xHfl5PCU+vBGvILUtGgF)w~eHw)jA?Le>3IZpG_r8;P^Uakq_8glVqF=9kx3@=Z_4-05#PL<=QX;7l)&i!WBzG_t{caN83)4yV<}B}3_V|GWjgbyaWg{|LipFd~JgMVwQ`TSCe>$<ZU8yH2S>EhER4;bb^h#!tVzEvo@*5GL3M^m`jWyRZIm~aG|7;@PB3fu*@U*WeVCjmi79bNUU}uWp9nx@UPek@7_^tp)rf4s1X*Um-Av4nj%HeA`(}5Uji$wpS`}0H3>}hj3+UguQ>Fu)1+``yBnn8^`kH!Kdh^Of)e>*Yg-VB~&`J^xns#3TV>c@2tqyS<$dTy|mYSAFeCHvrGs#5*i<h;6nV#wruOZS_*2{#mP3rQEFP>O83-l>6#zXl9%h(V;#ZBU~6*%#b}ho!5c(iu+`+N&nspUrxKm?RC_(q?^!>KqJVvH6Rg$DPYU0(7Y}d(JfSA(@5}DZwRUQz$+nxOGp+>TRiTORtZ2uxE&49m!ab1m@cz`rzpmnZkt7(@_68XsY8JPa-lQ!`A;)2G$7TR(-*!l1xY|ve0V3<7$>XqfGrLp#e@2+Yuc(Pe0Azx!v2Pfzd1@QVTXX6!?^OPo?)_+38VAR)LsBAzgBz46>{@+>KJcdtFts6O&zmmReIl=4La&G$7B=BO-lSN&j#Z^gt`<;oM9a!H6MmQnX-`yHvxn5K<A7LWFv8t5e&m)WbDB94(qEt4Gi(@9oqhs=by0h@Sg?lx;*%GPFW2h?@%t%QN2r^V(#<Z%t&~_kxnk(6SBCOFvUNUX68BSE`g)!KY6_9!#V6-azFRxU=FjZ$ijXGe>n;F^oJjG;rM1aZDTYZ??Nm@#R&6H@h>CgcV`%;+w|<m`npa;12Rd;M7k8WXHeVsoyn|p|X9Ld~ZB!V@<jDSP1|h6U2G*A*Sass2_Rx#s6hjgQeuyX6&?~ic9=5eNdW^%VOa@Vgqz`rGt{g>pJ|@;R0i}6`@#Tq^934^FEkAVJ>~PVyYs#LVA{=MwEgBx=r%)kt8IF5D4rcnU~r(uATSvqi=&H#Pt|_;^)c(t-SR49>n0i$4{}m$T;B>LUg0@av~)?xr^3KmWxG}R-4FWg;`P*=lxBg=q|HnrtW1F2qG0V6N>SgQ{JP~dqD!OE(VUTZf?qZE@R@7ux%rdIwt!wnH&Bi6Ncx#cxO+U0~to*lxTIb!?Mf0rV#;*bg9B2DFy>8+7ymO3Cfon>SHJKxv#=riAW*Xugo2>Q`r8w2r4Wj2_&9+g}U_tQdIW=CK<q3s%|FGe>=A2d+=YZG;HDrL%+rHNuF$krkop1Atx&u-aXZ5^@KIW#1Wi=%7Fr^)!SCuJh}?+vKOUKb|r?+j>Fg&v{jz-u*3wpRd*tt67&LmWm&~rvW2sj%q@l8Vmygj?3|_H&(SN&k`n~_4J7m5E8}ka3Q<doo8Eh%Jz5w772JGlN~m`W<j<79(fG96Gwr}y&gR!%xqKQLW>6<&4Tjefr6+}~cwm4<qpJMjDNKH8`KFX;TKhf3L(Dr_^m%YR_3SgO2Q@azz#QQhxI)@GY}zJnY5&pJqXN=4A-!D;B1&p6M)H3fSa?LB#Jc)cNex6dWN1pW+_C2YY<m}m8)BX|UC|!{cxZ!YGnh4RCh5?fKtviK)=<eFf{kQ!i{jqv<+N`+39d5mBI**SOE-Sez6pBBa@Miq$@aTll~WV`ueIxlPhb0aWYRC@E1JtcmnO7LTm1K>%-Es+Vsv>KbMAvb(oHaR8+=lU{%|Znke`&e#Af(-2vI}_2kxo9_kcnwvut~d79`Y@@lDfZ#zNN+0^^DuGWGG3Txlym9F&d^fM<Iu%+v9JhS9-8kGH@;lON67lSsT6p8OBZMI&I8Sq~J6cd7MTtO6^c-eVzO&Me8gQ7j9;r5joxIetAi?)-!v8i{DqMdIrHD7WcjWL_z;i1pX-fOQ$S1_K|my~v5P?ti34QAIj4sJ7&UOpSDTTo49DH?_a`V-hKvG4M}k)UR}SHkG<ytwvXo&eA2)t_Oq=&P&jyG%KfbtsjVLAB-oX?r6Vw2hkm>GsIEtYd}bkx`PI*W{lEIk~eU%<!v_bWAdd04&dgg)S^%Qg<jpLlkj$*-!EdbLM91wa)U{}@}`g}1=XncZsl0N7Je;P*{0q|x8K3K8DwccL&Q7rg!jGO2yfy`?gf{kDTv*=cjWreM5!mlpqXIfIGoyWY3C&&lu6bGi(^?=K^N-PA~1KgQC=Im1jzhXB|W5AWalE%Yw=hki2=JZqjsVchYW2f76E;-?7rmX+s0t!n77Wtf(spPusvTv=pT3>1Q{Whs45NLkJ@knDwB_60P=*wuf;Mcw`^aCR7U0_OLOT3*v|5ui&=?Bl2D}Gv&4o)ykd#;guPQ82Q&s7wBL?Go2Z*obFC~{Op9u)LrzHXLMFarAr&A>eJ>QMzcm%@Knj{uPj-X2AV^8Cm|n9g_X=F*gdmKGD2h1-)xt!Mv;MAxGS-S!VwPJx?uXVx_zUH#02|>{MuSk4;PQTGxeD?M#=&-!LBtSVP2A7Zw;Ew%-45h9JUpF6WrEQ+<X6FGFnyHWZ*!#TL5xOLo7$yLO$*Tf>Z;OngF6NPr(5dBJ6+_#kj08S_MZ{GB&GLA+)%91@LU#c*4q(`q>oq>EI6t}Oos3?EmOY;SwbDa6{4&59^Ky1dJulT4V8V2ZBt%OUsb3z@XdzrVo?6B$2VUu*_ZBT+0ZBc{cKg<+r&~3Xwx6lsyYl7xcz%7ItJV!fPb8KxHEdWkJx_$@wMZpS0z~uLp8X9p5b9etTuIE5HHxgNXA!eHHGbX<df^7PLT5`rlYSsdYr9ViT{V;z*2FnQWc9*(oV{ZB{z#N88vF$f`ld~&p_yBystzXAH#CB<J|GEppgH35`fM-!Y&-g@Fbl}{@zp4>WR9W7mk&IJ=)L`+F_s+7nNgpcvSZ4(fof80R-GsD?{YE=u<oo{WlY#`9MRD*+LdE9&gJKm8qd3WPjc*@LG~YksJ<bt~H@zn_3(T&}Jh2^dP*(YYR1RtL2x&IcLd<(liqFN>3dxNL{-f*p)|F9HmFz;rQB#*`+Td-K~Uop};P2RpYP$b6nT5n{342R3jWwYo&0x#w&OAy?8<O#bQJdOeWXzshWfB(2XI>{RQJ1KP*&Xk{J*N7Nz(R7KS8anbO0d=P!~WOElStWD3)#{|zhE`yP8_xG%xUvXbgMne<hpNELw*SsaWiTTGp7=|BuEoFj<HTk4BzF)^Dc30;MwIb)jh4a#BurxpuDp&~RBOzaTrR|zD}{<tcrStht5h?{jDT{umkbfdLE11KA<!z1Vt{wRC3+^1P|{A=q=j0Gzx>7_Lwft^RwGqn9-XiD_v1&<(cgI5#z?XDps*%!7C3go3x^0^avehy!xhY%Vl(rW-iD+%0_s34G*<Gs$W1<OVfseb)@FHH#1LsIr}e0!8n=)l?{+p48R=M+|r3evGt<84QHO2{{o4KbQxm(0TMuRFZK=YvI(6$Y@g3gmKohkd!HX;`inbXF7tX+ACrRWaQGJo+M)TSJ?063dC5nR^D{e9p#VfZ_hr;~xN&Pu=b73gS-WNq+%kQOiD^vmW)YgqF6WpT>sZI>I0StL!??L{5pgiZPEUiew%$ygf^`*i>2*+n9ZdXYRT?>fBj!9yk5sk1&dkKb4R3d3D&=naXxK@*!Sq&U_2Q-z<ZfL_YvjOyu|;l^X}BkbJKTvSvpu|LEicYC$Yi4q|%xcOc>r9c-gm*c;kp@%`$FA#G?}cI*C#;mVef2wcdW-)5H4pt=ww)Qs3B;inYkK|T8G?;3vzHJ37}$y+03$|<oH3+%ggWqQaH`!qS9)_kq)k=T{AJxmRdI?$n_t<M^2!uzO~tU=tn(gxA~-VxSdx`lT!6XTn|(qqycygd;PXY4Aj^WA2nG0iE@mg2`YD&CgXy|#Q&9gVC5d4`KA+ulh~H`(xF5q})}5Q42UAb{~F(rCi?MAxbhe>buWO{8n;JqanP^oE+N>V&iPei*{4d12m`n}B02gbwO<lewxBb9<iZI0QB0Ew}=gyq{<=O%f6Ch?a+kIX^D{qbxznz<KV2x?Bk&sg=<C2{3$AA*C|pBY`4245}t;Ci-Y|=nC;=7VJ!TPXg09)h1J;&HYJ|gNvr8u-UX${@9_uXgG(_5(GTfx+_*0zIZ(ZNX%4!3zsG0evyzKlbV>U{~}V4Uv|(DlbZGo>ZK~0h1pxah{>pQ^7P6`jCSxED${tOQO*1ft2hc%;f`4p*r0ptN<3n0Zlgm9y*eFLj!Jwe<X?APSlBNaD>CWQ*rj|8o1%M9ANLc9Chbwb2dYLI0!`_qZZp9wycvDl#KQ4y@vX3uNf~fkoa_VGrh1p1#L;I?cY3LeC{#*Aew%O=PAtkFmzSsI2&t0Ju_rta#={E1yoUB1x~Y2@w*skWYNPkRJ0^C3|E-oRf$oeWnbNvA>j<L6Wa_f@mMc!o1xH9{e%}U};dNT0Y+h@u(OJsWvH*PfH1ntF`PLOsObKOg5lbJ=#hTzeR_PIX33+_@u-nj(C3`sd#&0GN7uu;H{#cCrG`fl}_ceOAC#~FB?7plL?J5S*7~s7)^|f4B2BW6PXar1kB7AOsg3>O*X^r5o;x#iP!Ng9V^q1=t1V=!no>2(m@{l9S77=2DpnWT9OFhuYCPG6}*Nn8z!hZ~~slFV=VH6CWaf?DCxOMFg{n*v7Rs*VK$$&5KB%)UdW%agv7Mk<=K!Y$z;K@mtE!$f`aG!Xpr1jTOg4=B#QRT-8B)&>eXcpjF=)4T!=PptgI7sX{$ZuMwpyq9|;rL`Oh=wRDy`9H%dI>wsV<qUi=hME&*a(d?7zKPnjmug)Z-hOJ|Jp<PL?qf<{_ogz(A04Ws?f^dedL&<PHrO4mw!qh)UCF;b_mCse_Kq|QD}a5tV<Ide+fnPK4xNRM>WHa{*k1^@F?vdQUgdQ!&5f@L)JIKM#4{_tn(!{1Z<M)mJUkG&!@BU2n~SB6uzS!LWYxdWF+44%@GT15053NY|$L@ZwN0d4CUK4ebH1RYM$2toD1xWWCagEO8rC~0-jkYAE*;CE>eLF4R`*edQoloiZ^G?GYFMmgeVi_w@Oqi{b;E+F8k~S>3r~gkHZy7MD(E@_$)}u<>H*%h59}VE10)h^@lp@&;|49%he~3pt5DI2?mZL1vPmD`O&j*T7tXb8kYr7w*A+OCG>UY%qx*h238>)qSYX95LeEU8C`AOOPJIJ+AX^>K3$D`FbDEY?La09^sPZgF<_B_F6WqE#=DY7uy?-Lx!fm|D#?L_40G3bS4Sb(-27AU?`jqf85fD^(XVqKsYeG*q=l+fyJ<O{op&jvYac4|R??U0cR4q9YnbuVi<W$*PW{M##C82>Kpt(!xSYX|I3LUamGF>&YhcN!=O^`GiQf1!@H`!x59?}zhY>~Z9e+X5d}|o}VQ2+m>I62)K0a5?AIh*@;hp@WhbDSC0Z}U@hEp}Hqkf*MW}pG3QAj^vN9NVCyB%vje!DZDK((!GQmAL}F_Veke&ba@#k^=da37qblXz4+1PiWKUcXAF?A4UGbu!7zYh$xhn&5F1V|L4OHb!aE;6%%NXiETeYpkpR0;Zv#ui<1<&WL#Hs@GIsTz*+_r2xeG!dI-AYqMNN+>yf~{1w4f9wKsBDv!j&#C(vlgM}z1?up%Sr=qs){6=+0;e|}?K7xJTQM7E)Q1z!SRB6Qax8w#v9Mt9wXWRAh3ksFIQ4bD+$$A18s|SzKN2KG;JC3o1U)rx~ccEhnVRV}i8-OA#=4P@)(9QS@vayM~51mJ~x&YDn)Nm@bKSjji-WfVzs&Ar?b*lQJ0KD~lL0(`0Max}?aAYHX`S6SOSttaRD4dhHlS4{CTdz6eQCWE#i}6P313_Q;cghV|3yYQEs9PB+`WW$|kK5ONI&GJ1i?*ldR-Kak-*%L_{pE@T<U1F0Cjoj7vIIjz;>(X#6&Aup=4s{?yZlIgNc)3U-cZN*HnMrGD6e{UlpG>B_=_-(ez^p_<tbBT;GDWJMC^(ol=1n<Q>47ozZkdU#n{9xeOk>(wcdO_BFL<$tx=*uCmS4U1oT<Q-zXVa?|d|#*-r3eHgMhVCE(QP!)N?td#z1ouXfB@z}-!(?`@O{azJEy5HQQFXXl{7@(I3kLLJgylh<nqz&PS{3tXg^rhzZz#aUjMU5f)RX#$JSG*v08X+R%s*~R4Y>h~|s=`^Vc#0mDX!a2`n6O~M?Oo`&HZ0Wnz97-iWn8?%RXbO9|FmOmXC!`^Li6A6%kGyzo2pLgA2^&<(^D%euh!$DNfiE?tmWVot7wfLGrlyKoeLVYEQlnmIb;l-Rmz`=0xcEd2rt91j7`{6J{Y0+~#@>UYw|?l((D-`pLTaQR^!6q2j+~VH(3cK&8pWY)``krXd3dc7AnP4KyfO>G6(!}rQfdy7ceP~j!8qF(ZCxbyeVu|E+RdXn+;L`K_?j18n$!#ErJ3IG7}-(aa;I7!23n;0pRiKXI`}PR-+%Fi;x7Nr72ZmLC9~ZxrP`ypD{`HlVkw!~^__;#R`h_G>u9TMM9g8#hmwC+ZrEl0rj6g(I%t7DfJuf-AgjU#9s=?RV_coWPQh;v7co2xs5_?!AUI9JVHa#zI`-rjXsA{&3Pwj;$52&FtvaMvoGJ7fhOkSH1hS}ER!hap{WJPZ3$i-1$6+O-62s`kmSl^#(>o}7tL3#knhXgwFTy=8N;leqW^7sDtL2ZYJ*d23WQ_)>AS>}<Set~sNlnZdYuu{;R-_6WMVO)f&0(9W2SFB~fne4Tts20R1ZxDIw9LksT1z)s=3G)3&$@$AEYr}OA(cs4v9zRayVSd7F))Wvs4`c~o$e2hPRVR`+%7am!+3-ho)qqZSKu}gm_d#l|I)4KP|w}-@b=sa=yEC`zdLf!aJnoOzlvP>dj5j(p!Z^;!bpzH^rJ<5<+Y%m3H$R&W4XY3^gP|8*|bEn*rDsYEV&#xF1qoeJHmxc7u`F}l7F!evJ^i>gb3YD3mDdr@QvzII{q%FK9ko~WkRY$Mb&ikjE5tnQC2(XPY92}hHkA}2X982$k4`LHzab!mcxB}m=2DwzF{f%QVkJlUWjpvmWc}nB1r8?2^!}1-<8coggWI9v~ae=<KU*crID>}f#95kOKL@FlZ4vUU${!<^M{-V4!!z;hIG72VpcSDMS?H|AHOO20tgnBF}yVYRb`gSuJIiy-ygU^CG!xEuI$@IdP#lM4g4NksY<hiH>+@Yt=2U~nPy!eLk*X9+lDc9Kn#i!YE#?KU(99OMJ5X#1ziM6)m&M4d33Ua(m&tAKq`sp{ScJjThw7ru7lPr+q1Xe1Bg_#030(eJw1Z?U<IY81=#yIs*i|G$a_&;DCuz)7r5*W=brGpoJ_o4SyfJ-OUijbB~dbub0JlJMFgT0yku)hqZO%n{z71`!iusGg}ppELRQK9Dvem|6+8<(=(_7hDR5Venk-dq^asnOcMy4my(3mSD1`3kPnMEORxu4Eluu%N{hV!l>-kSKU2SwBU{;a6RiyrnCx4yzYNhsj(~WXnd(ra8$aA+gxns=7sC&#lMvq$Kv!dW@j)FED>l*KqqztUSrq6R-2Wnp=0mHHob`!lKoGO77-lK&Z&?TsfFJDO-v=B!uqUbH#^O6>BQl-J_OyQ&sqVE(5XxYqx8#>lZveq4C!prGbbz289VG(V@xLx)<loM4y`68l75>iX+*>4bwP>`MFsiXm@aivK#r&nKs@&+5sg+sSOVjf$$j@~EjewE%~(B%+WiBucz*0~h<{0#KvcF=)Lae1i6`Td;KC~oh;zaAmb9i+$4u@7XO<6|(SiH7j0k8N)+8#dA}?P^g(@;VKxdGZ{@{t$MbWK4(b%De1tG$N1KnAAW}Kw~W`RY6F}RJ`A60RiaBZopi<p6{Zie)mbeWJIGsQvzlJ{Jy}LD(}pFr3f9kq-H;;FbN}Vxxm)e)DHrdBrI|))w~$wzweuvZxINmc`GR}e5bO!{GOuQ0x-?*+NTBRfb&7z?;Y!>5Jx~XBcefZ4E)N>jlUWNJK50f01<F>2FbdRrQR9&cEeV>TPz?F%K|Mb19L1_T-@9>2HRDRDy<&#4#pjZa(tp$d;9Km$C`4@J@ohzbmJA|D6ks8X|KV<mHZR0cb^zcj2~x3t-_xm+5nLfs5zN_^)i1O8C?bHwyg$G2#lfVAR5f(qlgCh(`9$SFqN*N(pGO#oy^N#6NrXlcR(`+*>uFsXCRi|o=GJO9qg%Q!b{#+$k3u&3n{~d)+q<reM%ih=PQZ;{BsU{kVIgnK*d~1w=7Tkm^pc)xPfa-fdmV~AGKc+GU>|s7aN^cWxeksuSr>7^dwE^MmhmiBYmhl8HPz%zrdoq3L2w;q7^P`CEc4KS8FS1kxC*1@<A0u(^X!?SW3u*!p$ke<ZnP(10aXjmuUyPj~TZ<e#owo{lsNF=k)YU@2i^>Nz%zz&_E~E7kQa5cqU~{RsP$<bvom<<Rb`k!>c*F6gIJXzV)FXrJjO$PQmlJfrt6VSn_eH%7CZo_V7G?^(K_fx%Fz5cGEO4%$DziP|7$5=so)526rh!8W7fD^B|VAo~X?3vD+*bYqA{|lsj{iRUfR#ATbp>(xNkQOliobE5R@4^GN>@F2{Jr>}s*Q!gN6ePlxCZNRckLcyejtL_{-RF>Jw>jKe=>W3D9hTx*nJ{*;|$?G0p0wj!<nRP37yN+V4HgwIfqvs3PShC2{^8Rrq%ng)VysUz9W@g_>Z?ke;3-Q;B^2eY?bK^7oVpB&bVQiV(C$iJ3Q8ea2H6$QVAfFUFwUVh(21*^+_#_x~X<dS4mrxK1Thn!%Ie`}&)LZ}4i%z-xlZSxp0;{6YHRogdL5{59M^&c4Ox-1dWWtE)Czu+R1chPcDm!CRwy5o};drCiGF6q?6T{zn*9qE52B%cL<XhYF7%MZl5T&N*a1Dm_PLXtpJGaUQw(EAx4XiBIAPTwIS@==)m&>AAC5~<#)46IB#6So>)Lk%%z-7VMH0J6a;b!ZH$K&Vas-$?~dD}h3|_yfe0e)<3)_Zw-CB%;f23a(&G6`6GI4?J7N+3T`0BiUUGx;lz&G(5iQyHCbXyhp1~pH`1#;NU)KrUZp`6-g3*A;MI$d5wo<PjF-_UB1B{F8M|ws=cWq-cA^;)UT)Yjv3eYQ;}sP?q`rJ3XQ51d*Vf}r<t0)T%o(%ZUTgY9zK4L@u#?PW6EKtT|a+a{tN9BFwv3hb*c^tv*$8<j|!K`UfFzHr)3z0!HY9$J|+rlT{NO}v{6u0T=lgplYLZx$u{-6BtGK^jvMb0mk%6KWJ(gCDNV4D?SpHz(8J$hXL-w5^CS@*LLFIY+o+1d?c?X88g4nj4(-B-o-=X{C}UHJBfB}vUndEDHQzmsr$;w<&sz}N&pLPzx3GYY*CgZVA<;J)@=_l?cbhHfQmsEc%~|2y%Jq*6xGKw4?jwv~m|VlGhca=Sd&cLvvWu^0Puaass8Zh}yoZP39LRd!Aw!2Bz&%oBy0jj@y0xUpiZHd7>rWY9ld7{f%G3#`foT(r+V#A)Y7E&l1{P1`IS?(9dTAFIR#voDt~Ct6fqwGnRuK-038unZf$GzFSI&{-+>I*n7P>|=2V*=1^=5x=)6)S2<z0URG_gR!s!fl6tgF2kt~L1ql_1mD($IrKMj7Vp)?z$6MioAtbUIXCi?&_^f%0(Kdha}}T50#8@4g+~KgtMNlkM172dD1>89-wXv-@CQ2LH)_s~P?7BIesO1RE1;#Wr~%+a_7k#|r^+*I37OH1ZiK)n?C$-FaEazDeq?Y-WG2eW&&@<hoP2u~kMSY)}ts5s?zKu<DnC05(Br5Mg&gmJ*Zmy&_GBr`-20l($*KyoCB~=WwfM>N^nTZh5in$KK8l9=5NA<vfI|FfsC@!6rS}1R-O<*knRmSb;op0iG%Y692ib&m+y)i7vsnn%r+8mcU*UYisvFZdPFTZ{>G){(e<~5EKZ1oW_o_nQlIy@&O}TtSR{P<tHx|y2>r{FPe)Kd?5a~3mKd;OeCxysqMzKihPLby#uk+ayoAy%!20_{~#63Zf8$QSJvbR?xh=8I6$%8xE;LTfSJG)U<Dl0ACmvPjT~j|QbVY~I#5ae<Xn0Ii9Ims1+|{8-xC6BW%#14*fkQqZEmXRzF<o{Qq`7Pz~OU(qvZUiuZ0=|usW()EAZ)gO4_Z0ahHsis7xDvvNa4j&{vgU_Nqog*v-mXVvC%2HlZbR-W-+isnw^xB~nJrLWw7*h?dAF{1aGsh9o=6i1Xr(g%R}|1q?uYkXUeH7(~+~v{;#1ut($=3HQ@77Msvho6_72f6<gPFJTTd`P#-ZaZ?H6V>J<7Ws1aWq3U6_pwVdI0&5o*vVJ~Q)2IA}L)4deUZkZb;B~E0bB0@K<F)4G_Yk$X*x9w>N!h>LNT_VAc<%gVCrM{}51a4&nt9RnmL8a55hFWI->XbD+tI^&J;cik>%u(Y?>iTu5mZ@aW=E<c0equ?!@`1V-F(uJ`<r}y!YUx&a}_bj&>^EOFDx?hIFHEWL1H%H_HhzHjSQ#3+XuK){ch_=47X*QfqzS`#bB)(m%phPo+WKvIL<g-ZdCIQ^OG{{(_{IOmwN{IYY_{?yb@*5Zun{5LYK!SM&a!CDwzUS3g-D=vzFpYXht&}%gK_^(AKYiF4FP1>Q!=`g<IQ?`-GG7Li^3S{y&SvJ1Uf={r0MfC^W2Lk*xfp6ege@K>r=R#%#;zgo}U<Wp{YZt~qy?t@iLzQp#2IAGY$8)q&c`uEBFOeV*T6p50|ipVUO+BywoTALz$M$KxZ@1=tR9zRWPi{p`j&9Lns!6iD>()}I3gK{n=n0L#`(u}H{f^Qt8IT^mKq>3qwh@uSs`{++qkv@xWNBW5?M_!s;!=Si7ykx{_IL}Z_(*V>*B$JgxMwgQ0yYbHX|t#v~1>zoIm1A%k7tn~HR!4xK@?!XH?u2m}P5Do0@gzykl?2ZF(6;gbZzzF$Az2eqB1&Jv|^sa|T3rZYU?`;q6ggpj&I2Hvxo@dPeO~j-goRmr)XU}35_VsV{)%nr@ucjA0*=DEz^6Vib)HD*U2%cq`p+UfL#!`8n1%Wb^cMo+YU_LR*@PW_?5csSYjN8kjb9dqZ0DIic%7dC2;7n_jsdh6QL(cIeIShz>Nz&I=m&e??*UZEERWZzP3W@!ec=;i+=Le=pkbeUU!aZaU$g9WNuIw&Z)Hpqm*y9UmpqI};l#BlSUg$pze^7k##owpP7V+9EpQctn-PeR$oVGKNQ$BzMt^E@HuEe!=sZvtD)1ge;9u^!3c&I60=ETIC8%ri{=Ga>Wg&vS=NBgV8y93{%kgzR-eeG=!IS4^eP*>8z$4iijvKyyj+`NZw`tyKcY_EEJZ`+$Ovh>r)gV@weS7$_{<>^O{V4K=zIG(Ks{t96|5|BRV5GY)TuOB&nv2uHr&XH}-gXPyfFeZ$_y{)^|Xc$e<VlHk;8Kfu3zcwER!*RVkrlR6nc%+DE(Y0_4C#q8kO&wXSK~{t7YKd9v(EV+cYGA>9tbw_o&kd&F{HPjh_3oX+8!id55%772laCahU1-1>8Pju*JhfgK2ZA2=<b`Pe7gQz<d4rP;Gt@(G#due22767P0>^my15Xg&{?!zhK^u=PkP?3t-adYN;~P;nQmqF}lO&l**0o_hJ^`_8TtUB4K{B4|Q#az0J*0$<SYs~8R&Lh{qNoaPUg~deD@=m&9JNHO*kF!DMj##=b(<xvFkNdQH<E)zF7gO*XkgnKmc&FU{PYST+w%U!jVv8igr`}eZ6$GtE4cSdXjoUUqk9itLJO6@+bmxW+cnXV(j|h$_92?9@v7~tqAIPJjm%SFTO0D=ghuP<u$SG(XJ@M7!cf|G;7JcUxqQ{P;FLls$FCkz5(@ocCZ^W4c|7DSdTbWIzh7&mMtK()!-(5ORuP)~>z|w=i7qZ3&7BB~7NjwZaeQcg+39f~BVvS;r>mCJj73S*#=RT>99AEeEWz_PD7Fv?l%1|4rxl(x8dfT}F6}b6n}7BI``XaCiYzOopWmEe=@p`C&Aq1#EoVeL?1@XN9r4*RFtg{RgD(Yh!_jRlp;s9vsTc8Su%mZCw8m)H%^>{^$hnwfg6u;6>Z5L8@Zk(ek*M>w-$rg?`AI#n7KckOq==A7<=bo(9O}7}-^yC@tJ0~&7bkeJYSqf8TA=;r1keUMkN~#4WiTo!nCdZCM%%FID>7`TxVDgzA-Pa*NJrzlOWv0_H?Tb@v)A{~ub5Mg+s#4Pctb5h%hDv8E9^3VB>~GIgP1^rsd2r>a}U12Hmlq0QbXg!9-D_(P_sO~@>}E0kmp%%j#ByZ_dKIN0QNC6=hhfLd=v3rN?&W}k>)Wfq1Icp4@%P`JO_l}TQ$rIhOC$fFQC*<T2tjuac<bLy=YNR)rv4%!77L$O5|Vl+hEgEAiOpQRw2dF#nT3>vTrvQ-VC^v;Pb&qn&ThPkDX(hZM_F@Q4_zVCVOf%n@6WB0%GOG;$5iB*hr@UmG=sv3gy+;(i|B0Q5W@|rQIE%JlTyQ%QS^Q5pz6$5CoyiWRN{(h=}yY$`+r1D25{`>1AixV5H@UN}PRCDOM%w&{J4iwZ!*@DIaV8n+@PWL+b*Ai{lFUBaQMl5RL;ZdrEx=a+KcooL^Nu1P2WM-q7a_d`Cig%lN~>WwyFI#abjy0v$vChlWnvQ8BL6JhHZ^I<J}SQ?xzJDDPOE!5fEi)(O6&NglnjZUyb=HOC~Oo%&NUukZbl$4Hc=36)OM`8A%4Cru~&OIl-ReS%P~x3Eo&;6~2k3gqEIc4lM!Cx@YC@7UdK;C+x?++sgwvm^`_ta&I}>yP@Sdxx6WSbY`G_d>>=<Cu&U+R>_9EcHl58#J14MH1~8TD(_pq80@5mzRcm5O;(yCXZMA5U^C{Sz~(?n(l18y~A6RYJb1nwf*_dMv^^q0eAXIyn+w?ica*t4K;iosgivGZg{?C8js73_-HNHJ0P7M!t1ZExAV+80mwg7e{{tSa;I01FC1un5Q}%l+NE1iC2?7z6yEG9u6UQvmo;PY0~PovaRinU3j)t@Eo0b~iT5*tgjJ9{z@4>L19Aj5SuwDNUPtxFY5J~h*4N#0D8w3mw3)^zA-1~46mIB@0WX~CF@il1>+i;{T{5ejAd%9bVX(XHhT*j5LWcL`Ar)%~D*FqCNlm2S8H=f;a;g`D<P|`s9n6H`Ytnaq>L<fywiFBj7L9ddB<J+@$km>UWjQP%C=C}Jus)&y!@?pc!26wE+yIlu9>N4zuk$wIQM+M34V^a7(yp}^X(<LI<%O^H6u^!KXOPu5?157wDb(SI>*!hWJkF6s9Yt$t@8K#(4NzN1cEZHnE-_o{0FBQ`)tVd7S1K91e3Wnu`7K}-b&)G{7jq^FL`_Le!8H`q$ZiZ~rOY6Qqa5ubvSIk|4()ddRV{eDJ_A8b{WmkDX*Lj=npXU#g}5}3W#1hM7|NAwr;kfjXoJnQ5FPI;RuJb1YS~?XmE`Eo1l|wT+$fq%?itG-1!7aSnfsw;O-7s6UAhf>8h|-M!QUaDLs}v6X&r93PPcnbMGnmy>UjPUrDO6V9dQyCrmF>;QN+U1(iVS>hddeo1$z}D1$MUzz#o~9nyGQ7WQ>qguFJQ#%_5#PUo;#zrPa=H<2VYf;gRvzxiZFnw!!3Jz@X+WMTGED9UuxA9iqN}J?kp8twis;jT}Y@K3{_zd;m0{Pn7AS%ym3R{z#$$ul-Kwd7Usi=ZTF>nr~j&O9S!|VqGzlkI6|;JZY^_g0cWO-Zn)0W%ftGQzywsj{>O4fYaiWv_Q*-!zZly-hhxAt)?OX$J)H__&qFQeKfR@dXrK9D_p03!OaiTUq4Td#T-8DlzKgV*j4yzEYq5{X}aS`O1~(cC`U>oExjDyT<kui?QG4NVR_47-ITDWnMd4=Y)Sqrx!0w1J>`8kl2C(#6Zae<%SO^A`2Fz(UwvdGjBr6rr@UYF)y>84vrkEXS#kTIOm@&>PQc#^Fp(dM95dv5j3@n9r%b6cibA-?fRl1Hs0#;_c6jFhRRTF&>44e%;^R{?i{6w!Rk<{-0V2Q3ARGMUz!T78=>=1}=5l+2)S0om{p)0iKA|-AuecDqvb0*Kb#`ZGnExnSmls1D5dIFM{66>_$qMX|``R59`;O#JZH342c|WA+-KaVW@I>zjB1X$Ce+~Sx&GoZb+JZ3p-rVp;eY)WJSMZCDShx7<>E$%`@kA3Qn_GTTm9j;`BTM@5zMAP?^D2Ualo4AiGOe{fRy$l2U;AdF*{+@LHgzf$LP{_E4TdAQaVyWhN>*yFfL%i^Z~LevXAm#RS%&i;HiJ*PtVVCkKwz$pmtZekv-YUwas?CDi)iM9aOFRx#cl79Wh}A#*rCsT3d;{q{Rc!yZ)hZEw+M2c7-z-2@aRvD)oiex0vwIPmAB`g)Li&&Sa!nGq!!oeGu{&@-?z8g_kPLRMBh|sDh%7aHp#6z=Z5^=y@`SCsZct%x0i^Y2!2?^I$HH+@#kOCc%V1}GHl)~F*OUI$&pV=LBb3f#dSg8$kSU18kWiiRwHu3<Fd}J5r)r~AX1^6G#(Pbs1AcRrHzb^4^;s%<iUtMMo>CyywXYnXnO_5dS2}wcd?8|C3%~n$I>ohFFW*M0JEQRBu*`m=-;jrWM$dxRbwf*(;tf^o?rVvPm-!3Jvw4_lFVUb0|lWSn>vvNo2~1+bo7=ETCskcn0vL0g1(YMR=e{N?q%PrIk|EnkI!EpptQMtSm}MzaS=MF+Nbai6QOf@rv<m>cI*G5qXt*agD+6K!Hu1C3k(N>SrQ<Y3FN-_|KcQu^(WlVX=-HT&}1>?ohX<|=QQaRFHRBSa>dl&PiSPuYDeY||KN|s$-Y9zkx~@4n~~WIH+;uUe@~3A8q!b6yZkBg?b+ntA}E@4A}lz%wb}>~?WnDoPtFMAYx-4>Nj!J6>`+<R`U+R0(#&9ex9tjO-a5PP2XOFY7P74yk`hoSDZ`uJbBi|9qgp!MO@R4lqKN@erh2KQC>9?(vPPLbSF$vzSn)wF#qeKvvCXmM6*+riuB|<3ol|KG6gnqM(??77ts17*_zD#bQ9a2JJL)d|V~-ISAC*~@gq6=D44^59gt=Df5IuVI^X$q$tMqz({>L1-&IOw`s`rvhR@<wj@~Q2=az0L7yjyOI_QS1iXJ62iUnC`!rsVf6XB*aV+CA3cZ7n7TxUVfJ1K>V<@UB$^E)U$6=12|F1r=gHhrV=!IPgo6oBN&_6FV_6T~kGU8+TY%3NVE0u7&;~&(IUdPA+No-ONM3suLKjS*aK-;)GYFL4{~(QGmt^Ngap|{-uIt;@q7u2F=v}xB`VXARHaA31~lu=9vNR<_+QlUAICMtgBZ)1pNq+U&D`e`+bu3wD88s?2>`Tn@#ieHYG~DQ=s9-kSk~z%(U(s{!@aMTS6p2->7ud0!%3IVz}yb@q@PzgB7!8@y(1YSXO~~79;6Rjx99&zvow;euQ`RB+NVm;H*-o4J4!`RoVvTVs!sIelKck&^Nl|wjnehHa=J89h=kxFGs*CI04!ad8q8r>zBSno^D(_e#E1sWayP~6o?39KOFufIUZ<<KNm10tl})RfnOVP>KRC+RZs`fVZ9w}2MhsFo}7}jCtQu9T!!S>$CmX9&ocdxdKlij(sNiwj{YmHCE)K{PVD`Jfl#d%;zadV|J;+eu#X!AG}KQ^0WQX?yGM*Ejm*Z_6&<##s}C)BCZ&4y>xU&95+jdMw*ROztQ9FoK`Jbal7ziIm@x-e)44H3WP}F2qR`kt{^_wX@H32#u3@=~=8>0eCs(!K>R}V+g%&n0KUnT&MKJ?w3|f5QqJVdCFBZMVv<H!_CfcAwaA1%;R$EWH|6ZE^jPA94A)^?<){&H6R`Pi|6%VVq1QY}^EMJft8gl2itz-3rNz>wIN);E|iqoT2O_UZm#hsM@7E#QK1WM6-BRn@R=)swQlQk|4&L6N+GrH_OGw_tNB>Rpde@Ty)4{|=dN%PoaUQNTASr!av6z%@y9t;f$ycJsBEm78Na}c$KX#~K2Ej!(k-wEXL)orD?9V9fxsQ$)Rqjp6f;0p;;s%FDVjWM`~S|^_BBt9xomy1zy<Y7<GZ?d$p-z=r#Dt#;4DS-{cN3Np}{!Nm8?DuUVsml^%q7=^FA|<IjllQc?vsb5!j3IkOZ=|HTo7dahwH|9rLYMvfBwwk|T<FU=(f{qtRc38Q)@2T(#~#%2*$p*FbIld5+wuBh&U7b5ejo6-`qDTAu=e)wdw5hTiZd%BGv*K!yDCYEyw!A>^l2eQkX5L8?+I6~j`Jq<6eVH+<Y*>@b>mk2a0&>C@O=4Eg?+*j0$=el3a$atixF0o48}PNtOi?iFkvo3Ob`V*+SV)pxx;yiZ9>SM*d{^b0=-#xKL#6jf=Mt^)@Z6WLN0ZYh{tlZ$KDf5!FmnDY=L$<0Xo#!`y&KdfSwVe$9vEpCV89D_uszaX-wyJ^ZrOu1-yl36}euy5aem(1L&3rmg_xxRdz!$fa*$mTRS<@DA{bLk8Bb*DrwV>jMPo>)Pwf+Mm2~Y82g5p{dHW|*f{m1Z4Nop(WGs(3&+_kK-UWk_eNb!Jp-q1<c1y&aq5n3T%a2&g|U!2B_ndZNhuAD1xb7Gr^|lNitGwYpZWqnOpRlrA-yN}JyBO*qb`pam&<9W;*SWZ<Z_BDQ12?G#=!+4GoTY&OaOiFF1|u~H#}`zC$00W1>rupQ==4bR?~f!AeMFkXhMS4sZzBhRx9^F!lIn0KNCY}V7|}$SXG)=SK<;(%wLWD&pKa}mQU{;crP6!3Z^@Nlt@tC%Qpj0)7S+iwPR6J9Y~UF)+7oF6oOH?<Y)@WVQYqCLU{(H-pQjhjoJb<KMiL<eR&JSC^2BiGlNICRC%%VP2|)4a;7r8tM{S)vLmPP>xJ|<RoR}#)Z*btdQV+LGTia&v0MDhWZX_}zOXoS-LxgV48emUUHfp7Y=lrnm<{MPt<sDw97q@Kr`Y0AJCy@T`ss(o-574xCt|Tk>E4EMDP82Uh0TXE9hC*Xjeox75ZS*p;LyHQzXi%`Ed0@RKztn@jeuOrwQaV_oWerrp^%s?$shaGCzcpb%f{VFEO+5Y$GQNy5cxc_(RF6XYB<DLnm6RqH5@OJEUgp1w4fXd-A-LPY0b^^Ei4Dv{YBJHEvvOzD0RQ1i!OHREQ!akoy0Bq1{m5m7<p4~T%yFf4>;SS+PT2JGl6C0`_J)=;G1<p?Wov{WC`7PpQ}n*A<;V+N~@#viLrMl#U8VPC2bU>Z>Jtgzc%Nhid9GXkIW5<%)i4rariN8VCIDfvS^PkM&DwDN))ROWW_hd2i{h2se&}S9wiJ?er&N@{g2EtCslgHq~-yUwYC*e`NZk|5hTDGjBnJ$2W=ZkM~$)~|MFc*LV`GUS0_)~OW2iz!F^ELbFV~%u+*fo-++U=KyhtxN8mw?^B=ff$8t{z&&B_zP>W2w?gGE@`<9a50aD{iIv;4NNT*EbZ(s>F%2%uPIRh5$H2|TJddyYA0{k6gN)Wo#7IFc^b<W<7?H+SiK#R}V>)e*IN{OJ75<OF|W<18ti$|qO+bYgXt~oI}jj3kk69QO+uwWkw>B_suG8O4cl_EaSn2R*kdLdL(V?xYs@#IJc_oRBE!>9_Ur@NBBDA^(rR^qa{bFCYAK&MK%su5Uk>i_AVAx5~swW;!Vs(K4sd(pCf&zy|4UGfQ@Ty*naF7TRS7rGQka5aP$8yD#!h_|-r);~hlFlj=Ntn}RlF!Tqe=K~3(UYjlQ=mwYXI!ypV{J~|(Wliv2$bDLm`B`_YJE0mq!(jj`-M$*b;ZjNRImc@P;vY|f0<xh|iS~XKthPV%EHwFu*j%e1Z8B~e?WK)x(?<!`%|BBb<33R0avZ0r>6RqX(hy>(0vd$yG)QSHDuj2lH&2*)txx<gh=bT@$7O$A85=xZ#)T5BH8D=Fc#i*i&eu`+<P1d~v%tiABnvUHK|B{$i|L~0v3saJ;l3#YC{&7S(SHGo)#qCU@P;e@T{X8SR0`WF9P~K{ZdpyOI~7y0MB3jb2it9p%AXd#2B%e>B`=8+GxxhIOS=<f=^xRziij?tNAf!?zPk$NNs;M-``UlFR2IV*W4t+*mq3EqICvV1ePIIhh$V%?+|oK#L$sOoceUCgvA<l;5eM)Jo>2T##Ob@Smp)=xXOwr%NWR<#t$K2t2_f=m$kxT#%LU7R1kdvQJ(+Nh%wa`-SnrB`TaCpPO|5;m(NQXjoxY^nb3W2u`;dEXRs3?G@zQnJu0?tRJ6_sp!^u-4=50^j<Mpm=2?<^3EFUYCe0H!URrPA`0boH<>~aV&Ek@Y2Rt%Js$=^^=rzZ<at4|g3uy}<oIE4t2f<F|xT^Km1$C$uH!if6x<WpRRIz^*avP<NuL%~dNh1@7zw8-OxN|>?#k}wrnZNvf(cjaX7!6v)jNnXv=4@u#l1%+9}BlG(`(V9escI2%s)x9Fy0xiv?){ki%qP<MD43*13Vcg5<cC2ero@{Lny!C4q@qodnMR~I+yTt;{H&e+xr1dbMQCbGAyVNEo**ow+pcgVCobt^8e)&)y<HTUF-=L4WD-y~Mvgbqes>Yp=K$7e=V(_3>SkOW-#zApEze*8^*@^pXPuXkMY0dCwAGps)Y9oYh&kNko`Xvw_5U_w>6qGI_V&3BA$dJBoeir5;gE6qtG<CT%9{ZK8Pqw5<@^WRv8h|CLIVGf(pSCTg?Z;!Axy1S9Vw9<NwZt@W7nJ3|ymEB!U93KaTnk5Sm_N36uf2qQ%b{o;FF)k%De-yPQCKM=13`X0LySS9MM$?hbifch&-S`Mxwmpv>2Ub+<Mvja+rj=L_Uv<gc@Zmv62wgvs|w8;B1GP+_)1}xqia&qf^$U>KS<g^FMF!kl;POOVh|(`_zV=Gs>O*K6S18|zsL<$XUR#QL@$&b;YudPM*WK`>Ew}X2wKXZ`6pBcT3CCv5ykWAqqm20MmdtkOK@PcRl~nPCtBk+fo|<|qQ)nYG7iwHHm|*L37)%*$Fm!zuFS%};R}J~3heH8tr&f@k}G<q;Ty<$`t@(0nuLjf3qSGo(wN%EZdL6Ph#P=ai+YnEi8Tx+etu7q<`@cfe=nT{SNmE~cM;|s?);=?T`)5H@W7f{50O+GXko<j(qccCw9reS@fa`nFu`7|*CNcsT2*py+P#K|J$q1ogp3!3&{|!br)C;yPhshULU=79w8l5tDr{1Lr9{D#24pIO&Y8xpUnwb4MUXc0*zIGx&n|zDO>kACoKR#5Y|(3&9`jJKF;K|-FGs!jBORC`U07#Q19|5&080W!fE#R^(xz}Jv_-ox@<(!TnE|mL-weLM>xwt&+ec}#+Nr6xS<%6Tpn6MK9ZPWIq~>LT<=yagz2q5rnW5gb-t3`&vc`z3Je4)WlVXFX#PWOk{!;h(Z(pFiBFU&X)0vu;L+d}@9?pj$XcVTIPAlE$cy2>ePJn?1oam}JJ<F2|Z#mK=V=9B$O})8P0J?mya$Blx!)A?rC^VWqlYhP*vQxmulr~PxW5pA@_*TC>|3vs^npv7*o3)8%1DHB&%T(81OHE;*wTzI0SamXL(ey==nos@JKPvtmfqkt9C>s;GgA(&BxL&+oB7)%ke-HhmmHGHo{?#@Dp#Y<b6R}O&wwE9=S0?i;V^Kh8H!He4J`DL`qizLBOyXu*7lo5s6V?$ab!>M2%NnjlkUiS0a}(&A_G2W@R?qVJh;y#eY+^GpHx#B9c4Xf!NrL{>9tLuS3lBaYtTw3^F)pmqmT&7{JG$b*wp`R>T<d(=69oy8gWw$%Ua|8dSgPddb+R{($ArM7c;&ais9usMhoy7!j@ZPGno5(kIaHn&?b?hS%@i+LPz%z|z(a0rxZQf7Xf=rMtke5`EGf?n(=1TgdbejtjBCE-P(6lI0z9!3HGPeA)nfC}pij5++v2;yOKNboWSM5!QLH2)dR50g1trL!e=N15`H5h#UdUk(7d?o3Z;_F~%EX=+nEMuU{^*^ewF#`32J9R!Y(tVKz%bapSumP^J5|o=7gz)KACVWDB(pkXlpb8tsIvoFWM5^s<WLp^O;Q5gweE%}EXSpQq?8N-j*v}YJO0eYr0-1fzxx9oljnm(l&y8pqp@_)U|Jx*6Df01JDU{3o#us+EKqzeq`qQBr{Zx6`3*uw83azvczM#j=c?`N9y`hchsPMm(E-l?#1#?6d=#A&*=v9B&LkY%{@lMjIQxa7tz68E!+P$`OurVaYC0=m>t&n~{cf{z7f-XDs?_7^En-se!SB5ho<I8qk!@n!K>gTvV@mwS>vMQiMr%vO<eXnpMET#BTE6;%HhQf4=rGppaj$60{KuS~$J~G{ki{obz@K<_A&pol2&e85f}_c;AtXd|qHDZKfg>L;p0kbd4*Sa~*tj|jW7fJo8M&@H674S%euajXZ3(-S=tN-Sc-1`n2cChasT}dPLYFW}AjkY%F8W--ji0<{%YhuoML#*=4s$kz@}tP*`%m?>lzH(u9JWM+$afyJ&LLHe@de6iqrPP$((uY{E_nl<;y*vg={;u5DG#1FXu%y~G4@_jR)4jHq8Yz8Pleso8Z#4m(@F*7a=vTT*&Ob}_d?%n{rN<1o=pqEd_7~cQ1b31d5L?CKeQ(8j!D&BOuQB|u-1)l7W++j<g&-mq)Vku5~9xguluzw$LG|-nnals*Szp#6ScI9!5^mKmqmD*zG%teKV8?{vrpwrc_SrJk`g7eAd&SnzK41lmKWoGH(L%K<{<TvrK1d6UI?)+O|lxSDPXuR54Mtk2dvV@x?0sV)f_YpPcTa5?GQ&Z2nJut^fCk<4>kTNZ;Ol9%$+1bGRSZjnn6uoD6w}C2=}O@syuY8@-VpTjzamkRmy)YA9S;OkGjl<)!^*`J})eNnvc}_m+e_nf{%E;%%uIbwG_v2tNw;_fV>lESkKNEiPg@Q^re_US~!ih^sKZY%gplI1EC~?JHY~0@MYyh5=vHLz;(ZBhpnpl&=TYYZG5`ZW?Le|*jON-@Yir_7A8b$@AR5YmWYCG^&AMq79Wkaxx7w;e1F<vcT<_ged73+F65|~*5XGM*=I$1oUgKV6YZp#xwcgWgX5u4^jYD?<ttM))OHXp1WmK+*_Xjdr4ueW9K2H-8<W$-R^AyYf$P#=--lE!C2R0|j(`qin7Zn1_Pz@$^H@jpRGYuPkHYV`6fz_Fo^ChHO>D%93|MoMo6sCwy)W_Jk%wT7y2l0)iJDeo&&vciMed<YFNNbvZa1s~kUpw|NO^Y7pm}si%YU(-E*}SvU75N4%$Z8R*YCz<^c#scd<6skVT4@Qjp;Hh>^mf3?;o_cl^i`;*9QQvg<m+xe%(jjis(~6+{d9K(5UT>%Ew_b&B@GVD+)~)c-K9>VY1LQHs44xB9Ve#dcv^t<6mg`!xribX%uw|H+%95GG)H9`$-qK$}!JIPED=Fq%W6LO3vm43qx>zkvb29B?=H`>`?aEG!!;u0*mvtOuo^CO(wtB5fu}WIn5uffv~=hz{5|%tB&}NtXnlj$r7EvG|}dND0n_p8jIzvWVb#k#-V*vwSDbc7iGF&;s#~n_`$43ojrmSPi?u#Vf&D04|IF-ot9n^^aan3`#t9fPZig{lZSCXgaH7v;HZjA-z}-*pv?rvBpZql0UN}HGcS~t7^@Np{+**wktRjq7P9DdDVB5%9%5d=1T>uvs!_(v-AY$}u(7hE!lLW&`{F-V%9|t)q0ba+N*H7FG)TPTwxmWB!rjJxg;UmtLOVeBw|IG1X$J)n>A|_VJSD#s0Np>x{+PWRlha*44{^D;sDe%xO~CsV$z!~I`;`stoH+OD=TWz-kxH~W?et4ySRe{`dG9;C@`cdGd-H_lCW&r>C7*4b_VE^Il6)Y@YH)i;eppLSp=IA+15u|9g^r^Q`rgReEdmbqc4(&>A4vlaj^S>C!tOSPD;_7ZLCsB=h;`3@uB7q7^|k?nFL!4R-(d3GUIakWczXl$@T8OxVv04+M!uV{6OrP5EW-nsJVMN)f#KGZ`ZYuOb(fSc27+NwjfbueA)_Z^>FF)C%VJ@6qTfywOw5X;UB8Ui*)BsA59SnJ2CDWS$l0vr(;Q=2Eb7TgAiw|eX{k{fd8~R|>DgxwD0oT)o|C$>;^s>9FR_&pEHPa$43y^>7pmta$|<ecSi~Qadj)tm_*IK<uUCXh(gHkJlg#)Wxnc3ZV4kl4d1Z$HP|%3vp<Pc>TJ#pUBg-us4-Q?oH^#+K9-8%RF{k3cVl^`VqJ6)Qj&EaK{PEeXqjIE7fpvkMEZCiT<kFO|v5^wD8I1l!by5*#ehN+j2iuUIrUW?e-jNMzfj!W;uJ>GD5?kmp0eeN*f3u=`j6wm5?w`~#Jf_V>j$=((A45k&l7=YN)_ooe9wZBn+I9q&yKy%k?*<UoA@u=)o!PCLU>$E@>w4|-#{*&I6q!gkyDNS1%IhSA*y}ztWUzB3s9%#lkHUZEp*yU1#aQFhLAZuG4<PB5!4g`Tcgt1&gW@rEK9cjVEz0{4W4n{W1qdIEnC!8ao?}$?B&etuF6hx!4N{|WTZ0646_tivxKR@na8v_Z7%3J_(3twivd-h*z;QGLOLgkmg~20U@4$uj{&Apdajw`<(_ZS-FJq#Vq9hK~FETaN`Ok6ZFe%U3+zWzf1kc6AC^H;ap$|f#wz9p%{?AE(xy!;QAb=hRmh!8+OZ0nLQ{z2`r_vaMgN~_j3pDESGSihukAeM=Trws{u*>2hD0Gr|NKtb0f@Rg+QmfANC{)o4McLvgFL_ZLXP1Uye;7T5fqGMp%7}u*mMqrs>fp+c1MAq#0$0+N+_$Hr^rDISH<LLPp;u}{D`H(gPjHum2Wybb5O16}SKN1wjU-akrh8y}Cmn>Gs}6X(!lrt_?YR-oc32H_hs#;NGX2<7BhQ@AQBfYBz1Qo~7Kqn9qJ}_+MI`~5n|v-5N_<7sa6<95_5egS!$Tx66?xsMj9t<B`n?A1x;7#L&ptshw*a5K)ATNkRT7TR*sTm(A>?gWv78ya_O0F)Yise}AkxDxyV^TzIT8Oo3GXyBtCQ(Q^&Lg2Sy)F!8H;?U40BEh_r*c@)!|!KN=Y5T+n&VnvpYN_r)Qfb!E?Wszh(BR466%t56)=;urK?}_h%8@gnr<aSc)Vc0UsU*YzKh5QwiH!<{%F%tJul&8(oLU)lRA7&eI)kh&GYz&-;p)g_iY@w&5PcFYwWK`qUi%MroCRL(#Q+4uc+B<|(!a!gB~_-bHo^p>ZIX|D$R$ZXq3hHg(7q&SaR2%nC|l=o}$N8KgpN@eroL&%4BO#%1tR=v_Vj1%%mZ=-xqbo|X(A1NSJ`$DQXbo?PjKu>mUsN%^JC@)B?jXL<5@>*NpZdor5ozQr*&3YcuL9Jzw-ey-SBe%k{XZt1CRb#iQ0j{^0^)mpp5*ZYT<ye}4S#xj!FT~&vqAgmG<6&aV<tTe}<bwm-s)aJ-K>)eERO9U%=b10J^O9}(htNwwN5g;KnPRW-OJGUwMw_BFxdkDVF%HY*sUqTEOdIGaURAph*gqme00Ea2vk?^1(l$T>1Z$FFwiA`cd43n!&6;O1~Hd2~o_s^4>?UOQ5lK-FMf$bExn4*pk2J~$Ey*)}&hwb(^LA;p`1sD14Hu}L}tE@xgvo<~;Uu=+KCYy&@9O^HOpV&hh=Bli^5;x{qWj&4y+*lA<3~Z|x6!GVNuz+D+3!uqBU5RyvsQovF!~i~&*!ewzW_YX_4%pj<;4c9}TzoNB+L&G~CnlAQdFbaihKV$gh+_(=@(|V3fBd~6#9QWps{LRO=(TS7{<v3sA2qTbkt(PM>py|m>xWp*nMG1qp3$%HC{rU7)Dpe#xw2jD2GZ8e-u5ToHqOWUxOrNT0n^YWUyZ8tRw-UlY|gCd&%*sF4v{d`FUGnL0g3s}C#bYpV^P{fC~Z!#fA)TR?g)BF6z_)Sc!G}9V@$A@?cg2#4+bV(xi7OHl{7-30L_-|bs{=dK{8|I$6w&-m09$`c+acuX5|!S^Av!#8!2g5cM3clE`d$C{m<Rqw6A}M)Gc-(bZB8ZbITO>zGPy230nqXZ+VCF<=?%LFiPMishm+6R;;M<>*<f?Cwx#`qxE@Fd=E^v>K>GRkev7$?P<0hM+xuIWLY{`DE<=}LG6ot-`Cd?lb30Yt$AoTa<s<Li=tLFYr2A_a$c9i7{OVQE&bfsn_)$pIxLg>rv3%C^dwr-{mW1H#9i0DNwOd$zAy>k%kW%*JhmqYF9L|j?l`158s|5GzI(_JkJqAGN)eP~N=-O034lw`0TO3fD{-OjQ1ZVG?o5ICLANQz&<-&iquOwDvL9`ORKbwMcjjcY_tR1qM$Jsu*&I0xZABttX?n*yV=Ju3d%671rEOnm3Jgvbk1DJS$6kdk_KOu|)WZ6Zg8#+oF0b3YrVbFK-d`NI)W@1~%ZzEyC^_PwtRB?bY+XGc;!r$Zj-K;$VD9{^dO#zHnlCXa=`+IDsZbr1h!;ez+kU~CyOvtVg?*Ziw&`AiZz;95!7+*swJn66cKI}{`v=?78csU3FdBU$fgo=^uF?glAO=ajoBg0YNuKY;l#&H3u>FJR!f}Y1ip!g5*&^|1OwAizQig9H5<*3cQ1X?#q*w7&(>W;7vO&a$Zv!o&ERjBeDhs093>58=@r29J^H2r-DJuh3jo(txvaIDB*dn6(YT`gJ)oH;|MQJ>J>8N#5^bEdV*%;Iiev^r=%%>iaj^7v&I7>*bcPReCvlu601UJs99)*zrv06Ao2u3K{^G3AvFSVL+R{eufUsUhvXu_%e6A(d1q}CeL2Yed#_f6{fQ-^Ev+0CD?4|R=qaeTH+29Fk%d7XsI$Q=;zgL6}7Tf`t(2v}Rx^5~C99g_eB=Vv6v8}+0+OC|K+coe_?>{&2iG?V-~V|ju-k^aKm=bvMw+Vjk}W6Z1y{ir6roKgD$;K6=e`PjM0c-o%#xA`JB1>-E$2|8xheeZ3DA<izOO(hJ_9pY!i#{PHvzs+rB=CVK|Q)NhwltD;wgAqOWoe=xBCw$BPRIXianKN2vK5r-0&ixxdP9y7<n<5@77MR|Im+BVEL>BZw?Dw~adTKnhN5L?hg$)V&9pyBvMa0Zmz=3ELXJzLaynhQU^mQ0QYBWHG^fAOOzwmU2?h+dKF;iE_qi^6sxUL>gtZI3dct1tJSi(M)%M4XIKRr%5{&QXSVafUg*QYECu&$rb@J6;ugy%O41YU2x(g#;WfLF{%TJ>{Sk4UE3sK=3oTwZRH)b!-R#$hnDF;IlqnyE8rQ%q_UMvj1_JMDFAA;XoJOA9^zv5c2>4fqk}yK)`k_JLo$Babm?bd2&ZuE0fPQkRs@BCcd$#|nLz*`&mEW+AOK))mEN(VE&|%ETId(-c;6UH(0KPC1^c6<lQsV{$recb<&F%9z}{ih|Xm5ud!1RExwe>wdq05>l2~iy?4&68+#$mKIDtBP9m<T&)Q6S=c=ov*yrXe3!2W-c(!#mmy1TfuM0XQDQ!iSGBoFlhgbVUGihszldmL%NWqGLVC`{X<0sK<=B9VViTOk!0(H*F;7kOs!oD((a3*<zhdWAL)&(@NIe8)`OXBeCoU;`jjZEo%9@m*R})`Amd4S!3fTx-5h|Yb6OrT-<)n2)Qsj*sa`N|QUThmOeamUyTgQ!dRwQ$NnJ`k|5}52(VuJDv3BIxCEgbjo=54U^RWW|<)ACrobuH&pmrqJxwP4Bka+Zv?N7QGwAjVu8qQ$a$IOaEe*1?bVXA2VObBWL|i5EW#KdSY&0IDpnz3}h;@Vz8uF7S#yhm_hvm)3){;M*BD`-z;|w(q2prW2p$e6!Zib_oRL98bBa?n+C@S#`t>Bh5n7r&+d>ObNYYkq?!wF`0xnrtqW<n8R@Iv(B|M_{M~=%GJtC8U|CY@XS!pzpHcaWVvDUEFVOUh6=fv9WM(mw9)z2kqh~2Q~S3_F*QD;L*q5}56a@>Tn4Coz;KN&>li;virc;0_cM)@NE}N5Zo-NZ>(@+}tRL1jWYrlhOxvx3v-bD=q6L;ZLm6-phPO?WdHI~Z+Ve<XwF2`$M#<fjSSvS(DOYDSKII#dzF<1!Kb#Bin>1gge)6u%eh_={1?Ro6sAPF*Rm5tKXp6O%QF28AHe>EE3T{Q~Slk@eF`14pMQEBFH5o^9wI_XU$<vrl<8d+y6W(1XL!lM-3+&l%kQo!A77YkNF%6xZ*QMae<9G;Yt=k)TJ)NY?&dx}TCa_%w-s3-9^(!c|;T^w-ztVpsk^~Aje_@FkJ_T*hNEp?~ot)1o2l<T6b)JaI65SK@@PEqmuZgg}3|%^?{oPcQWJsJHR%l<1+LCIUn%!8di<^A<o4D1?gU9{~(DZYB#ZDD~P%X<mCWZ$yMNfGXRbB>9$`$u9IeviYH*tjTi2+@!rRpWO^p8)cpuqqIw@S9kEMC&g5iYi;y1sHR2KRENNlb1C@$uTm*k0WdZQ1g)$B(v+3}0gp)HH0UC`~ATEh^|Gnb+w!X4PO)MK%UMG51v$ziMJr#DyPv`hkC+#d?aSHhku+lI69d=qo8YlD>iDM02YzQbVq8;D^!+>+)-WZq{?iQL0TFC3_+x!yU<yC^8#Qfbt%tZ0xANk`<o}OTw5hADEAaX#yI8gga-8hhHMic_|{A)IfwS3o;Q*pSnxbk7H!eFC=U>IliWV)`YY|d=sb*RU|gdS$%<%%H3?>T2s5d-1%cZXpi+vdgvjkjsaf(dN_)Z$X{@EEbIG&xa>sbraEgWnMc@w8@gncLW7J}IouQt-UvkyLl>U3qC25mZi@H8NINkIy^VTRL0Sxl;J{t{)>*Vo?#_k=6~nru&duq3X`0MxHE(Ex3$~Yw)b*(1e65&{9X=bn&j4neFp+m^j6pIPYn4Z=M96cavwew;Pr^^Uok6FW(fM83VY{u+?9_f2BN6mPGpKJ|iZfH2mvbj~&Zp{2+x?rg@1}@K7)U2)^Z>(dIO?ra0tGopLk;!+j(pymtXwn9f*4W$Z3($Q)|i^|n;Xi&1G?oM+eH3L;Z|ZU$HH8~^<;>k?B%gaal=b>l2BJ>l@<_I^;ATkGFJPY^110QvEU2R2F?owknc4KmpLXAE@s=ABbhw7h`^Nw-UD4x>#zLxg}Am@;Ng=$?h4r`*3LSh6)-nW{+IN|8hGX=^Fqf7U&n;cx%A^`7|z0%%t;n5#3y(_)MLW4!R~_Em*9EX{dLyz{6NYsF|wtLM7T2#!6bbGZJ{QeE7z0N%Fjj5=_J!m39$&4=>0d8DDJbH<YL0~f9LD(Kh7iCAN%T2LknB^dRv#E1z&WKNO&zGBaJ*3WdhIwI}a&mCHu>d7ymg4gJJ;D`A=x1K$n9Neumn-3lNQoRW%-0b0&nQ+;-)Pc``#?1Gfu{=Dey@)bxseR$b_+>7Nx$tdh(&{0_o!1C`}nrKsGfZ~@=B<nM2VF%=VQpw?S%d^YN#qd33I48<$zwXn)7cdP{I9GvkILz5d(eJqYcJ}s)~h|2w5^#=JBkhUO&)mXDRFb?s3l{2Y^j5)DA`&IFlLx&d^%4qjb6zRT?9Ee~&ZUA8?01r3pAfxuz(tbJtk0!ufQrw*KZ-bM%s(g7nksJ`?0_9X^OE-X2&`Ltt9`fazQE9C4;{{@MP-1kYab|ul7f?nsjI9+P<t^JS(Dk(O5r9^06i$$EwyIK=A|$+3BAj$H{j&IX&YVR@!H$}IeW4^E1^AGvO8Z^fnZt?e2(tHoqVzG{o?sJi%Zk#?R5pN#b3;g4Mwk@41-%dPb3@oL%*um-{sU%w&a>^%xkMbX#%>E{MSx;dGEMdka5GK4mGIQ0L+b^l#Leh1(uW0l;go%q;r<SpZJh#cjbk`#j<;dLE|YHl@m0OR2S7kyCOxb&`~VMt9TNGNclF~cZ*xxQ9rQH-2)N%+F&3~ke#XVYzoev|MjC3fTg#VCyC;Y`RRc?qMKc0Qmj4OD9t%mVf!8*am`5Ye&bYJdznewy>SpF--<-0i{AM>hpP*Uh-3!`%NXvCu%FrP0Wqsn*NS+JjuDt(~q#lNiqf#&2#_KtT2m#qNSwpPW*o@HCH#n=3_bE5T{Nzo)f&Uva=xzGDd*(8okQm+L*dJSenyM6ugWR}(q5at<bz6haYi}_0^SnC=CClYf`8T_TK2073PSR9Ux5;vJ`ZR9u6=2C+ntQ+WD3K@68xm3&G84(D>TGQcaoOBkLm3+h{edRC(P}EOte8lo&kJqeBiN(7_ZHW)FUJ`Fai?zMN`H<abidjn#Zh&;o$t~M=4;b2$T2p(9r#|}7dtIHyj8jXTXC&NiN-IdH3{VbUn&*u-q~Rk0Rp4k(u`wVJ~RX!PZ$}qcFQS_+A>k9zqGMBBx%(k0m<M5c*Cn_Mnn!`W|+ZWbtx$@#69u2DS;LxD)GH6;%x_F>OeO7uJ}3z7LXWXBDv5k$U0m*n(^L9uYut_-`Cg!MEl!;)jsx;$gws`4GR$e?rDKBuhetv@c{DaVkEL^lEzFnIDX}5X8tgS%j9|;8Cj3>5t*ftY${H8EQaxQBt!?0gj<4Alp3xwB%0MlQn{+4s}%nLzPZ+67N2|~yK(}AhIgnW;sc6(hKwl)mD#mNo^SSD@5lT|+Ehxv1NOk}l7|)w0ccJC5frv4+7|Xk`;D5fL^8#OMGsyPF)<06R4M8>X|<y^jIF2y0X_sthQCpou~+z#cTfZN*%?(}Ub}xXY3{Jes|N!aH7C)G#>+<?bv~m&mt-Ig+2lePiM|ed&|+xd#08<C;7&I)ie^2m_c2XTS7HW@-@Y#s$fm&s+G%_HH(~CCZ9CM_5>p^|AJ;1fn*Cmz99ldD-laJ9YUT*`5A>m6qx02-FXq3%qFh>SD69t?vQ?watc8A6Y2F--iLp0fzEbI~$)T!McOmYTaj?%lFS8|1PxrmrV3jP5mKe0O*Qu68F2O2eG1JldlbEXQAZtd#>E(=<8Cj*rQZV;E8SYHDAH3i;X1t;J0QgPT)RwimA(`?1=JWUseWu%&Cw5L)$#Y-C3ff~9LhxMk?Coq2j*0_i6O|Txf?5W8RX9doObUbfW&PETk(=iR|2eeQy_Yfqcr;iY<p0}OB=6GCsMtdL;+%T1Wq+X`>zv=@ew8as!bVY?wBG&Kx6ejBZA%lPAO%YOs8=t+ETbe*0a?1*a+Kva@)!`sIH4J(q9ML`0j!+AEO{U`M_F54IAFM3!H+o<n`c%jMQiBOv*6tyqsr7LHHd*z3uIGD_V_84CR`$v(3!M(g4|60_I$<!3UyN^wJv8+1IhuIYVpYzoIxE53c8GP4BG<uR~(^zC^5o$9}C1LxZ)gz3?L)~?PydkO6p3PDbHLzb(rl_g^%HH!*eL#O-Q>%^Cu#AlFK=|?I~XUCT8SlGJ-X9i}H1xXiUwDyE4$9l2sMG%b_smaC}fRfy*vg%klAQfM?^bJhjO?il@fv^WWsxO_fEo&d2NR7VKrT^h*H4GVWYF;jR(_#l$3fW$d0WwF+oqFx_7Gi2on_^Suhc;(ZCrn=&_$2Zr*ZC5jV(XZIphQjuEjGu1dxoH5ixM`$7QyS*f^FJLf6H(E9Ee@tQvI`_xgg-!AIjDQ~&wdy@~DpuaSqU5l`JN~q6V_`)@2-xch%P88K@2DnL4+ZxL;}KX}gXVT25%CpoGeRmd_yj960EjH1HlP~;VtMLFV$!bz=K-C+2Q109uHQ9l-#T(XotuI+AwR5xaxl^rxf=_S1+7|DO1t|4<~aIQ*v($-m}(veO$6#BDF|HnP^qEYk36`vkZtJWC=XHFSPS1OLXpKLL-5uz-uGHMS2K|Z@4Lftibd-AMO!7>RXNJW(S%;0IL(tAfX;$ah5#Aa!Tx<;!u+Ih%{W#WEj^E7a*ir96gbq83X8~mmz6f#aT#!Cb0arw0l0t?qpL(bc*91X=F*pvTP!{xrajCFBSBuwgBEB743cwlRk89Y;8f%$q$sJg^$)QiEZ8Ip!jV6XJ=CuLX&;9907)6a^7II;JYb69=wNY5cVLkr+UfkFWw*?eHue;C_keG<K_-76uZ#UXAy=)36U=DvsIDPPLh~-0f6S2|43VCOs2ih<CYschE|$aSdONJDwIPH{Dder=&AXe1RDVL#r0I`Zg7bTC;M;}7E4@-ow4p)&L}$9NG#Fv_$9IJh0p+u*s05}^id1&^Pb!jtA{@CC{ctKul+<mZ@(|<^J!@NwH#$D;^VS(rOzRQAp>?0s9b#S>hUu&d4c3UAM#U_lsSczjGK6!M*dN>>9rVJrf0*`iRL5iFTnVWMCjZ86Na}hXcupR>iiSc+K%uxpFULb;bFev|Y^6QtSZLH2aN=ILd^$6@NDtzL*8!Z76R`crIDArQ0hWZe@PbUiJ(B!H$#Mei%%4I$sl=@f<e1WbE;Nip7TAyh5I^x{TAU5s0A|o1bOh50Gvt<b23=x_@DMF9iXa8(k>t|mf3J9G--ALc47an3g!df`%2qf}pu$vHke?y{<nJX<dJ?ewV;U)&AB^sJdF<PuF+b7kAv^YW=DQS!u|aQxLl-l8en+b8H9jAyDK56&(h(Krqwg>go3xV)exX`k8`OmBWZXI)<ZHh8l6-SE{j1jr*E)9uTB*hjIQa*fP*Bx^q>)X8&Ix@a^y3-7FhNF|v*a(7ED$Wf;T(I9aL1-~^6c$+dRM^&7MdbBAQLgU0b>@x5R`!N)^5yfeKtG5T^w5JXjOCft?#zW<RefON0~GX18cczX>>&dNELgv^971KV2hCkdfATKQ(x%P;Nzjrf+YYdv-v+3Op$?hw#cWiOrbdII+gX@1T~8u&PW~;VqTp!SIM*DLJ|!O_^I8Q-MgHO3O-FjEqDb+B|WKrx0!<g0|4#dBu)9tc(K$Pe>m^cf@05}mNy$3$8d>KWK&Ahm}a-G;seJ^QP)aEW{y3!^3`_h+Myn#bBn8k21r-t{pN=aY?!XYT_Mu}p_0YnLA1sI&DUB^D3{h`Zk+58W#lA@S(+G=+YN!@<dzBIDuIVEKxH&{ypP^_rpO}<;&<}};NWaKbrD)dwc%?UTc*J9@8a`Vf?u~kN${FNv)z9Aopv~#gc*1NjYp9h%>O*;8r6<R>u>%_7r%OTH~xS@KoKcRarp-iX%+HgKBeax2A08J;TI;NR6%5;CQx`a<Cf7IYEm|^W#9zrmxX|&pbrGl+(?byFW8fJ;<GRrO%YlH$xPC6I8EvmXu<Eg8OuwD9p*OeK|SW6A0_6Kw!1VRs}#~YnV}z{T&y0<t=Es6xh_O_dVAqB2J@SeCl2aXa%)u6FZMa9F(Y7QT3BG#|3R7zQ3(s@6ph)_`_enAfwB@JjERXiD?bik_I5}?V$-4ED0B^Uk>w0fu3x#+lKI-7zNzFRG}=F*oO~Dmg#64$ZT4?R5V*FTv3dC-_5j4of<mV8eB#_2*Ln0UICC5mP=nDd)VsM7vhTBt6a9zNiI8nX=MZD)_R4KR{0tHWl75wG@~hZ9^+AOl4ux`)uZ6K~3t#t<LOsk#Uf;;lfT&L77kpF8=GbU(b<_#LuEby{H4nJhI9aNk$BjPI_6}mVVa{p^j0u_$0u!(wN;z`jJq)KYnDmqya@AEdj&+TD)WI=&1!96rFwP8MV2+k+5>igamzw{4|1s90^b!M1i|@qgfQ3&ggZeFZICX=94wK~el<+ZT7e}2bZfDBNFEFQvY@rz;kTLK{g%W^Xa-X5UJ~?fHX)1}$3J;Px5r_&^Th{Y`vr?Si(Ig`^p7vc5DkxKEp{3IPShw?mCGmHg%9ePwNY=cC`-agR0n#4Z4UyFAjg3Y>`Hw#O6f|>ug?D%H?%>A4(bgu_ip|Nsc21XkHK#-Pt-sb1!csX9rdK1H&`aKl1WDyV8n$><h@dQs?T5=|GmSsUb?5pxF6huk-GPd`Mr5=1{jPZNEc{PY5|$lZ4^0Oh-p0)Dlm$yc`*q@|nj>yIpx&Y4fs307=;csb?3KoD8=msQAON6r`~B}-Hz0SJqZ<7XInK|yw?Elm4{TkG*7y2aDNQZy7|{6YKfQ~1h&uDP_NxFiV^JH!cKgNlvi+1^uMU4&`gXEq76Vti62Fy)wbM{_FVz$#r@p1<ZY^q%KX(5^T8{KWd68+-&{!R~4-Cm}?U&IOw__l?AYSYu5Fo%~uC8QY{s@OmIAA>bU@)-j;D7^-1c4+mCSsy{TOs2O6^+<g{a`|_5+o$KQOT$vJ%X<}ym~IYklGF(f){Qd#`1s;MV(C1=0@4^bSWrQ1I4UwiOPSOmg<*Pen8_JT3%#)5izQ}HSI9+vs(x}f%_tTb#M-va^Uud73l(p5FxWbPz5Xea6F3LiRHnu4V&hcfE6QTyH$B67g3(*%T+66co+Kz=@O{RH8}qmaZ<KprKFcHxz7jO4_j|Ka(*cMdmBjft`)x-1$mS~#o>#z#!F;3hU7gvf#)DG5?~rqMynxt_xXXgy|_ROz+G99_Ps(@mW^_29mPVz*ZM(EnMZ&uq!<6xh^f+M!qeaXlEGMf$N-;E?Z}BPl@q-eRkLuwNjUHsCzz_2t%Mm{K=F$4-&#=`H1m{z4!ywoZ}Z}YdBiM{4^gnRqGMYBIE{&wj<<>e3ZU7ioU|Z!o{~bxgV^BC?+7Y0HZZ*PHNp^=tM~jaDovkU+<Cx1C85vmd|VBb!YI_BJo@<}{YV*-XTl|yoh5^&QnkhN5mKGW_68DbNAh~s+X*PUxVLBkpVp+3Ncex5*8GS|DOuh`8@;p!d5WUlS-Q^>*4XM<t8*jy5K<*>%_9einq2<q7OitUmW9RM?WAd2HZ{mi=0HK^D@g<8iK>(w3Bpk&VOe*RAIgTEUO7~oNV2cX%Xy6F(qDt&M>YSd*v6aOeT1$n>dT%gi;Z;eu^YG7Hu4_`*%1aairen3ETYsar^sVv;^iq+Ns5b&0-_K5)wxfT#ndZoUy22TK5A94S4wH}pgk2-U?sGVPk-Hp@=$tq=RC;iNc_(SFa>bE(lSGt9c0P*vFXG$V~mhR_+<Pl+Gy;>8|;nB(zRVMc{kE!ev<^xk^+E2wt5#^v}0Vf<5jLqV(QuJ-~k}TmP^4f?bs5tVg|xe+P5fiO4&n-BjmHv8s02nK%QKQ9H^Q3;~57yk}i;-Ql6uC&-3${Hm!Yn2g)Afx{`aUX!ERImMvmN&mJ|H&GycAGPl0l*{#0OGGeUR@I9#rT=b55aG3mw8(HIjA=`J))1k{0#R?DNwniAE&^QKmbKUJ7MogG8h_t&g;|R~g47ea{P9^?3IG<WttiZW|J3rtge-TF9(|yN5lWSD|nPQ8u8Ggj23q%;C<9?yH^mTRJzO8IhXVJ%Vacy$%B;ktc`U0f98AK=K^VjQJ;W6Jvuy0WGQt|Goo@rnOU*@aMjkf!JM~v|lb1PJJAC09M>vO21d7$5&*&aMmahP6;aJ7`4ZaJZKC^j#HG)sqePw=wK!ZdcC3FU_#A?}j6A7|V0B71S7G?k95eCFGyxRZ-NB-jC{-L{Yn!#%D{_HVEi7yuQh-8MF78}cK3`nU_amxe00Uw@>LEBEfC?o-h6-{b%rshYT;SxiGdG1isw?nL|u(N!V;Pul`QFXU?qRl9V57&0$JtISm*BQd5M!?89gu?+2(-Ev1uktz0N404mFf18npEG_2zn7-8z>u@4X-w-8KwjtEo6?l7m!w}M|;U!JQ`A#!d2;S-POhN1%0>FjpGrut*S>-s^Q}d+#Y230Zh)82#|L;~t$b{(f!A9EDSnsU{zh?HV_%*tj&o=<^ghn^6v|TA$-PrOd#5fM4f9Fm0WtzIP7i;600K95o08)TPRWX=w{Oc#j4(Ushb#;M5TneC;kJAxbU;?EwM^N&Tp(0L?#vH2i+9{4nnYy+>v;YcrHph&!2;u+$nw+MmmN#t!o7TCwBkL6t=0H$t`bpZI;0cvBnY=h5F&8i@kB&SFg6@w9DA5Xx{g_+O4;H{5S*nu~n*ou`%az|uyrwtBlxJ+mITG-dAn+yjQYj1^tZZauHtyFry50S(%Z(&k*v!D<TWlxhg>s@wu0;E`A4(YA<EJcur}&KtT2!LkUvF<~4YKsUSYjZwbWQ%R1jXqCH_=MKIWo+yDsOj^0;WX(@+lz3V|1B!NRIe<oF+IT3ZH433(fziXQEujBxUvjJor}G$r#AstIp;H?bhL4tCccDpCN(;9Lm)xv67AsM=UCV2m$4QALxxB?~A-ilyo(!atj-jZz7kL4TU9MBYl#j5XT^aC6w%Yk}7H&7m|i{CpikhV-tlSbqF2B9w#QoREEUA{lsV)Km_HN<ZTUzPs}c`*FC44d~T*A1m<3PK?LeE{~8Gv_W1t}@)3fc6eYNt(1=;d^fV(6u?EA(JoF<~W5!r>YS^Q;(bGI}sZ%-!zS;;u$R!ImGkWm%jg>ViSA?Ut-ybGL@dl>al^vRtfi^YrO@S>-w%4(4=EVMQ(kl6A7p;e{g5zEMTJ%Om;{OoczcK!>_f>?%XGejmbBP7>uMX)Q8_TA19Z0^Hr61w4LxOt>6?=SX>$z^*>^Q*}re;ZA5>~>Fhly)_`UOj*$-hiNb1yG%1dyt}xA(-=Xd_I9TSc9-0PQtXQtJRaOP?*Dc7ov~`A{qX2OnCj6ioladW>QCUHVD)Op(E!Hj#pNJ29I6Yh6Tb@{C6E>4Ifzou!p|_(Zr*EyXO0(<53{jDc~v-&Q3<Q0M##{u>6K9tQt9PBW8;SK9OwYt~_^U{O$lb$it~+PdRSu=#w49*!YJ7wh5l?pg0b?G8rbQLfxIk^wSMDqZ70<I5Wo&^1ywFJ|q;y0by1a&usFVC=Ik6=S2tG#MQg1cxIeb4bZW&{F~a321Xb2`s(I`xW%hE5^h|%91yo2&+si#m+6R5@gADO|Ta8{-+k0?tw;7H(!9Gi;bt{MI--THN`J(38kUWqTP3pn|z!BAzoH$yOh2oOQVnpQ(@t2-WO9baGgfvNq4>0dWi3~4-#z!il4AP`(t>z41h)|c|nD6ph%h^&n<GW&<kf@pyoFo2%NQ6Ah57;_mqR`%SP;%jnC_dh6Xhl%k2?9!QDIkDgzJCpp!w8P6r%KGrd4&^(|)zgT7BKL%7U{P6DberIS2oLoVos^p?Cy`vUm6Ic}hl5#?jc>}{y7TIGHRieOvG`AbI!@e*$G-l`EdM;NpXTS#8kz5^fHIW<))22-TwXi}YvP$+Z3@*7Im%+j`Pu}#yVu95mZr&DhMkM{Uepadbfa61{}Q59KTM5Ey%|JINC3)Fz7)s%!>X1t$|(y2w7Iz0C7l|#K3p`k2xAFmV~FvtEx3c$XSN{v>|f<dj7ppe4|RsMTTK{6D2&NluPe#yFDkJHH1e+_)uJ*FYpB;CU0^fFY@6uKG(bn4&hx+Ib20-gm(>|Fqi?X$^DAmp~-Pg>ZWWl=PHmK`J`=DQM?ZZ#jfWdd0QMze=vENP$s4Gv-L-9CoHL%L~<%g;F_AC8+4VcQyEVzeypM=*rn_gQ-O6F(|ZOf&oxawud%3fkWU{I7N3*;nPEIvSKtyMQOw)d7)U@ath$Z|he(jJU4bs7l{TP794tQ)G*Q!zVOqqDu5*V&;6=)J|}%5EaH4+(VJCYxq2iaav@$+TQ2ins2*=kiR`t0s+jsrQ30c(=djKM#ovsYwR|WgA}L{@K2Gg<zJ+KRrJ(KRg}$;_Zuy?*1z2Y$T*_^K<|(Sqjw5ByK{L&Dei_S)Y^p0{%X%+`Mg4FvF_7l1?8DR9-O@&qwjvfvzCjHn9Gn@Tl<-*`V(wm%T_yEhPxN<jclPSYKf9WeO@a3)TB3UskMP9NqA}_Jx~Thp+C}7LVak+peCEXk26f?gMv5{xp#-ioKEu%XvHG2h$YW>#}YF156tGLN2<Ch-72<b-VO6U?1$u2fBFxq%Z)mDz1ag1JWww+grg$50b-z>9Ug?6r4WC)nH(k2{xY%R$$p1!BxR_C&p*$l3W<1cq;FY?EH$olN92*348~zJdLbcL?|>f1EQ3Fy@-3gvUpl2tJ`Hk$Pt5i4_bGXU78rj$*J`7Zj9%&NA_9N6-AQRT*uaoBotEYee)UF2Nub(>gH`m^Zl1@|vNRKOiwQY@(@c=C>NG+^=LEc@7Bf|Sh4ig)x<`PxOj*vL0`_i&)NtO{^~{iN`^kyz^zRJO(kBy%bw!DDK274Q{#&{YGjNKZ2{ck$5k~Uz-`Fnanb~9^*9HUmNvO+Knc4dc5d&x5U76-IuDdE8n~#^cYJ{h>jFg0V_Pse%0Q1W3DqA98ft1;B8pA#>d)czFUx~AforV~Dq(xnRFq>kN8{K%2%K4=q!ZN{&&8*5U)qs2AH;{?o-{r{iweGC^oooth%_!gV)MWGbO$)l>eGm$TOgY2&YN;uafs{T{n9tRzXJx$#J1ndkb^96BjtMsJExpU~M{V{L>o41Z=$eCY^P(l$lNEKPYfgOXgC5ypQsvoL3ye}58Xe_%b&jY}q{)LCrN3LJ{0zq1*b&LM+3<S*vuI@3j5*Wz^ZbCfBaVMgQVnND09G1xK^;hLcDedS7*8+sHys>OnVU^~e`o^VA@Y*OD_lR8d$vRt4RwF6A$b(S!-Z)Dq(#~crSGH#o&F%l8K%{|6VJH8*OioO3tnP;!nB#7Zz$@6q(yTEOH%Qgnm674Q$Xz-(<|qhpWvd-yip4^NnI97PJxxN=5T0##}}Esqml$VsRq@7gt{l`+KZnH5mMu7Rxt3_1==zH5pKGS-I+3R<{18XtgiE{fivJlJm)-rrJ^bSlGoB#d_z0omq~2qK48+O0J_DDtD2It9W$>2YP<BLu>qfcyq(pTDthsiSY19I3Zt;MRw%uKknvyNF9K#1vpAL;ro^gAX+Pn2JAKK-9(TMWqZfueuFR{1dl)=tr7@%yTy`<gj&itvsYh=m<3DwCLzw=gMLg0|F)Sj7tUjEEMLo&DAAM%n_+EdwVdE1a{tv5iIIaw~HqRX~q}B97cC}mP*028P>;&@DHn>wP>5M`6=u>v7Y(VVspnRIx5E5xEN%cX|m?$c5WXM=T#SNH^v=xO5=xr39H12+0>qzlkCn>WB#Z#s5?Y6q$Xq@B1xSCGiVY0{^C-@(zntV*C*l~YbrhU+2Mz59bLBO--bVbnWWy!IBJ<~C1iKaVBql>C`!2!&{N2L~I2N|b{7?HIvj@74&;B-?Eww<xE{eCSr-ka03gTj<5(wr4P@E)H*%(F`8B8Vx?l^&pJP@AwLZtqZOrV6mQKQCY36gCz(Jg-W#g&A#OGXa+f@Q`i9=FE|qA?@MO*2!9JN>Vv4gEqo~DxjIGO(wHobb$rr2tUN7g=nu}_=HR7BLWF@o26BH0jqN#H1zV>$p0N1;uN6Nu(K3q1MN)`b>bpj{)}ow<4~X%V#v+(?84<@Ym20%b)Q(znKrua@)lo$A&8Pd_{hcSo|96o(;7mQ=Fn|`BF>vrL|Li#(b-+V2X-14DS#v4=_i5*V76^Lt@OeH2g!1@ad2h^&rR2~J`8C8m&xD9IawQ|&QL9kVDNV=eii@3L)_)-J?h?co(!t^nlU!(@sioJQ-*H30=!u^eDS!;jWCvbgZJyF^HvxaoO8(6#aT4Oh3V<qF(|mLQscDe0#>&=C;_AvgR<kX$c+|&>`yOOJ=*cVB&U%mn>f0B9LesvBfULUa8{8IXI)8|SQEzt)o2C`p%UmGjwnKilY%3)3k*5JVa>Y?i4NlSF{mGUK}MYAL#Yc}z>8RtL|!bVI*5!>7m6dOJwM#Trd*Xa$#Z=xld||fZpCOvZ$@@XH1eu3l8upP5r!#y^lctrS+8|z2(EgK`_glrS^wGS*MA7$VSX{loSoXQtf#=ttEX7pi4i7-X~4DPik4H7Q{(H`Sp5;!+AkQV^@y;McQufTs*>zYyU^5eWYE&X7}!;E9)vD&N8;UWNcK3$jR~vys)sIcj(DcHasKAK3C*acTzecMC^}*DZlvPLQDlomi*!QsuS&bsSD)EhI2KN}s8VqoH_rpYc{YJ-?#XbYNy^W4)P@WWB(CwHz@Y1Z+Isjqh-P%!{ieY-N7i>tWbGYWzT-~Itzu%vM&{;IxcLkFyYsTXyiU8n4j}l&ULO_|<t9%htw)FKeFe)L^8&L8*XK*)5ksx>^o?^a8NRNPJqaQ9Q1T`W%>ZUzX{Oz(s)Z9#)KTW{L26Bh(*OYaKZ6^MuwpE$*??beV0Efy#?v!Pl3ylBnMCt2wAyrKp-tw~*nYnweKo_bk(7vX;Gm%pJHyMESP|Q>uVN)kr`xGEj+Az(q~~<_jeS<kJJ=GfV2C^+9hATg61JmxNSXV@B7oGHuld_1?(q0%sfcUQ+R*Tz)KE~H`qZBY;pO|q!(B_Y#9!2OB%ITUdSC|b#Dk`;4Qs`|#f=6}j@QGPhfAD!u?7S4N>e{>iZp`93kXk+k`Pa%wOZJdJx2k1FI`V<8ZHyg-1-XG<iR%O6WL3`<r{c#!3OQ?J3?yU*G+GvL_Cr)$}FzU>3u<n^u{;0DEAA;uv`KnJ+|d@jL$cF^Vc<etfoKCzRHPDgaYHw0;kIFw2{QIP~d!>qYvrD0C|f6^M*DIZig<RfL#U4ET>wWrr;}{+MpA{SDGq2B=nQK!nWJ;{OIHqErGDlscq`PrN8&Y(1^?$MK4g310&%p$cN<0qP>5}lsDs=X};)DT9acSXpry{uM>#$LtiN&uq9Y~V;)&l4PmpySIT66JreUYwGe9YyH$P}Lffdu*Pn&ldL^EMLK%v8S-R&ol~>$Ti-4^3Gjeg(w#R3?zx!ip?$LCNPDAv%cp)&SKhH;zt=AZP16<jacd0)|JFt%7zFHWb+UXgzOX+{+bK2Y!4KB1sLobNpkaPfr_+P}4A;u$^s4hx=);KDH;FL^d=xT8|mrJY6#o?~f)#LVeIHl<ugWP1oB%~S<T*apk-4}L~x_N>OQ8%YCl>ZnVC56f{r+RL6ERuEH=~ehmh?@Y|Tr9Ub#NBtXKu#9W$8y>QE;o{N+kkJNt48NqmlqaN@qhn#){fb3J$RoSfy*oGih2N?Y_OtRb3R4UT|%b{XR2BH>!`&tecF16oOaJb@y4@Gq-9KzzAJF~{mSMj@+v4HT?H3&PQ$Te@BRIz?m~4+*Yp}Eq=lMjXIzkVqQ8pd)->;+jP&0byllTI3UF5IJK1Gr{s;-$4!D#-tu;#lyScSP9_oC-9)?mz>xu>AHf;lf+|gs-vw7)UW>gM>#<`US@Z3jNA8{@&(Epl?dS*ierXXR209{lb^wCors$)z9NmLsVsB<fVs6^JhfAKvF(*ZT^#9<d56{7)C&T44T3?E$UBG+ZG%5Nf~01APDc=KMcJC=$ASA9K=-J>}nf5|Bag}M!a`iOdfCGd6v)C3$Xsmzw5u1e2L=EdC348xJsvFbap-^a@%Zski48z?b1xGg$?ah9N{kh$fVE8>AAzNL}ioJ9<H^?8HzCXg*^g{v3ka3MZLBHIQGjA#s%SQ*CoGgFFiXb@K+g}gGR+Ybxcc%MZ*JL}Jhf0)r{Tx>6FG-!t#ng3cOx7_qF93!(JOQ)5olnh$MO#g2YFeT_Ut@2(JDQ?QrpusvU^G#et4q&e{bx^nbOe)rDlGy=gNIXZ3iq7~;Foj5_up-BSPTsnxh$_>m9c=~r=BsWe;!WVi+D7CriOE~Gl1=Ftd=8qK3<{5|SzDEQI8czdk(2eio%zq~KfB-k1x-c$E6O*IrkHr9P3akz<|D%0PxfCyZt1*=y;~~>it&KKDs-m|c9HB5=NF1^%Y!Aru96Q<Dmp{iYs)vUF}P&Ih1TNn<ft9N0hx_p!qDF*lwn{~{FWKs#1l|RyLR;kPk9*s_}@4>c=9rs34hLCc4_QDEY`aDC$XL%<B1PIJ`8559KtgbKl2WG7q;sE7Tj30Ajr$9oq;|vFta0`tFN(tD0-+qha2Ttx^8+$Iy0i-In9KTO@0_REr_XS#E<|?HX>&(x07fY<2rFx&Kp0Y4xpRE3C3`+mY3S}D-)QbIMT-nz)HQM^zGq#mAi_25;}q(b){_l{U3L_r*%yGHnm2)Pxi_q{<wuS##7jwa^Kk~aFb?$cal7N=<pUVq_81xT{c#kp?|Z$r7Dy&KzOrYi^|cI9&-p+`@9(E<s%UJjRM(f=9YpoAWG$M77b=n5!!1(IV|)74J20;bLj`wpfkSiBdo1aHT&&FO`Ffzr(Pc4*H>jUZI)6&S2^E1sm$FuF_7}6hr>UKm*OSW`Ho;$5?ClrHM&qZFVU2B+ITBG*nw?!^MT6$nRxNx$Rc)1JQw&8?95Z9@dar7PcP9n(y+~p)c^nh^aN7AF*`!t00HCw0mAVH|0=RqvBYQl0ssI200dcD")           # (= NB4T's), dflash_seam.py (parallel agent)
    NB4T_LIB_SHA = "11e39802758b5e9472c9d341f8a909f4d170f23d4fb8e756ae2751c914c2365e"
    NB4T_LIB_SRC = _unx("{Wp48S^xk9=GL@E0stWa8~^|S5YJf5;Q!o7xm^GeXbna~Q3)_)cIa3Kp?M;PJ(ZR*<5La|qw_8nPfyP3YG$7PpFQdSZl_Ml^LvHSz0R>wp_-LI1fh(4;d12YR;dgxrTN8U3zVcp?Z>nKj8wErrO1{EE#9W~;hKu)Z63@`Y4Qk=S<)fwpk4YSGVWVcQ}}21jgx{<S^;drckxG9rU$>zvCi<;Hh>MWwW5=F$^h}>@)VkT8_f{NqVW6DBmeNX=-qU^3^Qtib^F2V6`*u6TD@9KWCX95dcGjZ_zmT6s+zj-8Answnt;Xf{N%KRj02e!3^Yi|xhLm!@PnC5V$oB2;lzv2_DVn=SGL3))huV9?@i|c!xIA_3mokW(`6MMhPkGMe~O3Ct)tIb(g!iI)|eW66bRge2(-?yWKM{iMbWpb=#UPc@EmJHh>B2KrZ}hxC$74{s8>+M25P++BU6w<m?SEJbF&B`r>h=F8DTo;^NwfI`o+Fkyvg)Zw1RYuSyZ{EC$-X>-zC!SLW}!8=5eY97;VRf#v{?UNlMpY@9VHA4oW?<(`ZLO@`q)wKO`$o9@%nHtQUO;68;G7V1$$|3=hhi#*oho?UevIZO6G6;_u(srE2J{?tX*SO3Ru%+4q&EnDtb2#M11diD$ocdnTfk53{UWY`R|5dLR@5AXcD4Vk*DPjwU0kngXY}ckHIYy=mu?m1~FhzTZoS_&iI0<h4^`@XlNA{{5>?g~oe2eY$TAr>%~v!c6bvE0pcy{h7kb+&*dlLU^3~;_lCsJ)ftEx(Qn$q<#;<qStuB-wtEGboo2=lfq@(nzcbw?=Pb3S{<sj;082$ERLXj$j@X?<-Avg+3pxpO1sply!LTPw+wdb`!9^1WsGW-!<uSECHn==ag1_MBu&E*gw<RGtS4N1V|hW@9pO$efJeol0fB}e;6td#e=<D(jKhV*@&!v6=|L0)@uuo$B%}s<kLX%sJzlg&mq58%ps|EL_f9OFNlyBRK91u(gc3%v4kj_XS7d-VfcyKQft_~T1|yE3$*DoVJ!BNXl&7rl4|Tab$7ReH{z}rds^~6f;&WU*w5cM*<xfosPRuDb`_KTob)F#2wmX?_Awo3=0f;G`z9~(~;7eK(M`@!wGWDkQds#|*hZ!=pLV&Ycc;?EN3&27}eBu*2=?&uXYUI3qqnqNfeJvvmcR3NgNqD(4msR-=XZVaTx2++p2re4}kFiBu`iofAre^R#`J;!G>C>Kz3$HzKWzYXAMA6y<6T<K<_Trk~Kq9uvNWy(3liJ|DNVlS}*IapVN>WjO0B%s<7q8JielS?~WNR<WsEuj+?4+>SB28flppT4MyC}$s<m<F|ybO`+B-lY8E~#tv4+^rmq%ZXIq(M-IpcWazv*T*RJ#5cX1#C)v%1xnqX!&Tbo%?RT9jBf|4p-;8a0mh_r=OXY0VzwI4|lwo!&o+*7-!^aGOFB34Xw9VKoTJ-*@}z0bPcZ-TJ|0F5-I+$d4n-0!iaWh65<aC*!9F_y&G2Cy^;W&8A09K>y=YTi@V){`)wd9S6|d=G1lp@+U#WbyH=|PvPRIDc#lRSZ_I>_vIYN(pd5@^-O!GgK<2<g&NRJO`OvH->7ck;V4Y4E80=QF%Ck{*mB%b{c<qlotS-Dx2#=}`=x(&rUGHJ5Y;uBL+Cn8P%d56lqeKX#aKR#fV8R;jWl5ox=(YG!lOVB)+!}E>{!9?q>z}-*2D2`Q8$0Jk#ohyxig@ME)Gh{TkjNHKZc^2x0YZRxoBvatS&aTe^vKG^0HJ8XNJ9LKz}?H<s1O54T?ee$dF|tANT{?Gx4D1kN~(Pjr@_QU^x=yK=Lob@_xA<7wv&idBW!)q^IW9yB#PUMYI=EIWFLAAdm{(Yf}i)mAMIry+0M}K7FDg+no6FFA9gUab@m3L?ra_lt+x3iGdLf0InC{E`txo+_nai)2MAVA&N(8{cg*f*X3(n`@TZhluSsY<g=scJqTtzq#o43xZGB30cY#z&T(7?@EUX$5Hm$j4X2~bT2Q~p$Fyc$|mMkR=kku_wIlQiT1;@yiPnHiKO%gFd+h8fe*w&Y<e3r2bU}z%a{%5zG;!lD@97g!+&B$(v3@eSmDl0B3O~mx8j^PI*RO)5<$%kO@;dkd^r!jqwvn6Htul*R}JwY4$i1ndJ@<xLgPt{z^njzA=w4!sSCd`phJR@}C`tf}260l=wFiTeBI}w(J#>R2rBoL!Tskq+%A9WxVMHa1`s!{ID8Y?LXGyl6~&|X%oB3=Zxnx^vxL7ns{!$|_$ZSZdbZD&kJ-js1mw!exY9|lGXLGt_@=&}!q=iz-Ah9uy}OalE-hO5o~hyDX>bpxg5FL9a0IJ%+o`OBu<l()r2xmBEy=Mx>-xUqKxUmg0?v`!11-b2oU<ex{rD-kZ1u&^g$OWE@#smu+k9RW@NZmnueT4tu14^V!^lnawdwOLH!6|K?;l06;J5|Lt5?tEo57LKYD0tDXE4E&RbRw%`vQG|D@fe4Js@|fkaN3Q=Mdukc(1b2^_V%XQrfbv*EVW)m!q*hnC5O`?$d9Hswcxvj(R+RP6i~<1*fmctpO(c7wx-V~B80;e~DG>N2v%0i*yQ|AVW{cv(;rjxr>p%CrJifl#1!rNyH7%3X64b{<)<00!s%FIp*1X-LuiZe1=5h+%4A&F&w9EEP--BSIfz^Ul@|T!R54CM?-DmyA{=!hLgk%$Ak%OYu-F(F%7AA)I>W-h(0Ak&Jz@KDv_QGN<(V0OP78`Q3mvU&`GX5b4%K{#ptn0<;qFZeW@(5a*&!LmjPcI%u&AoE_%y42dDP(<Nz>FPBhJi${8>Ig@p7osUxzNuA;fYk;KHyM~fP4yjp90LqY^Y>U^5X$u)sB@|LPza3?i`bzJ?~JpZ7-74fye#x<C(rirrKMZ8IJT0$ntX#<kh)1@qT89#0aaBrKF5gEhB^!Tya==WD8yn=B6F6K$xxJ@bgD--JR|joqdr;%VZ}7t)AyJ-HO|t=FO~S&ny`7RHe7P*K8ep2e!rU7c8idP-fsZ@MCP^+ZioldKud~G1Ofm3{3Od;{NZxfDv;_*A73}cEQOoN7O|T)eR79zkKOiQi~r@z-?$p%xo4FPk536xfFwfR#XG}he8AS`ztTzRqg>2K%;(?BYeC;5T<=t%zyc<ls3j1Zy-15uMD~QFJfI!e#pNwmh2A(Cf=x!ub->Hr*LhMcuSRT`lprm^%0-2R{f`efUR@hetQsljIm!Gp06)!g)x3-MJ)Av^nLc;lFEPBid|{`=OW#=Qvg=b`Rav=z3%EhZ9MRwA=yY}oImvtWa31S2;lsJ`V5%B-UP=)I3k+<7UKd#VQ&&D=XP<XcXBCZ^{+1A62GV(%@-hXP`Ef+nvj2m^l!KLO!c&}s!Z3t-1kq(?GpU6t1D}6G;TV)p>7gdT;I{7&%eTtv%X>>ddm$NB**H%9rl#ggcVLVaReBR)@k*F0<Fd>0hE-RH&Nh%Y%M3`h1w7jm&;yfL!g4lFgoj<le4XXX$`b9f$7lL5H(BHceHgwojroh25Qw&ZM$&crsB@D5Oq&QoP1{{A{+ELFRUjpIDw*|5Am=yStoT8WLz!Kjn!JnC#DE^PiEmKe8i~uk$vwyj-rv5+MJR}>la1!Z6L)rx0`Y+xq2%96!tG~QjOl9vNY&TGz~}-xM@oQCtCWlgu1~R7Dh8oo<aN21!M&DI-NojM5CM~ZM?oy1iQSJBwfP^s2v1&=(AQ+h<C(vB=6>hOaO6n%mp-zb;5D5m^imoLcbZQnbfrHNsiPml~wRMQNNR$O6aBP$2<orU@}9^|GzbFSb$GUEbXWi!2rc;i3d@qYd5D0tok0K@eo7TB9zq{KM{0pxW0HHY=4|%LBu&kIJtedc1f%2(PT82p`=&3Ov-K6CYsr+fIK`|XPGs6YrQ+n1N{tU-+Q#|Za{}fdeLasO0mvcZa}Ci)Nlk%J(13jw5{5FB7;;WupJ+_W`WTo{s?yma=>6-=vZ^WPxeBBU8wx7f*TdS6viB!U=!OMJ=2gzm1WPd4ZFBMt#Jv21Mcu-ZScN#SFKj0@pq?cz))l-h=A--cKl2b!7Y6<^(sP(#tdfSejB&sBF+>6(Mr|$IfVB*;U?HHg@}@`zcV9qRo4BI)}8^bt~g65&RQk5=JWLLf#cJ2H+>7+S;TxBf1*vkn0PKKF26MG2WBYyF{(V&<@fHnFGxncNy$7Xs(xog;5lNU$n2s}#Io<ND20QSl|~-6R{pR~dqkZL85E*)dV8P^x4v~ufEBqQI8N>%y?A7OufAy<k#@Hhz%7NCKH2a=soT(oNkF+(kObrA{E_ij;0g)IG?^i0>h|k%{6jABG*f$WTd`Kyj6cD2bX7+fM>mxjJ(4ZR@aPZD4F`=#4=7+ozH-Rld3+E4-39M8z))$H!daJ+6^3Z4T4`~Cd%jZC{U`p&R`PfTG3cZ=;sjpYdu&a#9s_5{1Fxk_r=<9g%kNd3bw__@`o$y!S#dKhqT1V7@5ZyRR@9q(53th@dLH}IjKk7t4(CwvuXT%k?k0UA`-p-Fwu{rX?C8gWF}DVQE&<9zr}<F>TPb2`hwFPq;7z`_GHqY)GkTb)IF2D(r*o=5GJIrvS6ys5M{ZfoVQv+wg~2n%`ee@xC=QfTo@__KBg7dCmU*K>r*uC8v18v<V`d06cPlwQJ2k=3jVoYib5tQk-mw&<mhVD4VmhnveQ%-&I7rmaWW*>xJ@_<3e*|h7rW}wAII}`8A|SX+EV)ISjvPYc)vgFch?uCkx}1&gW>gO{z$qsX@?0Eem_?Rwl~ewG3Lwq*i<TAV4K(z2<$4Fk&IqZM1w%Sg28ktN6FJ*6vHUg5maN?g8MGKTRMgm-KF2R7?$|h+!V^<LKDO&w4ATthr>?fI$r5J|QiYQirsx+l21`m4_|E#P7tnQ)7ydfw$6b{MyB_T-)zP5{gdJrMj(`wZ8>KQjCt}8er6YzN9jh|emQ>w<0E{FKTs1t%m}mnoMxX9Jpf$?nzN_;tTMpqu+PR`Y?YO?%CrL2YFTzBy$wnU^vch-(_R!wb`R8!-=X4cIn7y?W<7s5QsH9p=s;;>wYtXC;!1J6`hc65!27{pp?I<-*-Mww^4xmYvin0Z3aCfr5RfI!TNkj|-2;+sZpDx5WsS$r75LJF588++<4xWj79hmLneQog)AP?~STgnpGAc}4o(>x_W6xs?TcRg>(HCNmz0?(|D8ovWhaJEgRJ_mY_<W*-X>D7a-7E;Cnlc5JPcL)1|(f8b6fix_=51g>czHp7c5o^$2JS(yji9)9r_J_%QhWzwA>kriCMVhLtbr^;8DdE=J8e5I0sKY0-<Gn#(c{=hY<$}@6%L@k)+VIa93Nf5wVg%G-igkHifT+@pYKbXatZ!&ZRflYsxxb=Cb1sf4d^4x7BB|gT{5N#a*!fk(m1Xl|#2uG`X#{6#qY&m$XrZP)<^!+l{1=1<b!Kb|NcPNHNk>Zn)$$7{<(qx~d;o|GZ|*sGVeYJot%SZYzKSL#gECtWL^e^?fw<ukrcMeEb1P<9htC5M=M4+7IW`7n@Rqmv=t|j$36$s4s#{v|IWZMGn0F@R!wAT58gL=%Pf|htR)(?vrAx8SJl}fI4M9Z0oohQR=|;{H-P3&2nU6|@ftxxI=T9iOdV!smP&`H+U-V4GMqz(b{Zu*cEhNfUa$!i|!=lJzEiYKXbAmz!gSjq8xr#jPe{%zJwa7`V_&;6WSCf>$36Onddy^2dCQig(VcoL%DX>r#bAp$C1l>|T{5<ZGO_{83is9Y#Ly*siA<(BxVk7>?mG)6%3x!{zrR>+$ieA2h1$zmDoivE%W@yGh_4v>te#4)KnEj;0uvw@&+LPF13x>^dD4<`!(Jx&g|Km&Q=tObLahzpH;6h!~M0Z1LMPd+-P<{$jza@_G>-bd{z|l5PCtY0wc#$VWv|>i@MMh@}VOY-)MZ8Od96bD__JL>y-lxqQra5-|Co^DUO+pdAyr@Qchl42GSLfmXQU!IXL3!7Vz#g#V5w0C#5$<9h?O{_~f?>3GK(8a$gW}~2T>*t~8P3V4iYHtgeXuXgG?baucf>oYOgs#0Rr57&!7UZ-Zz+;i+m^_uzpFwF>@e+ICv#Yh!7zuDH_;WYXk<m4D<rov`;mk)<b8RQHu1%ej110MDYx91Sz$L#y*pg~9fD}H2>u+iJZAK0B<sD10$KfVFYi`${r+GUY`A9x)8o<vyO0$)TIN9Kmq|M-Py)o5$wf#NE7be-@akQBeS<0%2O<)G8iSrW1Zd;IRAkM$FCT9YY{dVMdIdIBffbwL0_ZupZ=e$41mQ%_jcmD)0x+B@npYI^H?}PqQ2FoP^e3IcZ)G=j*fmHgp6PB+v5bwJH1zr@)(pi$pLg^k5)tRrC2EC!_v2&_tz46_qZThpuB;4pg(iQz_eEz-f`SD;8SgY?ooE)0qb<FnG8giS`-r>|;gK5+TcMrudG4y3#iD1=Wxxcqa-B<^4XIuZPbmkc$wUYbBn2uJ;&SAeJz#SWR`e*K<9-*zQEXQXDz^BpY+_y|eahGm=Qr<(x2@g79>yE-(9T8X!WT*<TN%R<-YGrSMhl?_p#e$X46PIzumk2m48rNY3x>m=P~%6=JaEfW7E`GnQOsUM405K`d3+Rm;k$|}AshaZQhQ}GTXMjk)&EXtnDaPZ7QM)*)|>8$u0f!^I{~+)#_^xwSV!Dtncz%h`@f42r1}}P2>qEEEhAX1xu$OVt&1cxjl=W6_ypAZCagzuf#~5>iicVCDN=l8B)oc-ogDMjCyrFGZ}Ubo0+~N+4JxFyC&;!9`2Neh@eV*rrO-$|e@Kkye1t^$ZL_T^GGC5v?ix0R0h4tuu!%x2PVEQ(b%GizL)B5X?d`v;QxS}hLtoCku;2Kv*Hk-3!MoTz=9ZqaN8pKDVJTY!Wg|`ffI8@f!EUX5^7<nHUq~jx&5h%PbR|=TG>0-S;@`m3D)yKmfW2)bX*O=^T9;Wu3|N~WMU+I_s6f$8qxni7v!1L_(%wT!YUBXrhz+yK_7kfXvWydm>`+N?DM8?QN0^wMxr;ygkwjnHA6XJj>X9k~UYI&k1IiH>U&`+V`fDEv?-4?dYCb4sOz!lUTe6d(=-uy$UUOJO@*9pNw$O}w-LbuN<Q)uxlavba7-MfO+i^q&%|1uX`?H6@Ye=;oQGyg6J5G!C*-=?6K(Nz<O3G{w;mwhu!~jrg2NrlPt!4R}TYa(%DIcO;f>iTJj$w4k0OgdKzYT)C0}hWe6<^*r3I}|nx<){LY9ykD66ibxN$uZVe2j~D25k@-JO?rwF7~ICBKK|vM=X0Y!oz+{_-7of3SvJ4n=?;fVfy>zux0aGk06ldqAJBPS@^P>2cmgH*|R%q?!F0&9fqKrhQq+kTd~iE8K&lo4C|@AQ>zjW58;=r{11=eWNtTQjzk$rPuV$c%iOUQ91#*?J7IoBZ6CBj4;!&jYU1L9_XI~Uh^nCN%0#35W0&+5tFMJRR6tW!>2hOV8Unp8LR-q!W{8X6L$(-0vr%@XE^_KVqOx{Q64yR~)GEjUM*^+N7b+pW@?dK*Ra5haF`ZToe7`;_T@FZtUe}Sn%e4MSyFTs_p%$HWxYG!Qg5z_tQD)HsN|FQh1DgJgT-y2qSW(7qh#=Zvx=8=bW!sr+;Kh-iT0*ot&!DIr+6Zjr-nzGTn|SjNb611t5peo)F*YU*2TV)Zq~Q=WZ@RmG?SIX)A^&)I^AiB+9%eN@8Oc*!b-0C=G=EE3DgPlNiNzaT^F}#{^3AUPY*Rjwbe0RcRs)N6>9v#&A>$w`sV8$u0cO5z`fDpu)G2QQ>GwJn&QM0z@c3g}t`Iq7N+|)>8HML-oD@!C7<Edc_da%MI^g8~-!KEUIelOOQwt}?{Sb}NCR26;XvQ+T)R~?B1YzZ)WnKX4%QvIp`B>W=(z)+Xg36vYRh*z#IlVk!`ZN(Xr~yGB$cOK2SK-xA2*kHI=pKFqnNPa3e9Pq8g?brc7>yD2J{t)ni*Z!hbc`~0MF#Ii4wz`NoZ+4Z6NLiBPU-GX>a+=a&^A)kbiYpTYzPVu;aGx`QvU#X8VQlFaXhUkHzAe})9mcbiM`W+-4V~Za1xuF>*FRxP?vXX0xIaXoNT%6mb2Jn_!uLa28<)ek?{9`Eema)N^y5J_+a6M#Zlw&_unM0`Hrd4qTflk_|eRKY4_)ly{vr<^H-oae#It*{~VI|Un*i%<$_$YCLAZ*>9Vdc9(>ZjAei^NvwJ4(i*VPbqX0>30~$^BUB!GoSrz0AO>^lsP|Jg3fhG24j{j-1pcgec-B{0uXo78n3WFj<LNZE7LoeTBU$gyb)mxmsS$OW9P82};{2SZyOyRIph)VcCO;s;VP0-L~I|<E1D8Xji<&8;M?i-i!ym1PFqx;33@v^ADI{|C#encraX6D$aRB8+lOh}{@D?abc!YA{Y1m+2Hp!%l|*OnCOsAM&ozL&r5eQO4I9G1Mxn{a>%uak}SS77jo=z)osCI<N+$VF;qX3pNYJ<iIO{DboTF3vS=n~NAed91hR^YnSdBQ#9ygADuBzeDPPZW^qA$EU&}XYrO464A~1)IxF-{m%B2Y0kG9(SI(WRe<wkQ_Vq+%X9Y6aGjol84$7K?(5W>mZNx*uEnkuZNoAw%~pLLfPO1^orIY9gcg_`XcM+H*tE7ZkLho{OT!ThOUW90xI@ro{P6|P-q!I5TrXX|r|Yb|n`0^$<13i5{&Ef<l$XZa2=AMymVziPzpEQjjN=8f2>LTymz3GAezw!*CIt_!;-6iRxRx$NizjN<7NeMuFLD2$GWF1AY*Vr0%?u1$HG}l~u@xLjufM3x9CPNZI2CTT4-d+U(w69v0uTWz*_HL2`bC`E%Tr6>WvS<$BP_1jib{iwxYmMc1+;^xtAna@iP3!COVj*B_+e*IzULL%DzXr2k*3%>aM8h6a*QJ0)Yzy)h^#t4nT}M{iY3?&0>e)WBY*V60K#*7&1iC~3IIl<;;?glhT3xSgEYGIN+l0ihGAld|4gyx;t<L6h1cP+8}wT)akk0zsC0A;6x-oR=Te?JPYk`O**e{OIvz-;0%5;2YMKDX2KA0c)HHMzawgqx5tVVR%mt7%u!%eomtPzv`^9Ac{_B*+a<@&P?Q^BSUB0&k5eU=#U!3Q)&nko~HvDkQGU|ZQU|kQ=nGJF{^Pvu4`YmAU!Ppga;UPak$JBY-k!8$xIBi=;JJ=h^OiYaLH?@Ma`rsbnfI}I=&OI5R1y)Luc*cd!^egHUF0Ra1ftWYNI4Zuy%`})^H_A83DZ~MCX?h4-lOV;0sh+4Q@4A{m|9@q*+aI=FNz)>|XouU*YV&2IU$v|syaj<0JFva=5ylXC0_;;xWk0MU>u?n#)OpiAIRSH@dr`-FVzj~LbSnQBn3ynck_x|-n9b2g!`9;|(7}^e0;F=2wP#X=;<^#0-3f_Eavd`gjcCdO<Wj^Gr1-Wks}rUV`gCDGeOSH-5~JfYgK(+ngYs!k6(!l+Itd4rLM%(%5RU@_^dF+ZhCozul#;A>m+jLa3Ui*3Zle}v2G41OtVDt7#4{B2Y5o6};XDjN-6VNkp?@wH*<yFk?t77G3^PqMm<`FJ9W>Sa{8LefE<0{RL`^RLu-hPN>+KeF7y*VqdWvq}q_|q2b4TtU!Xvw}oYT#2`ya}(RC)l6BBOJ0{##$r@B<!jxJRNcju4#H!NVlt;o$NJS-`D#bPy2|p68!<_`HX+cnK;MBmA%*W0yRWLVB)tv*ZIzHL0V`#%i5tFYX6Pw~fp9B9^aafABh7_(R6A5E5$c@R!e3$>t%za{3udt(DcXuzltI4JQHnC2G6gu$S6P(N98i2zvu`0%?u%UjuM=fLN|FP4t#pR%9ftqAj%s#7~gc`f15U*nKrov>41c0<08;0ak|=!ixoW3a8U5p=cb<O42eGN7i!A;>x1IGS+qtBf|w=Yw|k_qk^97Kh+sVBfj(|nI|m-^2j6=|EPe1r^%VQzsGIS5w9)36dh~n46L+Pag2b1d74J1ndRHsr7QV?V1Uv5@v|mrBeg6yP2D%zngKyQ;wxb(HRPIRhzR>^FNV4LvAs_w91dr^i6eUgwBLLCkPR_dhNQUqkEFz#p{24i1JoyX@I=rnGjuygRueM>+W)Ra{w6uG-JeWXtw?jbpvgva)&w}jIKLQTnV<ArnT2F#(i5Z4(A;wD!lZ*ol0nw$EB<>truEks6`s{j_E+($Vhe3N5jVWn0EwbxcaIhcA;pdhKH?m%B&oan2l$4-!!*RC+b~d(YOj@rCDKm*1|U;qb}#x$yiIeJwQ*ZCm>c_e?V8;Nl}R5?gdI~c6huUx(@O)ZTapOj;v8J65cYbVHJT_(C*IUjM=`gHXuUar{wNp3OL%0x8>R!i){V#MZjXSp*M^&uk@z%*jXUXQ4>Q>qXB_*qucoCm%u>@yi&fIYlI070`q-nBSykG$6q0ynWpuTEb`qNhG#8WL4eyiy(cRnQkX=b4`?4sOl{Xm%RD9^<1E~XO=5v3r07QNOxqtF+ngFxW9taemmyE^AutUK=)Dl&Lz=eTq?p}{3qRyKqnMoloS<9693}N_jy6%g65DE6YKA&a*^#pV?soO;fW+X;bAH9b_7&jF&L~9bR{Che@oA@ncz?I$EO*(=WsKDy5SzfB`fDKbyj?Yy=ADOFXr?!%@aGaUhWN>QtQ4aw9-nqTrGhYZ;jU0kfC2`d7asKVn6+l3^lcNu`M;^=IE0f!$crh9Z<s2Q+Y@sKzCt}Q-Mn;qKBkaXOm+bOlVuWPD-=YIIKv&yBA3|Vbfnsy;vytH@OzCtP!!!hW>a>KkZBn40Diuz_ZzbNYExhjQR_%o;YdM{kj%4CC<@2VF6CMEK&h_tnq%e9}nYJ0o{JxUyVzsaQbV?vJn%jvbR^fPxQPS+#U@n(lTCSpM<>s!+Q8YwxJ~FdBQAI8vE*|QJY#qoynH!y3*$hPZFP^;ea*;w9GRbxsAj=N?3Dm9|STTn+GdLLRO^czLBqJqHHv1~4;4EnLHz{MtSH@!D_>R(C;+w5NVz9xaN1q>!o$x=oOhnSeOrif2i_RRe)<s%Ef}Ya>C96c0w?+wM9W$FX1Wqx=kXNE6JD)!FKD^~z?cCK!<@j){xx4o6B55)zb+8t!Kn?M%|7ZEF&EH|Ln!aBxp81qq>`<d3?VB|8Z-Rc9+xNSE9F4{n*n+XbNRwN{6hnrKYZ`Nn-VN<CY5anE(pt>xSwOIde6gvedf`@%xQu#CLeamoO4cM#fhZl^8jmri6eBEHn$Josi}S6uuCOtBp?Z={g0IfND!mJt21YYlVz;~~jC3eB_HNfq71z^+0jSwbf=~DFP`;Dn6`46>XjVCzZv|c&=3#v6WW>t@eihqcx6I>(vW;gHK>$WYg?D;6_kWe+mP*)<2sulT3XU=^KAtj;!~J$T;n)$p77`Kz*M}M9Qbkkg8x_Xc!*1uez9C9olw$iKM;1`TUdRa)#T$1a?WxWGjF@&cKbMjmaknqH@1~$7>LE7e&4_{T(ZyY%Uh_Ox=)LH6GZt0w^#qY5OhdcTOw4ckMQT15om$rp*NV5?N4|qw6FAQ>M2_#LBL{h1+_K+W9|W1pXZ4YWhnB)wgIKCy{k|5+mkpU7^e^5KaT9yT6Or_gZVCC2g%gMoL3=ZqK#UKIifm}#KhJMkT(@_3nfENV{1(M9-;bq2_8Ec8VzZ%2H2erz#mqHIF_nT|7|ab}6$sgKvS*!gRv52rHyKRK1FOm;Tn$O$pvf!c@|LE1q}c}`GC&=cX#=*YaL|~VAC><P>7bIjfi?i=r0DCR>J{2+-G@*>2mT%3G8XpEQ2;YQWI*_}hAQM0&X}Quguji%yY7v=M0`T&Ec^@D<Hq&uH3Af@%*z@W<67iZ{)n4MFngu2U5+-oM-J?RB|lAR*0;4?yGaHqY$EJdBL8TrytV1EW3HwU#|3TbgYQu{V|jSbNgyG>d~7GIR=BRf4X*B`TG%F!w%aLt?;(?B7Ee6U4+pslpm0Nf4?%@<FFqRm9vkU2x8sk#3<RnTQzOko;LZ?uC~|CTYWy-y!}nFjJE&hB;xIrVDS~yc1H1f|3AaOA9dD-IX3Q_V4)PJW1vE*9mx|+S^c5g2Hl#i2zH(@V^~p>aCFPbRD6P1hgdE~zf<Ya%z(^Q5bk53E?E^>~L5lXePK%j0AfP=_2qGx<!1QyhH<BdGoDqw$`D186T-+;bZklZ1@;Rq<Y{}Oey&r)2+0RK%z+|}fv5bi_W&9ZB%ApsA3G#}oujtYjiL-z*%Joqbn;}$6mGCw?QUmWvgNh+JPzxL~?=m;f-+2v4kQ^($tE^QRBa=a+COmn{u<~(|VM^7J@SPW;vj~DutaPV1=d>+jAWD`3R)l^^Qiuw>X}Dv>cwNWPPYyC_c29sfvGzsxv^$S2pA{CwX7zxUTY*!SFS^^^bAjO$@bA-NP7rDDpDj?P?3FUHbLy{3nj`T{)xZK~3xoa_)4GDAWC8vTmg>oJ@M2H!@Y^=c-TM7dG2V19jOyBaWmIY%$_5)m3Rhc^z0&Uspw=E0PL{lIzZP=2YQ3)Yqr?tQ)U(gRzg8{lLUWa!sw~;h6%-fq2uI@UnXSvi_0F_Ky9|71S|LlF?^ZFAjK(cjA%GXMT0Ra(p_v&#O!pv)+d|<vkf4!Cew5-c+Y98N2uFo8ZL*!_B>B74OHcWeUg%pO#z&%DX%7RkC=r6pGU0?ywGh8BU<kpYiBKcLsKq|j<8gRbxSJlEwQay!>|1o>0n%n--bH#h)cx@SnH5kzZ@RQvEjABq$CZu<i#J=7TXRNK<m`F+j!1Ts+|&9HId<cg<Mw#i0i5@1fbGzG*1mvrzFt57)yA(CmAO$pBN`{#&LlZ|q>RpGd2`TbSL2&a%{nxd4pHq&65vRY&VSut92DketfF=ZNalnYJ9o7Wd_zmN$7Lo|QTi_WHwKqclVUv2;DgR(Ms#$u6m`wV8AcXC)JO10^YoRz<ki<HOkQoBwwN(I$zQ@uP~PY!Pu4|`MK0d;J9>uO_-k{lUnc_by{Lkg2{kgx;{Sa`mo)CgD^jA&FIrmA@>HVjZoN3xP?z`&PX8sZ8y=Yy?o!tVm4tny86$<4gAKVk_f|>YoCb5tx&6(7c<g?-cIOOPzs{z9G%pp;+$|h1!d}f(-I8g28MC}1!jEBrFj5c9+E0P)bR68Y4>d7UMgtx7pqr_d%>oj-bfxY9hmN;aMtftx;}|VgPZQ)m{>xJ~|ERyNvLG7P*QRD(aaFO=dV@9yqi++!Oq?t0s-*o=Pj9flWVMD3I8%FBsP+=ey0iiSxis;9+$W*Js#s}MokR+t$pEjITYzK806Bb|7`S$Y1ZY;A|GGGKR_6!bf}W_E-gT{pE1n)d#F+>-0%7b(s8kO12k!i<^ju_RaAPylpGCuWduX$UhO>`8JdKrl9bnVP{82Ue7EvnpBs}J!KajCsivOo3!T(Q8BW}gK%-*|h7!#?!Y`V}j7NlayXuQCQ-|`P$U-`_IXTax{)577o+xLz%xYqjnJNkIEOFFI&*p-?M6X-wunED4$I&2g!yyY$l(S&)|9cAXYRP#nZ)U6&>%@{_ssDU!d3O_BUX%OwTG?S^S>&<_=nL~7@;-zi~O^w#Iz?zKZOpg>`<g3?^i=TSpoy_u*A_XkdmWvxmFKXA>seIhRPpSNAtb!sxn>BhuvBe)#6;=_)W8gd2v_1&Fjr5X2;`d&F9m2_GY`cp_X3^Uz{eEflBAP$(`(d7e*fEAU+}RrCYP&?*&rFBu{iJ_zu?n7&`&Z-J&7uIgU_1hHoaG`1=_(+fue!dxbRK0pw1**L=SrxU_aQl(MNyBi%vCHCp~=%3E<N-MFFj!xhBNRI+09aWJLvkTc%YjHF<`C<hFpAPs(CU0oUbX&d<DlW*@hW*uA*N*#Rn)*iS{jvdjs0oF#XUjW`DrO-n~*o<D_E|bSzZo`?edA!H+9a(@^15=>C4*j1t!+M1bi4bJ;FvK5PcA8wO=Ow&hTh+wLBv-!=PFcc?_rAW!I(LIIOD@DVY3Kb!TOYpJJlY=C9{`04Bmg5y$to@2(LKJdGx;ezr~k60D`0IpR$>NWTuc>G9Q??%Qgha~y{*d0gs_vm^3D&WT@CwD$~J(agAxS-BMQfoUt);xfI<Fz&%oCefg7d|f32p^>!^cI}$O;o!yowA}8vWL^d=fC$Yz%tf80xrg!Me?aT?y4l|I3xFmc_661X)<=m>=@JCbY+ISnsM2zZI(}#i*-%sD|;dlr(8YSsZyqZ*Zy`{n^W?U%4DnpJcj@-*kjjdw}Y?*sgs6;sZQZhK#0#beV;~g`vd)U3<49Gr6QupJ}Fv6cFjs=EwFL)F)cN}Tb74Mt9?w7|Euiy*8;#mvlaBSBB$IG`(h=m^8%33^kaa-E1R2<XKiZxrDKof%o;6+(@3u{Z^BNz|31&#5X1(v+pBTK+V4qQTc2sOz0rZZ#(Zg64RF)k%1LcThluGgq)1RiBG+fn8f4;sLI0V`7Bje_rnNeXuCPOfN7mdGwp1~e|4ja4yp_1rD}HRoaleRQob;E`OTHoE+58eayf*U`_g|XYQL^8n@lp6jmhV<Ypp6?Ya&xL0rC=SdGUdl~^}jX$+^Nhl<@Zfk*uQlTFNfr#N-JlzAKIf6dJCP^v`gP-N2yMP0yztS<po;u+i_S|fc<EO(FKf*^nxGr!qM6i)j6p>pP25v5)R@XqE^=!e8$@rN9o_lB|GB`6f8m>JAslOM^tSSRhGIAl^E_`Wt-Q}#B#&&YAIQsLeQJ*-%{|9`%(YhZt&Dc8e%)Jm;ABiWlK4nGR<j1D@;p974`augT5MVSR0-%S1iioorV5+1u~;qtyzarHYmZqw0(7dY1gGwS}qIcQ`!_#G*i8EPtyU=tP4jL85kQprZEhgV)^iaCTOQGy9B3AT4f1$O5c3}Vs>Cg?`JiBp%Mj|7e5Ouj8wCV3)s&m2-eUO#~!Hn9sbNR)k;MVzMuZ;Nq^ax@jB~S)FisjQa)jFMa47KbA7_IX~U4gin$cu_LCsis&Ld6wMF`qX%fBPI0QI&+T(d6tilb{cmAma!FJ1t0vi<~DswA_GvZ0W3}<KLKJR|*qM$on6)BTN;x7JdzKom*O>Kzm<@hhTZ9?<+e1$ZUrB$W309>oVjzbG;h?9j2X#?XPA-`xDJA4B`Dvi@{!Y^zg6^PoySe}KyNdNh-$L#oP;s9^boLxdDUXDfK`(TOsXN-KW)OG20sJ2e`a$#VLLV2wqVn6yG2up>Dpw7)D`D0r+fF$d0u2TO_qX*XMxlKrWiq5OT``g126Q=FptC%>z#2Q3dh`QI$ooqc$g8_zdnidbA(@<|occd5>jLHb8C1iFHH3C0vN!7~-?~T7TGV^d;08~%%_YZEc6aEVbrk^Fxe8+a?QQ8p4UXcXxdmOc;(XYTJ0QH;8B|8%=;{B8`dAXT(yDKd67O{l+RCDYM<Cvk-DZaRm4dAuASpLWNZ3&q|`wBqD%9xSn|41!}L@4jVt&KYES;X{%E1GjVeZdgdCRVJTrhR1hs4$5$=L(VGa_JySbM<wuk0aw>qw6)V%bj|~rc1+ZAVx}nyEOjDVzr3RGBMYE>b&@U!bLS1VTsAQw0`-fI5AS;@6BlZ?gY?8g(dr~Fc-4w=Ee`7a4U9F+hDp<1-f6IskoMdju*zr2Q@j&+Li3%i{K6hV+7tf8asK0k$Xa9mOV-}QRa#WcoHHLH?X`;+QO}Z4}O`sCOE>|c+nyY6}Y?Kyl5~?hoHO?PMbtrP)A+V#p(dSk&$y|5;#l|*^!DZC5>@2%$8IN=Zl2)7<*DTA4W17@%81x$YEvYbzDru>Lo|HG6LY~RGEZ+&J}p9NTU2ONio(K@qiYo*FV`JzUY)Fw#A9Ym70u-e@n>Pw7(_qT^9dzyF6Oa`vPSNMG9tRC(}3)k);K;jP0XVRn}Q~FB7lxdcFxP-&tp`<g{b+&NV*Pe~Z5yD~_RdH{_&s@>rQt7266Rxekq}yFlxsB9}=^ZFoN=!igTbmCCS7MNO`;mf&E8Bc>q_Y6uf(%kpzJ&b@%&jzH4Zjnp_9VmF0|LX_H>FhrOuT8WvRwihu*3TLP)@VBspOA;A%_y=hc?5N>zeXj{zARt6+1;5IsofsF2UTX9X^S@=MW(kIsBC2&wQL@3ySt?1c<6Udr6YKc^41JJWznOezV#AC7KeIoB;Oe=U)jd=ju6)|tJipiLlAkPG%cLcA7CRoL)TE#BLqO^{KB**dQwalHjFP`2uUT^}av(g-jAOAX?zwkWm(HL)&YH|LGxayvr}W|8RPyK`U-KNw$G~O{T0RVn=ip}jtK)l&X*USdVm8dWGs3pxh*i>i1lPf}?TCIErsj+_wJR2Yr#0PzKTTl3sUhXNjQbf`m_*C1hVMrb-C<Ge=D?KSk4i5o<{;?j-w}2|1LtF7&n~8l{yRDOlN7kxcp9vG|DOZ*Q0uBHrPxCzM)t8fM#qI^zNT_hGPsC7|3C|3WUShbc1fYA2?d)Ed24Mb?xR&cPiC22+_PI-y(K0N36881q*`kPWXBju5toqzvE3((dl57X07Oo=j1@w1a1@Zp);_)fd(EF}(D^f7*9m^vegO%Av%4d?Iu1=BVS^O`41X24$-<fdtYnVb`jzRMe$VCqRQdlk3PtcKNSgr)4&4q;z#P-4QJ#^RvGkqF-(cuQt{^&Bo5tsbZ;fGT`wnk9M}aOUonlK78-h;*Ea63lS>Coj2>H;anoHYGK%c9ow~WOX3`x{_$cVIleF|0RGCO%53ELl<gDL1~u>D$<QfOELBDC7fDoO6uZ-S3sz=yeB@=Eqr<!d0%zskBh96G<p$f=4yC5*K&oT{=d^FA#>`X_|$7$0Z&k8$3%0FIxfsUxOt@wsC5y1f~|<ZsQKABF|2DMXZ-7{5J{RnW2q7nQayu!<Cdwhj6g<`J=A!Ee(~zd;>LC`zR4F!aulfK!Yf4U1H?Hn2#nb{l0RV#kb~18%AOv(L8qF+O^18JE)RXdTNn1FCJ>h;skr6fVOubh{?Wan88ACOgQ7|05v+@LJG&OS2=<p1Dj;DN*-{f0+Vy-c;4|0RN<~>T?I|Oj*P-sjZk4IUhwoC^WSH#$waS9{zgl$FckDYwn^~6#HZ2Vn+W+6Dwtw)%F~i=3>C0^%FN1fGOcASmhNyW3|M)Zb$XMTlvC1Gc7fb)5Je!E9*eg<Vki>#o+)&EK}UK`xD7_FX1%hvQ`$V7jt%@z%DqAOhFKqMXx8{au-Ty<=lF!+(jH_58`EO4?xz)UX|AIUYL(D*YIxIZMl&M9nDeG?g<ba>e8}4`N6ySnhbaCb{t`y<?F|93SUM=`Y8lFbeZ#6joR*+=9ngjC&h+F{7c8VaT}ec=3k_t2wlUV<MIc%5yg?$wB5zk7azmdC-|qQoc<Fy-XFe1pGu%i9SW<^Cmx+EyN$ERHeZ!j!0MEqVFbn1xO^a~<+t|B@B377BUbK^UIW!M$R6`}e8_B!OxHr>CU-LnX7HryrbKY61$KXy2T!FsNco(DwUAXT6v;IOUO9s~`?B~<TwM)P8p%WkEpy+BDMVUA5&JOyn`&Cl#ztaCCit7DfR3lWs;2Q<`%s7N%{3ulm2)4rE^H{lwC5vQm?qiT46!SINVBQN{K#O8sr1_aTqiq%?aC!cI}jvP+E>7@zhcwG($owPWZ#euCP7n5iZ)`-RmpVM+Pt%nF34$!iD4l$B?rp9U?f9s?btV(Ijfn8J`u*ZK+Hq-MhLhegl}h9U2<}YA#co~+xXP$v^>S)N05klW5c9U16vbuhiZZ!Wb`gjI#ZMhV?P1)fgR!s8d+K7OW12N7tQrJR{WeH<L*h`CH{9s#s(QtJ0PiV%PfT*E%bL@$J^}=8@*qSS&bN5baM9Sh+w<tB(w6#85mC``Ih*UlxaP}%$2VwC*45uD>!ZFdqDK%F7PKe7pVjoe<~y^4{#V%^x#gt@leH4uSA8I{*o;kaErfFy8Js4o&#Rk;T*qjQBJ0w=&MM-(=4@?AobEM2!9Aq$a$1XnhJEERP5T>@Ai5|6GDwn$MSpDi1%pSvXEjXW=!}F!%>G9dk+SF1*3(?5kmXaPs`?&l>h%@SB$vjK<WP`11R;X<YCUf-AfRjlF`Oj#k{_*X^vChJ2TZZi1UM|BB4}SDtg{K*+ex<08}iB%AG*|T^|llSuYOBnV8v*Rr{SBAgz0iImsJeBU^RXVpgv*F&;s~&i95)A*TSj?ui52FT%D)Wn$jPu0KSkW}WTosmyVj9GXv;94I{4AUXKi3g~DW?Fe|rzHMs|`y>FfrpVg-0Mzy`Ji3-6nKqk-v&O)m{U=4wSbS>>MLfO9JLU1IMgPdznohiRruhQJ)mev({{aV?F@5co|3TThiDf{k{e(~;064#&ooJr9A@zYG);v5t7&!4X`tXuT>wzD0+yllT<>)cAy-$L$<RR@jr_4{t@P2W4C_7E)HrJ-;#x;P4?MsYgU%CWqyV9xn+c`Gq(L6FS05*Bh4^DnKF=B`dB2Y2@k!phH^gx3}s_QoxE2LiwoqG)_)o$DJ&qB(}AYz2~iGZ8-e&fM?lIlb1V`a*YbB_GQNG>{cR<Ne7`%SPq=m?7CY#a!w#7vyy3}|bt3*#vM&7?SDIHRl^wOms$B|R+eyeAcJv@JUNmNCqomhr5*VH0AVMdZBpgTj>zJ6@dh7T=UvPKwkG{bFMNUm7OM*TRX-v6li+|Di!0`IPZjzo^#2V|UNnZR|(T(~|UyNv~ZTSJ^>!^eLb=F7Iortm7#BL~8Ym%^1$z%O-Q2)3ynZc^5*D#<l4q+}V8?>c==}$;$;Z$5Pv)93Bi1E*r_PyTdC0n=-kex-O@qm7~(5G{#)EunE4k5|JCv)Y?VKAO&u@e<(rSVI%|bKvr3&${n!UEJjdb7Vs}Kg`oML$X-C-yQ=gEOfGB~;c`dXux};rX37^EJq2XjJ{gIv1<EQkuuhMBv;Q!`(0U5o&_a5%3)oLdd(Q`ea&!v6g2q=9ohEOu8stJ-jI@|7$3-%vthS_4ei)9KFVHOCop~h-rc6JT_of&fmIG>7!g@|X5L1kE`wuRq6Dmj3w2@nZDQIphvx!M`QQ_ki?Yt{1dDF6cjFDAjtxY01s=Bq&r3)G4b(~v)3~GN^m3sK2phFT-R$67z*aFK(=4A;~0RBFK-41vDFc{!t5Z0t$%NUlp(fPpB+Hh}qconvqWvBF<#?@8{s-=r#gN5~2^)%P$o)%-;AkfjEQJo`p2^9!u?REj*{GP|Dyp#o3@+O#>APx4e|BAS#=(%T6nnN)*de#(dj=DvNfYzf3`I}#LdvFmmISAQS*OC@r58yZQnaRu+F_8JFfAC!sw4rEKBlj(&=d5ga&TA&E3hLk-2*C&$HdJC3i$I4D)3%qbMp0`uFZ^I5J;NaJ=V7BllG^B+`;jOxquis90ZCB=4kt9>^?lR8v$F$Vp(#ICjlY#+lR`UDsMeF<ks87QKJOaPyNO~m=omZpjrQFZ&JF9Cvya5plD=je>F`B<|MT%pGzr#LDUqClD#vba6{VDN%z`Xb00^3ef?KdN=q=sOA0y#M8rRm?r953PN603?sH*$Rypy=093&Q9QetR+8IMI}|8I)&b+?TFxtGb~uj3X;D18`oOx_c+ex1J|8ohqo;P4)0^4UTIq;j4p1puq<9H!(;X|@WY^ZX@Wh+C5JH{qMD1<SUNn$=N%*(|+LOEVE~RYSvKOND4oebwP|vPEh#gTX`e&Xls7Q}+n9V={2&uko~9iu|dOG2hI>VZD!)_YJxV;UN^RTxUK()EV!!Q#pbZ3OFVA9Nn2{IgMdpo~QATT~LIqr}jI6u<ma?%#JdAk!`*D(9Pk9<iB|!vp4HWh@9~+fq3*DVtl~JrJyPEwZktM<Hil;lBP9rq&LL~`gmxc7w$)HQ@Z~G9D+9Hr)94zJ@8okH{}7hkF4Fj1HZ0v-z7cFGV-09JiN&P=aO*uyDUc-;hCt3KE0^3GhC0A76odQ5mbc(m{EBVK<h`L`>H2m<2gEY?R|<q+Iy!{!9tgH-F%|s&mLZKDe=+^`RS0#E;^RsJte~l0_+bnHn&>ZX6oI{o}XbvnA`Z3t%u3qXBqW8$YqpEgF^p2J=E7=^C1n9XS@>qxe@x8#?mrdQM;6ekCg)g5#%FI<F3*F=Acvd_+g5}5)ZC&^i{d!Cr3G3&}(vLAi85f$R7x*CtRRTAOvNVPQBp%5@Kl_hT>bIdM{V>@IdB9{)t%mg!m^nm4<1IAlDgpZG$@{0B!R%82^J-UB5-)SlZNar5}5>&mxN-V6x7)vbir77wofZ#>-m_IeC{k_YdHD1tAMFO?0)g5gcRP0o?C}pWJ|rork?K(;q3Lp(#QRg0JJliPVofIsW~@Ia80<rWYA0knjbjPkFwBliQ&sc1DtGsYI*Vkhb(3xmIlIA%*Z3Vg-05KWug3KjvUi!OcYFQ``JVfy(L2B4V?5Xz$C`e7@$`7tC~0l@@PnQ86n79Q1T-<olx{bVM_q-yh4wd+p<PD}X6Fd*rsy*iy=EwnWW8gq+E&ia2^|oi$EP3sghT98fH)T{i;ByE>cUinP7=43lG5+ol7^$7kgshG7*ZoC{<9K7&<bW&^@CV93&=2s7!ThW>-_ZVBSf0>_CR=`MSp7IueK%3Yx?(AH8fAOg?M8sA3k)uYL_ELF$HT9ebezG=1gG&2~r6uoSCpa)Jxj7{opc^X2zff&$+%`zQAT>ItDNsRD4kE(TW>1h&rYDSN?$kxOm%KMfTU2R2fd$xwpfcNk>XJzT!60<U7iBsPhr#r{T2q`GRLMG-bggLchF`+w_Iux+PYi{=_MeIw%y@AELj(rC*1}dF&NE(f5){dRTDR^*{&0#A+6G2eZ(C?$CWHZ{DTTG6R{LQ;?s+aX#e1@eMZh*P0PiCx@-V9ZdfDzoXCxqQ#5+Y4XX6PlK54Mg`tZvn`a(wdZ!fgvJOJP`2+H7FzV_qzVBy_T6I`y162^LvF;@#T$0_iS}`275(t4xXxYMM<qoo5yPGLIYrf&W&X+CZlz&kKC35CsJ<vp*gG;N-erfQY*`TtW%?f>iKx3WT&O3*<$66+@a@r2aVn_)bZ%^8?$3ZiHGE;L&Q}0iBf49n?wk*ME~kpUF+rnX|TQxfv)+bA6>}{>$6bL!*hl*(D<YfZyavlx4qoQo>CJiVULV0vdmst_WLrw|>7Fw$^%sf+2~P%$@H5dLYDvLIuAu?aOZwkFpv%m32Tt5v*pe58FVu?!GSuLK?hLY2INKR2E~3tMh_5(Ck)D+Qx-I*?+fCg$WR@P2I-ToDG7Z8<H>;q57Qi``+zcdN{Es@6|fN`;Iy^Zd^W_*Nz}fLp2Z+t4fQ+823$y=PRLjNVLGL8Gi#w$`5I0Aqe`S=DrcuDdwSnD<3>H{=ZXkCYC(4<5O|M(KcIBTFiRVMn}pjJyi=tif6?T3j4W|b6_JQukPvTH)?4B+vKC9s-UcySn!_aY^{42<@I4ehz7{>Ow`MW;rjq7pF7RNqKmF*qxnegg~UN1fj$T3*-C{MHLS`f6K59D@aHW>tP2a#iixBInGvSkm!S4O)qlCqXye(NJI41xnVSS;>*EJKI`vlFFxbvFmHgi0LSp>ZY9u#PXKF%%(;$LD#X%4VWO}{2v(9Ko`Rw81;obo`F62T~PhQpRb^@<)AX_q*&Y3XU3o5Hh<z=?xrm3@CLq|fxPKAM76sQRx{4bfMoh^Z)pCC9C;Yqin7E$6ZurmcHq;~+jhy`X*vx?xWe*v#YNpwz{YjLjs(~i9#%;pE7CYqljScvfHintQ$!HM6uQ>IqkJ1`BkAXYhTF;TLyQw6tS%`_&EV~{|mYm3)vfVb%wVWn1<EAUl-&3sdRFo7(wlDUM|rObel&u?7vrk->fRciWqVDx6RAlq5~Q9XE2ay`V`ij4;RN(uRh8_UI>T{{O*H`R5x%~f1@$Ie+iU{@t{DWX*2z$!cd6^4wI$59*N=3QRTHbhp>$s2`Jxg4K4>6pI)Vrhnc<b&7-4zjES=DWeK7KNFoJC#?7EmEo6Dd`WwLORELb4`2(O!UijcPAAiv9k>)6k>L_pL>^~k(j=g7Msi*6vV`B(5{nvZ;u>xTd8AFe;)!%zEqmMGGnBOypMpbe!yk6{s-0K!7g0?6grK{|Drz9W5Oo$=HK~BpNqlwT8}*yB^&|<7Ack29Pksq&;O~-)j(m5q-Xea?VwE|x(Oey*-r8p%4`6*zE%%)xQ&H6YhN+f)apyU=cuCOx@=`bpC{b~*V0iojV_-7r(2&|T|G9dMXF0D%w6sX%<{}0yi!CGCj)DQQO#~^sYA>7I0tSiR{IJ=PP^q6CJT`K*<&<SnQ$4-90&DUSII8V>9{%EAtfpQ5nB2N{Zu#cl{bhA(DvkU#72vHf;)x>nBe}KM*utUV@f$9FC!TI$!*f8Dr6OiON5LxJQ7KWED4OXM>`@oo9?-e-L~R!aK^-jYUXl*ON;rIllDf}Za$zJltJXxitTo<qy_xv8_rIa+9_vKqF3LC-69RH0#7}RxCoq(Bl**BwM@qTv*tNuo7C)ikhH9J_mokrdS^U3vN~=Mx~}v#v>4uZ4YqKV>k%3Go3Q+oy}*V}fPP?LJk~Q65jr8oCQ|@)$*);p8IG+GL4%t^Vl`vWVYI{tg8YR<QS_lUq_7QOgj`}k{ay+H2>SX#Yt9CVF3%OF4(}}DmdnQ+y(T|#cMGn%fR;=`R&0J0;TP0jJZ3eO+z2IhebmxOm|sz=I8rEB0f~|<#P=M^!eQW>(#{^7_ewr^_}sYV#f+`I3pnU5i22p|-*xGTAvj_)Dl;ti9XnP0caQ@8fkU_!shi94Q{OE9ZL8ZJ48mrMdxC{>mE0noaBvjzjN)DJkJHbd`4Xi5ZCH)*u~?cOmVqbH6h!;HDT+e(l5x!<1^*z~gPW)Tx>-`tTdcx*7yUwnDFUUFXtz1%zA~Hc3(_ejivAv6pPW-VBG(XW4b5N(i*6AIi-!*fQE^?t!T<TL_yRYFIpyNqf}K6(w#+dE#&``SAc$D%2xx2PdjZ`+<bKJYcG5kb1gj=d^U9|T@1X&1cZyxTHHpceHXOu!6AlKM$gQpqIgl{w2Hx=yNQbH?g(M~Tws^5Tw)342qiXnv@wQn~Sy`KaK7_&Jhm%{&lqn&K8NEV&nF178m_YuRh@<zv8UxI4oyhrJ7h$2VUP<x?T36bbN?%PWz{G5rD+V()n~?{vc|3lDl^rP^#%4w15ZeOQ9WjAXm2XLHgoM$uF~UW&hY%d)Ab_5{rq$*DbS6@Z@(&5}Rf?iR7hrqzmq*EVp9=8@3vPM+`4?FRvpEnsD$J91H?yTc$_(#B-|4+=?=L9DB+lYl87y3xlwlrJC7KOI<sS2^-78r@$ppSA$|u^@>PreYpdWiI_@|^n{T2d8oQXi#lk=r;=qOd>RyRg?ANUq_;wO04ODKQ=5yt;>RP{J2gpr+pH0z7ipu#PWptY`{#P5*#moOSlbXV9G4t>~nJfQ`~F~K3^Q-y2yV>Nq)+m@E!kBB;*RCb0PTv&^BG@$Q73GGZ?j-zBzlpuP5O(a5onUZEWav+1(`|%|q?Q6Dyt8tHraof#U%|sWTdw&LwHSaARYixQ;?Q^!@nz=b6J6n%te%8i7ml9JJnvc^2vBn^P(9vkfps%QS4b~&M45X&+Tf-2WGK~kl4l2L|ijnq_Ai>h0r=eTFw^2+eE<1nsKmA*m_B^(*Djs!aLJI$r?9XR;j6q^M_|+AtE^vdXKkGt^$1ue7*qL%oNE!p>^ax0s6totQrLZ4dC650uL|uE0KSev1L*_o6w03QnzEhH=fNY7$C1_k*uo`1|;EJVjUgQb8`S|x*KTU#D!S=57Y%YDC*$r_#y|3(wZ6Bmsq_f1P>R`LZ3gMB5<c|V_+|YLZ*{n!^d9w<GNYE-Lb5641x4sR5hdRoG@<w20jb2G}%6{HEZssCo!f!5Xm(+M5kO0SD?AHI!D6#+ZK>n-oj|vhCe5m38b#>7Oe<HQ#Ii7OS0O&?6OWd1W!~s_`Op}ctM|Th@0A~=Yyf_zKx|1eP78Fn`Y$(+U?gdFz=#R_L13ULH^MjcQr<%|vqvZ}A0TB_CaBXS;00000+#uIDUG*Vj00GsL0p0%tPiep)vBYQl0ssI200dcD")
    TL_SHA = "43a0848def257e70565285b6e172566a0480dc523c76eab100ed536a5a575f5e"
    TL_SRC = _unx("{Wp48S^xk9=GL@E0stWa8~^|S5YJf5;L}7rW?cXgXb*@(Krx}@rwH#q5Z`i_CznSd^pXjSWOYFQmMUNN`jlIeV2877X=c8K;UqF8@YR(mmmH!Xg3EJKlBDZ#shV5nX^7d{pA4*qx|RM}h4mj5C=335>JCqM9W8sP7P<BO=MHW5`v7(2C-y-ZQXFcRJI={NrbV{hhg@C%c^MOV(XQm-)VK*q78cC2WD9zLrjlXI+hhr@q>w_9mj^UexyLaJ=$jfCb7!+zA~)W+y*yE}@cO9Qvkv6i&KyvFS}@jHzvO4eFP#)H3oFCO#_emaxdK0NM6{JrIyT3r<vz`ets9E1=&NeLQ=n$tX9-O=)^YzD>_iJV#dKcaCwtR0b5W01IY?>jeN#bAbX_8)!TJeyj+^B^l>5PE*|~fM&DCVsnDPeCZQc9K&=3p}3^3eltd$SIR=a20mM;`seceC71W=pC17CW<FLRIpS?H7um84cvklb(T;e>CeU$K=oAc~D{3P5a1&kQXbvnNiKxmt`YwMqgiB!PJ^FnHtl7cehvKv6bM&$S;bJ5(k!nL4D*MtPe`7DTi57ZNed^02{G{W1#mHFp(H6-zRrEB?11tF_QURqFM1@DywpiwR@S(FgfW$08E439N#A@<9FH4h#KigY?GwJazzGkLrFnCh)W+A3g{^O9i|w-IzwZC^B{N>k*nX!}C8*+d`cwFDq2s3YZDo-S7U`MxL82GDj{)+-I#HE~NYY9K#4B%B<bP)}~(1iJB|ZL-{1wnVyz;`|v<aZp_!8nnm2M+}k*BdCAt4imUT3X57ylwxQKpX%jZ{-$UA}@6`^^1Ngg~le#wO9tzCx7%j%&)X1({+<=RNp+3B=qoq$YtX4`NrKmYNgJG)MJx4aEy~AE3X;caK;`%-FZi_GyP%@F-81cn{xC?{uNWyg3_97)7-GZpIT}zG`2Y3Q~?K|_P;<|KiIdzz%)j^29!28>n$Q3--dj4J?0z5r~{D+E_Ft5`lG|81Q?d!Ci3xoH8`_*i5(>5@JGxjrYYW#O4Z>_F_xezSv2giD^8G)h(AS77SWKeVd+EVvGPB8t~P9)!?u?diT@|}_*&Cex!CxkZtn2ORTwaHTkKcVQmV^Qm`ps$+Zj?A7(XL+>RPW=PIJg0lJOU7qydH&KByV0jGXP36sZ-9>q)9d_Ir$oC!WrDs>+#+N9C<kKvtulk)M?_^|LpT{pUeNMR>_w6Zi6gq_ypKV5!I5B9Yt&G(X8^9DuQ7KIq-0#!etlN@e^GaGD~h*FDioJ3YLi+}5xVYk11^I)V|9f@RiNJ~G_}DV4$G{-`ogyw`MRo;a%z=kU`tqmq7POM)lu0Luun=Dt&<ZAoe)H;oj`EopZCYPm7fJisuZEcRAr=YoG6fx4Gd_13UBy0P^$*xeRzv|e%ao68!aj$YehwIW^KN)-DKB>R6I*TDCV#BpgB=*KDy;CcF*xSE5cceiXiG1ard-HC2)W<He2Xcx{lt66u-76$EH4;22yF}3#G^f)5z&abkiWW^H)0&5z`#&sGRYc!D;_J7>q*PlGfInXbCfHP6L=y;y3^~)9A6RK<RZAJlSk^s~I>f^qhLCY~u>nM~i#l`EuH_tv$<2QYI!5_F&cT({yuBiXV%q!Dp;s6Hcd$pqn=u24n{!^|G_teX{{?{K5f=D!!?}E5IW3h1|9kT$Uu0LH>-#M<rqZ{N?NywdergESZQ+b=?f3<?8#=K_lhPM}|t>HtmN5)yBy)A}IJRqT|wE`0o91aP^EN=+3^$bUn(j=HaQSP%FQ36t4$1?cT;pq^Szc3~fE>?tE3&8#Kgq1wmBeJ3>jp9?)>mF>*-VD`+E_Iy32mv}eKYDM&F86ct^tH{f+_j66dBWY|GF`H9l<quK^of75Duau-_eRHyJkMQ`v0w*J-q_H?;E9}FnqCkwkfuS-resoy^g6=<}bmV3(HcyL{7*Bk#(_TWBjLX`&O^=uNUhebuPnAU7Ir~a05pLvy-UsElZ5$$)G#hD~B$jk2B%e<JZhAw6uWNc-5sb*u#OpUCVuk7igGg!BF-y=R&oU6icunf80pl)s@JIsOxWzChP<DGspq$}vC|CzPY7ZGul`#_)5=E2IF5Hk9n-rTY5b|vQ;)b3mYzGisrf~Ybyau<mu>rl56d{?#=dwOOI`@3z3+-A2&uy3?zV}<pGIS*>!)Gf(fMMt&f^0?fm0#%kNyLS;;=RFc~-_IO=<cVV#HhWM=<~mve^cSND*i0)jLv*yl0&zA8jW*g;Xa3>P$vx7MgS^k)f&XH`Iz0io^`$c;_6B&-hLR!4ID77WuGasVLCb$3!m_k99@alm6AM&ryeaS9Hk?G2F4aFF7S80~II0G#JUm>4>=FeCr`k<FOd>-(zxIt_oThGSb(0B-V}sEX5GcOx85AL2jw`GwOSwXZoTF~Ivsr@M7rf;*kK+38AZ_d1$8GlhNFcZ$EzZgR8LonXd#{@qA^-;N-Fz3xnDWgyys0*f9dya=lraIH8O)wAaRK)_t7gO%g^!fAA2QQcJs~zSW1^$i1jn`~(*1lIhJl(3V+XJ>Yk(K!i@^2ErP^ie8sE!jrQ4)jvAxBS=@YidazoZ+1L@2|aULsMS)kSC*zKw$RY`1QnU!@CVfm%ZWIjo|Q7thy0xOvK*C%g=p1h5FTfM+qcGR(Ih8BL`L&<xgbig}<B6VY@^~53JOCGuHa;o>%^vfTN0sJ>aP%!1Fofm}@{U4UOFB)aL+>~jxNthZ`QFlc5@d*K16bDf%mW2aqs*eHtu~(%7?z~ybgX&2{<<=B8Eb#HwHV=jcyYs<`ddQmmR44_UPKKQ+5^z*=lUor>8Xkbr<a{pAOr!ytR}zo^rHb+BFp)O}4V?Nkq(!4PLagm>54DkiVkaUf9QlHeBuTeg6Dlv%3crQfcXHkrU(;;;ajNq%yYYAoK!As$RikAyKTllgaa32Oz9WaTV*@`F5B3q!$>B?e9!?4=aT5)s00S=@#hBs*$2(mU%HH8hf4DwkF%G8NK`>fa;dm}SIZLJk`>w{{Gppn;k+sKzdi)JXm6SpgW`HNR+sgO{TD^GXY_Y|XA?aKfs#!aTD3dG$g6pT^u>yB`d~2~_rpv+(*Mn0FjbZ;|7)TCh>_zB%)6SHyWLGo9La!VXLB!i=6Dd%X+_ZP&ROUyc&0NW88?&=OGB{0b90xW%SQx8yWkyGRU;md(*OHg$M!PpW)CuZ0*5~=##l2E~M2`?k&9KA<8q6Io)h1%i!7}^xl$E#C3Ldr%CC~^BZvil*S0(^C2n($2l?bexh{dK@|Mc-z8(@JiR+5}zlk2`&9fS|cj#uOF&t>gGYyr^6f+-ud;YL@@1_;UXe?0HxdN9(y^cEWkZP&tdB#?rsb2mtvmR0@FyP%<#-8Hu!V1fsmaxMt(P7Hd(pW$;m$*|!aX~MGI9_uGklDGdI%cM}lp#^<N1fsc~!Gmz;<x-UA0x&u!_j|XjGoj0S$t3ep!0bU%v)OdVLwT#Z0W3aUY~+79-sXk!Q8+<h90FFoa^+-YQL!qWZ6ms4d9UG%eV|xsIP`vPrX9_m>?~bVQ6S&IWjmxs{~CWwEU0d%pV7%-^qm(|^Q2_JW3No6(W<%jgKX{l_HyPvE_i*%aq<_|qE{3wgwCq#z%(Tm`uiD0jrhVo^kcy_an+@aYl{}VpkWSs_Y1tEq0dG0Yztb&Fz=W7E<(^iKtxWLNKU_EEMJ%B|5#0R?Tc0ZC4*VM-L}*#eX#7(JoQ%TcqbG9&7zSVw9fdiEWf2*Y<{qyWed_3o=E~`V;anL_Mo*lqdGqY#FM^=+N+UV0BANo9`cYKgK!>TT1!91cXKvFAF-?`H4rJUjoor@Mt<;BpXbp|1x+bnI`FJLy-zV|t=J>$G!0p!xm*bTk6OO%gqe02-*2>}zcpxid0UJT;h+q5jV20Su4d;MvHU~!L7d_Cw~S^aQ4X{E-p@ey9yw4R`WEScDg!-oFn%9$=vWtySD%T$ESf`UewAYr6#|a37+lz>LE5v}R#aBcUGoR-w4ZsU)&q34_dxOtY5r|X<&PeJ|AZlT5h=DFXdPz8!*=4VrROM4;{P><WiFb(w|jUI{SPoEyDD(~QQB7~-c%dwdly4p1b6{R|G&P_dHwtz$r3e#U#sQ&wMFY)?_UE|f=)c=DhX{#E;V1fKX44^f%3Nq$+8swnj#^pJq|rTNg;Zg=3s=t4WUI`8cAY3evX>j+QB_-D)iGC3MKkZm=SQ4+U&*m+Wp?h;Y%eCSJo0D*4PRQoweU3kl~uN_kaChn|3bbok!ns7f6Qj;Hw@T0AWwvvlAelBo%@;9QvW`Vqb@lUI&iOA3=sDY~WqTaJ=#`=0T;v)AFge<XkuqYTn7=dbZ%#FxqZ+vlNH(t`~8PCwh391TTqcMMU<WtrcV#uX5bE$3~-xE53?NgHuD$_`lKwP+mD&SDd>Lb4#mVp1im`TSy-0FIqWGwyG6%%vPAUNG8k-%?$HqMWsoFTh~P{LBC{kV~A=j;{g>B+=k&D{r(N6nWbAnrPX22UJ5lfe9g%3AlxHcvr{zVgsgXn?}!6;e_|XON9^-dOB-g0`9RG3O>)E4U^kCtpGLtwAQceXLQ8M)Ayle5^o%0K&MA(I=aD{l;GAz!kJ9zP$8JP@hoeY={fzd@Nc<_7(a4)(Bg~3PH)7s;3+RoTDv%%7{v6;Us*r3vYv6AgS~3Ep{05*0CINZdzyJQ>{k{$kDmIP`KyB_58Zu8;_`m>HXr-Y-ECcy|NYzdK2Iwh)yq02?Vz)I7A#zTacV53>_#ywP`^rq$gx{%iCZ`3!p^6w&{fSI7p<gBQ#E9u<TsU4uW*EKFm_bKyO#^xQM!1b3Mv)vLSfLknEf}hFUSA~;6t{Sk7%65J!3~;VV<xkXC48!xi~8xG7-7JMy+8AU90M>^!uEX@*S>BM7U`8e!>u}q-IPbVYolJ<ghc*SsLk!G5P?cWID#AYQ3GTS)%Pg)NS`Lal1(av6A)oO<c?Pw6F=;3jw(X^8$8(=s)BAE+h|l>3CR0$=+VMcwxGPJZ#K;?3)49^imfA}WU8eVD5jfMXf7mMjoX-#Q1bcHCX=Or*d?lfGVVHr=)3X^kOp2kHUT_67u{*v!OK=P+!SfP#|Cr)ZZ!t_gs%7RhFCrgNutcpm^2*Z8i5uL+#^YVse*o1gD*Iz5S^<5vlp2`ok2Y9%VUJ5!}7lpx3K<=p}Er{z)$r0D|Igxc`)SwPhC&?%1#~dhIqOQy>Gh2{swKPu#)9eAoh0u&+W0@c8OL5I7~4~sEC(*FQSgL!?4x0$l+(dn7@7aZ;dwu@>(jFq2(d%*#U27m3v`ZiW-P&;Z3ox_Si~&n`&P<3ZyoBSF6^8-$33iW`vqL6Nj0Ab-!%Dm#p>5NI#btDwc}7D9Rs??qXswCm{R+2ese_SJX&-A3wK1yAR^@y)0HK_5g_NP7xM9+u#RVqYl`sRDRKTPNrI!Lt~Ei{hpF`_RqLlW?SA0;&RhX!VbpWyIomY@k4j->2((9`CuZj90Y(EFe=H${$>pNvp9Nj)bhh6vcybxUn{^C{c$|SSAl`L!^>v8PM@k_J&y&)%(=${8!_7I&j^yg@UsR$zZ_~`qvj^~cWPDWcL+xKYxQC)bpftt`Dxc+QR9i1P&?K-LBE!?n;3-Gv?Y&v02hh2hG`OrXx6r^xW<je+6cbBwN4XF63^2??AA<s0ksq96vOKx6i!5re1r@`j8W@~T0%%=h!}Jhk|-rc6YAf~U{2JLb@sT=a)`M%LaJsya5)cAcowoyTX_1%tXp$I%r?ujTzS=K`Tdi>UQ-v_@JV1Uihp8;>BU~`9#=-2DMprQnk{PvBb|!7F#(Pc5$53L?Sz1*5}pr~QM3YV%%?RlPh=Rk;JGV6ay&j8SzisYdAE1`lC1`Q4)PdsusE%Is%?pyr!UH;3u*&%UpE)`)c5Ek^mZ)7y1UfA-tg9R8)G*1kD5twX~I}rr)g->XZN&<(%Xh6zndGuux;Wj{XACgci?s@Zu}71kJvSdba_fvd-<Bk4t;=CbO9Ao1rdNo=llFWLk^_i(fPW2so}G|e{*{z<SOkehuoV|q_j=nG2mj3CWF_qjq=Ufxbg;F&lc7<uYWChf-Jf?ypF*pMzA@o9_`1X#N^gMgTEJwZyv3UwWX};y-{V8$*_s$91eSZqbLj}a2RQ3G3tJj2IlY22yk1fg?9Pzz`mB~gydIy%qjEiLLR}cy`7jLXyDWi7`YnJlwewul*SE&z9K9;A0tboE&2=2;MJkR3z|s<@p$-V_Kg9y8)~%4oTl0teOkV<>!NzF8A7;GYoXl!O=lbbJ{OP?Ujj#$?xFxL?%m$q21Uq<d9Wz6g%iCNLKRy61-ZTFIfyD}TCU*0n^F^u@l?*xr-E7KIbMILcs0e7E2t%P^>nC@Jatm;BjYm->x_}gzRa_tgo!))t5cF-rRL_(jpDv6MQ9Y*QAA*_6%)KA9=IC88Ru*y9JZr@ep=FDI6${t^}KFCL#j;{e04QxaYtWGt{I-X2-7PUPRwAHfGvfaiz*JlF)qW#6u>2}cDkk5wv2^FdltGVuY1y$lPd`<F1W#b!Uq*zmxC!JMU5b_n!L{aY-z!t$-_B+y?H*U@%~P2*N(kI%b<mtKeW<l9WH02ye3*}^_p5R=2@?8+5Q4*b|lM($i%4k6H~))-7e?B31=d*n}ON1O;U}XxV%~qy!-~N9+AY+Zc+(Ee%&dg;nf^}#^c3Zl>v!QULE1k7&-{}{wdiK!vt8f6eFdNui!?KB}UZ$c~z-k1af3;2VGre2U3`uKjJKf-n>Xp<*vJen(jN{hlb*0Nw%CQ#04`f;drXD!fnt-Z|A9E`9psAy;vo8IxNt0MjYdFmZ!y9LFUfDow;^9iIuSk-Qbo5q{^PVg2wy~b3_z5ieCm>u8EaA!$nY2bW|qoHMHX~CrbBYNS8AW>YBr0C^#`!#U%PF^*0?7FGt|8d;2rt#Wk^Uwm_cWa+*@SkYFRgA)$Ui8hyKlH?JXyAz^>99S?k3Nw)`>ZSz*YqBQ3sE-kW;GP3v*_pq8>fM3Zr8!`Y?C_dt$7y3Y}B3X1Q({u8^DECiux{~5eC#VZ_b4E22fMb=X4j(mfg>{2#z~1^nC!nQxXGZKx+;Hh9c6+NCiQkJ=;>H+_u9#CQDv(D>xls*Y^3UY#RS(9PVVv@sxlf$PMmCibrRXD+10u0=s9~_oc65qGCe=vLr^yJhYUZoK0nWhQS6;YSW5jkj1a%V4(>_6xKYQy&C(qv5h3xO30fi_1BXcx~W(cpo7P`8c0ZUSB^<LYsnX!**KQ~8(310p_3fHxMKkz7!WLY1zCDsrm!3Ypgd7v>F?+s{c+Am3!ES|izl0AH<QK3g>_6YAcj?Wr)d(=CIxxEM*O*dX}z;gK>_9VVyqv&KB<kD^#^KK(D67_YdBjWW(7@WM(pJt#$1og0GZ}Fri0xy5TIc3br(vl%-^k_%n*gj`85*ChW!zq&!eXe_R_=fpp(Pk?ymAfoYT#FP;6#3tYRNSy0F=4UB$TV6zEce&E`gm8glDKQ^=a=-p@U-XHDh}&}I;+x?&KX;VCJ>9rLTC5Jl&b)vuc<=Ues_nL6Q8V9oN4MNW}_tpG4-PBXW7X+MDJwj6(@;Dhl+e~bKtCr<HAY%U3D0wrYOR^!dV#ICZ<k1C;j~QKTUh->C!4fVZTY=;*8v3wcE%5R5`@$94oEy{tTQ3AWAnA>B%AYnXdg{n{xSC(9!UTjOQ%tP9aTFHT=^cEDB9^c=BF3PzEO52!EP}!qLotw$RzvBbM>-$HiwLFvV=g&e!m@!pNbA6}^AWX)=ZL^nhfJ-i+`3O0Rs299Wmg(9hHO$m4E{rJ7RG?&Ns;PMXg|(X%?E9;f4?up&w1lWuN#!B;yxRV&A`?B`a1PadhigHb=IW>8%_azJvGR{_6>G0;78r>XTY4O+Bfib^RD17f9QJvy94mW;s&U3^XX>j#iW`u|;#JDDH@aGO#Y`A}LUb*h&P{O2<}KASSsS(m>k6*`2rLz~yx+kBqto)qL+PHOXhGpUC<gO!KxPLJQ9u4Yq6WIMv9@!sxMgHr@1;^7KKX~Ib|uL|*Kis5|VHelN=0|}iAUx4oEB5W-VQ{1ioq16L_)lN>Owo&Ndgg%2n^(h6wE%FccZ<-Qg@gRSpMAm1^`6PxIKLVMw+}=Hk_EWNMXbD>Owc(&N=`h@DX`mYetKRn2qTg<^r!ECnd4m&_J@1&sR6@{zL2&=0d{V8rF7jub57QbwFw)dmb0143GEWyo?2!lz0%Wl%`eYnmQbZqzRxF3KZu!}tOU;RIkGa2w?>ctkx|_4dp{?;%7$e~Sz!D5g3)@N{)AB5Ge6ic65M?ZsL({EVJ}{1HmJ{^%Iz4q^y^&xR|D&U+K;av}z+o|qn_##ZZci-~_Riv`U{`Bzh7Z}XD&_L4I+OSnUjDkp;PXE7fe2j;HxcFQx8tv6X6@D;JDIeETTL5y8El}XO(_P2$1!7aA}EdmY}akr1E0M&o>S5cL@=ehq5AD{ab=DpQJi8p2kx?JgJh4k1Jtq+rSVDxVg)BMth^!}H=}Sa_2A@~BxW{_yXTCz?a1KA^q^kSU{yth!HY;qg2s;odgE+n?UakN-0(dFoIYstSg#%-&wCI%D!MJPi;0T3-r)J4$AFYv*s*(o=Zis%7DD}PqnA6z`VY30c;E&{@Prt1*}T2%ug981rO^&L2izVU`MpUlj;^*4;JmL-&HeU4JUz^y<+ThYX}Mt=5Vqv5WSmE}oW9|zen+Ou4LMpW1%d6xK)$#Ks;DzZ!$$(bkYnaD6?c}hKclN=u5NruD*C;SW9BvgGtf%4EyWxFl?N}w9M3EQK$ws%7N^9^N|owgxTU`}S=UbrL-k`<GwSSi%=s3GE=mflM(c0U9Ae+w`{M_+uPW7uW7H3LAwwXVquuTI@3rjfeTxaq0F=TJ`Xycns+|B0c%IWUU;H4TIX?eIY8m1#UV`3I5E{uQ*dSYWUlDON1QNX)ZEOx4LGjmQUK3tm=HhCau2(~XhxTzsU`A=F*z!wiS*k1s9J@1k?{W`a3P3@bfk#q?u00Y7jP~3cIKO_fknp^gqyv^@m6_l)P<?EA48tMMXv;%heVm|`Mv^kQmhpErsZcGJT|$omt7f50B4~lq9nq^R91e#51k18u76EM9QY<4~Jg5^N^QMZ?u>h`r=cK;)<jL&7?8}r_YI87ikux<&(&#A>@ms{CJBw&I^2b7;qA^>L#hDu*xeUzZTnxH8O=V2A^7L(|JBjk3PFo4N3UIo7W@oCGi70N|W#m}OV+9!{WrdaGHhw*Io9!>rVPJykLN>tXAr~~??mYGP*RFnzTI~dMwAb^f9yN$;Tft~Zffu=&*>9@dfcpV{1gpicT-xS;j#Y|oc6BFvHk|vf!ECO7$$^2rYuP!WIuVccTpfHGGBkttYy)}nIrH4qjer82hiB3Q?J=<-SYU-JA0@Itp~qX%2)c4N5;lH{#$bkAE7sqaqDM*PEW(qzAfUF|k!oPq8H2Ey(3{F1l`L=t7Tky4kLUeD)o@dJsFxX|N!iQ!--Jw5NbtA&ijzgx=V`We26<{{+GZ|m;O}O7YhN>ijw#9xlX|se>qf*_7XH=+Xdk>o&013U{34rjb*dj;nA@BHMvpoo?;dB_Anou%+h=svwvH=r6rT`dWE&>S*^d%>p2KgO@D&u~-9D8g-)N&)d<%V@(cJ_HO>1(7c!sr+Mw@k>WueDQQ3!gp#9_4P&BvOG!P|@@LG|<iw``4XZde_O=Yig2G5wqtM2K5$tZTE>U!;wzFQ=0@a0&}@(L7?8IUbyag*Z7sewNlzS!YbuMb|g|%!NR*s8k=|_IlS<awY#GS(ruiS!WXkXuQj?C_srenaqp&O)ALKi7iH4#}Rg=1!r-j17m|vj_f@MDcb;TFL}vtEsahB9xd32*`6Mex0RM4&7!QCUg)&o&-w4X&6zYI!v)dxZ#12+GC=7ulb_yNrcnRwS^sJcszr42E$sg0zyRs4?3n>XUhQP*u_76)K>5d#YWs~f>3`SuMe^$@CJ6s~Nfl#N$rQb|xv#*?v+|><cgMr)3@R7q$xoJAYohBV&u~_07I533dcw=%gqs1}Vo<)sIASBk^t>&}S@)Gvr43-6rnFfE7jm-VS*KT2&-V1}tM9nmVF<6T$rVxbNYI9Gx2}NvUa`7Ul>{kY%2$Zwjn+G6nC8G75;GK=$8+zPc_vw&XD;{S=8y)}g~&SY0}qfRO_XB_Qee(Gt`s-YdP&0Na9)y}A`!ut&TsvqJHEY<*TH{2SR<r#+WJRXJ8BMK3q3eA{F{KegI!ZO5~i)OAd;CAbDSOG-;!kP7prMJU8hsIljhpswuc@{*4YlYy>IK~t6#v}b#RHl34a@}phLjYDP6OF`i)t2#>mgrMZRP!Wn<DF0HNCb9N*Np&7|}Y{1RLm;^k6jd@`N_VoYgb&j8I}=VU=n9bTuaa0j1MYy7I4Z3-uZ>S`hl;1pmBFXevz2X|ghyc|q$mD#~(f)FO=K9J3zBI5fo>m({<6QtzJC^F-7+~jOpM~YFvCd`juG3W3G{IxR=QDuI}AI8##H)avZ7_>jI&l$|?0iD&Z>;o(t^=0H56_7+a8v7#mbFp1HKkc<)FTY4ZdvSnRbc*G?pHDbuU!w3i5(Zx0H8ij6Gd!hC{D<0cMumxvIiNUtv2L(Fs3mZXY@_P($|MVAwo5nEKRbVgD055Er2O2`KdP-6SU>o@{V0+Y)kSK_)XYbh1waGVigmTVlR-HkPI3oXg=e4C6}8FeZ}D~dh2Og0Y-<ZP&%qej$|qW(=ftJXcl721sG|ZKsyNg(7`4#h{`f85PXN95@lZ;078CH8>RC)*GjpkI?u?X0m5;XdU-7bHb75w%ort|Yyq}bAKxbtj$YnQEdkSvMbNx_tvk0Z`mo0a(o_)t)B^pyB&pkeg!i7Ee>7D4OkR|i{A(>{`5aq-IenHoEv&gBy$$K&5MbPQh7S7#*+vB48Y?frrfm2Qe4rpbrCO0=Hu}7#NU^zB|O{Umb?8<_PkO)gLb*Clj8YdnRY>Oh}gK8z3*&m<>;3((3OirRCKoP>eoC%W#WvdyX_hO5NInelPncFTDP+Q}7IF-Ww;tZ@LcU|xz+*%!ilp)<1z-3+CVrPSF!G-#6OkhQ}#F<8;pSjbl;iMr(&p9Xt`zIl2=rykGUF5ne(o`XkzQ4!mjz!_OwGYZ0STIJ=_`<r?x7_2d0-?#r5rYN;)K=HT;t=?nf+Mj4Z@RK>+vdDA3F=C{YZ#PfMxasLmo70imSyf&VTBqSKf#RY`gED~*$g2zGX<|d-Ayc66$gqDF9S-$p|R7&7cVmO$JeJgF3iP_3LcF4)5rsK`cqA)n}p?Q6!u3-Y-_WFGuF)kuO!eX+1}Gp?=0RT`BmHm=Xo>99rp18XnoGh%))gyshX^bj--u1!EiH=;@<*l>xv(@QCXEtU$j1I<JmZq&JxXV7nWF;$Mg|W6R$%>?aq1JQ+r1W%YrB`Yb7&R6zM4iVH3)n<|o}oTEGt{oL1s#J|K{A6~Rc^eP%m2s+%{Lnv8tV0?NBvz0Ia9uWiT!_de0$#AP;Yw(nx?BicAfwdFCK;d*Y?&MJgRt`F*ypq%&9aoDAmpD#Br685-(hw@dZWJAf+-ZrQ2`=@0q@d%AI%xkgk#?;2=ggqP7bZNo{LXvk>t}DS2{ew!CU%5SO8Z;h#NzGstLv+kHLW&_u{43TnJeoUd*HmFe8Xs1$)3mxhCw^PA;21!#_!+YoIm%iSjZMbNC%p2w=y2!Pzo;UP7FgB{TP`P58{5kNhR$@A|0V9S_LJxQA&I_dN-|2iuH|^iKMpbKwFvGJP2;`bpr0^*7x#6U&1r}EE>6rrUuM3K@>+ID9{LTkhfOJXOm*su;G-T3$U<d|xw<eZwpc_VCN759+<MK+I`3*7bp7`WNBCti(q1-^i1av&G+jJOe)IY*+<+Ro!Tm7i3NrZqil~=n#<8x-Xa}@Hxpza+ASL*~AYB|#Co99>hCsos0j&^WPdnQ9xY;3*epMEk%mp%|apy%dA6B1^2~bJ#x{d7+Mrd<&sAv`_dW6s2s*4SIKZxmtu)fF#xcBro<z9E4@J>>hNK$hL5~pqbZraiGSq%y**{%;@6&w6pzz!gk&4+2rPMY3{g@yP0vWe`iz_-A<VK+2pl#zG20ph<99OLBR%K6xt=|E=4bdy`Ov}=I@N6`Y4Fcq@#vfp|ymh$QtL#uZL<WfgqbcHih@$RHpA{MztyJgCZ$O9XCUN~zakjstl_oL_TVvwINn3{;o)kU@AKKt=6j^rk%bWkyN#R=N4S93s5QAIZFv1DlhNd7X#NO|+myDgj-pDb!RBTF<HBH?_-UOgn3R?%fFlnD%C%I`;##&E&f&x=%Z;ul3g^CLgGK2>`F?E|R`!=iJRJA*oJP*1oXSr<4v^+sX;ZTZ71r=3rLL=e67b`>hYv&w|b>F>*6NCfZ=*V2uZsJ^hr<hn9qR7V^%TV=gGeE0=o6<5KH)c8iufK7%X7HBK*fPFC&tAuTj>KuMv23YaSp(=l5+3_|z>v$k)Ir{r{NFjBW{p5|w`1Q1gEh{5oyt3WIPS={Jcc<E@^qX5%EasDu>o$I-w8PUxz(#^K3XV2lC7;GryGQu`WRt_zv;8#}?*iFmil3~U8o18>6Y@S5Xv;9T^%jP}wi$}iBf<~I9lf0Dp&HRGMi?|3Usu!ngsIaSPQ`>KR`H<{*qo(1&;{Scr^3=;5%;~5o~S#lyy+FbsS!mlykpPctZS|--LhU$0Q=+-KJSE{84yoa!y`+>FKy%PTDCn!kyb${?iF#1Z31Mmay>0=cLaeCZ`8{*IxB-$VmLNi`Ezf2_Gn)&7>c=GU;Q5_?g2P!*OO{B;-VY#K5G%QJKo^OJX+T&GJ&;sK;S=;RtkkX{({|*4Vc||X_sQbPo{oAH}2}hw=F5ikLz3D54sjt8$q<;^acWaaR5H?)66-9!1vhw5Zdtl%O|be@*#?W2jQbV*{084l~1MBq%yxL&T^~gi-><PWcKU+W-Mj!w%6GcjN#0ZeYcTpTIn%uQvcwY^g=O!djj%w-x`Hwz2rLRCo@-%UOrfFJ2Nl|wjRjc6zB!BCfUkn?6@q4LPfy0rH~5ej&=veT1=Vy1Rz|Ig*xPox2N7Z*{?0jQ>6KJ*i}W1y&bcnNE$`~fp47z$~a@0gdRVFu1&@vohLgf`jpCr$au9tno1`Vkj)f|0{M@$MKzbnAwtFs#MBvf2=XJQRQMjC{LM;*86F2Z{x3yRC>p-9SE>Z8$%IIGuT=Db?<DOxYdNK#iPC@eF;`y2A)25tQ<dr&3;@E@x0hn={dlBuYFI`i1d7Np=--$|OB;5=OIyG#f$!^FXWCgfO08><OV<Ncv%OBr3D~9?K1lsuX<#`0;%G}QX6G_iRK?pQ^V91CXw1)i+bw|Xekbk0rkRk0+~H->w<~Ng$o1tsU7+|L(kZ{4i=;faOqyZg?WLOtpAc+^jfL()KhFQ0l7uI0hzhVwcr||!>E|8BUozWTjBF|4^jNP0U#Wc}rAk~%_<X^4`oo=BdyOiae)HAp*&R@tFor;|??3|uoU4ksUA1p5FCRplG!AUXG5@7&z@b)j<t>b~dz;bMk4A*$HCF%!ZH{}t%wE-aR@dOx3IOwygGnu`_@d}0%g~S;jRb$eZ`cLDFL`!C5T6%-wMkItS#B{rRz;*-DD!f6g;}N}LjHUG0)lMC-#_sRQmu$1zL($F`i1|TbeJ{?G!b`}E8Fkbw*n^bZ_oD1uiOy<$tBoit-1-RP;=^Z`Q#M(kkIM1@ocMbAA6`x6Vvo<*9fv99IWJTdp7)auCbM_;v-1J`eT()qx*&^`z@BY`AtZk4x=D)-glk22%N!jk6-IG#*idPyZ^xc7|V`pG1N|ywu%PZcpjjIR&R~oe;0;Fzc|nK^{E%}7>j}s6JXRv|3G7q;h4l)LH+zJr~ya5Q>g!@s1*z#^YN6xPz1|(4&=G*LOK3AcvWc<f<sv;;1w3H&4n=&TKwU!sgShA+f#yp*IDRW-0Ey#uPD&v=07<;q+84{E<u2Dc66|AzSWyW=*+rW{8aHz2i>4s4u&%C7u7^=&f=4jA%!7gbGD}@xKQa0N01XwXA}dT!T}Tb{Y@$~D7n2m+T^M@CpRXaFH5TqqKF@w{@3K>7qZNjCS*v@yjIoie#j*)o*E2mvb6iVPA2{hT=wGkd`gI)_;ZeLaW196_{ft9u;_=mtGgZN{rSX7!35^$X!l+$8SuO|oQ$F<B{T$ec`#AEQai!oGgF9EpQr1;3u=bY1@#)s{fiILcw~{Ieb#XQ!x3@wH5uztc-rt!oDi0bKN|uLE55uZ{#78<_StG$ZSifEfzVNSfFTUdxS94}*-X<upg^6K%oUIVh-pRORD}HM&v+IY*F^Q7LI8cDwziE$ll;U&mVmJ!J;W?9x<i~kkC-Hxf4O$~L0a^WGK*^l5`||MDgzSj35NWkYd<McF-wKmiDa1`(}5AIDdXCllyl@1o^tbz44Z((@y*R^uHdUoJCh2!%8X7CLf_(Q2fPe?E?h(491w1}>D$K-T8WZi{-b|fVZ6`OYk2bhA^fH&BOK?Z1$gHbrMS&8>s-h#9oK<Y!keEwifEvVwumIHL!!yIAJ6*P#8pp}xOO6P03h=93P$uUI8(iKgHqwDFpO|e>GaHCh>11873L{2RdFf)ciEFmhuvH<TJa8S^hT+d9Y!d$9>dwq|B&b031tX`e;kJeeM&8i?K?(piwi_RL?(cEJw<N?a&c)+&W5EejMIFce48%)7JW}$xVzQug-A?iD1g;2tO8KK*<|Q%y1z?5hS0UTS??;X5`mxgN4@k}0S?3b_Ex7KMsnDy)_rA);vTCS=VVL+imL6A{IQ8kv^$Zr9s67Y;AMUP8MlCW2~O~O#t<sNxv0O)B@rctohz8~u&voP(n$;F3=*m07oD0-8R530Sp2F!Bm{Me9K9y7phQ<Q2^$gby|eiUa=kp-0pljmg72(E_Fa*_^kYD-Jdq$2amFm>f|b}^!im};YN}j&6Sna`I0&uUp$>e*>X@30sl)b0?>O*|UX|IAY5?wA+88^koaOSRkIhIU>)ipI*+%+8y*q4?x%ZXAOAV*V-WqiMU(})`^<RB!=qd~CQ^VcNF!y;^TeF}<=C|h`wKEngtog4JM4BtyHITIyXKqA+%t5oUNsrrLqs!gllH*(j15zH1wypVu?p9XwFflR`HeDuK+6^k{$I@PlYT|FEFbF{vM0k<bvSv2kVBG-OfK}4RkY1C<g`n@sQVh(B9U+O(_-rZH-?@LxQ{c)x&C{cbIK7yBgw?kUF$@dx?oP5j_)cypjQy*hm!8*&)#%*Z^-&Ejte*wx1%DqHYBoD6Xf4DrGJji&%^L9|%ctxF4%R;8c@&Y45pgjr$jxcE%3~#5F3$x<y^xA#{LQZZJ-4`Z5K(|n%)+$hJN|*-{rSj@TBKsTd--OH0W*4klmNe&MF0$LLkrm=ai=k8s_V1dO>a%w^lVw<HPY?h@Ljf&^+G*B6*BSjx$FE7fhQ>}7rqJr>wDD+ptI6T*?h?OB-?DkfitPmGJQfySD(aX7EyUksS3E0<#a6~{b<_dwbCI4^({K#7a|PM!-2dL+Khr7DDW#~_dyejg?GC9wAZR!4j9$NH?ypx+hNoK=qUKxYYQpv*O4p>FXJ^zAGn%EOm>E0zE>w<S?%?j_4;O^hUY=9TdsqHg8}R}w^88WFE}$9XF{~Jys+}{vr2~N&oN9fsPkP*2gNDXmYTjPp{y$#O*k&y+R|X9OFlX=G%f8$1#PtX6t&$7nDY(v;|^iMX4g93&UWq2+v3{oySGp}5Gc{Ik(HDbACh*;Y5~YSQ2X|8;7X$Utd;^00MzyQk<zqLS9L>ybM*Tla?8AyiX24rX#%^3@ScFG%kx}q^@Mh<5?hv>oBU{W1vgksfwfFk4R>A1U4lHfZbzGD!fTbcw$f%$4jerH6}~JbL3{Lyo9g7}*=0#v!?KuRfPk0hdUI4~v&Xdxl+5mJJ9>j%9tC9q3D*$o09w!`#3@axPXsgM>Yy2HM^8(B7lE3_ArX+qGXDhbfISQ=W297u{w*knV$8QCMFztD^H_CR-fZf<zoEtMrPMqS=BJ`K6PkWoOzj#SH&fsA&6Bvfd)ri7^dowa+#s-eWjf_&^-L(S&Yude7@0_JHtIko0^O}<14h-4=7}wmu^^VXLhYnIxo7(x`X$cdIQ3HDW<|^&WHg^S=J^K{JgI2eHWe??K@{rL)dhv?Q&>r1P3_OuCBRUoD{KK!@WjL-_Z;E|kNKNu``_{Z489tC^%tZIpNf>s0(oyl+=j8#V0aCf6v7D?QeP#2<@^gY<4d?{j=Z%Z=eiW1_aKB1v_Iayf&TL~$v9pU1$tPnFG_szR4p8uwj4NhZr3fNDh~JiYp+~f+P1II&hy`$L{FE>Vflf-f<T{=TC#o&&jS3gY@K_P03}y$;P%hOa!$ux;k`l3X4jBywNqMB4aV{4cA21NT5?JT2dtj!@UXK&iY>u0$|a#cV~2r6L4svsBLm`sP9DxkKcAyyFJ}-2mzike6kTCcJ!k|#Rx&zUl>DD^Dk2!`>vaWdV^BN+fs!-My`CA>&t)8j>L$=PtPbADHTCtFh~5y{E6tOzYtRKjsQ$H;T_6t|GdboYvEKZ<{`IN=T^-Y@qt41RBR=?QjbITGik?31+-H{D_y?VS1IvWJ4)MZ)b^~@VL_CxcAagAd+EUTXcOP$x%~XRtE;eVr<JCU;05_#boxRd7!(3nhbUnDY76;0jBUJ~odQD?Y(57KG#5cES4X;L*FbnDAd<Z9fnp|ex^Db6qvAFA%6rX6Hx<>fNV^S=M2S!D0!*8r5GH3y3)<5ueTh$TvlYi<d7)zZ=8v=KywU|w!*PNkZHNG42^YfpZqt|!@90P*184{0^QJ!<n$_jam(x)JRiwb-RMq#7JJuU9w-Jg-LN7q+O>QIn0T#-ooZTZ|`fssGoDmbOGQgKoux*Rq(4+tiDlE#KPRMBqa3GhGLF>JkC2_V2*$>4DQ^D%@__Oea?tnQ>16Zk9SJb~u@!{J53H<VbN)D8(gWQ>hiKh8xn5Rkg_5k1jzo7N-HfWkWVxU#LDB#uo0>l4g9!N146mkOwP{p({8`~{id36p_bCVWLzo>UxUa%j#9Nrbo#WlYPqbUp^NaFP!#7<5$o8!MO81K=Q91`JI3>kV+_Vt23ZM+Au}%7{1P*by&rY4S>F_|z?NMvFT*YJSUc@xH@QG94<Yx)5~$!ALfge%Lw3Du`6@?WMnl3#-3(+yg;o<u<jr=1H&nH3<B>5=pZUC%{s4<qd{W**8ole3fQ&sIEne&a9v=Ba{goc2x%6juEO6|IuUzgA@)3zdcH)t7QLj$Q5n1<;>LFKY!}Ho{1P{U$3+Pu8KD=-g=q4-+uIBA?e8&BxaYUzz`MrJ>gmVn=pr@p#__l>?h*{9?h-$1F$tjP}iiq5EbU=Gn6StIEs9p4_Ri(4+dd?nC6GL1C%Mu;~*?cXC*<9l2Xj9ik(_9);dq{O3&COT%_9sMeCKS=3>>=@tRJIq~ZUQm;Aommn+VzL_!pmJ*=OI{&;k(XxJ=nJCpjZ53`tvlIl?RCB!JO#K|R6_~G9hp@Q%hd<3+taLMU}NBGA`X;}+dEuz3L*p-ux?ksKj+#fAfc43#mm{NjV8k@$NNA-gjq_m+(kA4dJ)hcw*hpRAZudz6cGosZd%o6K<%{0*KF@7=MX{z}H>S06gsS(pwE2z*nYzB_jdsAWVKHH+h;hCS9v+o2_!i6-PNBTK+XhdcJ260s@R^>#$qf5|S&8jd<7{Vv<Vsm<#6uL7t&Er5TGJ>cYLuei9ZX4|rXZ>^HO$UBvh0j>X1oPL7oFLQIu)^0i<ll1h$M^7CNEHYQmL=+3YBj_h=#))J*$}q3B8|{!?FVqlQNZ6=TaC+R(`XJst!5Az95nT|e0-oku+lnx*-pGPm>P_Op9sP|Uyd5kiET<SbChl^{d_W!N6){yX69BRKKhv@6<48r)~4kD&6_$UdS`g(U#g0iFBFm?7Wr6K>fPF~{M{&n61#Y?^j06^E`v*nuu2ms^HcY2jQ^^NPeStYwJI3Ic)hX8Gf~|}6uIx9;4aPtAXv9Ct_N7Hf*Yf3+Bzv<w(kkcJKky$njNRDfXHgS8B^WpvkV$F85)a~vPG4cI}s14Z;9go9i(9QYBhtrf)%abQ+sOVHir&XquS?41}qLm2%ogDQVwVRea>(ha@x@W7x20m2XQ?q&AqJDWM>uQo_J`l?Be4Wpo>P{x_%!n+V2c*ad2#Qf^DQweP1bd$b_`YhZflJ*sGG`BlDvdYXV3b2zV5E;V@XjHnQB63t@fLJUA|)b1naK;&3*Dx*3)E=USv0NLm!z><cbY%Y#*dLMuU-$Y3&y`0dto^p8lEJy~mk#GC8w&5q=wS@4PC`i6Ssi_lSaFX5iO9;R+f)O(Bv>hTFC1%<sIbX>-@5`H7KKb=eS3wQ|fSwU(lBa-WGn<BZV&?9{uo~J`|ZT7z^!g9==uu<zq1$Q1nDa5br%|5l+92wyfLu+`SzAKk=cPJ^20eb>u^%a+Qo0)LEilB4?TqBGEExJHXm!Og5S@tubToL5WJEO*ywG=?J+>}LA(EC6~GY_?tr#IXCh^LGCNOer1o2Ob{EVnjZ@!=-jRkrR!wuo{^W%M}G<8yuQn%LJZV=O^?I~QTWYPP#%6v9;&=WYiS0X4d$EZg}2%6KFGP0+<nr6+uCL!C(1(tM9LN!Ms0<!{F_XIs@tT98RjQ=s}?TLd^@kc-Ph=D>+UVG*UNc!!@$hRK8~k)b&!={Zib_tW4_dpS}fc6Qg>ypF^z%xEQ+MGuWx4nF8BY}y`yn|trz%Fh{VD7Gqy82p^;k*0vFC(E~Fv<=VX1Wx||>1MFaxTPacFKW{Up%+XSwgb)<FNQVhA|gYXpG^JGKI(NQUBY7^sh?<Y1N>nm7p%7%;RHXn^wR{tX1Igp5)Q6{ETf7qn<4b<x+^L7K_U4M5oaee@0gC~6*2Yxm0z}EE7SfAfmfR)AOk1H9KRa=mo$TI%NT=WnS@^bTgG{MGwIUw3aR%$373;Ud|~+IV_ft>M^gvOp+LyIwSpx&G%9yqRKa2RH<?WEUmtg4>q*zZ@vg&Rg{~ZIlQw!n&Pl-Wh1!WU$MC#Az@Y3=M0k0{G8NAX1Kr&LZrC;3ZZ3PPa`J3?m#D89AYuVlgUY>}J@uiIaNgaT;3G(6l~M`+{_7A8`0!@P!II|$J_ggzE_*R#XmWN&t{QVtm*G_zDDd%Owo!4l<<!dHs7QOxoRyptBOKQvxDk%zBz@-q17^Vo`%GbOVXl<+0TCVYzWcl8th_~oXTB7`jw9Rv#Ai&>n`q1k>a;n;<#BE@5LwTSNY8iPX}R{T#1%L1s4LDNFrvj^*Uo1Ok$T=P0^R(OR`HD)h_4*<+p4Fd&Es&8o+z#9_HJp9bGk^NarG1VaPa+%ex92h_siW(6tcj5AS<=)I!h(d)NT<cz#|PmlXejJNSq8s=^@M#jpckW@Dt3cn8KRj)0g#6M|74KtQ$8$nM8%N3s3wWn^i}E&@lOUd^PzqlvK^Lq-gsmVnGbycn%=j$Zl69!~!Bv1|xM7>|45ss@scb)(Bxn2@a`#EaWeCNi)RtTj#J;SwI7WDovi*!Cv^2Bj@&fh|${8D@sm&p4>*Wj&B2|#=Al4&;S4c3N?YXpLCTo00Dw|#ij!Qm5-#;vBYQl0ssI200dcD")
    PPACK_SHA = "8dadf0763d43d22966603745198ad327ed6ed36001cc60a79925ea18818f2dea"
    PPACK_SRC = _unx("{Wp48S^xk9=GL@E0stWa8~^|S5YJf5;Gv-`@?8KCXbna~Q3)_)cEP3KbfXE9&SXJMV<=hB6!@)dJk{Re`aCPtYX_C1!aYh_9-NXG4tLHXzLaOnCEN-uVY6*S1s_8BBdD;N<8>(E`kZR(i(1>Kcfij0^X~`&9tJ{S9<6D7pZ4W{bxa-QKQA8vpyYtc<dI5OO?OMj-&)Pc7^!#mRhmRW_r&Wcg_Wrv`toa1_q5hRBg|;VNV!4%C8K`aW#{6vLMQNRHBft2DFF-0*xk<hak(>dTT9YBqDDu{`nLrJCFfvSGB^SnIhVV)?3JUXzi4oI$>`$`hS@dQYOOTpyK*=1Ug`let)V0#eYpDSYOC^=0ua}uio0ZSNAsFrol+O2@W04i^K91gRKB~}Ari2_ThU3}Mpi$l)wL&FZ6)*hIrclU3g+tKfCtCU9d2eK&A7~qYpu_{Pi?i8BYU;jYPT4Wpv;5~{gvOFINWN$UYEm?lI#@AzU-m=L=2n9cJ{aDZXwMl<-1U?-1{Ti9EWI3)g&$5y<<XzlMdbQ)Rzi<NM8ERF>iA=FeF?JifFuBR|8HfXDqMuak)@zg3R2&GJm`dtEgmlu{E<l3&c3iIXu@_(inSCzpZ8=x}yyY2eZ+yoAtuN(Uc_m58|*(TQ<W83hqwvJvjj-nW`T|a?f-15SjRhi6h%UK)C>TViKD*ZBVlG1D|N^Ndgy0@*ak_oh>{Ax)0k@f3pQB2NdGMPVrk^3SVb?dxR#|?y9;T_Cj(VrXg@R3gJy(crCGYA5S|Px~dKH0a2K|W`R?w=`b9rnVJ$r`$`3d3SPbFO?A>%*AsX*21p8;o8*(-fp;H7Paz3M4l`ZvgT3{6gu+%`^ySB{s{<A;&?38A1GZA=h1tjX@dmBUmkFbYPnO;P7a450wS70z4@-k#Ex^=a%cvO~pbBMjXyE2z#I1OL%ggL$wITdXh??Q&{n{{Uzjv|vsOA!gIznu%e$)R|EV)MO6~i;dpjL<VcrldQ!a6PCR<t+N*4j#QBDrR9l~+!cj%X!iKt>pC?t84gvodU5-v!j+=QRa02%9YefFcH-TRye><3%9L3D2(tF?Ud?Llp#Z3+vu;qt2oa(B!WNF2=7L>;TI@rEq_6enXO|-$&&OmVa#~5K5aR|4E{gY=CVvf!^potv1z+Qaw0%f_P;3(gl_LiB8{18o-uYri6a$1>M(2u1tpHIy{$3!`Qkde$v)Z-3c4ylV0NOay~6{oSgxp5i?<!d8@Pq)CUR&U6x>X5?hml{%nVuZ0a3ss5Hxs$=-<`H;OozhV#eZ#Y47^HW+I8Z_P7pMLVo+FhM47Tb|vfrq}@^{EQfNLRlTL;O6uB`o;*?M`DXKVEZMN-bQYH1KAU2vmkHCfjS5EQGb&8P||f0WiEQR_f{l=+{GF6Y8Wtdst8-%?6<^!Jma~syXtBDBsb^3qMYyG7?()fHkB<e7_h7==bnpGHK%TR%^EOX=y<I`3gZW}En8O}Tr<K-5yQWC`-=OXOMYsjM4Er@e~Z(~RlLd4RJPmGDU{AM8hG)Qn4x^mTPUqZepc)}I16387dS5m5)v9E*44U(>bBEjjr*xWu(vC?u<Rp!q)1ISm-cA3%(JDHK?Xuvyp9FfN-F!IU|4Eh<98wMEbV`5tv=(eBh=BCUKw{p?3<<feVzFK)}QF)7;WjnBMG5lIiKV+)>QwTPt*;;fK|MkN7uDJ^)7_BA>zwx+d*{MA}*3WFs((dXR(n2H{z8qya3!5GiAUeFv5^fz=5MpXo*(0BLUct&?b61SO19oNci}xRYZTm_9-4Os>7!y6yvUoidLYgHRJH1?~$oRh>PzgEBHg2Y~W>G?Yq`gIjwQwZQHM;4EBiq9>apGun@V*dGkpgjo7{}vwuM7fl)Sfk_m#l+@7_lJx<hgpD@F*<PbIk8UfIK=M;a>GuS5bV}zb;SYMoy*gag*`Bc(a+At;2D@=4+&bK}dQ8+4oDrxINqwk`NLcfhrcWV6cifpZ8W?C+h#F4;zZGnKnbt`(L?XGX&rD)k?oTxv9TZbn=MUMAC+0C?1W@p`;xdY@HR1rQ9JL;cPY{xN>tnlR4<mIk2WtPkr$7c7}v8w|BS=)awTb_R9dt4>}AbJHn7rZ$NT!T|A*8knL6;N#~7T38}ANj?(^PLT5cM^C-_TYhlQc@*Ut#Jg85obBA94C!rg+UEVX+7DquN0%B24se)7~A$btj4tIWQ^ZPo3Kcgi)*s%YmsaxEhS3-*3~Up<C4!GLDdR=i5Liw{=_2DAI*zykv!OiXMn25;UP|0lO0nHnqF<X;$acM9v^3-<;&-YUSFfSSN*R3nPKt&`)-_RK~Zo8hG|CI_X@5O#@LBgLq9X?;-3$&z#3+E>0C?{lRv8wCJDJ6*!=a}*gaz)F&=ct+`$8_)kVlxU?;a(!oC_}mpcWzyR7Lcg=G4m=1X_ftgr5CK$M=5E6$Y4cjikb2$3mP;tH4}TghN}tj*?j`c|o=Fz8fQ)a7sPHCG84VfuHhw;6_gLH=vF{@m<)_ohOfflLc$%0nVye8+pgVTCl+!-ZDbFt*(A>;N0WxNzHaMp)%Ibek#gYF)CbN5`Kh*hMJho7fva>FKKikV$uIwv2s(N_w^gY5Q|S8H}vYjLBpCbC{e8L;kCKD>SVP0Bv~XCZo4CXrDanr=0Ju3@&8{JpU8a^RQlsO8K;!Eq@h)`870BI|oJv6c_cS`UR4Vam6opTK>bX7fyQ4Cb@f^PB*34928wNHJpY3hPj!9`)QZteSwjjHUt8Se>vVyAxC1%cvem2ch!BQU*oSEb4I*+ha;xx^2?NRaVR3=V-vZx49;)9J;5@MW})HDzcG6C7!iMaK9l${(?7FSE65~-U2uW*NfTpVN9tz5QCvVVp6Ooq+(l2!50>X7c|>buTZU3p8<t!g4@StNqFkQCoD#~n|CS#tUSu<@r<}mu40^-|u2q{Olyg3oy{j3!zF*%8r{6+kO#pX$2@CFN{jhN!nnu&zT1u;sLqswmm?x}^VvxH0lb0L|S+Os26it|~D_Fr5Q|;SmVqj>}928Jsy^nutFK{gi*=Hnc0t4(IC&Me!;`^!W;JCIjI8<{;eMuA%xLFP$YoZ)GJ9N%cqpl<v{zl=SsqVC4d(+=hLu_>T6@^vJ(Xx`_PPO+~(}vdg;|dwTu%+zZ`N}KC)hDG%E<I=MiGwqea@pLmn9D_C6617|AJKmouGRH&qEAH;YL-|gK($wctJ}!K*>RLL5v<RBYsyX+=q>X6kU;?u!P*q%+q8W;RCC^x?J5iGYNomwAcY3E;gy91M&@^dGNC$xB-Fv_s<g8)-&>o{<xvYCMPhf3n);yTR}9zpG7!L7-&xc---jnqXA7rn7~t#Z4EJ@Hes&e({@VQ@k>tp6gswTY=5kN^9rH(6-vZWc1(&AedYy&d<;#%~QzUCN8Q6ijrTz9Q4gk26pm#x#?>GLyXzJH)gCt-`?P^B{2HW2JX9sN+g6`h_AdtA~!Ji5pR`o7U!c<fTYT}i-aftw8HptPzFv@SHPa_$!$2}O~3_(y_@I=Ky{>PkgQCme_@#J;-2Lfp}Fx@>A9MA{l#6)on?fpDOg5}WBws!g<MKSpfq#K&I3BT&!DxW(94<C!C?V%@G-E^C+X>g56{&60uptm$_SjUB;$6>wICtf(nv-}IBf{tIC5iHE#-sE?p4m&1>%ot;C<~yhwNPAk-to)q80f8;Y{)<VVc`t3N#ZI<r1UKe2jRM!XR&>r&;?SOqV@#qP*{z79vcx?Hcjk`9q`zLd_XuPcbX_$-mn*DMC7zf+IKb9H02ZVak+ST=>T^8HYfVzrEa8%Uk@qKGjb%fNz{rW?OX&F4yX%nK!;pC6fWu*~s4z>k!yF7&R4mPOdEu67Di`nEdT1<Yqy31B81%g|O~r$d2u_?zOv655iJ9@hUkn}wpDb1egD`LZ15_B-GfzTW=(Y)Gy@8mVCkrx{Mvr)t&k38y<@;~gm9|~0PR?vj!iH{sDC~32u+IF78R!r%S>;#e(3+CwU*2+u`TsG2v<_|A=B|CwQ$pSAKRoE+Vq0il-iXpQ26zQ;=#gE;060S}X_f62v_brzWDV7-r@xg{;YzGnS?5h>q;+s|Dv%pPI;QWc!@E|2w|K5BGDvpwhkn33?Jn_iW^OTHwlqhugm54o`$S=ydU&Gy+wCcStGJRNc{E(CcTUBmvqS{s6)#pteD|Bt{zMBSdE_uF-;OUJSa2-D!;w!nYKU(mu-a?&iWxM3Azqj!_S8|G*oBb-z%VgM4S3HbN0M5+^Ixib5>SI9CQbRnxlu<U(ttMdQ%U_<nf7~yU*8t*i=H8i8r>8(mL|+W+qI5Y7r{bF^9ttPXe6E*EoSL)=$JLy&&p_$YPNLNHuth$KtC0^MW>XmE&O9_;LS7JQ?j*Z$#=ccd1Pq@+qr7(hN4w`wjkCmhwG1`QY07ZX*Wp6Th6`v=S3P?K+3!7cV9bpDg1_Bg8Lh9+nuM{r1HyROZ<fG=3e^Y8!E%4=y?DWvimv8#_X7~@FLuFK{W>sXn0z#V2{du6++S&V2hU{^1_&1Wo!)Ryf=s3>%)4O*AiShIi~{^cynFi+5@E4UB7Whh1(XmzzkM-%`X_lDsuzZ_;mv}kc922oeW>89aF^NDSXv=XS4H;C9h&M2OGqh!b|H9f#q#}O`St11Ls=W_NbjQH8AT8d+0&f=W{?cG%Z3_2m~=&>f^T-QhDOzP<LeH@2lV^!~-xDq1!CdEt4%nj5oZN!(BJQ?6{MTI%){Lw_vYyF!IRpWzeW6N9@)0pv%pz+Y4mlr{m>x7^fNDIJ4ts<aG3Rm4`dJt?{=?&Es8HmB}ZH>vxXPK0Bzg07_re6w6`PZaIX2oCv$bvn?N;H5UOWOKya?v66;NiDg|w?9^Y;wd0YxG>by}ucNj6f7du`Ey*ga=V*~GHE~FomEJpqQ=U868i}(o&j+B~%K4qIDtd9^N%E|Pr~>8uqEgyPh?1WvBY|sz?+TlULF;dC<6@`4omLq-rbXdOrPm55?N~3U&1HR}AJJ)E7G}iDlmq6E;zIxgO=E$cfVN2iLj~pSm%a-}1lm?lIO&pwhlX;udTEoeufwn;GA`<||Jb6RI{R^bliy}0wmUTKg8LdZyyn1^DqkjHh{SbBch%vvfOJmJ6P2CUz|X|MvVO{gE5!kDcBm>Qn!nEsqqK@B=p$j3^s5@PuyWyuv^E4jhULY0Yq+nb-ndDfJ1=99yFst*UK74qLlcYLFoS{kq)<#;vx6clh`z{qhwux{AQ3V6@~pONjF6!1Un|}O%B&&h)t;zuwrJ{yw1}pzoH*SbqQ#EN8D>|KWpqikYRY93>_dfTEt7{uPx6Cubz)frKrw9oP!}cG^xTjipktwQ-ZH@w{*&@vnp$<Xo_+O716fK{?uydira+7=1EOYNGtlhi8s%H7p%dF8EwQs5^K-G|g`wh7D|#^2BdO79ZYkQ%3Hhsc#)a9cPfJbb;Zv$r2*t1=5L#jd+6HUEr7L&9`f1@`l~T6r`(e&zcVfa3lnV6s@$3aTEN~Ts=M41b6@}B^B=s`8o;nyydu`yoxLNA6huhF4xuKR%;K>04A-0WlpMjJ3`e6_^By=B4k3YX@uAZ2SA7b=v;7kto<3s-ICqzk@6%>rtySB@o9GR)fGu#InidmSndbb9Z@VTv{f4s*A0AO^7%5NAK_C^3?x~47y0K9i0?!+|fnZ>Jle5aW8Q#tGa7hDqXYb=m%{)1Y{j{kHxNaZXXZfLNEiTgowi1MiR7KfULY*XkO%^E~$s*E2eI2~7)t?#Rb`Fv~=OCZl|QZbZs=*@IJYPGUcxZf-@$$pAi#So!?^0&xU5=2HFSNqx|@(O`X$a{v^oo_UrN@pd!@XtpcO!=-Uw#e=Zm2)ACYy6vfd}#!}5InwM7B+;saw_Xp=Dn12+_|`r6B8xr*qu(=X}59?=>>oC;|*E%-*@lQj`8<`ZPCGf==WKIx8|7_R`n03A1qpx!e-dmugQZ3N#oroXE(s@nHiEkuXa|;oOoeNZV$`y=#QY86O9|+>rj?Z$LP4|S82_s*hS<W$A=JOi>uW76aZSnbK;Yze|lWgi_G>(p97=X_JkT~D5SBP$J)n+q6l1y-tm!+YV@z@c_Du8bKpx!>8BuMn=Na50{3mC+`1dkR;qdCVOv}A(WjzCPbz)T;N;BhuTbTo1s35vH@b>uCgm;#LI+c{^K&4vePGymyxikOkcZH<4dW*pAYmE`mPocL6FY@A@Wnb>z&{AFur2`o`z^Z`Y74<gdT*a~l_>Q-2=<a{aZY-`Mg`_=l^PnUAFv8g_tnjS7Sde!5>F8w7;74Xsp7BmfjSzui^XF_>7~wSxbia$DN-g(+#&S*FHi{>*~xNTT0}!|yS6y8;h|L1K4RfuhqH~Gl^zH+I}dH%hm}l%G3gRt8aO7I<b$fc@V8q7&B8*$Ucv<aYx?fM3AHvBJw*g#e2lZW*wp2Hp$dE)(oV@88tCsre8*-vhM$vuUsb<n<<r`P>u*tuqnkHA$K>N=LN<P(^SFO#KBNbz`w8`ub122&P2f=O4I^bA7=`ea$vi5hv^3*AemO@CCT+w|6QuLXv&B)Tk}W5#c!Z?r=%QOznfHB)LftHUSIK5L?Oe9UHV|QN?e~+j)t-!kg^OIAydmBJvJm>GC?H_CXpN|{lJoNAcrOI-o5Z9h=c{iMEZhx;^cZs{%ufS5r~{GsFCVK@weMMz6h+XJkCWC8)0^Iiojq@aofJ#nl(PW9giMU|!?Dr%qIRQm4#<t-0m)dCeFK3m6vaM^Dy%)8O866c%Z^3cF;a<bDzL^Bd*SUkkph+N8rI8LOB7>8HR$2y&`NT0_ejIYjES9l9LG6c-~^`*dZ$G75!OL-u$m0Ed=Wpb{Jtt{vjcYIC#I-rUdkE7Xeu556VF?98dH*pIy%;n{k2nSrqs9LH_Df52JI-$+B$aV?}Shs274^=OZGN+YR3zWBXGKP&cYumkihXppxw}w+o|vUw%S(KBJW;h2bf8ysZ^xzA{I99$qpTPbbksPF4v(x?n79DA(m=nQ3-_#kUa+r!uSR&#1F1+9F}?;EOsrh<;7-14vSFk&_jw+*Er5|dRN~b-oRY2gi*)sHM<Dxkoqs6kXNj&i;6DY6YQZ|fs9_j3Hx18tj0|urQ}Mq*Q{<rQ=47Fw56nCR|3Pv*e5%u0dsy|u*VC63zgcycI}5vTfR?8%u$?Fu~Od(^e3Sf6Z`7srI<bDbY1(eJ5eK%$-)J>T*^jAnpzz2o;bK3PXoNtt0J;7xSD66yL1->y4<w50CzQd(g@3|6rvHJecf(-cjd3%dy1n)t36a%Al*8-#BtsUM{i+~D_jIXN0wOJRs#7+fH^gE0AacxD>jqIxuza0Qfu?n4L_A~&izC+5Tb82*$TB2!z2^`PUvmYpXHB|q~ewJYMzO@$tt$ku~AtX*A-f}t*5kgFqSJj;)MhI%YDe<6GY+{k7Vm69pJ12BJh`WhWI)WI{c680)k-!aOL|r^;024u<ZefTV9IMu!_}l@|H%$doXPio19Y>@r6)@h;XhPs%T9S%w}bo-+i-nW3tlta9{yHy#h~^&A6e`E48O9&Jf{I?D~WufmOXud2n&5pe;lU!9HqX0bOAV6edskK-(mtZ{P$9Pob-WeJ5}@=dD%wGuo3je#qG}`1;@Fi<p8L8lr;FK{YUk8kgiM)qpqvnlBPpmyCR@A_O1A%+q~lZ$G)a3PX6iZb~IqJr$UNE;B%C#s}l~q<ceu4O|HYxY%3~=kTk*6ztPWeFnjq${;!4VL}t~hEvn<vW@nYPdgna0&v&*%eH{Q9Kg**ONZUy^e5MTjxrx{KG!%_=AhLV?*ezk^u&;Aj18zoIcQcN$pWCC=PRZf&O8$TTF^}aO*1J3HivKH1N5;{IFPU5(@-O)ik?Pt>{0iO!h&)GP2K~h^1{?MuDpvkFlW=5<_a41=Is>s<HUu?H3?Do9UGo-m}OP^V~J8{ay8!LX19$E#r$wF6@#ZB(Biib!pdL(leQxBgZLkQyAQ<)x5Zi=#mu8^%Eg}m1Aze$^nAuk9HcnklVZ8&%tuPUnRRw{maJq!3R}#{o#b!Jmte287>3iOSMnK*ObGR%T#-%|ougpr)Ai2wQsj0``8S#^YXt?@<wwa+WFDe{tU_bem*o7Yks7h|*ZPAnqgFGeUGCwPN<CH>CRNl1|8mLCnvc|0=#E@e*e7$LY{t!f66tzfTo_XsaR~?&mBhsJaS;Z;idYs@f?mVk=7c}!D;Ar??WxGCh!zgjW$8A;(?Vn+;>Wz>X%QosTTEi!W-sIZfO-?HJkpWKkTSF&?7uBGlCRx=URzLWMtR6R*SYnLgun!T<HVPvOm~b&h3D?HWlQ_I1ZjFM{czEGl*~*+g4c-16D6@=2s)icQIW1IyehLmK1J7h71qLuJW3M&hMun<DCe@IM-EI~3NPol0)_G<mMI2=4|W`qufT!J!?TlF9fQ$1&|G*~TJ!`Lf|Aw?qe=dzUI6x(uQa({hr;p$8NmKR3$rIUqQ0iC#2hO_iaBa$u+|li(AQ(C5EyPI&-o9uIR~AuK5_n2|B$0wv@}DH<#2a352>S}wu5gLu(vpQ!ZhM!=^r3XI_pG;aP+2HHX_Lq>h9NIRi}1%06+0gsvo-0(GS@vGVCeaix_tl?)#C|km?nZ?PgvTh?gO@a=jC(PAF;QP>!-&3o+_<^#UJbc_|^uLNEwD&gu|+bn-<)O@xkEa*66*o+)E9%w>i!lkypMo0D5TT~EJ!zwf4A>K|k|_5S$ZwrN??(SOn&9v-aXC1aTzt8&B3aY9GglL0u!PL8QTu5X?2TJt!!$@#pFZO^~s+vA=Mp4~6swAdqz!sY(bZ5gy(qx=_~ouxn|z9(%Vl*`@s*5r?r26~uc^_|f~oNJd$8#E_!40ff3%i;GjQKuk0o`8KiThTG8Nue_><rKB@n|#q>nuKM>Ds@sgKD#y`<?TAVaRX)Imh+!Sj#hTBqRm<`5umep6DfB9P)Q*~`zuthalq|V0jYYg*x*kgW31`!#d>!QIKd#@iwzPlCuI;yZwjjNA@8%0#Px5k1m`9aAu}IjF<7(;oz!4f*zl8S-H4+U&m0*tXEQ_!>qPm$dMqTo7=W&f(1sRj8a+6XyvV^<^XSX>Z~fozYr>eD562uUn~!<a(+IPDb;b<t^__Ilp$na3NL!BdOAi_{yA-g@c=}ruJl<I|XtU*eI_9+0EcC`%k=#{8pR%o$jlZ-o09wy?unItH(0TKn93`=`m^1mIx+1_WCqpR#wf7%Z$UTH@qoL!7O#ThorWDS<|EXg7cs$(~z8JR$y7~0bw><@5fs%GY6F-&-2T$shsHs(p&0;%e{{fYV047TnGKKj_cf29G`hI`>s6RPkvRa0W_Y)Gfk*9-nnpgkL^6B^t91&g1kggNmcoajQ*Qxfm1nCO#vEZyJ%Lga25{s{f_gH31tsx6ZJ_wTucX8X@j<R7`370a!s?v^uT+n)j!t4{UXs-e_R#12otI0$EJe?(@NiQwm+E^@-@YJ{N`qc`qd6(zeu6fcQ<fr-(V&HpL%oVMF7@kE$+n}F1<f-2VS284S7jwV4Z-H*DMxbu43oFja2NvAwaFA!Jb;rzkZd2|eK>T8+>L=E^qQhEv&5s)A6IO9vo|Z9YpK*d(OxG!~rAR=cx?=_lKt0UkSc2VI7|YWN_qbps;PU$5RYe}%WmpiXmXr}UZ@zBnbTV*Yc-=^ZyW#DtX?|mV17DhHi#N9qai8a=e-zn<&J#abi1PWEchw3RSg3RbJDsTJVBxYqtY}5hJz5c(3!CO6K{+M_J_72>lt0w%mJPQ|!}0WEAHM)s3W?|5t3^nU3liFxQEo@5^wpkmeWw}}%|DCkR;QVmEX2m8S(-;9<_zRx3*;o8qvA<X-K~||w_y5|c`F#iiE)8;T^8axo9&cp3|v-p$|T4S02!><SnUflw%G|Ibh*=yMewlQYoisdy`hMf#0SA5dXBLcz_-+5UEA_tWs6c!9yk~Xp_eqw0XXW6b1oKTn>CO#{xU9Q9<}A8_c8-&IpyqKo|TG#e36$g!NvVQIj^qsFJbS-_^?XR*+nGSHusG_=)6#`3wFrQ@kh_SzSRZuN-lFBtfP}51I#a5yoj$EoV;Z{$EgSp!d%R9Jfmqmww7kHSFky?Oe%hP1_wLS8gn3^ex)&<WVfPn`k4t{bjRU9>EcIy`Yx{x^=M5Uax@o%+`~d7RTaK~VHoh5?peDUG;aN&TjXDuY<)w9z#`2uo%N7a>iV5d=nCc>*1I@5;fHI2hOVT=&Pkox%s_}G!(^UTDmsbG^6+;px|t8WldXOT^Emt$J@qOpSJEZF`(P2Ls#n<9kio<*=erZ9aeg+QH(G-Rg%7B2V6O9N-=a6g1iRjffi{7f%G61>ht85tJJXGNx!d;LfJM;$6u%18143K0583k&u$4kL^`iCgLYi&%xS{u2<t}RSu)2NX0TJ(|#a<J~LihA+(us*et;#}+3p2o09g-<geS*f3nZtqzm0;O9d2%v>L1dSf(DKFCY%K4OLYahYWhM~SVl|S@3*;<+;#&xH#wy9<K?VWrX0K?{K5wWrK1DB_(Z`QC#(<7rpgjW2zaXe#pJh0F30v>)4Vj{k4$()sdnqqPcB^+Hlw91lGjO)ZH45r+$_|Ke!Qe{|;z_V&4&Z){$olt9qRD_Bld8^MMPFd6Nt~=}{I^p(2j>TS{8eBR9l?;YUMbx86f2V&mV{Z$F^Px&`a*3%Z+ay6zU@sEZbKDQjWhzWrAkDrM)bX2&>;xETZ`g#w6tZsVDJ?Ys>8sV^ey;{ihn&(F*R9cp)Wi+AiRhQgElj$l$qtxWy$w8Fc{(+@P+}jC=!z7`^Z=$4>&*nDc%IXl$33LHgBo$(Bo;THzMpolafx2deKW_!Vg|Zj0b0LFd^Gr{{5VL?nf`JL4UcH^Jy<nVCqS@Kk^8H-)(tG(gWsi-$z{0B^w=tt78r1*7YoR+2MX{n!^`4NDFo}B*VPJLf>7wUNZBVb>}2i0?veX8!ExDHDlK-44})JBUICd_<$?*tOIp)%A~b6n?v<@;+($w-P#yDi%J?u{wPPbE(fFRvcuwmRK?~D3^Lh<m7to|IuxuCv!to<xmWfV<lfBZzMn-VkK1u6HE2$QV`d*FQUwu?-4f79)H~z;lbn$%qc(N%|9c*WQY3<C#p_FE)XPS@VYnjujIY7q3K6;MqEDNP;tlJ_^C`mmJEd^pQ8_jv_&L?~WJ5zohzTX7xT0lK6roQvMGGMb(l84>`AwXlIp8>G*-V;bO+C2%vs10qcAs5J-r~r{kSDVV-}OM3HvY$(GY-Wn_X!-bypz)YXatlIPKN~)^TqmfP}yB}!|@fGnf@93I5oELNK<kt5QitTxgs--e`ivZ_pyWl@R+x2G-||tgyTSs9K9wz!rL%d?X^`O2T&I>4T;dHpxp_k79n+83acB$0RQXeT$zQh@k0m{*_L1P+$Y3%N=&fwNiE5=Szf6}K^~7e;qP2`Z>6x5hWQ#B8F>ctcb?A`k)sv=vsXk#n}%>&_id#^hV)|XzYdj}6#$V%2`Lgomt<Ie=hr6|SC&6>t+73h!Sh8bdgG;oTwyC$P&%w<4D&e`29?H$e?OGi61m&GdJk}={O%io&kTOlPVp`K)h9%sf$EE>YtszmfO`&K_ughl;D<vq#c%W|dv(u&m&Q|HQ>nw5FU6O|h-}YXx0yx5p9F|W?q~9tRQ51mp|4W1bQpSMXaNxbMc+3j-=b2Sm~bS&*x=RwOo=0)tO=-VCP(oaEWH2F`jnUKCNrn0i&vpE)!?_UmUSY|{y4}ksPSTPEGbkOj9lUzl-p6ScfRD`MxmR?n^Taxk8{^K|K&|937K9k@+)4UE0m_bI@;!Top7`TKeecH&Q&mEKOVRT(sPWuYS6!}&p0Mj4*a2xg4s#<P%0{%jZCTye*oE-%w-8#f)b)SdEGkZ(hVoC{GXrQ;VegzJRX`CoLxZ^J9xwa;xMqqSkQwuOJ19?*TQBaf#cJmZ$N_vO!5To*m;gC9F~x1J?Z$?7|8+}35;&`{)nPFhOOvv;*%h>>y})nu^3@|vxiGEZpe!(bdZX_PG`u`U^s6l&XGy|BK7>C%xzWl125~740iw-dV`HZZ(1vM(wh>9<Z1aGpz?&&D^Qmw-Z}Mw)9*&r-tZF+1Ui=XfO;OumwA)GtP>VDHIqpW*W0zQ5ArGRB`P`68=T?FA)$)Rik!tDt-50xz$bCdj7v2NYpGJF>s2V3#gWSf4$^Qv$H^xV@{eQXHw@CsnBBE|KW$lT>y!b<SkCNWTJEz$SW}!UtfACS?^@6*ozBm@W-{Dk=b5$D_%aLd-7+5mfv?@h#fuUKxHP$?XDHC0C@|wl=Zr=ZfM%4w>QyMmgka<RX?eo0P<HJ)@7+d4VfXw<>2ZKgV4%$MrE8^kRkd^-S&_>A`Z7{ddTJUQA3mK>C628+B-LZ~Y7hj!&G24`>zxY36hMe4+yfVhfY_+n-)0i>sr-iwww(3sN1Hop5o&lpwH&PBqi_7#==@Rj%NcAx>a%}dIG39)aAgq~ns>>HdY0uK55Wl8nBbTIc&Y4XEt513@EV9S0Yp~ykxWRYxAe9{fvy(y)S$s&9lI*RnzqH+GK1$<`x{~iU%o7Tixbh*t5v#nuouQ)(xs+Mqci*<@+%DMrF6WLu-w2vlM@+HECEJ*9t%zooe6o(8v~BgqQ(ZhCi~o<T6iIgPl&z4@pRq9{Bho|9wHkdFnQ)@>&aWHihS0C%=C(~Zf!*tAB5W4N8E|~0?e_X8ix;4Xd65sAki!N;@kNTE!%*7;2NCP+gS{`^2*Hx^MzABeddwew!%%P0D0s4FON9m)M#IMx8L%YD!yk8Bibo`khq#p2tKbt?}{^yJy(A{@gt*jE$CWgX%3;maM%Ew(LzBVA{5KBQ38Fe0!$#^PdKM|sNB*L`FJ7fL3+nLia}`MfGK{y;|-x>btuS0Z@EkpVQzrX0zTF_)Ke6UZ((TLYPJLHDBekz5FMvz9A^59#e83p1U#3nmBmj2a5p87s)JV#wT*YtX`f_u;x=nrPkx~&77iIp%&4={Y}RzcJ4vRW#VWrh;0k<L%Ee<zQ*jwcN~=9+iv60Hu7E=9*7kd>FRRhKwkt#@q*>6DEv2q401|bKD>FLsWk#N&i}Rv{KQqe1BEFaIdOIyG?d<Q7>^fO$)vL_tq^RQAG1@X$!n73FcPU^44~GmKw?Btis-m8eQM8Br#<wwOveAY%UTO~t9Cl1)*1`D8s*lTZDo^a3oj&jRRhfr%I-3fxrg$Z|^RoU$XkJC0DMwf#-Pg`mK#+6Jug-u&q2R?2_@>~a%@^hD1L`0!)E<{0U~EU6#q;B=8fMr5vq9w2pS;+fw+A*d)bbzlrVX35DwlKAp79QSh-J_FyqFSuB&&hup{#XQj{Tzly1*_1G%E7lkXAW)yLTmY=KtB&upp5&4UY*@a6;Qgt6sE70BV*TzU~HkN&>Y#i*WrDR+1)cxsHCD0H@hp{w5ATwuOs3CtLjqj<KH_n*SYy-B=aVU<alvB*v+TPpa9~WCPlU{R93o1@BP7YNsb=e!hh*7oZ3^R=6B+*e#uu>W<oidDq}*x;?~LA7PCg6j14*dF87jB2bSD<*Dl2!1X@P(i_PixCZc^WmzCZMw=Zcj9o!-ZK&G)G0O^i3)`~L3OBeURIi5YA4=EYem3<odyiJbXO(2zyic{pLWWOwi=rp2X}Dc;aLslN^e<J{6#_xoJY+t+)`XU#8Vpf{$E~=Gj22BiTy{6OjCQ`|mce?7-go<vP@iYc*G!W-s192q;=k^4nE_e>??m(iDbEsHm>D&A_D1a%nwjxqDf90QKe2J`I=DBVWWX=ViQF#9y~gC$e?hS!;Oy_blo#-@YGz1>kCX3D5!s}W5d(CI@_c|i7;X9OTYhBEwgdGZH9nYWK3xEov1jbLS*8VXwD|h~XK!Id0jG8~duxjqjez+9<*uv-v+~hZ)nr}lfu#-_GX#?x>8}AKrTStCT!SgZf<z@)q%vzkQp**bS=sAlo!hH+c+@@2v$b&`>2tjxu}88w3L94cVxgCKYNi`SdES@Ojb3uczbC;&Z2eo5AKQ@RMFK4(dDA!2l~UWXYk43d0^NpPY<V>*Q1RynN16{}_Y^^BlLM`RuC$D7&gjOsuf}WQ?75ANoeOyS67RY{NuFU0^2uDpTgEJ(>g+mKUDyAVyxVNa1)|~1(<kt#nAMsi`ltGaJh@wHdwrVt1Nhy<0IX{Q%%(*TIX_pV_K32Z!MbzVVSPFtSLK+Zrbk^MOj<`{pHoh97FTbWM@-<_`;A24VE)817ktUfdf@^sX}VYn5FHB7_?c4O`QH&WaHnz1=4Nesz_VS}0nIN8e~aqJbwzh^K+LdhL=9N$uQ||gb87(6CDdJi_uIE`!%JcMa^5+;y03bV_a&39NH`H_4o=jx&}YVX6n({9vmHO}&uK25qx6t~7^??S9!q4}V-ok3Z$4@L<tKU)<*aX|VA7jw6B1q^w@MtAoJBL+ZWI7(ol3H#qfbzgCfHFKXtr6N1O~Vya*;1Gm=0*mO56s$FeEi#^?eCb1C5a)!-tqf?@1ndiiX1Y7PBTh2p>M<#Hrf6MS>y)_p9Ud6@S)<X7Gkp?Huyee3}Q2eKYRDBJ_}MJQy?+;l|XfK)75REB8!V;BaTU00000A1WprmBwmp00E9#qQe3J3hnXJvBYQl0ssI200dcD")
    SEAM_SHA = "7356d4738962bdbab4091264861c4bfbbdcd7098d6c75b9c48db69eeb73e6937"                    # "" = the builder had no dflash_seam.py (every D arm NOT_INTEGRATED)
    SEAM_SRC = _unx("{Wp48S^xk9=GL@E0stWa8~^|S5YJf5;axsm(_H`&Xbna~aR~z}<^`mct^RE%jBwK?GV_~~IXTx@e<)InE4i$BWQ1so@0$Up72S8|1Y<?~at4{w9!}R6eQqkHnsUOAwkJc6^_i~VL&mUg`sk>^GQ0u0`?`w6hTY$$)22m-oV9F0eh7c}e7)fNE*i&&(V`ZpIHB)tQIVR7hkE#+^k&=eTBNS6FM$$0R&F>;^A?i1cw>g{%bGrS^TDv5JHIjCK#OuzIijuAcr!K!X0%|xtrU(GrUx75?Kev4?bZh5Fzxog4tpJgen+tGWb-avl~zr?g}gc<>UHMv?OCL~NMs*ivYGU|J#6!h*Bqt4#kHje#|bO(+3uHzE%TYpsG*ie3?#^4ti)-(Gh|lS$nZWX;{hQ}dj=U+G&olKumYM%2e*}R%ZVTQVL(QX_W9Y$6?y@wvCGFQ!mHf^pYG5+$F*sG+^xo|MAsREwJ}NOQ7MNot3jgfYiW?axu07!{Aw>q<QAVjrw&AP!%Xf^<ZU5%%^jCY!gd&_u8qSG2QaheaxaEDhvp?FewgHm?nQ$6oxG_-IOwSqR!|!<Wn#eBzJ^{G!QWi$c|4%yL1(;p4)?v|5lc^|9O|BC#nrUhW~E_F$~Cm}fm&i)q`jijCg0D`=Kg#95&uT6MuRn5eYIWNvI56Jq_&?QYetSGt!e_?E_2F}1Ghq;Pt;FHT^E?UDLzVZPfg*Kz!Lv}EXuKx>au?tBLzN>N?jlps-IVt_|)ZXvE1dpk^pp*i`4G;Njh_WL4#?F?+#?P+Kh8L)s)LlpvtOGD52-ow>KyReQG;Bw{Y-Pw#reaxwd8acVa`V`YI_yvm`Y2t!OU!82qa4Bc#_i-%><CEBQyeS3yUA_qUr`-Esk^5NZxU3-dfoZ*R@{`bcQiegV!T_>E?5<1%LIO=ybLaV7jlg~9Gl&T!O-{fz92e%#uaZhzDgl&)I4nJiZE@~A`@V1_){XgYJ5&TKua(4fFE<uLc;rvC^3nkwbI^aea=*87ncS4ToX{Druv621{QLm4#dj4ZcSm+38z!r7vD^S&k_x5l)ca=6L!L+J$si39GH1Z>{<d3h0E1VKIMSWUOYtQ2BZEN<ezj=GdLhlFX*wA*NzlBO6w&(sP!SvE`aI1G;!dS~jKStEIFB@LX=h=Dp}c-^h}0ezvfgU~B5&OG=|37^Bc1oN432+a8!BnK3byYsAYc)%RiekbQG^l+Yjg6{hi9PW2tVX0_{JD|~#hCt8!QCkW)Fx{{O1pIHg$0=&m$$%=FlI{W@|JLE^IGpT2vb2av{3846jRDEUjP`}1W|JuSW|WHhxLsTc*<VMJ*`T%Uz~Ps#_+0k;6L_kpfM)p(9-6he{A*dGU>EqEpcOo|Jn5AJ&34>aCQ&Xie;BWpS!`%GO@(e455{GDf(GLoX?20VwIP9^u>i3n>ntjljj%|`J&+<A5L`ZS4Yt;svaKlsJ)VWhgt@6aObaw9T9G`CQQ7z&DCN$>ufoQPBlgp)u5$@*t#+pCaN8sCXq5sJ0Vp?##EFBV`#b;|2fy;+L%Ca?@9&j877FQDNQHxowH8<%=2Wnab-SM=;1rVb?dTL^0r_@@!sG2CE9<wp5Rs#Z7%<D81{&7Yp^?hag2HSt)d&rB2iOVRU9dS=nLT3t4D78uY`$O#WK`<pJ`X6nqK@FjL$1S)Zs?dd1|lM4(+<S)@1R-!X`d-KVU583Gwd|iEL}Y>LiLiy`$8RN(XC*TazUjAcPgORrb2qjSzgPWB6fdhG5U#4-nJKtkt5PXz5dx<zIc-V;?M^Sqj~m++mzld50%3SOwH4ENejL3t}>_$?H!9LuwYPELvTzSZu@_?%8!k7vQ^+E(<lsPKDwm02l0t41Rt32zZXf(jN_K^*is~D1lQ`xg9Maygx^zCAXP2FyOphmeAv}v4NJ}&_0n7QbK8$xU9UcHRZ-Ig;Q@WY_Yd(X`!ooQx=Zq;@mf`KG7TL3)S4n}Q}N5kEVccMk%Su5$=k@(qBb#(eI3_{r;$*10zi}dFpo%I&^PwQTe(T7LlGa3aj*G&SZ2g^^NF^bQ&TY(zO&yz<I0+~^tb?xDvZsQH4?iO;bB5k44hT?83W*_;6=Ci3Y%6V1FjFK(X|@4p?Pjx5Y3*f%+diT)e~mp?jxDfzUdJ&I<PHECFmI#RqV<;y>@;&I&FvU>#EDG6efUL(0ZyI`ncx?iJyei!WoNx#Sqhl2v6o}-+M<2NH_}V@J&~<D!r;6isK@vy@%ytv)5W<2}0F1PF6nw;2tlmQL&I@C(V^5>+=`glvgCxo9BNe;X02<d7(<A!4VR%#-w|@^@<z}cIx@_cZqb&^(+puo_>rl1{>@^=beR?@c%l>5=Zp`CQ&}bpb%b_NHtm#P|?wqw*{$XIlHW6!rK(x437Ru)*`_q)9BOiclq;b@>H7}<_-Sb4oknBT{*-4ttRX3&D=|}chjGvY!cNsogy5b*EX2t)^yhveAjcVWFlYFVJ&S=k%@4LQ|BT$zyP>h5J_>Lh@aRt3P<3<-J`VL2J|(5|IlJw_B&ILz8B(F`QD~Sl73|M_P`VwzWLA?dAXw;QR&onFKm7wJ1K@7HsP{-g1&MEW(o7;zN4cR*&96{ESuoKo%Cv<ofEh?(}F^S)><X(N?pWCWb|@n=}GAeWvpkeeiaMiq%{~meA?NyeI3y2+S-OOSTN_kjne1n0La%X)+o~VqfsS1VJ)v~#UWvsM9OmqFDKskL_%v8vTlDcYz%469)*Z~AMA1He(sGW_p69+AftsWy}C(^c>y<k-T(_8$9Z4u94pL{&|as<k{FKKDWOIF0~~Fo6z<(qy?X>}j;sL<mF;bwoly=($)2KZLjjiGaHgo|D2QD}ISkmOthC4BR4l=yC7d4NNjPQL1l};znMWWdrY2DCfg+LmxdKBho`hy>y-brpNw*lfMbNGv=1H;$g~jp;Z=2W+taRuwc>F(kPfmuEM81N?J9zJ=aF?E1y<Ao&412BWq!t_ZM_XbDR!Lz*@B>|?yu>dBUb`#K5WqUv4*Vbb$y(wB_*#5f`o-=SgFf}c#v2L>N*8O&o5t)2zC=4~gw;swS8RfwOIwP<#YWnzHj(B6dY#S2N(ad(tFBnS>X-1w4@W<OM@bg<_21u!Wung(8T~nBu~2X;g;ahoB43Q|3++gEf(|ODJ-Ds0cqy^S#Ji0>3;*I`O$rp;?C|c&1~#U<qb758(jvR1hDrk7DASImf~Boz`SjK1XtR$U))_8LYq|H6ZOF!bGLN~7*SZK;!hL)PR-pPx#W=?(s;qnCL;5AdYQmrYA00gLe<avwQ4GA2TSS8HWoaq3xM99;VTX>Hwj~o)J9<~w2H-Xk&yG&9u*>D!XXf=3yk`Llgu}yJBA|>20yVA-QYvn_pa?DfV(F3-Lgux*`R1909^`Ri%9WVx%Nxa$Oi|i{Gg)BZEb8#G>8+=m^GGr7N!{$XM-NTKMQ{Ftu)*)m*64pz!>O6Sllz4$y8D~LiQxFA<xqQnXY6ksT_Aj&8o1r4t7M}1=DFFFyu6%8M@Q23&KX9fZTU)*l73VQZgW-(w$mjRv}d)jj<}%}58sdwfr39Dt(okeKkVy`0Pn?2x0f_+BofzA?>pRF{97VA9u=zYgG5{}S;eY}2NayZYuHOr!F@H0*Vun+LaN=vaA=GCS#mAbml~v`-&Jkd$lcAN=r*^^#ydlB@=+-e-*TEn5AlI&(&7W6$RWl|oTqjye{1DwqFpG%X0pWwm-&$$BRQt5xfE+ZcvU-e<LJMA_^u1f+q#vT=r9k51#5Ad`*Za;iM<l@#KrY7n;a>ucHFgB*}2r4z!{s%n`Ma*PtPr7%gEi`>fq1cP7Okx;LDt76McXH^G-rbzZ_k>e01#P80I9Lw@Pa934uVcYc-YH3*j#bZF}|{$3$%phy<j!w3q3f%hUk&7mLV9?9djuL?`NegrQ};{lLDXbk7zMZdRxB)AcR*$?osmqswv(*!yRaK8rKNiH3|v^^9P3ON}~}gJV??)GuH~kc@Y<(m%>|($sNJbnE_7Hc4MQHa1%wqmT`>8IW#lSrR5V!Vu}7uUn>S7L79FlhPW*R{OjNg|lK!1Oj6cR_1F_ze2y`#aXX<v|Gn1pY(Vu!Bal4H65ptaVK7|cgE{iN%&PdymfmUsJ!anwqYs!55EvFG}pI59a*)_2`>kAQ_}LR?fAVyQYKyM`cuF4#4ZZzGZq%~sy?sz#~q)&6T}Gb_IVG1^PS)!Cp**9ullt{Yobz+KBY_+o<miR2*Y_0%>{*LevU>D3pBqI_cDLC=5r{7#%X{YS&S=(5|f$VMH|;o=8x`qL@gEa&L!5$ZIp-8=X6KoW}iKgl`?gK&@<B79CR6t=?h*K=4Vv*Mh9xnIA=`wS}o=oB@PgJ9Y*Oy={AS<YlFcgbQ}^zAvTSp^pAqwkZ5#s2E+uO7A%jF#biZRDg<`wCCU1<yH}CPf>6>8&RDMrQCr6a^>IJ!Qn$YX!c;M^Ztyr5XZU=#;sVCTqkCDpW!GL;HtpiU#)=cUP7-x@ssM$;!00|U`?h>ABU&r@9#qr+9jN=GwKihM5*q`au=lMYBQcD0Yg8xO6xLd;vH{J&fpyh>O_KEN6lYbj-&L~cJx1m;fcU$L0Uj&*y6n{;l|fO+k-s;@jsA+U!$8X~2Y<i8B=U;rD$2`=(G%-9>J5W<xkeGM7j3OK_S9BX&qEosV~Uog9hKgIvGG{OpL?#jD22zp>7410@xGv?0VT9BAe)zd2;ci^&_O6{Ds*)P0Sp}je(qWUe3HeF(treTp?S$}+xSoNJ$pN9=_ms-j=ejK_{!$!uGB&5UiG}C<4&i}uav)fYiQd!EMKu=>*gA8uUkdQ^Pe2?5p5U>_@leI<+tXXdTOBw{*-|Z^Q)CO3)J*medv(VJF(nV4|YNpW=*8)Y({s2c7F7;T?Su@!DE?*0k4`HkaIKVL3<B|5O(W_;dZ^PhLg6V)+zf&T%CvQ$VFUBl<v_HPrt{XT4?ra=kRKayuYU9lYvNV1sKz6ho*CJjHv$~#vphO#2<yidq3*lCE_2}*u``~XuO?S1MRkNS*ar{jU>X3E_de-C4#ouqXS6p*8Dt<8Q5#<!QkQLnLA3-qSH+;2g)1&G?5$HtR+1o@`1jFP`n2(l0Qc>4Q#Waxrf4|bh*B@1xbIMv$FhDe5h4)Yx)~83b8$ePFF>zayF`5+ls8f{5<>1vB6I^dFRcm8EQVJB0pTIKthz1Dl{X?D8xwS2ePnao>uoTD$7>{B9!h?#8xIX0NKs7pY4tq&YGnhe8itnIpz3N6v(KcsVP_v?TMIyefuf=Ps<D`Iz*IP?fY4WV}$sarI^Yw{jl4{0Wm*zVE+6{knw^S1_1YEzSMd>@nH&r0KZFswsR`IOYtdp3*Of@##RETOCFn{iO?X%{FL(K$gj@|-f_vEtbhN%O|}uPnnp&!;mS>Z82!Q%P#^rXY@+j2Hggj2gRzJU`^bkp_g%p@#+%6YF^)9Ea8ca_9&u`Q5ZvGlIDue$d**{tdc~CG$p9OwSsq%=0lcR*(vhBQB@O95jU`Nrcm=F~Snx^C#`|tp*M#@2{&`G;;jJga?fAIdwm-_t7eg+Ovcs!gG6Lzzxrdfz*}rA+mk54A<XD8k1H2*WRU{C-#IdlgSkT8eV;?-r#a6y^GLp`Fnlgyq?lWG@DNK<*wW0q+eAaU(AYxOWHE@RKvqOUd61NAmD5nlN!AA;UMRz<&U5lu$@8#`j5#!}{W#EeB0w$D%UXy}Al!p!yn=tKu0z>Um+6Lc_+M5J43%m1nhKI?9p&G|aI5Fn%{-Sdc`w53mUoNqI>Q>OmCP;>q2x*Kg5(fC^#O7+=;E9N~<Icg1^o`TPW+@N4jXnZwJpzlQyz&l{%jjT{ZM9Q9qIT6Ho7t4T-YcA-<P*0$Id&ZS1t3f3Et^*ato|n<4_plY@XMORE}Y(dEBpGhV?bRHt^#_ZX1<nzQ{b?yBn+r}okQ@r1^DJ<m5%K(KI`%O>TTbwjgEK&lJA=cTqT7!{?_F^ce*zYPdFg}(ZO!aDa1<lkF@W>HGxn}lb$U3+<{{Af4Q$TX9xv07p{H@wdge|H*ka~q->*U1j4FgjmUFY3im6^F)A3+!fQmazQ7Yx$hYoDT~DJi{=6CbIB>-4lEZXqQJ*3RUL(}O8UJN>@s~@iGjPhQL}4V*=$3WRn^)_Da3#gCVz>(-I#h1{h}0hke7I$m8Dh<$xp^i5k0(aXN%CFIz0NF%382Jky;<=V)zY>_9R`S*(s-Rd7Ftto7`#)$d>=#WnU<^~Nd+y%KP(qOhGw4_$c9+4c?Az?5v1B}YeIVgQtBq;KrM%l9^0{a?-}ibGrAE|1@y7wxh>uYevd&`{B7+8*3eys%O%1iL;(`(6=tpy=L5@lBdU;AthL8tPSSC;89$4K)qhZ(+Pa;+XJ#jVU^$en#)PgF-6JdK_UMLV(ByLYhfoylNwEjMwJ36%QexlPk0;^vB?n%l){Ds}H4V9Oz#kroW25@XOcS|Sl>h#ZtUmnK7T*~YNd+wt=JW2IRUtI>SNg%k8gnc5KePJv3!_scl!~K+6(OP6qiRx9p6|EK&20xSf#<JubZf$2LO4|nTtHAA6zEaQxv{&Odvu8?b_)2y-_$G}?|}8-=#3tBB<dt9+d@40p8=DVrUOeb)w194J4q{i>!uVfl(!GKO>(`n```YX_cUl9u6Fh7_^BhIHw`@40l)<F=V0P3%h^vp#IHc?>>0prQt;1AjxQa7kFT}SKOLBN2G7B!dYdh9O5Gbs%D%ozt=kDtohzSu8Q>c4Ri3104h-%VT6hEzVJvjFP$Sw2G}_tSF-3#Dy2#aJ8M%e3JxUwx<6Hi8shxH=aFHSt1IZLKGW?Z~pU|i%$qvr@(p6XI`-rNMrN@tpWV~+^>d0SP6qonx+Z{Uutb!HcHkHvIX>=q$6%Le=W7!uN<v?-u_RRI+MaCt*nUkmfoCgOOk)&heqcaA$R%zvp2P3m<dyZKB##*k_C*yj3qI{!5BdIiKnXY+~nt2AFLu{9xu|ztyc~u_I`?-af_^3j7HveFR2JtpTLl4X!<~;uxN`L9?n$umSZ>^*0<LalGW_^;!gU;K(2z`LD=rWFtXX&9LSL~6O?xaVOus<&alt1J@1J|?=g#XZ!xZUI-(35+E-W6nS%{={t4zFnoOq1IJd8LMY>Cm<kv>Bz)ocP4Y^>&Adejyf`X0o(Hv1+CBp|aG{#oDhFm)EDgCxL0-YihT@|B=Nbu<ooNby(Tl7NhXbj6_6%FnA11`8O_DdMY!K{7ag9FapJvYIQJYPA0rr;;+J?XioBLE>XZ3_bIX;@18}nx9~9%XcZsSWZ%nhVG~Sun6pfzcqQKHtsF>67LzY5w}9Lo+(zCrh@_*GQuehB+k2<0&|>EJ-!Iwl#vgx9pO(IU2dVJ6XvdTjxjn({JVx-_d^{-}v&nbQ`foL~v$Ewv0s0!>z>B^rlrX=sGbbQWf8L?WIRQ_R1!)NwqO)ITC^R8P%$aeb$>C8M!P&44hrt#qJ9_Fqggs6fLijzrenO9)3l^@8Jfk&RfFqwYDdJgIaN3Dc+a{|6>#YjnlFL?D7)T<^@C+V@7~a}x$lY57o)lMQuP!$-*!j1h!z#pm)C7fytUOwr+6_?vOtZjliDFE{vGEW0boa!;25%)p&io&nfsTqC)GP5tjjZ<#pQyLFF2H@3s0nwVS6hdorwV&@6yfgO2i~gp6vFb$B^wuQf_P!aQ<%-R7-aEsPfa#bj`bi%<+Bj$c(HLXIm9O4#J2oJtQA=-lNL@^{;Jxv&eJHZ{}k+!1#O`S3v)J}H4_CNHUd)e)>MQh^f*=Z{cp~NJdQ?zyAPPa5VddIu22Q98vt**L7;uLL7nBgOLUv6+)&lk?0oN~x<JFfW{xlxtTVv&wsj{t>6DPvDN@63=$6~8B&lmagJUcT$Mt4Cap~5KS!vzwaVa-kdYB;?ba}`p@ag#@)~c*p4<xz}b*;}kUjr?it%~+Q6<%3;EU&twVl2kY1%O4bhSRIb$@$&L$Qto$rgSKKW-8dCs82xjWFUh5gpUn$a2~^)yYW2owUQza_(skAe;}pmc_`qbpAMk2v0tYFDkjTCDhZg&^*vH|SOS#hI&h=|5n(Rd5_l?>ql5J01CmJ8s|X{QZlW5!VL`#2#w&Gk)_L(sf?P7FQ)v9cBjcp}Da{Ef!XxAk#nS?4ai7oR(u;(=wl}BbLw;4F3H2mh(i<ub(}!~)g-SKU*e^CB%g?2KmYU(O(&AJ;@B7Lu+Tbsa`_=*lQ^9>EfG10Z2HL)7LFinVNK^?*^LjExP`QZa+G0NlQEVOCQ3~C23efAl-qFuCK4&W)U3vUJMc`#4*2tx-;GGI7&ZicbEcb;WY9;1jc~HGb*ePn^TU_e6jPc^hl4|OP$tP2d*Etf)^kTn&8(pSyd?DpK2s=|OrYc>?c6V!zVTSGi{);Y6%-2xbCi0DP_zWoAhQw0}EF}Elid<{Mo<6}Ge!uG<T>=(YGmsu9>y0yT)5piztQMY>B5MRfuvOA`2HQ>*4RmKG<U5LTXS{|#5>$5j)!uB*TO7ZTACm4{x#A<C$v{PI`@rfU`*PL^`*o4hWVcxt+<zHxsX;zxT!(Ug01sHk_tl9`N3Lp{JKj$dT6w-LoRe=@H3R=J9vyg+!~^l-co=B`LVG%So{0kJ^t{;Rj8vF@9}}t3-Rfm@V`zO7llWYx<YaaS5hq1QWd$L4itH(c;6@kpI<t|-(}^*nbOmt5_$V0C_jd<F7X0`}xLzoX5RWD@WV%=2OBp115PwCyYndj<9lmvG=dt}CcFkoWfeh}6dD|;*wfcr*k!wP$#(Nx>Abk?5_2(9Rd*&$0x!>vF%4Z$0j>ivhfk8t%1|k$9QXEE?+q&N}LqGw!i8B9Oi=T{|bju#QQ{$u2r&BnKYaO;k&U+Ea*kOBr-*8AP<*z9il}EqQ70d*fn+2v;PPwJnnSG?MWU^#fmR;`^FExv6ujC0>C?Gr+4tUNH6IxM}G@jci{KDjv_Kr~>%)r(F#T<%}VnsJl#xu)6%fXih4`?K>+H!)Y*4&riH6-GgdmqurpfAI36iuH0LAFGHrz~F>*J-OfyA^{YQtWPlcXC~&oI(zSR_&0UlQP}c)^frvhyb;801@{JV<WqrcNnnuwYfH^2q+`SAW^5Jloa*c6r6R&kpb@NF&QK<4OTdqNgK2m_PfXn4cwIcd}?8Y^UEC04_VBD_It1oD3dZ?&CW&D?M>OH`U-1$t>ZaDI2oW7s<++R(kE!!<o%WXzN>npS(<l%%kY2rxt!4wR5=v=B%bOmBJMz{O9J(v<F}KeOt-j~fZ9c}n)>p>Rx%K;C1IG*N78}NqiiYLG&46P1+Wo_^-N616lQOkSvJYlT9O4LrtU=3Eq8sEW@HQ~jx<{xOe0y;$1L6ht!YeTM5?voxSh_vCO^6XPmT-7s#2ee12{Xn829c72QtL<;1JrXkjKr57+vz1IPRNkpY6nmsoqSb4AL`~mk5l|b+V4FD<(*p8=gOmtYr^xbuku7YD*b{U!=sK2A&UzG(x1@%o|m;g2T~a=J<O(y|`!hNj(E{)S&QwdQOMT7eA%QG2Loo_=3z&of0<120%{W^b4D5_LvH7?8=kB+CdF-RZX@)maxWvl@#FwAUEF!STVIu>`S$zlNB`scARazssS-MAH%!en<M;VmM#mwep*-Au(qZB28<Xe+r)UVHHInY4*GD<WIr4AW%`Ck*n0ZFtU+Yjb9ldO5J|`QHk?nESQqhw`Rq*cw=~69XWL*2lI#zm!)eWfi8S+2`(;hhFfHWq!fb3lGJ?e9u+07uwUt|HE!z$TK#`C?n_BVgnSJ8Fww7UDUp%*e^TC8SNmsQi<dLm;pc-feYT^h4q9x3nn~tSPiXclCeGlj<wcWQ((Pa@Br-}SEclbl=BQM?~nb+Q(TiY=~oNrH`5N2reRlY#sP=I{<?k!OA_8U)ZpFcK$dKiFBsvP^sqz_KAnUB{Vzs_S`U$olIsVxtuc-!vbgz|7ST5mj-Vf;HK4nT)KyT;(S&!`ARPTUC`#MCj52fweo!e-Tjn%x(8DLzwW1W=O^8Yj0FgV}^{EnmXzUMmyi6+PixOWQrC2vtV62!@#ModEy`x|9MyS;rI+#DRGCI9$uV!PapT481gdr$Hcd6;(ST-Am+>*o0X;J0K0^)cgp7{#dzfP*-iVs$zm>-p2hQZM>g=Qi2BWpi;X4J!hm;y>c*pXQzQb=a?Bk?=EujA_Ck%&_APk<Qy&WSR81v4|aB9w%APo6z|@p^C9%!HqH^8U$T)fF{BD&m#~GODqDjSOib60o3nmp^2#>d?#z;NsXUp$HGa%f2#D{DZg=|TfPKj{KGo^vEa>~I&M>Z~{#e$B-<fLY&%MX`DO+VS<?)Z=6n!bkQjx9Jc>NQVvreGl5PT$-p}_d(w`@(eGXG7;ax8xua3P|GrRY(?e~GUtr($gRj@sy!5*+oSjhIvKS5_P+Tx4&=HXk1s@{li7IldHYQQP}dyD3>GSB=Q~<xJS-d|I6x(sMM6ur+sqz=E$6u>qfgRj=1ZYN;7UQUkf)L(k->upOyjJ-Pt&3_K!JqMtc&BHm+>QMf6<^rFp_sX`w05D%IX3W<1F=1*vPu-$LHJSYeE@&xgXIaYZ-uj;M9rXiuYKyNv1{6ns=1twrexun(Q4kBWl4{<2k!K!rXtZ>In{7+Kh(}MBrx?_$MJ0$|6DVBqpv!S%0ltEBmMmVaCh;UrUGv}bIo*|<DvSZ9qgK?{`F*To)S4~?;o@*{si)!grl*;o^t*>ebQs$BxF33#@GRcy$+Ja&Ml(dtJ93t28P*_ymekKm4?WBWZ@p?SW_#F(^VbsNWK@e4QW6tuoab!B{rB<KY<EvhlHZnzSyh7yGQOFRm@qSHCDQN}L{34Z}qSU0NzJ8xcZQ6%D>b*O0TqAPIw!FDi8PDF^;;qOL#7!Z<n`e~#_o~V+0ieHq?c48m2W<&2bG@Y+)EmHvT<F8RP>u89tg8^5j5%4GIJ2xxrC`icU**qye9;RE3QOWo3iyJX#{dZi7CL22QAn25N*;pNbq*h#^QJ=nqp;VzZIW}lOz2ZDmy9XY?FqN`Gu}tEEvoeFlNl<lDeoyx)<v7WGm?g(OF@fW-6Y6|{hI`I1R{Mm=1x9d^nR6FLn)gg4T_J7lA9e=W=wm{PUnc5FLsIC=hc$Yes?Gn%c74tM|YKDS@|0I=cRP#LXdnJn#nLw1c^541oHC7OHF0qw!_h3abzZH@**<SjnuR_WxxoN;dMqvo)N!NmbQxvR8KV4b`;2nEOVAcKZ5J`KQ;GEyjqen@%T6IsQaoDuCs`vCipLhd93xTdFbrs4zfH>Z#v4Rrfihj8|zEpfsO0)@I?+SM;2%I{j>%%vWjsu^na=(hv04#@;TL1da<y~_N2|wyhOqkUS_J-9iypJKo{9GEnr~o{segsQvi6Pn-<!}ht{k#4W7IPeYLD?$Uw%EdFCwUO*mP|)4^Z?jneq723EI|a={-+{aEwhU}>_%Ugh5ShWfmpL?YRw*(+Bb2Hb3!qz=NF2Bt-U4#!WaE$o64NZ^5E{Qn<OFJNC}UI2Tzyd9`<?%}}-!jPOZy~!pu;sC#XxB3q8kVSh4cyWDL<vA`E6LG$0v01QH`nuQa=5L}z=llJOc5Kn%esMMju5;1)fd%VmeVJ@H5NFmmBN-_6(N6=B<7I?O>G&XW6uRC=G#vWk#8yGCDNEd~0FaEKfZkTFOJ!hjf8NPG^ix|IL?Y}KO?#{UCKb#AXQls|tGaGyR$(JZ?a!>XF_9#f6VJYu3OU-MV;a~`+L?`Gn9>B~i3^6YD(;_CvKSbn-ryZouBr(M++M3ZiU=Dnsi}{OLM@Nu!H<A3t3-y2&{1qEnT3{3<FjHXD(L9N@_~YT3~GcxEl=M8_ws+V604Ri#GClE)6zuU2cmTXec<j9=|}}0G3oPHQ@Vz27`PGrY^}0p)XcONi<k7UB&!@5kic;;8aS)0kcXRUBeKHEOzXM(W(-)(S~o<Aoo<Lt?ORZ{wu+xfhN5e+<;1(hh1wDeq_xYVd}WYNP5A-xyoB@ZsSG)RR2(+itM}YDz|ya0>$u#9Hv)5Kbh;VY{B$6MFa&S-P++a~ZF|Ck*+;wQVD3igE4)5pQU~FV9nCG;V~amDaHL}*)mZH9t0G6wk{i;YBKEAhxtVUxR8=*v5Yo0dMU)uR1}J&L8rhicl-%Zx3v7f2%9PxLF(N@=Ew!B@10<p1>=nS-F-AAD_d1P|$Sf$qjblNH%=};5Yy~0~e}sQGthhV3&4fPrw~gg*+fNJ4JlaXP6E{9il2q^`c>-XFg+czo9A>7piPm^o31&dUb`Q;Jus<b?+#qpcH|`HVBtM$axC`BzFZhfHY0%M6FX;w@UhOiDW%&@r<2Lo5f{)IUJVG(NbA=(?L!-HpknW@njM|E$aU=e#th^Jdfpy%3dNS$p|1@pqc^PZA1dbvh0mt7OL*+{n$gK#_v^eE%c>z-`KX6d@Ui?!&VOD~vViMuCl(7g822ekU=z+>V6oMfLrLur?2Jyl(YK^7xie{X$kO$`HBp7pZDP?u!wjo%1vM>I4Fex%=U>32I&*NUiMWN~E=@r-lxIC-q-Aa{K9Att^v-1|WH<zG*JR3C~gZIy9b^}M2r1}eczR@q~ZZR*C)MQ@VhG%{$^H@SpM`9jiQM|;mO$P6$NKN%p!4d{sonC$Qid{jnm=<qsL{pK?td<GJ!CL4tSbo{E_SO#f^F7CJq!WP#yutKkn58J2inZ&8t)3q0TI?RGLE?0q-@t7fJZ}lRsXmy(RC=^JiB&`90HAmudzZ!s!7J{~FWlbz8w3Lwc8FvWY(#r;sQ#|5087edR2?wizJLs#k+4~kVf1}U>s9>%*_yv(85%2PlvEWF_v0X$>j4J%Jh;|?oIi6NuESRRen}Q%R;;29&^tY9lttg(eHW4PUuH}yt++?VI8m{_4yb?;C*O|<7QU(*Xq42>ZPlXA-~swaYsNO9f+aN9)v64l=W@wgM%LZ@RkU5BIixo+W)FhPBPyTFSW}3}sp2llBpgnZvD?x!*UbQ4VN83Zet+MHD3fwAfkiU%LN=F5qs?ofbX7j4YmS+z7>oxTCnZ8tu|eKCoF%Nb($j^rjl=XE$((4EHn!R<H;(h{@XD=D9p3S<N^**o7IphMi8wlH`<Z@pF`k3va(3)Qv9T(J6~23eSGpaNyOuYI=Bdl92((Lj9gKTf(Bt7~$A)pciFi;U6Lt;}KLH~=8TGHZDZUpxzc$m0AHriVV}kR&YJ*dbU{LG2E7P6ib6IH$q0mHZPBkXVuHnupH;XMKaj!>H=Hd)z3#L^D8}AWfRwNIPy8pG|Qvw8%$H7@+EnhNq%py9Dk#NpXwGb^`_ls49m3=X4&@qjhuxsNswF%h~(QB>8{!z0e4a#D%fjEz0IsM#xAsH|H70rW~MjigWd3l(ai$zof2UlaO-mmtmyC}{pmGn$kBJo@9jRc3!J>z2l-H&l8@3y82;zs)BM6$PAgFbss8FI6@CY_jyq0~&A0#428^&Hh;VGMO2Y+Q*z5MA`Cc#ZXPJ~Na@K&)y&>%V?(CTajo!e<4U{5n0$UbW8P*_T;Aubn=qlwCDykeKEZbrJMM1YC`P^uKkY0mM`v_Ez1LymF1b1Q`Sf0I_@Q&3?=!Mm*(*Tv82^jshXWOo)DH@;f?_sF`dgUrC0c%}{=-V5zXfT!Po(WFuLN+aqE^HAYy@|5T18wOGf9P-*NqB0^}b5W&&pNT$2KIkUQ*KYkBAAd;^P8+x4(?|~G^=%>KDFs3!DS0b(cg#ixbQt&`hFkC}j)t`QB1;@K1oN@IBp!n6nz6<uHV3-}X+|xGfmaL_((-j<th!|H@`au?xa3~2y32Fo`#;B)(&(fzBgMcGyut81#0vVuK*LI>&S$AtY02eaRo(?M~_#?t8ky)2B|0%$B@ow2lKC-VT{+UQ;u;&|gW7V!Ux3c2^m(w3<6Z{Xt(auc{nxm-=d|<6YfMCxD@?gx~;35*+CM^c%nxB;Qj==W;YK_glkq~MbVCeM^dBo!>{AU^xExM|ML=Bd_DK7JWYuPi2*C(*ny^xoxV*)f0Q5%VV0_5CmE0r!|jqP2eIQjVBklLSg8HuWQj6TRGCgb88C*#i>s7WSHotsNXt`qjPyBT!1DKj@_GKnKNG;Z)|BZeqC(b1J&RT9nWrDzwY=f|q+MII#2Do{|X*sBn$@&Y{1hwuf(<#LXxaz%Nx%dBjW1TY0SK<w^<j?*hb!Iol3s%z0HjhqTrhb2GX4*L_$2s6^5T_kreD-W^zHWRm1<S6eLg&-Cd7kTCiVR@%$MiMNj;0vw1$3}yHHT19gG;Q`f<Rgyw<a7wgsKtHxJllJY5iqtDH2+7be%IwMWcTabFvG2^7A-RF!72@>%h}Y7dNbEsA%MM7e)7j9lx)!%y}WBEcY`eROzN3K%&=DxaM=X8ue{br;uV$XzoJ739+5DC0Ln_enub(47~FCd9Tgb|TqgGVPZ)B0AkHXdC@I)U4lytIZ6&<hFv+d6GV{ydD!*~LOz+f>76u}Efl)n-j+qgstm~;eoyoD6aoK_(hTD6UiJLo;e8G{+G;-6bYFvz?1Vf+e8E^UlQ6g~~`#^jGzU}xXzo$T;gZdIM<L_Z`6u&^&)W6qsujH`}_DYh;B*{>wa-Op!6n~D#IAkVUbw^dMo$+1o?%t?D<U#`|@N(>`whlt|it7+ZCj;Ysgb`Cx1`nzEH=UI&k_4BpH3ByE<~O=F+r=-#%DUMxf~xp(!3J~$DLu@C6@0`8%j`TePFa72s@S-JfNAFypP(8zzVWjuA*O%>6Oi~3+uxYEGAu)N;ZZ>E)LkLWxa3RuMsh9QV6zlBcR~V}@!{NP1HS0986{6JYkC&tdHATYB~_^BUR)67`lv_kfQ+oi7C~z9JI^!}qtav^8Jjf{ZGj4cIUdcG;)iV6>qXQqiED6M$keiD5Rp#VMu9`k>o-&%OJPG{yQ4zxn6u?Bn8@<c$@S}&^6G5*JRw`O3?0F$_)k&H$Xd*W%$KfW1#UOrN}DbfqY}=m3pP5p{;W}+mDL*$jP3s6&4)#_qR^kcEZQx?qf@7fJ(Jor`go*MsuIHytzAphy)L=8=H=lpRH5|quJn#Z4=)boxM8+;4-T<*cqYqcsvrXptJ_iP|G*&90D4u?^Cnx&RiYYR^yw1dceb&hzl0oTF4hHE3*dkh#%t^TKHe6F`@V;pEmkI<x)ZP9MrFd}<ZqKeaSik!iXVL%{4att-^;^0bbW3fL&K(b90Ari!FR0w;;@N$3k_8+N(i&AzG1967TR?o#FJdAU6%#xf=DH<%c<jR7~#GsiBYIFhL<7r%nv%vn+{@(qc;gRtB}Tu9qc^|c4GT``nyo~(MZkM`l^{hs=CHJuay^t(60m8$)vh>q!UM77*}57-xY|k;9lI+hbhfCx#fZjvSLeR=Tl|Pc|OZ5QDGjb+&}>s6f7dQ*)I=<!+qp6#%jGV9c2HZ#P6l46PA+Tx^K}4`Xp{qZ!T)N-M*`7O>uy`$3LHF(YzmxyfGGNi=;*zZ6ZvYYMA6sfLfN`hh>5+z)uwO)xdoAF1vTZ+h&3XTDGm0tuMY9di2wjIA%hlt@Oe*1J{*22rMYPR7sba43<D_&>vILR6%h{gtEzN=^&8>{*wxk!WO-)j7}vrhVFjeN|ngatYCQjBJldcu_tW`!>*<<V#qZan?3m1It=nC`vH?#wjsCW69}QZbR^o(Iw-HW;a}*o5jRmX;DjObo0|3ZC&uPnV4Yie?n*^c33^~^0J(K995SXYmz%XGt!&&QFu2o?O)V>x@X@IQAHgV*l@ztg4lUfPIF$>{?(;C5@Ev>ZQkQzyl#-<xHIJoQ4PaLWLBFAY&oYEn6O{^Fpm5y{>kHk0bnH7D1L8dgy$)iqgu54XH-YnHKdkwNV8+9~w6yA$Y$C_@^R(|+_V4eV+OwVaLF*C(z0wH*`>QYYN>X3mp?aCtJY5Xn6183i#r_(e(4p?qp;%BcV_MR<@7B1udo+&{rN<T6h`)!aiVR;~)9Y^eU=#8eWf|Ix_)i0zRx;0HiEzyNY-l^V!Ax1>`JTG0c9R={`t;3!LaeM0`!#B_pgcPZ(}E^LE#<p7S~bQKfATMTg7%6Mt5F|0v0lQjh@;D$MRW|`HZb46EXQEaN_Q?70mDrx%}bd3sf)|i`*t3$!aX;0%?v4_1X*)B+odh7j2ewoS31xX-Cy-!vY&+}je`RDgrN4*5Oun-Rg`SN_acD(w1%F7pop|6#g`L3^_L~>y5FmqW8)N1{#Cy#*FrTb(?w2xnFZYEAmS{|LiJ`2mS<O3#pywwg+4R34tuf^U3R`ta8tHmGwFXs{wWIqNhw@t{7aD#2^_NH+djfH!jPtIccbNpwz<=?8PO~8x^#`S`xp&A-dtSDI`1R%m^LMJ68Niz3UpdX4V-|}%`grZrx=6)6#|u7swN}n82_j=aP5LGjqCkCbEO_+Jk4T}{3~mRi~XJF>pLkEq_e&Us=KS+%<)YHS%3$UfoESBOR$3C;x9O^ycq?(mjLWz#tS5QB&ss*4Uq<AUH8HHNofU7xP_^}fxIYZxAU=WB7zdXc^6Mdy<ah3cZ8=HIEDZslolJW3GN}EGDET9r`~(C0`RnoFX78+yh-D)38-(JH3<%bz`Di$X|tFbM?MaP-7{G~F0nEstJb6l^g(XlON_XV<$}iXDdB1+Z4ae(ysRo<Fsi^sNuu>rDy8pn;KvMJwG~2*BF5U&@%5nCz7Sd^r{^R%rPIB?{Pz=?&*dv(y7_<}%};X`gSL;Crt#nwg7rO1sJS;y)%I^GpxD@-cnr0Ij^%v*y*gvp;cuTv9825$E~$7+37*?K+fHEzc@G*?`OxmT7G<AD;}zEzz@z+*`#v!p)S6WOdi(75*ml=1==J>ER3i?JJ0}5(-lj3!(>Pz3{3i;V0Qc!T20rLGM;CowAT7S$vCP>1<&Sh;uW`W-^H)e9cm>gP9SDvPWF6GI_;Lvkf+6!))XQZZUodUFf;1;mo{a=+DB32y!8j3IS%c#ku?E3#6tg(O(h6c%wCGZ1bgjM>rlZjq0Fcb?ju70or+UHlq|I-2#T6v8)6Et9d}1aj2bS#^9t69KV7(jVSBVz8VdhoN1*gSQ%7PTrQb?WxMpAeq|6o?2dL5AaP;T>`6GH4G%H_1#b*|cl9GhV65y+qsQKPQ|mC`fAvr_l*2)a~G#P@1q-lw}Y;vc1-x~e8pyUlwtvv@ZFUoh5e(9B=t9=wA05?{KRTQ{oKM$(W9XSy7`e}3a;EfFx$8MKC_tv45;T9Jxa1DgaKi#t%QE;Ue(%H@v)t7ix99J8Z5(DJJA*#~EEH=uk*IM4G-;#`mJtV_*H8Bo2x&$p~)f*D*f1kLR%8vDE5sVCu#0v&+e`_za_5HZ;}qfs=Ya=UD*x6tR{SB>?(Q0PT69Mz5M<P0t0#E*N7E@K{x-4jJO9ppUCuLBd)3D}PPS?;3cZs}UjR{x-lFi~w%7EAiaMKTbuIac;#1%#SFw`e_;Go-IFlXt=9<Q*z#px*yV*=WbmBAxf^R{-jI1JV#wdz(CPk_>5(=|QmI*+0Lc&7`g~<}$fm+bJd`zqTC$rQ7r(*xAcy&=8*JwKenMr=bHEmKFg#p^SDboa#H(plhvT&T9F(CY4*$`<*W<BqKk+a}u!3pp9!O|Iii+H{-`0MsKez5G^L_(hPfwJ|#VDBSPuC#%g;#nZc~Pvxg)q)@->dsC8^%5>|m+kR+DH*6?05pdiIIL;dLDg_%#0jJVx{R6SmW2WQ$2c9O4=*4W_}&BmYDY!UC6LMG+gVD00?#^PAUI&e&3I)X;hHP>yYp_Ov6EdM*I_OBnzPSPdox}%cpY#W!;Is$fS>ni{1JCCaf9?bu7;?2*iUPV<kW<#+7Wnm|8MRxD}5>@o<*iyuge*0%hUU8?yDTkYViuCj$9rVD?ZLPXO<A$&HS1pPcv*(RdGo+fbxRdE_LRvvew_aDq*Zl9QRmqZZcN}&|(YsZ6c%zici2Bo-`2$WOvm{RmE<@!fcm^p<;2*3RN+;3PDe^)qSyfHtc1B0UY6w9+TJ__*!J)`;Eo>oiQ6k)w5Y*#Fcuqc752&w#-J59x$D{4%MJtr0xi{b`y7_gO009nh)-UAkKZZ=nk%qcz-jS!~07@f=`T+aJv3iJw$L3<zS_1@(yYOszX7dTI)N3E^J2{T^fjWq(y3%vAtD=hF(1w(MQ5y`QEr;ut5o_f%*b^4HbanO0+YojmkJ$Wf>othM4TjKTKe$nV`}N(0TPZyFBzk>U1wMnPUts=X>ty}>d-@Uh97N${^ZNccGyHM4=wEv5FB<6%eg$HmDjOPo+Bue5{|n~|A(1s;gM=-06%woT>tu?T53W(^G%+M<Ym5SUX!KZF{}myA5xIojmN_2V$8`7Q0u^VbWhy`+R@i42(SVbUp(P>^dr|0M<MppY;x*7edjyLCQX^32u;j}f8or&|<;9xSzc>=mojHD|sB_&4kyk$(dz%0;Xn)@{Z<dtG)2#y~RL&}tZG=v;0NZ5ZkLSdlL*(6rcEsI<<Z0Vui(^`;3c^I`v1F{U1F0Rp*l`KurzXd{HcgAEs*sUSNB4$q#_C?Y<_rQMfgGWBZy-ywkAI+nKyik#Jl-S_zo1Vv(gQ4I!Pi@lVC~Ws36nLdjFPEfaI~T=D`ZB<Zqho^x=Q`dX%u8bi~Fv-`UXf+&=xQQJm)}ITO!84mGsKpll6{;`1N<X!~t<)JaL#O>6ZHPWppk2#ft`g+MM1AF|MM~8wLhA7q}?lI34dpN5MYp1<HN_QE=Q*S*8q8tHIE7+j?lBG{AYi=sf1!&rzjgl@aax%S||W`u3^5#g`~sVj8XoIWB@EX{|?~0M+|PhWfVukzl+g6;6NL|D_Dik3DG4O>q-jHuqB04Jg!fV{>30C$v<0X;HzXkO^Kwhf%Zc;>NZ({^ec3P?8Rn28%AkHBrc3Q<w#^$NKolKp@*Mu3kxRvTgHrXDmIw-!15Gdry-wm&2Wovs1K(OPZ2tbFBW?=}cAJ_e#>Wp?Tr`R<gVL%6S380GlL5(DDN`Clt6Lw|LLkbP>gEqm?jTFz$y?T2Q<bUxmvzb*Ij6$_qu%n_dZ3K1S(+GAbrl|Hjq4p*Wc10-hHd@bnDT4gqx*FjR0L#2fM5G4nml*a=G>r2|l53~z6m@|A6DbMXYLjknlBJH!GtrRHmq;0p)Z?Cnut9+RI{K+B)2gy4!BXTmK})JXve1+L$GQuW*#CM@4&T%q&<EvkMvBC#?bIWAX46McH)E_BhTsK1nD&siC@PZn}INF>qMXD8ZJ_AJ8^^qZRv9Qvws9<$i_chJ&+H)?7Q8pF144i%Hu(X#4{)xm4|Xhzs)ET$lpm>mkL4vPCq%B7HWWZ;aWjf#`o8y($NNu-a**WST!g&}(X7)SXU+M17WaC9giOcBx+yut6H)y(-a-RLs!s@vorpx!L7pA2N<J+(uau&JtyajK=Ex~Nz)=#k5W2h_0iZOb(5gHxj&;{~QOKpy!*XJ<&O&qVRl&Ecxcn-5@WIPuU``KGT!23k49un`ZbaYy(I3)iB~Sbx`5<$q*cFn*+Gcjtm&8|%cb#&^g2u8@bGC0S09dKr+_0sA#D0)>n}Oi=o>Qfdk<@_0-3b4aAjgG5dU#vm*AH~euxy%w-|Ok)}RdlE*O1f}bBNQn7~`MF$o+)!4&FXCBeyY?#T>b-Nm#{<R_iy0X*;C>}Z_72R{-|u6t+sAF8tIbK9{?7nJBi8ojsiLM~%~%gW<KVtNDF9(ygX@g;3Ym<A^K+oSRD_V@Ldq-3dAbq`*je$4Qo0;sgNU>OB@PlAgM*T3z~6d^SQBHKbi8ACVpKCV7N#3W*)2<neS_%}Dtt$y4_0U*iwNR}R!tutF-!<VZ<sN+Vf`8`Y)p=Dj~ex&at^^RRK3eua;RDpxvrWzTQ9S5WuZ#yOa<S`9_}QA9>(NMO<;wh==e=@5pN<ayF)#u#CEnEm6;|xfCp7NJS`|4C0RU0o$WTt1pNhDwA4@a=VmHjz~0!X=s$UJR$(HrC0f4-ZiV<KvXt;+%*6DdPAX`O-%sF!m7ZD;xDYs?>pUVqk?yDaGH9}cJgI`}B>3)?2hoRepxGf7Op1Q1wymf#SJd@$M<ZiLhbD1?E>erB?Z#R_JZW?*v?wKve&ugr2V3I3^C9BaVt@rK%ZF+QfsQK9Xq&GE?Ss>R0?&#p|G#%zGqtQqcKmrtOwaK>1_d@?pTTeKsR_>Jd}w!u_YH*e2V3Z8ktmD~xQbhdS&^dkv{LJ#NRgP^05D<(^H=JrQh>?A3(FnkmQevOp~X#2!ZaCP*Mv6*%3ovF$toy2Aa>+oe<|!MlR$0AFDr3;x(^xZJX8ExIc|t81vZq_8+pMv_|`T8Tc?2f)`b1)>_!EZ^c{bltb8Bw;s>j|$e@dF0RKJ%*eoi#@A+()^=wffC^UR`$2<%ZrlZNZCT6eCX9)Hpt6W^**S>F?k#l5rcQ|0OYr4=0m<o1qXvOC)p;p`lHw&L}+TG~=honpAz!w(TT}|om+L$7?39!o!_3G@VPKPjR(k>{%Do^Saga{XKci7i1^QQ=_9g4Ip_*dBZrQrqqf_)&Ym<MOeI>dk8q8ENe<Uad^Pr3D&OBx@M2tw}dUHkDW(deGv3zsw<XHW}hi~<cc5-ii|ST8iVymL06U6AKG|JqgBn9WzS3e~l1ll5tfaZ*+_j%I=D{$c)6<X`e*bkYBpQ=v=sP0Wk|{zB3M?5B&z=B(P<mx?`T>R%z&$_^Oz)Ebh{kcalQ$e?}oRJ+5363zOI3BwpjMF-V5;!9YFzBZ%Jw5nNXivIM@{UBn1)zit+!2}L&qL921Nq%?2Z?3yoq1I_<_8M$u?FcqG>Yq@Qgmobk#!HMb0c0EDHGph=-v#TYIJwiR&HzI^Xg;^=2h7>u<3}0Zu#N{mtZ@!z7_Tq=>B~*loZ#VOtB<(74%uYYjL;_Tucv<n-AUButTPIm=K^4Rvh6%~4B1C_`iU)Q9X-VFqiMcG=n(|!U?{P&(%vsieg8)d_S8a}XTszxC8y%Ofvwb6D;wBfzfnQ_7^WTZhHBL@3k%opQr4c|rBJTjnTwoTh%S{tgFcoC+H-W3;kFX&S%>-lGMaWOVhpgcl{^G|n}=v4v01geh=!6F8du*JW4(P5<ZKEDec%KFz4Qe@L3x8f&|mDHlBqy3Txx;u9gdlZbX;+OeXKeJX+&ap#e$X-5!N))dtWQ)xX{Sk=nNKGww)GQ{#MO_sb~Zzx}X}LF-O1Y(D9gUeH1=lr`v6^`1*vYX}yT-=8lG@RLQcx8=_4=-ht^(98VC<7^K;+?5u3N=&RMm=UW5V^dwboPc;yOZbbmVT3N=-qfFjHJs$3Ff@<VvrGOVfivQSwG(*W5ZgOCl8{@-YU;o8B?qw^kU;Dt|ag`33=i7KvJ2}ZsfdH*H%Oj*4TC<C<=B+?et>3b{PMrZgEO-6>wK~rwQ7HNjK5EtP|L(Oj67SmLhos`8pqiLQxr6(`t55dA;WCA+!a$$c9%x#AsH)gtLZiqr(LqIt?R}Ve!m^emI8IJjZ?_rJ&#s6s;Ng<+F=T&;tA%8?=iE_qhlvhFrMO~5f3jcHu&5POELAO!oMm(GCJ2R1YhzYNbXq+~Ivt8>$cL_#iO=6ht}N{mD*5wk0&dsd%$qwu6OyXCj%Bv<Aa9o4b!rEBB9_}*igLQ-c-x97Z3|ZCQO|=0cQ1x>^^j;pYSg0vtkmoE&TGM&Tk1g6zi>4T6dTD3MI?5}kuFh2qI@?y4`{C3q0f7*QAbwu05^RSmO<2AlINotDfN_V*rPyuGAup;K<eQD&R2w32i-mOF>b6s6N{F34&@+(ImKW`>=VEX0n~JOOD_wBA~3?2M(3|~#OAuB7kAf3=9(rMk=9sZO<kR|C5Kte0a<d<_DQbLqK69Y+-IYYrS`WD5ygvz4k}I14_(#8p=fcw{D^xvVJ7g%UuKWuX5`Snl>@>_{!UJ5Rb5?rZsN*Bg7^rJcWIA95lnO?+gfLMqA6E3F(i*ccQ8>(aXd@baUITH5Fk7izMWC4TBeqS;<$0}N(?Fl*>HUBpN%6kuglqE41~H8j+2rm&83|<uDL*I>Q!LX^yucjnqyHf6gGmXV$?{$x$svyl;@vMS7z)g0y_&Zu%;7vymI#t*w}N#R%@qt;3NeKpVV$E3m=Q<<(6Ni!tE|6`5wkpLA-73f3t)HN<0}d@EsdMJ5(cKX{?vui9`xySbJh5K9+3_e-4ICb<)$WNYYGoK#~<!BNsB15^=_yXd1pS$&7Dcrz$%z*u4p!Nd9HFNns0v^PN491)d(uw;Hb)+Hcb=B7#orAd@}J@q8qb&)t+<AA8x2t&!MAT10hfGbs%(Us&v5HhW32#j3WRueiBG#6$+TKg19o_W~tKHf!t}gDEbp&I6Fh1EELrx`&&3oi+IPr9)2T{TuGWuYGEg89PuXydp`uhm!rA<{=?MW3}<q^2b)rYIpLVfHnQu>@Z)y`VJQn+8-3F4}QOI<HheIK?vHoByGL?hJ4)@-Mjea(}y?m8+U4FXby2!OGpL?(z?25_VXY^Jc04Tap-&n6JloJ(f<o>Nw#%PNbru(5~6`b({{-9jnm_FyvuU;l1ASEHA;0CZoQ83)BU2e>dEfXrQ{v<eX*UiOd6+<!Mp$`dk93u&`xbVu<fgg7uUxZC}=g*$w#gIm(6o}lD5^kX}Y;>cRN*AzJd9N{WJA!H^|$|6-9_D$728nu99(fO!k8S`I+P>LnC$Uzr@x7vqpPrF=jA{#STL5B+)|$zYt^WfqR>M7@A3J;Yq-Koq(F{ieZp(oQgJYQook-vo7y|Jh-cW{4`<iQrnnUWwYhvOL69Y7_E(IO|CH~3Aps}YCmDplW%&MQV;mm+lekHBA<|e5|0CqEFB!Xli+J=z12I6RXVSdK5;Q51kpd<?RGK-VKjdZQqWt}dK{y@xs>fJ&G8+t4fV3t0yxIZ8Z@IdAq3s&M9B@GP{Cc9uFKs&kCRf0f=L+g{oVvjd+XyEm6Ytjh7BU`bcoYN%0rT4Hdta2w;tji+lexRQb}#o<xI{?VUH$E=HQ%u@_PX9O729TtwS?Rb0sS#1EDAvY&fVYg3)cKu`YXF0mweEwifwOu%O5&fnRu0Pz!9DET{CqI)4=tX5%5SUc~!UVL0im3Y7M%^U>6@oJHaMm{@m(yWwz4-NdN#b%xxYaf`+-i8iN4FX^tRf8%7#j#(Yui+bg#_3htelygk=$bL85OUvpKTAoQkm^V>$UL)Zg{{(+o>QP@J<+E1_9Bj%*Rwll&5s%YwI4I-7AY~r)gOh^Xbo2e)Jd$~stSlVhhlo-E@LGMDwiD-1IlD}tEs-xJd&H&Z#?5>w#-g?MN8Y7IL2%Q#yLtTYHQ)9lY9^Xnv<DJi7U;f9oPhe*n}Dj`Y^9w7#s&i?cd$~lLG6^hYB;!Fl5lf-N_yt%&GfkM%n-+Ckn%{H`wQqI&8mdWh{?F@C1qnsviuR_o!ZiDC4M6P%PR!q5ZBX3R3&oy^^S7Y11$gN9b*yC6M80cs*g-v#Y+8ez<i!$adHsgJt_4yw|yvC!C8hAIMp5T=hKShy92*)*!Dv2c=qW^)b$3@C+hxcrO88qwTKiDNOMm-w_q6rcC)`ZBAl7@{=ah!;@jlJz|2$qwd!1m^`H4ND;3lvZ#ok<M#C-1oe1UCZBk?9O-4|TmTaP^xnm?p<lo%A1mL5(HjJh<W%m=wA*UJ5vS!Kg5G@c2?rp)}jeFDCOOb}}bTweKATH6c6bbJo&r*#H8mJ%P!02L1d(97?kZf?nS`b%Fk}_{2*~1_C3YoF})INfQq|E(}B~Hi1Rs+ZN8Qh{3Ky{*}&8E400hh&gfuF3MBG;gSqghuGa=Ofy1!=+gvPr6M9_!rzZgZHiRoNp1p{hB%PK%4W<t{6RLQ8`&eh}@8BfNnHFFu3bXH|U(V+=<u`8w?Xk9r+|XYk*^@ImY%#$2LP>Q&7*VK!!xLpW~laG{1lk%w&tNNM^63cX&U13A|X^Jpruh#bFU9?eCg>Ozd(cGVm}b5^{6gksk8l)gd*Sh>@6gqRvW>-x^LD^A-`NX##a%V#Zl6Qsft6S0X_&6aD4@rSTsfIhsMLQ=#elQf$PRz9ps_c~LbksiUYdx~UoD%s1?NY%QFca(ntb;f)@Z%B{jiXz_>qc3RGa13zqMN*mMZZh*H8uD!D^~eS@XkDxPF9=V8b4KKUJn<;%eJdg_HWl)#y(-XS(PpeeC+ssT?=Bmxx9ZW|zMbVQhHoGrv-uc@pPg+x!C_9La9NOE|9>Ynv48?AmWIMXGz7xR8i8Gz%W}-=5t9-@wnLm+*qmbN<9gbnb6(f6`8rTKS`<OvM9D<gtfu^;h1fPCy_np?0w1SU14vrXhp=VuMqgS6!p(_}h~C9X#kZvO0Xi834_tqoQEq&9FyrXW(DN!58v_^oeMUB?c;z^WN+y=xVyyL3lCDd?uG1X5yl!)&BlJ`My0A3Jclb8+QP!{ro7D#=D_olhlfGxUGOy>p2+$Vp?bSCt&mX({0z=Ia3w5@vBiLa*CN=3!(!!=JJ%|ISL0`uZW7G4zu|l?f0MfAtME1%O#%gB#B1f#xC9|vhHZlnS4X9r<%+J~H-;mZrlFiNC_%*?HK|=~3r<*u==SRR{K<-~VFjTAM37us}47nT~jZ636bcHs*;{jMYcot7Pulwi?hzDtP8)R?S3it#kz}YWt0JcgKfG96d-H<{UjR<q~D9o3(tISd4l~__6B1>=OyM+t~=l(0n*ucl3I6Ls91Z+vqip+${B!3xqRL9P8YsTDI5OfQ1+zoIW?^$OMIhUVJ28v7K-FRk|w_%&G>C>r86zT&^bK?P#iqVjf`(WI@@YXd>vVR==nvWPd;v3fTZbbEF(Z8pLLw(D%#a(dmOyxWsa@CeCa&=+R&h;?Rc|vY67Z!IV!4A0atCxD{H(MfMgYAzh>J^%F&Bl*AK<WbDDuE8{s`;u+or~>E<0gn%80CfMw&`QDtqnZ#JNH8Tstg@>jnAa-n_LAmK(b&$4(HJb$}jZZPJI`6IrhgDsgmrtUd{eTLIj}u6jBFUc~{_#kPPcjo0ZtkO6~YI_h^HQ%^trD3<>`203;IW$?nsSB#o0&=!dok7fs;@nQ2un===2|-ue&`;11VPKTBfXz7@iP7pvkLQ30bY%<s|V^nb|E9W?1fGd5yJqx|iYsAglwF}biy7U#g~&K>w*c|sWZflf`#1&CO{k1TMfE|>(2C&<tQ(&VqYV(h3IRRg4E|I`B@8mCC!zDbY@`~E>maEXo}BN3r>tn4$NGh!++#q<XHFjZEREqXe`TMIE1gLBRAyUn3KOj)d`3TfhYz_;0VT2(#_aC*&&Xu4@rk&^WrrdA`|o708x7=Z5?A>xX$Hy!;guK7>BHCww)V$4xQ-=9`9kEZ+FAzq>#RLehX!}8wKeH1DQVo6OxD#DAvFBtX0=zev`sX+uox_mN0CUxofT2wG~25UGK?Cif00^G)>nd!1uF(|OYj~|o_ScaG}Ga4l07Vg1JX7T?&=RlS~ZEJ-PbV_hln3msS_jX{GsDh$>@IX4DR;{AGjb1lZf?tW`P{snD1KC_d?|_8jb_7ENg963`4`!^t^o~a=Y`$qWqPj1MBBBYd4zYT*h;!J=b0@hd?B$^Cmg_I&(`;PI*8F_q#C74oy9PXOci5=uU1FKkum~!2?!Qq|w*r@U&gEz;t+^Z_4Q!ciqF(n<1ZE4d#mZ-c79PNRc+az<gE3z%;`L$T=2=x~@rrRue1gz>1Nn4c?l-$YTJKZ6+~BI@O#II`uE)i*?v2&P(d!i&MqceRWcEPNncnZ-TC_`|GeXH|zpVencl_M=vasVt{dx$^D9^>q2f?^D;Vi>ygcVm%=Np-#tz9kT{&&d#K?tgf##s&IV^vVQH~06p`q6LHEyQfTD}^+ClA@AoFur>`{ktrTEBPE5T_>2VW>|FcNjql;hS>m-ex_xpvQ~{{Iak*AEDg22IgADhXTA{EdxAx&*7hv@?$1AdRCQQpi|QT5H{_7jy^Pi2jk~qZtWm>ejtpbkWKR-HQM5Aqq*EUEz2M(4QVWyg-Fe%>ff%CHOA^|8iFcr434?94A=2|@`*Antma;-!B@UX}$xY%rLlc^s7;Xxsw7@#H**}YfyW#w2YOgT5%W*KUuBY&7%fWHOi)^{JJ0$PAE{AE%e{l_k(X@leJrDwSAhL$6)3^QiTpPBCR)FLqnite83}ezDdJbZqo+<B-7QFHzEiq}1S|#mM-MK1e#IMSH>FxrD8pV+$B^m69JQ*EREw1oXx3-8!PS7Ha=_?|5js>BU{tPp^*7jn+ufT|&5(mWUQ9$*?<D7z3HDto)H6?PRtRBJnpG#DDQcV4N>!YKE43!hE0>tN(Tk`#7_VqQrb^S@8)`}G3$QR$%9ySBQi<qX@e#(5v0&^$Q$ZW5|0XFua4vw)CJb2*@)VkR~!(O%q_4J+dPPn5+bb&U?5%*@2={PsksxY$jOE14yH7t7r>y`Za&8Jl#w&tIKw_f(Ymc|`qZe7_ou6|Sw20nH&XKl)qPURfNQnaFdvm)UeAQI!~B(1Y&VTx+OolUsl-kH#4E@1A0-UbykX;rbyrqNu~=ru1>_DO#l6}J_~#K0)?hR+<Svt3XUf9y#MOWpxM+h8MVnA~?^_PkXLKYgk~xdaH2(X&aR798iOWcd~Q-ll!lLasnxO@HDH2?>8ngJzDjPcNjWrM5O8CwxF%oK3(IhvG#=@X$7+z}6;Er@!JXpT%)9##CkFdfig9l6t*QWz+a5!KvDs7q5Ys?>^Fv>zg<K$TTl0V-@-N*49>M^viOcJ_r?)yhJWE1HRQ$Z{}0FZL?&e+w=iI22vN9gFTC=(RuR<#}7$Ap?;UfX5Z)*Cdt9E5Mq!dbD<+7cguX!=nGs!MG?f7@&Ld=7`nX;GCEDh!jiA<n&2paMsR!IlCAM4L$_w$D;^$`qKg^Zs-Igv@#0h>tq)ZC$mDXO?+)M-4VkrgnR`@$HO?_UP3e}zsx5bKCR_WigX{CT>?X-K?!I<^ei!h8rKoEC&ERFAe%EOzi{g?CDtoaXcmD%h$vHGPDm#Jk@{9@E*nwqmTZ+8rIQJmd=IM*ZS8R&%cMEAhz13xjhfqLz(Wg2#nY1~<{N`gDg}fl<DyjAHC636v0R{DKouVH@!3?4%?v$&XUEEvmp05T?mAh*-@x}qq#AOe*EWc>>;X&TVJK|}g7<shn5$^vLtp5OF+pRzMN69?8Be%xL0%fgoiGk}$$S1ZN5{;jm$(gg~qE;w_j&R;PAT5;YhgZ00$;f`LpayKcpx;I(p5F`W;c=6uHn!$Pq|df?L&(V}=68-=-4`mHNb`7dh;nlwBE+(^Kf;Mzak}@l4$oa3Tqk_Z{`d))IuH4dvN66Ut@LENKdAch238SQ<1O7kV|+4!WUciM6eAGBqBT^K<D6lKS#T9Hr0=AmVVKnxa87rW|8(&Kqek>RZcXDA9|8Tz;3e%55%IS>Fp4AAnU5saIIe{hkAC!-Y-~{qkA1org69sY)3^zD91~;ucV;X|ry{F?1-3;yJkfz@>8H$c<QO@%7Y)P~o+ltW0{c2$Ulnx#IzZ{ku+hGlWl5sPcZs!@U4sFuq%*Ecml-4Wmm(^eKZzG)7}x5zFmk~W8+zzE1At*zrg#7vQe^-y;#U;nmPlXP-K<4|ZC=E&P=`e7DFv1)UQ3;U1%jDHKrex)Rgc9@JU?!ayQNiV8z6Jdnqq%j(eZd@df7v#5i)&+6_>1Tnwh`r_arTmoaon6v;6HI>>G&@$rGRBZZ;<6_Rl`la?u82B+GCBD!fgXH8-}|LX`Eg5N5i<PAuH<m7PGo5XOec&HqZkI)iHH%wXTJ=PRNFmFe54)m2hy0-dhcZ7U|Ky^g~}8C#*8y@-AhTg<CcFgnwR4QCzXB3Vuu{mQ@7?VJex-Pd_Ca{ulFMFYrgfV(&A9@cH40BgqH8f5!%(iaJ`%s(G9O!nHbDOtQ1pBg+~*LE%w0!+kc1V?SC*T4k9TMIhgcK`kHn*_^HY9*U*-)ywkh}ZdjfbWGQH{KWoYIN<lLn(1ur|Cz6_!9VT3|}(YYWeewTLqdDOSfk>5<JSI=|CUkOd-4p086VtLi5n`&(mF`<}v}NdS8I;JhGj<^S#54cnKrL?=*s9b!@;GFq>$L3N{7YJ_O(v61k{VG@M+mW+KeR#QSs-R2zsDk3oh3>e24r1|Q_&4|>MfYvU57Mckw~KQC0imD0)BpD>F4z{8Gufg=Ed1^85PiC>%+mJJ+)UC>Tj{N2VRc$xpFY)?()2+uv!Fu|P=^hQ&f$DpVq00^357;ydBa;t{F!6ZuJW0IWwRr<f^(_XM5<Rc04hg1q-`I})<7NM|48^Rk4n#G>hqWxXuD%mK+g&{_P7gddx*uOLVFN8h~=)6C2N2dr4NM}@Qq3R~`pO@<86}U3$7HtP$1p+k)q-c>@Va~m(F8||8BcO@8p&GKbQH!^dMRDVoV}ErUeVfgHQOV(pVbjVXuE1GpI7%y#Jel$Q=FClr{s!un#G6h}<>BC2Z?WE9^m3lrO`}niQJg5|89PJ2$$mR}S}$DU)Lv(!lgh_na!4_KX-goH(u=>bg@ZOh2~m(xx)9G2s7r5D*ZTVc++YkwF#DKRQQ6J8)M`jAu8oxP$?(8;u(#3Xi@`u}b=t3BknNqL<^^X}MPZvYV%a2bHJ5ZU0m&8%@KkawaY<SA11C90g!)DE4=?w|I3DGX`D)W`k;*tcDL8x5X7fwzFJ!_1{fspC0d?%}NZ}TPsX%eu{|cFk9k<4dP%^uZKdb57=^KAFoEaPqTOhmads}hgYHUy72%K-Ys_IC44ny`|S8MNz##F+IEh*GQ%6el2kS)r&C;OhkX@CivGBjy=`y$6mibW_q`dAza)vq^7w^ZJ?y|k9`Js!kwQlW-R&R|FUX|$t^csqmC%@!i9euO6pM}ipQnG-5$K@7p3jSS1qcmGu+S2YoNO#xyd2;Qa`6rei{rjn3+EOoF#-H${aNwj)!8ksT^SWJ7Km>^D3WcM0e&TyEus<V>{cX@di{gg}9gj?k;6FbU~^URpno@7#;T$<r#t$nb^fbPM)6-c&@eWy60lnTHGPx1jz=t|Y<S?C2?1_%V&p;yUW4-6)*p+t6CBgUFy9^Hc@?)!2U{4}*m$&P1J3rjj%vK93~-GCBUmJ6O<lMt$v^GVt<X26e`!JtFB<{4uC&n+yt6a6DawAdcSP(LoAs(j(_>t*}JYY?ti!;Qr^B{S!L*7_E}tqXnl{fifW=bn^Q;!0{(XYfjibHmzG7OANuOT$qL?pGpI+t;$kp-}SoZ#};PKGOYlgQn<psUAS^2tD~p*0En75cu_ATpa|o9<O@=US7_p3FYuL{h!C(rJpyc7<)gZlumk-8SL+Yt$7~^y=Katq)kx_hlcacT`)pAH{MVzB;ki6*(t!50ANlXXvTCEJFAj+uTIf5k^dZ1ww|*~K3-)z+>1V`M(LQ4<XbG`s|PBF>eILdk569d1!wdz_reF_Lh2=`cUO!mnBf{_OPYGKNmeAzCVi-PDda=CXvlp-TU;c2wX^7kS14@f*(tSs;HR`JpqQ%WQeO&7U8G8>TLn>{*-$KqB%}R6#Bl~WiW5-?A=+E&p%;z@#<aUDsIXPJbn%ASJblqUe7=#wov}yoL6K0I5`xbL7-Rlfv*n|O7Lc&gcm`TMR$2COL(0wbP0xw!+E;5RC<37Z;{fyxsfuQ<QZhsBbGcyFj&iQY0~ZK!k?D}P`k037r<33wk`CY@&e>)*eM^a#;a<;9OW7xGS+x|AKi$@afDKo=Eb!UF%m{WWIz3foS8v*{;``!21n~(<RuWcp=>3L4#R&LB3K3rl5mh<WL{Fk#tQo;R6`hC3^?iM3l%exIZC=;Fy6F8HorfZ>S=JRKa2ofG{9_B>+)*vDX$5d>n537tsuCAcK#SuQHh%(9q^23TNs)<&TjdC;vJf4J^OxU2M9p?@87$X#@CzF>_-d3O(6l`{(=$>%`#ul=TiGBb!*EW-qas=fd%Qzp7a<|hKYA%3yOiUjEEZoZH)JhMqC@{I7%^b@7Log*`(xk$HH9E^eAtdK(kKI}--|$Wjow_j9Ub2xiqhwjQ?8%T?@Jh=I%kr*dt3k8jGrLL?&zz8yJYsC>z29d*?O+4b=y-;15Dn?hziMk-op%SIfOuq1=Ko9MIN@Vejx5+KBDByST4)-H;a|JfEPp+1Az|;==ObHAGl9uwm{<<iy@&@R+{oWr-7BIcrCjsG(G3a%mWtO7P!cIu9n8V8rNM^mVlTSZ9d?vv4xsN^3?hOsC=tAK5OPVkb6W+;KMBXaQyX9U7B}Th87@xCGc&*(MZorMp~}zpdc`w{7G*U?WbPLo?7$!-e<8wD`nPz)i?Xuo*sTaq1`Q8@!j6&_AqPjMr15tH)x{(V4Sh=ITAgrEiXGF^K1)JBh9~M+yq!~cEPRo+LKVYUtWLjI^@k+DT8NC%F2}Q^*Rl=IX}ji@;`{*-`Ha>0%ly&2K>84ZDbS*N}Y7^=U7?5*a4%`E0{~f^9=M>A5h}>E@$lFy$?MQddVv4D4+lUL^(ZVs06hq00Hm20l&HhdMK`2vBYQl0ssI200dcD") if SEAM_SHA else ""
    NBDF_BODY_SHA = "266a3b5124b037b0ede89ad14c782d14d8b6c4bbeb27094ffa1f099d112cbe1c"
    NBDF_BODY_SRC = _unx("{Wp48S^xk9=GL@E0stWa8~^|S5YJf5;WrCcmt6o6hy*!L{ZEZ$h>Y^w_j6QsV#pxRhB?_~yN4Ne%g^i}bVD49c3@*1YGhtwpL_W;R+>Q6$JPadlM+<yqHvsd1>%bnvAhEXi`DPtiEL5}@!fe>MMO%HRWQk0kLcnGw*0OzG%IS{t)WEc=b{^Q82@!?bfkEBqJ|gY(iv`ZSRY(0ue#H$im}Cq$+)HK;#pf)#*qHC>qZ_LY2<AYN*P0ttG!PU%CKG(g34{Zr$|<g=M9G{;|jvrW!yE)5K&Y#zq?^nG5`5V;K!&nEz?{6Tfb0Vtj-2d*Qo~0E9rz2$^)2V(<_V&{EpVP4F~Ap2#<WcVsOn%rpkE*Y*Ml?DCr&}B_Yyqo(sBlx+5{y;id{Wvbf7T$rAPx)IZ)n>qg3THZKWMRs54mi$2vCtO~7dc%v<~A(1FLtLime1D_=(L@qY2-lllTsSeh(J_*SD^j3mQe_Vj(cX5z)<W3iWH~0ESz8J;)F}uOn&ADM%R`ceDb@kc+F12ac62gLdxynVx08m9=0b_!lH4OI1)&GeTgW%6YIJaKmULk6~cOtQ<BB>E+1Al;bBQ>Ma>J4%_V<(Fo2dRYePM$CbXG!fr`jj6h8s#w(J{s%|`$-+P`^9&gOHXXnQHX+aY4NCuz%oxKJi!zKA|6dPhQ^KqbPb4_x)Qp>fPR<v4q*;w$JsBZ7k=4Dzv5msGAKJFkM7w&v6SQx3ZMyxfSMTz7)UL(#81r&;~S%-l2^%ba)6mZk?4*aIDH4%A!^5(P44{MO+El!=qZEm>5-TRN*7i9LFldCrGU?NF7t8i0Fy3HmB8e(i<@P5(;_)0tjM|S|2hCp;5-p!i*O(e=q4IgBrbf1qY#?g`t5N86?mkSWkK|xD*~^fT|_|*6D;UXl^OtU>4*7=&d5|2t^^<J)9TvrvjWI;k)_yJw6@aFVWi!m2qIR&4DMQLP!4vlHu9GRH*^7TC`=|HO+%GmEWB8vAJgzuOVf0qchqQ-WQ;tSnMh5n$i%IvY-mx7WB<&J=0T8<2J9M=cf+kL?FP`Y=q3pK(ZP;NbamnLh2lRO9`=o~wG1_~kXi1u&~vw(8BvSPVR}S#M)U(zjg8*EI3v<Jm2`y2rXt~5W4%o$7IWHNi8KX4M%SayU%VsZ08y1)^p4Koh%3~!lq}g-aMLb{xYgTHq&YQUy|n~7|DqQLNf%yxQ*W=CdkzQjxSLbHI$3pKY9^7l8G=&vUihgwpws-)5UENlK-&z%4)x2&ex2Zs#4t?F=uOKAR-#rUn{7dcZWG5q(Q)ekY2Y}7Ed;baNp#4EC<Q4qSF72+4%H~;Oil2!NS8+KUaA-7gIC|Q$`YL#0D&(-UA52kDVzns+Q7&Be0|U&o6-`bX0<c_Up(*2$p--&OU%9afvj9DB8x_||MYw^-QZy5B@ineFoI)>P&>^dWW73h1dt~O>K4PVgE6#XnTKixFX5@9<|JXCa2!YWnYEjy7Si|-#ZLgWobP9W*vJ?%@?Xr>ko|fHZzo6lu?9KmqrtZVdBN=bL7%@-{Mz6+R_jz4>wtKfu!R${P$1{_cJq(gmi=9$=)O>{PL_kgrPh(`lzlEMtx~_9SjkIV%c(I`xp@i!txTh!B24woaH}0CHFa8blz#LDo7(r44{%aC-qQnTi18C(#yT0E(^+IAs0k|Z=)a!~?=Iz6NkPYdu}lL)LE1$%Lo@*ZUj<Zm?U4V9V6$f^o<EfED$mL_xg)`@((T*b!E^-Bf*k|*nRXN8R#RiE%MkBpGyDs0{5b917B)?-f4&WlDT~!Vyw~$n!2Ol@ss%=AMTsk&l71p*qc>f$$CHyI-QlHs{vrNo@{Z6S<z4F{f_u$)2O{@DKdADFm60EGny7z}lCdrowhmBH+9hqz)ok^w8`3qmb3fNEea5I}a4m0;-Mg}87|jSqjq?EI{rHh-C8BkRfC9GZfZIe$rZ{)M1M`$5NhvAMc&7$}Ee}DAKq)bz0fvFJ90BIr_I0#^Mc-f{t@DBqc-sRt!DS>mt|KZk9?V~Gce9*mVLos6N9~qv8{p5S3L(JXss6@#f_rxE7cH-A<83Etl$l>4iqiBN?w?r4RGrRlsfrM|Ef^Wfpy@=EtU0dZPHs5(ooI*^Urg?xTvnt#QH5flo^ruf;0LDMGvJwO@J6;eI&qbmmV0q1z1a98lKFkey7V=&Dk~W4+WOcW=ukQ&D|1#Xi{}Xn(>YoHAaBB=$`&WM5%-_{U#Ix;W@1b}3h~xz@c4x>)m`fXRjB@sC99fDzci<NYN1+_2AFxz{-__PzJWGE>G*L(0Y{(D1ZPf(v1BwY*<p*<OlNa@Pwwjn9owtzj^{W+4VJile8U88me#9oBCW?JQVEralqR!X;~S2tqra=i0xg{|s})EnMe9<qA+Puen6ymGhU@coG@vGf*zaC8nRc?@PH@jEV9;}al_NzJO5)N}oZR-UM@2RE3DnO`@&$e?i8UAMOtpBHNa_A$UTD`qD0F<S<4}5NV9Z&U`G7I+T5+xuR=8@DZcLMm9dfKi5^(7(0>sBd)iLKoB|3+_8E&WfUnXaT5c&~3XAptypP)>7S=FS8#q&ITd|blqQ1HuU>yl}Lzb`FMzA^^W5a~B*KLyCYMJ$VVbuDg!0nHp}Kt9AC1lDXmzj9h*R5+6>4E2yRB4xZ)3R(IUWhilOtKbvC0O1}`s+GX~*kGd>vHWjQKN`68wmSmgc}dN<ig|UdAU&RB%(-gxX8F#~7JZ{%ka6qX{<hY4ilq)$LH{VKEZv?xx-*3nJ{Gylj`0<U6K=q%twhxkq3rQfkyF7k$<FlSF|+|RxfTdqOM`EjqTe5eA>Rz?{};B?pqs@}wH**_n8;|z5&!br#mw%oPd{pvstpM}Y46JW<rfZo-m>YvLz7)6N~s-UvmNh97XLq9;}oNtn+7&t44T~=8*2{QHej`NNAmxf1JTYq39h(|f5#*NPD1_(9o|Aa{^qUDn~HYy@x&)K)N@jLcGA)gnHRsUm~?AvKE+dDefYONNC;o+9epReC=*MjcQc>gHh=&PVjhZf==#8{1Tl0965y8-%<G>KjX&9Rj-XgYxAv9iBmH8;-mob#k>PAw?Yf37Uv#w*vEoguk>>Bz*a~4W_y;64uKi9WmH=c*5(Yz3lKR0k1!62{A6n63?ep)<&}zOsfRJOC43%l8m)XMjW^iu$46RCHe6b6>rR`tIhO~*Q<TzFHNE>8nv{09+&adrtX%g(L^gni_9A;(9ZV&p$86F<F7LbS|j%+d>^C`o<%>e|(lOd!<h^g8rAS;*fRj+$_PUrKS2opqEy|f7NihR(!^KkIL`iEgcd-i3CsoEMo<Q*H@9zhe+3(=&A3)0MZJ)l790RDVI7|ZUPmmE{~gvZz1n{NLkrxsu6Yav!93xpKL!+SGN$NoKwmrBeX;@z~t;q;bSm3lL5%E<HqpQlEo^X>waoIq+g`GO9#O8KD^;I#GXCi<y{GQ1iOs`;%UtRtrIcY(_DSD%fK>EOM5ja=b!2<N0=-TRrOglL$=Oqi4w<Irt<1CKgo^FAG)!0sR?iOFP2cZ*t8B#AOZ1Y3UZ2N{UPXqsXCs<JyQK6gSA&HkIt#Ch!^h}a69(!~f|ox@9qf%%?_h#mb*6rj?@P???DSw)n=-Ghu{_0oxm!_jldsSy<%G2L4D<%M?^WjH-EW}rQg*~Px(5F@!QAx8-+4XCtvADHlxGZN%f8~A9>r!Wk0fQ<1`YFnP5BVO|ECUaZ3v917-51v<?SG&V_id$EYPUVxWeWyd?5pSZXEo2i?_tLlVAXKzNnQ`mvA?lTufh<lgl^aVyt++&Ksi>4BBEL%<d`RFovw}U0hN<5gpKaF|`$Bv@@?-%~2|axde)11P@Q{`=qB!*!=h1#Gri;U5PghQzEKavk<(Gvo?te^yLSIXo7Pb9FaS@Mxl`Vh?KV`i76e|fjEfdd#;WC1s4$kb;LL{<8Q13`8R~7)d4E->RHn{Y3?qt5pm(yif3dW&!g0o1Ja<clq>Grvntt5S7Cky<h6J@833gbdZy;giBRYkXNIsR4kgbxm7I~hG)z((<&JylpWg&t~n>;~%s*Ge)Eh)R*%nCram7Xs0A@=<D#z7=N%rQurpoG2WuzUnFsm(5#A+jIf`2k|KJ0{q_Is2EL1W+L;a8Jbn}8b)N9DBVZ1Ntq$eCcZt^EF;`ZNY?qqqK1z)=%$SZ$)XbMLPZQZGh5Q?Oa@VC=Cz|MaOd-#u1ZqrK{|59tN4ewVGmC%^yQo)u*P0o4Um6{+-?)smjrV-lX^_7C*NKLsv$yXOG>AVbT@iSx!Qw);nzqVeVoEPP&d4ts@C4Kg5GarEC8r4)31o57w0%l0Wm&duyde-Q1~NvGGl8^cQt<AqqQX8z}-0ewZ*C5srcx~GeE;t@t1t61jr4rf|$9*X|-~3Guilcl48*<zj+wyy4)F1O(E9R1IIwQkOzv>A6zp^A3XxhKcCetYhDB2@C&#u+T~WOlz+F9lBP(e$T3A`zme26<?R=OVYh-Kwi3EndfgD7a3+<3GKg5hdcdq#q>{&=tF)#yM^e9ohs9j>`8e@snT1orCZL6)IEPy7lD-6GzX5Sk(s4xEQAijSUFR%3=YE-;85Qtc5fhmNV$-@$4I!HG+06v%oE)PEl4fqCz2=ANztsaRA-uY+39qWUS+rnmM$MhQXFe6JAPzu%TF^3@a!E>DRXq!wxymT2!B#J`yjHzHvpOQgoxQd>TVJ`22bAh7M2eyxBIIbxz1+y)`6yCX)9oqCw7vVz)FI6%DDAr|TmEkYvYirRzY}=|fEW&0Y15dLDoQ>OdQo<Qn4!_VF-hMDU}zBuMWr1ID%gNY6Yceh2@|(V0;t#wK6IS?lOnf=2@k&z9B43;nMjYP$C0DR6CU)sHV_q7ODr0(t0&e*pbFwy&CzLGgYpawq+?b;T4%Z%T5~f%bdWQ)5+YUx3vOezcPy*2^@gMWS~$rS>)e7-k_HG0bD52Vm|ImLx+&<pa3!76gqW0!kM$7b=wDF<*j|peqIQ<7(<d_o`IMl0#gCgSqDIk^pjOQiE{v>e|8V!2L;|S3YwLTO<?}KkM45W0zQOSj_K;#_eTa~DNsmigN*{?sw+Y$%4kzOv64+UxG1h}2bClqB@$;+g-Pa;94q1|%(nUHN?BnQbLT<<Nkyt%5{3xyrq6ektE^<85#DUZ4Yy@wA4FGain<;qu2{tL%wuruA9xj>Ku!2HKB}`4Gtc@1${)&;;mk?9Nlw)Z)I$f9nV$R`;AV6r*<x0<VsLs@0oKiGyWT#=0-%@&3mR@?OS6DQaal;Nw`;5_yTG1sgX8|e)_e4g-C^p)Kt{oC@8yCz7Fsu0tpe8a|GHX0fZ?GaCb>?tg%T9ea%eN$l_+l8w*i^u^7zo};+b746Da(c~pc+zTTxnt~SL;`t1n@`%2m@q#&zu^3F4$aGwO*OhKaGdT6>{{3S3+6>LP-yFH*=#F;TIWz0})g_rq{0}X5)Q~(7bUu@uED@?C1Lg{4Iv2@}jX#>hDo#Z^k%R#CexZt)DVm<GQ9)H=Q#2xQDeTYf)q&9E2mGb#@iJ@c^Cb7YC<=aUMQ219nx?7kIOLjwQ085cKPQw^$%%A?~e8{JY<=wB$uX$b{I4<FLi(TML+3ujZ}=rqanF+^K!k>qxx(b|Sl}&?jGk8~KX_W1@?^hDo%TiE_!IRa*1zg)*MRt0O$Kx+$OUwpfcR4}z2X;>{Uzal4F6O;-zQF0OMAtAk7>>_(V@TQ)gAdZ7$qePb^&Qaz;#N6Bd=Uid*)ul_@%0<#z8yU>3HQ7>9ad%<RU=;@voO-W@j^u`9h0%20TQC%SMAg&90O;OO}&;+z!<OTwoA<uJjRgQ|i2o+r_pA&N5cUak~2^N@wK|_*)2M{nt37yS?G%+PNZuds5i{Sj%#ia?bQ46Gx`PVCrFIBswjCY<)kfoFw$uGpvSj$<0Lmm}#{chretR_NSS8=2k5M+i#g}VwVP+&2v1FS7HpWbQ&L^3106F9p!0(R2m)4b2&cn}VTCz70s2MbOKT?1N|p~d0OW_`H~-#n#%%=}UF?)pPVO)d)qX>S7-uzmuh;1j-Z+JQZi78gJ4VT=jcWdUF?XHUP9)y=X!17L!9K3N@}gomq0DSD3wvsYgXvhCe8h+uIAV93QG7yw5yoPl4w4|yN3xG%bqYF?^s!B&2#8c6<$_MxVm+wu}DIl<2kHuL`ZGKEQ9>8_76(zh&Xw{ZDL4i_0qVGhsJDx%X}pUg5gVSz1FI~0fgV?TT00#r)_Z;RN!xD98H2h|ZmR$E<vJMqHcwqD!<x3Y!Bw!Sv~Q24;fyI4jC#YOA|J1%`^`g6?j%|rIF^KF3a9Nx8ebB<%}Xr*0tw~H{ayC5Uqm0^P9{4iNJo21+K7qHF1rgC9XxC_zTB^=OSz`z_cChkUM?3O?YiqR0R{^kA_7+^^OyMG3FdD;U0p}Odzb-iB+<?1ntAzk+^4pT}|*8eZbz-!^tSiPFmO)!Z&S1X3}up@OUaSsyY7#nM~Id7K6HIbX7m#S&dVj8VW1gH1m<EMUgY}g|1aU`5rlI$^HKFKq&kMI43d7hi^ETw5G==(}GPBQx1{|3s+gH(v?T5l)x^o4>Q+*|cUTik9OLk5jo+=UQ}WBKsMGdc1Bwq}etO$gC86)T~zrxg!sI>_GOvbfokfSW$oq*gy-fjwh=<|4SxUusC@hAnBw*6cTrB?~AUYgR2$mHbE%Xnef>6WPwAnXeoIvd@Mt5FVq~rfF8hEy|HW<6Ho?T4t-zI<ovo7d(xQUo}PWUknL|Y<q)9SW{4U+G<?DDjETyAbt0o=z35*u~Vx@{+fYBOhP_zB|(7-e#6iZY)k(uhI9dA8BR9~1;t?PKYjv`KxTbviL<vVrT_hkla))VnuxFzsf2)1_f0?CrVRuy#sQD75PlR1b~TFlWd_~0cU1Y&ukASK-GRuO?PdLEa}{{+x!0D~0a7Z7@uFTeJ<R<2T04{8L!|(^Tl#r!X(?EcqDiX8!JcQfnk@0%y2Os_pNM*qBR5b<25O9qrNjkn5=F3g%^Wlef4q6O>r2B^?bPwiHYQb5uVlE-#-pbNq^m+My*z+>Svn6}1oc>Kb+3AFw5m9gRc#yp_*ok2C$cb>j!H1qcj%@Eigws$wG{jtfg_HCGpMFSo$%mnr-O%_qs${gVgawILqD~VnMP`~eOAl<!Y&*BE=5ej6MwOoO)$j*I*#|u2O!ke+5UaGyANR@Cq84b1~wm_^T~QdDoJCjj>@APde+iyo5TrgTE)TNr>dg4n@~7-yrN8`hVoOXTrSc};=l)_{<W50LmUpLz5#qh4E!g`V`uZH-wrZ{9+1M<<t4&C_^ls(9s}~?rmV?Y-{Q6#<Ze1}+~Gji-<>F&!{cdmd_hajl_b%Jzp@-}jVoSF_=iKqkPC65k|WmVh@uA5@ID^jPYY}+1e6a}n4T+~k^!WqI2<FlG|v5Qc-;WdYSA;8n1e=9YGJ$fy(e|V-`lyGutf*tx8YL;HxE-@;G8Q4@|+zEu5T|D8NAS^>Lau63DgJRju`jrf;{E#mOUHhpCQuvj4B8GPsf{D{~PU)gR#eo`vW8}o*Bqx>Ns6!oq=99__>hT-_R76*TP`#boLj`@#W5&GV4r#90I=CKMI3i{Z&Z$su7;6;JGLz0**fq(`Rr&uH9a{9wZoy&qUQX1yLWn*{JfGj`XKm)4KH@rdGn~!jMdjrZzxC^M#)_Mu4!h1k7*!lolXcdp<x9XTg99#Xw#(VAl#=$>jUNpEA5_4+Hv=EYQDBQ}#k+({`T`<VFul@j4+GY_*v}1lHl6+)FtBIg8hAzuhYZEAv~c1Fyf(C&*gcunB71wKbb6*rVA=*9o2jQX(LYP~qf%Xd?eRZRPj`wN$@>s&|oeH(C59Whz<P9g%pGA8G89z$EO1i}jwIQIc$q*MtzE<5)6aN|<-tW{SIJcSLjYo;{G>e^iM5o3(ihTdaue^UE57sQx$+@3W!#IHX2O_qx)+6YK^1_-_Da=_dRy9a?2y0SfU({bhjylU+UpVvfD(fjd*W`zw_;nayp?pX`hLTbMAs({xuOpChy2xT(9%Svo~g*lX4p!W^3tZ+1q9&Fy6Pd}E6}>2N(%V)T&1qqS)W1iM9gk^hseQUy6>T3`yd1;BbkxI)O`f@IV9{OF=enUHz<#t~Jw!#IF6N2Vhs7ohkwB$x6@9Vg_0hcd(Wxe)UmkLPuF+N>R@59;^5^4=gC1XD^A$2sB>gF^r>@OfYGO@xVE@kWrCyq#>m9^o92t_1}CGRs=~or8wp`dgv>cEMbgez>dh99L#@;;cP#>BDob+wq9o-W1gzi~8P@DgnbDW7PCqzcX#?HHR9v4RLP|`96yDgFV$Hiw1sa=6Crs-adZv?L#p*KLsDh%-{`Eb??63YV;DGD))2`70AjG?!AQVqoZ@0NuwIIts|~vw>kD2>hyA8klr{5=mJW;gp{1(jLt!XLlD_Y5X=KA><0#sFNs*hYs6460sV?+-_);<h_iLE<m)!w99}!kweg<MId+H7NL~-)f8iF31|7qQfurnPEH3hGn)y`5qzCvhfh4dCRJJBz1!xv8*Pvf8yz2}|_df}mfra;fe~PA)tH1~F9fLAft<k8;Anl8DVu3sYm@KyJqJW&U{fsArJyBIYlGuEJ+Lq8^$rijz%-`BZ`LSOG_ay^j=IBLXL*US?ldcSP8p5{VS0tA;k<F^}Cip1_u6=~ky$I8kwddgCFKv^))WXHwc{VUnhBz|v3NeBh;DPN9<&e<BLw}6lTQQU0@G3(@0gsirU~ZYxDk@IeVA!6=FfqU?vP9rD?eLQDCc~3%zsucmeSrCSPMaESetz3s$<qdI?@-uiQZ%Fxgx5uIUTwTqWuYAkyS`xv^Mlvg)_fZrcEDfu1BlR$ekHhafJIk#kTP?v+peOIACRPYefO=w()j?}RJ-7$?|!2`8)lxBBg)cx3`lGrt`87&Y}Or6;!HU$yB6g}l#HrwWc;c|XKfubRqF2H={>z~-Q(lS>0kWOfq`V_Jv&b{=!fQxN5$^1dZ0D%4>1Ib3pwoRS-%jwltQGohxO?(O8tL0aaz1+nA$T4E;9Zhq%G6f1AiU#mZx8hn_%vp)K8>!`C~2j0dT#&$O6{p!-!^a>)g!HaU_)%j<}rz#0X0w8S*WjH*j9Xr}F>d!p=cADRdhA+q3sL!zf~1!BG6@uC!D2M;D2#30xGnM*{2Fgl|Kp*vQOjNesK2+Gzgs^Tm`nGvyVk1$0BPCKgAYRub7L#?=0=G9~1wD$D~4F~dR<evthJrl2V`m)cQwq0o>vA}3ERc79M(L1Abvn1;?~KYVu*D$N|IQ_rGo-5>ka+)M}tbZJox?7<C?(-9@*=7T%zPmt+2X-p(DY*!wn7G<q?^D?86zdzNO(Ab7llFN==DfolS;;T5(XV0_`yK0;<tC9@{T5tRS%^EXOm>Cnz+JA{^M4FW7({5S7m7nG-q1n$Em>4}4|5}I@sNvh=XXoj_j7}}LzUb?`k1a}$P}*rLUKxu^y&_tv!l`L2Nsy!2+O#Y%!&?v`eGcVnV)CZXwgjbY3tvfKkp1+31dZmCWty{kmCX}vzA4Ji!8^|o9{!XDM8*8@sDi}`;RN78K8k5;vWgu2<w@jDUMzDLq4JL5!xS>b;VKPuL+;?0v;WLBeDz{_WOAv!Z&Cn)U(+qZz;}VdOb-xuizjt(q?&xIHNM*`o;^;H@MwQI@93Z2c@JYBP+b-WIt!M4s7PMdQTlv<oAyK~G~ve~?&4N27GWg48dlL-DB8NJkGrI7J{Gi9{n!Q^bR>mG7cQp>>+g?Y)p@1Ok_gn>>;O0CsIf^J*Bva}flLfE1^=VAYM+PiDERpv#i>*hM@|Pt!*D>%WBZ*(3VURLw0vQDPu%^&29$p?ovd;Vfri%aP^GmgX`8WSycL@H;M5S;s}DiT(!G~-Rqcvk3Bz11Ls*B&7rCp3-HJX_9mhKFwgG53kit4d`4P=QZR1~$5!37FnSC~~$IOCGoo$bf8zkQR4Uk3mq)p7J1K_ZDb^9{kNF#(u;u7d8pZ*aM4z@=5dm-Co`$z@%0w>G~;yL&y*?)@mZq@1qU&>|KdrYqB>;S>x%IqjAaFO+VMoW?H2x8a0d+`(o3^aiB$Ybsi>}eC<>aQCL$^ojd_Cw`194sDWaL}T>tuO<8UF3i4c*y%twUa%1?)E~Spb*}%-VX-1ty3%}AdV-w>#ZIWZFUU1z<BDpW`Eg)N;%u3J-cRJ$RF8XVJR_<>w9D&;_Y+_d~50p;rYySR$UW7J<sds;cA(YPLd^z8;q!yNt!@`yga>;O`c&RE5i0CgS<x|!t)L>Xr6K7Li+=+N&pAbpGJ~#?ixyCXKs|((!~4$QU8S|O*>$$fn&^5umXPY`l;OgoO|Sd^{p*5#ds7mex2kV36PmwD${pzV!XgL$p7UT>C}-bhYSKD$(M<ZOn+mv^rBrwOv#A1JePw@lWjs_8V4RmibCDiupU(bHUXBTg-`Q;He|D5lN{fH&S85@r^rN9)@^!{=5&|xszt$BOVuyd9?PVGfc<z={`21pb9u&3UsRpnsHQesy^V3*Q{JL6gj?QAcc$=uigaii6OSCD@Gsd#wJ1j9l6$#Q2)p2N-?2x6OjasDl1hg~Z+rE~B;$^l=lgype(@mDITrTji>J_+fi)`&G`VW#M|{6Z9ZXH#msh1+H9c+;NZ_IfvRq{8pwa~KWhBitwo)D$j6sp(gW^Aw9I1Jjo7F=HDG?|}0zj9NZ%`#A!tTM?RZ|4;{<W=#SlI?pe36jN@2Z%(bkxDm*)ezu<y(!skH7fjleFjzJzU;|%g(06DSn)&Y%81i_}1I)?T7$4q}jU=;&yt|<!M8_+{wcX86_#a0K?u?ozYf3kZQ*Rq~h>j{)*+6X^QU7p5x%DFk*STdh#EN!u=MY9h2v>I;nwD+WO+_eF=Vk%Qrs$8bt{Uj7OBoAKapAui7D=e(kt`rFzfc%-f<RIM150d8?#-3!X!(f>xEgLd-KxBZ&P+>D#S~Q*Go$)Z|DK7am&whl&d03%X1c4<VgHwS_RDy68P;ds-gToX?n!BmJt`ZQ`hfj+4l@NH)wP7B2j+&}5ef!YiU1U>!*B-AHW4Oc(}J#AMxfsCYAZ28?7OfGBE>8p+{~ME63)CRru%>j}IAFz~Qluf;Iriy*%4FZcS2!!o=FD&JgV?cn8?WNdNe^qO1Q|6Y3_iPu9*k)B!IS&_AJ`p}z5RCa4IeyDn~)9y-nDU`T-3xVcee`yfI2fL6D*d7k=+^J;$Ackz@#;(_!2DOb&IIev>8KOiIxRrPO`Tb%6)HY%w|CC44|6&%@J(DF~&iHbNG&qy+ksD*5rY5M0X*~N4At%oo(6dliSBi5GWOzd7*e(INu$;?o*DTN{%a+Q{>*oW^^D3c$Cxlpz5bs^tcRNHyyMnvNd44m&C<fjOsAHb4&>)-oq%JyOT93{-L}Cb)sko<0UQMNqGti-~7y%kfmtH3cVnu9RWJ^Rjr0VBOW2-y+D}`MqsL~{(*#Ac2Gj=;`>WiB8qGDG&M1wC_8UV4ldlPuGosv%1MN(sVMkT)h1hN-pZt7DZfc+0+=8TG)7)Be>&wXv4GmF+36UR-_g`xwKuUneYhE{NV%T4>zYLSAg-hoMqH?sO*@kWl%=h-_83;BTfa9cY{cFq+_mlDDyI}eP_cHNID{#D9qu{?!pF9qT#85Pr7=-FeiZ`1)dYnCB=-Kvsy9UI>5hzkEw79&!=ML$|B#o@{3Zg(?X+>k+E8wNzh&a;oR(uiM~S8QW&3LIs51525rGUbTCQFd!t$)y2f7O@Gf9q{vvzrEzY0=l+OUSXZhWuzBHVFXD4GT0b8iJ>i+SP97u{OPFsYZ-;WWd3kOVyHq29D~}<I2M7i8Y#OQ&ZkXMf1y5@LPH*c5z@-@)QX6j<$oj>Uye|n(*io0nHaEqM;Eg6?`1PN2S4O~X@Ga2a&W*w<qp!<%#Ax{@q>6|Hzj@XS$AxF)~6s+pw6LRqNd_F`+iZfT^p7`E0ATESeYZ=NY=0Ut2sUNA~6?n387bEQX|QawaYlM0D$XHomK-bvVBzxarLXD=`{*V@2f%8HQM#NhReuezU5+)*?iA(o&5;@?;cAxn&I6tSt}?F`@mk^|0WqG(YLHz9Fw(7lcgNM!++i*CnXYef@MW{TVjZ~*2_j@!5Olx_k*I|ok(aRlNWF8;^-aWzGh!jw%R(+*W3ytOy(r@1rg`(O*rYd;&d^v8rSKx#E`1v194baZQsKM6#>Qm!n8BAQ$ubbw}%1IqScZ2pF_OR;L0T%0`H4RT#;~Yk*el8v8q1wM4SS%EYX6oc(@kF+PRZcfWCqO=!zOf2AmBCaJ!}Yp=FJMvg6&+qLaDm@h72_h8#m%H-K^ajX{T)3641U=uCqa-T*>_jyn+Nf}-1OZvgy#27gVcs~02SW?wq4=B!y<h77mbq>IEYQ6<CEV;nKWTlhvkw6qk=_rU%HGi|j+Lz+0)R;xLgn!uV-11yBF7cq%3_b#gEXd>atQx=*JcP4<R;X;rWJ|sXz&a*8&R58VQ!(Zp;R-#;NFq^oZDvr2m+OuEAUw7!kTlqU1l3++b7Ab)Xp?y1S7Vj5bbiT_cyjua`MqLaVY5$vMyF5;(otx-RHrquIO2E=F--@QE;pu*#7D+y<DR1;{ur(h(xRxlViX<v#R;?xC5h>cPUz1L_>{FoG9BExt^!q*rY(u<y+wzqI*LH1N3q;8?xCt7Ilhi?bEd_Kgc!QQHh`yB~Jj8KTiD@9$%2&W218WFamW`Y!P^RwfNd^(FDn4)+A?005zYqw}GMd@&_DKtp&MdO^48+L4s@ESHie6c3;Q*<$Qnj5XNEkS_?*(9zDGL0({J+@yQxl7rvxc1cMB2ma1e^UjGl;}@lvV;sEc)>9MDay;Rq~|2DaD_M9cdd^Uu_ttF({(QRWJS)7rDXEQmZfNgMNhtcHF^v!}y1OANyR~56?xE`%|Xq;9%F;ZjHHdiEw;AD5`N;Au!KDzsfa!B0fC?^fBHDFI!Od!TRfnnp?dP&r-{j=>0LWVUF-$Uldr3PI`Zv%OOE%cTEEh^!`)~2jX}0qYN;6vE`fs-5_sqj*bTb+2tNAr3OvpH+C+`!*sUKo-kA5Ja$jp$UO-(k@zp*l6QFf0&?G(awOT+u=R}dd|-N10S!V6F+dO%nEW<zYr`<F96<=L|D7pCLemh@D0m>LWJq4Do57<;XDv(4x@V1~^FrpzESY=OwB4NYN*Hji!>+<V>N#qFJ|`6w3g(Uly610mAIqg-V`7pN<-6#6dN|(3X32~tG27jnL$I`23%V}NJB$(HaSF^^2!qHNcq3V&C_uo8JAJua^H<j#_`?rVex_znw5T|q3i+<t_B115c=o{6R+f9cVQ6fgrv;voCv^`GLizS>_KE;tetPl<m8M=cF%y@&6`(CX+*B@vg3TqEQxqczZhc}(#LoCaq8WBy^>r<2nWpLWkYb0~H9aZ`J9Z3r<H)3!<DF6W8ANSQ@mH{MR4D<dv09&pKN_yc_KAs_swT>!=95>9m%mjNya)_f5lm;t>Qft2H-*4%6}pH|p<VsGbec4`T;u)uQHNN8Dg;FWD5*TbL?3y!D-gzT-$EXo-a6n9mZMh&>noTG1)uEgQ#9l_sz|xBjoz*$CM(!Df1mf@0!z$EjF$9d3d7|adM7J1={`{gi_T4=ra|W8xZ+Pv>O|-k6XOwXNirJ--~W$!D@MYiSBNGxl;q>su|pg}eiv&fG=bQ!N*!G?`ZxHIeIfJ?ZGBk-4l|~ZF2mutfI@Co1(E74Q?+T{|E23HoQ*kqY#0KW5U4Z&5}KIATqX6_R)Mjhk(i?F(ZnIFx)Snku;`FipEbkRwEn4V>}#R^vp!qIW~z6r_RSypqWN1iC+etRd%!%8r(RV-U<va!DBkzyzgaS~O#@0wh%>t=H^Ui{-!@J>4D@zZ&Lfm9kyv(qVY(|MG)fmo;*SjoU^uFUHqO)e?tvfX7H;C{RFx_8jAgjdzR5}To?E<^)sXcI>sIh)GFZ~B034SrIT3M+I@$9MEP_WYDy$;;98kK7^~+uC>j}o0FOl3KwzwX&Aw{Uxj40jtU<und2U7T3+U8vsm&p)(4^0lEuUXZPNwL2ReU7-`qWfqkjL7#!DyDNY!>tH0H)con^6lH*KPOTue1w@q_w_wSWvA~|O_%!uf}oA52*4cDpXku?ugD1f9F|sz#88?~Ic&Kejf;KK){M#65Mw(i*bAOiU<QuKYMF@<#eM;pYuTzlJctkn+K1i{l^3>XyZ=J<V-Y?2U}nmmdHnUQ>|4MBzk4?$WmWIMI1E+}i;%?aFyv@P3BH8NGl{cjMSKt+Gh3vgfe!{uR+k2f^HGT`M?0{@El?(~{q*R_^A&%IVe@dpz(H2{I4D>?3|wkFfW214zFtzR|Fx}cJwU8AfS$QpLBN=g3uP`u5S!CE?})lOCtFEnrw7%~f7)$-`j04(N3ea-i(oRZHNdnqN;t@@2H9O!x*Myp=B?5CgGl#U_mk<~#7Uai`$OY+ByVQKU;pfuyY4eJbfeg8AUhU(U6}WSgAPwxn7=i@n-T)`)<FhSpgM8JT3@_^nGh@nleHk%hjh5|Y*t-$YaJmW5@i>kzJrg)nnhPYy~107@^wTJVC;bk)#+;Kawcf_TonqIeZD{6rb(<uFKy%7$F(TPdf_=0_`8JYex#PrT%T;ypQz0qN3tb;TL9!!K~L(uWu{VxoY&y3ygo%>)*@rlLU4Y3;_ixBi_>GQ?`>X~RE_5$^oVqD_XhYE&@)2K;AZs1#!0KEfq~!`3kr@o11XvBV1MQZ0NHZb6^i{bdGdP0`JFvPj}S*8B+?uYdLx5VC>EB@Bl8DTr%KyBf`41}jw&W33dR%_<;!zjc60!VDq$TJzs;~;?qw>0$YV9%F9hT7=W5Uqf&*YHs>xTi_j59Wiwm}&NN7OmESB{LnSzR;#D$r@$REHFw&Q;+JTO{Wn9>IYh(13YX98iXw*6ex-w7uUp(gLEeG>TcUO@e^@^nmDFS(dr0kzn@OgP-*>*TZczW<Xao}X<t$gU#_Rur5beaq{Ch4zF0{)UWDp(@NpD9^|fTtZ=KezPTw1ZN5u;Q$O3l--g1h(>cQt#T5}0HIlaVQi@7nxGdBYs$AIr&xe%stMs*rpKm@A&ftT8U&2jD?UOmF#7`J^BtZU_L(z&ch7r$7jSQvepup3XW2c<N$FQQ{`^})h9X^)ab*-RPfO5fh_W6vqpf(#nt#2b)&~!X=Cdfgu|W~t6nq`qoS+mzMY34)Cs%K^)v`zF07Q??W+T;A(Sl7>I`u)cEs8yf4(h%Co;rZMKy+NS@w3i)bSr1-#{wK7gR;t$>n-e60qLd=W<t>BjkPP+80$Z%Jfb`3lAU~^xvm`Iyx#3RAq9OpY1+Z<^uf2Q!|&zTHSo^{-Aj~cLMC}eu12))oaC=U352|2s^^FvWc*06Z$a_bwT-DQ&AySoyK55g-A9I#YLq*rXPf5P(hV^Ptdf&ai*|@NnN-T7!&Sh8U?$P{tRDO0Crsa}E<&T+0&ydvL(zTj34BVwu84t$%^*;B5REw|*la_Vn0dbbXW^y7Y_ZDpq>r`!rdRutV%8}7z5()A%wI?dDaPBFXQLb&)$S@L*ASLp93|pOQtzdLX0b9;tjk^EWmo4RtZE0j#;#wTuiRnd)6!$vzs-``WS?;zj%+T*eZ}nW*$O7`sg!vD!7TVakSL(bGvVfJU!bHA<Z0rljgfT{x5vOV^4Mre5hHo~2*4Y5svn=soC{$^l64pV`gmp;_DxSTYK<{PTkXshCcV=O|MxBu$Ou!=*k%~P(nEhm*>6l!-O|kSHnnTuAa8O7im6eUa1u}-JHGY^q%h3{!H<&JE{N#mCr=nC#x_r-9U!|mcE=*E@O^2E$Twooz3uTIYF^M3T6Y#;Fb86SldQ7knhF3;NK>&f68DdWujFE=w}5B3W*6NmnErra2!$jW8uMsAmC0GY9~MM=fwy8gXy}!k<c@fgu2VB+k7gJVK2-mT3pGxE^9X@iVeq*<V*R&Wk{sqa|Nkd6Y^B!;ncBDELwi&6HCg<Z5(Xat0uLO^d(k|8ewEyCV_@`~Hs+VW7s^uTK<8%7e4~BEUzQfbuV(pMJdXNYuFqYHEJ>#GPKbIn2!)0arn_CxCBY^5M<G?STSo1Sxt!Ikl2zRo9v?CBf_WdqzaX|y>=Ah8Yeyw@Oo50_yj(mr8|0Aq!nl9d+l~^m9X`@RG0AOb{Y_GUn(st(r~H`KVinP;O~H#Lc*zHUVk(8@6h*|MKkleHrac7X#73XowtJ~m1(#oK^XmuF%Tyl2Gn-bb__*cZB!dwth>c6}zgkR5>!uf2w7O>+EDd9uGoAI5Z$fp(tYN+0KW=^QakBd@E#n?R&&1`S(r=O}>r1nyr_XRp6foVIb~^H30pfw5V7v)87%_}REYqsTOa=FwY>&1qV?<hNnr+98r33e+S)MA&W`AxicHU=beS{pc2T$Xle*GJ^XuO>uRr_&S-#j;DVC<?Ws#lwWu6Z~LkdiOyrrhd-<LYi!Yj+9~(~;LqJW#Vpnch-+s6guBdCoa5F|aCke{fxo&+1tSsH#1nJHm)hEC?@rDCQl=gE9e}8bWKOk)e_Fc$N<tHWyU3s+o8~;HSe3`k36I_HIZtFo7=i&^11bmhKzT6eUm$bi*!X4VDH0<Ut`f`kUJiaUxv1E<B1SIntll_gp8{Vr?DcLsL<!zC%~$L;-c0^ySu+9X1x^;@YfF8dtzbwly+|xtQS!-|ShNx3VcU*G`vbam}SL27gL^`r^&X7h$<DwISuhjGK4T7uW7*0!2T0ft^y5TIgR5(F_aY(1vEC^<Q|9jeJ(CPh!w!KRtw73|qmc*Tw1RJf3>5J5hbesv6X6EJ9-p=+JH)I~boc2K$wrH5qL|AI-!z>2WSSB9o<4fz#eq!~BE_UGkh~GE)PO5gMJG?g>@62TFs!jfLrU!aNo7(mM+@XqurGo}6E>d|cykJ~G>7XgC@nLy3V3^`aW-aUp&>&-f_y0p6z<y7Nq6(m{)5z^vfh;tQ3D+vgQk3u?2MU7w?JH1wF|cc}@=7AK7yX;5;Tt70^Lr}hlF<;e!lJf=3B1nY6iqur=1M{Yc11-n|sjA*aqb!hn{^59wN$yU~PewC@yg|b+uX=_uwnHGP?%CvzF{w(;_yzF#v2NZ^D^3wdsz1@W)3=f$J032~v)5*tl4AVXxR;HzjaG{KjGp6H*5f)%jLvF~fB?P$-;$6qctRC4M>b3eAFEsCPG`2|70>w#J2CH}~G(FjgT*HU905NOYV3i+NE(n_-_Dpx#vpoPH8C6j;Iw(mo!AX10F#eVhd=^_D^D&yGdP{jo^kR7fbaA;-C^*WgT3&*Ul)Ryw#WR!4CT7O%QI@osi;2(2@_Y0-rTWg=NzK-w20xUj;G`N^_=*#+I|!<dRRTy%oub$fa>;z=4wb6ucu^o>r#|qLb<90}m+-8JH7=U}Ow(QhN%fq;=ib1dkU9|ESnwDrC2bFWyfE^NmTP<<x?=VUs=(m30Sc3XLMbZ_Ajj+MdVz{Q`jiB7{yNRduc8QuM7D}GXU-+0?S;n`ptv)?oUO&Z;`bBW*_~L_zRVhR?W8F;N+t0503P9csP0dNy4ffu$8c#23q}>>CFmy#?IQHLK~F8cFOYxW^$=xo5PqRA?}1J9Y+=_mQO#w)R_R|dSsSAq1wl~sz#nBW^N8V{v(Gx@e7N_r>R!2#rlbtjgVAGxBw=+gwed-+^4)ECE-$}tOHYA^_90nkN_>mt!)chHciYg>^a8WFS#*@O71aDcBwO9jazATDqL?eK0VYPW)J#)=cZf1NxvaylLCE!cA9OrkJLlpq+NEMDBQc9V(-Vb3pXPO?LLy2HSpP>;A@cs4_%owlwxz!eRS$`v|MGL&;XfH8c~YfGM9icoPdHGggIxnS;#1MFh;PNpYCu8h94dmiZwfViL5?#+c{KKKoX#I+hBD;9dVyx%FXU_)+5T?fj0jjoOYwXg{ZKO)6K1uP=}os~sN<{Ooa^r%6=E*qx4ar?vU0w#!jGUIZabB)`Xt8qTst{g9&YR}^1-m1mt+|@kv{{Vz}doYA>x8=7fm$fKmfZ<*2vO{+wrw4ofKA6th@~0<Hfoq?`8>>BB*?)nEoQ?5PK%MItIt)HFj>>woio&6$wyeU<}oU6B+SRJux{0KHpnk>uEF;HQrQPiVl`UB~q>BNq<Gk)Jk{@)20By+op5+y#_F}u)PMD>E2lN#jbe)ABHj5i-F|-i|K95K`p~7pW{JXI%UxYe`6p5FrQ1=*Jo2=GB->&8c4p8rnDo+mW-b?72_t34($5nhdX!Rp%j2YI<^ABM{JZRJmFXD%-AbdAdk}Uuv6F)=a%RCnm(Y?Zx|&n{Sq`xrc`r*Sg3X#8R$X9U|>F=B0R0HhbmDwT7KQDG0oiE;H8uiz|B>(T}o!N{g6nPt<4YK)SfKa!=DA_8;w%cei>$3HNMaKzhf{CN7AVqSG&xpt>|NGQt$Kd`0X>?^LTHV4CiP}%<ELdFg!_bo1)<$DhzVI%S|%EA=*m7YIP6)T)-uJBeQKmBYp<-%bWjnXN0)GZJT2uRxn!2R{E?s%%vb)sUIZE&xMs7_UHk$Sa_Ybu6*VFN|BrY+>=P|?l8ZNHBGknf1@Nl#4bfn|K^~OdZq?1`0PCb8xKKId<%LTp-x>$gQyYi`S@3Y_A#32+X-Rc%R!qBt+(Y!CZ5GT={_qPBJNP$+<|9YBsS6+xjo@g?3hoF$Vja1k-?iKh`8ilW7n9#SLq#WikA*gMQ45APaH$5BwQ?nw`HR7+G0COCcs2XSO#T<ffDcDh2XQ?<5$ZSg{1mY4_h(A_9iqxd={36SNeIi*r!?(1O38!CxLEjN9D~b#%*v3j%2lMX%CSVGp3fDMRu>Fa@fa5MsFJ~f6h^VyZHD)66Y3!6|`E^5{fKDW|z5!dVVF5m+;f><?qPu&noz9P}!1OOk#7_Sv_&Y89m#LF~zsttCXmVy{WyOV$QnVlBObzcANbAam2oBe+uDEZI%f)K(llUN^#Nwm>vn1jiTCehxlU#n<JB`DF24JFAYR@RYA;*@y<@tUXdu*%uLrfn}yT10;T7Xk;t|fe{MFV*XP~Dt3A>b>6$34e_K7#?05u{l|HP*ABvqjC@1yZy!hjhr8{u@>W;}Kmt^&gSKekZqEG;#4A~T1INV62p!gZ~KcCle3kewlpo(_Gv#wS|iuD=x7^|8)&Ixf#I5*2w$Nth~dGQ_b0LmV8%@mN%y#sOwWb$8o6fUKEEMZR*VX~r20GejaRz-;fozIu_9^x9epl8>{E)LsmfqZKAyr3#sv)ox2K-ftK`VRFAwe)}{dID5<be_l(4NN!9a2pp!ug_S=_as{>jW`GYXT|_nVnwhKw_zAH;&0kcOc1SKirQD-^bDi_gH!;|RdT+#RPPvNV094((+JL89V*`kEXqLX`IYuZSD&l-I*I_Y{0gBdaog1}b_e_x7=n!X!Y5lj0F+sC=-2@B=!td-e;XwbQ^oCFpA^~qxUirgJ-W@0K#BvDc>8U0o%$_ty-|1ZO5Sba9+3ByGhdB&I;@*EjGy>)iu=?kognfPwr7>cy7LBSj8r1O%oczdp3K0=uwQgEQ9k74(cd2F&ur9A^%*66i*<NI{xbF_*{z`6j=6!_);a;pP_SW)+@SxBTFYWt%}-XT&HIZ4+40$XK>O>DXe2+y5avTUz9!;iClXFh(LVhVf}RRtS){Kns8muaaq5Jszy%1!?UHQRb0nZvTB#WH-i<&HzFUn)<STWMbJ9H{SD!p4vOF0KE1fkA!a)Fzi!z}puGH#;4yBxhx_czI=B}H0!DZZ;&s$Se88Ua551C%>Ji58Cjxhm}f7|ng(EGh$3rjEjQ=?c`H+9y@5DJ7NBW9KV@!K7IJZllYGj9t599JrR6DL_4w2PUi<7jQ8^eDCd0^{2Hf{(jtDq$MSdK+x*8uvhOI|0Evh6FWs_-kcHM?~jOb%ylf@-0hg9=@wVlwdV1df@D77t;;Z#n_5@8hDPmU`1Lc)bwm3v%#&dq%1W2I;)?`chtXT%zFgBpVzBRB8nex_3kqwNzw$p8HzgZVBx$2=&&!Fag|zpl#yXE54OHV=y1f!q7KR-l6eU(>1-!Zk@Qz@c!0m<Sk&^3`CcZ)Wla>&eJ;k6o{-6-guZtUgnJ{_I!zCxwM?+$(=Nj`Ncyg*|M<<M6NM{x1DHt3?L*9=3gegZ3#=W-Onds-#IVJU<;DRSFTAM1o?I{C+E+(0v3tn+BD^@ohJ16^4MZ0x_~M6>?-@oGZp0K*hEVIlHQzmv>b?qzHsz>ym}}>>n;6;#`-7VQvv+Y*IRsCn@9-ZYgye=({A&08mH=|CV)}h<`o=01?Yz3l8<tfwQ<GjUQb5s&oSf@DpxV%0>b<Ed@|<3%XD*Wz$m_IM!NWw67$l-_5IfAw?vIt`MZ!aMAi*$G@|T(u8x9=cBqu>Pp?MA^T+Igs)oeToctpT83lf-^N#(e8)b(X)3*sf)(He<Eh3EKg!bw?Dm9G*>g5-GvBJH|AAdZ5%v-2>aL88MJc7hvDeCFR&h=8tj5><UsD$uq)0%O%BXG=DjpB4!hC^ETZy$RBFz!sT=yIcX6A8V4%Ayq(nJ)MdZV}i9n`JEMChqzT{20O)>a9W@25Qo@MArDSIr35qxYE3^otV|QeT%a2PW*Y5@+0jKP+BE!L7iFL7`TPQL?GX0KC25mGjA-`w*kz?TdabL?o+7E*Z}<Mg^-*A+R_nXog5l)paYZ5AL%#|4)Vnp0=(Yawgt;xsa{WI{6At-Xzi^6*;a-r5tkw@q{p$Bj^D_<Mer=D`^g;Eks@a@+<;v8!j1nqO4z$E|&asjZrdH^;>YFpFU^!Mwosw9y*XlsMu3GvC50B-T2K*(=XTgbUIorZF8L_D7NQ?NeJpn*nDg+!;ygBeb*1@uFk&496Mh3jnW{P6(z16!j?Qx_Dah(LL|H332qWMD6&K%E3N&AhF2t=ft)C>>{KixQS5<w8JgQTsbEx57r;YyR5)(1UIFV?=!yL49c{N5dtie*wTkdysN-9Yqtd+XH^jCD-avE^b+qu6t>O45^6fHkDH4M&@3n6vFLNo{|b+nO()#L7TbK5|ae@T5)PoueGLpTX939h6dOtdY|a83*b6L^aSfE)z~cw$b{Y{g4DUnCmjK6`OqO$5Y3Es_7ZJ+-Rx=a$7{2_&-Pw`mA%YZ-jS4qLBrFXsHy4Z&>sL>spn!waXq5N>L)B1RUH!P@lmW$kbmo)!ojOEsbP3)n<)gT;R+d?j|TIy=7G7PlAe}LD|UO4;;%HdS|xH_GoQf2mS^p*aWeO0Sb9!S6-%6o%`&5wiYR_(P|Ja9^U55q70K9m27`Sxaq?#u<AoSIqs6vBfdU;W5i*1(SdIB1Y&eQJiL^$*v4P-|37R;yt)mTNx8u$_7fmK*Rj&5sv=Y+_4R$b+LR>|Gjfjq;-}FvF`Y4@oMV7OIT^27jKP>Y?!x4hKz(BgqKR>eZrF9=m>t|%)c*FL$P@$(D|8-=nnq@hIsKs{1~NDnuDEA*Dd_(t4GVU;)q6=e^x7Fh*RiV4;g{vlColJSgbX%d6}1$?*2K5a7s;DQMlG#?S?83eH_`7v?6SPHg*S7nVk2=T*P#Kft<N=d*Jyj-Wb+Ws=M4IN7SyI*mV(1L2;kxcVilk)w2~x)LcZBh&9xK$-KJE{kSUU*+Q=2BeaMWo!<E_scg+Z(tx|klZRt}Q?XxaoTb$R9rA!#b&MO;Dtw+m8Rc*|S9~L1GJNe)%9TBfyq@q^NAN8Q4cDoyMz3!aQJq$nSL9tfA0H2Zk-#gfy8O8h;o%gaDi$+JXzsZDO&PyegZ`%MzNJ{<AjrW@m#i`@-mt)*UViWdKoSku~IhQv)QL{a-^~B<z!0e(55H@6A#u=-o&t-I}A|O?1venaPAJ)6${S19LgFaVtQ*q71OkL(Kj4fO9m&EERKx|~R^Lg<y@m{WYws#V}_z=nPYok{h%-+B`d8Ec_8Sp;`rWBtr8j3G$%gbSq!|E4J=h~dJl4wfS3-J)mlR!`oh22!qOVDtvAb$Y6d+3f2)k7PNKBOb+Ge1rX-i*%iO%O!>J^nKo0u9Ti`5Y#YRld*4%Td|^qtEA7*fPUWl!(k(L0d{vaIrR1_h^O<)bYv#3k4a25~Wv!l<XCx+Y+)!`lxgK*5;wJ@4ZVU>=o#q4J^Ve7O-Vw2)~qXK^6v|P!bQ(bYNK_%ITFLCA!QF)l0y9A%vki2_s6<<1oIZBQgUvTet#?xi>}lF;k8Y8*f|zACAb74Y7$M$XD}g@G~Y47frn*FJEH}duk?MsQ-VjV38s^HZd;Z@w<m8-+K-PZEGE9qpB`XyX@nX!sSK~CXsnpIdzR@@nc;cGMqmG>Nz_8*ls=nL7q=}h6%!!3e#H6I;TDZ8Bp4Nqx+sY$a5&XHW>1s3w(%UmXc!<ra_7s)1f*jWozZ%zUL*4fgB)FvjkavA*K~nzy8+T6bkGiem)0A{=;C7V-;t((J6`V%Jjt?(4xI<2=-0#T7VkshG}BV2DJl1f6crIwhf_-ntK<P#e71{qk}O^fV49F0i^C7s<?RzB$O%Ph@M>}X1N^+&2LhNJw1*Tisz$>Ai%wPXg85S=b~@-=`lveblenP+`GSx0AWqeW8{V3=InR_J?hdQg8N|tLe<Mm{Fw<8V5nM<Wq_7tk7_F=RI<#^<B-GLa-FpGw^S?Yc+D^2PRLTd2V?V5RI9EUdNhD#c8L9Plhzyk_7x_oT$IgYLqv;0xdEk>rGN!7SN<8E{LJ^@ksGN{LN%FUR?3*JA=!{L0g3r}K>;dSji(ocQq+46Sdf7VJ~Ki{7tS+WJ<VPgzdrDOCqS7aqK|af%#itgIm66Z*)H4)SUR?QNvWht3OC2OM+3PLXT5B1P`^{0JBAsD9#a+?j+>UKBaMntkCnF}1u*NE&ph|-o>-Dm<_koudY6RgtXk!;bfM62s@(q7C2j2Ke;`H8{x2Q<+plKK56a4&9mICAcj}09O*k+!8bpskyhiD~Bs$%DE7W}<gsoOHf^|pX`j7cT#r`!n6<#hidf621Sr$LW3BPvT#>9xa*VV*@HS#1%<`@&#tjD?Ia>d1W;pPWm`w?t3y&~<W+0+2iXzU;ni~141`L5<GKL)|50(a{<vjoE%J9BGmR>UdxoHf@n9SiIl(ry`N&85rQQ9~#Z&1no&{}E<pC0vGJpG+2j;(hxAdPt9B`B>$Q5$j}Zk5(=n{YvXFO66vPRcETp=@Fe4UoHFebHdaDkn6_iSkwL%n*$anrq%Nl<}e?aFh6_U^n;kZ68YZV<(7SgW83-(9KNao=GN#)!Z!9^oBC$MJ~+6rT-77gB9rJ#ArYV})4M?w)J1A+LK*p=-8BUgmlb8Qc0Ibtm#$C=nmTq~KOy?Iv7k1aH)V`N$>Qp*m1<*wF6P{D!)*;vAR~*|b@)(!`m6eWFL9FiqGY}9a*)FPb>s@LWblu!@+#<g*u(?smn+`+_s1xc*ul0vAwe3Z5wHp4z=PuqfkF_xr+<b@NuBW#G0e?N4q|WhPstRNrM7pvR<tU5!Sx+$<nuq|z)3>>X!`gYSh#*~8U5)a_lZ<bJo2n@-W<^K{iADNs_BjuZPHSU#Wk%Vy(`nL3Uq0DLuUsqz9%V|yXcewkPk(`jR<tIOqa|xHan8YJ$OamH!~jnyg)xNI0Du2oXcCq9+3E}hm{=0oiIO2-&S|GyLna8`Co&rx}GSMvl=lLP0?oBJa5CW6uSU-0%f~M5kXSsSvaT}MweZ*lXrpUd4F&d4YPWkg8zQZHL|EdsS>P+MlMKuE0A0p%HdaYgVWig5Ze-z)qk$qXqQQnz^0`SQN%1uS%?okJm9hv<CyGg$tUO35!CE<@)8x`5iP~?EN4H*{EU#x>lC4B0MBINIR@?eY4?ImL7>~kq>0D*Zm0yW#(eUKLU7NenKrP_WiBM`&D}fH_s-UGY#)BPr4J--obPY4+1xVimWrwt3dTqUsM;|?9OKm`mQ%UC{35NRNk#Rhay)3T6xY=Q`00}Rwz@p;C@5HN((&W?$(w;Zt?sMbx^Bx$b*cdW_vPo+GuR*_r9gxd_mKn^gutURcwAw0e6Y<Ap~Z2$iMKY46rW<8kf)3GAJc^9SPO{x0tES2{sJhiI@E#E*t5G5vtH}hrDsf;<qMd0DKb%yw8`~Z=5iJ>I@JyeBE~MBX5j8<cKZFx|36`~6aN(8%ykOLCBu|^s^PzS0-oGT?{6(2LL0F8gOh>1SIxCs4O2bWtiq$S#Q44PE}pp2(sW(OTz*J-QEeDrGf~{JHi}fn^Q_FpGex;)RAXaTZ^KibPX8|A?M9HhML&;4hv=ag*C^I>E`L<AMk@4S!=J_E=cW<GL0J98Y5TxZlOoh=q?>Bob}DM=@5a&9S|Q^hHf`~wJYaqq-JsopfBQ}hS)`olRQW+IM1b{isQ>@{zT+{sDIh=1C7PC$e#mIV2A+Kl+fOsop`Z@UyOu4$5mw<93|@H8%*Eb(ERn7!Gaq&5k|=QR1NZZw+KYCruCGA$rL!Dx=Ejde+;VOFGjC|No6+_oRJ?CE`UNp)FVA2!fNz`@A8*J&zQBo=szQ0mO3H22u%b&0x;k`LZvpX72f2rJ?y4-<B1}}7u>ymlAHnn#x5wz6PkeMK?}lopMY9N(;9ZzOM~lV1I-h9>!Ptsn#xD#3d+S=R3TgXLF&khOO6n8M-j|sFC@{pY;a7SSD`NL%REr}P^5W40jDPAPM;3nL+{+Qz*s`prFbZRLS*{Z~qBHz=@68dQ6X>^%g6`F2F?TBZq4r8qA~Z$vA)-I{z{wsZA0?(EU5CX+ljnLtNO<o7GE391Uf^}qiKX<Z{Faq;l0-1DL`)WiR&c$n9Z4CnsX{s-GeDdBSis!SVwFWoI>I3Knito>IDZMSO%+UaZWuWz>lxa950xSVNWSE+S>SIv#mBAf*Cr%BzkG>~=(K7#gw>n}M5U<XhyIT<E+B^(*Vu`H>Q?{bA#Uu(sVm{|1gjp^`}+JOAhoM50B6?#pI?PqAjXO)SidCG_$P262`sd8XzFp$yxtVFw9RtXVy|}Ni1}LXyxBlaj@ueu*x4KSg%Vq9iOO%t`UU?<KT&i~bPDH?HIz@)J(!=tOIRH@M0Y;+<ANAfKk}ItD>xR@jE(iUNc^k#T0tQvR*yATymWSydBCgfOIjaF2Z=IkSCPESAOd&T4S;|Pp$xy6H11L0U=%v=rLi8`9F^GoW}GS3;UdNrz;Lm}#v>RRkq?OqUarl_>g1b0x~hVXG^<s4(BgY-(Rw-gN<=F!(s6T5*p;6GJ9cP`v`Mm~O79Ma^RSZ%Ibv+`8>dFjQ0B<{_)mZXr{Q4AAJJYRydfMlEQYuY*f*2<0vMQqenS!E9attv>gi$jY?xibf@2K8)caPVi&CdcHue}vnLrhOo{39wojn$i#c!gFFK`+$=l6>15A#>tYi5`V4h`m~)J^ZUYkb)}o`lMh1tlSQRUc>PE$o-osyZ?QEX~RX{<qBwMdJK9#?cL_(wBi-1|U>PP-t=0u<xU}eaChUY+dGZ;=x)!M|69+s5*vPFJw!3)-(%@-P}Bv8nOoAQ~=<<)Ts)iWGO}5ueA<3M(x`2ilr(VsP@s!rvithkE@sncQ@hfJ5u8c0Wa7wbW|Bb?Q&ds0owYsYtNj$5#W4&O9hZc*44Vf{?c6Fjq;4&QvrEq`ekbib|2~kL>h8sVFcmxwz%~0jq$-K+<yy?Fr^Ap(`5(y)(C<h8u|bN$|&JNQjucv!=le$sjR9GENS`sXEqI$h5SZCA?%}C(B!Em`Vq$dO>2uZXqk<+vM)LZGw~AcN4$p$AU@#V*@5RMb>9<8YhefUdexYo7@-nraznCTMZ7Kuec*!cSqC9x)vA=ZpW(<hcSx89;{&MEJ51B|bw-XkflunSdC?>(H^TM5jF;}AWG?R`RKx(MtiIt160l2CVO|7qSyQq-Akk+ycaA4+1XKKxgN|YoiQ(L@(v~gQh}pL5ztsI~E89Z&U$>22(kCHmEM;mlMjGP`H;a5I%j(~!Je9kN01T|{r&5C5tzE;bjnf&a62H#}c!>T+xiUoqcFG$wt(>H3T9Hz1pvY*pF;;%RG0KR<4)J>xt_NJ-PZrm)G9exz)acYnA$FI1Umn~72dCyxP%o%G(3`-uH2wS!<*cVnjHjU1>SX>cM=M**FB2MR_%6M+I!hm?x8~?p(c@3iI25E!0umG(21Vv6S4;-GDP#^0^TFDA^eoU@+E#-0kbabI9U2vtp+^nUKvb%g6WOOJE<2*rs!>9K`Qee3FMZ#x3RG!57P7(!Fm@IAWw_gu_NI(vcXbSrCO>LuL*@*!;g9ZjE*M?wBl8Ti|CTS{jm-3=`BAdU{Wv39h*!2-mcmJcrTv_?XF!btuiYv<)~S5{GP)V|LX{*%4^%@BfO(%FA#U2c#{U&hasn*bey)6IL;2O#txCq;z4g2qG`H<*J2Qj0x!noj`5g4=5e;wkhs|T!IwO+mRukhw7NST&*Bu`up}-VZirpD9Y8b-i&xOAOwD2BrKrEwev;sx+)m}+7r{8XEYkkm%OJm6e28+3qYe;-*`PbR>5boP|y`6vuQ#6(jR{C9yXJ>ULHi^!Wg|=V-0-<@O9#v4q6x6!EnW0_~SD_U`<$R}!XzQFJk#l!k)_>vQC11-ouOKBXA!%@W5Ef-6f7Aa&Ofa|K_36X?b8%`kIc{5_9+*oCob}>quL~U?bWk|%uXgT}(R1rNZL6TS(8R){EEFj-IS4OP3<<*MU)V4u3a+{pZ+$++H{bLvCF`p^85s`z4&>tO7Ssbxz({WZPYth0P5S@=v(0dA-d8@_Q!@_b^gOl()8ghX_%AqURNP!Aq6@=9nnKf2i~T#avX3IYYNTZo6^x&d_ZoazxtZf331Kz0IaRUW>pm=)6hvo0OQXV4nN*ni%f3yrcNW<zs|4j97ZWZ`lN%sXSp=lTNzHRM?F=yPyTA~S=9Do8bT#KkeGTd4FX3-20sd!j;u#WS7QvpwOw>-Ron$^&{WjB!Om&YKQ`Iw&Nf`$^-qwAt(|qpQM+E`ye^YuEC-VIN=A6XWjw9yq*uq+?S9Wzb83a-=lzQl#{gp5VKGskc{F=)Sf|fJTj!|-eZiF>quNZjn6vXYY0y0AfPrj2fo(Wh3_0TP$I#794EJLXg;7TFVgl5d3S4h=LU>E`aoA64HuF9|4L1a&5e6JkfH;5{JX-iey(7nC*>_@Yt=ONy(B^q0J99Rc0r=hfUp9$hgXKGjJUnL=U=f!|Yjfizn;T^Tal11*G7tOP~N`SIb0|Ic4$e?+`y4~lWRHYD)<cU)Ow@He>Tec5Z*TR5eJvpE6`P+aB>`~u9tz=LE(0zWh&|CL7oiH_y=1`#dP;`_Cx#G*wXzaq-L%d3v#&;T|teU>R2yS1xUn>;P?}ZJMI(*y_WI!AsOF`FDnikme|L=(018}d<G5_xQlSv{ZH3ov&LcTOtaJ3lr<R3`^uIUWC4zPHZySmdcd%*;Q%xpW1lSOLXN97|xRfoAXLIwgqXZf3Fi{Pu9ey=ila`0hfp7TmB_Ry;Qi0xuEaSB4#S-kSi%8^(R$dM!D=f9A-p^Cu$1gf=o+h(v_j4%dd4isvhmkW6m_9#`-G^;C!x*!u1EII-DiA}ukdMC=?F~cW_!XBLlg~Z(okBkzg9f~0Q$OzlRD}2HB%@0pleG<9#yUcFsZ8h&_MXD2c+Lp-(6AE;7_78%8cOvQoHI?`AQr_sB!0qAo_pl9LoQ3jQKy5}h{1I4);(HXjLyj1mo=5iNX{d575oee32wpCrv1xT#+%M~84fg&ja2rlhuX3OrD0Y1?te_>nfMnmVuPz%~5Boidt)^RzNmINKYCH%Xl`O*-irGa|A`(eUf8QZesf3Okh2Ug<Bv(_*Z~;zB+=AWYf?+!3ggBzlbVf;1N$2`VhV<o@REW6!Pg4!Fv}~V{zNvA%T%?**>JVFuoGm@<#?$r+fE7R}pmZt>+FY~NFHw9j#w0wS=Uzy_W7Us`bDV7CY%LMGEoA;-s7$0EKp&o%2L$DbzhcQ%2+6{v?af;<d|@&hZd7H=@^Rn+!vYLlzDwslYCrsOUQ*Isd_BD3$d)UehfD(z6h;8rf}35vj}zWPeTQW3CIwH=EjdZal!`DdPh~jXFPKpG$UX7FC`tW^OV4dz`6C{$553~+mTYG?+$JTqp*yox7`#V*nfvYM{H6*igJU@;WU)Ew%fUETJa<v#dPvXxJ;(eY!JhWXsM!x&O-yCbK-`(&fL(rW!3Z?9bE)CqH3VGyHGtn}-mEjk`@;=%Vs?j&-LCD~le=c(_xnc>$5BXkyn4=>l4H0~cQ%KSLCZno`y})J`pb~N<yLz>(5ym@(Na=H|4Q74`r#4~OC)Os(Ymys$Z~keI|Ac)eo0rrs45Rs0XQxXG>ISG24bFTpO`OA=bk&$q6|&Jxz<cV9LCl49=aT*+o>w%M+ymdtAr~45dF=;B-Q~nKP%A!>JYL+oUh~(drmjsELl=ABljuMwA?R3eR}lpZS}CNfJIbob4&mL1Uw708&{ee00FbF0gUbhyCQ!&vBYQl0ssI200dcD")
    if hashlib.sha256(NBDF_BODY_SRC.encode("utf-8")).hexdigest() != NBDF_BODY_SHA:
        raise RuntimeError("EMBED_SHA_MISMATCH: the CELL 7 body")
    exec(compile(NBDF_BODY_SRC, "nbdf_cell7_body.py", "exec"), globals())


if not RERUN:
    # ==================================================================== CELL 8 — report + the identity fallback submission (E18 R2 format)
    if not RERUN and not os.environ.get("RC2_UNIT"):
        write_fallback_submission()
        def _arm_brief(k):
            r = _arm_rec(k) or {}
            return {"status": r.get("status"), "why": r.get("why"), "correctness": r.get("correctness"), "quality_gate": r.get("quality_gate"),
                    "oracle_vs": r.get("oracle_vs"), "long_gate": r.get("long_gate"), "smoke_gate": r.get("smoke_gate"),
                    "prefix_gate": r.get("prefix_gate"), "al_vs_q": r.get("al_vs_q"), "short_exit": r.get("short_exit"),
                    "oracle_acceptance": r.get("oracle_acceptance"), "ingraph_meta": r.get("ingraph_meta"), "prefix_reuse": r.get("prefix_reuse"),
                    "memory_gate_ready": r.get("memory_gate_ready"), "memory_gate_first_decode": r.get("memory_gate_first_decode"),
                    "pin": r.get("pin"), "tries": r.get("tries"), "ready_sec": r.get("ready_sec"),
                    "env_readback": (r.get("env_readback") or {}).get("why"), "config_readback": (r.get("config_readback") or {}).get("why"),
                    "dflash_readback": (r.get("dflash_readback") or {}).get("why"), "dflash_checks": (r.get("dflash_readback") or {}).get("checks"),
                    "seam_inert": (r.get("seam_inert") or {}).get("ok"), "q_readback_final": (r.get("q_readback_final") or {}).get("label"),
                    "q_defer_shares": (r.get("q_readback_final") or {}).get("shares"), "kv_layout": r.get("kv_layout"),
                    "memory_stages": r.get("memory_stages"), "capacity": r.get("capacity"), "long_levels": r.get("long_levels"),
                    "residency_retry": r.get("residency_retry"), "spec_log_all": r.get("spec_log_all"), "graph_counts": r.get("graph_counts"),
                    "graph_spans": r.get("graph_spans"), "stage_compute": r.get("stage_compute"), "parity": r.get("parity_record"),
                    "windows": {k2: T.window_brief(v) | {"prefix_hit_rate": v.get("prefix_hit_rate"), "garbage": (v.get("garbage_review") or {}).get("gate")}
                                for k2, v in (r.get("steady") or {}).items() if isinstance(v, dict) and not k2.startswith("profile")},
                    "responses_saved": r.get("responses_saved"), "launch_error_lines": r.get("launch_error_lines"), "error": r.get("error")}
        R["summary"] = {k: _arm_brief(k) for k in list(ARMS) + list(ISO)}
        save()
        _v = NBDF.get("verdict") or {}
        print("NBDF THROUGHPUT WINNER:", _v.get("best_arm"), _v.get("best_verdict"), _v.get("best_gain_8k"), "|", _v.get("why"))
        print("NBDF TABLE (tok/s, tick, AL per arm):", json.dumps(_v.get("table"), default=str)[:8000])
        print(json.dumps({k: v for k, v in _v.items() if k != "table"}, default=str)[:8000])
        print(json.dumps(R["summary"], default=str)[:16000])
