"""E27 NBDF Kaggle CPU kits (pinned Py3.12 image, no GPU, no internet, private; account foysalemonshanto). Pattern: the NB4T
kits (build_e25_nb4t_cpu_kit.py). Each kernel is fail-soft, writes its JSON report and prints exactly one line
`@@KIT <name> ALL OK@@` or `@@KIT <name> NOT OK: <items>@@`.

  units  q27-e27-nbdf-kit-units: nbdf_unit_tests.py (T1-T10, incl. SeamSeq + nb4_ppack on real copies of the Merlin files
         and the real NB4T Q worker record) and dflash_seam_tests.py (the seam agent's 520 checks) on Py3.12.
  real   q27-e27-nbdf-kit-real (the 7 RC2 Models + the drafter Model + ARC): NBDF's own code (RC2_UNIT + RC2_CPU_KIT) on the REAL
         mounts: CELL 0 identity submission; inputs, merge, full sha256, prompts; the drafter gate on the real mount (pinned
         file / embed tensor / mask-row shas, no model load); the real Merlin install + the flag-source shas; #60490 + the
         extension; nb4_ppack + dflash_seam applied by the notebook's own calls (three-state check, combined_tree_state);
         launch.build() + host_phase() + the NBDF launch check for ALL 5 arms on the patched tree, each env read back in a
         spawned child; the argv fields; the spec-config preflight in the Merlin venv (every key a SpeculativeConfig field,
         the Literal values, the backend enum, draft_tensor_parallel_size unset -> the target TP); the patched-model import
         probe; the drafter loaded-weights probe; Merlin's get_kv_cache_configs on per-stage specs (Q calibrated against the
         NB4T GPU record: 215 blocks; then the drafter group per K) = the KV gate the notebook embeds; then seam + ppack
         reverted (pre-shas), #60490 / extension restored.
Run: python build_e27_nbdf_cpu_kit.py -> D:/ARC AGI 2/_scratch/push_e25/q27-e27-nbdf-kit-{units,real}__foysalemonshanto/
The real kit's report (nbdf_kit_real_report.json) is the --kv-gate-report input of build_e27_nbdf.py.
"""
import base64
import hashlib
import json
import lzma
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
E25B = Path(r"D:/ARC AGI 2/experiments/Experiment 25 - Flash-Next Throughput 1500 (planned)/Experiment Notebooks/Build")
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(E25B))
import nbdf_lib as N  # noqa: E402
import nb4_ppack as PPK  # noqa: E402
import dflash_seam as DSM  # noqa: E402
NB_PATH = HERE.parent / "Q27-XHIGH-E27_NBDF_DFLASH2.ipynb"
NB_SHA = hashlib.sha256(NB_PATH.read_bytes()).hexdigest()
FACTS = json.loads((HERE / "nbdf_build_facts.json").read_text(encoding="utf-8"))
assert FACTS["sha256"] == NB_SHA, "nbdf_build_facts.json is not for this notebook: rebuild"
EXPORT = (HERE / "nbdf_code_export.py").read_text(encoding="utf-8")
assert hashlib.sha256(EXPORT.encode("utf-8")).hexdigest() == FACTS["export_sha256"], "export != build facts"
MERLIN_SRC = Path(r"D:/ARC AGI 2/_scratch/e23/p2/merlin-src")
NB4T_RES = Path(r"D:/ARC AGI 2/_scratch/e25_gpu_out/q27-xhigh-e25-nb4t-levers/nb4t/nb4t_results.json")
ROOT = Path(r"D:/ARC AGI 2/_scratch/push_e25")
OWNER = "foysalemonshanto"
IMAGE = "gcr.io/kaggle-private-byod/python@sha256:37c64f7dd9c54116ecd1bcc88817c5469b88387388fade02bfa8bf3fc647d461"
MODELS = FACTS["model_sources"]
SRC_FILES = ("tools/merlin/launch.py", "tools/merlin/registry.py", "vllm/config/speculative.py",
             "vllm/v1/worker/gpu/spec_decode/dflash/speculator.py", "vllm/v1/worker/gpu/spec_decode/dflash2/speculator.py",
             "vllm/platforms/cuda.py", "vllm/v1/worker/gpu/cudagraph_utils.py", "vllm/v1/core/kv_cache_utils.py",
             "vllm/v1/kv_cache_interface.py")
SRC_SHAS = {rel: hashlib.sha256((MERLIN_SRC / rel).read_bytes()).hexdigest() for rel in SRC_FILES}
SEAM_TEST_RELS = ("vllm/model_executor/layers/attention/attention.py", "vllm/model_executor/models/config.py",
                  "vllm/model_executor/models/interfaces.py", "vllm/model_executor/models/interfaces_base.py",
                  "vllm/model_executor/models/qwen3.py", "vllm/model_executor/models/qwen3_5.py",
                  "vllm/model_executor/models/qwen3_dflash.py", "vllm/model_executor/models/qwen3_vl.py",
                  "vllm/model_executor/models/utils.py", "vllm/models/qwen4_exp/common/qsa_cache.py",
                  "vllm/models/qwen4_exp/nvidia/model.py", "vllm/models/qwen4_exp/nvidia/ops/hc.py",
                  "vllm/v1/worker/gpu/model_runner.py", "vllm/v1/worker/gpu/pp_utils.py",
                  "vllm/v1/worker/gpu/spec_decode/dflash/utils.py", "vllm/v1/worker/gpu/spec_decode/eagle/eagle3_utils.py",
                  "vllm/v1/worker/gpu/spec_decode/eagle/utils.py", "vllm/v1/worker/gpu_worker.py",
                  "vllm/v1/worker/gpu/spec_decode/dflash/speculator.py", "vllm/v1/worker/utils.py")


def blob(files):
    return base64.b85encode(lzma.compress(json.dumps(files).encode("utf-8"), preset=9 | lzma.PRESET_EXTREME)).decode("ascii")


R_ = json.loads(NB4T_RES.read_text(encoding="utf-8"))
Q_REC = R_["sections"]["Q"]["nb4t_q"]
Q_SLIM = {"workers": Q_REC["workers"], "pool": Q_REC["pool"], "env_readback": Q_REC["env_readback"],
          "config_readback": Q_REC["config_readback"], "status": Q_REC["status"], "quality_gate": Q_REC["quality_gate"],
          "q_readback_final": Q_REC.get("q_readback_final"), "free_after_ready_min": Q_REC.get("free_after_ready_min"),
          "capacity": Q_REC.get("capacity"), "pin": Q_REC.get("pin"), "not_integrated": Q_REC.get("not_integrated")}
UNIT_FILES = {f"build/{n}": (HERE / n).read_text(encoding="utf-8") for n in ("nbdf_lib.py", "nbdf_unit_tests.py", "dflash_seam.py",
                                                                             "dflash_seam_tests.py", "nbdf_cell7_body.py")}
assert hashlib.sha256(UNIT_FILES["build/nbdf_cell7_body.py"].encode("utf-8")).hexdigest() == FACTS["body_file_sha256"], "body != build facts"
for n in ("nb4t_lib.py", "nb4_ppack.py"):
    UNIT_FILES[f"build/e25/{n}"] = (E25B / n).read_text(encoding="utf-8")
UNIT_FILES["nb4t_q_record.json"] = json.dumps({"sections": {"Q": {"nb4t_q": Q_SLIM}}})
UNIT_FILES["drafter_config.json"] = Path(r"D:/ARC AGI 2/_scratch/dflash2_drafter/kernel_out/bf16-embed/config.json").read_text(encoding="utf-8")
for rel in sorted(set(SEAM_TEST_RELS) | set(DSM.PATCHES) | set(PPK.PATCHES)):
    UNIT_FILES["merlin/" + rel] = (MERLIN_SRC / rel).read_bytes().decode("utf-8")
for rel, (pre, *_r) in list(DSM.PATCHES.items()) + list(PPK.PATCHES.items()):
    assert hashlib.sha256(UNIT_FILES["merlin/" + rel].encode("utf-8")).hexdigest() == pre, rel
for k, v in UNIT_FILES.items():
    assert "\r" not in v, f"CR in {k}"
UNITS_BLOB = blob(UNIT_FILES)
EXPORT_BLOB = blob({"nbdf_code_export.py": EXPORT})
FIXTURE_BLOB = blob({"q_workers": Q_REC["workers"], "q_pool": Q_REC["pool"]})

HEAD = r'''# E27 NBDF CPU kit __NAME__ (pinned image, no GPU): see the builder docstring for the checks and the verdict rule
import os, sys, json, time, subprocess, shutil, runpy, traceback, hashlib, re, base64, lzma
from pathlib import Path
T0 = time.time()
KIT = "__NAME__"
INPUT_ROOT = os.environ.get("KIT_INPUT", "/kaggle/input")
K = Path(os.environ.get("KIT_TMP", "/tmp/nbdfkit")); shutil.rmtree(K, ignore_errors=True); K.mkdir(parents=True)
W = Path(os.environ.get("KIT_WORK", "/kaggle/working")); W.mkdir(parents=True, exist_ok=True)
REP = {"what": f"E27 NBDF CPU kit {KIT}", "notebook_sha256": "__NBSHA__", "python": sys.version, "checks": {}}
def save():
    (W / f"nbdf_kit_{KIT}_report.json").write_text(json.dumps(REP, indent=1, default=str))
def log(*a):
    print(f"[{(time.time() - T0) / 60:5.1f} min]", *a, flush=True)
def unpack(b):
    return json.loads(lzma.decompress(base64.b85decode(b)).decode("utf-8"))
def sh(name, args, env=None, timeout=3600, cwd=None):
    t = time.time()
    try:
        r = subprocess.run(args, capture_output=True, text=True, timeout=timeout, env={**os.environ, **(env or {})}, cwd=str(cwd or K))
        out, rc = r.stdout + "\n--- stderr ---\n" + r.stderr, r.returncode
    except Exception as e:
        out, rc = f"{type(e).__name__}: {e}", -9
    (W / f"kit_{name}.log").write_text(out)
    return {"rc": rc, "sec": round(time.time() - t), "tail": out[-1500:], "_out": out}
def verdict(ok, recorded=None):
    REP["verdict"] = {"checks": ok, "ALL_OK": all(ok.values()), "recorded": recorded or {}, "minutes": round((time.time() - T0) / 60, 1)}
    save()
    bad = [k for k, v in ok.items() if not v]
    print("VERDICT", json.dumps(REP["verdict"], default=str)[:6000], flush=True)
    print(f"@@KIT {KIT} ALL OK@@" if not bad else f"@@KIT {KIT} NOT OK: {', '.join(bad)}@@", flush=True)
'''

UNITS = r'''
U1 = {}
try:
    F = unpack("__UNITSBLOB__")
    B = K / "kit"
    for rel, txt in F.items():
        (B / rel).parent.mkdir(parents=True, exist_ok=True)
        (B / rel).write_text(txt, encoding="utf-8", newline="\n")
    U1["files"] = {rel: hashlib.sha256(txt.encode("utf-8")).hexdigest()[:12] for rel, txt in F.items() if not rel.startswith("merlin/")}
    for k_ in list(os.environ):
        if k_.startswith(("NB1_", "E23_", "RC2_", "NB4_", "Q27X_", "DFLASH_")):
            os.environ.pop(k_, None)
    r = sh("units", [sys.executable, str(B / "build/nbdf_unit_tests.py"), "--merlin-src", str(B / "merlin"),
                     "--nb4t-results", str(B / "nb4t_q_record.json"), "--drafter-config", str(B / "drafter_config.json")],
           timeout=1800, cwd=B / "build")
    lines = r["_out"].splitlines()
    m = next((re.match(r"(\d+)/(\d+) PASS", l) for l in lines[::-1] if re.match(r"\d+/\d+ PASS", l)), None)
    U1["units"] = {"rc": r["rc"], "sec": r["sec"], "summary": m.group(0) if m else None, "fails": [l[:300] for l in lines if l.startswith("FAIL ")][:40],
                   "skips": [l for l in lines if l.startswith("SKIP ")], "tail": r["tail"][-800:]}
    U1["units"]["all_pass"] = bool(m) and m.group(1) == m.group(2) and r["rc"] == 0 and not U1["units"]["skips"]
    log("units", json.dumps(U1["units"])[:1500])
    r = sh("seam_tests", [sys.executable, str(B / "build/dflash_seam_tests.py"), "--merlin-src", str(B / "merlin"), "--nb4-dir", str(B / "build/e25")],
           timeout=1800, cwd=B / "build")
    U1["seam_tests"] = {"rc": r["rc"], "sec": r["sec"], "all_pass": r["rc"] == 0 and "ALL PASS" in r["_out"],
                        "fails": [l[:300] for l in r["_out"].splitlines() if l.startswith("FAIL")][:40], "tail": r["tail"][-1500:]}
    log("seam tests", json.dumps(U1["seam_tests"])[:1500])
except Exception as e:
    U1["fatal"] = f"{type(e).__name__}: {e}"[:800]; U1["tb"] = traceback.format_exc()[-1500:]
REP["checks"]["U1"] = U1
verdict({"nbdf_units_all_pass": (U1.get("units") or {}).get("all_pass") is True,
         "seam_tests_all_pass": (U1.get("seam_tests") or {}).get("all_pass") is True},
        recorded={"units": (U1.get("units") or {}).get("summary"), "files": U1.get("files")})
'''

REAL = r'''
FILES = unpack("__EXPORTBLOB__")
FIX = unpack("__FIXBLOB__")
(K / "nbdf_code_export.py").write_text(FILES["nbdf_code_export.py"], encoding="utf-8", newline="\n")
REP["export_sha256"] = hashlib.sha256(FILES["nbdf_code_export.py"].encode("utf-8")).hexdigest()
ARMS5 = ("Q", "D4s", "D3s", "D4", "D4t", "D7", "D4b")   # every arm of the plan (check names keep "_all_5")
SRC_SHAS = json.loads(r"""__SRCSHAS__""")
R0, R1, R2, R3, R3P, R3S, R4, R5, R6, R9, R10, R11, R12 = {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}
G = None
try:
    os.environ.update(RC2_UNIT="1", RC2_CPU_KIT="1", E23_OUT=str(K / "out"), E23_TMP=str(K / "tmp"), E23_INPUT=INPUT_ROOT,
                      RC2_SHM=str(K / "shm"), Q27X_WORKING=str(K / "work0"))
    for k_ in [x for x in os.environ if x.startswith(("DFLASH_", "NB4_"))] + ["E23_FAKE_SERVER", "KAGGLE_IS_COMPETITION_RERUN", "DRAFT_HEAD",
                                                                             "VLLM_PP_LAYER_PARTITION"]:
        os.environ.pop(k_, None)
    for d in ("out", "tmp", "shm", "work0"):
        (K / d).mkdir(exist_ok=True)
    t = time.time()
    G = runpy.run_path(str(K / "nbdf_code_export.py"), run_name="nbdfkit")["nbdf_main"].__globals__
    R = G["R"]
    sub = json.loads((K / "work0" / "submission.json").read_text())
    tc = G["test_challenges"]
    R0.update(tasks=len(tc), sub_tasks=len(sub),
              identity=all(len(sub[t_]) == len(v["test"]) and all(a["attempt_1"] == q["input"] == a["attempt_2"]
                                                                 for a, q in zip(sub[t_], v["test"])) for t_, v in tc.items()) and set(sub) == set(tc))
    R0["ok"] = R0["identity"] and R0["tasks"] > 0
    R1.update(load_sec=round(time.time() - t), inputs=R["inputs"], merge=R["sections"]["A0"]["merge"], arms=list(G["ARMS"]),
              rc2_rows_loaded=sorted(k for k in G["ROWS"] if k.startswith("rc2_")), prompts={b: len(v) for b, v in G["PROMPTS"].items()},
              embed=G["NBDF"].get("seam"), drafter=G["DRAFTER"], seam_envs=G["SEAM_ENVS"], seam_notes=G["SEAM_NOTES"],
              kv_kit_gate=G["KV_KIT_GATE"])
    R1["drafter_ok"] = G["DRAFTER"].get("ok") is True and G["DRAFTER"].get("pins_ok") is True
    log("R0", json.dumps(R0)); log("R1 drafter", json.dumps({k: G["DRAFTER"].get(k) for k in ("ok", "status", "why", "dir", "sec")})[:900])
    save()
    ok, why = G["sha_gate"](4 * 3600)
    R1["sha"] = {"ok": ok, "why": why}
except Exception as e:
    R1["fatal"] = f"{type(e).__name__}: {e}"[:1000]; R1["tb"] = traceback.format_exc()[-2500:]
    log("R1 FATAL", R1["fatal"])
REP["checks"]["R0"] = R0; REP["checks"]["R1"] = R1; save()

eng = None
try:
    eng = G["merlin_install"]()
    tree0 = Path(eng["kv"]["MERLIN_TREE"])
    R2.update(ok=True, kv=dict(eng["kv"]), src_shas={rel: hashlib.sha256((tree0 / rel).read_bytes()).hexdigest() if (tree0 / rel).is_file() else None
                                                     for rel in SRC_SHAS})
    R2["src_equal"] = R2["src_shas"] == SRC_SHAS
except Exception as e:
    R2.update(ok=False, error=f"{type(e).__name__}: {e}"[:800], tb=traceback.format_exc()[-1500:])
log("R2 install", json.dumps({k: v for k, v in R2.items() if k != "tb"})[:900])
REP["checks"]["R2"] = R2; save()


STUB = {}
try:
    import ctypes, glob
    try:
        ctypes.CDLL("libcuda.so.1")
        STUB["libcuda_so_1"] = "loadable"
    except OSError as e:
        STUB["libcuda_so_1"] = f"not loadable: {e}"[:200]
    cands = []
    for root in [eng["cuda_home"] if eng else "", "/usr/local/cuda", "/usr/local/cuda/targets/x86_64-linux"]:
        if root:
            cands += glob.glob(f"{root}/lib*/stubs/libcuda.so") + glob.glob(f"{root}/**/stubs/libcuda.so", recursive=True)
    if cands:
        d_ = K / "cudastub"
        d_.mkdir(exist_ok=True)
        if not (d_ / "libcuda.so.1").exists():
            os.symlink(cands[0], d_ / "libcuda.so.1")
        STUB.update(stub=cands[0], dir=str(d_))
except Exception as e:
    STUB["error"] = repr(e)[:300]
REP["checks"]["libcuda_stub"] = STUB

# E25 klee100 kit (k100kit_real.py:74-148, run on Kaggle CPU): vllm.platforms._current_platform = a NonNvmlCudaPlatform
# subclass reporting sm_89 "NVIDIA L4" BEFORE any vllm config / model import (else "Failed to infer device type"), and a
# single-process gloo group (TP1 / PP1) inside set_current_vllm_config(VllmConfig()) for layers built on meta.
PLATFORM = r"""
import json as _j
PLAT = {}
try:
    import torch
    import vllm.platforms as VP
    from vllm.platforms.interface import DeviceCapability
    from vllm.platforms import cuda as VPC

    class FakeL4(VPC.NonNvmlCudaPlatform):
        @classmethod
        def get_device_capability(cls, device_id=0):
            return DeviceCapability(8, 9)

        @classmethod
        def has_device_capability(cls, capability, device_id=0):
            want = tuple(capability) if isinstance(capability, tuple) else (capability // 10, capability % 10)
            return (8, 9) >= want

        @classmethod
        def get_device_name(cls, device_id=0):
            return "NVIDIA L4"

        @classmethod
        def get_device_total_memory(cls, device_id=0):
            return 23034 * 2 ** 20

        @classmethod
        def is_fully_connected(cls, physical_device_ids):
            return False

    VP._current_platform = FakeL4()
    from vllm.platforms import current_platform as CP
    PLAT.update(ok=bool(CP.is_cuda() and not CP.is_cpu()), cls=type(CP).__name__, capability=list(CP.get_device_capability()))
except BaseException as e:
    PLAT.update(ok=False, error=f"{type(e).__name__}: {e}"[:400])


def init_gloo():
    import socket
    from vllm.distributed import init_distributed_environment, initialize_model_parallel
    from vllm.config import VllmConfig as _VC, set_current_vllm_config as _scvc
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    with _scvc(_VC()):
        init_distributed_environment(world_size=1, rank=0, distributed_init_method=f"tcp://127.0.0.1:{port}", local_rank=0, backend="gloo")
        initialize_model_parallel(tensor_model_parallel_size=1, pipeline_model_parallel_size=1, backend="gloo")
"""


def venv_py(code, args=(), name="probe", timeout=1200, env_extra=None, base_env=None, platform=False):
    tree, py = eng["kv"]["MERLIN_TREE"], eng["kv"]["MERLIN_VENV"] + "/bin/python"
    if platform:
        code = PLATFORM + code
        env_extra = dict(env_extra or {}, CUDA_VISIBLE_DEVICES="", PYTHONUNBUFFERED="1")
        if STUB.get("dir"):
            env_extra["LD_LIBRARY_PATH"] = STUB["dir"] + ":" + os.environ.get("LD_LIBRARY_PATH", "")
    env = dict(base_env) if base_env is not None else {k: v for k, v in os.environ.items() if k not in ("PYTHONPATH", "LD_PRELOAD")}
    if base_env is None:
        env.update(PYTHONPATH=tree, CUDA_HOME=eng["cuda_home"], VLLM_USE_RUST_FRONTEND="0", HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1",
                   PATH=f"{eng['kv']['MERLIN_VENV']}/bin:{eng['cuda_home']}/bin:{os.environ.get('PATH', '')}")
        if eng["kv"].get("MERLIN_SHIM"):
            env["LD_PRELOAD"] = eng["kv"]["MERLIN_SHIM"]
    env.update(env_extra or {})
    (K / f"{name}.py").write_text(code)               # never named after a stdlib module (no argparse.py etc.)
    try:
        r = subprocess.run([py, str(K / f"{name}.py"), *args], capture_output=True, text=True, timeout=timeout, env=env, cwd=str(K))
        out, rc = r.stdout + "\n--- stderr ---\n" + r.stderr, r.returncode
    except Exception as e:
        out, rc = f"{type(e).__name__}: {e}", -9
    (W / f"kit_{name}.log").write_text(out)
    js = next((json.loads(l.split(" ", 1)[1]) for l in out.splitlines() if l.startswith("@JSON ")), None)
    return {"rc": rc, "json": js, "tail": out[-1500:]}


SPAWN_ENV = r"""
import json, multiprocessing as mp, os, sys
KEYS = sys.argv[1].split(",")
def child(q):
    q.put({k: os.environ.get(k) for k in KEYS})
if __name__ == "__main__":
    ctx = mp.get_context("spawn")
    q = ctx.Queue()
    p = ctx.Process(target=child, args=(q,))
    p.start(); r = q.get(timeout=120); p.join(60)
    print("@JSON " + json.dumps({"parent": {k: os.environ.get(k) for k in KEYS}, "child": r}))
"""
SPECPROBE = r"""
import json, sys, typing
out = {}
specs = json.loads(sys.argv[1])
try:
    from vllm.config import speculative as S
    hints = typing.get_type_hints(S.SpeculativeConfig)
    out["fields_missing"] = {k: [f for f in sp if f not in hints] for k, sp in specs.items()}
    lit = lambda t: set(x for a in typing.get_args(t) for x in (typing.get_args(a) or (a,)))
    out["method_ok"] = {k: sp["method"] in lit(S.SpeculativeMethod) for k, sp in specs.items()}
    out["draft_sample_ok"] = {k: sp.get("draft_sample_method") in typing.get_args(S.DraftSampleMethod) for k, sp in specs.items()}
    from vllm.config.cache import CacheDType
    out["kv_dtype_ok"] = {k: sp.get("kv_cache_dtype") in typing.get_args(CacheDType) for k, sp in specs.items()}
    from vllm.v1.attention.backends.registry import AttentionBackendEnum as E
    out["backend_ok"] = {k: S.SpeculativeConfig._parse_attention_backend(sp["attention_backend"]) == E[sp["attention_backend"]]
                         for k, sp in specs.items() if "attention_backend" in sp}
    out["draft_tp_default"] = str(hints.get("draft_tensor_parallel_size"))
    import inspect
    src = inspect.getsource(S.SpeculativeConfig._verify_and_get_draft_tp)
    out["draft_tp_unset_is_target_tp"] = "target_parallel_config.tensor_parallel_size" in src
    out["ok"] = (not any(out["fields_missing"].values()) and all(out["method_ok"].values()) and all(out["draft_sample_ok"].values())
                 and all(out["kv_dtype_ok"].values()) and all(out["backend_ok"].values()) and out["draft_tp_unset_is_target_tp"])
except BaseException as e:
    out.update(ok=False, error=f"{type(e).__name__}: {e}"[:600])
try:
    from vllm.engine.arg_utils import EngineArgs
    from vllm.utils.argparse_utils import FlexibleArgumentParser
    p = EngineArgs.add_cli_args(FlexibleArgumentParser())
    out["argparse"] = {k: str(vars(p.parse_args(["--model", "/tmp/x", "--speculative-config", json.dumps(sp)])).get("speculative_config"))[:300]
                       for k, sp in specs.items()}
except BaseException as e:
    out["argparse_error"] = f"{type(e).__name__}: {e}"[:400]
out["platform"] = PLAT
print("@JSON " + json.dumps(out, default=str))
"""
IMPORTPROBE = r"""
import json
out = {}
try:
    import vllm.models.qwen4_exp.nvidia.model as M
    out["import"] = M.__file__
    cls = M.Qwen4ExpModel
    out["mro"] = [c.__name__ for c in cls.__mro__][:8]
    out["eagle_mixin"] = any(c.__name__ == "EagleModelMixin" for c in cls.__mro__)
    out["aux_over_pp"] = getattr(cls, "supports_aux_hidden_states_over_pp", None)
    out["compiled_wrapper"] = any("compile" in c.__name__.lower() for c in cls.__mro__) or hasattr(cls, "__vllm_compile__") or "support_torch_compile" in repr(getattr(cls, "__init__", ""))
    out["served_eagle3"] = any(c.__name__ == "SupportsEagle3" for c in M.Qwen4ExpForConditionalGeneration.__mro__)
    out["ok"] = out["eagle_mixin"] and out["aux_over_pp"] is True and out["served_eagle3"]
except BaseException as e:
    out.update(ok=None, error=f"{type(e).__name__}: {e}"[:600])
print("@JSON " + json.dumps(out, default=str))
"""
WEIGHTPROBE = r"""
import json, sys, io, os, traceback, contextlib, dataclasses
out = {"platform": PLAT}
d, ckpt = sys.argv[1], sys.argv[2]
os.environ["DFLASH_SEAM"] = "1"                 # the seam's allowlist + loaded-weights check (qwen3_dflash.py _e27_check_loaded) ON
try:
    from safetensors import safe_open
    with safe_open(d + "/model.safetensors", framework="pt", device="cpu") as f:
        names = sorted(f.keys())
        shapes = {n: (list(f.get_slice(n).get_shape()), f.get_slice(n).get_dtype()) for n in names}
    out["checkpoint_tensors"] = len(names)
    out["has_embed"] = any(n.endswith("embed_tokens.weight") for n in names)
    import torch
    from vllm.config import VllmConfig, ModelConfig, SpeculativeConfig, set_current_vllm_config
    init_gloo()
    from vllm.model_executor.models.qwen3_dflash2 import DFlash2Qwen3ForCausalLM
    from vllm.v1.worker.gpu.spec_decode.dflash import utils as DU
    out["class"] = DFlash2Qwen3ForCausalLM.__name__
    # the engine's path: the TARGET model config + SpeculativeConfig(method dflash, the drafter dir), then the draft vllm_config
    # exactly as load_dflash_model builds it (dflash/utils.py: attention_config non-causal + backend, cache dtype, load config)
    mc = ModelConfig(model=ckpt, tokenizer=ckpt, dtype="bfloat16", max_model_len=131072)
    vc0 = VllmConfig(model_config=mc)
    sc = SpeculativeConfig(method="dflash", model=d, num_speculative_tokens=4, draft_sample_method="probabilistic",
                           kv_cache_dtype="auto", attention_backend="FLASH_ATTN", target_model_config=mc,
                           target_parallel_config=vc0.parallel_config)
    vc = VllmConfig(model_config=mc, speculative_config=sc)
    from vllm.model_executor.models.qwen3_dflash import dflash_has_any_non_causal
    dvc = dataclasses.replace(vc, attention_config=dataclasses.replace(vc.attention_config, use_non_causal=dflash_has_any_non_causal(
        sc.draft_model_config.hf_config), backend=sc.attention_backend),
        cache_config=dataclasses.replace(vc.cache_config, cache_dtype=sc.kv_cache_dtype) if sc.kv_cache_dtype is not None else vc.cache_config)
    out["draft_arch"] = getattr(sc.draft_model_config.hf_config, "architectures", None)
    DT = {"BF16": torch.bfloat16, "F16": torch.float16, "F32": torch.float32}
    buf = io.StringIO()
    from vllm.utils.torch_utils import set_default_torch_dtype
    out["draft_dtype"] = str(sc.draft_model_config.dtype)
    with set_current_vllm_config(dvc), set_default_torch_dtype(sc.draft_model_config.dtype), torch.device("meta"):
        m = DFlash2Qwen3ForCausalLM(vllm_config=dvc, prefix="")
        params = sorted(n for n, _ in m.named_parameters())
        out["named_parameters"] = len(params)
        out["params_sample"] = params[:6]
        with contextlib.redirect_stdout(buf):
            try:
                ret = m.load_weights((n, torch.empty(shapes[n][0], dtype=DT.get(shapes[n][1], torch.bfloat16), device="meta")) for n in names)
                out["load_weights"] = "returned None" if ret is None else f"returned {type(ret).__name__}"
            except BaseException as e:
                out["load_weights_error"] = f"{type(e).__name__}: {e}"[:900]
    out["seam_events"] = [l for l in buf.getvalue().splitlines() if "E27_DFLASH" in l][:6]
    chk = [l for l in out["seam_events"] if "draft_load_check" in l]
    out["draft_load_check_line"] = chk[:1]
    out["false_raise_suspect"] = "got no tensor" in str(out.get("load_weights_error", ""))
    out["ok"] = bool(chk) and "load_weights_error" not in out and '"skipped": true' not in (chk[0] if chk else "")
    if not out["ok"] and not out["false_raise_suspect"] and "load_weights_error" in out:
        out["ok"] = False
except BaseException as e:
    out.update(ok=None, error=f"{type(e).__name__}: {e}"[:600], tb=traceback.format_exc()[-1800:])
print("@JSON " + json.dumps(out, default=str))
"""
KVPROBE = r"""
import json, sys, dataclasses, re, copy, traceback
from types import SimpleNamespace as NS
out = {"runs": {}, "platform": PLAT}
fx = json.loads(open(sys.argv[1]).read())
Q_PIN, D_PIN = int(sys.argv[2]), int(sys.argv[3])
ckpt = sys.argv[4] if len(sys.argv) > 4 else None
try:
    import torch
    from vllm.v1 import kv_cache_interface as KI
    from vllm.v1.core import kv_cache_utils as KU
    from vllm.config import VllmConfig
    from vllm.v1.attention.backends import utils as AU
    tdt = lambda v: getattr(torch, str(v).replace("torch.", "")) if v else None

    from vllm.v1.attention.backends.registry import MambaAttentionBackendEnum as MBE
    PAGE_MISMATCH = []

    def mk(s, name=""):
        sp = _mk(s, name)
        f = {x.name for x in dataclasses.fields(type(sp))}
        want = s.get("page_size_bytes")
        have = getattr(sp, "page_size_bytes", None)
        if "tokens_per_state" in f and isinstance(want, int) and isinstance(have, int) and have != want and want and have % want == 0:
            sp = dataclasses.replace(sp, tokens_per_state=have // want)          # e.g. the QSA compressed indexer cache (ratio 4)
            have = sp.page_size_bytes
        if isinstance(want, int) and have != want and len(PAGE_MISMATCH) < 12:
            PAGE_MISMATCH.append([s["type"], name[:60], have, want])
        return sp

    def _mk(s, name=""):
        cls = getattr(KI, s["type"])
        f = {x.name for x in dataclasses.fields(cls)}
        kw = {}
        if "block_size" in f: kw["block_size"] = s["block_size"]
        if "num_kv_heads" in f: kw["num_kv_heads"] = s.get("num_kv_heads")
        if "head_size" in f: kw["head_size"] = s.get("head_size")
        if "dtype" in f and s.get("dtype"): kw["dtype"] = tdt(s["dtype"])
        if "shapes" in f: kw["shapes"] = tuple(tuple(x) for x in s.get("state_shapes") or ())
        if "dtypes" in f: kw["dtypes"] = tuple(tdt(x) for x in s.get("state_dtypes") or ())
        if "page_size_padded" in f: kw["page_size_padded"] = s.get("page_size_padded")
        if "mamba_type" in f and s.get("mamba_type"): kw["mamba_type"] = MBE[str(s["mamba_type"]).split(".")[-1]]
        if "mamba_cache_mode" in f and s["type"] == "MambaSpec": kw["mamba_cache_mode"] = "align"     # --mamba-cache-mode align
        if "tp_replicated" in f and ".ple" in name: kw["tp_replicated"] = True                    # "folded replicated Mamba group (ple)"
        if "sliding_window" in f and s.get("sliding_window"): kw["sliding_window"] = s["sliding_window"]
        return cls(**{k: v for k, v in kw.items() if v is not None})

    def k_shapes(s, k):
        # the K-dependent state rows (nvidia/model.py:980-1062 + mamba_utils.py:331-375): GDN conv (conv_kernel - 1 + K),
        # the RecoverSSM replay record (K + 1), the PLE short conv (conv_state_len + K); the recorded specs are at K = 3
        s = copy.deepcopy(s)
        sh = [list(x) for x in s.get("state_shapes") or []]
        ex = str(s.get("example") or "")
        if s["type"] == "MambaSpec" and sh:
            sh[0][0] += k - 3
            if "linear_attn" in ex and len(sh) >= 3:
                sh[2][1] += k - 3
        s["state_shapes"] = sh
        return s

    LT = None
    try:
        _c = json.load(open(f"{ckpt}/config.json"))
        LT = (_c.get("text_config") or _c).get("layer_types")
    except BaseException:
        LT = None
    out["layer_types_from_ckpt"] = bool(LT)

    def layer_names(stage, s, n):
        # the real per-layer names on this PP stage (25 / 23): GDN on linear_attention layers, the QSA caches on
        # full_attention layers (+ the MTP layer 48 on the last stage), the PLE at layers.1; else stage-unique names
        lo, hi = (0, 25) if stage == 0 else (25, 48)
        ex = str(s.get("example") or "layer")
        suf = ex.split(".", 4)[-1] if ex.startswith("language_model.model.layers.") else None
        if LT and suf is not None:
            if ".ple" in ex:
                idx = [1]
            elif "linear_attn" in ex:
                idx = [i for i in range(lo, hi) if LT[i] == "linear_attention"]
            else:
                idx = [i for i in range(lo, hi) if LT[i] == "full_attention"]
            names = [f"language_model.model.layers.{i}.{suf}" for i in idx]
            if stage == 1 and len(names) + 1 == n and "linear_attn" not in ex:
                names.append(f"mtp.layers.48.{suf}")
            if len(names) == n:
                return names
        return [re.sub(r"layers\.\d+", f"layers.{1000 + 100 * stage + i}", ex) for i in range(n)]

    def worker_specs(ranks, k=3, drafter=None, drop_mtp=False):
        ws = []
        for w in ranks:
            d = {}
            stage = 0 if w["rank"] < 2 else 1
            for s in w["kv_cache_specs"]:
                s = k_shapes(s, k)
                for nm in layer_names(stage, s, int(s.get("layers") or 1)):
                    if drop_mtp and nm.startswith("mtp."):
                        continue                          # the MTP layer (layer 48) is not built on a DFlash arm
                    d[nm] = mk(s, nm)
            if drafter and w["rank"] >= 2:
                for i in range(5):                        # qwen3_dflash.py:489: prefix model.layers.{i + target layers}
                    d[f"model.layers.{48 + i}.self_attn.attn"] = mk(drafter)
            ws.append(d)
        return ws

    MC = {}
    try:
        from vllm.config import ModelConfig
        MC["mc"] = ModelConfig(model=ckpt, tokenizer=ckpt, dtype="bfloat16", max_model_len=131072) if ckpt else None
        MC["how"] = "real ModelConfig of the merged W4 checkpoint"
    except BaseException as e:
        MC["error"] = f"{type(e).__name__}: {e}"[:400]
    out["model_config"] = {k: v for k, v in MC.items() if k != "mc"}
    BK = {}
    try:
        from vllm.models.qwen4_exp.nvidia.qsa import Qwen4ExpQSAFlashAttentionBackend
        from vllm.models.qwen4_exp.common.qsa_cache import QSAStateBackend
        from vllm.v1.attention.backends.flash_attn import FlashAttentionBackend
        from vllm.v1.attention.backends.triton_attn import TritonAttentionBackend
        BK = {"target": [Qwen4ExpQSAFlashAttentionBackend, QSAStateBackend], "FLASH_ATTN": FlashAttentionBackend,
              "TRITON_ATTN": TritonAttentionBackend}
    except BaseException as e:
        out["backend_import_error"] = f"{type(e).__name__}: {e}"[:400]

    def summary(c, drafter_names):
        groups, builders, wasted = [], 0, 0
        for g in c.kv_cache_groups:
            sp = g.kv_cache_spec
            inner = getattr(sp, "kv_cache_specs", None)
            types_ = sorted({type(x).__name__ for x in (inner.values() if isinstance(inner, dict) else [sp])})
            builders += len(types_)
            for x in (inner.values() if isinstance(inner, dict) else [sp]):
                pad, real = getattr(x, "page_size_padded", None), getattr(x, "real_page_size_bytes", None)
                if isinstance(pad, int) and isinstance(real, int) and pad > real:
                    wasted += pad - real
            groups.append({"spec": type(sp).__name__, "inner": types_, "layers": len(g.layer_names),
                           "block_size": getattr(sp, "block_size", None), "page_size_bytes": getattr(sp, "page_size_bytes", None),
                           "is_eagle_group": getattr(g, "is_eagle_group", None),
                           "drafter_layers": sum(1 for n in g.layer_names if n in drafter_names)})
        return {"kv_group_count": len(groups), "groups": groups, "attn_metadata_builders": builders,
                "drafter_group_count": sum(1 for g in groups if g["drafter_layers"]), "wasted_bytes_per_block": wasted or None}

    import logging
    class _Cap(logging.Handler):
        msgs = []
        def emit(self, r):
            try:
                _Cap.msgs.append(r.getMessage())
            except Exception:
                pass
    logging.getLogger("vllm").addHandler(_Cap())

    def run(tag, ws, pin, draft_backend=None):
        _Cap.msgs.clear()
        vc = VllmConfig()
        if MC.get("mc") is not None:
            vc.model_config = MC["mc"]
        else:
            vc.model_config = NS(max_model_len=131072, original_max_model_len=131072, hf_config=NS(), use_mla=False, is_hybrid=True,
                                 get_num_layers=lambda *a: 48)
        vc.cache_config.block_size = 4096
        vc.cache_config.enable_prefix_caching = True
        vc.cache_config.cache_dtype = "fp8_e4m3"
        rec = {"pin": pin}
        try:
            # the engine core's own call (v1/engine/core.py:388-392): resolve_kv_cache_layout(vllm_config, the workers'
            # supported layouts (worker_base.py:125-128 = get_supported_kv_cache_layouts(the backends)), every spec)
            bks = list(BK.get("target") or []) + ([BK[draft_backend]] if draft_backend and BK.get(draft_backend) else [])
            sup = [l.name for l in AU.get_supported_kv_cache_layouts(bks)] if bks else None
            rec["supported_layouts"], rec["backends"] = sup, [b.__name__ for b in bks]
            lay = AU.resolve_kv_cache_layout(vc, [sup] * len(ws), [s for w in ws for s in w.values()])
            rec["layout"] = lay.name
            cfgs = KU.get_kv_cache_configs(vc, ws, [pin] * len(ws))
            dn = {n for w in ws for n in w if n.startswith("model.layers.4") or n.startswith("model.layers.5")}
            rec.update(num_blocks=[x.num_blocks for x in cfgs], **summary(cfgs[2], dn))
            try:
                rec["max_concurrency_131072"] = KU.get_max_concurrency_for_kv_cache_config(vc, cfgs[2])
            except BaseException as e:
                rec["max_concurrency_error"] = f"{type(e).__name__}: {e}"[:200]
        except BaseException as e:
            rec.update(error=f"{type(e).__name__}: {e}"[:600], tb=traceback.format_exc()[-1500:])
        rec["draft_group_warning"] = any("no KV cache group could be identified as the draft model" in m for m in _Cap.msgs)
        rec["fine_grained_disabled"] = any("Disabling fine-grained prefix-cache hits" in m for m in _Cap.msgs)
        out["runs"][tag] = rec

    ranks = fx["q_workers"]["ranks"]
    run("Q", worker_specs(ranks, 3), Q_PIN)
    out["page_mismatch"] = PAGE_MISMATCH
    out["q_target"] = {"num_blocks": 215, "groups_rank0": [[g.get("layers"), g.get("block_size"), g.get("page_size_bytes")]
                                                          for g in (ranks[0].get("kv_cache_config") or {}).get("groups") or []],
                       "groups_rank2": [[g.get("layers"), g.get("block_size"), g.get("page_size_bytes")]
                                        for g in (ranks[2].get("kv_cache_config") or {}).get("groups") or []]}
    q = out["runs"]["Q"]
    out["q_calibrated"] = bool(q.get("num_blocks")) and 213 <= min(q["num_blocks"]) <= 217
    bf16 = {"type": "SlidingWindowSpec", "block_size": 4096, "num_kv_heads": 4, "head_size": 128, "dtype": "torch.bfloat16", "sliding_window": 2048}
    fp8 = dict(bf16, dtype="torch.uint8")
    if out["q_calibrated"]:                   # no D number counts before Q reproduces NB4T's 215 blocks
        for tag, k, dr, bk in (("K3", 3, bf16, "FLASH_ATTN"), ("K4", 4, bf16, "FLASH_ATTN"), ("K7", 7, bf16, "FLASH_ATTN"),
                               ("K4_fp8", 4, fp8, "TRITON_ATTN"), ("K4_swblock1024", 4, dict(bf16, block_size=1024), "FLASH_ATTN"),
                               ("K3_swblock1024", 3, dict(bf16, block_size=1024), "FLASH_ATTN")):
            run(tag, worker_specs(ranks, k, dr, drop_mtp=True), D_PIN, bk)
    out["note"] = ("target specs = the NB4T GPU record (K = 3) with the K-dependent state rows scaled to K (GDN conv, the RecoverSSM "
                   "replay record, PLE short conv), the MTP layer removed on PP1, the drafter's 5 SWA layers added (4 KV heads x 128 "
                   "per TP rank); layout via the engine core's resolve_kv_cache_layout with the target's attention backends")
    out["ok"] = out["q_calibrated"] and all(bool((out["runs"].get(t) or {}).get("num_blocks")) and "error" not in out["runs"].get(t, {})
                                            for t in ("K4_swblock1024", "K3_swblock1024"))
except BaseException as e:
    out.update(ok=False, error=f"{type(e).__name__}: {e}"[:600], tb=traceback.format_exc()[-1500:])
print("@JSON " + json.dumps(out, default=str))
"""

orig, qsa_file, tree = None, None, None
try:
    tree = Path(eng["kv"]["MERLIN_TREE"])
    qsa_file = tree / G["P60490_REL"]
    orig = qsa_file.read_bytes()
    rec = G["apply_60490"]()
    R3["ok"] = rec.get("applied") == "applied" and rec.get("sha_after") == G["P60490_POST"] and (rec.get("py_compile") or {}).get("rc") == 0
except Exception as e:
    R3.update(ok=False, error=f"{type(e).__name__}: {e}"[:800])
REP["checks"]["R3"] = R3; save()

plans = {}


def plan_one(key):
    a = G["ARMS"][key]
    nm = a["name"]
    G["NB1_EXTRA"][nm], G["NB1_ENV"][nm], G["NB1_KV"][nm] = list(a["extra"]), dict(a["env"]), a["kv_bytes"]
    G["ARM_OF"][nm] = a
    b = {"arm": key, "tree_check": G["tree_check"](a)}
    try:
        s = G["merlin_fn_server"](nm, "fp8", a["port"], a["kv_bytes"])
        b.update(ok=True, host_phase=G["HOST_PHASE"].get(nm), argv=s.argv, launch_check=G["N"].launch_check(a, s.env, s.argv, a["kv_bytes"]),
                 server_started=s.proc is not None, spec=G["T"].spec_from_argv(s.argv),
                 env={k: s.env.get(k) for k in G["N"].WATCHED + ("KV_BYTES", "VLLM_SERVER_DEV_MODE", "PYTHONPATH")})
        sp = venv_py(SPAWN_ENV, [",".join(G["N"].WATCHED)], name=f"r4_spawn_{key.lower()}", base_env=dict(s.env))
        b["spawn_env"] = sp["json"] or {"error": sp["tail"]}
        b["spawn_ok"] = isinstance(sp["json"], dict) and sp["json"]["child"] == a["expect"] and sp["json"]["parent"] == a["expect"]
    except Exception as e:
        b.update(ok=False, error=f"{type(e).__name__}: {e}"[:800], host_phase=G["HOST_PHASE"].get(nm))
    plans[key] = b
    log("R4", key, json.dumps({k: v for k, v in b.items() if k not in ("argv",)}, default=str)[:900]); save()


try:
    R3P["apply"] = G["_ppack_apply"]()
    R3P["after_apply"] = G["P"].verify_ppack_patch(tree)["state"]
    R3S["pre_state"] = G["DS"].tree_state(tree)
    R2["merlin_commit"] = G["DS"].MERLIN_COMMIT if R3S["pre_state"] == "ORIGINAL" else None
    R2["merlin_commit_evidence"] = "every dflash_seam file at its Merlin ad42e37 pre-sha on the installed tree (tree_state ORIGINAL before apply)"
    REP["checks"]["R2"] = R2
    ok_s, why_s = G["SSEQ"].apply()
    R3S.update(apply_ok=ok_s, why=why_s, ring=G["SSEQ"].ring, ring_status=list(G["N"].ring_status(G["SSEQ"])),
               combined=G["DS"].combined_tree_state(tree, G["P"], ring=G["SSEQ"].ring), check=list(G["SSEQ"].check("kit")))
    for k in ARMS5:
        plan_one(k)
except Exception as e:
    R4["fatal"] = f"{type(e).__name__}: {e}"[:800]; R4["tb"] = traceback.format_exc()[-1500:]
R4["plans"] = plans
R4["host_phase_ok"] = len(plans) == len(ARMS5) and all(p.get("host_phase") == "ok" for p in plans.values())
R4["launch_check_ok"] = len(plans) == len(ARMS5) and all(p.get("ok") and p.get("launch_check") == [] for p in plans.values())
R4["spawn_env_ok"] = len(plans) == len(ARMS5) and all(p.get("spawn_ok") is True for p in plans.values())
R4["tree_ok"] = len(plans) == len(ARMS5) and all((p.get("tree_check") or {}).get("ok") for p in plans.values())
REP["checks"]["R3P"] = R3P; REP["checks"]["R3S"] = R3S; REP["checks"]["R4"] = R4; save()

try:
    fields = {}
    for k in ARMS5:
        x, a, bad = plans.get(k, {}).get("argv") or [], G["ARMS"][k], []
        lv = G["T"].last_value
        if G["T"].spec_from_argv(x) != a["spec"]: bad.append(f"spec {G['T'].spec_from_argv(x)}")
        if G["N"].captures_from_argv(x) != a["captures"]: bad.append(f"captures {G['N'].captures_from_argv(x)}")
        if lv(x, "--max-num-seqs") != "8": bad.append("seqs")
        if lv(x, "--kv-cache-memory-bytes") != str(a["kv_bytes"]): bad.append("kv bytes")
        if lv(x, "--kv-cache-dtype") != "fp8_e4m3": bad.append("kv dtype")
        if "--language-model-only" not in x: bad.append("lmo")
        if any(f in x for f in ("--no-async-scheduling", "--no-enable-prefix-caching")): bad.append("never-do")
        fields[k] = bad
    R5["field_check"] = fields
    R5["ok"] = len(fields) == len(ARMS5) and all(not v for v in fields.values())
except Exception as e:
    R5.update(ok=False, error=f"{type(e).__name__}: {e}"[:600])
REP["checks"]["R5"] = R5; save()

R10 = venv_py(SPECPROBE, [json.dumps({k: G["ARMS"][k]["spec"] for k in ARMS5 if k != "Q"})], name="r10_spec_preflight", platform=True)
R11 = venv_py(IMPORTPROBE, name="r11_patched_model_import", platform=True)
R12 = (venv_py(WEIGHTPROBE, [str(G["DRAFTER"].get("dir")), str(G["CKPT"])], name="r12_drafter_weights", timeout=1800, platform=True)
       if G and G["DRAFTER"].get("dir") else {"json": {"ok": None, "error": "no drafter dir"}})
(K / "q_fixture.json").write_text(json.dumps(FIX))
R9 = venv_py(KVPROBE, [str(K / "q_fixture.json"), "3553580524", "3016709612", str(G["CKPT"])], name="r9_kv_cache_configs", timeout=1800, platform=True)
R9["summary"] = R9.get("json")
for nm, r in (("R9", R9), ("R10", R10), ("R11", R11), ("R12", R12)):
    REP["checks"][nm] = r
    log(nm, json.dumps(r.get("json") or r.get("tail"), default=str)[:1500])
save()

try:
    R3S["finish"] = G["SSEQ"].finish()
    R3S["after"] = G["DS"].combined_tree_state(tree, G["P"])
    R3P["revert"] = G["_ppack_revert"]()
    R3P["after_revert"] = G["P"].verify_ppack_patch(tree)["state"]
    R3S["pristine"] = G["DS"].tree_state(tree) == "ORIGINAL" and R3P["after_revert"] == "not_applied"
    if orig is not None:
        qsa_file.write_bytes(orig)
        ext = tree / "nb1_worker_ext.py"
        if ext.exists():
            ext.unlink()
except Exception as e:
    R3S["pristine"] = False; R3S["restore_error"] = repr(e)[:300]
REP["checks"]["R3S"] = R3S; REP["checks"]["R3P"] = R3P; save()
verdict({"cell0_identity_submission": R0.get("ok") is True, "inputs_found": bool((R1.get("inputs") or {}).get("merlin_inputs_ok")),
         "merge_ok": bool((R1.get("merge") or {}).get("ok")), "sha256_all_ok": bool((R1.get("sha") or {}).get("ok")),
         "drafter_pins_ok": R1.get("drafter_ok") is True, "arms_q_d4_d3_d7_d4b": R1.get("arms") == list(ARMS5),
         "merlin_install_ok": R2.get("ok") is True, "merlin_flag_sources_equal": R2.get("src_equal") is True,
         "patch_60490_ok": R3.get("ok") is True, "seam_apply_verify_revert_ok": R3S.get("apply_ok") is True and R3S.get("ring") is True
         and (R3S.get("combined") or {}).get("valid") is True and R3S.get("pristine") is True,
         "host_phase_all_5_ok": R4.get("host_phase_ok") is True, "launch_check_all_5_ok": R4.get("launch_check_ok") is True,
         "env_in_spawned_child_all_5": R4.get("spawn_env_ok") is True, "tree_check_all_5": R4.get("tree_ok") is True,
         "argv_fields_ok": R5.get("ok") is True, "spec_config_preflight_ok": (R10.get("json") or {}).get("ok") is True,
         "kv_cache_configs_ok": (R9.get("json") or {}).get("ok") is True,
         "drafter_loaded_weights_ok": (R12.get("json") or {}).get("ok") is True},
        recorded={"patched_model_import": R11.get("json"), "spec_argparse": (R10.get("json") or {}).get("argparse"),
                  "kv_runs": (R9.get("json") or {}).get("runs"), "drafter": {k: (R1.get("drafter") or {}).get(k) for k in ("status", "why", "dir")}})
'''

KITS = {"units": {"body": UNITS, "title": "Q27 E27 NBDF Kit Units", "models": []},
        "real": {"body": REAL, "title": "Q27 E27 NBDF Kit Real", "models": MODELS}}


def build(name):
    spec = KITS[name]
    code = HEAD + spec["body"]
    for k, v in (("__EXPORTBLOB__", EXPORT_BLOB), ("__UNITSBLOB__", UNITS_BLOB), ("__FIXBLOB__", FIXTURE_BLOB), ("__NBSHA__", NB_SHA),
                 ("__NAME__", name), ("__SRCSHAS__", json.dumps(SRC_SHAS))):
        code = code.replace(k, v)
    compile(code, f"<kit {name}>", "exec")
    slug = f"q27-e27-nbdf-kit-{name}"
    nb = {"cells": [{"cell_type": "code", "execution_count": None, "metadata": {}, "outputs": [], "source": code.splitlines(True)}],
          "metadata": {"kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"}, "language_info": {"name": "python"}},
          "nbformat": 4, "nbformat_minor": 5}
    data = json.dumps(nb, indent=1).encode("utf-8")
    assert len(data) < 400_000, (name, len(data))
    assert b"\r" not in data.replace(b"\\r", b"")
    out = ROOT / f"{slug}__{OWNER}"
    out.mkdir(parents=True, exist_ok=True)
    for f in out.glob("*.py"):
        assert f.name not in ("argparse.py", "json.py", "typing.py"), f
    (out / f"{slug}.ipynb").write_bytes(data)
    meta = {"id": f"{OWNER}/{slug}", "title": spec["title"], "code_file": f"{slug}.ipynb", "language": "python",
            "kernel_type": "notebook", "is_private": True, "enable_gpu": False, "enable_tpu": False, "enable_internet": False,
            "keywords": [], "dataset_sources": [], "kernel_sources": [], "competition_sources": ["arc-prize-2026-arc-agi-2"],
            "model_sources": spec["models"], "docker_image": IMAGE, "machine_shape": "None"}
    (out / "kernel-metadata.json").write_bytes((json.dumps(meta, indent=2) + "\n").encode("utf-8"))
    print("kit", out, "|", len(data), "bytes | sha256", hashlib.sha256(data).hexdigest(), "| NBDF", NB_SHA[:8], flush=True)
    return out, code


if __name__ == "__main__":
    for n in KITS:
        build(n)
