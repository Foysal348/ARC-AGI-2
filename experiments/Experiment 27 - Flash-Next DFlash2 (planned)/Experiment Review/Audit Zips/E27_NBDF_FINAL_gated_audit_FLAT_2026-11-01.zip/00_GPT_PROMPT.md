# E27 NBDF FINAL audit (gated build): DFlash2 vs MTP K3 GPU notebook (Qwen3.8-Flash-Next W4, Merlin v3.0.0, Kaggle 4 x L4)

**Answer GO or NO-GO on the first line. Then list BLOCKERS ONLY**: defects that would crash the GPU run, waste it, measure the wrong thing or give a wrong verdict. For each blocker give file:line, why it fails, and the fix. No style or nice-to-have items. Verify every claim in the files: the code is the truth, reports can be stale.

This is the FINAL gated notebook: `NB__Q27-XHIGH-E27_NBDF_DFLASH2.ipynb`, sha `ffa605e8aa037fbb148692f5b4975402b3fa90c9741592240963a8189cadbd48`, 393,767 B. `gpu_ready` true, `KV_KIT_GATE.passed` true.
- It was built with `--kv-gate-report KIT5__nbdf_kit_real_report.json`, which is the real Kaggle CPU kit v5 run on the closed build `61abc8aa…`. That kit was ALL OK, 18 / 18.
- Provenance is bound to the closed rebuild: notebook / seam / nb4_ppack / drafter / Merlin shas, tp 2, pp 2, partition 25,23, commit ad42e37.

## What the notebook must do
- **Arms, budget-gated, in this order:** Q → D4s → D3s → D4 → D4t → D7 → D4b. Hard stop 150 min, deadman at 155 min (not armed in a competition rerun or in the kits).
  - **Q:** MTP K3 + Q-defer (nb4_ppack rev 2), NB4T's base, pin 3,553,580,524.
  - **D4s / D3s (primary):** DFlash2 K4 / K3 with `DFLASH_DRAFT_SW_BLOCK=1024`, BF16 drafter KV, FLASH_ATTN. They start at pin 3,016,709,612, with one step-down to 2,748,274,156 on an OOM or a rank below 512 MiB.
  - **D4:** plain BF16 drafter at block 4096 (kit R9: 71 blocks); a short control (smoke + oracle + 8k × 2), never a winner.
  - **D4t:** D4s + `DFLASH_CONV_IMPL=torch`; short, compared with D4s.
  - **D7 / D4b:** optional.
- **Why SW-1024 (kit R9 at the D pin):**
  - BF16 drafter KV at block 4096 gives 71 blocks (the drafter page of 41.9 MB sets the stride);
  - FP8 gives 143;
  - drafter block 1024 gives 205 (page 10.5 MB, stride unchanged);
  - Q gives 215 at its own pin.
  - **Known open risk:** the engine lowers `cache_config.block_size` to 1024 engine-wide (`v1/engine/core.py:436-448`), so the GPU pool / F will differ from the kit's 205. The notebook reads the real block size and recomputes residency.
- **Seam `BUILD__dflash_seam.py`** (sha `7356d473…`, 8 Merlin files):
  - allowlist;
  - Qwen4Exp aux taps [6, 16 | 26, 36, 46], hc-mean, with the PP2 relay (PR #61180 semantics);
  - drafter embed checks / mask-row sha / B5 lm_head release / loaded-weights check;
  - QSA ring helper (PR #54912);
  - drafter SW block;
  - the PR #64059 port (vLLM #63587: FULL-graph DFlash acceptance about 0);
  - the grouped-conv A/B (vLLM #58250).
- **Per arm:**
  1. Read-backs: env, config, Q-defer, the DFlash labels (`readback_label`), `ingraph_meta`, `conv_impl`, `draft_sw_block`, the engine block, the KV groups, pool / F vs Q, memory per stage.
  2. 4-rank memory gate: fail-closed, and both gates required for WIN.
  3. Smoke + concurrency ladder (probe alone / +2 / +4 / +7) + the zero-accept canary. `DFLASH_ZERO_ACCEPT` with `kernel_map_refresh` triggers one `INGRAPH_META_FALLBACK` relaunch.
  4. Greedy oracle against Q by token ids.
  5. Long oracle at 90k and 116k.
  6. Prefix test, 2 prompts × 3 turns.
  7. Windows: 8k@8 × 2, then 40k / 90k / 116k at the resident level (Q runs A/A).
  8. Profiles.
  - D4 exits only by the 8k throughput rule (D4-only); AL is a diagnostic.
- Every response is saved. Garbage is gated by the windowed check.
- **Verdict:** WIN needs 8k on both windows, valid 40k / 90k / 116k with no regression beyond max(Q A/A, 2 %), long oracle and prefix PASS, and both memory gates. Recorded flags: `PREFIX_REUSE_DROP`, `KV_GROUP_EXPLOSION`, `QDEFER_K_FALLBACK`, `PREEMPT_ACCEPT_DROP`, `PP0_GRAPH_DEGRADED`, `SW_BLOCK_LOWERED_ENGINE_BLOCK`, `CONV_IMPL_*`.
- CELL 0 = E18 R2's cell 1 verbatim (a competition rerun writes only the identity submission).
- The modules and the CELL 7 body are lzma + base85. **Read `BUILD__nbdf_cell7_body.py`** (the readable CELL 7 body); `BUILD__nbdf_code_export.py` holds the notebook's code cells exactly.

## Evidence included
- **Kit v5 (real + units) reports and logs:** the `KIT5__*` files.
- `REVIEW__FIX_LIST_NBDF.md`: every audit item and its status.
- `REPORT__*`: verbatim agent reports.
