"""Audit check after a gated rebuild (W4 or K100): the build facts and the CELL 7 body's embedded KV_KIT_GATE agree, the
gate passed, gpu_ready, every arm of the variant has an explicit per-K success (W4 / K100: nbdf_lib per_k booleans; K100
also per_k_success from the K100 real kit). Never edits anything.
usage: python nbdf_gate_verify.py <build facts json> <cell 7 body py> [D3s D4s ...]"""
import json
import re
import sys

facts = json.load(open(sys.argv[1], encoding="utf-8"))
body = open(sys.argv[2], encoding="utf-8").read()
arms = sys.argv[3:] or ["D3s", "D4s"]
g = facts["kv_kit_gate"]
m = re.search(r'KV_KIT_GATE = json.loads\(r"""(.*?)"""\)', body, re.S)
emb = json.loads(m.group(1)) if m else None
res = {"notebook_sha256": facts.get("sha256"), "closed_build_sha256": facts.get("closed_build_sha256"), "passed": g.get("passed"),
       "gpu_ready": facts.get("gpu_ready"), "embedded_equals_facts": emb == g,
       "per_k": {a: (g.get("per_k") or {}).get(a) for a in arms},
       "per_k_success": {a: ((g.get("per_k_success") or {}).get(a) or {}).get("success") for a in arms} if "per_k_success" in g else None}
ok = (g.get("passed") is True and facts.get("gpu_ready") is True and res["embedded_equals_facts"]
      and all(v is True for v in res["per_k"].values())
      and (res["per_k_success"] is None or all(v is True for v in res["per_k_success"].values())))
res["ok"] = ok
print(json.dumps(res, indent=1))
sys.exit(0 if ok else 1)
