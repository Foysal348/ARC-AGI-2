# E27 NBDF-K100 audit: DFlash2 vs MTP K3 on the klee100 3bpw-MTP target (Merlin v3.0.0, Kaggle 4 x L4)

**Answer GO or NO-GO on the first line. Then list BLOCKERS ONLY** (crash, wasted run, wrong measurement, wrong verdict), each
with file:line, why, fix. No style items. The design below is FINAL (coordinator 2026-11-01, from the two research reports
`REPORT__NBDF_K100_research_A_*` and `REPORT__NBDF_K100_research_B_*`); audit the implementation against it.

## Final design (K100_CFG in `BUILD__build_e27_nbdf_k100.py`)
- Builder: `BUILD__build_e27_nbdf_k100.py` runs the NBDF builder (`BUILD__build_e27_nbdf.py`, NBDF_VARIANT=k100) with exact-once
  "E27 K100" edits. Readable notebook code: `BUILD__nbdf_k100_code_export.py` (= the code cells), body `BUILD__nbdf_k100_cell7_body.py`.
- klee100 boot (klee100 LOAD rev 3 / K100Q / E28 K100, reused via the K100Q builder): CELL 1 inputs + the lab from the tf-ref
  dataset, CELL 2b (overlay merge, K6, the K7 / K3 digests, k100_scales, the K100 payload fd92a814), CELL 3 klee100 tokenizer,
  the worker extension = NBDF's (NB1 + nb4s_env) + klee100's method map / kv scales; K6 + VLLM_QSA_KV_SCALES + the --help flag
  gate around every launch; k100_setup after #60490; boot gates GPU_METHOD_MAP_PASS (MTP rows required on MTP arms only: the
  DFlash2 drafter is dense) and STATIC_SCALES_APPLIED (an MTP layer at DEFAULT 1.0 is recorded only).
- Arms and order: **Q -> D3s -> D4s**, all at **24 sequences** (`--max-num-seqs 24` on every arm), ladder (2, 8, 23).
  - Q = E28 K100 production: MTP K3 + Q-defer + MERLIN_SHARE_DRAFT_WORKSPACE=1 + I8 (DRAFT_HEAD=int8 into Merlin's build();
    I8_ENGAGED required by the E28 / NB4T read-back, else the same pin with the BF16 head; switch `q_i8`), captures = Merlin
    registry capture_sizes_for(24, 3) (1..96) as Q's trailing --compilation-config.
  - D3s / D4s: dflash spec (BF16 drafter KV, FLASH_ATTN), DFLASH_DRAFT_SW_BLOCK=1024, captures 4..96 / 5..120 (exact multiples).
  - D4s always runs (a D3s failure never skips it). Reruns (INGRAPH_META nometa, the one Q-defer-off isolation, the
    DFLASH_TAP_MODE=pre_combine diagnostic on a STRUCTURAL / TAP_SUSPECT pos0) are deferred to the end, budget permitting.
- Pins: every arm starts at 7,933,526,016. D launch OOM: DFLASH_DRAFT_EMBED_HOST=1 at the same pin, then 7,665,090,560,
  7,396,655,104, 6,859,784,192. Q launch OOM: 7,665,090,560. The 512 MiB memory gate is recorded only.
- Windows: 8k@16 x 2, 20k@24, 40k@16, 90k@8, 116k@6 (a long band runs at min(fixed, the boot's resident level)); the window
  admit limit is computed at <= 3,000 tok/s prefill; profile 8k@16 (+ 116k when due). D4s may start with >= 25 min left
  (its last items then drop by due()).
- Correctness on a non-deterministic base: Q runs its greedy oracle twice (cache reset between) + its ladder = Q's A/A. D's
  token-id oracle, long oracle and ladder FAIL_HIGH_MARGIN / CONCURRENCY_CONTAMINATION -> NONDET_BASE_RECORDED when Q's A/A is
  not clean (`nbdf_lib.k100_rel`). The hard correctness gate: teacher-forced prompt logprobs at 2k / 8k / 40k, D vs Q, fail
  only outside Q's own A/A (mean|dlp| > q_aa + 0.05 or rank1 < q_aa - 0.03 per band; `nbdf_lib.tf_gate`), run LAST in each boot.
- Gates (USER RULE: real failures only; a failure stops only its own arm, no cross-arm skips): crash / boot failure; garbage,
  request errors, short output; zero acceptance (< 2 % after >= 200 drafts); the TF envelope; NaN (non-finite logprobs);
  real fallbacks (SPEC_MISMATCH: wrong method / K / drafter, MTP on a D arm, DFlash2DraftModel not resolved, an EAGER drafter;
  S4: DRAFT_HEAD / draft_lm_head_quant on a dflash spec is refused at launch); missing init (nb4_ppack NOT_INTEGRATED);
  NO_GO_DRAFT_LOAD_CHECK; the klee100 boot gates. Global setup failures (merge, #60490, k100_setup, sha gate) boot nothing.
  Recorded only: Q-defer labels, parity, memory, prefix cold / warm (0.8 and 0.9 ratios), research B's no-hope cut (smoke
  AL3 < 2.40) and its D4s data gate (c >= 0.80), pos0 STRUCTURAL / TAP_SUSPECT, KV groups, read-back gaps.
- Records: the concurrency trend (D / Q at 8k@16 and at 20k@24, direction), residents at 40k / 64k / 90k / 120k (block 4096)
  next to Q's 29 / 21 / 17 / 13, F at the boot's own block, q_groups vs d_groups, the NaN draft-score count (no cheap read-back
  hook in Merlin: NOT_AVAILABLE), the metadata-build time (from the kept traces).

## Kits
- Units (`q27-e27-nbdf-k100-kit-units`): `BUILD__nbdf_k100_unit_tests.py` (B1 relative-gate fixtures incl. a
  non-deterministic Q A/A that must not stop a D arm, the B3 rung walk, the TF gate, S4, the Q I8 launch check, seqs 24,
  nbdf_main without cross-arm skips) + `BUILD__nbdf_k100_nan_tests.py` (NaN injected in one draft block of the torch
  `_grouped_conv`; neighbours bit-identical). The shared nbdf_lib's 281 tests + the seam tests run in the W4 units kit.
- Real (foysal, klee100 Models + tf-ref dataset): research A's 10 items (R9 Q 480 / D-SW 540 + pages, D-SW F, the core.py
  block drop + level_for_band at 4096, MTP vs drafter bytes from the safetensors headers, R12 on the klee100 inc config 67 = 67,
  `_k100_scan` on the meta drafter + method map, seam / ppack / #60490 three-state, the tokenizer + mask row, captures / argv /
  pack views at 24) + R9_IDX (indexer fp8, record only).

## Known open items
- Q's projected ticks, DFlash2 acceptance on klee100 and humming above T64 are unmeasured (the run measures them).
- The fused CUDA grouped-conv kernel is not covered by the CPU NaN test (torch path only).


## READ FIRST: the closed KV gate is BY DESIGN (not a blocker)
- This notebook (sha d0d3ff0d...) is the CLOSED build: `KV_KIT_GATE.passed = False`, `gpu_ready = false`. Three earlier audits
  reported only this. It is intended: the D arms open only through the gated rebuild
  `build_e27_nbdf_k100.py --kv-gate-report <real kit report>` after the new real CPU kit prints ALL OK (running now on foysal).
- Audit instead: (1) `BUILD__nbdf_gate_verify.py` (asserts passed, gpu_ready, embedded CELL 7 == build facts, per_k and the
  explicit `per_k_success[D3s|D4s].success`); (2) `k100_gate_extra` in `BUILD__build_e27_nbdf_k100.py` (can only close the gate;
  needs the kit ALL_OK and all 10 k100_* checks); (3) that nothing else can skip D3s / D4s.
- Kit v1 (`KITV1__...FAILED_kitside.json`) failed on two KIT-side bugs, both fixed in `BUILD__build_e27_nbdf_cpu_kit.py`
  (see `REPORT__agent_round2_kitfix.md`): the scales sidecar was not written before the kit's R4 launch dry-run (the notebook
  writes it in k100_setup before Q), and the klee100 layer name `qwen_sparse_attention` was not treated as attention, so the
  D-SW simulation kept the MTP layer (540 vs 480; the 540 is now record-only). The other units kits and the W4 real kit were ALL OK.
- Round 3 (`REPORT__agent_round3_noskip_loadcheck.md`): the last cross-arm skip is removed (a failed Q ppack before_arm skips
  only Q); the draft_load_check parser is proven against the seam's own emit line (no prefix / prefix / reprint pass; one worker,
  skipped or PP0 fail); test K6 = Q failure matrix (crash, I8 retry fail, smoke fail, oracle NO_GO, base unusable, Q-defer real
  failure, ppack fail -> D3s and D4s still launch). Local: shared 281/281, K100 59/59, NaN 173/173, gate 11/11.
- THE KEY QUESTION FOR THIS AUDIT: once the gate is open, can ANY path still skip / stop D3s or D4s other than a real failure
  of that same arm (crash, garbage, errors, zero accept, TF envelope, NaN, SPEC_MISMATCH, S4, missing init, draft load check,
  boot gates) or the time budget? List every such path with file:line.
