# E27 NBDF audit: DFlash2 vs MTP K3 GPU notebook (Qwen3.8-Flash-Next W4, Merlin v3.0.0, Kaggle 4 x L4)

**Answer GO or NO-GO on the first line. Then list BLOCKERS ONLY**: defects that would make the GPU run crash, waste the
run, measure the wrong thing, or produce a wrong verdict. For each blocker give the file:line, why it fails, and the
fix. Do not list style, naming, or "nice to have" items.

## What the notebook must do
- Arms in this order: **Q** (MTP K3 + Q-defer, NB4T's base, unchanged) -> **D4s** -> **D3s** (drafter SW block 1024)
  -> **D4** (short control) -> **D4t** (conv impl torch, short) -> **D7** (only if the seam's QSA ring widening verifies)
  -> **D4b** (optional: FP8 drafter KV + TRITON_ATTN). One Q-defer isolation rerun of the first failing D arm
  (`NB4_PPDEFER` unset).
- D arms: `dflash_seam.py` applied after `nb4_ppack.py` (three-state tree check before each boot), the seam env
  (`DFLASH_SEAM=1`, `DFLASH_MASK_ROW_SHA`, `DFLASH_QSA_RING_WIDEN=1` at K >= 5), a trailing
  `--speculative-config {"method":"dflash","model":<drafter dir>,"num_speculative_tokens":K,"draft_sample_method":"probabilistic","kv_cache_dtype":"auto","attention_backend":"FLASH_ATTN"}`
  and a trailing `--compilation-config` with the multiples of 1 + K up to 8 x (1 + K).
- Drafter Kaggle Model `foysalemonshanto/qwen38-flash-next-dflash2v2/transformers/bf16-embed/1` (files in a
  `bf16-embed/` subfolder; glob-resolved, exactly one dir), pinned shas checked from the header + tensor bytes.
- Pins: Q 3,553,580,524; D arms start 1-2 rungs (0.25 GiB) lower; a launch OOM or a rank below 512 MiB free (after
  ready / after the first decode) steps one rung lower.
- Per arm: read-backs (env, config, Q-defer exec / fallback share, DFlash: arch, drafter FULL graphs, draft backend,
  aux taps [6, 16 | 26, 36, 46] on all 4 ranks, embedding + mask row, B5 release, load check, ring, KV layout, pool / F
  vs Q, memory per stage) -> smoke (2 x 2,048 + the concurrency ladder alone / +2 / +4 / +7, zero-accept canary) ->
  greedy oracle vs Q by token ids (+ the K = 4 AL early exit) -> long oracle 90k + 116k -> prefix cold / warm 2-turn
  acceptance -> 8k@8 x 2, 40k, 90k, 116k at the resident level (Q: A/A) -> profiles 8k + 116k.
- Every response saved (gzipped jsonl per arm); garbage under load gated by the windowed 2,000-token check, the
  stream-level check recorded only.
- Verdict: WIN only with 8k PASS on both windows, valid 40k, 90k and 116k without regression beyond max(Q A/A, 2 %),
  long oracle and prefix PASS; else SHORT_ONLY_WIN / NO_GAIN / REGRESSION / named failure.
- Hard stop 150 min, absolute deadman 155 min. CELL 0 = E18 R2's cell 1 verbatim (a competition rerun writes only the identity submission).
- Notebook < 400 kB: the modules and the CELL 7 body are lzma + base85, sha-checked, exec'd into the notebook globals.
  **Read `BUILD__nbdf_cell7_body.py` for the readable CELL 7 body**; `nbdf_code_export.py` = the notebook's code cells exactly.

## Gate rule (USER RULE 2026-11-01, after GPU commit 8b1760ed skipped every D arm on a Q-defer label)
A measurement label / read-back never skips or aborts an arm. Only REAL failures gate: crash / launch failure, oracle
FAIL / garbage, DFLASH_ZERO_ACCEPT (and the other smoke FAILs: request errors, short output, no drafts, concurrency
contamination at high margin), ADMISSION_DEADLOCK, NO_GO_DRAFT_LOAD_CHECK, tree INVALID / not integrated, and a real
Q-defer failure (`nbdf_lib.qdefer_real_failure`: not applied, init lines < 4, any rank fallback_share > 0, or
flush_recv + flush_consume > 5 % of defer_park). Q is a usable base (`nbdf_lib.base_usable`) when DONE, correctness
CLEAN, oracle / long oracle not FAIL and no real Q-defer failure; ENGAGED_FALLBACK / exec_share, parity, memory-gate
readings, INCONCLUSIVE smoke / oracle, read-back gaps or contradictions and a missing per-K kit summary are recorded
(flags) and the D arms run. Say if any kept gate is not a real failure, or any demoted one is.

## Known open items (not blockers by themselves; say if you think one is)
- The D arms are skipped at run time (`SKIPPED_KV_KIT_GATE`) until the real CPU kit's `get_kv_cache_configs` check
  passes and the notebook is rebuilt with `--kv-gate-report`. The kit's KV probe uses synthesized per-stage specs from
  the NB4T GPU record (K = 3 state shapes), calibrated on Q's 215 blocks.
- The CPU box cannot import `vllm._C`; the patched-model import and the drafter loaded-weights probe may come back
  "unavailable" on CPU (recorded); the GPU boot is the final proof.

## Files (flat)
- `NB__Q27-XHIGH-E27_NBDF_DFLASH2.ipynb` (the GPU notebook), `BUILD__nbdf_code_export.py` (readable),
  `BUILD__build_e27_nbdf.py`, `BUILD__nbdf_lib.py`, `BUILD__nbdf_build_facts.json`, `BUILD__nbdf_unit_tests.py`,
  `BUILD__build_e27_nbdf_cpu_kit.py`, `BUILD__dflash_seam.py`, `BUILD__dflash_seam_tests.py`, `PUSH__kernel-metadata.json`.
- Base: `E25__nb4t_lib.py`, `E25__nb4_ppack.py`, `E25__E25_NB4T_GPU_v1_2026-11-01.md`.
- Plan and reports: `E27__README.md`, `REPORT__verify_A_engine.md`, `REPORT__verify_B_drafter_gain.md`, `REPORT__seam_build.md`.
- Merlin source (ad42e37) the flags come from: `MERLIN__*`.
