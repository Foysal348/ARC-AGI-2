# Research and port request: DFlash2 speculative decoding for Qwen3.8-Flash-Next in our two Merlin notebooks (2026-11-01)

All files are flat; read every file before answering. Prefixes:
- `W4__`: notebook 1, our production W4 path, with its GPU output;
- `K100__`: notebook 2, the klee100 low-bit path, with its GPU output;
- `DF__`: our feasibility report and external patches;
- `MERLIN__`: Merlin v3.0.0 source files (a vLLM 0.32.0 fork, commit ad42e37), path with `__`.

## Context
- **Platform:** Kaggle 4×L4 (24 GB each, sm_89, PCIe, P2P off, NCCL over SHM).
- **Engine:** Merlin v3.0.0 with TP2 × PP2 + EP, the V2 model runner, async scheduling, FULL_AND_PIECEWISE graphs, FP8 E4M3 QSA KV with static scales, and RecoverSSM. Speculation today is MTP K3, probabilistic.
- **Model:** Qwen3.8-Flash-Next (48 layers: 36 GDN + 12 QSA, 512 experts top-10, hyper-connections hc = 4, PLE pinned on the host).
- **Workload:** the Duck agentic harness on ARC-AGI-2, xhigh long reasoning (attempts up to 104k generated tokens), 9-21 concurrent streams.

### Notebook 1: W4 (`W4__Q27-XHIGH-E25_NB6_SUBMIT.ipynb`, and `W4__Q27-XHIGH-E25_NB6Q_SUBMIT.ipynb` = NB6 + Q-defer)
- W4A16 Merlin checkpoint, pool 214 blocks, 9 workers.
- Measured: steady Duck 225 tok/s; with Q-defer, synthetic 8k@8 309 tok/s (NB4S).
- MTP K3 Duck acceptance: AL 2.83, positions 0.795 / 0.599 / 0.439.
- Stage 1 (the last PP rank: target layers 25-47, MTP drafts, LM head) binds the tick at about 33 ms.
- GPU outputs: `W4__OUT__*` (the NB6 commit run).

### Notebook 2: klee100 (`K100__Q27-XHIGH-E26_K100_QUALITY.ipynb`; base load test `K100__Q27-XHIGH-E25_KLEE100_LOAD_K3ONLY.ipynb`)
- Low-bit klee100 checkpoint: W3 g128 / W2 g64 routed experts on humming kernels, W4 MTP.
- Pool 479 blocks, 21 workers.
- Measured: 460-562 tok/s at 16-24 streams (synthetic, MTP K3).
- GPU outputs: `K100__OUT__*` (the K3_ONLY v2 run).

### The candidate drafter
`incoai/Qwen3.8-Flash-Next-DFlash2` on HuggingFace:
- DFlash2DraftModel, 5 layers, hidden 2560;
- `block_size` 8, `target_layer_ids` [5, 15, 25, 35, 45], `mask_token_id` 248077, vocab 248320;
- about 603M BF16 params, with no `embed_tokens` and no `lm_head`;
- served only in SGLang, TP1, block 4.

### Our feasibility report (`DF__DFLASH2_FEASIBILITY_2026-11-01.md`)
- **Merlin already has:** the DFlash / DFlash2 model classes, the V2 speculators, the PP aux-hidden relay helpers, and hybrid drafter KV support.
- **Missing:**
  1. The Qwen4Exp allowlist entry (`MERLIN__model_executor__models__config.py`, around 1049-1058).
  2. The aux-hidden-state seam on Qwen4Exp: EagleModelMixin and SupportsEagle3, with taps averaged over the 4 HC streams. `DF__roozich_patch_dflash_qwen4exp.py.txt` is a third-party patch for upstream 0.32.0; it was NOT executed.
  3. The PP2 relay of the taps. The template is `MERLIN__models__deepseek_v4__nvidia__model.py`, around 1466-1527.
  4. The drafter's `embed_tokens` on PP rank 1 (`maybe_share_target_embed` returns early under PP), otherwise silent garbage.
  5. For K ≥ 5, the QSA ring widening (`qsa_cache.py` around 960-965, vLLM PR #54912).
- **Estimated gain:** K = 3 about +9 % (−8 % to +28 %). K = 4 and K = 7 are unmeasured.

## What we ask
1. **Feasibility:** confirm or refute every claim in the feasibility report against the Merlin source files. Is DFlash2 under TP2 × PP2 + EP + V2 + FULL graphs + RecoverSSM / GDN + FP8 QSA KV workable? List every blocker we missed.
2. **Problems:** find every likely failure. For example:
   - tap capture under hyper-connections;
   - PP relay ordering with our Q-defer patch (deferred PP receive: `W4__nb4_ppack.py`);
   - the drafter KV group in the hybrid allocator (block 4096, F = 6);
   - prefix caching across Duck turns;
   - drafter prefill running eager;
   - the embedding share;
   - mask_token_id vs the tokenizer;
   - the QSA ring;
   - async scheduling;
   - capture sizes;
   - memory on the PP1 cards (W4 has about 191 MiB free; klee100 about 1.19 GiB).
3. **Solutions:** a concrete fix for each problem, with file:line and a code sketch.
4. **Porting plan for BOTH notebooks:**
   - exactly how to add DFlash2 to notebook 1 (W4, NB6Q) and to notebook 2 (klee100, K100Q): which patch files, where to apply them (after the Merlin install, like our Q-defer patch: pre / post sha checks, fail-safe revert), the speculative-config, the drafter Kaggle Model layout (with or without an embedding copy), and the capture sizes;
   - which K (3 / 4 / 7) to try first on each;
   - how it combines with Q-defer;
   - the expected tok/s on each, using our measured numbers.
5. **The cheapest decisive GPU experiment:** at most 3 arms, with exact flags, read-backs and pass gates (acceptance per position, oracle / garbage check, tok/s at equal streams).

Answer each item with evidence: source lines, docs, PRs.
