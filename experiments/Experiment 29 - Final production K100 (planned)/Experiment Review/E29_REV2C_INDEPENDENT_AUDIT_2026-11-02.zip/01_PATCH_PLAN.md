# Exact developer patch plan — not a drop-in replacement for SHA-pinned payload

The E29 notebook builds and verifies the strict SHA of `arc2_duck.py`, `e29d_sched_patch.py`, and `e29_nbx.py`. **Do not overwrite a module inside the Kaggle payload without rebuilding `e29_direct_build.py`, `e29d_sched_patch.py`, e29 payload SHA pins, notebook builder and test kits.** The following changes are code-level instructions for the source builder.

## H1: Guard Phase-C DIRECT *before* Duck C is replaced

1. In the scheduler patch's global hook block alongside `E29D_RUN = None` add:

```python
E29D_CAN_START = None  # notebook hook: (solve_deadline_monotonic) -> bool
```

2. Replace the conditional in the patched `worker()` **before** the original `sess(tid,p,qpos)`:

```python
if (
    p["phase"] == "C"
    and _e29d_on()
    and callable(E29D_CAN_START)
    and E29D_CAN_START(deadline)
):
    # EXISTING special DIRECT branch, unchanged
    ph, s, t_start = "C", None, _sec()
    e28["started"]["C"] += 1
    e28["first_start_sec"].setdefault("C", _sec())
    e28["last_start_sec"]["C"] = _sec()
    state["running"] += 1
    active.add((tid, 1))
    break
# ORIGINAL `s = sess(tid,p,qpos)` remains the fallback (Duck C).
```

3. On successful E29 notebook `e29_direct_setup()` (in generator source `e29_nbx.py`):

```python
E12A.E29D_RUN = e29_direct_run
E12A.E29D_CAN_START = lambda deadline: (
    time.monotonic() + 60.0 + float(E29_DIRECT2['drain_min']) * 60.0 < deadline
)
```

Clear both hooks on OFF or failed setup. The 60 seconds is a configurable **start margin**, not a promise that Duck C itself will finish. `e29_direct_run` still handles unexpected deadline expiry safely.

**Tests:** with solve_end-now=31m -> DIRECT branch; 20m -> ordinary Duck C; 1m -> original Duck behavior; switch OFF -> original Duck behavior and answer; failing hook -> no direct. Test `E28_RELEASE` exactly once per path and `e28.done.C` exactly once.

## H2: In-run XID must drop DFlash (same as documented preboot policy)

In `e29_lib.py::df_relaunch_plan()`:

```python
def df_relaunch_plan(cur, log_text, tries):
    if is_device_fault(log_text):
        return 'mtp'           # XID, illegal memory access, launch failure
    if not is_oom(log_text):
        return None            # normal dead server / health error, same plan retry
    rungs = [t for t in tries if t.get('df')]
    i = next((j for j,t in enumerate(rungs)
              if cur and t['df'].get('rung') == cur.get('rung')), None)
    return rungs[i+1] if i is not None and i+1 < len(rungs) else 'mtp'
```

Do not change the existing regular OOM rung progression. If the device is permanently lost, even the MTP fallback can fail; preserve the CELL0 submission fallback and return a clear `GPU_DEVICE_FAULT` report.

**Tests:** `NVRM: Xid 79` -> MTP; `NVRM: Xid 79 + CUDA OOM` -> MTP; plain CUDA OOM rung0 -> rung1; healthy non-OOM death -> same-config; final rung OOM -> MTP. Confirm MTPTOP pin, I8, argv and QSA env reset on the full runtime path.

## H3: Seam revert must be fail-closed

In `e29_drop()` do **not** swallow `SSEQ.finish()` exceptions and then mark the tree safe for MTP. Obtain expected original file-SHA manifest *before* seam apply and verify it *after* rollback.

```python
if lever == 'df' and SSEQ is not None and not FAKE:
    try:
        rec = SSEQ.finish()
        clean = verify_pristine_seam_files(PRISTINE_SEAM_FILE_SHAS)
    except Exception as exc:
        clean = False
        rec = {'error': repr(exc)}
    if not clean:
        E29_RT.setdefault('errors', []).append('SEAM_REVERT_UNVERIFIED: ' + repr(rec))
        raise RuntimeError('SEAM_REVERT_UNVERIFIED: refusing MTP boot on a possibly modified tree')
# Only now remove 'df' from E29_RT['on'] and restore I8.
```

`verify_pristine_seam_files` and the baseline SHA map are **new functions/data to implement in the builder**; do not copy the snippet without supplying them. Preserve the last valid CELL0/E15B submission and the fault report if fail-closed. CPU regression: injected `finish()` raise -> no MTP relaunch; valid revert restores exact SHA of every changed module; partial restore -> no MTP relaunch.

## New exact identity and validation

- Rebuild generated scheduler patch; update PRE/POST/PATCH SHA, new payload module SHA, notebook's `E29D_FILES`, notebook SHA and rev2c kit facts.
- Run the complete `e29_sched_tests.py`, `e29d_direct_tests.py`, `e29_kit_lib_tests.py`, plus new H1/H2/H3 adversarial cases on the same generated build.
- Run 4×L4 Kaggle CPU/real-kit before spending a 6h commit. Then a short smoke: DIRECT early and late C, a fake XID as a watchdog fixture, long-context QSA 128/64 worker readback, submission JSON schema.
