# E29 rev2c independent audit bundle

First-line verdict: **NO-GO for unmodified production rev2c** because of HIGH risks H1 (late DIRECT C silently no-ops), H2 (in-run XID retries DFlash despite MTP requirement) and H3 (failed seam revert swallowed on fallback).

Start with `00_AUDIT_REPORT.md`, then `01_PATCH_PLAN.md`. Run `python audit_repro_e29.py` to independently exercise key exact source paths. Run `python e29_kit_lib_tests.py` with the command/environment described below for the 33/33 local boot tests.

**Scope:** This ZIP is an audit and code-level fix plan; it is **not** a regenerated SHA-pinned Kaggle notebook. The developer's original E29 builder and full Duck dataset are absent and were not reconstructed. All new conditions must be integrated into the builder and artifacts regenerated before GPU.

Optional 33-unit re-run from this bundle:

```bash
E29LT_NB=Q27-XHIGH-E29_DFLASH_D3S.ipynb \
 E29LT_FACTS=e29_dflash_d3s_build_facts.json \
 E29LT_KF=audit_kit_facts.json \
 E29LT_NB5LIB=nb5_lib.py \
 python e29_kit_lib_tests.py
```

`audit_kit_facts.json` was reconstructed solely for local tests from checked literals and is not an authoritative original Kaggle kit report. The `nb5_lib.py` fixture was recovered from another previously supplied E25 archive, not this exact E29 upload. The full `e29_sched_tests.py` / `e29d_direct_tests.py` require unavailable original Duck payload and were not run.
