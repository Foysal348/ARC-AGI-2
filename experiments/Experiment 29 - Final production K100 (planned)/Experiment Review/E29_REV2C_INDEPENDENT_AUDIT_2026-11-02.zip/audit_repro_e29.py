"""Independent E29 rev2c static/dynamic reproductions. Offline; no GPU or user dataset required."""
import ast
import json
import tempfile
import time
import types
from pathlib import Path

import e29_lib as L
import e29_direct as D

CODE = Path(__file__).with_name('e29_dflash_d3s_code_export.py').read_text()
TREE = ast.parse(CODE)
wanted = {'e29_drop', 'e29_mtp_boot', 'e29_relaunch_plan'}
ns = {
    'E29L': L,
    'DS': types.SimpleNamespace(ALL_ENVS=('DFLASH_SEAM', 'DFLASH_DRAFT_EMBED_HOST', 'DFLASH_DRAFT_SW_BLOCK', 'DFLASH_MASK_ROW_SHA')),
    'E28_I8_ENV': {'DRAFT_HEAD': 'int8'},
    'E28_I8': {'want': True, 'on': False},
    'K100_PIN_STEPS_GIB': [L.gib_of(L.D_PIN0)],
    'NB5_ACTIVE_BOOT': {},
    'E29_RT': {'on': ['df'], 'dropped': [], 'errors': [], 'df': {}, 'df_try': True, 'df_live': True, 'df_cur': {'rung': 0}, 'relaunch_plans': []},
    'SSEQ': None,
    'FAKE': False,
    'NOTEBOOK_T0': time.perf_counter(),
    'time': time,
    'json': json,
    'log': lambda *a, **kw: None,
    'E29_CFG': {'embed_host': True},
    'e29_env': lambda df: {'DFLASH_DRAFT_EMBED_HOST':'1', 'DFLASH_SEAM':'1', 'VLLM_SPARSE_INDEXER_MAX_LOGITS_MB':'128', 'VLLM_E2_QSA_LOGITS_GRANULE_MB':'64'},
}
for x in TREE.body:
    if isinstance(x, ast.FunctionDef) and x.name in wanted:
        ex = ast.Module(body=[x], type_ignores=[])
        exec(compile(ast.fix_missing_locations(ex), '<real E29 function>', 'exec'), ns)

TAIL = L.df_spec_argv('{"method":"dflash","num_speculative_tokens":3}', '{"cudagraph_mode":"FULL_AND_PIECEWISE"}')

def reset(rung):
    ns['E28_I8'] = {'want': True, 'on': False}
    ns['E29_RT'] = {'on': ['df'], 'dropped': [], 'errors': [], 'df': {'tail': TAIL}, 'df_try': True, 'df_live': True, 'df_cur': {'rung': rung}, 'relaunch_plans': []}
    ns['NB5_ACTIVE_BOOT'] = {
        'name': 'D', 'kv_bytes': L.D_RETRY[-1][0], 'levers': {
            'DFLASH_SEAM': '1', 'DFLASH_DRAFT_EMBED_HOST': '1',
            'VLLM_SPARSE_INDEXER_MAX_LOGITS_MB': '128',
            'VLLM_E2_QSA_LOGITS_GRANULE_MB': '64',
        },
        'extra': ['--max-num-seqs', '24'] + TAIL,
        'pin_gib': L.gib_of(L.D_RETRY[-1][0]),
    }

reset(0)
ns['e29_mtp_boot']('TEST_DIRECT_MTP_FALLBACK')
a=ns['NB5_ACTIVE_BOOT']
assert a['kv_bytes']==L.D_PIN0
assert a['levers'].get('DRAFT_HEAD')=='int8'
assert not (set(a['levers']) & set(ns['DS'].ALL_ENVS + L.QSA_KEYS))
assert a['extra']==['--max-num-seqs', '24']
assert 'df' not in ns['E29_RT']['on'] and ns['E28_I8']['on']
print('PASS: actual E29 e29_mtp_boot => top pin + I8 + clean env/argv')

reset(0)
class Old:
    def __init__(self,s): self.s=s
    def log(self): return self.s
ns['e29_relaunch_plan'](Old('torch.OutOfMemoryError: CUDA out of memory'))
assert ns['NB5_ACTIVE_BOOT']['kv_bytes']==L.D_RETRY[1][0]
assert ns['NB5_ACTIVE_BOOT']['levers']['DFLASH_DRAFT_EMBED_HOST']=='1'
print('PASS: actual E29 e29_relaunch_plan => next D rung')

reset(4)
ns['e29_relaunch_plan'](Old('torch.OutOfMemoryError: CUDA out of memory'))
a=ns['NB5_ACTIVE_BOOT']
assert a['kv_bytes']==L.D_PIN0 and a['levers']['DRAFT_HEAD']=='int8' and 'df' not in ns['E29_RT']['on']
print('PASS: actual E29 e29_relaunch_plan end => MTP top + I8')

reset(0)
ns['e29_relaunch_plan'](Old('NVRM: Xid (PCI:0000:01:00): 79\ntorch.OutOfMemoryError: CUDA out of memory'))
assert ns['NB5_ACTIVE_BOOT']['kv_bytes']==L.D_RETRY[-1][0]
print('REPRODUCED HIGH: XID leaves DFlash boot plan unchanged, despite README requiring MTP')

def enc(s):
    if s==D.STOP_THINKING_TEXT: return list(D.FN_STOP_IDS)
    if s=='</think>': return [D.FN_THINK_CLOSE_ID]
    return [1000+ord(c) for c in s]

tok={'render':lambda msgs: msgs[0]['content'], 'encode':enc, 'decode':lambda ids,k:'', 'eos_ids':list(D.FN_EOS_IDS)}
tasks={'late001':{'train':[{'input':[[1]],'output':[[1]]}],'test':[{'input':[[2]]}]}}
with tempfile.TemporaryDirectory() as td:
    out=D.solve_all_direct(tasks,['late001'], out_dir=td,
        deadline=time.monotonic()+20*60, base_url='http://127.0.0.1:9', model_id='mock', workers=1,
        cfg={'think':104000,'answer':8192,'temperature':1.0,'drain_min':26},tok=tok,harness=True,
        health=lambda:True,log=lambda *a,**kw:None)
    rep=json.loads((Path(td)/'e31_direct_report.json').read_text())
    assert out['late001']==[]
    assert rep['sched']['admitted']==0 and rep['sched']['not_admitted']==1
    print('REPRODUCED HIGH: phase-C with 20m remaining: 0 DIRECT requests, no result')
# Source-level XID branch test: in-run helper returns None; e29_relaunch_plan returns without e29_mtp_boot.
assert L.df_relaunch_plan({'rung':0}, 'NVRM: Xid 79\nCUDA out of memory', L.df_tries(True)) is None
print('REPRODUCED HIGH: in-run XID returns None, triggering same-config DFlash relaunch')

# Failure injection: seam restore failure is swallowed, yet DFlash is marked dropped / I8 restored.
class BrokenSeam:
    def finish(self):
        raise RuntimeError('injected revert failed; original Merlin tree not restored')
reset(0)
ns['SSEQ'],ns['FAKE']=BrokenSeam(),False
ns['e29_drop']('df','TEST_SEAM_REVERT_THROW','D')
assert 'df' not in ns['E29_RT']['on']
assert any('seam finish' in e for e in ns['E29_RT']['errors'])
assert ns['E28_I8']['on'] is True
print('REPRODUCED FAIL-OPEN: seam rollback throws, DFlash still marked dropped and MTP remains enabled')
print('7 independent checks completed')
