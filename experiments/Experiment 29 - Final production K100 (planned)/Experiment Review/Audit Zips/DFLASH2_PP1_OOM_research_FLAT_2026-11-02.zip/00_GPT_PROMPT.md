# RESEARCH: eliminate the DFlash2 first-request OOM on PP1 (Qwen3.8-Flash-Next klee100 3bpw on Merlin vLLM-0.32 fork, Kaggle 4x L4)

**Goal.** Find the BEST way to make this OOM never happen, not just a way to recover from it with a retry ladder, while keeping as much KV and speed as possible.

**Deliverable.**
- The root-cause memory accounting per rank.
- A ranked list of fixes, each with the exact config / env / patch (file:line) and its KV / speed cost.
- A GPU validation plan: what to read back to prove each fix worked.

No style items.

## Setup (identical in every run)
- **Parallelism:** TP2 x PP2, PP partition 25,23. PP1 = GPU 2,3 and also holds the LM head and the DFlash2 drafter.
- **KV cache:** `--kv-cache-memory-bytes 7933526016`, i.e. 7.39 GiB per worker. Memory profiling is skipped; the log says "Initial free memory 21.67 GiB, reserved 7.39 GiB ... skipped memory profiling".
- **Serving:** FP8 QSA KV, max-num-seqs 24, block 4096. The DFlash2 drafter's SW block is 1024. max-num-batched-tokens is in the argv in the logs.
- **Drafters:**
  - MTP reference: MTP K3 + I8.
  - D3s: DFlash2 K3 with BF16 drafter KV, FLASH_ATTN and dflash_seam.
- **Other:** Q-defer (nb4_ppack) is on.

## What happened on GPU (2026-11-01/02)
1. **MTP, no OOM.** E28 K100, same pin, 6 h (`REF_E28_K100_MTP_nb5_report.json`). GPU memory used after ready was about 20.3 / 20.3 / 21.9 / 21.9 GiB of 23.0.
2. **DFlash2 D3s without `DFLASH_DRAFT_EMBED_HOST`: OOM on the first request.** Log: `GPU1_NBS1_v1_OOM__server_nbs1_b.log`.
   - **At ready:**
     - model load: PP0 11.45 GiB, PP1 12.64 GiB;
     - graphs: 0.92 / 0.94 GiB;
     - free per card: [1473, 1469, 631, 631] MiB.
   - **The crash:** the first sampled request hit a torch OOM on GPU 2 / 3.
     - Location: the `torch.empty(...)` backing allocation in `qsa_indexer.py:801 qsa_select_paged_prefill`, called from `indexer_qsa.py:503 forward` with `backing_bytes=self._prefill_backing_bytes`.
     - Message: "Tried to allocate 256.00 MiB ... 161.06 MiB is free ... 350.91 MiB reserved but unallocated".
     - Then EngineCore died.
   - **F8 arm:** the same OOM, with 141 MiB free. F8 = fp8 drafter KV, TRITON_ATTN, SW 2048.
3. **DFlash2 D3s with `DFLASH_DRAFT_EMBED_HOST=1`, same pin: runs.** EMBED_HOST puts the drafter embedding on the host (`OURS__dflash_seam.py`). Logs: `GPU2_SMOKE__*`, `GPU3_FULL__*`.
   - Free after ready: [1431, 1427, 1047, 1047] MiB.
   - End-of-run minimum (worker view): [961, 957, 577, 577] MiB.
   - Every window from 8k@16 to 116k@6 ran, with 0 preemptions.
   - **But** each arm's FIRST try, which had no EMBED_HOST, OOM'd, and the ladder retried.
4. **Per-try facts:** `GPU_memory_facts_per_arm_try.json` holds every try's memory stages, free MiB, pool, residents and the OOM lines (extracted).

**Our current mitigation** (E29 rev 2, `OURS__E29_DFLASH_D3S_rev2_report.md`):
- EMBED_HOST from the first try;
- a pin ladder 7.93 → 7.67 → 7.40 → 6.86 GB, stepped on an OOM at any stage;
- then the MTP fallback.

Our memory gate only checks that each rank has at least 512 MiB free after ready.

## Questions
**1. Exact accounting on PP1.**
- What is the size of the paged-prefill backing (`_prefill_workspace_bytes`, the granule / fixed-size logic)?
- When is it allocated: on the first prefill only, on every call, or cached?
- What other first-request transients exist on PP1? Candidates: the fp32 draft_logits, the DFlash aux hidden states, the sampler, NCCL buffers, cudagraph pools.
- Why does MTP fit and DFlash not? DFlash adds the drafter (0.73 GiB) and its embedding (0.59 GiB) against the MTP module.

**2. Best fixes.** Candidates to evaluate:
- (a) Pre-allocate or cap the indexer prefill backing at startup, so it is counted before KV. Is there an env or config for this in Merlin (`VLLM_QSA_*`)?
- (b) A per-PP-rank KV size (PP1 smaller than PP0). Is this possible with kv_cache_memory_bytes / gpu_memory_utilization in vLLM 0.32 / Merlin?
- (c) The effect of max-num-batched-tokens and the long-prefill chunk on the backing size.
- (d) `PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True`, to address the 350 MiB of reserved-but-unallocated fragmentation.
- (e) EMBED_HOST always on. What does it cost in host RAM and speed?
- (f) A memory gate that measures the real worst-case first-prefill transient (for example a forced max-size prefill probe at boot) instead of a fixed 512 MiB.
- (g) Anything else: moving the LM head or the drafter, a smaller drafter KV, a 24,24 partition.

For each fix give:
- the expected free MiB after the first prefill;
- the KV tokens lost;
- the risk;
- how to verify it on GPU.

**3. Production recommendation.** Which ONE change set do you recommend for production (12 h, 24 streams, prompts up to 131k), and what read-back proves it?

**Note.** The `MERLIN_LOCAL__*` files are a LOCAL copy of Merlin. The GPU ran Merlin v3.0.0 ad42e37, so line numbers in the GPU traceback (e.g. qsa_indexer.py:801, indexer_qsa.py:503) may differ slightly from these files. Match by function name.
