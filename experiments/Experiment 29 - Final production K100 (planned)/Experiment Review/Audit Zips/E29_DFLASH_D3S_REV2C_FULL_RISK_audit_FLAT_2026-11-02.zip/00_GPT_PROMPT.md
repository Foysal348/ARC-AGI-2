# EXHAUSTIVE risk / bug / blocker hunt: E29_DFLASH_D3S rev 2c (hybrid Duck + DIRECT on DFlash2), Kaggle ARC-AGI-2, 4x L4

**Goal.** Find EVERY risk, bug, blocker and weak point before this notebook's GPU smoke and its 6-h EVAL commit. It is a production candidate: its 12-h competition rerun writes the real submission.

**Output format.**
1. GO or NO-GO on the first line.
2. A ranked table: BLOCKER, SEVERE, HIGH, MEDIUM, LOW. Each row gives:
   - id;
   - file:line;
   - what fails, and the trigger;
   - the impact (crash / wasted run / lost or wrong answer / wrong score / deadline / slow / silent fallback);
   - the evidence;
   - the exact fix;
   - the test that proves the fix.
3. Mark each finding CONFIRMED (you reproduced it, or read it in code) or PLAUSIBLE (a reasoned risk).
4. List what you could NOT check.

Do not pad with style items, but do list every real risk, including GPU-only ones the CPU kits cannot see.

## What the notebook is
`Q27-XHIGH-E29_DFLASH_D3S.ipynb`, sha ed2e23a72c7fcbb9a15a9758544d499e59c5b528681387cad4bc23a4710d871c. The readable code is `e29_dflash_d3s_code_export.py`; the history is in `README.md` and `REPORT__*`.

**Base.** E28 K100 EVAL120 6H: 6 h, VALID, task-norm 65.0 %. It is Duck on Qwen3.8-Flash-Next klee100 3bpw-MTP, Merlin vLLM-0.32 fork, TP2xPP2, Q-defer, 24 workers. Its run summary is `REF__E28_K100_run_summary.json`; its code is `REF__e28k100_code_export.py`.

**Layered on top.**

1. **DFlash2 D3s drafter.**
   - It uses `dflash_seam.py` 341d859b, which includes the GRD edit of Merlin `v1/e2_guards.py`.
   - Settings: K3, SW-1024, BF16 drafter KV, FLASH_ATTN, I8 off.
   - `DFLASH_DRAFT_EMBED_HOST=1` from the first try.
   - The D pin ladder is 7.93 → 7.67 → 7.40 → 6.86 GB. A step happens on an OOM at any stage (`df_oom_step`). XID means no step, straight to MTP.
   - After the ladder, or on an XID / gate / GRD failure, the run goes to the E28 MTP top rung: 7.93 GB, 24 seqs, I8 on. Only then does E28's own ladder apply.
   - An in-run zero-accept canary or an OOM with no rung left relaunches on MTP at the top rung.
2. **QSA workspace switch.** `E29_QSA = {'max_logits_mb': 128, 'granule_mb': 64}` is set on the DFlash tries only, after Merlin's build(), which itself sets 256 / 256 (`launch.py:419-420`).
3. **attempts_supply** (E29 S-1).
4. **DIRECT as the second branch.**
   - `E29_DIRECT2 = {'on': True, 'think': 104000, 'answer': 8192, 'temperature': 1.0, 'drain_min': 26}`.
   - DIRECT replaces Duck's phase-C attempt 2 in C's order, inside the same 24-slot worker pool.
   - The solver is `e29_direct.py`, which is the E31 solver (`REF__e31_direct.py`) plus two marked edits.
   - attempt_2 is DIRECT's grid when it is valid and differs from attempt_1; otherwise E28's attempt_2.
5. **LIVE progress lines.** Print only.

**Payload dataset** `foysalemonshanto/q27-e29-final-payload` holds: the seam, e29_direct.py, e29d_sched_patch.py, e29_nbx.py (DIRECT + LIVE notebook functions) and the vocab tables.

## GPU evidence available
- `GPU__memory_facts_per_arm_try.json`: the DFlash2 runs of E25 NB-S1.
  - Without EMBED_HOST the first request OOM'd on PP1. That allocation was the QSA prefill backing of 256 MiB, with 161 MiB free; PP1 free at ready was 631 MiB.
  - With EMBED_HOST every window from 8k to 116k ran, with 0 preemption. PP1 free at ready was 1,047 MiB, and the worker-view minimum was 577.
  - DFlash2 steady tok/s vs MTP was +4 to +16 % (20k@24 763 vs 658; 90k@8 383 vs 339). AL was 3.16.
- `FIXLIST__DFLASH2_PP1_OOM.md`: 3 research reports on that OOM and the chosen fixes.
- `REF__E31_*`: the DIRECT solver's design, the 3 audits, the fix round and the delta audit. The one open delta item, the phase-2 resend keeping its ids, is fixed in e29_direct.py.
- E31 is now running on GPU (MTP base, T 0.6): 24 active, 604-612 tok/s, 2/2 hits so far, KV usage 0.95 at 40 min.

**Not yet run on GPU:**
- DFlash inside a Duck run;
- DIRECT inside the scheduler;
- LIVE;
- QSA 128 / 64;
- the in-run MTP relaunch with I8.

**CPU kits.** The rev 2c kits are running now. The rev 2b real kit (`KIT_rev2b_real__*`) failed on the MTP-fallback-to-pin0 bug, which rev 2c fixes; it is included as evidence. units: 44/44 + 33/33, direct 12/12 (local).

## Check at least
1. **Boot path.** The seam apply, verify and revert. GRD. EMBED_HOST on the first try. The drafter gate. C-11. The method map. The ladder and every drop / fallback branch. A relaunch at every stage. XID handling. The GPU-release wait between tries. The time each try costs vs the window. Whether any try can be skipped or loop forever.
2. **Memory.** PP1 headroom with EMBED_HOST + QSA 128 / 64 at 24 streams and 131k prompts. Whether the env really reaches the workers. The host RAM cgroup, about 177 GB and near its limit with EMBED_HOST. Leaks and fragmentation over 12 h.
3. **Scheduler.**
   - A / B2 / C-DIRECT / supply ordering and starvation.
   - The DIRECT slot use vs the KV pool: 24 long DIRECT contexts, the preemption storm risk.
   - The deadline guard, the drain inside the solve end, and the 12-h rerun timeline. About 240 tasks; A alone takes about 76 % of the window at E28 speed.
4. **DIRECT correctness.** Prompt bytes. The multi-test labels. The phase-1 / phase-2 token-exact path. The resends. The fail-closed STOP_IDS. Temperature 1.0 vs the proven 0.6. Seeds when one task at a time is called. Request errors are never a finish.
5. **Submission.**
   - attempt_1 must never change; the attempt_2 rule; multi-test grid K → test K.
   - The E15B writer and CELL 0's fallback.
   - The rerun writes the real submission. Can any path write a wrong / partial / missing submission.json or crash before writing?
6. **The switches.** E29_DIRECT2 'on': False equals the old path. A bad value. A missing dataset module (e29_nbx.py) means DIRECT / LIVE off and the run continues.
7. **LIVE.** It must never affect the run. It must not slow the scheduler. No gold may leak in the rerun.
8. **Size / packaging.** 396.8 kB vs the 400 kB commit limit. Packed literals and their shas. The dataset versions the notebook expects vs what is mounted.
9. Anything that differs from proven E28 behaviour without a reason.
