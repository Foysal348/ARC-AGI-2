"""Runs the four E29 test files of THIS folder only (self-contained check):  python -I -X utf8 00_RUN_TESTS.py
Every input path is pointed into this folder (no D:/ARC AGI 2 path, no Kaggle mount): the Duck payload, e28_sched_patch.py,
nb5_lib.py, the K100Q / W4 branch records (records_k100q_w4.zip -> _records/), the ARC eval challenges, the payload-dataset
files (by name + sha), the kit_lib facts. Logs: _logs/<test>.log; summary: 00_RUN_TESTS_RESULTS.json. Exit 1 on any failure."""
import json
import os
import subprocess
import sys
import time
import zipfile
from pathlib import Path

H = Path(__file__).resolve().parent
REC, TMP, LOGS = H / "_records", H / "_tmp", H / "_logs"
if not REC.is_dir():
    with zipfile.ZipFile(H / "records_k100q_w4.zip") as z:
        z.extractall(REC)
TMP.mkdir(exist_ok=True)
LOGS.mkdir(exist_ok=True)
ENV = dict(os.environ, E28_TEST_PAYLOAD=str(H / "q27x_e15b_duck_9e4b89285136.bin"), E29_TEST_E28_DIR=str(H), E28_TEST_K100=str(REC / "k100q"),
           E28_TEST_W4=str(REC / "w4"), E28_TEST_EVAL=str(H / "arc-agi_evaluation_challenges.json"), E28_TEST_EXPORTS=str(H),
           E28_TEST_TMP=str(TMP), E29LT_NB=str(H / "Q27-XHIGH-E29_DFLASH_D3S.ipynb"), E29LT_FACTS=str(H / "e29_dflash_d3s_build_facts.json"),
           E29LT_KF=str(H / "e29_kit_lib_facts_dflash-d3s.json"), E29LT_NB5LIB=str(H / "nb5_lib.py"), E29LT_PAYLOAD_DIR=str(H),
           PYTHONIOENCODING="utf-8")
TESTS = [["e29_sched_tests.py", []], ["e29d_direct_tests.py", []], ["e29_kit_lib_tests.py", []], ["e29_rev2d_adversarial_tests.py", ["--no-fallback", "--strict"]]]
# python -I (isolated) where possible: the Duck harness needs `requests`; when it lives only in the user site (-I hides it),
# fall back to -E -P (PYTHON* env ignored, the script dir / cwd not prepended; the user site kept), recorded.
FLAGS = ["-I"]
if subprocess.run([sys.executable, "-I", "-c", "import requests"], capture_output=True).returncode != 0:
    FLAGS = ["-E", "-P"] if sys.version_info >= (3, 11) else ["-E"]
print("interpreter flags:", FLAGS, sys.version.split()[0], flush=True)
out, bad = {"_flags": FLAGS}, 0
for name, extra in TESTS:
    t0 = time.time()
    cp = subprocess.run([sys.executable] + FLAGS + ["-X", "utf8", str(H / name)] + list(extra) + (["--dir", str(H)] if "adversarial" in name else []),
                        cwd=str(H), env=ENV, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=3600)
    (LOGS / (name + ".log")).write_text(cp.stdout + "\n--- STDERR ---\n" + cp.stderr, encoding="utf-8")
    tail = [l for l in (cp.stdout + "\n" + cp.stderr).splitlines() if l.strip()][-6:]
    out[name] = {"rc": cp.returncode, "sec": round(time.time() - t0, 1), "tail": tail,
                 "outside_path_mentions": sum(1 for l in (cp.stdout + cp.stderr).splitlines() if "ARC AGI 2" in l)}
    bad += int(cp.returncode != 0)
    print(f"{'OK  ' if cp.returncode == 0 else 'FAIL'} rc={cp.returncode} {name} ({out[name]['sec']} s)", *("    " + l for l in tail), sep="\n", flush=True)
(H / "00_RUN_TESTS_RESULTS.json").write_text(json.dumps(out, indent=1), encoding="utf-8")
print("ALL OK" if not bad else f"{bad} test file(s) failed")
sys.exit(1 if bad else 0)
