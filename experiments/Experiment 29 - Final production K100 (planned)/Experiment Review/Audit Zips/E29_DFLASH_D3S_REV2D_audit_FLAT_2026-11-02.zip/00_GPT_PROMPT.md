# GPT audit request: E29_DFLASH_D3S rev 2d (Experiment 29, 2026-11-02) -- GO / NO-GO on the rev 2d DELTA only

You audited rev 2c (notebook ed2e23a7) four times (A1 = RISK_AUDIT, A2 = A3 = GPT_AUDIT, A4 = INDEPENDENT_AUDIT; all in this zip
as AUDIT_*). Every finding was verified and turned into the fix list FIX_LIST_E29_REV2C_AUDITS_2026-11-02.md (F1..F14). Rev 2d
(notebook sha256 80d4aeff3127d650cb38653a189caf328bf26dcd95185ea4140e0f7bfa8542c2) applies them. Please review ONLY the rev 2d delta (DELTA_rev2c_to_rev2d.diff + the files it touches)
and answer:

1. First line: **GO** or **NO-GO** for (a) the GPU smoke and (b) the 6 h / 12 h production run.
2. Then ONLY blockers and severe issues of the delta (a crash, a skipped arm, a wasted GPU run, wrong data / a wrong
   submission, a fix that does not do what the fix list says, a regression of rev 2c behaviour). For each: file:line, the
   trigger, the impact, the minimal fix, and a test that would catch it. No style, naming, documentation, medium or low items.

## The fixes to check (FIX_LIST F1..F14)
- F1 / F1+ late phase C: `arc2_duck.E29D_CAN_START(deadline)` (now + 60 s + drain_min x 60 < deadline, set in e29_direct_setup,
  cleared on OFF / failure). The patched scheduler takes the DIRECT branch only when the hook is callable and True; otherwise
  that same item runs the ORIGINAL Duck C session (one C start / completion / reservation release).
- F2 forced max-size first prefill probe on every DFlash try + worker-side free memory (low free -> one D ladder step).
- F3 / F14 QSA 128/64 read-back required on all 4 workers before the first prefill (/proc, else worker RPC); a mismatch or a
  missing rank -> the SAME rung relaunched without the QSA env (Merlin's 256/256 + EMBED_HOST), DFlash kept; UNVERIFIED_QSA label.
- F4 the in-run DFlash -> MTP relaunch runs the E28 boot gates (C-11, method map, I8 read-back / E28's I8 rule).
- F5 effective_algorithm record + experiment_validity DIRECT_OFF (never stops the run). F6 / F13 host cgroup + KV ledger (record only).
- F9 size (< 400 kB, new code in the payload module). F10 in-run XID -> MTP (device fault first), GPU_DEVICE_FAULT recorded.
- **F11 is decided differently from A4's fail-closed proposal** (on purpose: a fail-closed raise kills the whole production run
  and leaves only the CELL 0 identity submission): the pristine sha of every seam-touched file is snapshotted before the apply;
  after SSEQ.finish() (also when it raised) the files are verified, re-restored from the snapshot and verified again; if still
  not pristine, the next MTP boot needs the q_seam_inert read-back (seam env unset): inert -> continue, recorded
  SEAM_REVERT_UNVERIFIED_INERT; not inert -> that try fails (the E28 ladder continues). Judge this decision only for a real
  hole (a way to produce wrong answers or a crash), not for the policy itself.
- F12 submission_check (record only) after the writes, in the report and the LIVE header. F7 / S1 = smoke measurements.

## Executable evidence (run it yourself)
`python -I -X utf8 00_RUN_TESTS.py` in the extracted folder runs, with every path inside the folder:
e29_sched_tests.py, e29d_direct_tests.py, e29_kit_lib_tests.py and e29_rev2d_adversarial_tests.py (--no-fallback --strict).
The adversarial file turns every audit regression (F1, F2, F3, F4, F5, F10, F11, F12 and A4's 7 audit_repro scenarios) into a
plain-assert case on the REAL modules / the notebook's own functions (AST-extracted from e29_dflash_d3s_code_export.py); its
header records the rev 2c results (25 FAIL = the bugs reproduced, 20 SKIP_NOT_IMPLEMENTED) and the expected rev 2d result
(58/58 PASS). Kit reports included: rev2c, rev2d_units, rev2d_real, rev2d_direct.

## Contents
Notebook Q27-XHIGH-E29_DFLASH_D3S.ipynb + PUSH__ (kernel-metadata, payload dataset metadata / SHA256SUMS), every Build module and test, the
dependencies (e28_sched_patch.py, e28k100_lib.py, nb5_lib.py, dflash_seam.py, the Duck payload q27x_e15b_duck_9e4b89285136.bin), the payload-
dataset files by facts sha, records_k100q_w4.zip (branch_result.json of the K100Q / W4 GPU runs) + the public ARC eval
challenges, AUDIT_*, FIX_LIST_*, REPORT__ (agent reports), KIT_<label>__ (Kaggle CPU kit outputs), KITNB__ (kit notebooks),
DELTA_rev2c_to_rev2d.diff, 00_MANIFEST_SHA256.json / SHA256SUMS.

