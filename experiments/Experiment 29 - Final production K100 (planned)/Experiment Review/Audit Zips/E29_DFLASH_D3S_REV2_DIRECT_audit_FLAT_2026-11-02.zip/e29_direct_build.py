"""E29 rev 2 DIRECT (user 2026-11-02, fixed spec): build-time helpers of build_e29_final.py (stdlib only).

DIRECT becomes the SECOND BRANCH (attempt_2) of E29_DFLASH_D3S, behind the CELL 1 switch E29_DIRECT2:
  - e29_direct.py   = E31's solver e31_direct.py (sha 9967a6e0, reused verbatim) + exact-once edits:
                      N1 (the open audit item: a phase-2 resend keeps the already streamed phase-2 ids: prompt = prefix +
                      p2_ids, cap = the remaining answer tokens) and task_index (the ORDER2 seed index of a task in the FULL
                      task set: the scheduler calls the solver one task at a time);
  - e29d_sched_patch.py = the DIRECT diff on arc2_duck.py (the E29 post text d8603109 -> the E29 DIRECT post text): phase C
                      of the E28 A / B / C scheduler runs ONE DIRECT request per task in its worker slot (C's priority order
                      unchanged) through the notebook hook E12A.E29D_RUN; the answer rule (attempt_1 never changes;
                      attempt_2 = the DIRECT grid of that test when valid and != attempt_1, else today's attempt_2).
Both go to the payload dataset (the notebook loads them by name + sha256; the 400-kB commit limit).
"""
import difflib
import hashlib
from pathlib import Path

E31_DIRECT = Path(r"D:/ARC AGI 2/experiments/Experiment 31 - Flash-Next Direct measurement (planned)/Experiment Notebooks/Build/e31_direct.py")
E31_DIRECT_SHA = "9967a6e0c83067e9d4a4bb3cf262614d356b693acc26a573c946faa630362528"


def sha(t):
    return hashlib.sha256(t if isinstance(t, bytes) else t.encode("utf-8")).hexdigest()


def once(text, old, new, label):
    assert text.count(old) == 1, (label, text.count(old))
    return text.replace(old, new)


# ------------------------------------------------------------------ e29_direct.py
DIRECT_EDITS = [
    ("D0 doc", '"""E31 Flash-Next DIRECT (user 2026-11-01): ',
     '"""E29 DIRECT (Experiment 29 rev 2, 2026-11-02) = E31\'s e31_direct.py (sha 9967a6e0) VERBATIM + two marked "E29" edits: N1 (a\n'
     'phase-2 resend keeps the streamed phase-2 ids) and task_index (ORDER2 seeds over the full task set; the E28 scheduler calls\n'
     'solve_all_direct for ONE task per phase-C worker slot). The original docstring follows.\n'
     'E31 Flash-Next DIRECT (user 2026-11-01): '),
    ("D1 version", 'LIB_VERSION = "e31_direct 1.0 (2026-11-01)"',
     'LIB_VERSION = "e29_direct 1.0 (2026-11-02) = e31_direct 1.0 (9967a6e0) + E29 N1 + task_index"'),
    ("D2 signature", "                     max_model_len=MAX_MODEL_LEN, health=None, max_error_retries=2, log=print):\n",
     "                     max_model_len=MAX_MODEL_LEN, health=None, max_error_retries=2, log=print, task_index=None):   # E29\n"),
    ("D3 seed index", "    TASK_INDEX = {t: i for i, t in enumerate(task_ids)}            # seeds do not depend on timing (ORDER2 F13)\n",
     "    TASK_INDEX = {t: int((task_index or {}).get(t, i)) for i, t in enumerate(task_ids)}   # ORDER2 F13; E29: full-set index\n"),
    ("D4 N1", '''        prefix = list(st["prompt_ids"]) + list(st["p1_ids"]) + list(st["p2_prefix"])
        room = max_model_len - len(prefix) - 8
        cap = min(int(answer_cap(st["tid"])), room)
        if cap < 64:
            return False
        st["phase"] = 2; st["p2_cap"] = cap; st["p2_ids"] = []; st["p2_prefix_len"] = len(prefix)
''', '''        kept = list(st["p2_ids"]) if resend else []    # E29 N1: a phase-2 resend keeps the streamed phase-2 ids
        while kept and kept[-1] in EOS_IDS:
            kept.pop()
        prefix = list(st["prompt_ids"]) + list(st["p1_ids"]) + list(st["p2_prefix"]) + kept
        room = max_model_len - len(prefix) - 8
        cap = min(int(answer_cap(st["tid"])) - len(kept), room)    # E29 N1: cap = the remaining answer tokens
        if cap < 64:
            return False
        st["phase"] = 2; st["p2_cap"] = cap; st["p2_ids"] = kept; st["p2_prefix_len"] = len(prefix)
        st["p2_kept"] = int(st.get("p2_kept") or 0) + len(kept)       # E29 N1 (recorded)
'''),
    ("D5 N1 doc", "        (after a phase-2 request error) sends the same prefix again.\"\"\"\n",
     "        (after a phase-2 request error) sends the same prefix + the streamed phase-2 ids (E29 N1).\"\"\"\n"),
    ("D6 N1 record", '"seed_p2": task_seed(TASK_INDEX[tid], 2) if st["p2_cap"] else None, "p2_prefix_len": st.get("p2_prefix_len"),',
     '"seed_p2": task_seed(TASK_INDEX[tid], 2) if st["p2_cap"] else None, "p2_prefix_len": st.get("p2_prefix_len"),\n'
     '               "p2_kept": int(st.get("p2_kept") or 0),   # E29 N1'),
]


def make_direct():
    raw = E31_DIRECT.read_bytes()
    assert sha(raw) == E31_DIRECT_SHA and b"\r" not in raw, ("e31_direct.py is not the pinned 9967a6e0", sha(raw))
    t = raw.decode("utf-8")
    for lab, old, new in DIRECT_EDITS:
        t = once(t, old, new, lab)
    compile(t, "e29_direct.py", "exec")
    return t


# ------------------------------------------------------------------ the DIRECT diff on arc2_duck.py (E29 post -> E29 DIRECT post)
DUCK_MARKER = "# E29 DIRECT: DIRECT as the second branch (attempt_2) of the E28 scheduler: env-gated (E28_SCHED=1 + E29_DIRECT=1 + hook)."
DUCK_EDITS = [
    ("K1 hook", 'E28_RELEASE = None           # notebook hook (N4): (key) -> None, frees a reservation (idempotent)\n',
     'E28_RELEASE = None           # notebook hook (N4): (key) -> None, frees a reservation (idempotent)\n'
     'E29D_RUN = None              # E29 DIRECT hook: (task, task dict, plan, deadline, base_url, model_id, out_dir) -> record | None\n'),
    ("K2 select", "    if _e29_on():      # E29 SUPPLY: the A / B / S best-train rule (S attempts = branches >= 3)\n",
     "    if any(_e29d_is(r) for r in branch_records):   # E29 DIRECT: attempt_2 = the DIRECT grid (the rule below on the rest)\n"
     "        return select_attempts_e29d(task, branch_records, _slots_out)\n"
     "    if _e29_on():      # E29 SUPPLY: the A / B / S best-train rule (S attempts = branches >= 3)\n"),
    ("K3 take", '''                        qlen = [len(qa), len(qb), len(qc)]
                        e28["pop_seq"] += 1
                        start_seq = e28["pop_seq"]
                        try:
                            s = sess(tid, p, qpos)
''', '''                        qlen = [len(qa), len(qb), len(qc)]
                        e28["pop_seq"] += 1
                        start_seq = e28["pop_seq"]
                        if p["phase"] == "C" and _e29d_on():   # E29 DIRECT: branch 1 = ONE DIRECT request, no Duck session
                            ph, s, t_start = "C", None, _sec()
                            e28["started"]["C"] += 1
                            e28["first_start_sec"].setdefault("C", _sec())
                            e28["last_start_sec"]["C"] = _sec()
                            state["running"] += 1
                            active.add((tid, 1))
                            break
                        try:
                            s = sess(tid, p, qpos)
'''),
    ("K4 run", '''            t0 = time.monotonic()
            tag = {"stage": {"A": 1, "C": 2}.get(ph, 3), "e28_phase": ph}
''', '''            t0 = time.monotonic()
            if s is None:                      # E29 DIRECT: the phase-C item runs its DIRECT request in this worker slot
                _e29d_item(tid, p, wi, t_start, qlen, start_seq, t0)
                continue
            tag = {"stage": {"A": 1, "C": 2}.get(ph, 3), "e28_phase": ph}
'''),
    ("K5 item", '''    def worker(wi: int):
        while True:
            try:
                return _worker_body(wi)
''', '''    def _e29d_item(tid: str, p: dict, wi: int, t_start, qlen, start_seq, t0: float):
        """E29 DIRECT: this task's phase-C item = ONE DIRECT request (the notebook's E29D_RUN: e29_direct.py on the same
        server), published as branch 1 (submissions[{test_outputs}], accepted False, train_exact []). No record (an error,
        or not admitted after the DIRECT drain point) = nothing published: the E28 attempt_2 rule stands for that task."""
        rec, err = None, None
        try:
            rec = E29D_RUN(tid, tasks[tid], dict(p), deadline, base_url, model_id, Path(out_dir) / "direct")
        except Exception as exc:
            err = f"{type(exc).__name__}: {exc}"[:300]
            log.warning("%s E29 DIRECT failed: %s", tid, err)
        if E28_RELEASE is not None:
            try:
                E28_RELEASE((tid, 1))
            except Exception:
                pass
        x = (rec or {}).get("e31") or {}
        m = meta.get((tid, 1)) or {}
        row = {"task": tid, "branch": 1, "phase": "C", "e29_direct": True, "c_priority": p.get("c_priority"),
               "c_key_tokens": p.get("c_key_tokens"), "budget": p.get("budget"), "worker_slot": wi,
               "tokens": int((rec or {}).get("generated_tokens") or 0), "start_sec": t_start, "end_sec": _sec(),
               "status": "done" if rec else "no_record", "queues_at_start": qlen, "start_seq": start_seq, "error": err,
               "kind": "DIRECT" if rec else "DIRECT_NO_RECORD",
               "end_reason": x.get("end_reason") or ("error" if err else "not_admitted"), "queued_sec": m.get("queued_sec"),
               "wait_sec": (round(t_start - m["first_tried_sec"], 1) if m.get("first_tried_sec") is not None else None),
               **{k: x.get(k) for k in ("mode", "think_tokens", "p2_tokens", "mapping_source", "has_grid", "score")}}
        if rec is not None:
            try:
                rec = dict(rec, branch=1, e29_direct=True, e28=dict(row))
                rec["submissions"] = [dict(s_, branch=1) for s_ in rec.get("submissions") or []]
                publish(rec)
            except Exception as exc:
                row["error"] = f"publish {type(exc).__name__}: {exc}"[:300]
        with cond:
            d = e28.setdefault("direct", {"started": 0, "records": 0, "no_record": 0, "errors": 0, "by_task": {}})
            d["started"] += 1
            d["records" if rec is not None else "no_record"] += 1
            d["errors"] += int(bool(row.get("error")))
            d["by_task"][tid] = {k: row.get(k) for k in ("kind", "mode", "end_reason", "tokens", "think_tokens", "p2_tokens",
                                                         "mapping_source", "has_grid", "score", "start_sec", "end_sec")}
            e28["rows"][f"{tid}_b1"] = row
            e28["done"]["C"] += 1
            state["running"] -= 1
            state["last_free_t"] = time.monotonic()
            active.discard((tid, 1))
            state["durations"].append(round(time.monotonic() - t0, 1))
            cond.notify_all()

    def worker(wi: int):
        while True:
            try:
                return _worker_body(wi)
'''),
    ("K6 report", '                           **({"supply": _e29_report(sup, e28, rows_, slots, order)} if sup is not None else {}),\n',
     '                           **({"supply": _e29_report(sup, e28, rows_, slots, order)} if sup is not None else {}),\n'
     '                           **({"direct": e28["direct"]} if e28.get("direct") else {}),   # E29 DIRECT\n'),
    ("K7 slot src", '''    if s in src:
        return src[s]
    if isinstance(s, str) and s[:1] == "S" and s[1:].isdigit():
''', '''    if s == "D":                       # E29 DIRECT: the DIRECT answer (branch 1)
        return 1
    if s in src:
        return src[s]
    if isinstance(s, str) and s[:1] == "S" and s[1:].isdigit():
'''),
]
DUCK_TAIL = '''

# ==================================================================== E29 DIRECT (Experiment 29 rev 2, user 2026-11-02)
''' + DUCK_MARKER + '''
# On: a phase-C item (C's priority order unchanged: train-fail tasks first, then the accepted ones by ascending attempt-1
# tokens) runs ONE DIRECT request in its worker slot (the notebook's E29D_RUN = e29_direct.py, the E31 solver) instead of a
# Duck attempt; A / B / supply / the deadline guard are unchanged. Answers: attempt_1 = today's rule on the Duck records (it
# never changes); attempt_2 = the DIRECT grid of that test when valid and != attempt_1, else today's attempt_2.
# Off (E29_DIRECT unset, or no hook): the code above runs exactly as the E29 post file (no DIRECT record exists).
def _e29d_on() -> bool:
    return _e28_on() and os.environ.get("E29_DIRECT", "").strip() == "1" and E29D_RUN is not None


def _e29d_is(rec) -> bool:
    return isinstance(rec, dict) and bool(rec.get("e29_direct"))


def select_attempts_e29d(task: dict, branch_records: list[dict], _slots_out: list | None = None) -> list[dict]:
    """E29 DIRECT answer slots (same output format): attempt_1 / the fallbacks = select_attempts_e28 on the Duck records
    (unchanged); attempt_2 = the latest DIRECT record's grid for that test input (grid K -> test K) when it is a valid grid
    and differs from attempt_1, else the Duck rule's attempt_2. Slot source "D" = the DIRECT answer."""
    rows: list = []
    out = select_attempts_e28(task, [r for r in branch_records if not _e29d_is(r)], rows)
    ds = [r for r in branch_records if _e29d_is(r)]
    d = max(ds, key=lambda r: int(r.get("publish_seq") or 0)) if ds else None
    outs = (((d.get("submissions") or [{}])[0] or {}).get("test_outputs") or []) if d else []
    for qi, o in enumerate(out):
        g = outs[qi] if qi < len(outs) else None
        use = valid_grid(g) and g != o["attempt_1"]
        if use:
            o["attempt_2"] = g
        if qi < len(rows) and isinstance(rows[qi], dict):
            rows[qi]["e29_direct"] = "attempt_2" if use else ("same_as_attempt_1" if valid_grid(g) else "no_grid")
            if use:
                rows[qi]["attempt_2"] = "D"
    if _slots_out is not None:
        _slots_out.extend(rows)
    return out
'''

MODULE_TMPL = r'''"""E29 DIRECT scheduler patch (Experiment 29 rev 2, user 2026-11-02; generated by Build/e29_direct_build.py, do not edit).

DIRECT = the SECOND BRANCH (attempt_2) of the E28 A / B / C scheduler: a strict unified diff on arc2_duck.py from the E29
post text (e29_sched_patch.py, sha __PRE__) to the E29 DIRECT post text (sha __POST__).
Runtime (E28_SCHED=1 + E29_DIRECT=1 + the notebook hook arc2_duck.E29D_RUN): a phase-C item runs ONE DIRECT request
(e29_direct.py) in its worker slot instead of a Duck attempt, recorded as branch 1; the answer rule select_attempts_e29d
(attempt_1 never changes; attempt_2 = the DIRECT grid when valid and != attempt_1, else today's attempt_2).

    import e29d_sched_patch as E29DS    # e28_sched_patch.py importable (the applier)
    rec = E29DS.apply_direct(E12_DIR)   # E29 post -> DIRECT post (dir / file / text); DIRECT post -> no-op; else raises
    ok, why = E29DS.verify_direct(E12_DIR)
    rec = E29DS.revert_direct(E12_DIR)  # DIRECT post -> the exact E29 post bytes; E29 post -> no-op
    E29DS.tree_state(E12_DIR)           # "E29_POST" | "DIRECT_PATCHED" | "OTHER"
"""
import hashlib
import json
from pathlib import Path

import e28_sched_patch as E28S

DUCK_REL = "arc2_duck.py"
PRE = "__PRE__"                 # the E29 post text (e29_sched_patch.E29_POST)
POST = "__POST__"
MARKER = __MARKER__
ENV_DIRECT = "E29_DIRECT"
PATCH = r__TQ__
apply_unified, reverse_unified = E28S.apply_unified, E28S.reverse_unified
SHA = {"pre": PRE, "post": POST, "patch": hashlib.sha256(PATCH.encode("utf-8")).hexdigest(), "applier": E28S.E28_SCHED_SHA["applier"]}


def _sha(b):
    return hashlib.sha256(b).hexdigest()


def _state_of(data):
    h = _sha(data)
    if h == POST and MARKER.encode() in data:
        return "DIRECT_PATCHED", h
    if h == PRE:
        return "E29_POST", h
    return "OTHER", h


def _file(target):
    p = Path(target)
    return p / DUCK_REL if p.is_dir() else p


def _is_text(target):
    return isinstance(target, str) and "\n" in target


def tree_state(target):
    if _is_text(target):
        return _state_of(target.encode("utf-8"))[0]
    f = _file(target)
    return _state_of(f.read_bytes())[0] if f.is_file() else "OTHER"


def verify_direct(target):
    if _is_text(target):
        st, h = _state_of(target.encode("utf-8"))
    else:
        f = _file(target)
        if not f.is_file():
            return False, f"OTHER missing {f}"
        st, h = _state_of(f.read_bytes())
    return st == "DIRECT_PATCHED", f"{st} sha256={h} (pre {PRE[:12]}, post {POST[:12]})"


def _move(data, forward):
    out = apply_unified(data.decode("utf-8"), PATCH if forward else reverse_unified(PATCH)).encode("utf-8")
    want = POST if forward else PRE
    if _sha(out) != want:
        raise RuntimeError(f"E29_DIRECT_{'POST' if forward else 'REVERT'}_SHA_MISMATCH {DUCK_REL}: {_sha(out)}")
    return out


def _do(target, forward):
    key = "applied" if forward else "reverted"
    done, start = ("DIRECT_PATCHED", "E29_POST") if forward else ("E29_POST", "DIRECT_PATCHED")
    if _is_text(target):
        data = target.encode("utf-8")
        st, h = _state_of(data)
        rec = {"mode": "text", "before": st, "sha_before": h, "sha": SHA}
        if st == done:
            rec.update({key: "already" if forward else "not_applied", "text": target})
        elif st == start:
            rec.update({key: key, "text": _move(data, forward).decode("utf-8")})
        else:
            raise RuntimeError(f"E29_DIRECT_STATE_MISMATCH {DUCK_REL}: {st} {h}")
        rec["after"] = _state_of(rec["text"].encode("utf-8"))[0]
        rec["ok"] = rec["after"] == done
        return rec
    f = _file(target)
    data = f.read_bytes() if f.is_file() else b""
    st, h = _state_of(data)
    rec = {"mode": "file", "file": str(f), "before": st, "sha_before": h, "sha": SHA}
    if st == done:
        rec[key] = "already" if forward else "not_applied"
    elif st == start:
        E28S._write_atomic(f, _move(data, forward))
        rec[key] = key
    else:
        raise RuntimeError(f"E29_DIRECT_STATE_MISMATCH {f}: {st} {h}")
    E28S._drop_pyc(f)
    rec["after"], rec["sha_after"] = _state_of(f.read_bytes())
    rec["py_compile"] = E28S._py_compile(f)
    if rec["after"] != done or rec["py_compile"]["rc"]:
        raise RuntimeError("E29_DIRECT_VERIFY_FAILED: " + json.dumps({k: rec.get(k) for k in ("after", "sha_after", "py_compile")}))
    rec["ok"] = True
    return rec


def apply_direct(target):
    """The E29 post arc2_duck.py -> the DIRECT post (atomic, pyc dropped, py_compile + post sha + marker verified)."""
    return _do(target, True)


def revert_direct(target):
    """The DIRECT post -> the exact E29 post bytes (the E29 / E28 reverts then work as before)."""
    return _do(target, False)
'''


def make_dsched(e29_post_text, e29_post_sha):
    """-> (post_text, patch_text, module_text). The diff is strict (n=3 context), checked forward and backward with the
    E28 applier by the caller."""
    assert sha(e29_post_text) == e29_post_sha
    t = e29_post_text
    for lab, old, new in DUCK_EDITS:
        t = once(t, old, new, lab)
    assert t.endswith("    return out\n")
    post = t + DUCK_TAIL
    compile(post, "arc2_duck.py", "exec")
    a, b = e29_post_text.splitlines(True), post.splitlines(True)
    body = "".join(difflib.unified_diff(a, b, "a/arc2_duck.py", "b/arc2_duck.py", n=3))
    patch = ("# E29 DIRECT onto arc2_duck.py (the E29 SCHED post text).\n# pre-patch sha256  " + e29_post_sha
             + "\n# post-patch sha256 " + sha(post) + "\n" + body)
    assert "'''" not in patch and "\r" not in patch and not patch.rstrip("\n").endswith("\\")
    mod = (MODULE_TMPL.replace("__PRE__", e29_post_sha).replace("__POST__", sha(post))
           .replace("__MARKER__", repr(DUCK_MARKER)).replace("__TQ__", "'''" + patch + "'''"))
    compile(mod, "e29d_sched_patch.py", "exec")
    return post, patch, mod
