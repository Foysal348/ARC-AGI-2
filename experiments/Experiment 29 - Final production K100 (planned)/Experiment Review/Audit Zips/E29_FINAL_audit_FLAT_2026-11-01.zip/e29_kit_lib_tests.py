"""E29 kit unit tests (quick; the Kaggle CPU units kit runs them on Py3.12): e29_lib's pure helpers and the notebook's OWN
nb5_boot / e29_env / e29_extra / e29_ntries / e29_drop defs (exec of the built notebook's engine cell) with E29 levers on,
a scripted nb5_boot_try (no server, no GPU). The real-mount versions of the same paths run in the real kit.

usage: python e29_kit_lib_tests.py   env E29LT_NB (notebook) / E29LT_FACTS (<variant>_build_facts.json) / E29LT_KF (kit facts:
       variants_cfg, nbdf_k100 d_retry / q_pin / q_captures) / E29LT_NB5LIB (nb5_lib.py). e29_lib.py, e28k100_lib.py next to it.
Prints one PASS / FAIL line per check, then "<n>/<m> PASS"; exit 1 on any FAIL.
"""
import ast
import json
import os
import sys
import time
import traceback
import importlib.util
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import e29_lib as L          # noqa: E402
import e28k100_lib as E28L   # noqa: E402

RESULTS = []


def check(label, fn):
    try:
        ok, why = bool(fn()), ""
    except Exception as e:
        ok, why = False, f"{type(e).__name__}: {e} | {traceback.format_exc()[-700:]}"
    RESULTS.append((label, ok))
    print(("PASS " if ok else "FAIL ") + label + ("" if ok else "  <- " + why[:1200]), flush=True)
    return ok


NB = Path(os.environ["E29LT_NB"])
FACTS = json.loads(Path(os.environ["E29LT_FACTS"]).read_text(encoding="utf-8"))
KF = json.loads(Path(os.environ["E29LT_KF"]).read_text(encoding="utf-8"))
_s = importlib.util.spec_from_file_location("nb5_lib_e29lt", os.environ["E29LT_NB5LIB"])
NB5L = importlib.util.module_from_spec(_s)
_s.loader.exec_module(NB5L)
CODE = ["".join(c["source"]) for c in json.loads(NB.read_text(encoding="utf-8"))["cells"] if c["cell_type"] == "code"]
C1, ENG = CODE[1], CODE[4]
VAR = FACTS["e29"]["variant"]


def raises(fn):
    try:
        fn()
        return False
    except (AssertionError, ValueError, TypeError, KeyError):
        return True


def modules():
    line = next(l for l in C1.splitlines() if l.startswith("E28_SRC = json.loads("))
    expr = ast.get_source_segment(line, ast.parse(line).body[0].value.args[0])
    return json.loads(eval(compile(ast.Expression(ast.parse(expr, mode="eval").body), "<packed>", "eval")))


MODS = modules()
NBDF = {}
exec(compile(MODS["e29_nbdf.py"], "e29_nbdf.py", "exec"), NBDF)


# ------------------------------------------------------------------ L: e29_lib
def _l1():
    pre = 'E29_CFG = E29L.check_cfg(json.loads(r"""'
    line = next(l for l in C1.splitlines() if l.startswith(pre))
    cfg = json.loads(line[len(pre):line.rindex('"""')])
    var = next(l for l in C1.splitlines() if l.startswith("E29_VARIANT = "))
    return (cfg == FACTS["e29"]["cfg"] == L.check_cfg(cfg) and var == f'E29_VARIANT = "{VAR}"'
            and MODS["e29_lib.py"] == (HERE / "e29_lib.py").read_text(encoding="utf-8"))


check("L1 the notebook's E29_CFG literal == the facts' cfg == check_cfg(it); E29_VARIANT == the facts' variant; the packed "
      "e29_lib.py == this e29_lib.py", _l1)
check("L2 check_cfg: every builder variant (E29_DEFAULT / E29_DFLASH_D3S / E29_MTP_V64 / ALL_OFF) passes; ALL_OFF == default_cfg; "
      "bad values raise (unknown key, drafter, vocab with dflash, embed_host with mtp, workers 20, a non-bool flag)",
      lambda: all(L.check_cfg(c) == dict(L.default_cfg(), **c) for c in KF["variants_cfg"].values())
      and L.is_default(KF["variants_cfg"]["ALL_OFF"]) and not L.is_default(KF["variants_cfg"]["E29_DEFAULT"])
      and raises(lambda: L.check_cfg({"x": 1})) and raises(lambda: L.check_cfg({"drafter": "eagle"}))
      and raises(lambda: L.check_cfg({"drafter": "dflash_d3s", "draft_vocab": "64k"}))
      and raises(lambda: L.check_cfg({"embed_host": True})) and raises(lambda: L.check_cfg({"workers": 20}))
      and raises(lambda: L.check_cfg({"indexer_fp8": 1})))


def _l3():
    t0, t1 = L.df_tries(False), L.df_tries(True)
    want = [[KF["nbdf_q_pin"], False]] + [[p, bool(e.get("DFLASH_DRAFT_EMBED_HOST") == "1")] for p, e in KF["nbdf_d_retry"]]
    got0 = [[t["kv_bytes"], t["df"]["embed_host"]] for t in t0]
    assert got0 == want, (got0, want)
    assert [t["df"]["rung"] for t in t0] == [0, 1, 2, 3, 4] and all(abs(t["gib"] - L.gib_of(t["kv_bytes"])) < 1e-12 for t in t0)
    assert L.D_RETRY == [[p, True] for p, _ in KF["nbdf_d_retry"]] and L.D_PIN0 == KF["nbdf_q_pin"] == FACTS["pins"][0]
    return [[t["kv_bytes"], t["df"]["embed_host"]] for t in t1] == [[KF["nbdf_q_pin"], True]] + want[2:]


check("L3 df_tries == the NBDF-K100 D ladder: try 0 = the K3 top pin 7,933,526,016 B (no EMBED_HOST), then NBDF's d_retry rungs "
      "(EMBED_HOST=1); embed_host first skips the duplicate pin-0 rung; gib = (pin - FP8 pin) / 2^30", _l3)
check("L4 lever_to_drop: fixed order df > idx > vocab > gdn; a lever the log names goes first (indexer_kv_dtype / draft_vocab / "
      "gdn switches); df never by name; None with no E29 lever on",
      lambda: L.lever_to_drop(["vocab", "idx", "df"], "OOM") == "df" and L.lever_to_drop(["idx", "vocab"], "") == "idx"
      and L.lever_to_drop(["df", "idx"], "FAIL_CLI_FLAGS: missing flags: --attention-config.indexer_kv_dtype") == "idx"
      and L.lever_to_drop(["idx", "vocab"], "bad draft_vocab file") == "vocab"
      and L.lever_to_drop(["gdn_align", "gdn_fastpath"], "VLLM_GDN_SHARED_ALIGN_INDEX ...") == "gdn_align"
      and L.lever_to_drop([], "x") is None and L.lever_to_drop(None) is None)
_TAIL = L.df_spec_argv('{"method":"dflash"}', '{"cudagraph_capture_sizes":[4,8]}')
check("L5 df_spec_argv = the 4 trailing args; strip_df_argv round trip (base + idx + tail -> base + idx; no tail -> unchanged; "
      "an earlier identical block stays: only the LAST exact occurrence is removed)",
      lambda: _TAIL == ["--speculative-config", '{"method":"dflash"}', "--compilation-config", '{"cudagraph_capture_sizes":[4,8]}']
      and L.strip_df_argv(["--a", "1"] + L.IDX_ARGS + _TAIL, _TAIL) == ["--a", "1"] + L.IDX_ARGS
      and L.strip_df_argv(["--a", "1"], _TAIL) == ["--a", "1"] and L.strip_df_argv(_TAIL + ["--b"] + _TAIL, _TAIL) == _TAIL + ["--b"]
      and L.strip_df_argv(None, _TAIL) == [] and L.strip_df_argv(["--x"], []) == ["--x"])


def _c(d, t, a):
    return {"drafts": d, "draft_tokens": t, "accepted": a}


check("L6 canary (nbdf smoke rule): 0 / 300 draft tokens accepted -> hit DFLASH_ZERO_ACCEPT; 4 / 300 (1.3 %) -> hit; 150 tokens -> "
      "TOO_FEW_DRAFTS (no hit); 30 % -> OK with AL 1 + accepted / drafts; None counters -> no hit",
      lambda: L.canary(_c(0, 0, 0), _c(100, 300, 0), 3)["label"] == "DFLASH_ZERO_ACCEPT"
      and L.canary(_c(0, 0, 0), _c(100, 300, 4), 3)["hit"] is True
      and L.canary(_c(0, 0, 0), _c(50, 150, 0), 3)["label"] == "TOO_FEW_DRAFTS" and L.canary(_c(0, 0, 0), _c(50, 150, 0), 3)["hit"] is False
      and (lambda r: r["label"] == "OK" and r["al"] == 1.9 and r["accept_rate"] == 0.3)(L.canary(_c(10, 30, 0), _c(110, 330, 90), 3))
      and L.canary(None, None, 3)["hit"] is False)


def _rows(vals):
    return [{"t": 1000.0 + 15 * i, "sd_drafts": d, "sd_draft_tok": t, "sd_acc": a} for i, (d, t, a) in enumerate(vals)]


check("L7 inrun_zero on sampler rows (hit at 0 % over >= 200 draft tokens, TOO_FEW_ROWS with < 2 rows); hourly_al per hour + the "
      "0.7 x first-hour flag; next_try_index (OOM -> next D rung, else the first non-D try); is_oom",
      lambda: L.inrun_zero(_rows([(0, 0, 0), (100, 300, 0)]), 3)["hit"] is True
      and L.inrun_zero(_rows([(0, 0, 0)]), 3)["label"] == "TOO_FEW_ROWS"
      and L.inrun_zero(_rows([(0, 0, 0), (100, 300, 200)]), 3)["hit"] is False
      and (lambda h: h["first_al"] == 3.0 and h["flag"] == "AL_DROP_BELOW_0.7_FIRST_HOUR" and h["low_hours"] == [1])(
          L.hourly_al([{"t": 0, "sd_drafts": 0, "sd_draft_tok": 0, "sd_acc": 0}, {"t": 3500, "sd_drafts": 100, "sd_draft_tok": 300, "sd_acc": 200},
                       {"t": 7000, "sd_drafts": 200, "sd_draft_tok": 600, "sd_acc": 300}]))
      and L.next_try_index([{"df": 1}, {"df": 1}, {}], 0, True, False) == 1 and L.next_try_index([{"df": 1}, {"df": 1}, {}], 0, False, False) == 2
      and L.next_try_index([{"df": 1}, {}], 0, True, False) == 1 and L.next_try_index([{"df": 1}], 0, True, False) == 1
      and L.is_oom("torch.OutOfMemoryError: CUDA out of memory") and not L.is_oom("ValueError"))
_CR = {"ok": False, "checks": {"kv_dtype": True, "max_num_seqs": True, "speculative_config": False, "engine_spec": False},
       "log": {"speculative_config": {"method": "dflash", "num_speculative_tokens": 3}, "engine_spec": {"method": "dflash", "num_spec_tokens": 3}}}
check("L8 df_config_check: C-11's MTP checks dropped, the DFlash arch line + method dflash K3 (log spec + engine spec) required; "
      "a wrong K or a missing arch line -> INCONCLUSIVE_CONFIG_MISMATCH",
      lambda: (lambda r: r["ok"] and r["verdict"] == "PASS" and r["mtp_checks_dropped"] == ["speculative_config", "engine_spec"])(
          L.df_config_check(_CR, "Resolved architecture: DFlash2DraftModel", 3))
      and L.df_config_check(_CR, "Resolved architecture: DFlash2DraftModel", 4)["ok"] is False
      and L.df_config_check(_CR, "", 3)["verdict"] == "INCONCLUSIVE_CONFIG_MISMATCH")


def _l9():
    sp = NBDF["dflash_spec"]("/d", 3, "auto", "FLASH_ATTN")
    caps = NBDF["capture_sizes"](24, 3)
    js, cj = json.loads(NBDF["spec_json"](sp)), json.loads(NBDF["compilation_json"](caps))
    assert caps[0] == 4 and caps[-1] == 96 and all(c % 4 == 0 for c in caps), caps
    assert js["method"] == "dflash" and js["num_speculative_tokens"] == 3 and js["model"] == "/d", js
    assert js.get("kv_cache_dtype") == "auto" and js.get("attention_backend") == "FLASH_ATTN" and js.get("draft_sample_method") == "probabilistic", js
    assert cj.get("cudagraph_capture_sizes") == caps, cj
    assert NBDF["SW_BLOCK"] == 1024 and NBDF["DRAFTER_MODEL"] == FACTS["e29"]["drafter_model"] and L.K_OF["dflash_d3s"] == 3
    return KF["nbdf_q_captures"][-1] == caps[-1] == 96


check("L9 the DFlash spec the notebook builds (its e29_nbdf literal = nbdf_lib verbatim): method dflash, K3, the drafter dir, BF16 "
      "drafter KV auto, FLASH_ATTN, probabilistic; captures(24, K3) = the multiples of 4 up to 96 (= NBDF-K100 q_captures max); the "
      "compilation JSON carries them; SW_BLOCK 1024; the drafter Model pin", _l9)


# ------------------------------------------------------------------ B: the notebook's own nb5_boot with E29 levers on
def _defs(names):
    t = ast.parse(ENG)
    fns = [n for n in t.body if isinstance(n, ast.FunctionDef) and n.name in names]
    assert sorted(f.name for f in fns) == sorted(names), [f.name for f in fns]
    return ast.Module(fns, [])


class DSStub:
    ALL_ENVS = ("DFLASH_SEAM", "DFLASH_MASK_ROW_SHA", "DFLASH_DRAFT_SW_BLOCK", "DFLASH_DRAFT_EMBED_HOST")

    @staticmethod
    def server_env(mask_row_sha=None, embed_host=False, draft_sw_block=None, **_):
        e = {"DFLASH_SEAM": "1", "DFLASH_MASK_ROW_SHA": mask_row_sha, "DFLASH_DRAFT_SW_BLOCK": str(draft_sw_block)}
        if embed_host:
            e["DFLASH_DRAFT_EMBED_HOST"] = "1"
        return e


TAIL = L.df_spec_argv(NBDF["spec_json"](NBDF["dflash_spec"]("/drafter", 3, "auto", "FLASH_ATTN")),
                      NBDF["compilation_json"](NBDF["capture_sizes"](24, 3)))
STEPS = [float(x) for x in FACTS["pin_steps_gib"]]
SEQS_T = {round(float(k), 2): int(v) for k, v in FACTS["seqs_table"].items()}


def ladder(on, cfg, script, rerun=False, i8_on=True, vocab=None):
    g = {"json": json, "time": time, "NB5L": NB5L, "NB5_KV_DTYPE": "fp8", "NB5_KV_BYTES": {"fp8": L.FP8_PIN}, "NB5_BOOTS": [],
         "NB5_EXTRA_ARGS": [], "NB5_MTP_OFF_ARGS": ["--speculative-config", "None"], "FAKE": None,
         "P": dict({"pin_ladder": True, "patch_60490": True, "k100": True, "i8": True, "top_rung_seqs": 24}, **({"e18_ladder": True} if rerun else {})),
         "NB5_PIN": {"start_gib": None, "levers": None, "patch_60490": {"ok": True}}, "K100_PIN_STEPS_GIB": STEPS,
         "NB5_LEVER_ENV": {"MERLIN_SHARE_DRAFT_WORKSPACE": "1"}, "NB5_SEQS_RULE": "k100", "K100_SEQS_TABLE": SEQS_T,
         "left": lambda: 1e9, "E28_I8": {"want": True, "on": i8_on, "static": None, "dropped": None, "readback": None},
         "E28_I8_ENV": {"DRAFT_HEAD": "int8"}, "E28L": E28L, "log": lambda *a: None, "nb5_write_report": lambda: None, "ABORT": {},
         "NB5_READY_TIMEOUT": 1800, "NB5_BOOT_LEVERS": {}, "NB5_BOOT_EXTRA": [], "NB5_BOOT_KV": None,
         "E29L": L, "E29_CFG": L.check_cfg(cfg), "DS": DSStub, "SSEQ": None, "NOTEBOOK_T0": time.perf_counter(),
         "E29_RT": {"cfg": cfg, "on": list(on), "dropped": [], "tries": [], "canary": [], "errors": [], "df_try": False, "df_live": False,
                    "df": {"k": 3, "tail": TAIL, "mask_row_sha": "ab" * 32, "sw_block": 1024} if "df" in on else None,
                    "vocab": vocab}}
    if not i8_on:
        g["E28_I8"]["suspended"] = "N/A_DFLASH"
    seen, it = [], iter(script)

    def nb5_boot_try(trec, name, kv_bytes, phases, mtp_on):
        st = next(it)
        av = list(g["NB5_BOOT_EXTRA"])
        seen.append({"name": name, "kv_bytes": kv_bytes, "levers": dict(g["NB5_BOOT_LEVERS"]), "extra": av, "df_try": g["E29_RT"]["df_try"],
                     "seqs": av[av.index("--max-num-seqs") + 1] if "--max-num-seqs" in av else None, "e29_on": list(trec.get("e29_on") or []),
                     "e28_i8": trec.get("e28_i8")})
        if st == "OOM":
            trec.update(status="SERVER_DIED", log_text_for_ladder="torch.OutOfMemoryError: CUDA out of memory")
        elif st == "NOT_ENGAGED":
            trec.update(status="E29_DFLASH_NOT_ENGAGED", log_text_for_ladder="")
        elif st == "CLI":
            trec.update(status="E29_LAUNCH_PREP_FAILED", log_text_for_ladder="RuntimeError: FAIL_CLI_FLAGS: missing flags: --attention-config.indexer_kv_dtype")
        else:
            trec.update(status="DONE", phases_started=True)
        return trec
    g["nb5_boot_try"] = nb5_boot_try
    exec(compile(_defs(["nb5_boot", "e29_env", "e29_extra", "e29_ntries", "e29_drop"]), "<nb5_boot e29>", "exec"), g)
    b = g["nb5_boot"]("merlin_fp8_mtp", [["Q", "all", None, "on", "A", "fp8"]], True, "fp8")
    return b, seen, g


DCFG = dict(L.default_cfg(), drafter="dflash_d3s", indexer_fp8=True, attempts_supply=True)
VCFG = dict(L.default_cfg(), draft_vocab="64k", indexer_fp8=True, attempts_supply=True)
TOP = FACTS["pins"][0]
DPINS = [KF["nbdf_q_pin"]] + [p for p, _ in KF["nbdf_d_retry"]]


def _b1():
    for rr in (False, True):
        b, seen, g = ladder(["df", "idx"], DCFG, ["OOM"] * 5 + ["OOM", "DONE"], rerun=rr, i8_on=False)
        assert [s["kv_bytes"] for s in seen] == DPINS + [TOP, TOP], [s["kv_bytes"] for s in seen]
        d, m = seen[:5], seen[5:]
        assert all(s["df_try"] and s["extra"][-4:] == TAIL and s["seqs"] == "24" and s["levers"]["DFLASH_SEAM"] == "1"
                   and s["levers"]["DFLASH_DRAFT_SW_BLOCK"] == "1024" and "DRAFT_HEAD" not in s["levers"] for s in d), d
        assert [s["levers"].get("DFLASH_DRAFT_EMBED_HOST") for s in d] == [None, "1", "1", "1", "1"], d
        assert all(" ".join(L.IDX_ARGS) in " ".join(s["extra"]) for s in d + m[:1]) and " ".join(L.IDX_ARGS) not in " ".join(m[1]["extra"])
        assert [s["name"].split("_pin")[1] for s in d][0].endswith("_df3r0_idx"), [s["name"] for s in seen]
        assert all(not s["df_try"] and s["levers"].get("DRAFT_HEAD") == "int8" and not any(k.startswith("DFLASH_") for k in s["levers"])
                   and s["seqs"] == "24" and "dflash" not in " ".join(s["extra"]) for s in m), m
        assert [x["lever"] for x in g["E29_RT"]["dropped"]] == ["df", "idx"] and b["status"] == "DONE" and g["E28_I8"]["on"] is True, (
            g["E29_RT"]["dropped"], b["status"], g["E28_I8"])
        assert m[1]["name"].endswith("_i8") and m[0]["name"].endswith("_i8_idx"), [s["name"] for s in m]
    return True


check("B1 DFLASH (df + idx on): the notebook's nb5_boot runs the 5 NBDF-K100 D tries first (pins = q_pin + d_retry; --max-num-seqs "
      "24; the trailing dflash spec + captures LAST; seam env DFLASH_SEAM=1 / SW_BLOCK 1024 / EMBED_HOST from rung 1; no DRAFT_HEAD), "
      "an OOM on every D rung -> df dropped -> the MTP K3 top rung with I8 restored + idx, an OOM there -> idx dropped -> the same pin "
      "plain E28 (DONE); the commit and the rerun (E18 3-try cap counts non-E29 tries only)", _b1)


def _b2():
    b, seen, g = ladder(["df", "idx"], DCFG, ["NOT_ENGAGED", "DONE"], i8_on=False)
    assert [s["kv_bytes"] for s in seen] == [DPINS[0], TOP] and seen[0]["df_try"] and not seen[1]["df_try"], seen
    assert seen[1]["levers"].get("DRAFT_HEAD") == "int8" and seen[1]["e29_on"] == ["idx"] and b["status"] == "DONE"
    b2, seen2, g2 = ladder(["df", "idx"], DCFG, ["CLI", "NOT_ENGAGED", "DONE"], i8_on=False)
    assert [s["kv_bytes"] for s in seen2] == [DPINS[0], DPINS[0], TOP], seen2
    assert seen2[0]["e29_on"] == ["df", "idx"] and seen2[1]["e29_on"] == ["df"] and seen2[2]["e29_on"] == []
    return [x["lever"] for x in g2["E29_RT"]["dropped"]] == ["idx", "df"] and b2["status"] == "DONE"


check("B2 DFLASH: a non-OOM D failure (NOT_ENGAGED) ends DFlash at once -> the MTP top rung (I8 + idx); a FAIL_CLI_FLAGS naming the "
      "indexer flag drops idx first, the same D pin retried without it", _b2)


def _b3():
    voc = {"want": "64k", "file": "/m/draft_vocab_k100_arc_n65536.pt", "sha256": L.VOCAB_FILES["64k"][1]}
    b, seen, g = ladder(["idx", "vocab"], VCFG, ["OOM", "OOM", "DONE"], vocab=voc)
    assert [s["kv_bytes"] for s in seen] == [TOP] * 3 and all(s["seqs"] == "24" and s["levers"].get("DRAFT_HEAD") == "int8" for s in seen), seen
    assert [s["levers"].get("VLLM_DRAFT_VOCAB_FILE") for s in seen] == [voc["file"], voc["file"], None]
    assert [s["levers"].get("VLLM_DRAFT_VOCAB_SHA256") for s in seen] == [voc["sha256"], voc["sha256"], None]
    assert [" ".join(L.IDX_ARGS) in " ".join(s["extra"]) for s in seen] == [True, False, False]
    return [x["lever"] for x in g["E29_RT"]["dropped"]] == ["idx", "vocab"] and b["status"] == "DONE" and g["E28_I8"]["on"] is True


check("B3 MTP_V64 (idx + vocab on): the E28 top rung (pin 7,933,526,016 B, 24 seqs, I8) with VLLM_DRAFT_VOCAB_FILE / _SHA256 and "
      "the indexer flag; an OOM -> idx dropped (order), an OOM -> vocab dropped -> the same pin plain E28 (DONE)", _b3)


def _b4():
    b, seen, g = ladder([], dict(L.default_cfg(), attempts_supply=True), ["DONE"])
    return (len(seen) == 1 and seen[0]["kv_bytes"] == TOP and seen[0]["levers"] == {"MERLIN_SHARE_DRAFT_WORKSPACE": "1", "DRAFT_HEAD": "int8"}
            and seen[0]["extra"] == ["--max-num-seqs", "24"] and seen[0]["name"].endswith("_i8") and not g["E29_RT"]["dropped"])


check("B4 DEFAULT (no E29 lever): nb5_boot == E28 K100 (one try: top pin, 24 seqs, I8 + the lever env, no E29 argv / env)", _b4)
check("B5 the E29 edits in place: launch-prep raise wrapper in nb5_boot_try (E29_LAUNCH_PREP_FAILED), the D tries prepended only "
      "with df on and MTP, e29_setup() in CELL 8 after the I8 static check, the report key e29",
      lambda: 'trec.update(status="E29_LAUNCH_PREP_FAILED"' in ENG and "tries = E29L.df_tries(bool(E29_CFG[\"embed_host\"])) + list(tries)" in ENG
      and CODE[6].index("e28_i8_static()") < CODE[6].index("    e29_setup()") and 'E28_OUT["e29"] = dict(E29L.summary(E29_RT)' in CODE[7])

n_bad = sum(1 for _, ok in RESULTS if not ok)
print(f"\n{len(RESULTS) - n_bad}/{len(RESULTS)} PASS", flush=True)
sys.exit(1 if n_bad else 0)
