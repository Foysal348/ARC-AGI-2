"""E29 FINAL production (2026-11-01): the switchable build of the E28 K100 EVAL120 notebook (the production config running on
GPU now). Every FINAL_CFG flag OFF = E28 K100 exactly (the same levers / scheduler / boot; the E29 code paths are inert:
no E29 lever is on, the E28 scheduler is applied, the E28 ladder runs). The decision after tonight's GPU results = flags.

  python build_e29_final.py [VARIANT ...]      (default: the three notebooks below; ALL_OFF = every flag off, a check build)
    E29_DEFAULT     = E28 K100 + attempts_supply (the E29 scheduler S-1, e29_sched_patch.py)
    E29_DFLASH_D3S  = E29_DEFAULT + drafter dflash_d3s + indexer_fp8
    E29_MTP_V64     = E29_DEFAULT + draft_vocab 64k + indexer_fp8
  -> ../Experiment Notebooks/Q27-XHIGH-<VARIANT>.ipynb, Build/<variant>_code_export.py, Build/e29_build_facts.json and the GPU
     push folders D:/ARC AGI 2/_scratch/push_e25/<slug>__foysalemonshanto/ (nothing is pushed), the payload dataset folder
     D:/ARC AGI 2/_scratch/push_e25/ds_q27-e29-final-payload/ (dflash_seam.py + the two draft vocab tables)

Built on the E28 builder (Experiment 28 Build/build_e28_k100.py, imported, its build() never called; it asserts the K100Q
base 4506a71f byte for byte). The E29 edits (marked "# E29") are exact-once text replacements on E28's cells:
  E1  (CELL 1)  the modules literal + e29_sched_patch.py (scheduler S-1), e29_lib.py (flag helpers), e29_nbdf.py (verbatim
                nbdf_lib pieces: drafter pins / check, dflash spec, captures, SeamSeq); E29_CFG; the config record
  E2  (CELL 1)  workers (top_rung_seqs) and, for 28 / 32, Merlin's capture_sizes_for(workers, 3) (24 = K100_CAPS unchanged)
  E3  (CELL 3)  the scheduler apply: E29 (supply) first when asked, any failure -> revert -> the E28 scheduler (E28's rule)
  E4  (engine)  the E29 lever code: setup (vocab / drafter / seam from the dataset), per-try env + argv, the drop rule, the
                DFlash C-11 + seam read-back (ENGAGED) + the zero-accept canary, the in-run canary (-> MTP relaunch)
  E5  (engine)  nb5_boot: the D tries first (NBDF-K100 pin ladder), the E29 drop rule BEFORE the E28 I8 rule, the E18
                3-try cap counts non-E29 tries only; nb5_boot_try: a launch-prep raise with an E29 lever on = a failed try
  E6  (engine)  the sampler records the spec-decode counters (non-default builds)
  E7  (runner)  e29_setup() after k100_setup / the I8 static check
  E8  (report)  e28_k100_report.json["e29"] (flags, drops, canaries, hourly AL)
  E9  (markdown) the E29 header
"""
import ast
import hashlib
import json
import os
import sys
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
E28B_DIR = Path(r"D:/ARC AGI 2/experiments/Experiment 28 - Flash-Next EVAL120 6h W4 vs klee100 (planned)/Experiment Notebooks/Build")
E27B_DIR = Path(r"D:/ARC AGI 2/experiments/Experiment 27 - Flash-Next DFlash2 (planned)/Experiment Notebooks/Build")
VOCAB_DIR = Path(r"D:/ARC AGI 2/experiments/Experiment 25 - Flash-Next Throughput 1500 (planned)/Experiment Results/prep_0gpu/draft_vocab")
PUSH_ROOT = Path(r"D:/ARC AGI 2/_scratch/push_e25")
OWNER = "foysalemonshanto"
DS_SLUG = "q27-e29-final-payload"
DS_ID = f"{OWNER}/{DS_SLUG}"
DS_DIR = PUSH_ROOT / f"ds_{DS_SLUG}"
DRAFTER_MODEL = "foysalemonshanto/qwen38-flash-next-dflash2v2/transformers/bf16-embed/1"
PUSHED: set = set()          # sha256 of every E29 notebook that ran on Kaggle (never overwrite one: rebuild -> *_REBUILD)

_argv = sys.argv
sys.argv = [_argv[0]]                       # the E28 builder reads sys.argv (--interim): import it without our args
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(E28B_DIR))
import build_e28_k100 as E28B   # noqa: E402
sys.argv = _argv
import e29_lib as E29L          # noqa: E402
import e29_sched_patch as E29S  # noqa: E402

KQ, B, N6 = E28B.KQ, E28B.B, E28B.N6
sha = E28B.sha
assert E28B.E28S is not None, "the E28 builder must embed e28_sched_patch.py"
E28_NB_SHA = sha(E28B.OUT_NB.read_bytes())

FINAL_CFG = E29L.default_cfg()      # every flag OFF = E28 K100 exactly
VARIANTS = {
    "E29_DEFAULT": dict(FINAL_CFG, attempts_supply=True),
    "E29_DFLASH_D3S": dict(FINAL_CFG, attempts_supply=True, drafter="dflash_d3s", indexer_fp8=True),
    "E29_MTP_V64": dict(FINAL_CFG, attempts_supply=True, draft_vocab="64k", indexer_fp8=True),
    "ALL_OFF": dict(FINAL_CFG),
}
for _v in VARIANTS.values():
    E29L.check_cfg(_v)


# ------------------------------------------------------------------ the E29 modules
def _cut(src, names, label):
    """Top-level defs / assignments / classes of `src` by name, verbatim (ast.get_source_segment), in source order."""
    t = ast.parse(src)
    seg, got = [], []
    for n in t.body:
        nm = getattr(n, "name", None) or (n.targets[0].id if isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name) else None)
        if nm in names:
            seg.append(ast.get_source_segment(src, n))
            got.append(nm)
    miss = [x for x in names if x not in got]
    assert not miss, (label, miss)
    return "\n\n\n".join(seg) + "\n", got


NBDF_LIB_SRC = (E27B_DIR / "nbdf_lib.py").read_text(encoding="utf-8").replace("\r\n", "\n")
NBDF_NAMES = ("DRAFTER_MODEL", "DRAFTER_BASE", "DRAFTER_REL", "DRAFTER_VARIATION", "DRAFTER_PINS", "TARGET_LAYER_IDS",
              "MASK_TOKEN_ID", "DRAFT_HIDDEN", "DRAFT_LAYERS", "DRAFT_BLOCK", "DRAFT_KV_HEADS", "DRAFT_HEAD_DIM", "VOCAB",
              "DRAFT_ARCH", "MAX_NUM_BATCHED", "DRAFT_SAMPLE", "SW_BLOCK", "SMOKE_MIN_ACCEPT", "SMOKE_MIN_DRAFTS",
              "capture_sizes", "dflash_spec", "spec_json", "compilation_json", "tree_state", "SeamSeq", "safetensors_keys",
              "drafter_check", "bf16_row_norm", "drafter_pins_check")
_nbdf_cut, _ = _cut(NBDF_LIB_SRC, NBDF_NAMES, "nbdf_lib")
E29_NBDF = ('"""E29: verbatim pieces of E27 nbdf_lib.py (sha ' + sha(NBDF_LIB_SRC)[:12] + '; NBDF-K100\'s DFlash2 boot facts):\n'
            "the drafter Model pins, the drafter check, the dflash spec / captures / compilation JSON, the seam apply sequence."
            '"""\nimport json\nimport math\n\n\n' + _nbdf_cut)
compile(E29_NBDF, "e29_nbdf.py", "exec")
assert E29L.SEAM_FILE[1] == "7356d4738962bdbab4091264861c4bfbbdcd7098d6c75b9c48db69eeb73e6937"
assert json.loads((E27B_DIR / "nbdf_k100_build_facts.json").read_text(encoding="utf-8"))["seam_sha256"] == E29L.SEAM_FILE[1]
SEAM_BYTES = (E27B_DIR / "dflash_seam.py").read_bytes()
assert sha(SEAM_BYTES) == E29L.SEAM_FILE[1] and b"\r" not in SEAM_BYTES
_nbdf_ns = {}
exec(compile(E29_NBDF, "e29_nbdf.py", "exec"), _nbdf_ns)
assert _nbdf_ns["DRAFTER_MODEL"] == DRAFTER_MODEL and _nbdf_ns["SW_BLOCK"] == 1024
assert _nbdf_ns["capture_sizes"](24, 3)[-1] == 96 and _nbdf_ns["capture_sizes"](24, 4)[-1] == 120
for _k, (_f, _s) in E29L.VOCAB_FILES.items():
    assert sha((VOCAB_DIR / _f).read_bytes()) == _s, _f

# the NBDF-K100 drafter gate (notebook functions, verbatim from its CELL 7 body; they read MD / N / hashlib / time)
NBDF_BODY_SRC = (E27B_DIR / "nbdf_k100_cell7_body.py").read_text(encoding="utf-8").replace("\r\n", "\n")
DRAFTER_FNS, _ = _cut(NBDF_BODY_SRC, ("drafter_resolve", "_sha_file", "drafter_facts"), "nbdf_k100_cell7_body")

LIB_TEXT = (HERE / "e29_lib.py").read_bytes().decode("utf-8")
SCHED_TEXT = (HERE / "e29_sched_patch.py").read_bytes().decode("utf-8")
for _n, _t in (("e29_lib.py", LIB_TEXT), ("e29_sched_patch.py", SCHED_TEXT), ("e29_nbdf.py", E29_NBDF), ("drafter_fns", DRAFTER_FNS)):
    assert "\r" not in _t, _n
assert E29S.NOTEBOOK_EDITS is E29S.E28S.NOTEBOOK_EDITS and E29S.E28S.E28_SCHED_SHA == E28B.E28S.E28_SCHED_SHA
_duck = E28B.DUCK_SRC.read_bytes().decode("utf-8")
_p = E29S.apply_e29_sched(_duck)
assert _p["ok"] and sha(_p["text"].encode()) == E29S.E29_SCHED_SHA["post"]
assert E29S.revert_e29_sched(_p["text"])["text"] == _duck
assert E29S.server_env(supply=False) == E28B.E28S.server_env() and E29S.server_env(supply=True)["E29_SUPPLY"] == "1"

MODULES = dict(E28B.MODULES, **{"e29_lib.py": LIB_TEXT, "e29_sched_patch.py": SCHED_TEXT, "e29_nbdf.py": E29_NBDF})
MODULES_JSON = json.dumps(MODULES, sort_keys=True, separators=(",", ":"))
REGISTRY_CAPS = {str(w): KQ.capture_sizes_for(w, 3) for w in (24, 28, 32)}


def once(text, old, new, label):
    assert text.count(old) == 1, f"E29 {label}: x{text.count(old)}"
    return text.replace(old, new)


# ------------------------------------------------------------------ E1 / E2: CELL 1
E29_MODS = r'''# ---- E29 FINAL: the switchable flags (Build/build_e29_final.py FINAL_CFG; every flag OFF = E28 K100 exactly) + the E29
# modules from the same sha-pinned literal: e29_lib.py, e29_sched_patch.py (scheduler S-1 over e28_sched_patch), e29_nbdf.py
import e29_lib as E29L
import e29_nbdf as N
E29S, E29S_ERROR = None, None
try:
    import e29_sched_patch as E29S
except Exception as _e:
    E29S_ERROR = f"{type(_e).__name__}: {_e}"[:400]
    print("!!!!!!!!!! E29 SCHED MODULE NOT LOADED:", E29S_ERROR, flush=True)
E29_CFG = E29L.check_cfg(json.loads(r"""__CFG__"""))
E29_VARIANT = "__VARIANT__"
print("E29 FINAL", E29_VARIANT, json.dumps(E29_CFG), flush=True)
'''


def cell1(c, cfg, variant):
    c = once(c, "PPK, PPK_ERROR = None, None   # E26 K100 Q-defer:",
             E29_MODS.replace("__CFG__", json.dumps(cfg, sort_keys=True)).replace("__VARIANT__", variant)
             + "PPK, PPK_ERROR = None, None   # E26 K100 Q-defer:", "E1 modules")
    c = once(c, '                        "lib": E28L.LIB_VERSION}   # E28 K100\n',
             '                        "lib": E28L.LIB_VERSION}   # E28 K100\n'
             'CONFIG["nb5"]["e29"] = {"variant": E29_VARIANT, "cfg": E29_CFG, "lib": E29L.LIB_VERSION, "sched_error": E29S_ERROR,\n'
             '                        "sched_sha": getattr(E29S, "E29_SCHED_SHA", None)}   # E29\n', "E1 config")
    w = int(cfg["workers"])
    if w != 24:
        c = once(c, "                  top_rung_seqs=24)   # user 2026-11-01: 24 workers / --max-num-seqs 24 on the TOP rung only\n",
                 f"                  top_rung_seqs={w})   # E29: workers {w} / --max-num-seqs {w} on the TOP rung only\n", "E2 workers")
        line = next(l for l in c.splitlines() if l.startswith("K100_CAPS = [1, 2, 3, 4, 6, 8, 12, 16, 24, 32, 40, 48, 64, 80, 84]"))
        caps = E29L.mtp_captures_for(w, [], REGISTRY_CAPS)
        assert -(-w * 4 // 2) in caps, (w, caps)
        c = once(c, line + "\n", f"K100_CAPS = {json.dumps(caps)}   # E29: Merlin capture_sizes_for({w}, K=3) (workers {w})\n", "E2 caps")
    return c


# ------------------------------------------------------------------ E3: CELL 3 (the scheduler)
E29_SCHED_APPLY = r'''# ---- E29 FINAL: the scheduler (Build/E28_SCHED_API.md; e29_sched_patch.py docstring). attempts_supply -> the E29 scheduler
# (E28 A / B / C + S-1: idle workers start extra attempts once the A / B / C queues are empty); any failure -> reverted to the
# original file -> the E28 scheduler (proven). The E28 path keeps its rule: commit = NO_GO_E28_SCHED (raised), rerun =
# reverted, the original scheduler runs.
E28_SCHED_REC = {"want": bool(P.get("e28_sched")), "applied": False, "e29_supply_want": bool(E29_CFG["attempts_supply"]), "failures": []}
if E28_SCHED_REC["want"]:
    _e29_paths = (["E29"] if E29_CFG["attempts_supply"] else []) + ["E28"]
    for _lab in _e29_paths:
        try:
            if _lab == "E29":
                if E29S is None:
                    raise RuntimeError("E29_SCHED_MODULE_MISSING: " + str(E29S_ERROR))
                _ap, _vf = E29S.apply_e29_sched, E29S.verify_e29_sched
            else:
                if E28S is None:
                    raise RuntimeError("E28_SCHED_MODULE_MISSING: " + str(E28S_ERROR))
                _ap, _vf = E28S.apply_e28_sched, E28S.verify_e28_sched
            E28_SCHED_REC.update({k: v for k, v in _ap(E12_DIR).items() if k != "text"})
            _ok, _why = _vf(E12_DIR)
            E28_SCHED_REC.update(verify_ok=_ok, verify_why=_why, state=(E29S if _lab == "E29" else E28S).tree_state(E12_DIR))
            if not _ok:
                raise RuntimeError(f"{_lab}_SCHED_VERIFY_FAILED: " + str(_why))
            _e28env = dict(E29S.server_env(supply=True) if _lab == "E29" else E28S.server_env())
            if E11_HARNESS:              # local / CPU-kit harness only: the fake run's short attempts (NB5_ATTEMPT_B0 / E28H_B2_TOKENS)
                _e28env.update(E28_T1=str(NB5_ATTEMPT["b0"]), E28_B2_TOKENS=os.environ.get("E28H_B2_TOKENS", _e28env["E28_B2_TOKENS"]))
            _e28env["E28_B2_REQUEST_TIMEOUT"] = str(E28_B2_TIMEOUT)   # E28 K100 (user 2026-11-01): B2 requests 9,000 s; T1 7,200 s
            if int(_e28env["E28_T1"]) != int(NB5_ATTEMPT["b0"]):
                E28_SCHED_REC["warning"] = f"E28_T1 {_e28env['E28_T1']} != NB5_ATTEMPT b0 {NB5_ATTEMPT['b0']}"
            os.environ.update(_e28env)
            E28_SCHED_REC.update(applied=True, env=_e28env, path=_lab, error=None)
            print(f"{_lab} SCHED: applied", json.dumps({k: E28_SCHED_REC.get(k) for k in ("applied", "path", "before", "after", "sha_after", "verify_why")}), flush=True)
            break
        except Exception as _e:
            E28_SCHED_REC.update(applied=False, error=f"{_lab}: {type(_e).__name__}: {_e}"[:800])
            E28_SCHED_REC["failures"].append(E28_SCHED_REC["error"])
            for _k in set((getattr(E29S, "ENV_NAMES", None) or ()) + (getattr(E28S, "ENV_NAMES", None) or ("E28_SCHED",))):
                os.environ.pop(_k, None)
            try:                        # back to the original arc2_duck.py (E29 revert handles E28-patched and E29-patched)
                E28_SCHED_REC.setdefault("reverts", []).append({k: v for k, v in (E29S.revert_e29_sched(E12_DIR) if E29S is not None
                                                                                   else E28S.revert_e28_sched(E12_DIR)).items() if k != "text"})
            except Exception as _e2:
                E28_SCHED_REC["revert_error"] = f"{type(_e2).__name__}: {_e2}"[:400]
            print(f"!!!!!!!!!! NO_GO_{_lab}_SCHED:", E28_SCHED_REC["error"], "->", "the E28 scheduler" if _lab == "E29" else
                  ("RERUN: the ORIGINAL scheduler runs" if RERUN else "commit: no solve (CELL 0's fallback)"), flush=True)
            if _lab == "E28" and not RERUN:
                raise RuntimeError("NO_GO_E28_SCHED: " + E28_SCHED_REC["error"])
CONFIG["e28_sched"] = E28_SCHED_REC
'''


def cell3(c):
    return once(c, E28B.E28_SCHED_APPLY, E29_SCHED_APPLY, "E3 scheduler")


# ------------------------------------------------------------------ E4 - E6: the engine cell
E29_ENGINE = r'''


# ==================================================================== E29 FINAL: the switchable levers (e29_lib, build_e29_final.py)
# Real-failure gates only. A boot try with an E29 lever on that fails before any phase (launch / OOM / not ready / probes /
# C-11 / the DFlash read-back / the zero-accept canary) drops ONE lever (e29_lib.lever_to_drop: the one the log names, else
# DFlash, then indexer, vocab, GDN) and the next try runs; DFlash -> the proven MTP K3 config at the top rung (I8 restored).
# With no E29 lever left the E28 ladder (and its I8 rule) runs unchanged.
E29_RT = {"cfg": E29_CFG, "on": [], "dropped": [], "df": None, "vocab": None, "idx": None, "gdn": None,
          "supply": None, "tries": [], "canary": [], "inrun": None, "hourly_al": None, "seam": None, "drafter": None,
          "errors": [], "df_try": False, "df_live": False}
DS, SSEQ = None, None


__DRAFTER_FNS__


def _e29_tree_py():
    eng = merlin_install()
    return Path(eng["kv"]["MERLIN_TREE"]), eng["kv"]["MERLIN_VENV"] + "/bin/python"


def e29_drop(lever, why, try_name=None):
    """Drops one E29 lever (recorded); DFlash: the seam reverted (exact Merlin files), I8 restored (E28's MTP config)."""
    if lever in E29_RT["on"]:
        E29_RT["on"].remove(lever)
    E29_RT["dropped"].append({"lever": lever, "why": str(why)[:600], "try": try_name, "t_sec": round(time.perf_counter() - NOTEBOOK_T0)})
    log("!!!!!!!!!! E29 lever dropped:", lever, "|", str(why)[:300], "| try", try_name, "| still on", E29_RT["on"])
    if lever == "df":
        E29_RT["df_try"] = E29_RT["df_live"] = False
        if SSEQ is not None and not FAKE:
            try:
                E29_RT["seam"] = dict(E29_RT.get("seam") or {}, finish=SSEQ.finish())
            except Exception as e:
                E29_RT["errors"].append(f"seam finish: {e!r}"[:300])
        if E28_I8.get("want") and not E28_I8.get("dropped"):
            E28_I8["on"] = True                   # E28's proven MTP config (I8 on; its own I8 rule applies from here)
        E28_I8.pop("suspended", None)


def e29_df_setup():
    """NBDF-K100's DFlash2 boot path (E27 Build): the drafter Model gate (pinned shas: model.safetensors d2e0464d, config,
    embed tokens, mask row 248077), dflash_seam.py (sha 7356d473, from the E29 payload dataset) applied with SeamSeq
    (ring first, then core; draft_block on), the seam env (DFLASH_SEAM=1, DFLASH_MASK_ROW_SHA, DFLASH_DRAFT_SW_BLOCK=1024),
    the spec {"method": "dflash", BF16 drafter KV "auto", FLASH_ATTN, probabilistic} and the captures (1 + K) x 1..workers."""
    global DS, SSEQ
    k = E29L.K_OF[E29_CFG["drafter"]]
    rec = E29_RT["df"] = {"want": E29_CFG["drafter"], "k": k, "ok": False}
    try:
        drafter = (drafter_facts() if not FAKE else
                   {"ok": True, "fake": True, "dir": str(TMP / "fake_drafter"), "check": {"embed_in_checkpoint": True}})
        E29_RT["drafter"] = {k_: drafter.get(k_) for k_ in ("ok", "status", "why", "dir", "pins_ok", "pin_mismatches", "check", "sec", "fake")}
        if not drafter.get("ok"):
            raise RuntimeError("DRAFTER: " + str(drafter.get("why")))
        if not (drafter.get("check") or {}).get("embed_in_checkpoint"):
            raise RuntimeError("DRAFTER_NO_EMBED_TOKENS (the bf16-embed variation is required)")
        src = q27x_payload(*E29L.SEAM_FILE)
        (TMP / E29L.SEAM_FILE[0]).write_bytes(src)
        import dflash_seam as _DS
        DS = _DS
        if not FAKE:
            tree, py = _e29_tree_py()
            SSEQ = N.SeamSeq(lambda ring: DS.apply_dflash_patch(tree, py, ring=ring),
                             lambda ring: DS.verify_dflash_patch(tree, ring=ring),
                             lambda ring: DS.revert_dflash_patch(tree, py, ring=ring))
            ok, why = SSEQ.apply()
            E29_RT["seam"] = {"apply": why, "ring": SSEQ.ring, "state": SSEQ.state,
                              "ppack_after": (PPK.verify_ppack_patch(tree)["state"] if PPK is not None else None)}
            if not ok:
                raise RuntimeError("SEAM: " + str(why))
        rec.update(dir=drafter["dir"], spec=N.dflash_spec(drafter["dir"], k, "auto", "FLASH_ATTN"),
                   captures=N.capture_sizes(int(E29_CFG["workers"]), k),
                   mask_row_sha=N.DRAFTER_PINS["mask_row"]["sha256"], sw_block=N.SW_BLOCK)
        rec["tail"] = E29L.df_spec_argv(N.spec_json(rec["spec"]), N.compilation_json(rec["captures"]))
        rec["ok"] = True
        return True
    except Exception as e:
        rec["error"] = f"{type(e).__name__}: {e}"[:800]
        E29_RT["dropped"].append({"lever": "df", "why": "setup: " + rec["error"], "try": None})
        log("!!!!!!!!!! E29 DFlash setup failed -> MTP K3 (E28):", rec["error"][:400])
        if SSEQ is not None and SSEQ.state in ("applied", "failed"):
            try:
                E29_RT["seam"] = dict(E29_RT.get("seam") or {}, finish=SSEQ.finish())
            except Exception as e2:
                E29_RT["errors"].append(f"seam finish: {e2!r}"[:300])
        return False


def e29_setup():
    """Before the first boot (after k100_setup and the I8 static check): which E29 levers are on. A setup miss = that lever
    off (recorded); never raises."""
    c, on = E29_CFG, []
    try:
        E29_RT["supply"] = {"want": bool(c["attempts_supply"]), "path": E28_SCHED_REC.get("path"), "applied": E28_SCHED_REC.get("applied")}
        if c["indexer_fp8"]:
            on.append("idx")
            E29_RT["idx"] = {"want": True, "args": E29L.IDX_ARGS}
        for g_ in ("gdn_fastpath", "gdn_align"):
            if c[g_]:
                on.append(g_)
        E29_RT["gdn"] = {g_: bool(c[g_]) for g_ in ("gdn_fastpath", "gdn_align")}
        if c["draft_vocab"]:
            nm, sh = E29L.VOCAB_FILES[c["draft_vocab"]]
            try:
                q27x_payload(nm, sh)
                E29_RT["vocab"] = {"want": c["draft_vocab"], "file": Q27X_PAYLOAD_USED[nm]["path"], "sha256": sh}
                on.append("vocab")
            except Exception as e:
                E29_RT["vocab"] = {"want": c["draft_vocab"], "error": f"{type(e).__name__}: {e}"[:400]}
                E29_RT["dropped"].append({"lever": "vocab", "why": "setup: " + E29_RT["vocab"]["error"], "try": None})
        if c["drafter"] != "mtp" and e29_df_setup():
            on.insert(0, "df")
            E28_I8.update(on=False, suspended="N/A_DFLASH")   # checklist 2: DRAFT_HEAD never reaches a dflash spec
    except BaseException as e:
        E29_RT["errors"].append("setup: " + traceback.format_exc()[-1200:])
    E29_RT["on"] = on
    NB5_REPORT["e29"] = E29_RT
    log("E29 setup", json.dumps({"on": on, "dropped": E29_RT["dropped"], "i8_on": E28_I8.get("on")}, default=str)[:900])


def e29_env(df):
    """The server env of this try's E29 levers (into NB5_BOOT_LEVERS: the server env, replayed by a relaunch)."""
    env = {}
    if df:
        env.update({str(a): str(b) for a, b in DS.server_env(mask_row_sha=E29_RT["df"]["mask_row_sha"], embed_host=bool(df.get("embed_host")),
                                                             draft_sw_block=E29_RT["df"]["sw_block"]).items()})
    elif "vocab" in E29_RT["on"]:
        env.update(VLLM_DRAFT_VOCAB_FILE=E29_RT["vocab"]["file"], VLLM_DRAFT_VOCAB_SHA256=E29_RT["vocab"]["sha256"])
    for g_, k_ in E29L.GDN_ENV.items():
        if g_ in E29_RT["on"]:
            env[k_] = "1"
    return env


def e29_extra(df):
    """The trailing argv of this try's E29 levers (after --max-num-seqs; the DFlash spec + captures come last: last wins)."""
    return (list(E29L.IDX_ARGS) if "idx" in E29_RT["on"] else []) + (list(E29_RT["df"]["tail"]) if df else [])


def e29_ntries(brec):
    """E18 R2's 3-try cap counts the tries without an E29 lever (the E28 ladder keeps its 3 tries)."""
    return sum(1 for t_ in brec["tries"] if not t_.get("e29_on"))


def e29_df_readback(s):
    """dflash_seam.readback_label on the boot log (NBDF dflash_rb): ENGAGED = aux taps on 4 ranks, embed own + mask row sha,
    head shared, draft_load_check per drafter worker, ingraph_meta consistent."""
    if FAKE:
        return {"label": "FAKE_SERVER"}
    try:
        lab, det = DS.readback_label(s.log() or "", mask_row_sha=E29_RT["df"]["mask_row_sha"],
                                     embed_host=(getattr(s, "env", None) or {}).get("DFLASH_DRAFT_EMBED_HOST") == "1")
    except Exception as e:
        lab, det = "NOT_INTEGRATED", {"error": repr(e)[:300]}
    return {"label": lab, "detail": det, "arch_line": E29L.DF_ARCH in (s.log() or "")}


def e29_counters():
    try:
        return E29L.spec_counters(e21_prom())
    except Exception as e:
        return {"error": repr(e)[:200]}


def e29_inrun_check(rows):
    """The in-run zero-accept canary (checklist 8): DFlash live, >= 200 draft tokens since the phase start and < 2 % accepted
    -> the booted config is switched to MTP K3 (trailing DFlash args + seam env removed) and the server is stopped; the
    E15B watchdog relaunches it with that config (e21_relaunch replays NB5_ACTIVE_BOOT). Fires once."""
    if not E29_RT.get("df_live") or E29_RT.get("inrun_fired"):
        return
    c = E29L.inrun_zero(rows, E29_RT["df"]["k"])
    E29_RT["inrun"] = c
    if not c.get("hit") or FAKE:
        return
    E29_RT["inrun_fired"] = True
    try:
        NB5_ACTIVE_BOOT["extra"] = E29L.strip_df_argv(NB5_ACTIVE_BOOT.get("extra"), E29_RT["df"]["tail"])
        NB5_ACTIVE_BOOT["levers"] = {k_: v_ for k_, v_ in dict(NB5_ACTIVE_BOOT.get("levers") or {}).items() if k_ not in DS.ALL_ENVS}
        e29_drop("df", "IN_RUN DFLASH_ZERO_ACCEPT " + json.dumps(c, default=str)[:300], NB5_ACTIVE_BOOT.get("name"))
        E28_I8["on"] = False                      # the relaunch replays the booted levers (BF16 head: no I8 read-back gate there)
        log("!!!!!!!!!! E29 in-run DFlash zero accept -> the server stops; the watchdog relaunches with MTP K3")
        if E11_SERVER is not None:
            E11_SERVER.kill()
    except Exception as e:
        E29_RT["errors"].append(f"inrun fallback: {e!r}"[:300])
'''


def engine(c):
    anchor = E28B.E28_ENGINE
    assert c.count(anchor) == 1
    c = c.replace(anchor, anchor + E29_ENGINE.replace("__DRAFTER_FNS__", DRAFTER_FNS.rstrip("\n")))
    # E5: nb5_boot_try
    c = once(c, "    srv = merlin_fn_server(name, NB5_BOOT_KV, NB5_PORT, kv_bytes)\n",
             "    try:\n"
             "        srv = merlin_fn_server(name, NB5_BOOT_KV, NB5_PORT, kv_bytes)\n"
             "    except Exception as _e29e:                         # E29: with an E29 lever on, a launch-prep raise (e.g. FAIL_CLI_FLAGS)\n"
             "        if not trec.get(\"e29_on\"):                    # = a failed try (the lever is dropped); without one: E28 (raise)\n"
             "            raise\n"
             "        trec.update(status=\"E29_LAUNCH_PREP_FAILED\", e29_error=f\"{type(_e29e).__name__}: {_e29e}\"[:800],\n"
             "                    log_text_for_ladder=f\"{type(_e29e).__name__}: {_e29e}\")\n"
             "        return trec\n", "E5 launch prep")
    c = once(c, '        trec["config_readback"] = NB5L.config_readback(s.log(), s.argv, NB5_BOOT_KV, mtp_on)    # C-11\n',
             '        trec["config_readback"] = NB5L.config_readback(s.log(), s.argv, NB5_BOOT_KV, mtp_on)    # C-11\n'
             '        E29_RT["df_live"] = False\n'
             '        if E29_RT.get("df_try"):                             # E29 DFlash: C-11 without the MTP checks + the DFlash facts,\n'
             '            trec["config_readback"] = E29L.df_config_check(trec["config_readback"], s.log(), E29_RT["df"]["k"])\n'
             '            trec["e29_df_readback"] = e29_df_readback(s)     # then the seam read-back (ENGAGED required, NBDF)\n'
             '            if not trec["config_readback"]["ok"] and not FAKE:\n'
             '                trec["status"] = "E29_DFLASH_CONFIG_MISMATCH"\n'
             '                return {}\n'
             '            if trec["e29_df_readback"]["label"] not in ("ENGAGED", "FAKE_SERVER"):\n'
             '                trec["status"] = "E29_DFLASH_NOT_ENGAGED"\n'
             '                return {}\n', "E5 df readback")
    c = once(c, '        trec["k100_gates"] = k100_boot_gates(s, mtp_on)      # E26 K100',
             '        trec["k100_gates"] = k100_boot_gates(s, mtp_on and not E29_RT.get("df_try"))      # E29: no MTP experts on DFlash; E26 K100',
             "E5 gates")
    c = once(c, '        trec["warmup"] = nb5_warmup(s.port, W)\n',
             '        _e29_c0 = e29_counters() if E29_RT.get("df_try") else None   # E29 DFlash: the zero-accept canary over the warm-up\n'
             '        trec["warmup"] = nb5_warmup(s.port, W)\n'
             '        if E29_RT.get("df_try"):\n'
             '            trec["e29_canary"] = E29L.canary(_e29_c0, e29_counters(), E29_RT["df"]["k"])\n'
             '            E29_RT["canary"].append(dict(trec["e29_canary"], try_name=name))\n'
             '            log("E29 DFlash canary", json.dumps(trec["e29_canary"]))\n'
             '            if trec["e29_canary"]["hit"] and not FAKE:\n'
             '                trec["status"] = "E29_DFLASH_ZERO_ACCEPT"\n'
             '                return {}\n'
             '            E29_RT["df_live"] = True\n', "E5 canary")
    # E5: nb5_boot (the D tries, per-try env / argv, the drop rule before the I8 rule)
    c = once(c, "    levers = dict(NB5_PIN[\"levers\"] if NB5_PIN[\"levers\"] is not None else NB5_LEVER_ENV)\n",
             "    levers = dict(NB5_PIN[\"levers\"] if NB5_PIN[\"levers\"] is not None else NB5_LEVER_ENV)\n"
             "    if \"df\" in E29_RT[\"on\"] and mtp_on:            # E29 DFlash: the NBDF-K100 D pin ladder first, then the E28 ladder (MTP)\n"
             "        tries = E29L.df_tries(bool(E29_CFG[\"embed_host\"])) + list(tries)\n", "E5 df tries")
    c = once(c, "        NB5_BOOT_LEVERS = dict(levers, **(E28_I8_ENV if E28_I8[\"on\"] else {}))   # E28 K100 I8: DRAFT_HEAD=int8 into build()\n",
             "        _e29d = tr.get(\"df\") if \"df\" in E29_RT[\"on\"] else None   # E29: this try's DFlash plan (None = MTP)\n"
             "        if tr.get(\"df\") and _e29d is None:\n"
             "            i += 1\n"
             "            continue\n"
             "        E29_RT[\"df_try\"] = bool(_e29d)\n"
             "        NB5_BOOT_LEVERS = dict(levers, **(E28_I8_ENV if E28_I8[\"on\"] and not _e29d else {}))   # E28 K100 I8: DRAFT_HEAD=int8 into build()\n"
             "        NB5_BOOT_LEVERS.update(e29_env(_e29d))     # E29: seam env / draft vocab / GDN switches\n", "E5 levers")
    c = once(c, "        seqs = NB5L.seqs_for(NB5_BOOT_KV, tr[\"gib\"]) if NB5_SEQS_RULE == \"table\" else",
             "        seqs = int(E29_CFG[\"workers\"]) if _e29d else NB5L.seqs_for(NB5_BOOT_KV, tr[\"gib\"]) if NB5_SEQS_RULE == \"table\" else",
             "E5 df seqs")
    c = once(c, "        NB5_BOOT_EXTRA = base_extra + ([\"--max-num-seqs\", str(seqs)] if seqs else [])\n",
             "        NB5_BOOT_EXTRA = base_extra + ([\"--max-num-seqs\", str(seqs)] if seqs else []) + e29_extra(_e29d)   # E29: indexer / DFlash last\n",
             "E5 extra")
    c = once(c, '                + ("_i8" if E28_I8["on"] else ""))   # E28 K100\n',
             '                + ("_i8" if E28_I8["on"] and not _e29d else "") + (f"_df{E29_RT[\'df\'][\'k\']}r{_e29d[\'rung\']}" if _e29d else "")\n'
             '                + "".join("_" + x for x in E29_RT["on"] if x != "df"))   # E28 K100; E29\n', "E5 name")
    c = once(c, '                "e28_i8": bool(E28_I8["on"])}   # E28 K100\n',
             '                "e28_i8": bool(E28_I8["on"]) and not _e29d,   # E28 K100\n'
             '                "e29_on": [x for x in E29_RT["on"] if x != "df" or _e29d], "e29_df": _e29d}   # E29\n', "E5 trec")
    c = once(c, '        if (E28_I8["on"] and not ABORT.get("why") and not trec.get("phases_started") and not (P.get("e18_ladder") and len(brec["tries"]) >= 3)\n',
             '        E29_RT["tries"].append({k_: trec.get(k_) for k_ in ("name", "status", "kv_bytes", "max_num_seqs_launch", "e29_on", "e29_df")})\n'
             '        _e29s = str(trec.get("status"))\n'
             '        if (trec.get("e29_on") and not trec.get("phases_started") and not ABORT.get("why") and _e29s != "DONE"\n'
             '                and _e29s not in ("GPU_NOT_EMPTY", "HOST_RAM_GATE_FAILED")):\n'
             '            # E29: a pre-phase failure with an E29 lever on -> drop ONE lever (DFlash: an OOM -> the next D rung first)\n'
             '            _e29l = E29L.lever_to_drop(trec["e29_on"], _e28_log, _e29s)\n'
             '            if _e29l == "df":\n'
             '                _e29o = E29L.is_oom(_e28_log) and _e29s not in ("E29_DFLASH_NOT_ENGAGED", "E29_DFLASH_ZERO_ACCEPT", "E29_DFLASH_CONFIG_MISMATCH")\n'
             '                _e29n = E29L.next_try_index(tries, i, _e29o, False)\n'
             '                if not (_e29n < len(tries) and tries[_e29n].get("df")):\n'
             '                    e29_drop("df", f"{_e29s} (oom {_e29o})", name)   # -> the proven MTP K3 config, the top rung\n'
             '                else:\n'
             '                    log("E29 DFlash OOM -> the next D rung", tries[_e29n])\n'
             '                i = _e29n\n'
             '                continue\n'
             '            if _e29l:\n'
             '                e29_drop(_e29l, _e29s, name)\n'
             '                continue                           # the same pin without that lever\n'
             '        if (E28_I8["on"] and not ABORT.get("why") and not trec.get("phases_started") and not (P.get("e18_ladder") and e29_ntries(brec) >= 3)\n',
             "E5 drop rule")
    c = once(c, '        if not fail["failed"] or not P.get("pin_ladder") or ABORT.get("why") or (P.get("e18_ladder") and len(brec["tries"]) >= 3):\n',
             '        if not fail["failed"] or not P.get("pin_ladder") or ABORT.get("why") or (P.get("e18_ladder") and e29_ntries(brec) >= 3):\n',
             "E5 e18 cap")
    # E6: the sampler
    c = once(c, '                 "gen": g("vllm:generation_tokens_total"), "preempt": g("vllm:num_preemptions_total")}\n',
             '                 "gen": g("vllm:generation_tokens_total"), "preempt": g("vllm:num_preemptions_total")}\n'
             '            if not E29L.is_default(E29_CFG):           # E29: the spec-decode counters (hourly AL, the in-run canary)\n'
             '                s.update(sd_drafts=g(E29L.SD_DRAFTS), sd_draft_tok=g(E29L.SD_DRAFT_TOK), sd_acc=g(E29L.SD_ACC))\n', "E6 sampler")
    c = once(c, "        rows.append(s)\n",
             "        rows.append(s)\n"
             "        if E29_RT.get(\"df_live\"):                       # E29 DFlash: the in-run zero-accept canary (fires once)\n"
             "            try:\n"
             "                e29_inrun_check(rows)\n"
             "            except Exception as _e:\n"
             "                E29_RT[\"errors\"].append(f\"inrun check: {_e!r}\"[:200])\n", "E6 inrun")
    return c


E29_SETUP = r'''    e29_setup()   # E29 FINAL: the switchable levers (vocab / DFlash drafter + seam / indexer / GDN); a miss = that lever off
'''


def runner(c):
    a = '    log("E28 K100 I8", json.dumps({k: E28_I8.get(k) for k in ("want", "on", "dropped")}, default=str)[:600], "| static",\n'
    i = c.index(a)
    j = c.index("\n", c.index("\n", i) + 1) + 1
    return c[:j] + E29_SETUP + c[j:]


def report(c):
    return once(c, '    write_json_atomic(BASE_OUT / "e28_k100_report.json", E28_OUT)\n',
                '    try:                                     # E29: flags, drops, canaries, hourly AL (record only)\n'
                '        E29_RT["hourly_al"] = E29L.hourly_al(globals().get("_ksamp"))\n'
                '        E28_OUT["e29"] = dict(E29L.summary(E29_RT), variant=E29_VARIANT, sched=E28_SCHED_REC.get("path"))\n'
                '    except BaseException:\n'
                '        E28_OUT["e29_error"] = traceback.format_exc()[-1500:]\n'
                '    write_json_atomic(BASE_OUT / "e28_k100_report.json", E28_OUT)\n'
                '    print("E29 FINAL:", json.dumps(E28_OUT.get("e29") or E28_OUT.get("e29_error"), default=str)[:6000], flush=True)\n', "E8 report")


def md0(variant, cfg):
    on = {k: v for k, v in cfg.items() if v != E29L.default_cfg()[k]}
    return (f"# E29 FINAL production · {variant} · klee100 3bpw-MTP (E28 K100 base) · E28EVAL120\n\n"
            f"- **Flags on:** `{json.dumps(on, sort_keys=True)}` (every flag off = E28 K100 exactly; Build/build_e29_final.py).\n"
            "- **Base = E28 K100** (klee100 3bpw-MTP on Merlin TP2 x PP2, MTP K3 + Q-defer + I8, 24 workers, the A / B / C scheduler,"
            " T1 104k / B2 120k / max-model-len 131,072).\n"
            "- **Fallbacks (real failures only):** scheduler S-1 -> E28 scheduler; DFlash2 boot / read-back / canary -> MTP K3 at the same"
            " pin; indexer fp8 / draft vocab / GDN -> the same try without it.\n"
            "- **Dual mode (proven):** commit = EVAL120 scored; rerun = every hidden task, CELL 0 = E18 R2 verbatim, the E15B writer,"
            " 12 h budget. Report: `q27x/e28_k100_report.json` (`e29` key) + `q27x/nb5_report.json`.\n")


def cells_for(variant, cfg):
    E28B.MODULES_JSON = MODULES_JSON                    # E1: the E28 K5 literal now carries the E29 modules too
    base = E28B.cells()
    out = [("markdown", md0(variant, cfg)), base[1], ("code", cell1(base[2][1], cfg, variant)), ("code", cell3(base[3][1])),
           base[4], ("code", engine(base[5][1])), base[6], ("code", runner(base[7][1])), ("code", report(base[8][1]))]
    assert out[1][1] == KQ.E18R2_CELL0, "CELL 0 must stay E18 R2's (dual mode + fallback submission)"
    return out


CELL6_HEAD = "def e21_cell6():\n"
CELL6_PACK = r'''# ---- E29 FINAL (size: the 400-kB commit limit): e21_cell6() (E15B CELL 6 as E28 K100 runs it, the E28 scheduler N3 included,
# UNCHANGED) as ONE sha-pinned lzma + base85 literal executed into this namespace (= E28's e21_cell7 technique). The readable
# text is in the build's code export.
exec(compile(__PACKED__, "<E29: e21_cell6 = E15B CELL 6>", "exec"), globals())
'''


def pack_cell6(c):
    i = c.index(CELL6_HEAD)
    j = c.index("# ---- E28 K100 (size: the 400-kB commit limit): e21_cell7()")
    assert c.count(CELL6_HEAD) == 1 and i < j
    body = c[i:j]
    return c[:i] + CELL6_PACK.replace("__PACKED__", E28B.packed_lzma(body, "e21_cell6")) + "\n\n" + c[j:], {"sha256": sha(body), "bytes": len(body.encode())}


def slug_of(variant):
    return "q27-xhigh-" + variant.lower().replace("_", "-")


def kernel_metadata(variant, cfg):
    ds = list(KQ.DATASETS) + ([DS_ID] if (cfg["drafter"] != "mtp" or cfg["draft_vocab"]) else [])
    models = list(KQ.MODELS) + ([DRAFTER_MODEL] if cfg["drafter"] != "mtp" else [])
    return {"id": f"{OWNER}/{slug_of(variant)}", "title": "Q27 Xhigh " + variant.replace("_", " ").title(),
            "code_file": f"{slug_of(variant)}.ipynb", "language": "python", "kernel_type": "notebook", "is_private": True,
            "enable_gpu": True, "enable_tpu": False, "enable_internet": False, "keywords": [], "dataset_sources": ds,
            "kernel_sources": [], "competition_sources": ["arc-prize-2026-arc-agi-2"], "model_sources": models,
            "docker_image": KQ.DOCKER, "machine_shape": "NvidiaL4"}


def write_dataset():
    DS_DIR.mkdir(parents=True, exist_ok=True)
    files = {E29L.SEAM_FILE[0]: SEAM_BYTES}
    for _k, (_f, _s) in E29L.VOCAB_FILES.items():
        files[_f] = (VOCAB_DIR / _f).read_bytes()
    for n, b in files.items():
        (DS_DIR / n).write_bytes(b)
    meta = {"title": "q27-e29-final-payload", "id": DS_ID, "licenses": [{"name": "CC0-1.0"}], "isPrivate": True}
    (DS_DIR / "dataset-metadata.json").write_bytes((json.dumps(meta, indent=1) + "\n").encode("utf-8"))
    return {"dir": str(DS_DIR), "id": DS_ID, "files": {n: {"bytes": len(b), "sha256": sha(b)} for n, b in files.items()}}


def build(variant):
    cfg = E29L.check_cfg(VARIANTS[variant])
    cl = cells_for(variant, cfg)
    B.undefined_names_check(cl)
    ncl, pack7 = E28B.notebook_cells(cl)
    data, n, fmt = E28B.notebook_bytes(ncl)
    pack6 = None
    if len(data) >= 395_000:
        c6, pack6 = pack_cell6(ncl[6][1])
        ncl[6] = ("code", c6)
        data, n, fmt = E28B.notebook_bytes(ncl)
    assert b"\r" not in data.replace(b"\\r", b""), "CR in the notebook"
    assert len(data) < 400_000, ("Kaggle commit notebook size limit (keep < 400 kB)", len(data))
    nb = json.loads(data.decode("utf-8"))
    assert "".join(nb["cells"][1]["source"]) == B.norm(KQ.E18R2_CELL0) or "".join(nb["cells"][1]["source"]).rstrip("\n") == KQ.E18R2_CELL0.rstrip("\n")
    out = ROOT / "Experiment Notebooks" / f"Q27-XHIGH-{variant}.ipynb"
    if out.exists() and sha(out.read_bytes()) in PUSHED:
        out = out.with_name(out.stem + "_REBUILD.ipynb")
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(data)
    slug = slug_of(variant)
    push = PUSH_ROOT / f"{slug}__{OWNER}"
    push.mkdir(parents=True, exist_ok=True)
    (push / f"{slug}.ipynb").write_bytes(data)
    (push / "kernel-metadata.json").write_bytes((json.dumps(kernel_metadata(variant, cfg), indent=2) + "\n").encode("utf-8"))
    export = HERE / f"{variant.lower()}_code_export.py"
    export.write_bytes("\n\n".join(B.norm(t) for k, t in cl if k == "code").encode("utf-8"))
    rec = {"variant": variant, "cfg": cfg, "notebook": str(out), "sha256": sha(data), "bytes": len(data), "cells": n,
           "push": str(push), "slug": f"{OWNER}/{slug}", "export": str(export), "e21_cell7_packed": pack7, "e21_cell6_packed": pack6,
           "kernel_metadata": kernel_metadata(variant, cfg)}
    # the per-variant facts in the E28 facts format (the E28 kit chain reads that format), E29 keys added
    f28 = json.loads(E28B.FACTS.read_text(encoding="utf-8"))
    f28.update(notebook=str(out), notebook_sha256=rec["sha256"], bytes=len(data), cells=n, json_format=fmt, e21_cell7_packed=pack7,
               e21_cell6_packed=pack6, export=str(export), push=str(push), kernel_metadata=rec["kernel_metadata"],
               modules={nm: sha(t) for nm, t in MODULES.items()}, modules_json_sha256=sha(MODULES_JSON),
               e29={"variant": variant, "cfg": cfg, "sched_sha": E29S.E29_SCHED_SHA, "seam": list(E29L.SEAM_FILE),
                    "vocab_files": E29L.VOCAB_FILES, "dataset": DS_ID, "drafter_model": DRAFTER_MODEL,
                    "e28_notebook_sha256": E28_NB_SHA})
    vf = HERE / f"{variant.lower()}_build_facts.json"
    vf.write_bytes((json.dumps(f28, indent=1, default=str) + "\n").encode("utf-8"))
    rec["facts"] = str(vf)
    print("wrote", out.name, "sha256", rec["sha256"], "|", len(data), "bytes |", n, "cells")
    return rec


if __name__ == "__main__":
    want = sys.argv[1:] or ["E29_DEFAULT", "E29_DFLASH_D3S", "E29_MTP_V64"]
    recs = {v: build(v) for v in want}
    facts_f = HERE / "e29_build_facts.json"
    facts = json.loads(facts_f.read_text(encoding="utf-8")) if facts_f.exists() else {}
    facts.setdefault("variants", {}).update(recs)
    facts.update(e28_notebook_sha256=E28_NB_SHA, e28_builder_sha256=sha((E28B_DIR / "build_e28_k100.py").read_bytes()),
                 modules={k: sha(v) for k, v in MODULES.items()}, modules_json_sha256=sha(MODULES_JSON),
                 e29_sched_sha=E29S.E29_SCHED_SHA, nbdf_lib_sha256=sha(NBDF_LIB_SRC), seam_sha256=E29L.SEAM_FILE[1],
                 drafter_fns_sha256=sha(DRAFTER_FNS), registry_caps=REGISTRY_CAPS, dataset=write_dataset(),
                 final_cfg_default=FINAL_CFG, variants_cfg=VARIANTS)
    facts_f.write_bytes((json.dumps(facts, indent=1, default=str) + "\n").encode("utf-8"))
