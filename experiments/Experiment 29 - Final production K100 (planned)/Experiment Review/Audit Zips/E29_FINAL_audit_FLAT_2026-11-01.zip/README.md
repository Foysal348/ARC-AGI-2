# Experiment 29: final production K100 (switchable build)

## Goal
One builder for the final submission notebook. Tonight's GPU results set only the flags.
- **Base:** E28 K100 EVAL120 (klee100 3bpw-MTP on Merlin TP2 x PP2, MTP K3 + Q-defer + I8, 24 workers, A / B / C scheduler, T1 104k / B2 120k / max-model-len 131,072, CELL 0 = E18 R2 verbatim, the E15B writer).
- **Builder:** `Build/build_e29_final.py`. It imports the E28 builder (`Experiment 28/.../Build/build_e28_k100.py`) and applies marked `# E29` edits.

## Flags (`FINAL_CFG`; all OFF = E28 K100)
| flag | values | what it does | fallback on a real failure |
|---|---|---|---|
| `drafter` | `mtp` / `dflash_d3s` / `dflash_d4s` | NBDF-K100 DFlash2 boot path: drafter Model `foysalemonshanto/qwen38-flash-next-dflash2v2/transformers/bf16-embed/1` (pinned shas), `dflash_seam.py` 7356d473 via SeamSeq, seam env (DFLASH_SEAM=1, DFLASH_MASK_ROW_SHA, DFLASH_DRAFT_SW_BLOCK=1024), BF16 drafter KV, dflash spec JSON, captures (1 + K) x 1..workers, I8 off, D pin ladder (EMBED_HOST, then 0.25-GiB rungs) | boot failure / C-11 / seam read-back not ENGAGED / zero-accept canary -> MTP K3 at the top rung (I8 restored, seam reverted); in-run canary -> MTP relaunch through the watchdog |
| `indexer_fp8` | bool | `--attention-config {"indexer_kv_dtype":"fp8"}` (the JSON form of `--attention-config.indexer_kv_dtype fp8`: the K-9 help gate only knows listed flags) | same try without it |
| `embed_host` | bool (dflash only) | `DFLASH_DRAFT_EMBED_HOST=1` from the first D try | (part of the D ladder) |
| `draft_vocab` | None / `32k` / `64k` (MTP only) | `VLLM_DRAFT_VOCAB_FILE` + `VLLM_DRAFT_VOCAB_SHA256` | same try without it |
| `gdn_fastpath` / `gdn_align` | bool each | `VLLM_GDN_DECODE_FASTPATH=1` / `VLLM_GDN_SHARED_ALIGN_INDEX=1` | same try without it |
| `workers` | 24 / 28 / 32 | top-rung workers = `--max-num-seqs`; 28 / 32 use Merlin `capture_sizes_for(w, 3)` | (E28 ladder) |
| `attempts_supply` | bool | scheduler S-1 (`Build/e29_sched_patch.py`): with A / B / C queues empty, idle workers start extra attempts (S1: no train pass, T1; S2: all cap-cut, B2 120k); best train -> attempt_1 | E29 apply / verify fails -> revert -> E28 scheduler |

**Drop rule:** a pre-phase failure with an E29 lever on drops one lever, then retries. The lever named in the log goes first; otherwise the order is DFlash, indexer, vocab, GDN. With no E29 lever left, the E28 ladder (including its I8 rule) runs unchanged.

## Notebooks (2026-11-01)
| notebook | flags | sha256 | bytes |
|---|---|---|---|
| (a) `Q27-XHIGH-E29_DEFAULT.ipynb` | attempts_supply | `5c74abf869bee204de3da97f26cfc0d9abe3fd9d5eb7cef69ae285925b871af9` | 397,092 |
| (b) `Q27-XHIGH-E29_DFLASH_D3S.ipynb` | + dflash_d3s + indexer_fp8 | `c775f653e2353c8d1957fb2f101995388491b79619546a23466cba05f1d70210` | 397,156 |
| (c) `Q27-XHIGH-E29_MTP_V64.ipynb` | + draft_vocab 64k + indexer_fp8 | `13419f696db4054a508551f97ba7711a050a01df595b45e416704c12d1292a27` | 397,143 |
| check build `Q27-XHIGH-ALL_OFF.ipynb` | none | `d7c391200bd9ab344b1fd2b4db196d13b3c79a70b2f1033372dfc7f8457f8381` | 397,060 |

- **GPU push folders** (foysalemonshanto, private): `D:/ARC AGI 2/_scratch/push_e25/q27-xhigh-e29-<default|dflash-d3s|mtp-v64>__foysalemonshanto/`.
- **Inputs:** the same Models / datasets as E28 K100. (b) adds the drafter Model; (b) and (c) add the dataset below.
- **Payload dataset to upload:** `D:/ARC AGI 2/_scratch/push_e25/ds_q27-e29-final-payload/` as `foysalemonshanto/q27-e29-final-payload`. It holds `dflash_seam.py`, `draft_vocab_k100_arc_n32768.pt` and `draft_vocab_k100_arc_n65536.pt`. The notebook finds each file by name + sha under `/kaggle/input`.
- **Size:** E28's e21_cell7 packing is kept, and e21_cell6 is packed the same way, so every notebook stays under 400 kB.

## Kits
- **Builder:** `Build/build_e29_cpu_kit.py`, a wrapper over the E28 kit chain.
- **Kits:** units x 3, sched, real-dflash-d3s and real-mtp-v64, under `D:/ARC AGI 2/_scratch/push_e25/q27-e29-kit-*__foysalemonshanto/`.
- **Local results:** retargeted E28 units 44/44, e29 lib / nb5_boot units 14/14 for each variant, and e29_sched_tests 29/29 on Py 3.12 and 3.14.
- **Not run yet:** the real kits; they run on Kaggle.
- **e2e kits:** not built.

## Open / not done
- The real kits have not run.
- The E28 e2e kits have not been retargeted, so there is no fake-server e2e of the E29 drop rule. The scripted nb5_boot units cover it.
- The DFlash and indexer GPU behaviour is unmeasured. (b) is DFlash's first full Duck run.
- NBDF's "no-hope" low-AL cut is not used, by the real-failure-only rule. Only the zero-accept canary gates; hourly AL is recorded.

## Change log
- 2026-11-01: folder, builder, the S-1 scheduler, kits. The indexer flag was switched to the JSON form after the kit agent found that the help gate would drop it.
