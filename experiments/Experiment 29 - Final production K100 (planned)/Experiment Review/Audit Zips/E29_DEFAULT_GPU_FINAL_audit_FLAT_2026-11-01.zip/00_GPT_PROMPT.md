# FINAL GPU audit: E29_DEFAULT (production candidate), Kaggle ARC-AGI-2, klee100 on Merlin, 4xL4

**Answer GO or NO-GO on the first line. Then list ONLY BLOCKERS and SEVERE bugs** (crash, a wasted / dead run, wrong or missing
submission output, wrong answers written, a scheduler that idles or starves, deadline overrun). Each with file:line, why, fix.
No style items, no "nice to have", no new features.

The GPU notebook is `NB__PUSH_q27-xhigh-e29-default.ipynb` (sha 5c74abf869bee204de3da97f26cfc0d9abe3fd9d5eb7cef69ae285925b871af9), the exact push-folder file.
- What it is: E28 K100 EVAL120 (this config ran 6 h on GPU: task-norm 65.0 %, 107/172, VALID, no errors;
  `REF__E28_K100_EVAL120_result_summary.json`) + ONE new lever: `attempts_supply` (scheduler S-1,
  `BUILD__e29_sched_patch.py`, env E29_SUPPLY=1): when the A / B / C queues are empty and time remains, free workers start
  extra attempts for tasks with no train pass (T1 budget) and for tasks whose attempts were all cap-cut (B2 budget);
  A/B/C keep priority; deadline guard unchanged; final answers: best-train -> attempt_1. Every other E29 flag is OFF here.
  Fallback: if the E29 scheduler patch fails to apply / verify, the file is reverted and the proven E28 scheduler applies.
- CELL 0 = E18 R2 verbatim (the proven eval + private-format submission cell); E15B writer unchanged; commit = 6 h window,
  competition rerun = 12 h - 3 min (E28 timing unchanged).
- CPU kits ALL OK: `KIT__units-default_report_ALL_OK.json` (retargeted E28 units 44/44 incl. "no lever on == E28"),
  `KIT__sched_report_ALL_OK.json` (e29_sched_tests 29/29 on the real Duck payload).

Questions: (1) can the supply lever ever idle workers, starve A/B/C, exceed the deadline, or write a worse / missing answer
than E28 would? (2) is the submission-writing path behaviourally identical to E28 (which produced a VALID submission)?
(3) anything that would crash or kill the 12 h competition rerun? List each with file:line.
