"""Small source-derived timing regression for E29-DIRECT late-phase-C selection.
This does not test the original Duck integration: the integration test must be added
in the full project using the exact arc2_duck fixture.
"""
import unittest

DRAIN_MIN=26

def direct_admit_possible(remaining_seconds, drain_min=DRAIN_MIN):
    return remaining_seconds > max(12 * 60, drain_min * 60)

def safe_direct_dispatch(phase, enabled, remaining_seconds, drain_min=DRAIN_MIN):
    return phase == 'C' and enabled and direct_admit_possible(remaining_seconds, drain_min)

class TestLateC(unittest.TestCase):
    def test_before_drain(self): self.assertTrue(safe_direct_dispatch('C', True, 27*60))
    def test_after_drain(self): self.assertFalse(safe_direct_dispatch('C', True, 25*60))
    def test_exact_boundary(self): self.assertFalse(safe_direct_dispatch('C', True, 26*60))
    def test_off(self): self.assertFalse(safe_direct_dispatch('C', False, 30*60))
    def test_other_phase(self): self.assertFalse(safe_direct_dispatch('A', True, 30*60))
    def test_original_unconditional_dispatch_would_be_wrong(self):
        # Current source: phase == 'C' and _e29d_on(); ignores remaining time.
        old = 'C' == 'C' and True
        self.assertTrue(old)
        self.assertFalse(safe_direct_dispatch('C', True, 10*60))

if __name__ == '__main__': unittest.main()
