# E29 DFLASH D3S REV2C — Independent risk audit (2026-11-02)

## Verdict
**NO-GO for unconditional 6-hour production commit** until HIGH-01 is fixed or demonstrated harmless with a late-C integration replay. **GO for a controlled GPU smoke** of DFlash boot/QSA, conditional on dataset/version gates. This is not a proven DFlash correctness failure.

## Scope & evidence
Inspected README.md, 00_GPT_PROMPT.md, current notebook, e29_direct.py, e29_nbx.py, e29d_sched_patch.py, e29_lib.py, build_e29_final.py, exported code, reference E28 code, rev2b kit material. SHA256 manifest 47/47 PASS; notebook hash `ed2e23a72c7fcbb9a15a9758544d499e59c5b528681387cad4bc23a4710d871c` matches README. Full live Merlin / GPU unavailable. The provided rev2b real kit is evidence of a **previous failed configuration**, not a passed rev2c integration test. Local pytest collection cannot proceed without `e28_sched_patch.py` and original Duck payload.

## Ranked findings

### HIGH-01 — Phase-C DIRECT silently consumes an attempt when the shared solve deadline enters the final 26 minutes (CONFIRMED source-level)
- `e29_direct.py:525-530`: `DRAIN=T_END-drain_min*60`, `ADMIT=min(T_END-720,DRAIN)`; with `drain_min=26`, a newly invoked one-task DIRECT will NOT admit any request after T−1560 sec.
- `e29_nbx.py:170-191`: each phase-C work item invokes a fresh one-task `solve_all_direct()` with the **shared full-run deadline**.
- `e29d_sched_patch.py` PATCH hunk near `_e29d_item` and worker selection: phase-C is replaced with DIRECT whenever `_e29d_on()` is true, **without checking remaining time against DIRECT's admission boundary**. The solver then returns empty records, `_e29d_item` marks C done, and the E28 Duck C opportunity is lost. The baseline E28 C execution is not reached.
- This is a conditional correctness/score coverage loss, not a guaranteed occurrence. Given E28 A alone consumes much of the six-hour window, this scenario must be tested.
- **Minimal fix**: In the phase-C dispatch condition **before** bypassing `sess()`, require `remaining_sec > direct_drain_sec + safety_margin_sec`; if not, keep original E28 Duck C dispatch (or explicitly enqueue a non-DIRECT fallback). Bind `direct_drain_sec` from the validated runtime E29_DIRECT2 config via a dedicated env/hook; do not hardcode an unrelated constant in arc2_duck. Example conceptual condition: `if p["phase"] == "C" and _e29d_on() and (deadline - time.monotonic()) > E29D_MIN_REMAIN_SEC:`. `E29D_MIN_REMAIN_SEC` must be derived from `drain_min` and checked across notebook/worker. Alternatively change `E29D_RUN` to return an explicit `NOT_ADMITTED` sentinel and have `_e29d_item` launch E28 Duck for that SAME item without double-release/double-completion; this is more intrusive.
- **Test**: fake clock T−27 minutes => DIRECT dispatched and stream count >0; T−25 minutes => E28 Duck C path, no DIRECT skip, one C completion, one reservation release, and a valid `attempt_2`. Repeat at exact boundary, with server unavailable and with `on=False`. Verify all-source winner selector remains correct.

### HIGH-02 — QSA 128/64 env readback is diagnostic, not a safety gate (CONFIRMED code, failure PLAUSIBLE)
- `e29_lib.py:279-343`: `qsa_env`, `proc_env_readback`, `qsa_readback`; `build_e29_final.py:~480`, `~696`: logging/record only. No requirement for 4 workers with matching values before the first 131k prefill.
- The earlier PP1 OOM with 256 MiB workspace is reproduced in supplied logs; current 128/64 setting itself has NOT been GPU tested. A missing or mismatched env on one PP1 worker could recreate the same OOM. Status **HIGH risk** not confirmed present in this build.
- **Fix**: fail the DFlash attempt (and advance safe fallback) if all four worker PIDs cannot be enumerated and expected QSA vars verified; if `proc` unavailable use a trusted worker-rank RPC readback, not a guess. Assert actual first-prefill allocator/peak too. Do not trust the reported arithmetic bound as a GPU allocation measurement.
- **Test**: four correct ranks => PASS; rank 3 missing => INCONCLUSIVE/no D admission; one `256` instead of `128` => explicit failure; post-boot first-prefill peak and 8k/40k/90k/116k checks.

### MEDIUM-03 — DIRECT full quality/memory with 24 long C tasks remains unvalidated (PLAUSIBLE)
- CPU fixtures cannot model DFlash2 + DIRECT same-KV demand, 104k thinking, 8192-token answer per test, tool waiting, or stage-1 QSA transient. Need resident count, preemption count, PP1 worker-min free memory, output/second and completed attempt_2.
- **Fix/test**: matched GPU smoke with task mix and 24 concurrent C entries; abort/retry, 1/2/3 test grids, long context and forced close. Treat OOM as real fallback, not an inconclusive/quality score.

### MEDIUM-04 — rev2c kits not proven passing (CONFIRMED evidence limitation)
- README states rev2c kits built but not pushed. The bundled `KIT_rev2b_real__*` report is prior failure. Unit 44/44 + 33/33 and DIRECT 12/12 are **reported**; independent full e2e cannot run here because the exact E28 patch and Duck payload aren't bundled.
- **Fix/test**: run exact rev2c unit, direct, real and fake-server e2e kits pinned to the notebook SHA, including XID vs OOM ladder, DFlash→MTP top rung 24 seqs/I8, and late-C dispatch.

### MEDIUM-05 — Optional payload absence can silently downgrade DIRECT (CONFIRMED designed behavior)
- `e29_extras()` turns DIRECT off on module absence or SHA mismatch while allowing Duck C to proceed. This preserves submission but invalidates evaluation of DIRECT.
- **Fix/test**: for an explicit DIRECT experimental run, require `E29_DIRECT_RT.state == 'ON'` and `E29D_SCHED_REC.ok` as a report/experiment-validity gate (do not necessarily abort production). Validate exact dataset version SHA at startup; verify `attempt_2` from DIRECT is actually selected.

## Corrected GO gates
1. SHA manifest, notebook, payload and Merlin patch-tree checks pass; rev2c exact-SHA kits pass.
2. Explicit late-C routing test passes. All scheduled C items must either execute DIRECT with `admitted>0` or retain the original Duck C path; no `C done` when the only intended request never got admitted.
3. Four-rank QSA env read-back and PP1 first-prefill memory probe pass under 128/64 (if not, 64-MiB cap or reduced pin fallback).
4. DFlash zero-accept canary, 8k/40k/90k/116k long tests, no NaNs, teacher-forced parity, PP fence correctness, MTP fallback at top rung with I8 engagement.
5. Final `submission.json`: all task IDs, all test inputs, valid 0–9 grids and existing CELL0 fallback; inspect selected attempt_1 and attempt_2 separately.

## Explicitly NOT VERIFIED
Current GPU boot; QSA cap peak; 12-h memory/cgroup stability; actual 24-C resident streams; live Merlin patch apply/revert; exact dataset mounting; rev2c real kit; E29 production submission e2e. No additional source-based engine crash blocker established.
