# E29 DFLASH D3S rev2c — Independent risk audit (2026-11-02)

## Decision: NO-GO for a blind 6-hour production EVAL / 12-hour submission rerun; GO for a bounded GPU smoke

This is a risk gate, not a claim that a new crash was reproduced. No independent **confirmed runtime blocker** was reproduced from the supplied source alone. E28 MTP is the proven fallback, but the new DFlash + QSA + DIRECT integrated run has no successful GPU evidence in this pack. A short real GPU smoke must precede irreversible submission. If time does not permit that smoke, use E28 K100 rather than declaring E29 GPU-verified.

## Evidence and reproducibility

- SHA-256 + byte lengths: 47/47 entries in `00_MANIFEST_SHA256.json` matched files in the supplied zip; production notebook `ed2e23a72c7fcbb9a15a9758544d499e59c5b528681387cad4bc23a4710d871c`, 396,772 bytes.
- Source modules `e29_lib.py`, `e29_nbx.py`, `e29_direct.py`, `e29d_sched_patch.py`, `e29_live.py`, and builder compile without syntax errors.
- Direct test invocation `python e29d_direct_tests.py` failed before tests because dependency `e28_sched_patch.py` is **not in this audit zip** (`e29_sched_tests.py:40`). Existing 12/12, 33/33, 44/44 are supplied local-result claims; not independently reproduced here.
- Included rev2b Kaggle kit logs are evidence of a *superseded* MTP fallback flaw, not evidence of rev2c Kaggle success.

## Ranked findings

| ID | Severity | Status | Evidence | Trigger -> impact | Exact mitigation and validation |
|---|---|---|---|---|---|
| R1 | HIGH | CONFIRMED missing gate; PLAUSIBLE OOM | `e29_dflash_d3s_code_export.py:3925-3952`, `e29_lib.py:291-300`, `FIXLIST__DFLASH2_PP1_OOM.md` | Warm-up gate verifies request failure / empty stream but does not force a maximal 116k/131k QSA prefill, nor minimum PP1 free headroom. New QSA 128/64 is not GPU verified. An ordinary warm-up may pass and later long DIRECT requests OOM / preempt. | First smoke: run first-request 131k near 24-active mixed workload and collect per-PP-rank memory (`torch.cuda.mem_get_info` inside worker); reject if allocation fails, or choose a conservative pin if free dips below empirically chosen margin. Try 256/256+EMBED_HOST as the controlled known-working baseline. Add a full first-prefill canary before phases, route OOM into the D rung ladder. |
| R2 | HIGH | CONFIRMED architecture; PLAUSIBLE throughput/quality regression | `e29_dflash_d3s_code_export.py:49`, `e29d_sched_patch.py:52-94`, `e29_direct.py:56,498-535`, `00_GPT_PROMPT.md` | Every phase-C task changes from Duck's REPL to one up-to-104k-token DIRECT solve at T=1.0, with 24 workers sharing the KV pool. At E28 pace, A consumed ~76% of run, leaving limited C window. High-concurrency contexts may preempt each other and reduce effective solved tasks, even when server remains healthy. | Run matched task-set, fixed-time E28 vs E29, track `C` admitted/finished/valid distinct attempts, total task-normalized scores, TTFT, KV/preemptions, decode tok/s and unsolved A queue. Keep DIRECT behind switch and turn it OFF if useful-attempt throughput falls below baseline. |
| R3 | HIGH | CONFIRMED missing verification; PLAUSIBLE bad relaunch | `e29_dflash_d3s_code_export.py:2286-2294,2305-2325,3778-3821` | In-run DFlash->MTP changes active boot state and INT8 requested env, but relaunch only `sampled_check`; does not call `e28_i8_gate`/`i8_readback` or validate capture/method map end-to-end as a new boot. MTP fallback could silently use BF16 head or incomplete configuration after an OOM, with different throughput. | After relaunch, perform config and I8 read-back from *new* server log; if not engaged, drop I8 explicitly and restart BF16, or fail closed to the known E28 boot. Test injected in-run OOM on each rung and zero-accept, assert new argv, env, pin 7,933,526,016, 24 seqs, absence of all DFlash/QSA vars, I8_ENGAGED or explicit BF16 fallback. |
| R4 | MEDIUM | CONFIRMED | `e29_lib.py:291-300`, `e29_dflash_d3s_code_export.py:2297-2303,3930` | QSA read-back is record-only, not a gate. An env propagation discrepancy silently leaves possibly different workspace geometry; the statement “mismatch means defaults” isn't necessarily established by read-back. | During GPU smoke assert all four worker env rows match `128/64` and check actual effective QSA initialization/log or instrumentation. On mismatch switch to verified 256/256 + host embedding; do not treat a record-only assertion as proof. |
| R5 | MEDIUM | CONFIRMED handling; PLAUSIBLE user-visible loss | `e29_dflash_d3s_code_export.py:2328-2342`, README rev2c payload description | Missing/outdated payload `e29_nbx.py` disables DIRECT *and* LIVE silently; DFlash seam issues can instead trigger MTP. The run can produce a formally valid submission with a different algorithm than requested. | Before expensive EVAL, enforce `E29_DIRECT_RT.state == ON` if DIRECT is required, seam readback ENGAGED, and payload SHA pins; allow explicit manual override for fallback only. Test wrong version and missing module deliberately; assert report marks final effective algorithm. |
| R6 | MEDIUM | PLAUSIBLE | `e29_dflash_d3s_code_export.py:2214-2225`, `FIXLIST__DFLASH2_PP1_OOM.md` | EMBED_HOST improves PP1 VRAM but raises host memory near reported cgroup limit; 12-hour long-run memory peaks are not measured. | Log `memory.current/max` at ready, after max prefill and every 15 minutes. Gate only on measured approaching-limit margin; use E28 MTP fallback on genuine host OOM. |
| R7 | MEDIUM | CONFIRMED | Notebook size 396,772 bytes vs stated 400,000 limit; `e29_dflash_d3s_code_export.py:49-50` | Only 3,228 bytes slack. Regenerating or embedding more code could exceed packaging limit. | Assert notebook byte length on each rebuild, and compare SHA with pushed copy before committing. |
| R8 | LOW | CONFIRMED limitation | `e29d_direct_tests.py:32`, `e29_sched_tests.py:40` | This flattened audit pack alone is not fully runnable; missing E28 scheduler dependency prevents reproducing claimed DIRECT tests. | Include `e28_sched_patch.py` and any E28 parent dependencies in next self-contained audit pack; run tests in fresh env. |

## Minimal GPU smoke pass conditions

1. Verify payload SHAs and QSA 128/64 effective across four workers; DFlash GRD + method map ENGAGED; host embedding detected.
2. Force first-131k-prefill and mixed 8k/40k/90k/116k contexts at up to 24 active slots, observe worker free-memory nadir, no OOM, no XID, no runaway preemptions. Account for time and KV throughput impact.
3. Run at least one real C-DIRECT phase: verify STOP_IDS, one/multi-test mapping, `attempt_1` unchanged and `attempt_2` valid/different, bounded early errors and honest no-record handling.
4. Inject warm-up failure, in-run OOM, XID and zero-accept independently. Confirm one rung progression / top-MTP restore and I8 read-back after relaunch. Confirm `submission.json` shape after an interruption.
5. Compare task-normalized score and solved tasks per minute against E28 over a matched task set / time budget. No score improvement claim without evidence.

## Cannot verify

Actual Kaggle GPU boot/runtime, effective QSA backing bytes, 24-stream KV/preemption, cgroup headroom, Kaggle payload current version, new rev2c real kit logs, or final production writer behaviour under a real crash. The zip has no new rev2c GPU/EVAL logs. GPU proof in the pack comes from the earlier NB-S1 DFlash windows, not the integrated E29 configuration.

## Scope of decision

**GO**: run bounded smoke on real Kaggle L4x4 with capture logs, only then run longer EVAL if tests pass. **NO-GO**: commit a production rerun based solely on this zip. If no smoke budget, prefer the previously demonstrated E28 K100 65.0% task-normalized baseline rather than claiming E29 is safe.
