"""Offline smoke of arc2_duck.Arc2ToolAgent tool path (no server). All code below is our own scripted code."""
import json
import os
import sys
import tempfile
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")
_HERE = Path(__file__).resolve().parent
# audit-zip layout (harness/ next to duck_arc2/) or the local workspace
E12 = (_HERE.parent / "duck_arc2") if (_HERE.parent / "duck_arc2").is_dir() else \
    Path(r"D:/ARC AGI 2/experiments/Experiment 12 - Duck REPL agent for ARC-AGI-2 (planned)/duck_arc2")
sys.path[:0] = [str(E12), str(E12 / "vendor")]
import arc2_duck as A  # noqa: E402
import re  # noqa: E402
import subprocess  # noqa: E402
import time  # noqa: E402

# Windows-only test shim: Duck passes its 65 KB bootstrap as `-c` (fine on Linux, MAX_ARG_STRLEN 128 KiB;
# Windows caps a command line at 32,767 chars). Write it to a file instead. Vendored code is untouched.
if os.name == "nt":
    _real_popen = subprocess.Popen
    _SHIM_DIR = Path(tempfile.gettempdir()) / "e12_smoke_bootstrap"
    _SHIM_DIR.mkdir(exist_ok=True)

    class _PopenShim(_real_popen):
        def __init__(self, args, *a, **kw):
            if isinstance(args, list) and len(args) >= 5 and args[1:4] == ["-I", "-S", "-c"]:
                f = _SHIM_DIR / "sandbox_bootstrap.py"
                if not f.exists() or f.read_text(encoding="utf-8") != args[4]:
                    f.write_text(args[4], encoding="utf-8")
                args = [args[0], "-I", "-S", str(f)] + args[5:]
            super().__init__(args, *a, **kw)
    subprocess.Popen = _PopenShim
    if not hasattr(os, "killpg"):          # Duck kills a timed-out child's process group (Linux); Windows: kill it
        import signal as _signal
        os.killpg = lambda pid, sig: os.kill(pid, 9)
        if not hasattr(_signal, "SIGKILL"):
            _signal.SIGKILL = 9

os.environ.update(A.duck_env("http://127.0.0.1:9/v1", "qwen", 12))
TA, DP, _, write_runtime_state = A._import_duck()
LIMIT = A.install_sandbox_memory_limit(4096)       # no-op with a note on Windows (no resource module)
Agent = A.make_agent_class()

flip = lambda g: [list(reversed(r)) for r in g]
task = {"train": [{"input": g, "output": flip(g)} for g in ([[1, 2, 3], [4, 5, 6]], [[7, 0], [0, 8], [9, 9]])],
        "test": [{"input": [[3, 1], [2, 2]]}, {"input": [[5, 6, 7]]}]}

(_HERE / "runs").mkdir(exist_ok=True)
tmp = Path(tempfile.mkdtemp(prefix="e12smoke_", dir=str(_HERE / "runs")))
state = tmp / TA.RUNTIME_STATE_FILENAME
write_runtime_state(state, current_frame=None, history=[])
ag = Agent(task=task, task_id="flip", branch=0, model="qwen", base_url="http://127.0.0.1:9/v1", provider="vllm")
ok = True


def run(code):
    r = ag._run_python_tool(state, {"code": code})
    return r, json.loads(r.content) if r.content.strip().startswith("{") else r.content


def expect(name, cond, info=""):
    global ok
    print(("PASS " if cond else "FAIL ") + name + ("" if cond else f"  -> {info}"))
    ok &= bool(cond)


# 1 system prompt carries the task, no game words
sp = ag._system_prompt
expect("system prompt has task", "Training pair 2 output:" in sp and "Test input 2:" in sp)
bad = [w for w in (r"current_frame", r"action\(actions\)", r"(?<!top-)\blevel\b", r"\bgame", r"segmentation", r"RESET")
       if re.search(w, sp)]
expect("no game words in system prompt", not bad, bad)
expect("tool description replaced", ag._tools(state)[0]["function"]["description"] == A.ARC2_TOOL_DESCRIPTION)

# 2 globals + check, retention of a top-level def
r, p = run("print(len(train), len(test_inputs))\ndef transform(g):\n    return [list(reversed(r)) for r in g]\nres = check(transform)")
expect("globals visible", "2 2" in p.get("stdout", ""), p)
expect("check prints 2/2", "check: 2 / 2" in p.get("stdout", ""), p)
expect("check result not echoed", "'pair'" not in p.get("stdout", ""), p)
expect("retention wording", "on this task." in p.get("function_retention", "") and "game" not in p.get("function_retention", ""), p)
expect("retention prompt honest", "the provided `check`" not in sp and "(not the provided globals)" in sp)
expect("transform retained", "transform" in ag._kept_functions, list(ag._kept_functions))
expect("prelude helpers not retained", not (set(ag._kept_functions) & A.PRELUDE_NAMES), list(ag._kept_functions))
expect("no submit -> not a step", not r.step_executed)

# 3 wrong function, then submit -> rejected with pairs listed
r, p = run("def wrong(g):\n    return g\nsubmit(wrong)")
expect("wrong submit is a step", r.step_executed and not r.made_progress, p)
expect("wrong summary", "wrong on training pair(s) [0, 1]" in str(p.get("submission")), p)
expect("submit reply not echoed", "'executed'" not in p.get("stdout", ""), p)
r, p = run("def wrong3(g):\n    return g\nres = check(wrong3, verbose=False)\nprint(sum(x['ok'] for x in res), len(res))")
expect("check verbose=False returns list", p.get("stdout", "").strip() == "0 2", p)

# 4 function reading `train` directly is not retained -> submit refused
r, p = run("def cheat(g):\n    for q in train:\n        if q['input'] == g:\n            return q['output']\n    return g\nsubmit(cheat)")
expect("cheat not accepted", r.step_executed and not r.made_progress and "not retained" in str(p.get("submission")), p)

# 5 numpy refused, line numbers relative to the model code
r, p = run("x = 1\nimport numpy")
expect("numpy refused", "not allowed" in p.get("error", ""), p)
expect("line number rebased", 'line 2' in p.get("error", ""), p)

# 6 lambda refused
r, p = run("submit(lambda g: g)")
expect("lambda refused", "def" in p.get("error", "") and not r.step_executed, p)

# 7 submit the retained transform in a later call -> accepted, host test outputs
r, p = run("submit(transform)")
expect("accepted", r.step_executed and r.made_progress and ag.arc2_accepted is not None, p)
expect("test outputs", ag.arc2_accepted and ag.arc2_accepted["test_outputs"] == [flip(t["input"]) for t in task["test"]],
       ag.arc2_accepted)

# 8 forged self-reports (GPT audit rev 2): none may be accepted; per-grid host verification
ag2 = Agent(task=task, task_id="flip", branch=1, model="qwen", base_url="http://127.0.0.1:9/v1", provider="vllm")
st2 = tmp / "b1" / TA.RUNTIME_STATE_FILENAME
write_runtime_state(st2, current_frame=None, history=[])
OLD_MARKER = "__ARC2_VERIFY__"
forged = json.dumps({"train": [p["output"] for p in task["train"]], "test": [[[9, 9]], [[9]]]}, separators=(",", ":"))
attacks = {
    "forged marker printed by the snippet": "def t2(g):\n    return g\nprint('" + OLD_MARKER + forged + "')\nsubmit(t2)",
    "monkeypatched print (the rev-1 exploit)":
        "def t3(g):\n    b = __builtins__\n    real = b['print']\n    def fake(*a, **k):\n"
        "        real('" + OLD_MARKER + forged + "')\n    b['print'] = fake\n    return g\nsubmit(t3)",
    "result global forged inside the function":
        "def t4(g):\n    b = __builtins__\n    return g\nresult = " + forged + "\nsubmit(t4)",
    "print silenced (accidental)": "def t5(g):\n    __builtins__['print'] = lambda *a, **k: None\n    return g\nsubmit(t5)",
    "returns a non-grid": "def t6(g):\n    return 'grid'\nsubmit(t6)",
    "raises": "def t7(g):\n    raise ValueError('boom')\nsubmit(t7)",
}
for label, code in attacks.items():
    r = ag2._run_python_tool(st2, {"code": code})
    v = ag2.arc2_submissions[-1]
    expect(f"spoof rejected: {label}", not r.made_progress and not v["accepted"] and ag2.arc2_accepted is None,
           (v["summary"], v["train_exact"]))
expect("raise -> first error shown to the model", "boom" in ag2.arc2_submissions[-1]["summary"], ag2.arc2_submissions[-1])
# verification code holds one input grid only: no train outputs, no other grids, no marker
vc = A._grid_call_code("t", task["train"][0]["input"])
expect("verification code carries no task outputs or other grids",
       json.dumps(task["train"][0]["output"], separators=(",", ":")) not in vc and "train" not in vc
       and json.dumps(task["train"][1]["input"], separators=(",", ":")) not in vc and "print" not in vc, vc)
# slow function: verification stops after the first timeout instead of 30 s per grid
t0 = time.monotonic()
r = ag2._run_python_tool(st2, {"code": "def t9(g):\n    while True:\n        pass\nsubmit(t9)"})
el = time.monotonic() - t0
expect("slow function: rejected, verification bounded (<= 2 sandbox timeouts)", not ag2.arc2_submissions[-1]["accepted"]
       and el < 2 * 30 + 15, round(el, 1))
# a correct function in branch 2 passes the per-grid verifier, incl. tuples
r = ag2._run_python_tool(st2, {"code": "def t10(g):\n    return tuple(tuple(reversed(r)) for r in g)\nsubmit(t10)"})
expect("per-grid verifier accepts a correct (tuple-returning) function", r.made_progress and
       ag2.arc2_accepted["test_outputs"] == [flip(q["input"]) for q in task["test"]], ag2.arc2_submissions[-1])
ag2.arc2_accepted = None
ag2.arc2_submissions = [s for s in ag2.arc2_submissions if not s["accepted"]]
# HTTP cold-start grace disabled (rev 2)
expect("first-request 900 s grace disabled", ag._http_initial_grace_used is True)
# memory limit: Linux only (resource.prlimit); on Windows the installer reports why it is off
if os.name == "nt":
    expect("memory limit reported unavailable on Windows", LIMIT["applied"] == 0 and "not available" in LIMIT["last_error"], LIMIT)
else:
    expect("memory limit applied with read-back", LIMIT["applied"] > 0 and LIMIT["readback_ok"] is True, LIMIT)
    r, p = run("x = bytearray(5 * 1024 ** 3)\nprint(len(x))")
    expect("5 GiB allocation fails inside the sandbox", "MemoryError" in p.get("error", ""), p)
    r, p = run("x = bytearray(128 * 1024 ** 2)\nprint(len(x))")
    expect("128 MiB allocation works, next call fine", p.get("stdout", "").strip() == str(128 * 1024 ** 2), p)

# 9 nudge rewrite keeps Duck prefix, drops the game tail
msgs = []
nudge = TA._mark_control_message({"role": "user", "content": "Your reply had no tool call. Then investigate and revise your working world model of the level ... action(actions) ..."}, "nudge")
ag._append_context_message(msgs, nudge)
c = msgs[-1]["content"]
expect("nudge rewritten", c.startswith("Your reply had no tool call. ") and "world model" not in c and "check(transform)" in c, c)

# 10 resume opener is a continuation
ag._resume_after_yield = True
op = ag._build_user_prompt(0, valid_actions=[])
expect("resume opener continues", "continue from them" in op and "Start" not in op, op)
ag._resume_after_yield = False

# 11 selection: accepted beats partial; attempt_2 distinct
sel = A.select_attempts(task, [{"submissions": ag.arc2_submissions}, {"submissions": ag2.arc2_submissions}])
expect("selection attempt_1", sel[0]["attempt_1"] == flip(task["test"][0]["input"]), sel)
expect("selection attempt_2 distinct", sel[0]["attempt_2"] != sel[0]["attempt_1"], sel)
# rev 2: no mirror guess; with nothing else, attempt_2 = the test input
sel0 = A.select_attempts(task, [])
expect("fallback = test input in both attempts (no mirror)", all(a["attempt_1"] == q["input"] and a["attempt_2"] == q["input"]
                                                                 for a, q in zip(sel0, task["test"])), sel0)
symq = {"train": task["train"], "test": [{"input": [[1, 1], [2, 2]]}]}   # flip(input) == input
sel1 = A.select_attempts(symq, [{"submissions": [{"accepted": True, "test_outputs": [[[1, 1], [2, 2]]], "t": 1}]}])
expect("accepted grid == test input -> attempt_2 repeats it (no invented grid)",
       sel1[0]["attempt_1"] == [[1, 1], [2, 2]] and sel1[0]["attempt_2"] == [[1, 1], [2, 2]], sel1)
# 12 rev 4 audit: E12_DUCK_REQUEST_TIMEOUT reaches run_branch (EVAL6 1,800 s); unset -> run_branch default 900 s
import inspect as _insp
_seen = []
_rb, _pg = A.run_branch, TA._priority_gate
A.run_branch = lambda *a, **k: (_seen.append(k), {"task_id": k["task_id"], "branch": k["branch"], "accepted": False, "submissions": []})[1]
TA._priority_gate = lambda: None
try:
    os.environ["E12_DUCK_REQUEST_TIMEOUT"] = "1800"
    A.solve_all({"t1": task}, ["t1"], out_dir=Path("."), deadline=time.monotonic() + 60, base_url="x", model_id="m", live_branches=6)
    expect("timeout 1800 passed to both branches", len(_seen) == 2 and all(k.get("analyzer_timeout") == 1800.0 for k in _seen), _seen)
    _seen.clear(); del os.environ["E12_DUCK_REQUEST_TIMEOUT"]
    A.solve_all({"t1": task}, ["t1"], out_dir=Path("."), deadline=time.monotonic() + 60, base_url="x", model_id="m")
    expect("unset -> no override; run_branch default stays 900", len(_seen) == 2 and all("analyzer_timeout" not in k for k in _seen)
           and _insp.signature(_rb).parameters["analyzer_timeout"].default == 900.0, _seen)
finally:
    A.run_branch, TA._priority_gate = _rb, _pg
print("ALL OK" if ok else "SOME FAILED")
