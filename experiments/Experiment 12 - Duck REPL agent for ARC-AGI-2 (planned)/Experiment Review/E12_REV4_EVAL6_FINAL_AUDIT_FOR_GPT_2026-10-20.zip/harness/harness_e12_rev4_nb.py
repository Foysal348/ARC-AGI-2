"""CPU harness for the E12 notebook: runs the REAL notebook cells (mode/fallback, config, install branch with
Q27X_SKIP_INSTALL, tokenizer + E11 tokenizer check, Duck package + sandbox self-test, tasks, SGLang engine cell with launch /
caps / smoke against fake_sgl_duck_server.py, the Duck solver, the report). Scripted model replies only.
usage: python harness_e12_nb.py <notebook> <scenario>      scenarios: smoke | rerun | launchfail | thinkmarkup | modelsfail (the last two: vLLM notebooks)"""
import json
import os
import shutil
import socket
import subprocess
import sys
import time
import urllib.request
import zipfile
from pathlib import Path

NB, SCEN = sys.argv[1], sys.argv[2]
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / "fixtures"))
import e12_fixtures as B  # noqa: E402  (self-contained fixtures next to this file)

sys.stdout.reconfigure(encoding="utf-8")
if os.name == "nt":   # Windows-only test shim (Duck passes a 65 KB bootstrap as -c; Linux allows it)
    _real = subprocess.Popen
    _bdir = HERE / "runs" / "_bootstrap"
    _bdir.mkdir(parents=True, exist_ok=True)

    class _Shim(_real):
        def __init__(self, args, *a, **kw):
            if isinstance(args, list) and len(args) >= 5 and args[1:4] == ["-I", "-S", "-c"]:
                f = _bdir / "sandbox_bootstrap.py"
                if not f.exists() or f.read_text(encoding="utf-8") != args[4]:
                    f.write_text(args[4], encoding="utf-8")
                args = [args[0], "-I", "-S", str(f)] + args[5:]
            super().__init__(args, *a, **kw)
    subprocess.Popen = _Shim
    if not hasattr(os, "killpg"):      # Duck kills a timed-out child's process group (Linux only)
        import signal as _sig
        os.killpg = lambda pid, sig: os.kill(pid, 9)
        if not hasattr(_sig, "SIGKILL"):
            _sig.SIGKILL = 9

ROOT = HERE / "nbwork"
ROOT.mkdir(exist_ok=True)
WORK = ROOT / f"{SCEN}_{time.strftime('%H%M%S')}"
WORK.mkdir()
ch, sol, multi, single = B.load()
PICK = ["2ba387bc"] + multi[:2] + single[:2]
FP8 = B.TOKDIR_FP8
assert (FP8 / "config.json").exists(), FP8
DFL = ROOT / "dflash"; DFL.mkdir(exist_ok=True)
json.dump({"architectures": ["DFlash2DraftModel"]}, open(DFL / "config.json", "w"))
WH = ROOT / "wheelhouse"; WH.mkdir(exist_ok=True)
json.dump({"sglang": "0.5.21"}, open(WH / "BUILD_INFO.json", "w"))
(WH / "requirements.lock").write_text("", encoding="utf-8"); (WH / "SHA256SUMS").write_text("", encoding="utf-8")
ARC = WORK / "arc"; ARC.mkdir()
shutil.copy(B.DATA / "arc-agi_evaluation_challenges.json", ARC / "arc-agi_evaluation_challenges.json")
shutil.copy(B.DATA / "arc-agi_evaluation_solutions.json", ARC / "arc-agi_evaluation_solutions.json")
json.dump({t: {"train": ch[t]["train"], "test": [{"input": q["input"]} for q in ch[t]["test"]]} for t in PICK},
          open(ARC / "arc-agi_test_challenges.json", "w"))
with socket.socket() as s:
    s.bind(("127.0.0.1", 0)); PORT = s.getsockname()[1]
os.environ.update(Q27X_ARC_ROOT=str(ARC), Q27X_WORKING=str(WORK), Q27X_MODEL=str(FP8), Q27X_SKIP_INSTALL="1",
                  PYTHONIOENCODING="utf-8", E11_HARNESS="1", E11_PORT=str(PORT),
                  E11_FAKE_SERVER=str(HERE / "fake_sgl_duck_server.py"), E11_INT4=str(B.TOKDIR_INT4), E11_DFLASH=str(DFL),
                  E11_SGL_WHEELHOUSE=str(WH), FAKE_SCEN=SCEN, E12_DIR=str(WORK / "e12_duck"),
                  ARC3_HTTP_RETRY_BASE_SECONDS="0.05", ARC3_HTTP_RETRY_MAX_SECONDS="0.1",
                  E12_VLLM_PORT=str(PORT), E12_FAKE_VLLM_SERVER=str(HERE / "fake_vllm_duck_server.py"))
if SCEN == "rerun":
    os.environ["KAGGLE_IS_COMPETITION_RERUN"] = "true"
if SCEN == "eval6":     # rev 4: tiny per-branch cap so the fake run ends by cap (role-1 branches never submit)
    os.environ["E12_MAX_GEN"] = "2000"
SMOKELIKE = ("smoke", "thinkmarkup", "modelsfail")   # SMOKE1 profile; the fake server varies its behaviour

nb = json.load(open(NB, encoding="utf-8"))
code = ["".join(c["source"]) for c in nb["cells"] if c["cell_type"] == "code"]
VLLM = "CELL 5 — engine: vLLM 0.19 OpenAI server (E12-V)" in code[5]   # E12-V notebook (same Duck, vLLM engine)
assert len(code) == 8 and "CELL 3 — E12: Duck package" in code[3] and ("CELL 5 — engine: SGLang" in code[5] or VLLM), len(code)
G = {"__name__": "__main__"}
t0 = time.time()
for i in (0, 1):
    exec(compile(code[i], f"<cell{i}>", "exec"), G)
G["E12_SOLVE_WINDOW_SEC"] = (90 if SCEN == "eval6" else 25) if SCEN != "rerun" else None
for i in (2, 3, 4, 5):
    exec(compile(code[i], f"<cell{i}>", "exec"), G)
if SCEN == "rerun":
    G["HARD_STOP"] = time.perf_counter() + 25 + G["E12_STOP_BEFORE_HARD_SEC"]
exec(compile(code[6], "<cell6>", "exec"), G)
# read the fake server's request log NOW: CELL 7 stops the server at its end (before rev 3 every flog check was skipped)
FLOG = None
try:
    if G.get("E11_SERVER") is not None and G["E11_SERVER"].alive():
        FLOG = json.loads(urllib.request.urlopen(f"http://127.0.0.1:{PORT}/fake_log", timeout=10).read())
except Exception as _e:
    print("fake_log read failed:", repr(_e))
exec(compile(code[7], "<cell7>", "exec"), G)

checks = []


def check(label, cond, info=""):
    checks.append((label, bool(cond), "" if cond else str(info)[:800]))


rep = json.load(open(WORK / "q27x" / "e12_run_report.json", encoding="utf-8"))
sub = json.load(open(WORK / "submission.json", encoding="utf-8"))
test = json.load(open(ARC / "arc-agi_test_challenges.json", encoding="utf-8"))
check("submission schema = every test task, every test input",
      set(sub) == set(test) and all(len(sub[t]) == len(test[t]["test"]) for t in test), list(sub))
check("sandbox self-test ok", G["E10_SANDBOX_SELFTEST"].get("ok"), G["E10_SANDBOX_SELFTEST"])
_mem = G["E10_SANDBOX_SELFTEST"].get("memory_limit") or {}
if os.name == "nt":
    check("memory-limit evidence reported (Windows: unavailable, run continues)",
          "not available" in str(_mem.get("limit", {}).get("last_error")) and _mem.get("ok") is False, _mem)
else:
    check("memory limit verified (read-back, 5 GiB rejected, 128 MiB ok)", _mem.get("ok") is True, _mem)
check("HTTP cold-start grace disabled in the notebook's agents", "_http_initial_grace_used = True" in
      (Path(G["E12_DIR"]) / "arc2_duck.py").read_text(encoding="utf-8"), "")
if SCEN == "launchfail":
    check("engine not ready -> Duck not run", not G["ENGINE_READY"] and "not run" in str(rep["e12_run"]["error"]), rep["e12_run"])
    check("fallback submission = identity", all(a["attempt_1"] == q["input"] for t in test for a, q in zip(sub[t], test[t]["test"])), "")
else:
    flog = FLOG
    check("harness: fake server request log captured before CELL 7 stops the server", flog is not None, "")
    check("engine ready with concurrency 12", G["ENGINE_READY"] and G["CONCURRENCY"] == 12, G["ENGINE_INFO"])
    if VLLM:
        vi = G["ENGINE_INFO"]["vllm"]
        check("E12-V rev 2: cold smoke reply without prompt_tokens_details is accepted (vLLM 0.19, issue 44377)",
              vi["smoke"]["ok"] and vi["smoke"]["cache_details_present"] is False, vi.get("smoke"))
        check("E12-V: KV + concurrency parsed from the vLLM log (SIMULATED values, parser test only)",
              vi.get("kv_tokens_logged") == 337600 and vi.get("max_concurrency_logged", {}).get("x") == 7.66, vi)
        ua = rep["usage_all"]
        check("E12-V rev 2: cache report keeps 'not reported' apart (coverage < 1, reported-only rate present)",
              ua.get("cache_detail_coverage") is not None and ua["cache_detail_coverage"] < 1
              and ua.get("cached_pct_reported_only") is not None, ua)
        check("E12-V: history key = reasoning", G["os"].environ.get("ARC3_REASONING_HISTORY_KEY") == "reasoning", "")
        check("model id from /v1/models", rep["e12_run"]["model_id"] == "Qwen/Qwen3.8-27B-FP8", rep["e12_run"])
        ds = rep.get("e11", {}).get("decode_summary") or {}
        check("E12-V: engine stats summarised from the vLLM log", ds.get("n_lines", 0) > 0 and
              ds.get("prefix_cache_hit_pct_last") == 88.0, ds)
    else:
        check("e11 smoke passed (generate + abort)", G["E11_SGL"]["smoke"]["ok"], G["E11_SGL"]["smoke"])
        check("model id from /v1/models", rep["e12_run"]["model_id"] == "fake-int4", rep["e12_run"])
    check("no solver error", not rep["e12_run"]["error"], rep["e12_run"]["error"])
    n_br = len(G["TASK_IDS"]) * G["E12_BRANCHES"]
    check(f"all {n_br} branches finished", rep["e12_run"]["branches_done"] == n_br, rep["e12_run"])
    check("one accepted branch per task", rep["e12_run"]["branches_accepted"] == len(G["TASK_IDS"]), rep["e12_run"])
    check("usage recorded with cached_tokens", rep["usage_all"]["requests"] > 0 and rep["usage_all"]["cached_tokens"] > 0,
          rep["usage_all"])
    if SCEN == "eval6":
        T6 = ["136b0064", "898e7135", "135a2760", "b5ca7ac4", "4c3d4a41", "62593bfd"]
        check("rev 4: profile EVAL6 = the 6 tasks", G["PROFILE"] == "EVAL6" and sorted(G["TASK_IDS"]) == sorted(T6), G["TASK_IDS"])
        check("rev 4 (audit): live 6 / streams 6 / 60k output / timeout 1,800 / cap 2000 (harness)",
              (G["E12_LIVE_BRANCHES"], G["E12_STREAMS"], G["E12_DUCK_MAX_OUTPUT"],
               G["E12_DUCK_REQUEST_TIMEOUT"], G["E12_MAX_GEN_PER_BRANCH"]) == (6, 6, 60000, 1800, 2000), "")
        check("rev 4 (audit): Duck env keeps the milestone window 131,072 and carries output 60,000 (read by Duck at import)",
              G["os"].environ.get("LOCAL_ANALYZER_CONTEXT_WINDOW") == "131072" and G["os"].environ.get("LOCAL_ANALYZER_MAX_OUTPUT") == "60000",
              (G["os"].environ.get("LOCAL_ANALYZER_CONTEXT_WINDOW"), G["os"].environ.get("LOCAL_ANALYZER_MAX_OUTPUT")))
        if flog:
            mt = sorted({c.get("max_tokens") for c in flog["chat"] if c.get("tools", True)})
            check("rev 4: every Duck request asks max_tokens 60000", mt == [60000], mt)
            check("rev 4: at most 6 requests in flight (live branches)", flog.get("max_inflight", 99) <= 6, flog.get("max_inflight"))
            first6 = [t for t, _, _ in flog["new_convs"][:6]]
            check("rev 4: the first 6 conversations = first 3 tasks x both branches (fair start)",
                  sorted(first6) == sorted(G["E12_ORDER"][:3] * 2), (first6, G["E12_ORDER"][:3]))
        check("rev 4: eval scored, every query hit (role-0 lookup)", rep.get("eval_query_hits") == rep.get("eval_query_total"),
              (rep.get("eval_query_hits"), rep.get("eval_query_total")))
    if SCEN in SMOKELIKE:
        check("profile SMOKE1 = 2ba387bc", G["PROFILE"] == "SMOKE1" and G["TASK_IDS"] == ["2ba387bc"], G["TASK_IDS"])
        check("eval scored: every query hit", rep.get("eval_query_hits") == rep.get("eval_query_total") and rep["eval_query_total"],
              (rep.get("eval_query_hits"), rep.get("eval_query_total")))
        check("task-norm 100 %", rep.get("eval_task_norm_pct") == 100.0, rep.get("eval_task_norm_pct"))
        check("evaluation keeps the test fallback in submission.json",
              all(a["attempt_1"] == q["input"] for t in test for a, q in zip(sub[t], test[t]["test"])), "")
    if SCEN == "rerun":
        check("rerun: TASK_IDS = test tasks", sorted(G["TASK_IDS"]) == sorted(test), G["TASK_IDS"])
        # rev 2 (GPT audits): concurrent submission writes are serialized; every intermediate file parses
        import threading as _th
        errs, bad_reads, stop = [], [0], _th.Event()

        def _w():
            for _ in range(20):
                try:
                    G["e12_write_submission"]()
                except Exception as e:
                    errs.append(f"{type(e).__name__}: {e}")

        def _r():
            while not stop.is_set():
                try:
                    json.loads((WORK / "submission.json").read_text(encoding="utf-8"))
                except (ValueError, OSError):
                    bad_reads[0] += 1
        # concurrent readers only on Linux: Windows refuses os.replace onto a file another handle has open
        rt = _th.Thread(target=_r if os.name != "nt" else (lambda: None)); rt.start()
        ws = [_th.Thread(target=_w) for _ in range(12)]
        [t.start() for t in ws]; [t.join() for t in ws]; stop.set(); rt.join()
        sub2 = json.load(open(WORK / "submission.json", encoding="utf-8"))
        leftovers = [p.name for p in WORK.iterdir() if p.name.endswith(".tmp")]
        check("12 concurrent writers x 20: no error, every read parses, same final content, no temp files",
              not errs and bad_reads[0] == 0 and sub2 == sub and not leftovers, (errs[:3], bad_reads[0], leftovers))
        hit = sum(a["attempt_1"] == sol[t][qi] for t in test for qi, a in enumerate(sub[t]))
        check("rerun: submission carries the solved grids", hit == sum(len(test[t]["test"]) for t in test), hit)
    if flog and SCEN == "thinkmarkup":   # vLLM issue 39056: XML only in `reasoning`; Duck recovers it
        check("E12-V: tool calls inside reasoning recovered by Duck (task solved)", flog.get("markup_replies", 0) > 0
              and rep["e12_run"]["branches_accepted"] == len(G["TASK_IDS"]), (flog.get("markup_replies"), rep["e12_run"]))
    if SCEN == "modelsfail":
        check("E12-V rev 2: /v1/models failing in CELL 6 -> model id falls back to the served name",
              rep["e12_run"]["model_id"] == "Qwen/Qwen3.8-27B-FP8" and rep["e12_run"]["branches_accepted"] == len(G["TASK_IDS"]), rep["e12_run"])
    if flog:
        c0 = [c for c in flog["chat"] if c.get("tools", True)][0]   # E12-V: skip the engine smoke request
        if VLLM:
            check("E12-V rev 3: every request names the served model (no 404)", not flog.get("model_404"),
                  flog.get("model_404", [])[:3])
        if VLLM:   # vLLM 0.19 reads prior reasoning only from `reasoning` (chat_utils.py:1512)
            hk = [k for k in flog["history_keys"] if k]
            check("E12-V: prior reasoning sent back under `reasoning` only", hk and all(k == ["reasoning"] for k in hk), hk[:5])
        check("chat request: preserve/enable thinking, 12288, 0.7/0.95/20, non-stream",
              (c0["chat_template_kwargs"] or {}).get("preserve_thinking") is True and c0["max_tokens"] == (60000 if SCEN == "eval6" else 12288)
              and (c0["temperature"], c0["top_p"], c0["top_k"]) == (0.7, 0.95, 20) and not c0.get("stream"), c0)
        roles = [r for _, r, _ in flog["new_convs"]]
        if n_br > G["E12_RUN"]["streams"] and not G.get("E12_LIVE_BRANCHES"):   # old order; rev 4 live pool = task-major (checked above)
            check("first branches start before any second branch", roles == sorted(roles), flog["new_convs"])
        else:                                 # every branch is admitted at once: first-request order is a thread race
            check(f"all {n_br} branches started (slots {G['E12_RUN']['streams']} >= branches)", len(roles) == n_br, flog["new_convs"])
        check("in-flight <= streams", flog["max_inflight"] <= 12, flog["max_inflight"])
    with zipfile.ZipFile(WORK / "Q27X_E12_DUCK_BUNDLE.zip") as z:
        names = z.namelist()
    trs = [n for n in names if n.endswith("transcript.txt")]
    check("bundle: report, submission, transcripts per branch, server log",
          {"e12_run_report.json", "submission.json"} <= set(names) and len(trs) == n_br
          and any(n.startswith("vllm_openai_server" if VLLM else "sglang_server_") for n in names), names[:20])
    with zipfile.ZipFile(WORK / "Q27X_E12_DUCK_BUNDLE.zip") as z:
        check("transcripts hold the thinking", all("THINK step" in z.read(n).decode("utf-8", "replace") for n in trs), "")
        reqs = [n for n in names if n.startswith("duck/") and n.endswith("requests.jsonl")]   # not E11's sglang_requests
        if SCEN in SMOKELIKE:   # rev 2: request snapshots for the smoke (exact messages sent, incl. replayed thinking)
            snap = [json.loads(l) for n in reqs for l in z.read(n).decode("utf-8").splitlines() if l.strip()]
            replay = any(any(m.get("role") == "assistant" and "THINK step" in str(m.get("reasoning" if VLLM else "reasoning_content") or "")
                             for m in (s.get("messages") or [])) for s in snap)
            check("smoke: request snapshots bundled, with replayed reasoning_content",
                  len(reqs) == n_br and replay, (reqs, len(snap)))
        else:
            check("rerun: request snapshots off by default", not reqs, reqs)
G["e11_kill_server"](wait=False)
bad = [c for c in checks if not c[1]]
print(f"\n[{SCEN}] {len(checks) - len(bad)}/{len(checks)} ok in {time.time() - t0:.0f} s")
for c in bad:
    print("   FAIL", c[0], "->", c[2])
print("@@NB_OK@@" if not bad else "@@NB_FAIL@@")
