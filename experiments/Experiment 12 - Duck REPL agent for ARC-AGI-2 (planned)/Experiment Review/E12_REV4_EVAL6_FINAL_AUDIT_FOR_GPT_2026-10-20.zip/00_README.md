# E12 rev 4 EVAL6 (Duck REPL agent, Qwen3.8-27B, 4xL4): final pre-run audit (2026-10-20)

## Ask

This is the **last audit before the GPU run**. Please check two things:
1. that the changes below are correct and complete;
2. that nothing taken or rejected is wrong.

Report **blockers and bugs only** (file:line), and separate *certain* from *possible*. Do not propose new features, tests or plans: the user chose this small accuracy test.

The user's rule: ARC-AGI-2 is not ARC-AGI-3 (Duck's home), so change what this competition needs. Not so few changes that the test is worthless, not so many that it breaks.

## History

1. The previous zip (`audited_zip_versions/`, its request is `00_AUDIT_REQUEST_previous.md`) was reviewed by three GPT audits, full text in `gpt_audits/`:
   - **A**: NO-GO, fix the timeout;
   - **B**: NO-GO, timeout + hard cap + drain;
   - **C**: conditional GO, timeout only.
2. Each claim was checked in the vendored Duck source; see `E12 rev 4 EVAL6 - GPT audits validated (2026-10-20).md` (14 claims).

## What was TAKEN

| # | From | Change | Where |
|---|---|---|---|
| T1 | A, B, C | **Request read timeout 900 → 1,800 s, EVAL6 only.** Non-streaming (`openai_compat.py:52`), a ReadTimeout is not retried (`tool_agent.py:628`) and loses the in-flight reply (`:7106`); 6 x 60k at 368 tok/s = 978 s of decode alone. The audits said 1,500; 1,800 adds margin for slower long-context decode. `min(timeout, remaining)` still bounds it by the deadline | `duck_arc2/arc2_duck.py` `solve_all._one` (env `E12_DUCK_REQUEST_TIMEOUT`; unset = run_branch default 900); builder sets 1800 for EVAL6 |
| T2 | A, B, C (exposure risk) | **Solve window 60 → 90 min, total budget 100 → 125 min.** The soft cap gives 12 x ~120k = 1.44 M tokens = 65 min of decode + about 14 min of prefill; with 6 live there are 2 waves, and at 60 min the second wave (3 tasks) gets about half the time, so a 0-1 result would be ambiguous. The audits kept 60 min and asked only for exposure reporting; this is the one place we go further | builder `PROFILES["EVAL6"]` |
| T3 | A | Wording: 60,000 is a **ceiling** per request, not a minimum thinking | builder comments + notebook header |
| T4 | A, C | 1.2 M tokens is not reported as a ceiling; actual tokens per branch are reported | analysis plan (no code) |
| T5 | B | **Fully solved tasks** (all test inputs hit) from `eval_unit_records` drive the decision rule | analysis plan (no code) |
| T6 | A, C | **Exposure**: turns and tokens per branch; a branch that never ran = incomplete exposure, not model failure | analysis plan (no code) |
| T7 | A, C | Count timeouts (`request_timeout (yielding`), trims (prompt smaller than the previous) and `context_overflow_recovered` | analysis plan (no code) |
| T8 | A, B | The 6 tasks are selected, so the result is a targeted signal, not an unbiased accuracy | analysis plan |

## What was NOT taken (and why)

| # | From | Proposal | Why not |
|---|---|---|---|
| N1 | B | Clamp `max_tokens` to the remaining branch budget (second request 40k) | It cuts reasoning, the thing this test measures (EVAL30: 29/30 first requests cut at 12,288). A and C accept the soft cap; the deadline is the hard wall |
| N2 | B | `ARC3_CONTEXT_DRAIN_TOKENS` = 11,168 (trim target 59,392) | Duck's own rationale (`tool_agent.py:228-242`): a small drain trims nearly every turn, and each trim invalidates the whole prefix cache. Re-prefill was the main EVAL30 loss (9.6 M tokens). With 60k replies the block size dominates: the older reply is dropped at either target |
| N3 | (mine) | Duck window 154,624 with 5 live (applied after audits A/B, **now reverted**) | No audit asked for it. With 60k replies it keeps no extra reply (two 60k replies fit no budget under the 155,648 server context); it cost one live branch and left about 1k of margin to the server context. The hook was removed |
| N4 | B | A slow-request test (between 900 and 1,500 s) | A new test of 15+ min. A unit check instead proves that 1,800 reaches both branches and that unset keeps 900 |

## Unchanged from the audited zip

- Output per request: 60,000.
- Per-branch cap: 100k, soft.
- 6 live branches = 6 streams (6 x 131,072 = 786k ≤ KV 866,744 measured in EVAL30).
- Duck milestone context: 131,072, drain 58 Ki → input budget 70,560, trim target 35,280.
- Task-major order and the gate hold.
- The same 6 tasks (8 test inputs), 2 branches each.
- Vendored Duck: byte-identical.

## Checked by us, not covered by the three audits

- **Yield at 2,048 tokens** is checked only between requests (`tool_agent.py:6718-6731`), so a 60k request is never cut.
- **`ARC3_HTTP_RETRY_INITIAL_SECONDS` 900** is the cold-start connect grace, not a read timeout.
- **Rolling summaries** are off (`ARC3_SUMMARY_INTERVAL_TOKENS` unset).
- **SGLang abort on client disconnect** is not verifiable locally. Either way, the longer timeout is the safe side.

## Files

| Path | What |
|---|---|
| `notebook/Q27-XHIGH-E12_DUCK_REPL_SGLANG_EVAL6.ipynb` | **The notebook to run.** sha256 `53a66856f330aa07a9634059a4d9c0e1d54b6a19743d6ba35a1e411da0f44b74` |
| `duck_arc2/arc2_duck.py`, `duck_arc2/vendor_inference_agent/` | ARC-2 adapter (final) and vendored Duck (unchanged) |
| `build/build_e12_duck.py`, `build/push_e12_duck.py` | Builder (final), push script |
| `diffs/arc2_duck_audited_vs_final.diff` | Adapter: audited → final (T1 only) |
| `diffs/build_audited_vs_final.diff` | Builder: audited → final (T1-T3) |
| `diffs/EVAL6_audited_vs_final_notebook.diff` | Notebook cells: audited → final |
| `diffs/EVAL30_vs_EVAL6_final_notebook.diff` | Notebook cells: the Kaggle-run EVAL30 (`base/`) → final EVAL6 |
| `audited_zip_versions/` | The previously audited adapter, builder, notebook and request |
| `gpt_audits/GPT-A.txt`, `GPT-B.txt`, `GPT-C.txt` | The three audits, full text |
| `E12 rev 4 EVAL6 - GPT audits validated (2026-10-20).md` | Claim-by-claim validation |
| `harness/` | CPU harness (real notebook cells against `fake_sgl_duck_server.py`), unit checks, logs |
| `analysis/`, `reference/` | EVAL30 run analysis, simulator, Duck milestone settings |

## Local evidence (after the final changes)

- **EVAL6 harness: 25/25** (`harness/hrev4_eval6.txt`):
  - knobs live 6 / streams 6 / output 60,000 / timeout 1,800 (cap 2,000 in the harness only);
  - Duck env window 131,072;
  - at most 6 in flight;
  - first 6 conversations = first 3 tasks x both branches;
  - all branches finish; scoring and fallback work.
- **SMOKE1 regression** (knobs unset): 22/22.
- **Adapter unit checks: 41 OK**, including timeout 1,800 → both branches and unset → no override (default 900).
- **Check-only on the run account** (hosen42) passed with the sha above: account, 3 models, 2 datasets; quota 27.1 of 60 h used.
- **Not proven locally:** real 60k generations, real timeouts, real KV behaviour (a GPU-only question).

## Pre-run capacity check

| Item | Number |
|---|---|
| Branches | 6 tasks x 2 = 12; 6 live, 6 streams |
| KV | 6 x 131,072 = 786k ≤ 866,744 |
| Tokens | soft cap → about 1.44 M typical (≤ about 1.92 M worst) vs 90 min x 368 tok/s = 1.99 M minus prefill; the deadline is the wall |
| Time / quota | 125 min → about 4.2 h of quota (hosen42: about 32.9 h left) |

## Decision rule (fully solved tasks among exposed tasks)

| Result | Next step |
|---|---|
| 2-3 or more of 6 | Full rev 4 EVAL30 |
| 0-1 with full exposure | Back to the Poetiq line |
| 0-1 with poor exposure | Inconclusive (state why) |
