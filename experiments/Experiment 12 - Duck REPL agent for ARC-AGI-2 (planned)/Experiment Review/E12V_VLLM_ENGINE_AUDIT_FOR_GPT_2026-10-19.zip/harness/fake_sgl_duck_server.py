"""Fake SGLang 0.5.21 server for the E12 notebook harness (CPU, no model). Launched by the REAL engine cell with the REAL
flags. Serves what the E11 engine cell needs (launch log with the capacity lines, /health, /metrics, /generate for the
two smoke requests, /abort_request) plus what Duck needs (/v1/models, /v1/chat/completions, non-stream, OpenAI tool
calls, reasoning_content, usage with prompt_tokens_details.cached_tokens).
Scripted replies only (our code): role 0 of a task submits a lookup-table transform built from the known solutions
(exercises the host verification + scoring path); role 1 submits identity, then inspects until the deadline.
FAKE_SCEN: launchfail (every launch fails)."""
import json
import os
import re
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "fixtures"))
import e12_fixtures as B  # noqa: E402  (self-contained fixtures next to this file)

argv = sys.argv[1:]
SCEN = os.environ.get("FAKE_SCEN", "")
PORT = int(argv[argv.index("--port") + 1]) if "--port" in argv else 30000
K = int(argv[argv.index("--max-mamba-cache-size") + 1]) if "--max-mamba-cache-size" in argv else 56
print("[2026-10-19 10:00:00] fake sglang server args:", " ".join(argv), flush=True)
REQUIRED = [["--reasoning-parser", "qwen3"], ["--tool-call-parser", "qwen3_coder"], ["--schedule-policy", "lpm"],
            ["--enable-cache-report"], ["--default-chat-template-kwargs", json.dumps({"preserve_thinking": True})]]
for req in REQUIRED:
    i = argv.index(req[0]) if req[0] in argv else -1
    if i < 0 or (len(req) == 2 and argv[i + 1] != req[1]):
        print(f"ValueError: E12 harness: missing Duck serving flag {req}", flush=True)
        sys.exit(1)
if SCEN == "launchfail":
    print("ValueError: simulated permanent configuration error", flush=True)
    sys.exit(1)
for tp in range(4):
    print(f"[2026-10-19 10:00:02 TP{tp}] Load weight end. elapsed=2.4 s, type=Qwen3_5ForConditionalGeneration, quant=compressed-tensors, avail mem=17.10 GB, mem usage=4.62 GB.", flush=True)
    print(f"[2026-10-19 10:00:03 TP{tp}] Mamba Cache is allocated. max_mamba_cache_size: {K}, conv_state size: 0.04GB, ssm_state size: 1.00GB intermediate_ssm_state_cache size: 1.83GB", flush=True)
    print(f"[2026-10-19 10:00:03 TP{tp}] KV Cache is allocated. dtype: torch.float8_e4m3fn, #tokens: 881336, K size: 3.36 GB, V size: 3.36 GB", flush=True)
print("[2026-10-19 10:00:04 TP0] Capture target verify CUDA graph begin. backend=full, num_tokens_per_req=8, bs=[1, 2, 3, 4, 5, 6, 7, 8, 10, 12], avail mem=5.27 GB", flush=True)
print("[2026-10-19 10:00:05 TP0] Capture draft verify CUDA graph end. elapsed=1.0 s, mem usage=0.38 GB, avail mem=2.22 GB.", flush=True)

CH, SOL, _, _ = B.load()
LOCK = threading.Lock()
LOG = {"chat": [], "generate": []}
CONV_STEP, CONV_META, TASK_ROLES, NEW_CONVS = {}, {}, {}, []
INFLIGHT = [0, 0]
ABORT = set()
T_READY = time.time() + 0.5
CONV_RE = re.compile(r"CONV=(\w+)")


def rows(g):
    return "\n".join(" ".join(str(v) for v in r) for r in g)


def task_of(system_text):
    head = system_text.split("Training pair 1 input:\n", 1)[-1].split("\nTraining pair 1 output:", 1)[0]
    for tid, t in CH.items():
        if rows(t["train"][0]["input"]) == head:
            return tid
    return None


def lookup_code(tid):
    t = CH[tid]
    table = {json.dumps(p["input"]): p["output"] for p in t["train"]}
    for qi, q in enumerate(t["test"]):
        table[json.dumps(q["input"])] = SOL[tid][qi]
    return ("def transform(g):\n    import json\n    table = " + json.dumps(table) + "\n"
            "    return table.get(json.dumps(g), g)\ncheck(transform)")


INSPECT = "print(len(train), len(test_inputs), [(len(p['input']), len(p['input'][0])) for p in train])"
IDENT = "def transform(g):\n    return [list(r) for r in g]\ncheck(transform)\nsubmit(transform)"


def program(tid, role):
    if role == 0:
        return [INSPECT, lookup_code(tid), "submit(transform)"]
    return [IDENT, INSPECT]


def chat_reply(body):
    msgs = body.get("messages") or []
    tid = task_of(str(msgs[0].get("content", ""))) if msgs else None
    conv = None
    for m in msgs:
        if m.get("role") == "assistant":
            f = CONV_RE.search(str(m.get("reasoning_content") or ""))
            if f:
                conv = f.group(1)
    with LOCK:
        if conv is None:
            role = TASK_ROLES.get(tid, 0)
            TASK_ROLES[tid] = role + 1
            conv = f"{tid}r{role}"
            CONV_META[conv] = (tid, role)
            CONV_STEP[conv] = 0
            NEW_CONVS.append([tid, role, time.time()])
        tid, role = CONV_META[conv]
        i = CONV_STEP[conv]
        CONV_STEP[conv] = i + 1
    steps = program(tid, role)
    code = steps[min(i, len(steps) - 1)]
    rendered = json.dumps({"messages": msgs, "tools": body.get("tools")})
    prompt = max(1, int(len(rendered) / 3.2))
    cached = int(prompt * 0.9) if i else 0
    msg = {"role": "assistant", "content": "", "reasoning_content": f"CONV={conv} THINK step {i} for {tid} role {role}.",
           "tool_calls": [{"id": f"call_{conv}_{i}", "type": "function",
                           "function": {"name": "python", "arguments": json.dumps({"code": code})}}]}
    return {"id": f"chatcmpl-{conv}-{i}", "object": "chat.completion", "model": body.get("model"),
            "choices": [{"index": 0, "message": msg, "finish_reason": "tool_calls"}],
            "usage": {"prompt_tokens": prompt, "completion_tokens": 400, "total_tokens": prompt + 400,
                      "prompt_tokens_details": {"cached_tokens": cached}}}


class H(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):
        pass

    def _send(self, body, code=200, ctype="application/json"):
        b = body.encode() if isinstance(body, str) else body
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(b)))
        self.send_header("Connection", "close")
        self.end_headers()
        self.close_connection = True
        self.wfile.write(b)

    def do_GET(self):
        if self.path == "/health":
            return self._send("" if time.time() >= T_READY else "loading", 200 if time.time() >= T_READY else 503)
        if self.path == "/v1/models":
            return self._send(json.dumps({"object": "list", "data": [{"id": "fake-int4", "object": "model"}]}))
        if self.path == "/metrics":
            with LOCK:
                n = INFLIGHT[0]
            lines = [f'sglang:num_running_reqs{{model_name="int4"}} {n}', 'sglang:num_queue_reqs{model_name="int4"} 0',
                     'sglang:token_usage{model_name="int4"} 0.1', 'sglang:full_token_usage{model_name="int4"} 0.1',
                     'sglang:gen_throughput{model_name="int4"} 300.0', 'sglang:cache_hit_rate{model_name="int4"} 0.9']
            return self._send("\n".join(lines) + "\n", ctype="text/plain")
        if self.path == "/fake_log":
            with LOCK:
                return self._send(json.dumps(dict(LOG, new_convs=NEW_CONVS, max_inflight=INFLIGHT[1])))
        return self._send("{}", 404)

    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0))
        req = json.loads(self.rfile.read(n) or b"{}")
        if self.path == "/abort_request":
            with LOCK:
                ABORT.add(req.get("rid"))
            return self._send("", 200)
        if self.path == "/v1/chat/completions":
            with LOCK:
                INFLIGHT[0] += 1
                INFLIGHT[1] = max(INFLIGHT[1], INFLIGHT[0])
            try:
                out = chat_reply(req)
            finally:
                with LOCK:
                    INFLIGHT[0] -= 1
            with LOCK:
                LOG["chat"].append({k: req.get(k) for k in ("model", "max_tokens", "temperature", "top_p", "top_k", "stream",
                                                            "chat_template_kwargs", "tool_choice")}
                                   | {"n_messages": len(req.get("messages") or []), "id": out["id"]})
            print(f"[2026-10-19 10:01:00 TP0] Decode batch, #running-req: 1, #full token: 5000, full token usage: 0.01, "
                  f"accept len: 3.50, cuda graph: True, gen throughput (token/s): 300.00, #queue-req: 0", flush=True)
            return self._send(json.dumps(out))
        if self.path != "/generate":
            return self._send("{}", 404)
        rid, sp = req["rid"], req["sampling_params"]
        with LOCK:
            LOG["generate"].append(rid)
        total = 16 if rid == "e11-smoke-a" else int(sp["max_new_tokens"])
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Transfer-Encoding", "chunked")
        self.send_header("Connection", "close")
        self.end_headers()
        self.close_connection = True

        def emit(b):
            self.wfile.write(f"{len(b):x}\r\n".encode() + b + b"\r\n")
            self.wfile.flush()
        sent, fin = 0, None
        while fin is None:
            with LOCK:
                ab = rid in ABORT
            if ab:
                fin, chunk = {"type": "abort"}, []
            else:
                chunk = [11] * min(8, total - sent)
                sent += len(chunk)
                if sent >= total:
                    fin = {"type": "length", "length": total}
            meta = {"id": rid, "finish_reason": fin, "prompt_tokens": 10, "completion_tokens": sent, "cached_tokens": 0}
            emit(b"data: " + json.dumps({"output_ids": chunk, "meta_info": meta}).encode() + b"\n\n")
            if rid == "e11-smoke-b":
                time.sleep(0.01)
        emit(b"data: [DONE]\n\n")
        self.wfile.write(b"0\r\n\r\n")
        self.wfile.flush()


srv = ThreadingHTTPServer(("127.0.0.1", PORT), H)
srv.daemon_threads = True
print(f"[2026-10-19 10:00:06] The server is fired up and ready to roll! port {PORT}", flush=True)
srv.serve_forever()
