"""Scripted fake OpenAI /v1/chat/completions server for the Experiment 12 CPU harness.

It never generates or runs model code: every reply is a scripted step written by us. A conversation is identified
by a CONV=<id> tag that the fake writes into its own reasoning_content (replayed by Duck's preserve-thinking
history); the first request of a conversation has no tag and gets the next role for that task (0, 1, ...).
"""
from __future__ import annotations

import hashlib
import json
import re
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

CONV_RE = re.compile(r"CONV=(\w+)")


class FakeOpenAI:
    def __init__(self, programs, latency: float = 0.0, single_conv: bool = False, fail_first: int = 0):
        """programs(task_key, role) -> list of steps; a step is a dict:
        {"kind": "tool"|"markup"|"prose", "code": str, "ct": completion tokens}. The last step repeats.
        single_conv: one conversation per task (survives trimming); fail_first: the first N requests get HTTP 500."""
        self.programs = programs
        self.latency = latency
        self.single_conv = single_conv
        self.fail_left = fail_first
        self.lock = threading.Lock()
        self.requests: list[dict] = []
        self.inflight = 0
        self.max_inflight = 0
        self.conv_step: dict[str, int] = {}
        self.conv_meta: dict[str, tuple[str, int]] = {}
        self.task_roles: dict[str, int] = {}
        self.new_conv_order: list[tuple[str, int]] = []
        self.task_keys: dict[str, str] = {}
        self.httpd = ThreadingHTTPServer(("127.0.0.1", 0), self._handler())
        self.httpd.daemon_threads = True
        self.port = self.httpd.server_address[1]
        self.base_url = f"http://127.0.0.1:{self.port}/v1"
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()

    def close(self):
        self.httpd.shutdown()

    @staticmethod
    def task_key(system_text: str) -> str:
        return hashlib.sha1(system_text.encode("utf-8")).hexdigest()[:10]

    def _conv(self, body) -> tuple[str, str, int]:
        msgs = body.get("messages") or []
        tkey = self.task_key(str(msgs[0].get("content", ""))) if msgs else "none"
        conv = None
        for m in msgs:
            if m.get("role") == "assistant":
                found = CONV_RE.search(str(m.get("reasoning_content") or m.get("reasoning") or ""))
                if found:
                    conv = found.group(1)
        with self.lock:
            if conv is None and self.single_conv and tkey in self.task_roles:
                conv = f"{tkey}r0"
            if conv is None and any(m.get("role") == "assistant" for m in msgs):
                # history trimmed past every tagged reply: the task's only / latest conversation
                cands = [c for c, (t, _) in self.conv_meta.items() if t == tkey]
                conv = cands[-1] if cands else None
            if conv is None:
                role = self.task_roles.get(tkey, 0)
                self.task_roles[tkey] = role + 1
                conv = f"{tkey}r{role}"
                self.conv_meta[conv] = (tkey, role)
                self.conv_step[conv] = 0
                self.new_conv_order.append((tkey, role))
            tkey, role = self.conv_meta[conv]
        return conv, tkey, role

    def _reply(self, body):
        with self.lock:
            if self.fail_left > 0:
                self.fail_left -= 1
                return 500, {"error": "scripted internal error"}, None, -1
        conv, tkey, role = self._conv(body)
        steps = self.programs(tkey, role)
        with self.lock:
            i = self.conv_step[conv]
            step = steps[min(i, len(steps) - 1)]
            self.conv_step[conv] = i + 1
        rendered = json.dumps({"messages": body.get("messages"), "tools": body.get("tools")}, ensure_ascii=False)
        prompt_tokens = max(1, int(len(rendered) / 3.2))
        ct = int(step.get("ct", 200))
        reasoning = f"CONV={conv} THINK step {i}: scripted reasoning for role {role}. " + step.get("think", "")
        msg = {"role": "assistant", "content": "", "reasoning_content": reasoning}
        finish = "stop"
        kind = step["kind"]
        if kind == "http500":
            return 500, {"error": "scripted internal error"}, conv, i
        if kind == "tool":
            msg["tool_calls"] = [{"id": f"call_{conv}_{i}", "type": "function",
                                  "function": {"name": "python", "arguments": json.dumps({"code": step["code"]})}}]
            finish = "tool_calls"
        elif kind == "markup":
            msg["content"] = ("<tool_call>\n<function=python>\n<parameter=code>\n" + step["code"]
                              + "\n</parameter>\n</function>\n</tool_call>")
        elif kind == "prose":
            msg["content"] = "I think the rule is a reflection. Let me consider it more."
        return 200, {"id": f"cmpl-{conv}-{i}", "object": "chat.completion", "model": body.get("model"),
                     "choices": [{"index": 0, "message": msg, "finish_reason": finish}],
                     "usage": {"prompt_tokens": prompt_tokens, "completion_tokens": ct,
                               "total_tokens": prompt_tokens + ct,
                               "prompt_tokens_details": {"cached_tokens": 0}}}, conv, i

    def _handler(self):
        fake = self

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def do_POST(self):
                n = int(self.headers.get("Content-Length") or 0)
                body = json.loads(self.rfile.read(n) or b"{}")
                with fake.lock:
                    fake.inflight += 1
                    fake.max_inflight = max(fake.max_inflight, fake.inflight)
                t0 = time.time()
                try:
                    if fake.latency:
                        time.sleep(fake.latency)
                    status, out, conv, step = fake._reply(body)
                finally:
                    with fake.lock:
                        fake.inflight -= 1
                with fake.lock:
                    fake.requests.append({"path": self.path, "t0": t0, "t1": time.time(), "body": body,
                                          "status": status, "conv": conv, "step": step, "reply": out})
                data = json.dumps(out).encode("utf-8")
                try:
                    self.send_response(status)
                    self.send_header("Content-Type", "application/json")
                    self.send_header("Content-Length", str(len(data)))
                    self.end_headers()
                    self.wfile.write(data)
                except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                    pass

        return H
