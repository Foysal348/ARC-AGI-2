"""Self-contained fixtures for the E12 notebook harness (paths relative to this file).
data/: ARC-AGI-2 public evaluation challenges + solutions. tok_int4/: RedHatAI/Qwen3.8-27B-INT4 tokenizer + config
(compressed-tensors). tok_fp8/: the S49 FP8 tokenizer files + a minimal fp8 config. Same task pick as the E11-05 harness."""
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
DATA = HERE / "data"
TOKDIR_INT4 = HERE / "tok_int4"
TOKDIR_FP8 = HERE / "tok_fp8"


def load():
    ch = json.load(open(DATA / "arc-agi_evaluation_challenges.json", encoding="utf-8"))
    sol = json.load(open(DATA / "arc-agi_evaluation_solutions.json", encoding="utf-8"))
    multi = sorted(t for t in ch if len(ch[t]["test"]) >= 2)[:3]
    single = sorted(t for t in ch if len(ch[t]["test"]) == 1)[:5]
    return ch, sol, multi, single
