"""Measure how long our past Qwen3.8 Poetiq programs (E10 R5 EVAL120, E11-05 EVAL30, E11-06 EVAL14) take per grid,
to validate the E12 per-grid verification budget (30 s per grid, 60 s per submission). User allowed running them
locally (2026-10-19). Untrusted code: one fresh `python -I` process per (program, grid), cwd = an empty temp dir on D:,
minimal env, 60 s wall limit; programs that touch os/subprocess/files/network/eval are skipped, not run.
    python time_poetiq_programs.py            -> results.jsonl + summary"""
import json
import os
import re
import subprocess
import sys
import tempfile
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

HERE = Path(__file__).resolve().parent
EXP = Path(r"D:/ARC AGI 2/experiments")
RUNS = {
    "E10_R5_EVAL120": EXP / "Experiment 10 - Q27-XHIGH Poetiq Code-Verify attempt_2 (planned)/Experiment Results/Kaggle Runs/GPU EVAL120 Poetiq R5 (hosen42 q27-xhigh-e10-poetiq-r5-eval120)",
    "E11_05_EVAL30": EXP / "Experiment 11 - SGLang 0.5.21 + RedHat INT4 + DFlash2 (planned)/Experiment Results/Kaggle Runs/E11-05 EVAL30 run1 (esfersami50, 2026-10-18)",
    "E11_06_EVAL14": EXP / "Experiment 11 - SGLang 0.5.21 + RedHat INT4 + DFlash2 (planned)/Experiment Results/Kaggle Runs/E11-06 P1-60K EVAL14 run1 (esfersami50, 2026-10-19)",
}
DATA = HERE.parent / "e12_harness" / "fixtures" / "data"
CH = json.load(open(DATA / "arc-agi_evaluation_challenges.json", encoding="utf-8"))
SOL = json.load(open(DATA / "arc-agi_evaluation_solutions.json", encoding="utf-8"))
UNSAFE = re.compile(r"\b(import\s+(os|sys|subprocess|socket|shutil|ctypes|pathlib|requests|urllib|pickle|multiprocessing|threading|signal)"
                    r"|from\s+(os|sys|subprocess|socket|shutil|ctypes|pathlib|requests|urllib|pickle|multiprocessing)\b"
                    r"|open\(|__import__|\beval\(|\bexec\(|compile\(|globals\(|getattr\()")
LIMIT = 60.0
CHILD = r'''
import json, sys, time
src, grid = json.load(sys.stdin)
ns = {"__name__": "prog"}
exec(compile(src, "<prog>", "exec"), ns)
import numpy as np
t0 = time.perf_counter()
out = ns["transform"](np.array(grid, dtype=int))
dt = time.perf_counter() - t0
out = out.tolist() if hasattr(out, "tolist") else out
print("@@" + json.dumps({"sec": dt, "out": out}))
'''
TMP = HERE / "run_tmp"
TMP.mkdir(exist_ok=True)


def run_one(src, grid):
    with tempfile.TemporaryDirectory(dir=TMP) as d:
        env = {"PATH": os.environ.get("PATH", ""), "SYSTEMROOT": os.environ.get("SYSTEMROOT", ""),
               "PYTHONIOENCODING": "utf-8", "OMP_NUM_THREADS": "1", "OPENBLAS_NUM_THREADS": "1", "MKL_NUM_THREADS": "1"}
        t0 = time.perf_counter()
        try:
            p = subprocess.run([sys.executable, "-I", "-c", CHILD], input=json.dumps([src, grid]), capture_output=True,
                               text=True, encoding="utf-8", cwd=d, env=env, timeout=LIMIT)
        except subprocess.TimeoutExpired:
            return {"status": "timeout", "sec": LIMIT, "wall": LIMIT}
        wall = time.perf_counter() - t0
        line = next((l for l in reversed(p.stdout.splitlines()) if l.startswith("@@")), None)
        if line is None:
            return {"status": "error", "err": (p.stderr or "")[-200:], "wall": round(wall, 2)}
        r = json.loads(line[2:])
        return {"status": "ok", "sec": r["sec"], "wall": round(wall, 2), "out": r["out"]}


def main():
    jobs = []
    for run, d in RUNS.items():
        for f in sorted((d / "q27x" / "poetiq_programs").glob("*.py")):
            tid = f.name.split("_e")[0]
            src = f.read_text(encoding="utf-8", errors="replace")
            jobs.append((run, f.name, tid, src))
    out_path = HERE / "results.jsonl"
    done = set()
    if out_path.exists():
        done = {(json.loads(l)["run"], json.loads(l)["prog"]) for l in open(out_path, encoding="utf-8")}

    def do(job):
        run, prog, tid, src = job
        if (run, prog) in done:
            return None
        if tid not in CH:
            return {"run": run, "prog": prog, "task": tid, "skipped": "task not in eval data"}
        if UNSAFE.search(src):
            return {"run": run, "prog": prog, "task": tid, "skipped": "unsafe pattern: " + UNSAFE.search(src).group(0)}
        t = CH[tid]
        rec = {"run": run, "prog": prog, "task": tid, "train": [], "test": []}
        for p in t["train"]:
            r = run_one(src, p["input"])
            rec["train"].append({"sec": r.get("sec"), "status": r["status"], "exact": r.get("out") == p["output"]})
        for qi, q in enumerate(t["test"]):
            r = run_one(src, q["input"])
            rec["test"].append({"sec": r.get("sec"), "status": r["status"], "exact": r.get("out") == SOL[tid][qi]})
        return rec

    t0 = time.time()
    with ThreadPoolExecutor(max_workers=6) as pool, open(out_path, "a", encoding="utf-8") as fo:
        for i, rec in enumerate(pool.map(do, jobs)):
            if rec is not None:
                fo.write(json.dumps(rec) + "\n"); fo.flush()
            if i % 25 == 0:
                print(f"{i}/{len(jobs)} programs, {time.time() - t0:.0f} s", flush=True)
    print("done", len(jobs), "programs in", round(time.time() - t0), "s")


if __name__ == "__main__":
    main()
