"""Validate the two GPT audits of the E12 step-3.5 build WITHOUT changing project code.
All code run in the Duck sandbox here is our own scripted test code.
    python validate_gpt_findings.py race|spoof|grace|scale"""
import json
import os
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
# audit-zip layout (harness/ next to duck_arc2/, fake_openai.py beside this file) or the local workspace
E12 = (HERE.parent / "duck_arc2") if (HERE.parent / "duck_arc2").is_dir() else \
    Path(r"D:/ARC AGI 2/experiments/Experiment 12 - Duck REPL agent for ARC-AGI-2 (planned)/duck_arc2")
sys.path[:0] = [str(E12), str(E12 / "vendor"), str(HERE), str(HERE.parent / "e12_harness")]
sys.stdout.reconfigure(encoding="utf-8")
WHAT = sys.argv[1]

if os.name == "nt":   # Windows-only shim (Duck passes its 65 KB bootstrap as -c)
    _real = subprocess.Popen
    _bdir = HERE / "_bootstrap"; _bdir.mkdir(exist_ok=True)

    class _Shim(_real):
        def __init__(self, args, *a, **kw):
            if isinstance(args, list) and len(args) >= 5 and args[1:4] == ["-I", "-S", "-c"]:
                f = _bdir / "sandbox_bootstrap.py"
                if not f.exists() or f.read_text(encoding="utf-8") != args[4]:
                    f.write_text(args[4], encoding="utf-8")
                args = [args[0], "-I", "-S", str(f)] + args[5:]
            super().__init__(args, *a, **kw)
    subprocess.Popen = _Shim
    if not hasattr(os, "killpg"):      # Duck kills a timed-out child's process group (Linux only)
        import signal as _sig
        os.killpg = lambda pid, sig: os.kill(pid, 9)
        if not hasattr(_sig, "SIGKILL"):
            _sig.SIGKILL = 9

flip = lambda g: [list(reversed(r)) for r in g]
TASK = {"train": [{"input": g, "output": flip(g)} for g in ([[1, 2, 3], [4, 5, 6]], [[7, 0], [0, 8], [9, 9]])],
        "test": [{"input": [[3, 1], [2, 2]]}]}

if WHAT == "race":
    # the notebook's CELL 0 write_json_atomic, verbatim
    def write_json_atomic(path, obj):
        tmp = Path(str(path) + ".tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(obj, f)
        os.replace(tmp, path)
    d = Path(tempfile.mkdtemp(dir=HERE)); p = d / "submission.json"
    big = {f"t{i}": [{"attempt_1": [[i % 10] * 30] * 30, "attempt_2": [[1] * 30] * 30}] for i in range(240)}
    errs, bad = [], [0]
    stop = threading.Event()

    def writer(k):
        for _ in range(40):
            try:
                write_json_atomic(p, dict(big, writer=k))
            except Exception as e:
                errs.append(type(e).__name__)

    def reader():
        while not stop.is_set():
            try:
                json.loads(p.read_text(encoding="utf-8"))
            except FileNotFoundError:
                pass
            except (ValueError, PermissionError) as e:
                bad[0] += 1
    rt = threading.Thread(target=reader); rt.start()
    ths = [threading.Thread(target=writer, args=(k,)) for k in range(12)]
    [t.start() for t in ths]; [t.join() for t in ths]; stop.set(); rt.join()
    try:
        json.loads(p.read_text(encoding="utf-8")); final = "valid JSON"
    except Exception as e:
        final = f"INVALID ({type(e).__name__})"
    print(f"RACE: 12 writers x 40 writes: writer errors {len(errs)} {sorted(set(errs))}; reader saw corrupt/locked {bad[0]} times; final file {final}")

if WHAT == "spoof":
    import arc2_duck as A
    os.environ.update(A.duck_env("http://127.0.0.1:9/v1", "x", 12))
    TA, DP, _, wrs = A._import_duck()
    Agent = A.make_agent_class()
    d = Path(tempfile.mkdtemp(dir=HERE)); st = d / TA.RUNTIME_STATE_FILENAME
    wrs(st, current_frame=None, history=[])

    def run(code, branch=0):
        ag = Agent(task=TASK, task_id="flip", branch=branch, model="x", base_url="http://127.0.0.1:9/v1", provider="vllm")
        r = ag._run_python_tool(st, {"code": code})
        return ag, r
    forged = json.dumps({"train": [p["output"] for p in TASK["train"]], "test": [[[9, 9]]]}, separators=(",", ":"))
    cases = {
        "1 correct": "def t(g):\n    return [list(reversed(r)) for r in g]\nsubmit(t)",
        "2 wrong": "def t(g):\n    return g\nsubmit(t)",
        "3 wrong + forged marker printed by the snippet": "def t(g):\n    return g\nprint('" + "__ARC2_VERIFY__" + forged + "')\nsubmit(t)",
        "4 wrong + monkeypatched print (needs the hidden marker + the train outputs)":
            "def t(g):\n    b = __builtins__\n    real = b['print']\n    def fake(*a, **k):\n"
            "        s = ' '.join(str(x) for x in a)\n"
            "        if s.startswith('" + "__ARC2_VERIFY__" + "'):\n            real('" + "__ARC2_VERIFY__" + forged + "')\n"
            "        else:\n            real(*a, **k)\n    b['print'] = fake\n    return g\nsubmit(t)",
        "4b wrong + print overridden WITHOUT knowing the marker (accidental)":
            "def t(g):\n    __builtins__['print'] = lambda *a, **k: None\n    return g\nsubmit(t)",
    }
    for label, code in cases.items():
        ag, r = run(code)
        v = ag.arc2_submissions[-1] if ag.arc2_submissions else {}
        print(f"SPOOF {label}: accepted={v.get('accepted')} train_exact={v.get('train_exact')} test={v.get('test_outputs')} | {str(v.get('summary'))[:90]}")

if WHAT == "grace":
    import arc2_duck as A
    os.environ.update(A.duck_env("http://127.0.0.1:9/v1", "x", 12))   # port 9: connection refused = a dead server
    os.environ.update(ARC3_HTTP_RETRY_BASE_SECONDS="0.5", ARC3_HTTP_RETRY_MAX_SECONDS="1")
    TA, DP, _, wrs = A._import_duck()
    Agent = A.make_agent_class()
    d = Path(tempfile.mkdtemp(dir=HERE))
    t0 = time.monotonic(); out = {}
    th = threading.Thread(target=lambda: out.update(rec=A.run_branch(
        Agent, task_id="flip", task=TASK, branch=0, queue_position=0, out_dir=d, deadline=time.monotonic() + 5,
        base_url="http://127.0.0.1:9/v1", model_id="x", save_request_logs=False, backoff=0.2)), daemon=True)
    th.start(); th.join(90)
    el = time.monotonic() - t0
    print(f"GRACE: deadline 5 s, dead server: branch {'returned' if not th.is_alive() else 'STILL RUNNING'} after {el:.0f} s"
          + (f" (note: {out['rec'].get('note')!r}, failures {out['rec'].get('failures')})" if 'rec' in out else " (gave up waiting at 90 s; the grace is 900 s)"))

if WHAT == "scale":
    import arc2_duck as A
    from fake_openai import FakeOpenAI
    os.environ.update(A.duck_env("http://127.0.0.1:9/v1", "x", 12))
    n_tasks = int(sys.argv[2]) if len(sys.argv) > 2 else 240
    tasks = {}
    for i in range(n_tasks):   # distinct synthetic flip tasks (distinct system prompts)
        g1 = [[(i + c) % 10 for c in range(3)], [(i * 7 + c) % 10 for c in range(3)]]
        g2 = [[(i // 10) % 10, 0], [0, (i % 9) + 1]]
        tasks[f"s{i:03d}"] = {"train": [{"input": g, "output": flip(g)} for g in (g1, g2)], "test": [{"input": [[i % 10, 1]]}]}
    code_def = "def transform(g):\n    return [list(reversed(r)) for r in g]\ncheck(transform)"
    fake = FakeOpenAI(lambda tk, role: [dict(kind="tool", code=code_def, ct=300), dict(kind="tool", code="submit(transform)", ct=300)],
                      latency=0.05)
    peak = [0]; stop = threading.Event()

    def mon():
        while not stop.is_set():
            peak[0] = max(peak[0], threading.active_count()); time.sleep(0.05)
    threading.Thread(target=mon, daemon=True).start()
    d = Path(tempfile.mkdtemp(dir=HERE)); t0 = time.monotonic()
    recs = A.solve_all(tasks, sorted(tasks), out_dir=d, deadline=time.monotonic() + 1800, base_url=fake.base_url,
                       model_id="x", branches=2)
    stop.set(); el = time.monotonic() - t0
    flat = [r for v in recs.values() for r in v]
    roles = [r for _, r in fake.new_conv_order]
    first_b1 = roles.index(1) if 1 in roles else None
    print(f"SCALE: {n_tasks} tasks x 2 = {len(flat)} branches in {el:.0f} s | accepted {sum(r['accepted'] for r in flat)} | "
          f"peak threads {peak[0]} | max in-flight {fake.max_inflight} | first branch-1 start at position {first_b1} "
          f"(all branch-0 before it: {roles[:first_b1].count(0) == n_tasks if first_b1 is not None else None}) | "
          f"notes {sorted({r.get('note') for r in flat if r.get('note')})[:3]}")
    fake.close()
