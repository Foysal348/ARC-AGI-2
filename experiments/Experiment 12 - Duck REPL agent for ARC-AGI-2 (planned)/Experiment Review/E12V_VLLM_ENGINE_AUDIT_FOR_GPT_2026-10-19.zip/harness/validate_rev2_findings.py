"""Validate the rev-2 GPT audit claims WITHOUT changing project code (our own scripted test code only).
    python validate_rev2_findings.py failopen|jsonspoof|lookup"""
import json
import os
import subprocess
import sys
import tempfile
import types
from pathlib import Path

HERE = Path(__file__).resolve().parent
E12 = Path(r"D:/ARC AGI 2/experiments/Experiment 12 - Duck REPL agent for ARC-AGI-2 (planned)/duck_arc2")
sys.path[:0] = [str(E12), str(E12 / "vendor")]
sys.stdout.reconfigure(encoding="utf-8")
WHAT = sys.argv[1]
if os.name == "nt":
    _real = subprocess.Popen
    _bdir = HERE / "_bootstrap"; _bdir.mkdir(exist_ok=True)

    class _Shim(_real):
        def __init__(self, args, *a, **kw):
            if isinstance(args, list) and len(args) >= 5 and args[1:4] == ["-I", "-S", "-c"]:
                f = _bdir / "sandbox_bootstrap.py"
                if not f.exists() or f.read_text(encoding="utf-8") != args[4]:
                    f.write_text(args[4], encoding="utf-8")
                args = [args[0], "-I", "-S", str(f)] + args[5:]
            super().__init__(args, *a, **kw)
    subprocess.Popen = _Shim
    if not hasattr(os, "killpg"):      # Duck kills a timed-out child's process group (Linux only)
        import signal as _sig
        os.killpg = lambda pid, sig: os.kill(pid, 9)
        if not hasattr(_sig, "SIGKILL"):
            _sig.SIGKILL = 9
    # Windows keeps a killed child's cwd locked for a moment; ignore that temp-dir cleanup error (Linux: no issue)
    _RealTD = tempfile.TemporaryDirectory

    class _TD(_RealTD):
        def __init__(self, *a, **kw):
            kw.setdefault("ignore_cleanup_errors", True)
            super().__init__(*a, **kw)
    tempfile.TemporaryDirectory = _TD

import arc2_duck as A  # noqa: E402
os.environ.update(A.duck_env("http://127.0.0.1:9/v1", "x", 12))
TA, DP, run_sb, wrs = A._import_duck()

flip = lambda g: [list(reversed(r)) for r in g]
TASK = {"train": [{"input": g, "output": flip(g)} for g in ([[1, 2, 3], [4, 5, 6]], [[7, 0], [0, 8], [9, 9]])],
        "test": [{"input": [[3, 1], [2, 2]]}]}
KW = dict(timeout_seconds=30, initial_state={"current_frame": None, "history": [], "valid_actions": [],
                                             "last_action_call_result": {}},
          action_handler=lambda a, stale_after=None: {"action_result": {}, "state": {}}, kept_functions=[])

if WHAT == "failopen":
    # inject a resource module whose prlimit always fails, then install the limit as the notebook does
    fake = types.ModuleType("resource"); fake.RLIMIT_AS = 9

    def _fail(*a, **k):
        raise PermissionError("simulated prlimit failure")
    fake.prlimit = _fail
    sys.modules["resource"] = fake
    lim = A.install_sandbox_memory_limit(4096)
    r = run_sb(code="print('MODEL_CODE_EXECUTED')", **KW)
    ran = "MODEL_CODE_EXECUTED" in (r.get("stdout") or "")
    r2 = run_sb(code="print('MODEL_CODE_EXECUTED')", **KW)   # a later child must fail closed too
    ran2 = "MODEL_CODE_EXECUTED" in (r2.get("stdout") or "")
    print(f"FAILOPEN: model code ran = {ran} / {ran2} (must be False / False) | error = {r.get('error')!r} | limit state: {lim}")

if WHAT == "fakeok":   # the success path on Windows: a fake resource that records and reads back the limit
    store = {}
    fake = types.ModuleType("resource"); fake.RLIMIT_AS = 9

    def _pl(pid, res, new=None):
        if new is not None:
            store[pid] = tuple(new)
            return None
        return store.get(pid, (-1, -1))
    fake.prlimit = _pl
    sys.modules["resource"] = fake
    lim = A.install_sandbox_memory_limit(4096)
    r = run_sb(code="print('MODEL_CODE_EXECUTED')", **KW)
    print(f"FAKEOK: model code ran = {'MODEL_CODE_EXECUTED' in (r.get('stdout') or '')} (must be True) | "
          f"limits set = {sorted(set(store.values()))} | state: {lim}")

if WHAT == "mixed":   # GPT 1: 2 train pairs exact + 1 timeout -> must be rejected (real eval task)
    import time
    data = HERE.parent / "e12_harness" / "fixtures" / "data"
    ch = json.load(open(data / "arc-agi_evaluation_challenges.json", encoding="utf-8"))
    tid = next(t for t in sorted(ch) if len(ch[t]["train"]) >= 3 and len(ch[t]["test"]) == 1)
    task = ch[tid]
    Agent = A.make_agent_class()
    d = Path(tempfile.mkdtemp(dir=HERE)); st = d / TA.RUNTIME_STATE_FILENAME
    wrs(st, current_frame=None, history=[])
    ag = Agent(task=task, task_id=tid, branch=0, model="x", base_url="http://127.0.0.1:9/v1", provider="vllm")
    table = {json.dumps(p["input"]): p["output"] for p in task["train"][:2]}
    code = ("def t(g):\n    import json\n    table = " + json.dumps(table) + "\n    k = json.dumps(g)\n"
            "    if k in table:\n        return table[k]\n    while True:\n        pass\nsubmit(t)")
    t0 = time.monotonic()
    ag._run_python_tool(st, {"code": code})
    v = ag.arc2_submissions[-1]
    print(f"MIXED {tid} ({len(task['train'])} train, {len(task['test'])} test): accepted={v['accepted']} "
          f"train_exact={v['train_exact']} test={['grid' if g else None for g in v['test_outputs']]} "
          f"verify+tool {time.monotonic() - t0:.1f} s | {v['summary'][:160]}")

if WHAT in ("jsonspoof", "lookup"):
    Agent = A.make_agent_class()
    d = Path(tempfile.mkdtemp(dir=HERE)); st = d / TA.RUNTIME_STATE_FILENAME
    wrs(st, current_frame=None, history=[])
    ag = Agent(task=TASK, task_id="flip", branch=0, model="x", base_url="http://127.0.0.1:9/v1", provider="vllm")
    if WHAT == "jsonspoof":   # GPT rev-2 audit: a WRONG function patches json.dumps so the 'final' payload carries the truth
        code = ("def t(g):\n    import json\n    old = json.dumps\n    want = [list(reversed(r)) for r in g]\n"
                "    def forged(payload, *a, **k):\n"
                "        if isinstance(payload, dict) and payload.get('type') == 'final':\n"
                "            payload = dict(payload); payload['result'] = want\n"
                "        return old(payload, *a, **k)\n"
                "    json.dumps = forged\n    return g\nsubmit(t)")
    else:   # the honest equivalent: a lookup table of the train outputs (always possible: the outputs are in the prompt)
        table = {json.dumps(p["input"]): p["output"] for p in TASK["train"]}
        code = ("def t(g):\n    import json\n    table = " + json.dumps(table) + "\n"
                "    return table.get(json.dumps(g), g)\nsubmit(t)")
    ag._run_python_tool(st, {"code": code})
    v = ag.arc2_submissions[-1]
    print(f"{WHAT.upper()}: accepted={v['accepted']} train_exact={v['train_exact']} test={v['test_outputs']}")
