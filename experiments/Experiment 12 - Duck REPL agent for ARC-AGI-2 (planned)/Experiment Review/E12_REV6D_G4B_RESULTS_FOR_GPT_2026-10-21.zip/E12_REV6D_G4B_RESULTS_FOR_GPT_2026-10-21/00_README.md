# E12 Duck agent, rev 6d: GPU run EVAL12R6G4B, review request (2026-10-21)

**Project:** Kaggle ARC Prize 2026, ARC-AGI-2.
- **Model:** Qwen3.8-27B, RedHat INT4 (W4A16 g128) + BF16 DFlash2 drafter.
- **Engine:** SGLang 0.5.21, TP 4 on 4×L4.
- **Agent:** Duck REPL (vendored, unchanged) + our ARC-2 adapter `duck_arc2/arc2_duck.py`.
- **Hidden run:** 240 tasks in one 12 h Kaggle session.

## 1. What we ask you to do

Please do all of this, in this order. Recompute every number you use from the raw files in this bundle; do not trust our summaries.

1. **Validate our claims.** Sections 3–6 make claims with numbers. For each one: confirmed / wrong / unverifiable, with the file and the value you found.
2. **Identify the problems.** What went wrong in this run, including anything we did not notice. Rank by impact on the hidden-run score.
3. **Give a verdict for every fix (section 4 table).** For each fix ID:
   - did it work, partly work, not work, or was it not exercised in this run?
   - why: the mechanism, with evidence (transcript file + line, report field);
   - what would make it work: a concrete change, not a direction.
4. **Propose solutions** for the top problems: a concrete design (code-level where possible). For each:
   - the measurement that would show it worked;
   - the CPU test that must pass before a GPU run.
5. **Answer the open questions in section 7.**

**Output format we would like:**
- one table per item 3 (`ID | verdict | evidence | why | what would make it work`);
- then the ranked problem list;
- then the proposals;
- then the answers to section 7.
- Mark every statement as **measured** (file/field/line) or **inferred**.

**Constraints for any proposal (the user's rules):**
- **Keep the setup:** Qwen3.8-27B on the same stack. No fine-tuning, no API models, no other model.
- **Full coverage is a hard goal:** every one of the 240 hidden tasks gets a real attempt inside 12 h. Hidden tasks are about as hard as the public eval set.
- **Token budget:** thinking per task must not be cut below the current settings without the user's explicit approval. The user's floor is 60,000 thinking tokens for single-pass pipelines. The per-request caps 12,288 / 24,576 and the 28k soft first exposure were approved for rev 6. Say clearly if a proposal needs a new approval.
- **Ground truth:** never used at runtime (analysis only).
- **Bundling:** changes go into one evidence-based release per GPU run, not one-change ablations.
- **No impossible claims:** do not say a score target (LB 60+) is impossible or needs fine-tuning. The user knows teams reach 70–88 with Qwen3.8 + an optimized Duck harness and full coverage. Focus on how.
- **Capacity probe:** the user already decided its replacement (section 5, bug 1). Validate the implementation details; do not replace the decision.

## 2. What ran

| Item | Value |
|---|---|
| Notebook | `notebooks/Q27-XHIGH-E12_DUCK_REPL_SGLANG_EVAL12R6G4B.ipynb` (sha256 `1bdadd8266e758ee48c0947d3197d0aa804f5d751d28277a79e947e7e73980a5`), commit run on Kaggle, COMPLETE in 3,528 s |
| Profile | **Gate 4b**: the 12 EVAL12R5 tasks (19 test inputs) at the hidden run's average time per task. Solve window = 12 × (42,720 − solve start) / 240 = **2,063 s (171.9 s per task)**. These tasks were selected from earlier runs (6 of them hard), so this is a screening test, not an LB forecast |
| Engine | SGLang 0.5.21, INT4 + DFlash2, fp8 KV, context 155,648, KV pool 866,744 tokens, mamba cache 56 slots (4 per request), CUDA graph decode bs [1–8, 10, 12], max running 12 (server 13). Launch took **1,197 s** (a slow cold start; earlier runs about 700 s). Solve started at 1,463 s |
| Agent settings | xhigh (template default), temperature 1.0, preserved thinking, `tool_choice` auto. Per-request caps 12,288 (first) / 24,576 (after a successful Python call) / 32,768 (rescue). First exposure 28,000 tokens (soft pause). Per-branch soft cap 100k. 12 workers. Facts view on branch 0, grids view on branch 1 |
| Note on the report | `configuration` top-level fields (SAMPLING temperature 0.6, MAX_NUM_SEQS, vLLM fields, THINK_BUDGET) are the shared notebook's DIRECT-pipeline defaults and are **not used by the Duck solver**. The Duck values are in `configuration.e12` and `configuration.e12.rev6` |

### Result

| Measure | Value | Source |
|---|---|---|
| Score | **2 / 19 inputs, task-norm 16.67 %**: bf45cf4b (b0, 19.4k tokens), b5ca7ac4 (b0, 27.4k), both by `submit` after a host-verified `check` | `e12_run_report.json` `eval_*` |
| Coverage | 12/12 tasks exposed, stage-1 starts left 0, stragglers 0; finished at 3,517 s vs the deadline 3,526 s | `rev6.scheduler`, `e12_run` |
| Branches | 16 started (12 b0 facts + 4 b1 grids); 2 done, 14 paused at the deadline; 22 items left in the queue | `rev6.scheduler` |
| Tokens | 572,035 generated = 47.7k per task; 277 tok/s over the window | `usage_all` |
| Cache | 75.0 % of prompt tokens cached (rev 5: 85.4 % xhigh / 91.0 % low); uncached prompt 670k > generated 572k | `usage_all`, `rev6.metrics` |

### Earlier runs on the same tasks (all in `runs/`)

| Run | Inputs | Tokens | Notes |
|---|---|---|---|
| rev 4 EVAL6 xhigh | 4/8 | 1,217,904 | 6 tasks, 6 streams, no budget pressure |
| rev 5 EVAL6R5 xhigh | 5/8 | 846,080 (70.5k per branch) | 6 tasks |
| rev 5 EVAL12R5 low | 10/19 | 1,743,889 (72.7k per branch, about 145k per task) | the same 12 tasks, `reasoning_effort` low, 110 min |
| **rev 6d G4B xhigh** | **2/19** | 572,035 (47.7k per task) | hidden-equivalent time share |

**Token-matched comparison** (`analysis/compare_rev5_vs_g4b_output.txt`): would rev 5's branch 0 have had a correct candidate within the tokens G4B's branch 0 used?
- rev 5 xhigh: **1 of 6** tasks; rev 5 low: **3 of 12**; G4B solved **2**.
- Per task: b5ca7ac4 is better in G4B (26k vs 54k xhigh).
- 136b0064 (rev 5 xhigh correct at 35k), 247ef758 (low 29k) and f931b4a8 (low 47k) were solved earlier in rev 5 than G4B's branch-0 budget.
- Each run is one sample, so the per-task differences can be noise.

**Our reading** (inferred): at about 48k tokens per task the binding limit is tokens-to-a-correct-program, and rev 6 has not yet reduced it.

## 3. The rev 6 design in one paragraph

Rev 6 (built after three GPT design reviews; full text in `docs/E12 next fix list (running, 2026-10-20).md`, sections from "Rev 6 gap check" on):
- **Facts view:** no raw grids in the prompt on branch 0. A bounded facts block (≤ 800 Qwen tokens) sits in the system prompt, and the exact grids live in Python (`train`, `test_inputs`), with trusted helpers.
- **Print guard:** whole-grid prints are collapsed by a guard.
- **Checking:** auto-check of new `transform*` functions; host-verified candidate harvest (rev 5); state-aware resume texts.
- **Scheduling:** first exposure for every task (stage 1 = all b0 first, soft pause at 28k), then stage 2 with fair share and a branch-1 hedge in the grids view.
- **Requests:** short per-request caps.
- **Deadline:** clamps on every request and verification.
- **Serving checks:** a capacity probe and serving diagnostics.

The goal was to move the first `check()` from about 55k tokens (rev 5) to ≤ 25k and to fit 240 tasks in 12 h.

## 4. Fix-by-fix result in this run (our evidence; please validate and complete)

Evidence files: `analysis/g4b_fix_evidence_output.txt` (per branch), `runs/rev6d_EVAL12R6G4B/e12_run_report.json` (`rev6.metrics`, per-branch `rev6_events`), transcripts `runs/rev6d_EVAL12R6G4B/duck/<task>_b<k>/transcript.txt`.

| ID | What it should do | Our verdict | Evidence (measured unless marked) |
|---|---|---|---|
| R6-V1 facts view | No hand reading of grid text; act in Python early | **Partly** | First tool call median **46 tokens** (rev 5 xhigh: first reply p50 33.6k before any call). But first `check()` median 33.7k (censored); **10 of 16 branches never checked**; **7 of 12 b0 never defined a `transform`** in 29–59k tokens. Reasoning per request p50 874 characters, p90 25.6k, max 64.9k: one or two long thinks per branch remain |
| R6-V2 facts block | Facts in the system prompt, ≤ 800 tokens | **Worked (size)** | p50 627, p90 763, max 798, 0 over target. Usefulness unclear: 14/16 branches call `arc_overview()` first, which repeats the same facts |
| R6-V3 helpers | Exact inspection in Python | **Rarely used** | `inspect_pair` in 7 branches, `components` 3, `color_counts` 2, `object_diff` 1, `diff_summary` 1; `crop`/`bbox`/`objects`/`grid_diff`/`check_many` 0. T1 (a transform that uses a helper is retained and verified) **not exercised**: the 2 accepted transforms use none |
| R6-V4 print guard | Stop whole-grid prints | **Partly; bug** | 432 rows hidden (38 notes, 11 branches). **Leak: 173 rows printed as `print(r, row)` (`0 [0, 0, 5, …]`) reached the model** in 4c3d4a41_b0 (48), f931b4a8_b0 (97), 247ef758_b1 (28). `_GRID_ROW_RE` does not match a row index followed by a list. `show()` crops (150-cell limit): 138 rows, mostly 136b0064_b0 (6 calls) and bf45cf4b_b0 (9 calls, solved) |
| R6-P1 short prompt | Provisional transform + check early | **Did not change the behaviour** | See V1: most branches inspect and think, then do not write a transform |
| R6-P2 resumes | Truthful, state-aware openers | **Worked mechanically** | first 16, continue 45, length 5, partial 5, verified 1. Cut / rejected / timeout / no-tool states not reached |
| R6-P3 generalization note | Once, after the first verified candidate | **Not testable** | Sent only in the 2 solved branches (both submitted) |
| T6 nudge | Replace Duck's "Investigate first" | **Not exercised** | `nudges_replaced` 0 |
| R6-K1 auto-check | Check every new `transform*` | **Worked, rarely triggered** | 2 calls (898e7135_b0 `transforms` 0/2; bf45cf4b_b0). Few transforms were written |
| R6-K2 `check_many` | Several variants in one call | **Not used** | 0 calls |
| R6-K3 verify cache / caps | Dedupe, separate caps | **Worked** | 2 verified, 1 duplicate skipped, 0 cap hits; verify 0.86 s p50 |
| Rev 5 B1 harvest | Keep exact `check()` candidates | **Worked** | 2 signalled, 2 verified, 2 accepted |
| Rev 5 B2 selection | Two distinct attempts | **Not exercised** | Never more than 1 candidate per task |
| Rev 5 B3 estimate | Real token count of history | **Worked** | estimate/actual prompt tokens p50 0.998 |
| Rev 5 B6 / R5-2 cut calls | A cut call is never executed | **Not exercised** | `cut_tool_calls_dropped` 0 |
| R6-S1 first exposure | Every task gets branch 0 first | **Worked** | 12/12 exposed, stage-1 left 0; the planned order is the report's `order` field (ORDER2 sort); the actual start order per branch is not logged separately |
| R6-Q2 soft pause at 28k | Bound the first exposure | **Worked** | Overshoot p50 5.1k, max 15.8k (136b0064_b0 43.8k) |
| R6-S2 stage-2 classes + b1 grids view | Second hypothesis where needed | **No yield here** | 4 b1 starts, all class 1 (no candidate). **0 new verified candidates in 123,560 tokens.** First tool call in b1 at 12.4–18.0k, so every b1 first request (12,288 cap) was cut with no call |
| R6-S3 fair share | Spread stage-2 compute | **Mechanical** | Shares 7,544 → 3,758 tokens, below the 24,576 minimum chunk, so every stage-2 run got about 24.6k + overshoot |
| R6-S4 progress signal | Partial progress to scheduler and model | **Exercised once** | 247ef758_b0: best single function 1/3 pairs, cell accuracy 0.771, 5 partial resumes, still no solve |
| **R6-S5 capacity probe** | Step down only under real pressure | **BUG** | See section 5, bug 1 |
| R6-S6 deadline | Never overrun | **Worked** | 91 request timeouts clamped, 0 stragglers, finished 9 s before the deadline |
| R6-Q1 request caps | Short requests, continuation | **Mixed** | 12,288 × 20, 24,576 × 160. Length cut with no call: 7 (all 4 b1 first requests, f931b4a8_b0 2, 136b0064_b0 1). In the facts view the cap rarely binds |
| R6-D1 window / reserve | Window = KV / 12 | **Conservative** | Window 72,228 per stream; KV usage never above 0.44 in this run; 4 resume rewrites after trims, 1 reasoning-only block trimmed |
| R6-D2 prefix-cache invariants | Keep the cache high | **Worse than rev 5** | 75 % vs 85–91 %. **15 of 180 later requests had < 5 % cached** in 9 branches; only 2 of those branches had a trim. Unexplained (section 7, Q4) |
| R6-X1 serving diagnostics | Isolation, drafter config, parity | **Worked** | Isolation PASS 12/12; drafter `target_layer_ids` [5, 19, 33, 47, 61]; parity control 2/2 identical |
| R6-M1 metrics | Measure everything | **Mostly worked** | `hand_reading_grid_row_share` 0.0038 misses prose hand-reading ("row2: col3, col5"); the metric needs a better definition |

## 5. Bugs found in this run (ours)

1. **Capacity probe false step-down (R6-S5), 12 → 10 → 8 → 6 workers in 13 minutes.**
   - **The rule:** "requests queued at the server in 3 consecutive 60-s probes" (rev 6d added retraction and KV ≥ 0.98 triggers).
   - **The data:** queue = 1 with 11 running is SGLang's steady state at 12 in flight. G4B: 189 of 710 batch lines have queue ≥ 1 at running 10–11, with KV ≤ 0.35. E11-05: 2,601 of 2,816 at running 10–11.
   - **The second flaw:** there is no cooldown. The allowed count only gates new admissions, so the probe stepped down again before the previous step took effect.
   - **The cost:** decode was 370–406 tok/s at 11 running vs about 321 at 6.
   - **Why the tests missed it:** the fake-server "healthy" fixture used queue = 0, our assumption rather than a measured value.
   - **User decision (2026-10-21):** replace the probe with one rule: **no new task or branch is admitted while KV usage ≥ 0.95**. Workers stay at 12; no step-down logic.
   - **Replay on 7 logs** (`analysis/kv_queue_scan_output.txt`): the rule would hold back only in E12 EVAL30 rev 1 (291 of 4,153 lines; the real KV-thrash run), never in the others (KV max 0.43–0.73). Mamba usage max 0.71 everywhere.
   - **Please review:** where to read the metric, the poll interval, fail-open when metrics are missing, and whether mamba usage must be gated too.
2. **Print-guard leak (R6-V4):** rows printed with a leading row index (`print(r, row)`) bypass `_GRID_ROW_RE`. 173 rows reached the model (section 4).
3. **Measurement-script gap (bundle only):** `tests/facts_size.py` must run with `E12_TOKENIZER_JSON` set, otherwise the adapter's fallback of 1.9 chars/token gives a looser bound (p50 757 / max 1,005 instead of 699 / 798). The bundled copy now sets it. On Kaggle the tokenizer loaded (`configuration.e12.rev5_tokenizer.loaded = true`).

## 6. Throughput and coverage (measured; projections inferred)

| Running | Decode tok/s (median by context) |
|---|---|
| 11 | 406 (< 10k), 404 (10–20k), 371 (20–40k) |
| 12 | 226 / 194 / 258, 29 lines only (unexplained, Q5) |
| 8 | 357 |
| 6 | 321 |
| 4 | 240 |
| 2 | 160 |

From `e11.decode_summary.by_context`.

Stage-1 runs took 909–1,511 s each (19–44k tokens; `rev6.scheduler.durations`), i.e. about 21–35 tok/s per stream.

**Hidden-run arithmetic (inferred):**
- 11.3 h × 3,600 × 370 tok/s / 240 tasks ≈ 63k tokens per task.
- Stage 1 alone at about 33k per task = 7.9M tokens ≈ 5.9 h.

## 7. Open questions

1. **Why do 7 of 12 facts-view branches never write a `transform`** in 29–59k tokens, although the first call comes after 46 tokens?
   - Read the transcripts: what is the model doing in the long thinks (p90 25.6k chars per request)?
   - What concretely would make it write and check a candidate within 10–20k tokens?
2. **Is the facts view a net win?** At the same token budget it solved 2 vs rev 5's 1 (xhigh) / 3 (low). Should branch 0 show grids, both views, or a different representation (e.g. a compact indexed grid)?
3. **Branch 1 in the grids view yielded nothing** (0 new candidates, 123k tokens) and its first 12,288-token request was always cut without a call. Keep, change or drop it under the hidden-run budget?
4. **Prefix cache:** why do 15 later requests show < 5 % cached while KV usage is ≤ 0.44?
   - Hypothesis (inferred): the mamba state cache (56 slots, 4 per running request, mamba usage up to 0.70, `--mamba-radix-cache-strategy` extra_buffer_lazy) evicts the SSM states of paused or idle conversations, so their prefix cannot be reused.
   - Verify from the logs and SGLang 0.5.21 source if you can, and say what to change.
5. **Why is decode at exactly 12 running slower** (194–258 tok/s) than at 11 (370–406)? Is 12 the right concurrency, or 11, or more with a different mamba cache size?
6. **The capacity rule** (section 5, bug 1): implementation details only.
7. **The biggest lever** from 2/19 at about 48k tokens per task toward a hidden LB of 60+, with full coverage, on this stack. Rank your top 3 with evidence from these transcripts.
8. **Anything in our code or outputs that is wrong** and that we did not list.

## 8. File map

| Path | What |
|---|---|
| `duck_arc2/arc2_duck.py` | **The adapter, rev 6d** (sha256 prefix `7c60454c`), embedded unchanged in all three notebooks. Everything rev 6 sits behind `E12_ARC2_REV6=1` |
| `duck_arc2/vendor/` | Vendored Duck (`inference/…`), unchanged since rev 4 |
| `source/build_e12_duck.py` | The notebook builder (CELL 6 scheduler wiring, preflight, probe; CELL 7 report) |
| `source/diffs/` | `arc2_duck` rev 5 → 6d and rev 6c → 6d; builder rev 6c → 6d |
| `source/history/` | Full rev 5 and rev 6c adapter, rev 6c builder |
| `notebooks/` | EVAL12R6G4B (ran), EVAL12R6 (150-min unconstrained profile, not run), PARITYR6 (diagnostic, not run, NO-GO) |
| `runs/rev6d_EVAL12R6G4B/` | **This run:** `e12_run_report.json`, `e12_generated_attempts.json`, `submission.json`, `kernel_log.txt`, `sglang_server_try0.log`, `sglang_decode_summary.json`, `sglang_requests.jsonl`, and `duck/<task>_b<k>/` (`transcript.txt` = the full thinking and every tool call/result, `branch_result.json`, `prompts/`) |
| `runs/rev5_EVAL6R5_xhigh/`, `runs/rev5_EVAL12R5_low/`, `runs/rev4_EVAL6_xhigh/` | Earlier runs on the same tasks, same layout |
| `runs/server_logs_12_streams/` | SGLang logs of three earlier 12-stream runs (E11-05, E11-06, E12 EVAL30 rev 1) for the capacity question |
| `data/` | The 12 tasks and their solutions (analysis only) |
| `analysis/` | `g4b_fix_evidence.py`, `compare_rev5_vs_g4b.py`, `kv_queue_scan.py` and their outputs (`python <script> .` from the bundle root); `inputs/` = rev 5 first-check data and analysis outputs |
| `docs/` | Running fix list (all audits and decisions), G4B analysis, rev 5 analysis, weakness analysis, verbatim GPT prompt drafts, the problem → fix map (Bengali) |
| `tests/` | Unit checks, notebook harness, fake SGLang server, fixtures (Qwen INT4 + FP8 tokenizers, eval data), `recorded_outputs/` |

## 9. Tests (run from this bundle on 2026-10-21; Windows, Python 3.12, `tokenizers` 0.22)

```
cd tests
python smoke_adapter.py      # 41/41  (rev 5 and 6 off: legacy behaviour)
python smoke_rev5.py         # 56/56
python smoke_rev6.py         # 104/104 (rev 6d: facts, helpers, auto-check, guard, resumes, scheduler sim, deadline, isolation, probe)
python regex_check.py        # ALL OK
python facts_size.py         # 120 eval tasks: bounded facts p50 699 / p90 779 / max 798 tokens
python replay_rev6.py ../runs/rev5_EVAL6R5_xhigh/duck ../data/eval_challenges_12.json ../data/eval_solutions_12.json out.jsonl
                             # recorded rev 5 tool calls through the rev 6d agent: identical to recorded_outputs/replay_rev6d_xhigh.log
python harness_e12_rev4_nb.py ../notebooks/Q27-XHIGH-E12_DUCK_REPL_SGLANG_EVAL12R6G4B.ipynb g4b   # 46/46
python harness_e12_rev4_nb.py ../notebooks/Q27-XHIGH-E12_DUCK_REPL_SGLANG_EVAL12R6.ipynb r6       # 45/45
```

- **Linux:** the Windows-only shims in the harness and the smoke tests are skipped automatically.
- **What the tests do not cover:** the real model and server. The fake server is scripted, and the capacity bug above shows what that misses.
