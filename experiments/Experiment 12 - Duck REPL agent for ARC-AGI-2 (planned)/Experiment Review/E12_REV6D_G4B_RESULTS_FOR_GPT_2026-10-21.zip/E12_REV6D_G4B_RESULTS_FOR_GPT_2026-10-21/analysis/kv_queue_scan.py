"""SGLang server-log scan: queue vs running vs KV / mamba usage, for every server log in the bundle.
(a) shows that queue >= 1 is the steady state at 12 in flight (11 running + 1 queued), so 'queue > 0' is no pressure
signal (the rev 6d capacity-probe bug); (b) replays the user's simple admission rule 'no new task while KV usage >= 0.95'
(column 'KV>=0.95' = in how many logged batches the rule would have held new tasks back).
Uses every prefill and decode line that carries '#running-req', '#queue-req' and 'full token usage'.
Usage: python kv_queue_scan.py <bundle_root>"""
import re
import sys
from pathlib import Path

root = Path(sys.argv[1] if len(sys.argv) > 1 else ".")
F = {k: re.compile(p) for k, p in {"run": r"#running-req: (\d+)", "queue": r"#queue-req: (\d+)",
                                   "kv": r"full token usage: ([\d.]+)", "mamba": r"mamba usage: ([\d.]+)"}.items()}
logs = sorted(root.glob("runs/*/sglang_server_try0.log")) + sorted(root.glob("runs/server_logs_12_streams/*.log"))
print("log | batch lines | max running | KV usage p50/p90/max | lines KV>=0.95 | mamba max | lines queue>=1 | "
      "queue>=1 by running | KV max while queue>=1")
for f in logs:
    rows = []
    for ln in open(f, encoding="utf-8", errors="replace"):
        m = {k: p.search(ln) for k, p in F.items()}
        if m["run"] and m["queue"] and m["kv"]:
            rows.append((int(m["run"].group(1)), int(m["queue"].group(1)), float(m["kv"].group(1)),
                         float(m["mamba"].group(1)) if m["mamba"] else 0.0))
    if not rows:
        continue
    kv = sorted(r[2] for r in rows)
    n = len(kv)
    q = [r for r in rows if r[1] >= 1]
    by = {}
    for r in q:
        by[r[0]] = by.get(r[0], 0) + 1
    print(f"{f.relative_to(root).as_posix()} | {n} | {max(r[0] for r in rows)} | "
          f"{kv[n // 2]:.2f}/{kv[int(.9 * n)]:.2f}/{kv[-1]:.2f} | {sum(k >= .95 for k in kv)} | "
          f"{max(r[3] for r in rows):.2f} | {len(q)} | {dict(sorted(by.items()))} | "
          f"{max((r[2] for r in q), default=0):.2f}")
