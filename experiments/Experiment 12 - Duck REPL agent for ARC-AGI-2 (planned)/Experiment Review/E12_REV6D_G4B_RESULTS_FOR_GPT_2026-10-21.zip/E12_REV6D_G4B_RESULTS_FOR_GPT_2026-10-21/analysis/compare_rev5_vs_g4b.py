"""Per task: rev 5 (xhigh EVAL6R5, low EVAL12R5) vs rev 6d G4B, on the same tasks.
For every branch-0: first check() tokens, first host-verified candidate, first CORRECT candidate (test outputs == truth),
and a token-matched question: would rev 5's branch 0 have had a correct candidate within the tokens G4B's branch 0 used?
Usage: python compare_rev5_vs_g4b.py <bundle_root>   (reads runs/ and data/ inside the bundle)"""
import json, sys
from pathlib import Path

root = Path(sys.argv[1] if len(sys.argv) > 1 else ".")
sol = json.loads((root / "data/eval_solutions_12.json").read_text())
pre = json.loads((root / "analysis/inputs/precheck_behaviours.json").read_text())   # rev 5 first-check tokens per branch
RUNS = {"r5_xhigh": root / "runs/rev5_EVAL6R5_xhigh", "r5_low": root / "runs/rev5_EVAL12R5_low", "g4b": root / "runs/rev6d_EVAL12R6G4B"}


def branches(run):
    out = {}
    for p in sorted((run / "duck").glob("*_b*/branch_result.json")):
        d = json.loads(p.read_text())
        out[(d["task_id"], int(d["branch"]))] = d
    return out


def correct(task, outs):
    t = sol[task]
    return outs is not None and len(outs) == len(t) and all(o == s for o, s in zip(outs, t))


def cands(d):
    rows = [c for c in (d.get("checked") or []) + (d.get("submissions") or []) if c.get("accepted")]
    return sorted(rows, key=lambda c: c.get("tokens") or 0)


def solved(run):
    rep = json.loads((run / "e12_run_report.json").read_text())
    hits = {}
    for u in rep["eval_unit_records"]:
        hits.setdefault(u["task"], []).append(bool(u["hit"]))
    return {t: (sum(h), len(h)) for t, h in hits.items()}


B = {k: branches(v) for k, v in RUNS.items()}
S = {k: solved(v) for k, v in RUNS.items()}
FC = {"r5_xhigh": {r["branch"]: r["first_check"] for r in pre["xhigh"]},
      "r5_low": {r["branch"]: r["first_check"] for r in pre["low"]}}
g4b_rep = json.loads((RUNS["g4b"] / "e12_run_report.json").read_text())
tasks = g4b_rep["order"]

hdr = ("task", "G4B b0 tok", "G4B b0 1st check", "G4B solved", "r5x b0 1st check", "r5x b0 1st correct", "r5x solved",
       "r5x correct<=G4B tok", "r5l b0 1st check", "r5l b0 1st correct", "r5l solved", "r5l correct<=G4B tok")
print(" | ".join(hdr))
agg = {"r5_xhigh": [0, 0], "r5_low": [0, 0]}
for t in tasks:
    g = B["g4b"].get((t, 0))
    gtok = g["generated_tokens"] if g else 0
    gfc = (g.get("rev6_events") or {}).get("first_check_tokens") if g else None
    row = [t, gtok, gfc, "%d/%d" % S["g4b"].get(t, (0, 0))]
    for k in ("r5_xhigh", "r5_low"):
        d = B[k].get((t, 0))
        if d is None:
            row += ["-", "-", "-", "-"]
            continue
        fc = FC[k].get(f"{t}_b0")
        first_ok = next((c["tokens"] for c in cands(d) if correct(t, c.get("test_outputs"))), None)
        within = first_ok is not None and first_ok <= gtok
        agg[k][0] += 1
        agg[k][1] += int(within)
        row += [fc, first_ok, "%d/%d" % S[k].get(t, (0, 0)), "yes" if within else "no"]
    print(" | ".join(str(x) for x in row))
for k, (n, w) in agg.items():
    print(f"{k}: tasks with branch 0 = {n}; branch 0 had a correct candidate within G4B's branch-0 tokens on {w}")
print("G4B solved inputs:", g4b_rep["eval_query_hits"], "/", g4b_rep["eval_query_total"])
