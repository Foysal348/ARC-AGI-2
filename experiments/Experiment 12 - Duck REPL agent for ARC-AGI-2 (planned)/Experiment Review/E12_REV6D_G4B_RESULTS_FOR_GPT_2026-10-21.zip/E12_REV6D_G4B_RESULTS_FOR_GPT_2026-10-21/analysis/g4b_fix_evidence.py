"""Per-branch evidence for every rev 6 fix from the G4B run (runs/rev6d_EVAL12R6G4B).
Usage: python g4b_fix_evidence.py <bundle_root>
Sections: (1) per-branch rev 6 counters from e12_run_report.json; (2) tool usage and (3) the grid-print guard per branch,
from the transcripts: rows hidden vs grid rows that reached the model with a row-index prefix ('0 [0, 0, ...]', which
_GRID_ROW_RE does not match); (4) reasoning size per request (from [MODEL RESPONSE META]); (5) later requests with < 5 %
of the prompt cached; (6) the run-level rev 6 metrics and scheduler record."""
import glob
import json
import os
import re
import statistics as st
import sys
from pathlib import Path

root = Path(sys.argv[1] if len(sys.argv) > 1 else ".")
run = root / "runs/rev6d_EVAL12R6G4B"
r = json.loads((run / "e12_run_report.json").read_text())
src = (root / "duck_arc2/arc2_duck.py").read_text(encoding="utf-8")
GR = re.compile(re.search(r'_GRID_ROW_RE = re\.compile\(r"(.*?)"\)\n', src).group(1))
IDX = re.compile(r"^\s*(?:row\s*)?\d+\s*[:\]]?\s*[\[\(]\s*\d+(?:\s*,\s*\d+){2,}\s*[\]\)],?\s*$", re.I)
SHOWROW = re.compile(r"^\s*r\d+\s*\|")
CALL = re.compile(r"\[TOOL CALL: python\]\n<tool_call>\n<function=python>\n<parameter=code>\n(.*?)\n</parameter>", re.S)
RES = re.compile(r"\[TOOL RESULT: python\]\n(.*?)(?=\n\[(?:THINKING|TOOL CALL|USER PROMPT|ASSISTANT|ANALYZER STATUS|"
                 r"MODEL RESPONSE META|SYSTEM PROMPT)\])", re.S)
META = re.compile(r"\[MODEL RESPONSE META\]\nfinish_reason: (\w+)\n.*?reasoning_chars: (\d+)", re.S)
HELPERS = ("arc_overview", "inspect_pair", "inspect_test", "show", "components", "objects", "object_diff", "grid_diff",
           "diff_summary", "color_counts", "bbox", "crop", "grid_summary", "check_many")

print("== (1) per-branch counters (report)")
print("branch | view | status | gen tok | requests | first tool tok | first check tok | exact checks | autocheck | "
      "rows hidden | length cut, no call | resumes | caps | verified/kept | submitted | accepted | "
      "best single fn (name pairs cell-acc) | stage2 class | overfit | runs (stage, tokens, status, overshoot)")
for b in r["branches"]:
    e, pb = b["rev6_events"], b.get("progress_best") or {}
    runs = [(x["stage"], x["tokens"], x["status"], x.get("overshoot")) for x in b["runs"]]
    print(" | ".join(str(v) for v in (
        f"{b['task']}_b{b['branch']}", b["view"], b["status"], b["generated_tokens"], b["usage"]["requests"],
        e["first_tool_tokens"], e["first_check_tokens"], b["rev5_events"]["checks_signalled"], e["autocheck_calls"],
        e["grid_rows_suppressed"], e["length_cut_no_call"], e["resumes"], e["caps"],
        f"{b['checked_verified']}/{b['checked_kept']}", b["submissions"], b["accepted"],
        f"{pb.get('name')} {pb.get('k')}/{pb.get('n')} {pb.get('acc')}", b["stage2_class"], b["overfit_flags"], runs)))

print("\n== (2)+(3)+(4) per branch: tool usage | grid-print guard | reasoning chars per request")
tot = {"index_prefixed_rows_shown": 0, "show_rows": 0, "guard_notes": 0, "rows_hidden": 0}
allrc = []
for f in sorted(glob.glob(str(run / "duck/*/transcript.txt"))):
    t = open(f, encoding="utf-8", errors="replace").read()
    name = os.path.basename(os.path.dirname(f))
    calls, res = CALL.findall(t), RES.findall(t)

    def cnt(pat):
        return sum(len(re.findall(pat, c)) for c in calls)

    tf = sorted({m for c in calls for m in re.findall(r"^def ((?:transform|solve)\w*)", c, re.M)})
    hel = {h: cnt(r"\b" + h + r"\(") for h in HELPERS}
    lines = [ln for x in res for ln in x.split("\n")]
    idx = sum(bool(IDX.match(ln)) for ln in lines)
    shw = sum(bool(SHOWROW.match(ln)) for ln in lines)
    notes = [int(m) for x in res for m in re.findall(r"\[\.\.\. (\d+) more grid rows not shown", x)]
    nested = sum(x.count("(nested list)") for x in res)
    tot["index_prefixed_rows_shown"] += idx
    tot["show_rows"] += shw
    tot["guard_notes"] += len(notes) + nested
    tot["rows_hidden"] += sum(notes) + nested
    m = META.findall(t)
    rc = [int(x[1]) for x in m]
    allrc += rc
    fin = {}
    for x in m:
        fin[x[0]] = fin.get(x[0], 0) + 1
    used = ", ".join(f"{k}: {v}" for k, v in hel.items() if v)
    print(f"{name}: calls {len(calls)} | print() {cnt(r'\bprint\(')} | defs {cnt(r'(?m)^def \w+')} | "
          f"transform/solve defs {tf} | check calls {cnt(r'\bcheck(?:_many)?\(')} | helpers {{{used}}} || "
          f"index-prefixed grid rows that reached the model {idx} | show() rows {shw} | "
          f"guard notes {len(notes) + nested} hiding {sum(notes) + nested} rows || "
          f"reasoning chars/request p50 {int(st.median(rc)) if rc else 0} max {max(rc) if rc else 0} "
          f"total {sum(rc)} | finish {fin}")
print("totals:", tot)
print("guard regex (_GRID_ROW_RE):", GR.pattern)
print(f"all {len(allrc)} requests: reasoning chars p50 {st.median(allrc)} p90 {sorted(allrc)[int(.9 * len(allrc))]} "
      f"max {max(allrc)}")

print("\n== (5) later requests (index > 0) with < 5 % of the prompt cached")
n0 = 0
for b in r["branches"]:
    c = b["usage"]["cached_pct_by_request"]
    z = [i for i, x in enumerate(c) if i > 0 and x < 5]
    n0 += len(z)
    if z:
        print(f"{b['task']}_b{b['branch']}: requests {len(c)} | low-cache request indices {z} | "
              f"resume_rewritten_after_trim {b['rev5_events'].get('resume_rewritten_after_trim')} | runs {len(b['runs'])}")
print("total:", n0, "of", sum(len(b["usage"]["cached_pct_by_request"]) for b in r["branches"]), "requests")

print("\n== (6) run-level rev 6 metrics and scheduler")
print(json.dumps(r["rev6"]["metrics"], indent=1))
print("scheduler:", json.dumps(r["rev6"]["scheduler"]))
print("e12_run:", json.dumps({k: v for k, v in r["e12_run"].items() if k not in ("rev6_scheduler",)}))
print("decode summary:", json.dumps(r["e11"]["decode_summary"]))
