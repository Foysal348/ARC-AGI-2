# Rev 6 problem → fix map (Bengali, as given to the user 2026-10-21; the user asked to check every row against the code)

Rev 6-এর প্রতিটা fix কোন মাপা সমস্যার সমাধান করবে, নিচে সাজিয়ে দিলাম।

## ক. Model হাতে গোনে, দেরিতে code চালায় (মূল সমস্যা)
| সমস্যা (মাপা) | Fix | কী আশা করছি |
|---|---|---|
| ৩৬টার মধ্যে ৩৫টা branch-এ হাতে grid পড়া আর ভুল গোনা। প্রথম check() আসে প্রায় ৫৫k-তে | R6-V1: prompt-এ লেখা grid থাকবে না, পুরো grid থাকবে Python-এ। R6-V2: system prompt-এ গুনে রাখা fact block | হাতে গোনার মতো কিছুই সামনে থাকবে না। প্রথম check ২৫k-র মধ্যে আনার লক্ষ্য |
| হিসাবগুলো model নিজে বের করে (component, diff, bbox) | R6-V3: তৈরি helper (components, diff_summary, crop, inspect_pair …) | এক লাইন code-এ সঠিক হিসাব |
| grid লুকালে model নিজেই পুরো grid print করবে, তারপর আবার হাতে পড়বে | R6-V4: show()/crop helper আর ARC-2-এর জন্য grid print guard | হাতে পড়া tool output দিয়ে ফিরে আসতে পারবে না |
| "code লিখব" বলেও চিন্তা চালিয়ে যায় (xhigh-এ ৩৭ %, low-এ ২০ % token)। প্রথম reply-তেই tool ছাড়া p50 ৩৩.৬k | R6-Q1: ছোট request (১২,২৮৮, তারপর ২৪,৫৭৬), আগের চিন্তা রেখে চালিয়ে যাওয়া। R6-P2: "এখন python চালাও" ধরনের ছোট আদেশ | চিন্তা মাঝপথে থামিয়ে code চালানোর সুযোগ। মোট চিন্তা ৬০k বা তার বেশিই থাকবে |
| rule পেয়েও check দেরিতে করে। test output হাতে simulate করে, p['output']-এর সাথে নিজে মেলায় | R6-P1: ছোট prompt ("দুটো rule মিললে দুটোই check করো")। R6-K1: নতুন transform লিখলেই check নিজে থেকে চলবে | rule আর তার যাচাইয়ের মাঝের ফাঁক কমবে |
| দুটো variant হাতে তুলনা করে। error-এর loop (sys import, IndexError) | R6-K2: check_many, আগে রায়, তারপর বিস্তারিত, কোন লাইনে error তা দেখানো | debug-এ কম call লাগবে |

## খ. সঠিক উত্তর পাওয়া গেলেও হারিয়ে যায়
| সমস্যা | Fix | কী আশা করছি |
|---|---|---|
| transform_alt, transform2 লেখা হয়েছিল, কিন্তু কখনো check বা harvest হয়নি | R6-K1: transform নামের সব function auto-check হবে | বিকল্প উত্তরও portfolio-তে ঢুকবে |
| ২৪টার যাচাইয়ের সীমা আগেই শেষ হয়, পরে আসা সঠিক উত্তর হারায় | R6-K3: source দিয়ে dedupe, শুধু host-এর রায় cache-এ রাখা, auto-check আর হাতে check-এর আলাদা সীমা | দেরিতে আসা সঠিক উত্তর (135a2760, 898e7135) রক্ষা পাবে |
| দেরিতে সংশোধন হওয়া উত্তর (৭১k থেকে ৯৮k) | প্রথম train-exact পেলেই থামানো হবে না (KEEP) | — |
| Trim হলে tool-এর ফল হারায়, তারপর overfit উত্তর accept হয় (4c3d4a41 low) | R6-D1: reserve = আসল সীমা। R6-D3: tool call আর result জোড়ায় রাখা। R6-S5: ৫৫–৬৭k-এ trim | context হারানো কমবে |

## গ. ভুল বা বিভ্রান্তিকর নির্দেশ
| সমস্যা | Fix |
|---|---|
| candidate রাখা হয়ে গেলেও বলে "Nothing has been submitted yet" | R6-P2: অবস্থা বুঝে সত্যি কথা বলা resume |
| Duck বলে "Investigate first", আমরা বলি "আগে কাজ করো", দুটো উল্টো | R6-P2: লেখাটা বদলানো |
| এক সময়ে একাধিক nudge, পরস্পরবিরোধী | R6-P1/P2/P3: অগ্রাধিকার ক্রমে একটাই message, advice নয়, fact |

## ঘ. Overfit (train-এ মেলে, test-এ ভুল; প্রায় ⅓)
| সমস্যা | Fix |
|---|---|
| 4c3d4a41-এ +10 offset। model নিজেই সন্দেহ করেও accept করেছে | R6-P3: প্রথম verified উত্তরের পর একবার generalization মনে করানো (নিজে থেকে বাতিল নয়) |
| দুটো branch-ই একই ভুলে পড়ে | R6-S2: একটা verified উত্তর থাকলেও branch 1-এর সুযোগ। branch 1 আলাদা view দেখবে (লেখা grid বা CSV) |
| কোন উত্তর overfit, তা বোঝার উপায় নেই | R6-M1: label ছাড়াই overfit-এর লক্ষণ (train-এর literal, fixed offset, source-এর দৈর্ঘ্য, branch-গুলোর মিল) |

## ঙ. Coverage (প্রতি task-এ ৯–১০ মিনিট, দরকার ২.৮)
| সমস্যা | Fix | কী আশা করছি |
|---|---|---|
| একই task-এর দুই branch একসাথে চলে, পরের task অপেক্ষা করে | R6-S1: আগে সব task-এর branch 0, ORDER2 ক্রমে | ২৪০টা task-ই সুযোগ পাবে |
| দুই branch-এ একই কাজ দুবার (bf45cf4b, f931b4a8) | R6-S2: branch 1 শুধু দরকার হলে | পুরনো রেকর্ডে replay: token ৩৭–৪১ % কম, score প্রায় একই |
| বাজেটের কোনো হিসাব নেই। ১০০k-র নরম সীমা ১৫৯k পর্যন্ত গেছে | R6-S3: ন্যায্য ভাগ, সীমা পেরোনো হিসাবে ধরা। R6-S4: অগ্রগতির সংকেত। R6-Q2: প্রথম সুযোগ ২৫–৩০k | — |
| Scheduler-এর ফাঁদ: attempt-major করলে ৪৮০টা branch একসাথে চালু হয়ে যায় | R6-S1: ক্রম, worker সংখ্যা আর অগ্রাধিকার আলাদা setting | EVAL30-এর মতো KV thrash হবে না |

## চ. Throughput (২৪৪–২৬৫ tok/s)
| সমস্যা | Fix |
|---|---|
| ১২টা চালানোর ক্ষমতা থাকলেও চলে ৬টা stream। ১২টার জায়গায় ১১টা চলার bug | R6-S5: পরীক্ষা করে ১০টা stream, দরকারে ৮, তারপর ৬ |
| prefill তৈরি হওয়া token-এর চেয়েও বেশি (০.৯৭M বনাম ০.৮৫M) | R6-D2: prompt স্থির রাখা, state-এর লেখা শুধু শেষে যোগ, deterministic fact |
| DFlash ঠিক output দিচ্ছে কি না, একাধিক request-এর লেখা মিশে যাচ্ছে কি না | R6-X1: isolation পরীক্ষা, target_layer_ids যাচাই, control রেখে parity পরীক্ষা |

## ছ. Deadline (hidden run-এ সবচেয়ে বড় ঝুঁকি)
| সমস্যা | Fix |
|---|---|
| EVAL30 deadline-এর ৬৭৯ সেকেন্ড পরে শেষ হয়েছিল। turn-এর timeout পরের request-গুলোতেও চলতে থাকে, rev 5-এ সবচেয়ে খারাপ ক্ষেত্রে প্রায় ৩০ মিনিট দেরি | R6-S6: প্রতিটা request আর যাচাইয়ের timeout deadline দিয়ে সীমিত, submission লেখার জন্য আলাদা সময় |

## জ. নতুন fix-গুলো যেন নিজেই ভেঙে না দেয় (P0 ফাঁদ)
| নতুন fix-এর ঝুঁকি | সমাধান |
|---|---|
| helper ব্যবহার করা transform যাচাইয়ে বাতিল হবে (T1) | helper-এর trusted source retention আর যাচাই দুই জায়গাতেই দেওয়া |
| fact block trim-এ মুছে যাবে (T2) | system prompt-এ রাখা |
| auto-check-এর জন্য serializer spoof-এর ফাঁক আবার খুলবে | শুধু host-এর রায় বিশ্বাস করা (R6-K3) |
| থামানো branch আবার চালু করলে state হারাবে | একই agent object রাখা (R6-Q2-এর শর্ত) |

## ঝ. মাপজোখ
| সমস্যা | Fix |
|---|---|
| EVAL6/12-এর score noise (একই code-এ ২, ২, ৩, ১) | R6-M1: সিদ্ধান্ত নেওয়া হবে প্রতি GPU-ঘণ্টায় সঠিক উত্তর, প্রথম check-এর token, হাতে পড়ার ভাগ আর oracle দিয়ে। gate 4b: hidden-এর সমান বাজেটে eval |

The status of every row (built / added in rev 6b / not built + reason) is in the fix list, section "Rev 6b".
