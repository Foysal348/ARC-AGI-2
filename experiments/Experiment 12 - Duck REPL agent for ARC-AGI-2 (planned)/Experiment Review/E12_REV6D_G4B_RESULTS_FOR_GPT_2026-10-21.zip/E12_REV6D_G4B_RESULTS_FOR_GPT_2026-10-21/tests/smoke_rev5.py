"""Rev 5 unit checks for arc2_duck (E12_ARC2_REV5=1), real Duck sandbox, no server. Our own scripted code only, plus
one recorded EVAL6 reasoning text (62593bfd_b1, first reply) for the B3/B4 reproduction."""
import json
import os
import re
import sys
from pathlib import Path

os.environ["E12_ARC2_REV5"] = "1"
os.environ["E12_DUCK_MAX_OUTPUT"] = "60000"            # B3/B4 reproduce the EVAL6 budget (70,560) exactly
os.environ["E12_DUCK_TEMPERATURE"] = "1.0"
os.environ["E12_CHECK_VERIFY_CAP"] = "4"
TOK = Path(str(Path(__file__).resolve().parent / "fixtures") + r"/tok_int4/tokenizer.json")
os.environ["E12_TOKENIZER_JSON"] = str(TOK)
_HERE = Path(__file__).resolve().parent
src = open(_HERE / "smoke_adapter.py", encoding="utf-8").read().split("# 1 system prompt carries the task")[0]
exec(src)                                              # same setup as smoke_adapter.py: A, TA, Agent, task, ag, run, expect

# ---- B9 / B5 config
env = A.duck_env("http://x/v1", "m", 6)
expect("B9 temperature 1.0 in Duck env", env["LOCAL_ANALYZER_TEMPERATURE"] == "1.0", env["LOCAL_ANALYZER_TEMPERATURE"])
expect("B5 output from env", env["LOCAL_ANALYZER_MAX_OUTPUT"] == "60000")

# ---- B7/B8 prompt
sp = ag._system_prompt
expect("B7 old 'Investigate until' line gone", "Investigate until your code has a clear plan" not in sp)
expect("B7 code-first + lookup + alternatives present",
       "rather than counting cells or simulating" in sp and "lookup table or case" in sp and "disagree on a test input" in sp)
expect("B8 train usage example", "for p in train: inp, out = p['input'], p['output']" in sp)
expect("B1 prompt tells the model check() keeps candidates", "keeps it as a candidate answer" in sp)
bad = [w for w in (r"current_frame", r"action\(actions\)", r"(?<!top-)\blevel\b", r"\bgame", r"segmentation", r"RESET")
       if re.search(w, sp)]
expect("no game words in the rev 5 prompt", not bad, bad)
off = A.arc2_system_prompt(task, DP, 3072, rev5=False)
expect("rev 5 off -> prompt has the old text", "Investigate until your code has a clear plan" in off and "keeps it as a candidate" not in off)
expect("rev 5 off -> prelude without the hook", A.CHECK_PREFIX not in A.task_prelude(task) and A.CHECK_PREFIX in A.task_prelude(task, rev5=True))

# ---- B1 harvesting
r, p = run("def transform(g):\n    return [list(reversed(x)) for x in g]\ncheck(transform)")
expect("B1 exact check -> kept as candidate", len(ag.arc2_checked) == 1 and ag.arc2_checked[0]["accepted"]
       and "Kept `transform`" in r.content, (ag.arc2_checked, r.content[-400:]))
expect("B1 branch NOT stopped by a check", ag.arc2_accepted is None and not r.step_executed)
expect("B1 harvested test outputs are the function's", ag.arc2_checked[0]["test_outputs"] == [flip(q["input"]) for q in task["test"]])
r, p = run("check(transform)")
expect("B1 same code checked again -> no second verification", len(ag.arc2_checked) == 1
       and ag.arc2_rev5_events["checks_skipped_dup"] == 1, ag.arc2_rev5_events)
r, p = run("def transform(g):\n    out = [list(reversed(x)) for x in g]\n    return out\nres = check(transform, verbose=False)")
expect("B1 changed source + verbose=False -> verified again", len(ag.arc2_checked) == 2 and ag.arc2_checked[1]["accepted"],
       ag.arc2_checked)
r, p = run("def ident(g):\n    return g\ncheck(ident)")
expect("B1 non-exact check -> no candidate", len(ag.arc2_checked) == 2)
r, p = run("def leak(g):\n    return train[0]['output'] if g == train[0]['input'] else [list(reversed(x)) for x in g]\ncheck(leak)")
expect("B1 exact but not retained (reads train) -> rejected with a reason", len(ag.arc2_checked) == 3
       and not ag.arc2_checked[2]["accepted"] and "did not keep `leak`" in r.content, r.content[-500:])
r, p = run("def wrong(g):\n    return g\naction({'action': '" + A.CHECK_PREFIX + "wrong'})")
expect("B1 forged signal for a wrong function -> host rejects", len(ag.arc2_checked) == 4
       and not ag.arc2_checked[3]["accepted"], ag.arc2_checked[3:])
r, p = run("def t5(g):\n    return [list(reversed(x)) for x in g]\ncheck(t5)")
expect("B1 cap (4) reached -> not verified, model told", len(ag.arc2_checked) == 4 and "limit of 4" in r.content
       and ag.arc2_rev5_events["checks_skipped_cap"] == 1, r.content[-300:])
ag._arc2_check_cap = 99
r, p = run("def t6(g):\n    return [list(reversed(x)) for x in g]\ncheck(t6)\nsubmit(t6)")
expect("B1 check + submit of the same function -> verified once (submit path), branch ends",
       len(ag.arc2_checked) == 4 and ag.arc2_accepted is not None and ag.arc2_accepted["name"] == "t6", ag.arc2_checked[-1:])

# ---- B2 selection
mk = lambda name, outs, t, origin=None, ok=True: dict(name=name, accepted=ok, train_exact=[ok, ok], test_outputs=outs, t=t,
                                                      **({"origin": origin} if origin else {}))
X, Y, Z = [[1]], [[2]], [[3]]
tk = {"train": task["train"], "test": [{"input": [[0]]}]}
s = A.select_attempts_r5(tk, [{"submissions": [mk("a", [Y], 5)]}, {"submissions": [], "checked": [mk("b", [X], 3, "check")]}])
expect("B2 two branches, different exact outputs -> both attempts", {json.dumps(s[0]["attempt_1"]), json.dumps(s[0]["attempt_2"])}
       == {json.dumps(X), json.dumps(Y)}, s)
s = A.select_attempts_r5(tk, [{"submissions": [], "checked": [mk("a", [Z], 1, "check"), mk("a", [X], 9, "check")]}])
expect("B2 latest exact version of a branch first, earlier one as attempt_2", s[0]["attempt_1"] == X and s[0]["attempt_2"] == Z, s)
s = A.select_attempts_r5(tk, [{"submissions": [mk("a", [X], 1)]}, {"checked": [mk("b", [X], 2, "check")]}])
expect("B2 identical predictions deduplicated -> attempt_2 = test input", s[0]["attempt_1"] == X and s[0]["attempt_2"] == [[0]], s)
s = A.select_attempts_r5(tk, [{"submissions": [mk("p", [Y], 1, ok=False)]}])
expect("B2 only a partial program -> it is attempt_1", s[0]["attempt_1"] == Y, s)
s = A.select_attempts_r5(tk, [])
expect("B2 nothing -> test input fallback", s[0] == {"attempt_1": [[0]], "attempt_2": [[0]]}, s)
s = A.select_attempts_r5(tk, [{"checked": [mk("bad", [[[10]]], 1, "check")]}])
expect("B2 invalid grid never selected", s[0]["attempt_1"] == [[0]], s)
expect("B2 build_submission uses r5 when the flag is on",
       A.build_submission({"t": tk}, {"t": [{"checked": [mk("b", [X], 3, "check")]}]})["t"][0]["attempt_1"] == X)

# ---- B3 estimate (reproduces EVAL6 62593bfd_b1: the 60,000-token first reply was dropped at a 1.40 ratio)
TX = Path(__file__).resolve().parent.parent / "runs/rev4_EVAL6_xhigh/duck/62593bfd_b1/transcript.txt"
txt = TX.read_text(encoding="utf-8", errors="replace")
reasoning = re.search(r"\[THINKING\]\n(.*?)\n\[(?:ASSISTANT|TOOL CALL|ANALYZER STATUS|USER PROMPT|SYSTEM PROMPT|MODEL RESPONSE META)",
                      txt, re.S).group(1)
expect("B3 tokenizer counts the recorded reply as ~60,000", 59000 <= A.reasoning_tokens(reasoning) <= 61000, A.reasoning_tokens(reasoning))
ag2 = Agent(task=task, task_id="flip", branch=1, model="qwen", base_url="http://127.0.0.1:9/v1", provider="vllm")
ag2._text_chars_per_token = 1.40
sysmsg = {"role": "system", "content": "x" * 13000}           # ~9.3k tokens at 1.40, like the 62593bfd system prompt
msgs = [sysmsg, {"role": "user", "content": "Solve the task."},
        {"role": "assistant", "content": "", "reasoning_content": reasoning},
        TA._mark_control_message({"role": "user", "content": A.ARC2_RESUME_R5}, "resume")]
est5 = ag2._estimate_request_input_tokens(msgs)
ag2._arc2_rev5 = False
est4 = ag2._estimate_request_input_tokens(msgs)
ag2._arc2_rev5 = True
budget = ag2._context_budget_tokens
expect("B3 budget is the EVAL6 one (70,560)", budget == 70560, budget)
expect("B3 old estimate over budget, rev 5 estimate within (reply kept)", est4 > budget >= est5, (est4, est5, budget))
kept = ag2._trim_messages_for_context(msgs, preserve_recent=1)
expect("B3 trim keeps the 60k reply with rev 5", any(m.get("reasoning_content") for m in kept), [m.get("role") for m in kept])
ag2._arc2_rev5 = False
dropped = ag2._trim_messages_for_context(msgs, preserve_recent=1)
ag2._arc2_rev5 = True
expect("B3 control: without rev 5 the reply is dropped (the EVAL6 bug)", not any(m.get("reasoning_content") for m in dropped),
       [m.get("role") for m in dropped])

# ---- B4 truthful resume after a real trim
big = {"role": "assistant", "content": "", "reasoning_content": reasoning + reasoning}   # ~120k tokens: cannot fit
msgs2 = [sysmsg, {"role": "user", "content": "Solve the task."}, big,
         TA._mark_control_message({"role": "user", "content": A.ARC2_RESUME_R5 + "\n\nretained note"}, "resume")]
out = ag2._trim_messages_for_context(msgs2, preserve_recent=1)
last = out[-1]
expect("B4 trimmed -> resume says messages were removed (suffix kept)", last["content"].startswith(A.ARC2_RESUME_TRIMMED)
       and last["content"].endswith("retained note") and TA._CONTROL_MESSAGE_KEY in last, last)
expect("B4 untrimmed -> resume unchanged", ag2._trim_messages_for_context(msgs[:2], preserve_recent=1)[-1]["content"] == "Solve the task.")
ag2._resume_after_yield = True
expect("B4 rev 5 resume opener makes no claim about tool results",
       ag2._build_user_prompt(0, valid_actions=[]) == A.ARC2_RESUME_R5)
ag2._resume_after_yield = False

# ---- B3 calibration correction: ratio describes the non-reasoning text
usage = {"prompt_tokens": 9300 + A.reasoning_tokens(reasoning) + 30}
ag2._text_chars_per_token = None
ag2._calibrate_from_usage(msgs, None, usage)
expect("B3 calibration with a long reply stays near the grid ratio (not pulled to ~2.1)", 1.2 <= ag2._text_chars_per_token <= 1.6,
       ag2._text_chars_per_token)

# ---- B6 cut tool call is not executed
class _R:
    def __init__(self, fr):
        self.finish_reason = fr
        self.message = {"role": "assistant", "content": "", "tool_calls": [
            {"id": "c1", "type": "function", "function": {"name": "python", "arguments": json.dumps({"code": "def f(g):\n    H=len(g)"})}}]}
        self.usage, self.served_by = None, ""
_orig = TA.ToolAgent._chat_completion
try:
    TA.ToolAgent._chat_completion = lambda self, messages, **kw: _R(kw.pop("_fr", "length"))
    res = ag2._chat_completion([], tools=None)
    bad_json = False
    try:
        json.loads(res.message["tool_calls"][0]["function"]["arguments"])
    except json.JSONDecodeError:
        bad_json = True
    expect("B6 length + tool call -> arguments made invalid (Duck drops it and says 'cut off')", bad_json
           and ag2.arc2_rev5_events["cut_tool_calls_dropped"] == 1, res.message)
    TA.ToolAgent._chat_completion = lambda self, messages, **kw: _R("tool_calls")
    res = ag2._chat_completion([], tools=None)
    expect("B6 normal tool call untouched", json.loads(res.message["tool_calls"][0]["function"]["arguments"])["code"].startswith("def f"))
    ag2._resume_after_yield = True
    op = ag2._build_user_prompt(0, valid_actions=[])
    expect("B6 next resume says the call was cut (once)", op == A.ARC2_RESUME_CUT + A.ARC2_RESUME_R5
           and ag2._build_user_prompt(0, valid_actions=[]) == A.ARC2_RESUME_R5, op)
    ag2._resume_after_yield = False
    cutmsg = TA._mark_control_message({"role": "user", "content": A.ARC2_RESUME_CUT + A.ARC2_RESUME_R5}, "resume")
    out = ag2._trim_messages_for_context([sysmsg, {"role": "user", "content": "Solve the task."}, big, cutmsg], preserve_recent=1)
    expect("B4+B6 trimmed cut resume keeps the cut note and says messages were removed",
           out[-1]["content"] == A.ARC2_RESUME_CUT + A.ARC2_RESUME_TRIMMED, out[-1]["content"])
finally:
    TA.ToolAgent._chat_completion = _orig

# ---- R5-1 serializer guard (GPT rev 5 audit 2: json.dumps spoof was host-accepted via CHECKED and submit)
SPOOF = ("def evil(g):\n    import json\n    old = json.dumps\n    want = [list(reversed(r)) for r in g]\n"
         "    def forged(payload, *a, **k):\n"
         "        if isinstance(payload, dict) and payload.get('type') == 'final':\n"
         "            payload = dict(payload); payload['result'] = want\n"
         "        return old(payload, *a, **k)\n"
         "    json.dumps = forged\n    return g\n")
def _fresh(rev5=True):
    a = Agent(task=task, task_id="flip", branch=0, model="qwen", base_url="http://127.0.0.1:9/v1", provider="vllm")
    a._arc2_rev5 = rev5
    return a
a = _fresh(); a._run_python_tool(state, {"code": SPOOF + "action({'action': '" + A.CHECK_PREFIX + "evil'})"})
expect("R5-1 forged CHECKED + json.dumps spoof -> rejected", a.arc2_checked and not a.arc2_checked[-1]["accepted"], a.arc2_checked[-1:])
a = _fresh(); a._run_python_tool(state, {"code": SPOOF + "submit(evil)"})
expect("R5-1 spoof via submit() -> rejected", a.arc2_submissions and not a.arc2_submissions[-1]["accepted"], a.arc2_submissions[-1:])
a = _fresh(); a._run_python_tool(state, {"code": "def good(g):\n    import json\n    k = json.dumps(g)\n    return [list(reversed(r)) for r in g]\ncheck(good)"})
expect("R5-1 a correct function that uses json.dumps is still kept", a.arc2_checked and a.arc2_checked[-1]["accepted"], a.arc2_checked[-1:])
a = _fresh(rev5=False); a._run_python_tool(state, {"code": SPOOF + "submit(evil)"})
expect("R5-1 control: without rev 5 the old path is unchanged (spoof accepted, as before)", a.arc2_submissions[-1]["accepted"], a.arc2_submissions[-1:])

# ---- R5-2 markup recovery on cut replies (GPT rev 5 audit 3: reproduced bypass)
MARKUP = "<tool_call>\n<function=python>\n<parameter=code>\nprint(123)\n</parameter>\n</function>\n</tool_call>"
def duck_view(res):   # the exact sequence in tool_agent.py after _chat_completion (recovery + malformed check)
    m = res.message
    rr = TA._extract_reasoning_text(m); rc = TA._normalize_message_content(m.get("content", ""))
    calls = json.loads(json.dumps(m.get("tool_calls") or []))
    if not calls and TA._contains_tool_call_markup(rr, rc):
        calls = TA._recover_tool_calls_from_markup(rr, rc)
    for tc in calls:
        a_ = (tc.get("function") or {}).get("arguments", "{}")
        if isinstance(a_, str):
            try:
                json.loads(a_)
            except json.JSONDecodeError:
                return "dropped"
    return "executes" if calls else "no call"
class _M:
    def __init__(self, fr, content="", reasoning="", calls=None):
        self.finish_reason, self.usage, self.served_by = fr, None, ""
        self.message = {"role": "assistant", "content": content, "reasoning_content": reasoning, "tool_calls": calls or []}
_orig = TA.ToolAgent._chat_completion
try:
    for label, mk, want in [
            ("length + complete markup in content", lambda: _M("length", content=MARKUP), "dropped"),
            ("length + complete markup in reasoning", lambda: _M("length", reasoning="think " + MARKUP + " more"), "dropped"),
            ("length + incomplete markup", lambda: _M("length", content="<tool_call>\n<function=python>\n<parameter=code>\nprint("), None),
            ("length + plain reasoning, no markup", lambda: _M("length", reasoning="just thinking"), "no call"),
            ("stop + markup (normal recovery kept)", lambda: _M("stop", content=MARKUP), "executes")]:
        TA.ToolAgent._chat_completion = lambda self, messages, _mk=mk, **kw: _mk()
        got = duck_view(ag2._chat_completion([], tools=None))
        expect(f"R5-2 {label} -> {want or 'never executes'}", got == want if want else got != "executes", got)
finally:
    TA.ToolAgent._chat_completion = _orig

# ---- R5-3 forced reduction also gets the truthful resume
fr = ag2._force_reduce_messages([sysmsg, {"role": "user", "content": "Solve the task."}, big,
                                 TA._mark_control_message({"role": "user", "content": A.ARC2_RESUME_R5}, "resume")])
expect("R5-3 _force_reduce_messages rewrites the resume opener", fr[-1]["content"].startswith(A.ARC2_RESUME_TRIMMED), fr[-1])

# ---- R5-4 tokenizer status (present here; missing in a subprocess so the module latch is fresh)
st = A.tokenizer_status()
expect("R5-4 tokenizer status: loaded, path recorded, probe counted", st["loaded"] and st["path"].endswith("tokenizer.json")
       and st["probe_tokens"] > 0 and not st["error"], st)
import subprocess as _sp
_code = ("import os, sys, json; os.environ['E12_TOKENIZER_JSON'] = r'D:/nope/tokenizer.json'; "
         f"sys.path[:0] = [{str(E12)!r}, {str(E12 / 'vendor')!r}]; import arc2_duck as A; print(json.dumps(A.tokenizer_status()))")
_o = _sp.run([sys.executable, "-I", "-c", _code], capture_output=True, text=True, timeout=120)
try:
    _ms = json.loads(_o.stdout.strip().splitlines()[-1])
except Exception:
    _ms = {"raw": _o.stdout[-300:] + _o.stderr[-300:]}
expect("R5-4 tokenizer missing -> recorded as not loaded with a reason, fallback count > 0 (never fatal)",
       _ms.get("loaded") is False and "not found" in str(_ms.get("error")) and _ms.get("probe_tokens", 0) > 0, _ms)

# ---- R5-5 estimate vs actual recorded per request
ag3 = _fresh()
ag3._calibrate_from_usage(msgs, None, {"prompt_tokens": 70000})
pe = ag3.arc2_rev5_events.get("prompt_estimates")
expect("R5-5 prompt estimate vs actual recorded", pe and pe[-1][1] == 70000 and pe[-1][0] > 0, pe)

# ---- low-effort variant (user 2026-10-21): reasoning_effort in every request's chat_template_kwargs
os.environ.pop("E12_REASONING_EFFORT", None)
expect("effort unset -> not sent (model default xhigh)", "reasoning_effort" not in ag2._harness_template_kwargs(),
       ag2._harness_template_kwargs())
os.environ["E12_REASONING_EFFORT"] = "low"
kw = ag2._harness_template_kwargs()
expect("effort low -> reasoning_effort low, preserve_thinking kept", kw.get("reasoning_effort") == "low"
       and kw.get("preserve_thinking") is True, kw)
os.environ["E12_REASONING_EFFORT"] = "high"
expect("unsupported effort ('high') -> not sent (the template would raise)", "reasoning_effort" not in ag2._harness_template_kwargs())
os.environ.pop("E12_REASONING_EFFORT", None)

# ---- run_branch record carries the harvest (metrics)
expect("record fields exist on the agent", isinstance(ag.arc2_checked, list) and "checks_verified" in ag.arc2_rev5_events)
print("ALL OK" if ok else "SOME FAILED")
