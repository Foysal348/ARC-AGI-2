"""Regression corpus (GPT plan reviews; fix list 'Regressions b'): every recorded tool call of every branch of a rev 5
GPU run is replayed through the REV 6 agent in the REAL Duck sandbox (rev 6 prelude, trusted helpers, auto-check,
verification cache, caps). Then build_submission picks the attempts; scored with the truth (analysis only, never a
runtime input). Checks that rev 6 keeps every candidate rev 5 found (late corrections) and reports what auto-check adds.
Usage: python replay_rev6.py <run duck dir> <challenges.json> <solutions.json> <out.jsonl> [task ...]"""
import json, os, re, sys, tempfile, time
from pathlib import Path
os.environ["E12_ARC2_REV6"] = "1"
sys.argv, ARGS = sys.argv[:1], sys.argv[1:]
exec(open(Path(__file__).with_name("smoke_adapter.py"), encoding="utf-8").read().split("flip = lambda g")[0])
duck_dir, ch, so, out_path = ARGS[:4]
challenges, solutions = json.load(open(ch)), json.load(open(so))
tasks = ARGS[4:] or sorted({p.name.rsplit("_b", 1)[0] for p in Path(duck_dir).iterdir() if p.is_dir()})
CALL_RE = re.compile(r"\[TOOL CALL: python\]\n<tool_call>\n<function=python>\n<parameter=code>\n(.*?)\n</parameter>", re.S)
with open(out_path, "w", encoding="utf-8") as out:
    for task_id in tasks:
        task, truth = challenges[task_id], solutions[task_id]
        recs, t0 = [], time.time()
        for b in (0, 1):
            tx_path = Path(duck_dir) / f"{task_id}_b{b}" / "transcript.txt"
            if not tx_path.exists() or not tx_path.stat().st_size:
                continue
            codes = CALL_RE.findall(tx_path.read_text(encoding="utf-8", errors="replace"))
            tmp = Path(tempfile.mkdtemp(prefix="r6_", dir=str(Path(__file__).with_name("runs"))))
            state = tmp / TA.RUNTIME_STATE_FILENAME
            write_runtime_state(state, current_frame=None, history=[])
            ag = Agent(task=task, task_id=task_id, branch=b, model="qwen", base_url="http://127.0.0.1:9/v1", provider="vllm")
            errs = 0
            for code in codes:
                if ag.arc2_accepted is not None:      # the real branch ends at an accepted submit
                    break
                r = ag._run_python_tool(state, {"code": code})
                errs += '"error"' in (r.content or "")[:200]
            orig = json.loads((Path(duck_dir) / f"{task_id}_b{b}" / "branch_result.json").read_text(encoding="utf-8"))
            recs.append({"branch": b, "submissions": ag.arc2_submissions, "checked": ag.arc2_checked,
                         "calls": len(codes), "errors": errs, "ev": ag.arc2_rev6_events,
                         "orig_kept": sum(1 for v in (orig.get("checked") or []) if v.get("accepted")),
                         "orig_submitted_ok": sum(1 for v in (orig.get("submissions") or []) if v.get("accepted"))})
        sub = A.build_submission({task_id: task}, {task_id: recs})[task_id]
        hits = [att["attempt_1"] == g or att["attempt_2"] == g for att, g in zip(sub, truth)]
        cand = [v for r in recs for v in r["submissions"] + r["checked"] if v.get("accepted")]
        oracle = [any(i < len(v.get("test_outputs") or []) and v["test_outputs"][i] == g for v in cand) for i, g in enumerate(truth)]
        row = {"task": task_id, "inputs": len(truth), "hits": sum(hits), "oracle": sum(oracle), "sec": round(time.time() - t0),
               "per_branch": [{"b": r["branch"], "calls": r["calls"], "errors": r["errors"],
                               "kept_r6": sum(1 for v in r["checked"] if v["accepted"]), "kept_r5": r["orig_kept"],
                               "auto_kept": sum(1 for v in r["checked"] if v["accepted"] and v.get("origin") == "auto"),
                               "submit_ok": sum(1 for v in r["submissions"] if v.get("accepted")),
                               "submit_ok_r5": r["orig_submitted_ok"], "autocheck_fns": r["ev"]["autocheck_functions"],
                               "grid_rows_suppressed": r["ev"]["grid_rows_suppressed"]} for r in recs]}
        out.write(json.dumps(row) + "\n")
        out.flush()
        print(json.dumps(row), flush=True)
