"""H6-16 (GPT rev 6e audit 3): the gate-4b window and the commit-window shift at the REAL values, not under the harness's
300 s cap. Both helpers are read from the built notebook (CELL 6) with ast and called directly.
Usage: python window_check.py [notebook.ipynb]  (default: the EVAL12R6G4B_REBUILD notebook)"""
import ast
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
NB = Path(sys.argv[1]) if len(sys.argv) > 1 else next(
    p for p in (HERE.parent / "notebooks/Q27-XHIGH-E12_DUCK_REPL_SGLANG_EVAL12R6G4B_REBUILD.ipynb",
                HERE.parent / "notebooks/Q27-XHIGH-E12_DUCK_REPL_SGLANG_EVAL12R6G4B_REBUILD.ipynb") if p.exists())
src = "\n".join("".join(c["source"]) for c in json.load(open(NB, encoding="utf-8"))["cells"] if c["cell_type"] == "code")
ns, found = {}, []
for cell_src in src.split("\n# CELL"):
    try:
        tree = ast.parse(cell_src)
    except SyntaxError:
        continue
    for node in tree.body:
        if isinstance(node, ast.FunctionDef) and node.name in ("_e12_g4b_window", "_e12_shifted_end"):
            exec(compile(ast.Module([node], []), "<cell6>", "exec"), ns)
            found.append(node.name)
if len(set(found)) < 2:   # cells may not split on the marker: parse the whole code text
    tree = ast.parse(src)
    for node in tree.body:
        if isinstance(node, ast.FunctionDef) and node.name in ("_e12_g4b_window", "_e12_shifted_end"):
            exec(compile(ast.Module([node], []), "<cell6>", "exec"), ns)
            found.append(node.name)
ok = True


def expect(name, cond, info=""):
    global ok
    print(("PASS " if cond else "FAIL ") + name + ("" if cond else f"  -> {info}"))
    ok &= bool(cond)


expect("both helpers are in the notebook", {"_e12_g4b_window", "_e12_shifted_end"} <= set(found), found)
per, win = ns["_e12_g4b_window"](42720.0, 1463, 12)
expect("gate 4b at the G4B values: 171.9 s per task, a 2,063 s window for 12 tasks", round(per, 1) == 171.9 and round(win) == 2063,
       (per, win))
# CELL 6 order: _end = start + window, then the preflight (say 35 s); the shift moves the end by exactly the setup time
start, setup, hard_end = 1463.0, 35.0, 80 * 60 - 180.0      # G4B profile budget 80 min, outputs stop 180 s before
end0 = start + win
end1 = ns["_e12_shifted_end"](end0, setup, hard_end)
expect("the full 2,063 s window is left after a 35 s preflight", abs((end1 - (start + setup)) - win) < 1e-6, end1 - start - setup)
expect("a 240 s setup still leaves the full window when the hard stop allows it",
       abs(ns["_e12_shifted_end"](end0, 240.0, hard_end) - (start + 240.0) - win) < 1e-6)
expect("the end never passes the hard stop", ns["_e12_shifted_end"](hard_end - 10, 600.0, hard_end) == hard_end)
expect("a negative setup never shortens the window", ns["_e12_shifted_end"](end0, -5.0, hard_end) == end0)
# EVAL12R6: the 150-min solve window
w = 150 * 60
expect("EVAL12R6: 9,000 s left after the preflight (185-min budget, hard stop permitting)",
       abs(ns["_e12_shifted_end"](1463.0 + w, 120.0, 185 * 60 - 180.0) - (1463.0 + 120.0) - w) < 1e-6)
print("ALL OK" if ok else "SOME FAILED")
sys.exit(0 if ok else 1)
