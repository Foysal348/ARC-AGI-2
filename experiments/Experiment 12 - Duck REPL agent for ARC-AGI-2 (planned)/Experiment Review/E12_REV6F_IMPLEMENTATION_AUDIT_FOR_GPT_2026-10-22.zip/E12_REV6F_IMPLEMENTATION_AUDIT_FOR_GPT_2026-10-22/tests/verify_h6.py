"""Verify the claims of the three GPT rev 6e audits by reproduction (not by reading): H6-2, H6-4, H6-7, H6-8, H6-13.
Prints REPRODUCED / NOT REPRODUCED per claim. Changes no production code."""
import copy
import json
import os
import sys
import tempfile
import threading
import time
from pathlib import Path

os.environ["E12_ARC2_REV6"] = "1"
os.environ["E12_DUCK_TEMPERATURE"] = "1.0"
os.environ["E12_DUCK_CONTEXT_WINDOW"] = "78000"
TOK = Path(__file__).resolve().parent / "fixtures/tok_int4/tokenizer.json"
_HERE = Path(__file__).resolve().parent
src = open(_HERE / "smoke_adapter.py", encoding="utf-8").read().split("# 1 system prompt carries the task")[0]
exec(src)                      # A, TA, DP, Agent, task, ag, run, expect, tmp, state

out = {}


def verdict(key, reproduced, info):
    out[key] = (reproduced, info)
    print(("REPRODUCED " if reproduced else "NOT REPRODUCED ") + key + " | " + json.dumps(info, default=str)[:600])


# ---------------------------------------------------------------- H6-2: transform(a, b) suppresses the nudge
a2 = Agent(task=task, task_id="flip", branch=0, model="qwen", base_url="http://127.0.0.1:9/v1", provider="vllm")
tmp2 = Path(tempfile.mkdtemp(prefix="h6_", dir=str(_HERE / "runs")))
st2 = tmp2 / TA.RUNTIME_STATE_FILENAME
write_runtime_state(st2, current_frame=None, history=[])
a2._run_python_tool(st2, {"code": "def transform(a, b):\n    return a\nprint('ok')"})
ft = a2._arc2_first_transform_tokens
a2._session_generated_tokens = 27500
a2._resume_after_yield, a2._resume_reason = True, "yield_tools"
op = a2._build_user_prompt(1, valid_actions=[])
verdict("H6-2 two-arg transform(a, b) sets first_transform_tokens and suppresses the 27k nudge",
        ft is not None and not op.startswith(A.R6_TEXT["provisional"]),
        {"first_transform_tokens": ft, "kept": sorted((a2._kept_functions or {})), "opener": op[:80],
         "single_grid_arg": A._r6_single_grid_arg("def transform(a, b):\n    return a")})
a3 = Agent(task=task, task_id="flip", branch=0, model="qwen", base_url="http://127.0.0.1:9/v1", provider="vllm")
tmp3 = Path(tempfile.mkdtemp(prefix="h6_", dir=str(_HERE / "runs")))
st3 = tmp3 / TA.RUNTIME_STATE_FILENAME
write_runtime_state(st3, current_frame=None, history=[])
a3._run_python_tool(st3, {"code": "def solve_row(r, i):\n    return r[::-1]\nprint('ok')"})
verdict("H6-2 helper solve_row(r, i) also suppresses it", a3._arc2_first_transform_tokens is not None,
        {"first_transform_tokens": a3._arc2_first_transform_tokens})

# ---------------------------------------------------------------- H6-7: indexed view bound with only <= 400-cell grids
def synth(n_train, n_test, h=20, w=20):
    g = [[(r * 7 + c * 3) % 10 for c in range(w)] for r in range(h)]
    return {"train": [{"input": g, "output": g} for _ in range(n_train)], "test": [{"input": g} for _ in range(n_test)]}


rows = {}
from tokenizers import Tokenizer as _Tk  # noqa: E402
_real = _Tk.from_file(str(TOK))
for label, obj in (("tokenizer", _real), ("fallback", None)):
    A._TOKENIZER.update(obj=obj, tried=True, cache={})
    for nt, ns in ((10, 3), (12, 1)):
        t = synth(nt, ns)
        txt = A.arc2_indexed_grids(t)
        rows[f"{label} {nt}+{ns}"] = (A.reasoning_tokens(txt), txt.count("not shown here for size"))
A._TOKENIZER.update(obj=_real, tried=True, cache={})
verdict("H6-7 all grids 20x20 (400 cells): the 12,000-token bound is not enforced",
        any(v[0] > 12000 and v[1] == 0 for v in rows.values()), rows)

# ---------------------------------------------------------------- H6-13: arc_overview extras drop lines repeated under another header
ch = json.load(open(Path(__file__).resolve().parent / "fixtures/data/arc-agi_evaluation_challenges.json",
                    encoding="utf-8"))
lost_tasks, lost_lines = 0, 0
for tid, t in sorted(ch.items()):
    b, f = A.arc2_facts_bounded(t), A.arc2_facts(t, level=0)
    if b == f:
        continue
    def pairs(text):
        head, out_ = None, set()
        for ln in text.splitlines():
            if ln.startswith(("TRAIN ", "TEST ")):
                head = ln
            out_.add((head, ln))
        return out_
    have = pairs(b) | pairs(A.arc2_facts_extra(t))
    extra_text = A.arc2_facts_extra(t)
    # a full-facts (header, line) pair present neither in the bounded block nor in the extras
    ex = pairs(extra_text)
    missing = [p for p in pairs(f) if p not in pairs(b) and p not in ex and not p[1].startswith("Exact grids in the python tool")]
    if missing:
        lost_tasks += 1
        lost_lines += len(missing)
verdict("H6-13 arc_overview extras drop lines whose text appears under another header",
        lost_lines > 0, {"tasks_with_lost_lines": lost_tasks, "lost_lines": lost_lines})

# ---------------------------------------------------------------- scheduler fakes (H6-4, H6-8)
class R:
    retryable_failure, yielded_control, step_executed = False, True, False


class Base:
    def __init__(self, *, task, task_id, branch, view, **kw):
        self.task_id, self.branch = task_id, branch
        self.generated_tokens = self.total_tokens = 0
        self.arc2_accepted, self.arc2_submissions, self.arc2_usage, self.arc2_checked = None, [], [], []
        self.arc2_rev5_events, self.arc2_rev6_events, self.arc2_requests = {}, {}, []
        self.arc2_progress = {"best": None, "first_check_tokens": None, "runs": 0}
        self._arc2_deadline = None


TA._priority_gate = lambda: None
ORDER_LOG = []


class Hang(Base):                     # H6-4: the second request hangs past the deadline + join grace
    def analyze(self, sp, n, *, should_stop=None, **kw):
        if should_stop is not None and should_stop():
            return R()
        if self.generated_tokens >= 1000:
            time.sleep(2.5)
        self.generated_tokens += 1000
        return R()


od = Path(tempfile.mkdtemp(prefix="h6sched_", dir=str(_HERE / "runs")))
recs = A.solve_all_r6({"t1": {"train": [], "test": [{"input": [[0]]}]}}, ["t1"], out_dir=od, deadline=time.monotonic() + 1.0,
                      base_url="x", model_id="m", branches=1, workers=1, first_exposure_tokens=None, agent_cls=Hang,
                      min_admit_sec=0.1, join_grace_sec=0.2)
f = od / "t1_b0" / "branch_result.json"
at_return = (f.read_bytes() if f.exists() else b"", A.SCHED_LAST.get("stragglers"))
time.sleep(3.5)
later = f.read_bytes() if f.exists() else b""
verdict("H6-4 branch_result.json changes after the scheduler returned (straggler)",
        at_return[1] == 1 and later != at_return[0],
        {"stragglers": at_return[1], "bytes_at_return": len(at_return[0]), "bytes_later": len(later),
         "tokens_at_return": (json.loads(at_return[0]) if at_return[0] else {}).get("generated_tokens"),
         "tokens_later": (json.loads(later) if later else {}).get("generated_tokens"),
         "published_tokens": [r.get("generated_tokens") for r in recs["t1"]]})


class Late(Base):                     # H6-8: no progress in stage 1, progress as soon as branch 0 runs in stage 2
    def analyze(self, sp, n, *, should_stop=None, **kw):
        if should_stop is not None and should_stop():
            return R()
        time.sleep(0.01)
        self.generated_tokens += 1000
        if self.branch == 0 and self.generated_tokens > 3000:
            k = self.arc2_progress["runs"] + 1
            self.arc2_progress["runs"] = k
            self.arc2_progress["best"] = {"name": "transform", "k": 1, "n": 3, "acc": min(0.9, 0.3 + 0.1 * k), "tokens": 0}
            ORDER_LOG.append((time.monotonic(), self.task_id, 0, "progress"))
        return R()


# H6-8 measured at the real pop time: a branch-1 session is created under the scheduler lock when its start is popped.
# (Our first version compared request-log order; a branch 1 popped BEFORE branch 0 improved can log its first request
# later, 3-73 ms after the pop, which read as a false reproduction.)
_bs_init = A.BranchSession.__init__


def _bs_logged(self, *a, **kw):
    _bs_init(self, *a, **kw)
    if kw.get("branch") == 1:
        ORDER_LOG.append((time.monotonic(), kw.get("task_id"), 1, "popped"))


A.BranchSession.__init__ = _bs_logged
res = {}
for rep_i, workers in enumerate((1, 2, 4, 2, 4, 2, 4)):
    ORDER_LOG.clear()
    tasks = {f"t{i}": {"train": [], "test": [{"input": [[0]]}]} for i in range(6)}
    od2 = Path(tempfile.mkdtemp(prefix="h6sched_", dir=str(_HERE / "runs")))
    A.solve_all_r6(tasks, sorted(tasks), out_dir=od2, deadline=time.monotonic() + 6.0, base_url="x", model_id="m",
                   branches=2, workers=workers, first_exposure_tokens=3000, agent_cls=Late, min_admit_sec=0.1,
                   min_chunk_tokens=2000, fair_share=False, max_generated_tokens=12000)
    popped_after = []
    for t in tasks:
        pop = [x[0] for x in ORDER_LOG if x[1] == t and x[2] == 1 and x[3] == "popped"]
        prog = [x[0] for x in ORDER_LOG if x[1] == t and x[2] == 0 and x[3] == "progress"]
        if pop and prog and pop[0] > prog[0]:
            popped_after.append(t)
    res[f"run{rep_i} workers {workers}"] = {"b1_popped": sum(1 for x in ORDER_LOG if x[3] == "popped"),
                                            "b1_popped_after_b0_progress": popped_after,
                                            "b1_deferred_at_pop": A.SCHED_LAST.get("b1_deferred_at_pop")}
A.BranchSession.__init__ = _bs_init
verdict("H6-8 a queued branch 1 is popped after its branch 0 already has stage-2 progress (pop time, 7 runs)",
        any(v["b1_popped_after_b0_progress"] for v in res.values()), res)
print(json.dumps({k: v[0] for k, v in out.items()}))
