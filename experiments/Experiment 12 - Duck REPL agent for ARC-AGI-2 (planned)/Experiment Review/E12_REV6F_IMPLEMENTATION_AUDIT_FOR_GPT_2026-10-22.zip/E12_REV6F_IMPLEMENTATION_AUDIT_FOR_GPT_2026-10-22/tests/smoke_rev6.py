"""Rev 6 unit checks for arc2_duck (E12_ARC2_REV6=1), real Duck sandbox, no server. Our own scripted code only.
Covers the fix-list traps T1-T8 and items R6-V/P/K/S/Q/D (fix list 'Rev 6 gap check' + the two plan reviews)."""
import json
import os
import re
import sys
import threading
import time
from pathlib import Path

os.environ["E12_ARC2_REV6"] = "1"
os.environ["E12_DUCK_TEMPERATURE"] = "1.0"
os.environ["E12_CHECK_VERIFY_CAP"] = "6"
os.environ["E12_AUTOCHECK_CAP"] = "3"
os.environ["E12_DUCK_CONTEXT_WINDOW"] = "78000"
TOK = Path(str(Path(__file__).resolve().parent / "fixtures") + r"/tok_int4/tokenizer.json")
os.environ["E12_TOKENIZER_JSON"] = str(TOK)
_HERE = Path(__file__).resolve().parent
src = open(_HERE / "smoke_adapter.py", encoding="utf-8").read().split("# 1 system prompt carries the task")[0]
exec(src)                      # A, TA, DP, Agent, task (row flip), ag, run, expect, flip, tmp, state

# ------------------------------------------------------------------ R6-V2 facts (deterministic, shape-aware)
shape_task = {"train": [{"input": [[1, 1], [1, 2]], "output": [[1, 2, 3]]},
                        {"input": [[0, 3, 3], [0, 0, 0]], "output": [[0, 3, 3], [0, 0, 5]]}],
              "test": [{"input": [[2, 2], [0, 2]]}, {"input": [[7]]}, {"input": [[1, 0, 1]]}]}
f1 = A.arc2_facts(shape_task)
expect("facts: deterministic", f1 == A.arc2_facts(json.loads(json.dumps(shape_task))))
expect("facts: shape change -> no cellwise diff", "shape changed 2x2 -> 1x3" in f1 and "TRAIN 0" in f1, f1[:600])
expect("facts: same-shape pair -> changed cells + transitions", "changed cells 1" in f1 and "(0, 5, 1)" in f1, f1)
expect("facts: every test input covered (3)", all(f"TEST {j}" in f1 for j in range(3)))
expect("facts: 'modal', never 'background'", "modal" in f1 and "background" not in f1.lower())
os.environ["E12_R6_FACTS_MAX_CHARS"] = "200"
fb = A.arc2_facts_bounded(shape_task)
expect("facts: over the bound -> lists dropped with an explicit notice", "largest (color" not in fb and "omitted for size" in fb)
os.environ.pop("E12_R6_FACTS_MAX_CHARS")

# ------------------------------------------------------------------ R6-V1/P1 prompt
sp = ag._system_prompt
expect("V1: facts view has no raw grid rows", "Training pair 0 input:" not in sp and "ARC TASK FACTS" in sp)
gp = A.arc2_system_prompt_r6(task, DP, 3072, view="grids")
expect("V1 hedge: grids view shows the rows + facts", "Training pair 0 input:" in gp and "ARC TASK FACTS" in gp)
expect("P1: helpers + check_many + auto-check + submit-ends-branch described",
       all(s in sp for s in ("components(g", "check_many", "checks it automatically", "ends this branch", "crop(g, r0, c0, r1, c1)")))
bad = [w for w in (r"current_frame", r"action\(actions\)", r"\bgame\b", r"segmentation", r"Investigate first")
       if re.search(w, sp)]
expect("P1: no game words", not bad, bad)
expect("P1: rigid V3.1 stage text absent", "By your second Python execution" not in sp)

# ------------------------------------------------------------------ R6-V3 / T1 helpers usable inside transform
r, p = run("def transform(g):\n    return flip_h(crop(g, 0, 0, len(g) - 1, len(g[0]) - 1))\ncheck(transform)")
expect("T1: helper-using transform is retained", "transform" in (ag._kept_functions or {}), (ag._kept_functions, r.content[-600:]))
expect("T1: ... and host-verified as a candidate", len(ag.arc2_checked) == 1 and ag.arc2_checked[0]["accepted"], ag.arc2_checked)
expect("T1: trusted helpers stay hidden from the model's retained list",
       not (set(ag._kept_functions) & A.R6_HELPER_NAMES), sorted(ag._kept_functions))
r, p = run("print(grid_shape(train[0]['input']), len(components(train[0]['input'])))")
expect("T1: helpers available in later calls", "(2, 3)" in r.content, r.content[-300:])
r, p = run("def leak(g):\n    return [list(reversed(x)) for x in g] if g != train[0]['input'] else train[0]['output']\ncheck(leak)")
expect("T1: a function that reads `train` is still rejected", not any(v["name"] == "leak" and v["accepted"] for v in ag.arc2_checked),
       r.content[-500:])

# helpers correctness (trusted source executed on the host)
ns = {}
for s in A.R6_HELPER_SOURCES:
    exec(s, ns)
g8 = [[1, 0], [0, 1]]
expect("components: 4-conn splits a diagonal, 8-conn joins it",
       len(ns["components"](g8, color=1)) == 2 and len(ns["components"](g8, color=1, connectivity=8)) == 1)
expect("crop inclusive in bbox order", ns["crop"]([[1, 2, 3], [4, 5, 6]], 0, 1, 1, 2) == [[2, 3], [5, 6]])
expect("diff_summary: different shapes -> no invented diff", ns["diff_summary"]([[1]], [[1, 2]])["changed_cells"] is None
       and ns["diff_summary"]([[1]], [[1]])["changed_cells"] == 0 and ns["diff_summary"]([[1]], [[2]])["changed_cells"] == 1)
expect("rot90 clockwise", ns["rot90"]([[1, 2], [3, 4]]) == [[3, 1], [4, 2]])
expect("modal_color tie -> smallest", ns["modal_color"]([[3, 1], [1, 3]]) == 1)

# ------------------------------------------------------------------ R6-K2 check output + progress
r, p = run("def ident(g):\n    return g\ncheck(ident)")
expect("K2: verdict line first + identity flag + test inputs status",
       re.search(r"check\(ident\): 0/2 train pairs exact; returns the input unchanged on pair\(s\) \[0, 1\]; test inputs: ok, ok",
                 r.content) is not None, r.content[-500:])
r, p = run("def boom(g):\n    x = 1\n    return g[99]\ncheck(boom)")
expect("K2: an error names the function and its line", "(in boom, line 3)" in r.content, r.content[-500:])
expect("S4: progress recorded per single function", ag.arc2_progress["runs"] >= 3
       and ag.arc2_rev6_events["first_check_tokens"] is not None, ag.arc2_progress)
best = ag.arc2_progress["best"]
expect("S4: best = the exact transform (identity scores 0 changed-cell accuracy)", best["name"] == "transform" and best["k"] == 2, best)

# ------------------------------------------------------------------ R6-K1 auto-check
n0 = len(ag.arc2_checked)
r, p = run("def transform2(g):\n    return [row[::-1] for row in g]")
expect("K1: transform2 defined without check -> auto-checked + harvested",
       "checked `transform2` automatically" in r.content and len(ag.arc2_checked) == n0 + 1, r.content[-600:])
expect("K3: same outputs as a saved candidate -> noted, no new distinct candidate",
       ag.arc2_checked[-1].get("dup_of") == "transform" and "equal the saved" in r.content, (ag.arc2_checked[-1], r.content[-400:]))
r, p = run("print(1)")
expect("K1: unchanged source -> no second auto-check", "automatically" not in r.content)
r, p = run("def rotate(g):\n    return [list(x) for x in zip(*g)]")
expect("K1: helper-like name (rotate) not auto-checked", "automatically" not in r.content)
r, p = run("def solve_two(g, k):\n    return g")
expect("K1: two required args -> not auto-checked", "automatically" not in r.content)
r, p = run("def transform_alt(g):\n    return [list(reversed(x)) for x in g] if len(g) > 1 else [[9] * len(g[0])]")
expect("K1: transform_alt auto-checked; distinct test outputs -> a second distinct candidate",
       "`transform_alt`" in r.content and ag.arc2_checked[-1]["accepted"] and "dup_of" not in ag.arc2_checked[-1]
       and len(ag._arc2_accepted_sigs) == 2, (ag.arc2_checked[-1], r.content[-500:]))
r, p = run("def transform2(g):\n    return [row[::-1] for row in g]\ncheck(transform2)")
expect("K3: re-check of an unchanged closure -> trusted verdict reused (no new verify)",
       ag.arc2_rev5_events["checks_skipped_dup"] >= 1 and len([v for v in ag.arc2_checked if v["name"] == "transform2"]) == 1)
r, p = run("def unrelated(x):\n    return x + 1\nprint(2)")
r, p = run("check(transform2)")
expect("K3: a new unrelated function does not change transform2's key", len([v for v in ag.arc2_checked if v["name"] == "transform2"]) == 1)
# auto cap = 3: transform2, transform_alt used 2; one more auto, then exhausted; explicit check still verifies
r, p = run("def transform_v2(g):\n    return [list(reversed(x)) for x in g]\n")
r, p = run("def transform_v3(g):\n    out = [list(reversed(x)) for x in g]\n    return out")
expect("K3: auto cap reached -> neutral note (no 'submit your best')", "limit of 3 automatic" in r.content
       and "submit your best" not in r.content, r.content[-500:])
r, p = run("check(transform_v3)")
expect("K3: explicit check still verifies after the auto cap", any(v["name"] == "transform_v3" for v in ag.arc2_checked),
       r.content[-400:])

# ------------------------------------------------------------------ R6-V4 grid print guard
r, p = run("for row in [[1, 2, 3, 4, 5]] * 12:\n    print(*row)")
expect("V4: a long grid print is collapsed with the note", "more grid rows not shown" in r.content
       and ag.arc2_rev6_events["grid_rows_suppressed"] >= 10, r.content[-400:])
r, p = run("print([[0] * 30 for _ in range(30)])")
expect("V4: one long nested-list line is cut", "(nested list)" in r.content, r.content[-300:])
_t0 = time.monotonic()
_g, _d = A.guard_grid_prints(("[" + ", ".join(["0"] * 100) + "], [1\n") * 3)
expect("V4: a near-row line (old pattern backtracked exponentially) is classified in linear time",
       time.monotonic() - _t0 < 1.0 and _d == 0, round(time.monotonic() - _t0, 3))
r, p = run("show(train[0]['input'])")
expect("V4: show() small crop allowed with indices", "r00 | 1 2 3" in r.content, r.content[-300:])
r, p = run("show([[0] * 30 for _ in range(30)])")
expect("G4-4: show() prints a whole 30x30 grid with indices", "r29 | 0 0" in r.content and "rows 0..29" in r.content
       and "not shown" not in r.content, r.content[-300:])
r, p = run("show([[0] * 30 for _ in range(30)])\nshow([[1] * 30 for _ in range(30)])")
expect("G4-4: past 1,000 shown cells in one call the next grid is paged (rows that fit + where to continue)",
       "rows 0..2," in r.content and "call show(g, r0=3)" in r.content and "r03 | 1" not in r.content, r.content[-400:])
if HAVE_TOKENIZERS:   # H6-19: without the package this check is skipped (counted), the rest still runs
    from tokenizers import Tokenizer as _Tk  # noqa: E402
    _tk = _Tk.from_file(str(TOK))
expect_tok("G4-4: a full show() call stays inside the 3,072-token tool cap (Qwen tokenizer)",
           lambda: len(_tk.encode(r.content).ids) < 3072, lambda: len(_tk.encode(r.content).ids))
r, p = run("show([[0] * 31 for _ in range(30)])")
expect("G4-4: one show() over 900 cells is refused", "at most 900 cells" in r.content, r.content[-300:])
r, p = run("show(train[0]['input'], r0=1, c0=1)")
expect("G4-4: a crop keeps its row and column indices", "rows 1..1, cols 1..2" in r.content and "r01 | " in r.content,
       r.content[-300:])
# G4-3: rows printed with a row index, 'row N:' and tuples are collapsed too; dicts and short lists are untouched
r, p = run("g = [[0, 0, 5, 2, 1, 0, 3]] * 12\nfor i, row in enumerate(g):\n    print(i, row)")
expect("G4-3: print(i, row) rows are collapsed (G4B: 173 such rows reached the model)",
       "more grid rows not shown" in r.content and "11 [0, 0, 5" not in r.content, r.content[-300:])
r, p = run("for i in range(8):\n    print('row ' + str(i) + ': (1, 2, 3, 4)')")
expect("G4-3: 'row N: (..)' tuples are collapsed", "more grid rows not shown" in r.content, r.content[-300:])
# self-audit of rev 6e (149 recorded transcripts): index + joined digits (G4B: about 480 rows in 5 branches), 'r N: [..]'
# (rev 5) and 'N: 0 0 5 2' also reached the model; show() rows stay untouched
r, p = run("g = [[0, 0, 5, 2, 1, 0, 3, 3, 1, 0]] * 12\nfor i, row in enumerate(g):\n    print(i, ''.join(map(str, row)))")
expect("G4-3+: print(i, joined digits) rows are collapsed (G4B 247ef758_b0, 62593bfd_b0, 898e7135_b0)",
       "more grid rows not shown" in r.content and "11 0052103310" not in r.content, r.content[-300:])
r, p = run("for i in range(8):\n    print('  r ' + str(i) + ': [0, 0, 5, 2, 1]')")
expect("G4-3+: 'r N: [..]' rows are collapsed (rev 5 9385bd28_b0)", "more grid rows not shown" in r.content, r.content[-300:])
r, p = run("for i in range(8):\n    print(str(i) + ': 0 0 5 2 1')")
expect("G4-3+: 'N: 0 0 5 2 1' rows are collapsed", "more grid rows not shown" in r.content, r.content[-300:])
r, p = run("show([[3] * 12 for _ in range(12)])")
expect("G4-3+: show() rows are never collapsed by the widened guard", "more grid rows" not in r.content
       and "r11 | 3 3" in r.content, r.content[-300:])
r, p = run("print({'a': [1, 2, 3, 4]})\nprint(12, [1, 2])")
expect("G4-3: dicts and short lists are untouched", "more grid rows" not in r.content and "{'a': [1, 2, 3, 4]}" in r.content,
       r.content[-300:])

# ------------------------------------------------------------------ R6-P2 resumes
ag2 = Agent(task=task, task_id="flip", branch=1, view="grids", model="qwen", base_url="http://127.0.0.1:9/v1", provider="vllm")
op = lambda a: a._build_user_prompt(1, valid_actions=[])
expect("P2: first opener", op(ag2).startswith(A.R6_TEXT["first"]))
ag2._resume_after_yield, ag2._resume_reason = True, "yield_bare"
expect("P2: no tool, no evidence -> notool", op(ag2).startswith(A.R6_TEXT["notool"]))
ag2._arc2_length_pending = True
expect("P2: length cut without a call", op(ag2).startswith(A.R6_TEXT["length"][:40]))
ag2._arc2_cut_pending = True; ag2._arc2_length_pending = True
expect("P2: cut call has precedence", op(ag2).startswith(A.R6_TEXT["cut"][:40]))
ag2._resume_reason = "timeout"
expect("P2: timeout", op(ag2).startswith(A.R6_TEXT["timeout"][:40]))
ag2._resume_reason = "yield_tools"
expect("P2: tools ran, no evidence -> neutral continue", op(ag2).startswith(A.R6_TEXT["continue"]))
ag2.arc2_progress["best"] = {"name": "t1", "k": 1, "n": 2, "acc": 0.5}
expect("P2: partial progress", "`t1`, is exact on 1 of 2" in op(ag2))
ag._resume_after_yield, ag._resume_reason = True, "yield_tools"
expect("P2: verified candidate beats partial", "is host-verified" in op(ag), op(ag))
ag2._resume_after_yield = False
ag2.arc2_submissions.append({"name": "t1", "accepted": False, "summary": "wrong on training pair 1."})
expect("P2: a new turn after a rejected submit names the rejection (not the first-turn text)",
       op(ag2).startswith("Your submission `t1` was not accepted: wrong on training pair 1. Continue"), op(ag2))
ag2.arc2_submissions.pop()
msgs = [{"role": "system", "content": "s"}, {"role": "user", "content": "a" + A.R6_COMPLETE},
        {"role": "assistant", "content": "x"}, {"role": "user", "content": "b" + A.R6_COMPLETE}]
out = ag2._arc2_rewrite_resume(msgs + [{"role": "assistant", "content": "y"}], msgs)
expect("P2/T2: trim rewrites only the newest opener", out[3]["content"].startswith("b") and A.R6_TRIMMED in out[3]["content"]
       and A.R6_COMPLETE in out[1]["content"])
expect("T2: facts stay in the (never trimmed) system prompt", "ARC TASK FACTS" in ag2._system_prompt)
msgs = []
ag2._append_context_message(msgs, {TA._CONTROL_MESSAGE_KEY: "nudge", "role": "user",
                                   "content": "You have not acted yet. Investigate first. Then investigate and revise ..."})
expect("T6: Duck's 'Investigate first' nudge replaced", msgs and "Investigate first" not in msgs[-1]["content"]
       and msgs[-1]["content"].startswith(A.R6_TEXT["notool"]), msgs)

# ------------------------------------------------------------------ R6-Q1 / R6-D1 dynamic caps
ag3 = Agent(task=task, task_id="flip", branch=0, model="qwen", base_url="http://127.0.0.1:9/v1", provider="vllm")
c = ag3._arc2_apply_cap()
expect("Q1: 12,288 before the first successful tool call; D1 reserve and budget follow",
       c == 12288 and ag3._reply_reserve_tokens == 12288 and ag3._context_budget_tokens == 78000 - 12288 - 512,
       (c, ag3._reply_reserve_tokens, ag3._context_budget_tokens))
ag3._arc2_tool_ok = True
expect("Q1: 24,576 after tool progress", ag3._arc2_apply_cap() == 24576 and ag3._context_budget_tokens == 78000 - 24576 - 512)
ag3._arc2_nocall_cuts = 2
expect("Q1: 32,768 rescue after two no-call cuts", ag3._arc2_apply_cap() == 32768 and ag3._max_output_tokens == 32768)
ag4 = Agent(task=task, task_id="flip", branch=1, view="indexed", model="qwen", base_url="http://127.0.0.1:9/v1", provider="vllm")
expect("G4-2: branch 1 (a grids view) starts at 24,576; branch 0 (facts) keeps 12,288",
       ag4._arc2_apply_cap() == 24576 and Agent(task=task, task_id="flip", branch=0, model="qwen",
                                                base_url="http://127.0.0.1:9/v1", provider="vllm")._arc2_apply_cap() == 12288)

# ------------------------------------------------------------------ R6-S6 / T8 deadline clamps
seen = {}
_orig = TA.ToolAgent._chat_completion


class _R:
    finish_reason, message, usage = "stop", {"role": "assistant", "content": "ok", "tool_calls": []}, {}


def _fake(self, messages, **kw):
    seen.update(kw)
    return _R()
TA.ToolAgent._chat_completion = _fake
try:
    ag3._arc2_deadline = time.monotonic() + 10
    ag3._chat_completion([{"role": "user", "content": "x"}], tools=None, request_timeout_seconds=1800)
    expect("T8: a request's read timeout is clamped to the deadline", seen["request_timeout_seconds"] <= 10.0, seen)
    ag3._arc2_deadline = time.monotonic() - 1
    ag3._chat_completion([{"role": "user", "content": "x"}], tools=None, request_timeout_seconds=1800)
    expect("T8: past the deadline -> minimal timeout", seen["request_timeout_seconds"] == 0.5, seen)
finally:
    TA.ToolAgent._chat_completion = _orig
ag._arc2_deadline = time.monotonic() - 1
v = ag._verify_submission("transform")
expect("S6: no verification after the deadline", v.get("skipped") and not v["accepted"], v)
ag._arc2_deadline = None

# ------------------------------------------------------------------ R6-S1..S5 scheduler simulation (fake agents)
class FakeResult:
    retryable_failure, yielded_control, step_executed = False, True, False


class FakeAgent:
    """Emulates Duck's analyze(): one request per call (yield after 2,048 tokens), should_stop checked before it."""
    log = []
    lock = threading.Lock()

    def __init__(self, *, task, task_id, branch, view, **kw):
        self.task_id, self.branch, self.view = task_id, branch, view
        self.generated_tokens = self.total_tokens = 0
        self.arc2_accepted, self.arc2_submissions, self.arc2_usage, self.arc2_checked = None, [], [], []
        self.arc2_rev5_events, self.arc2_rev6_events = {}, {}
        self.arc2_progress = {"best": None, "first_check_tokens": None, "runs": 0}
        self._arc2_deadline = None
        h = sum(map(ord, task_id))
        self.solve_at = None if h % 3 == 0 else (8000 + (h % 5) * 9000)     # some tasks never solve
        self.oid = id(self)

    def analyze(self, state_path, n, *, should_stop, **kw):
        if should_stop():
            return FakeResult()
        with FakeAgent.lock:
            FakeAgent.log.append((time.monotonic(), self.task_id, self.branch, self.generated_tokens))
        time.sleep(0.002)
        self.generated_tokens += 4000
        self.total_tokens = self.generated_tokens
        if self.solve_at and self.generated_tokens >= self.solve_at and not self.arc2_checked:
            self.arc2_checked.append({"name": "transform", "accepted": True, "test_outputs": [[[self.branch]]], "t": time.time()})
        return FakeResult()


tasks240 = {f"t{i:03d}": {"train": [], "test": [{"input": [[0]]}]} for i in range(240)}
order = sorted(tasks240, key=lambda t: (sum(map(ord, t)) % 7, t))          # stand-in for ORDER2
os.environ["ARC3_MAX_ACTIVE_STREAMS"] = "10"
done = []
t_start = time.monotonic()
recs = A.solve_all_r6(tasks240, order, out_dir=tmp / "sched", deadline=time.monotonic() + 120, base_url="x", model_id="m",
                      branches=2, max_generated_tokens=100000, workers=10, first_exposure_tokens=28000,
                      on_branch_done=done.append, agent_cls=FakeAgent, min_admit_sec=1)
first_req = {}
for t, tid, b, tok in FakeAgent.log:
    first_req.setdefault((tid, b), t)
b0_starts = sorted((first_req[(t, 0)], t) for t in order)
stage2 = [first_req[k] for k in first_req if k[1] == 1]
expect("S1: every one of 240 tasks got branch 0", all((t, 0) in first_req for t in order))
rank = {t: i for i, (_, t) in enumerate(b0_starts)}
expect("S1: branch-0 admission follows the given order (ORDER2, within the 10 concurrent workers)",
       max(abs(rank[t] - i) for i, t in enumerate(order)) <= 30, max(abs(rank[t] - i) for i, t in enumerate(order)))   # 10 workers + timer jitter
expect("S1: no stage-2 work before the last task's first exposure starts", min(stage2) >= max(x for x, _ in b0_starts) - 0.5,   # admission is ordered; the first request can jitter
       (min(stage2), max(x for x, _ in b0_starts)))
r0 = [x for x in recs[order[0]] if x["branch"] == 0][0]
expect("Q2: branch 0 paused at the first-exposure budget, then resumed (2 runs)",
       len(r0["runs"]) >= 1 and r0["runs"][0]["status"] in ("paused", "done"), r0["runs"])
paused_then = [t for t in order if any(x["branch"] == 0 and len(x.get("runs", [])) >= 2 for x in recs[t])]
expect("Q2: resumed branches keep their agent (tokens continue past the pause)",
       paused_then and all(max(x["generated_tokens"] for x in recs[t] if x["branch"] == 0) > 28000 for t in paused_then[:20]),
       len(paused_then))
solved_b0 = [t for t in order if any(x["branch"] == 0 and any(c["accepted"] for c in x.get("checked") or []) for x in recs[t])]
expect("S2: tasks with one candidate still get branch 1 (about 1/3 of accepts are test-wrong)",
       any(any(x["branch"] == 1 for x in recs[t]) for t in solved_b0))
expect("S: every record published per (task, branch), replaced not appended", all(len({x["branch"] for x in recs[t]}) == len(recs[t])
                                                                                  for t in order))
print("scheduler sim:", round(time.monotonic() - t_start, 1), "s,", len(FakeAgent.log), "fake requests,",
      sum(len(v) for v in recs.values()), "branch records")

# deadline: a short run must stop admitting and return promptly
FakeAgent.log = []
t0 = time.monotonic()
recs2 = A.solve_all_r6(tasks240, order, out_dir=tmp / "sched2", deadline=time.monotonic() + 3, base_url="x", model_id="m",
                       branches=2, max_generated_tokens=100000, workers=10, first_exposure_tokens=28000,
                       agent_cls=FakeAgent, min_admit_sec=1)
expect("S6: returns shortly after the deadline", time.monotonic() - t0 < 3 + 2.5, round(time.monotonic() - t0, 2))
expect("S6: no request after the deadline", max(t for t, *_ in FakeAgent.log) <= t0 + 3.05)

# G4-1 (user 2026-10-21): the worker count stays fixed; no new admission while the full-attention KV usage >= 0.95
_conc = {"now": 0, "max": 0}
_orig_run = A.BranchSession.run


def _count_run(self, *a, **k):
    with FakeAgent.lock:
        _conc["now"] += 1
        _conc["max"] = max(_conc["max"], _conc["now"])
    try:
        return _orig_run(self, *a, **k)
    finally:
        with FakeAgent.lock:
            _conc["now"] -= 1


def gate_run(probe, secs=2.0, **kw):
    _conc.update(now=0, max=0)
    t0_ = time.monotonic()
    A.solve_all_r6(tasks240, order[:60], out_dir=Path(tempfile.mkdtemp(dir=str(tmp))), deadline=time.monotonic() + secs,
                   base_url="x", model_id="m", branches=1, max_generated_tokens=400000, workers=12,
                   first_exposure_tokens=None, agent_cls=FakeAgent, min_admit_sec=0.3, capacity_probe=probe,
                   kv_poll_sec=0.05, **kw)
    return dict(A.SCHED_LAST), _conc["max"], time.monotonic() - t0_


import tempfile  # noqa: E402
A.BranchSession.run = _count_run
try:
    sS, mS, _ = gate_run(lambda: {"kv_usage": 0.31, "queue": 1.0, "running": 11.0, "mamba_usage": 0.62})
    expect("G4-1: G4B steady state (queue 1, KV 0.31) -> no hold, 12 workers stay, 12 run at once",
           sS["kv_holds"] == 0 and sS["allowed"] == 12 and sS["workers"] == 12 and mS == 12 and not sS["events"],
           (sS["kv_holds"], sS["allowed"], mS, sS["events"][:3]))
    sH, mH, dH = gate_run(lambda: {"kv_usage": 0.97})
    expect("G4-1: KV 0.97 -> new admissions held; only the no-deadlock idle release admits (one at a time)",
           sH["kv_holds"] >= 1 and mH == 1 and sH["kv_idle_overrides"] >= 1 and dH < 2.0 + 2.0,   # rev 6f audit: 3.22 s seen once
                                                                                                  # under load; a deadlock = 60 s
           (sH["kv_holds"], mH, sH["kv_idle_overrides"], round(dH, 2)))
    _t_rel = {"t": None}

    def _release():
        if _t_rel["t"] is None:
            _t_rel["t"] = time.monotonic()
        return {"kv_usage": 0.97 if time.monotonic() - _t_rel["t"] < 0.6 else 0.5}
    sR, mR, _ = gate_run(_release, secs=2.5)
    kinds = [e.get("kind") for e in sR["events"]]
    expect("G4-1: KV back below 0.95 -> admission resumes (hold then release recorded, 12 run again)",
           "kv_hold" in kinds and "kv_release" in kinds and mR == 12 and sR["kv_hold_sec"] > 0,
           (kinds[:4], mR, sR["kv_hold_sec"]))
    sM, mM, _ = gate_run(lambda: {}, kv_stale_sec=0.2)
    expect("G4-1: metric missing -> fail-open (no hold, 12 run), counted, one warning event, no deadlock",
           sM["kv_holds"] == 0 and mM == 12 and sM["kv_missing"] >= 2 and sM["kv_missing"] == sM["kv_samples"]
           and [e.get("kind") for e in sM["events"]].count("kv_metric_missing") == 1,
           (sM["kv_holds"], mM, sM["kv_missing"], sM["kv_samples"], sM["events"][:2]))
    _bad = iter([float("nan"), 1.7, "x", None] * 1000)
    sI, mI, _ = gate_run(lambda: {"kv_usage": next(_bad)})
    expect("G4-1: NaN / out-of-range / text values are treated as missing (no hold)", sI["kv_holds"] == 0 and mI == 12,
           (sI["kv_holds"], mI))

    def _boom():
        raise RuntimeError("metrics endpoint down")
    sE, mE, _ = gate_run(_boom)
    expect("G4-1: a probe exception never blocks admission", sE["kv_holds"] == 0 and mE == 12, (sE["kv_holds"], mE))
    _calls = {"n": 0}

    def _stuck():
        _calls["n"] += 1
        if _calls["n"] == 2:
            time.sleep(1.5)        # the probe thread hangs: the last sample (0.97) goes stale
        return {"kv_usage": 0.97}
    sT, mT, _ = gate_run(_stuck, secs=2.5, kv_stale_sec=0.3)
    expect("G4-1: a stale sample (probe hung) stops holding (fail-open)", mT == 12, (mT, sT["kv_holds"]))
    sD, mD, dD = gate_run(lambda: {"kv_usage": 0.99}, secs=1.2)
    expect("G4-1: deadline while held -> clean return by the deadline + grace", dD < 1.2 + 1.5, round(dD, 2))
finally:
    A.BranchSession.run = _orig_run
import inspect as _insp  # noqa: E402
_gate_src = _insp.getsource(A.solve_all_r6)
expect("G4-1: the rev 6d step-down is gone (no min_workers, no queue/retraction streaks, no allowed -= 2)",
       "min_workers" not in _gate_src and "streak" not in _gate_src and '"allowed"] - 2' not in _gate_src)
expect("G4-17: the minimum stage-2 chunk default is 12,288",
       _insp.signature(A.solve_all_r6).parameters["min_chunk_tokens"].default == 12288)

# ================================================================== rev 6b (gap check against the problem -> fix map)
def fresh(t, tid="x", b=0):
    st = Path(tempfile.mkdtemp(prefix="r6b_", dir=str(tmp))) / TA.RUNTIME_STATE_FILENAME
    write_runtime_state(st, current_frame=None, history=[])
    a = Agent(task=t, task_id=tid, branch=b, model="qwen", base_url="http://127.0.0.1:9/v1", provider="vllm")
    return a, (lambda code: a._run_python_tool(st, {"code": code}))


import tempfile  # noqa: E402

# R6-V2 / Q-5: token-bounded facts (both plan reviews: 600-800 Qwen tokens first)
EV = json.load(open(str(Path(__file__).resolve().parent / "fixtures") + r"/data/arc-agi_evaluation_challenges.json",
                    encoding="utf-8"))
f_full, f_b = A.arc2_facts(EV["135a2760"]), A.arc2_facts_bounded(EV["135a2760"])
expect("Q-5: a block over 800 tokens is reduced to <= 800 with an explicit omission note",
       A.reasoning_tokens(f_full) > 800 and A.reasoning_tokens(f_b) <= 800 and "omitted for size" in f_b,
       (A.reasoning_tokens(f_full), A.reasoning_tokens(f_b)))
f3 = A.arc2_facts(EV["d8e07eb2"], level=3)
expect("Q-5: the smallest level keeps the core facts (shape, colors, changed cells) and says what is omitted",
       "components:" not in f3 and "colors" in f3 and "TRAIN 0" in f3 and "all component facts omitted" in f3)

# R6-V3: object-level diff
o = ns_obj = {}
for s_ in A.R6_HELPER_SOURCES:
    exec(s_, ns_obj)
od = ns_obj["object_diff"]([[0, 0, 0, 0, 0], [0, 1, 1, 0, 0], [0, 0, 0, 0, 2], [3, 0, 0, 0, 0]],
                           [[0, 0, 0, 0, 0], [0, 0, 0, 1, 1], [0, 0, 0, 0, 5], [0, 0, 0, 0, 0]])
expect("V3: object_diff finds moved (with offset), recolored and removed objects",
       od["moved"]["examples"][0]["offset"] == (0, 2) and od["recolored"]["examples"][0]["new_color"] == 5
       and od["removed"]["count"] == 1 and od["added"]["count"] == 0, od)
expect("V3: object_diff is listed in the prompt and usable inside transform (trusted helper)",
       "object_diff(a, b)" in ag._system_prompt and "object_diff" in A.R6_HELPER_NAMES)

# M1: label-free overfit flags (never the test truth)
t20 = {"train": [{"input": [[0] * 20 for _ in range(4)], "output": [[0] * 20 for _ in range(4)]}],
       "test": [{"input": [[0] * 7 for _ in range(3)]}]}
fl = A.overfit_flags(t20, "def transform(g):\n    return [[g[r][(c + 10) % len(g[0])] for c in range(len(g[0]))] for r in range(len(g))]",
                     [[[0] * 7 for _ in range(3)]])
expect("M1: overfit signs: fixed offset tied to the train width, test output equal to its input",
       {"fixed_offset", "offset_tied_to_train_dims", "test_output_equals_input"} <= set(fl), fl)
agF, runF = fresh(task, "flipF")
runF("def transform(g):\n    k = 0 + 3 - 3\n    return [list(reversed(r)) for r in g]\ncheck(transform)")
vF = [v for v in agF.arc2_checked if v["accepted"]]
expect("M1/T7: a host-verified candidate carries its overfit signs and source size (scheduler + report)",
       vF and "fixed_offset" in vF[-1].get("overfit_flags", []) and vF[-1].get("source_chars", 0) > 0, vF)
runF("def transform(g):\n    return [list(reversed(r)) for r in g]\ncheck(transform)")
e6 = agF.arc2_rev6_events
expect("M1: per-branch events: tool calls, redefinitions, facts size and level",
       e6["tool_calls"] == 2 and e6["redefinitions"] == 1 and e6["facts_tokens"] > 0 and e6["facts_level"] is not None, e6)
sh = A.reasoning_shares("I count: 0 1 2 3 4\n[1, 2, 3, 4]\nthe same long sentence here\nthe same long sentence here")
expect("M1: hand-reading and loop proxies per reply", sh["grid"] > 0 and sh["repeat"] == len("the same long sentence here"), sh)

# R6-K2: harness limits are labelled as such
agF._python_timeout = 2
rT = runF("while True:\n    pass")
expect("K2: a sandbox time limit is labelled a harness limit (not a verdict on the rule)",
       "[harness limit" in rT.content and agF.arc2_rev6_events["infra_errors"] == 1, rT.content[-400:])

# Q-3: a transform using an unavailable global is not retained and never becomes a candidate
agQ, runQ = fresh(task, "flipQ")
rQ = runQ("def transform(g):\n    return missing_helper(g)\n")
expect("Q-3: a transform calling an unavailable global is rejected by retention, no candidate",
       "transform" not in (agQ._kept_functions or {}) and not agQ.arc2_checked, (agQ._kept_functions, rQ.content[-300:]))

# 2 exact pairs + 1 timeout -> rejected (pending since rev 2/3)
t3 = {"train": [{"input": [[1, 2], [3, 4]], "output": [[2, 1], [4, 3]]}, {"input": [[5, 6]], "output": [[6, 5]]},
                {"input": [[1, 1, 1], [2, 2, 2], [3, 3, 3]], "output": [[1, 1, 1], [2, 2, 2], [3, 3, 3]]}],
      "test": [{"input": [[7, 8]]}]}
ag3b, run3b = fresh(t3, "slow")
ag3b._python_timeout = 2
run3b("def transform(g):\n    while len(g) == 3:\n        pass\n    return [list(reversed(r)) for r in g]\n")
v3 = ag3b._verify_submission("transform")
expect("regression: exact on 2 pairs + a timeout on the 3rd -> rejected, timeout recorded",
       not v3["accepted"] and v3["train_exact"][:2] == [True, True] and v3.get("verify_timed_out"), v3)

# R6-D3: reasoning-only blocks are dropped first; blocks stay whole; the newest block stays
H = [{"role": "user", "content": "u1"},
     {"role": "assistant", "content": "", "tool_calls": [{"id": "c1", "type": "function", "function": {"name": "python", "arguments": "{}"}}]},
     {"role": "tool", "tool_call_id": "c1", "content": "r1"},
     {"role": "user", "content": "u2"}, {"role": "assistant", "content": "long reasoning, no call"},
     {"role": "user", "content": "u3"},
     {"role": "assistant", "content": "", "tool_calls": [{"id": "c3", "type": "function", "function": {"name": "python", "arguments": "{}"}}]},
     {"role": "tool", "tool_call_id": "c3", "content": "r3"},
     {"role": "user", "content": "u4"}]


def paired(h):
    for i, m in enumerate(h):
        if m["role"] == "tool" and not any(c.get("id") == m["tool_call_id"] for x in h[:i] if x["role"] == "assistant"
                                           for c in (x.get("tool_calls") or [])):
            return False
    return True


agD, _ = fresh(task, "trim")
h1 = list(H)
agD._drop_oldest_history_block(h1, preserve_recent=1)
expect("D3: the reasoning-only block goes first; the tool-result blocks stay paired",
       [m["content"] for m in h1 if m["role"] == "user"] == ["u1", "u3", "u4"] and paired(h1), h1)
agD._drop_oldest_history_block(h1, preserve_recent=1)
expect("D3: then Duck's oldest-block rule; calls and results still paired; newest block kept",
       [m["content"] for m in h1 if m["role"] == "user"] == ["u3", "u4"] and paired(h1)
       and agD.arc2_rev6_events["trim_reasoning_only_blocks"] == 1, h1)


# R6-S3 fair share: long stage-2 branches pause softly and are re-queued, so more tasks get stage-2 compute
class FakeSlow(FakeAgent):
    def __init__(self, **kw):
        super().__init__(**kw)
        self.solve_at = None

    busy_violations = []

    def analyze(self, state_path, n, *, should_stop, **kw):
        if should_stop():
            return FakeResult()
        if getattr(self, "_busy", False):
            FakeSlow.busy_violations.append((self.task_id, self.branch))
        self._busy = True
        time.sleep(0.05)
        self.generated_tokens += 4000
        self.total_tokens = self.generated_tokens
        self._busy = False
        return FakeResult()


t30 = {f"t{i:03d}": {"train": [], "test": [{"input": [[0]]}]} for i in range(30)}
o30 = sorted(t30)


def fair(flag):
    r = A.solve_all_r6(t30, o30, out_dir=tmp / f"fair{int(flag)}", deadline=time.monotonic() + 10, base_url="x", model_id="m",
                       branches=2, max_generated_tokens=400000, workers=4, first_exposure_tokens=8000, agent_cls=FakeSlow,
                       min_admit_sec=0.5, min_chunk_tokens=8000, fair_share=flag, share_warmup_sec=0.3)
    st2 = {t for t in o30 for x in r[t] for run_ in x.get("runs") or [] if run_.get("stage") == 2}
    return r, st2, dict(A.SCHED_LAST)


rF, st2F, schF = fair(True)
rN, st2N, _ = fair(False)
runsF = [run_ for t in o30 for x in rF[t] for run_ in x.get("runs") or []]
expect("S3: with fair share more tasks get stage-2 compute than without (no starvation by long branches)",
       len(st2F) > len(st2N) and len(st2F) >= 20, (len(st2F), len(st2N)))
expect("S3: stage-2 runs pause softly at their share and resume later (rounds), with the same agent",
       any(len(x.get("runs") or []) >= 3 for t in o30 for x in rF[t]) and schF.get("shares"), schF.get("shares", [])[:5])
expect("S3: a branch is never driven by two workers at once (re-queue skips running sessions)",
       not FakeSlow.busy_violations, FakeSlow.busy_violations[:5])
counts = sorted(sum(r_.get("tokens", 0) for x in rF[t] for r_ in x.get("runs") or [] if r_.get("stage") == 2) for t in o30)
expect("S3: round robin: stage-2 tokens are spread over the tasks (max task <= 4x the median)",
       counts[len(counts) // 2] > 0 and counts[-1] <= 4 * counts[len(counts) // 2], (counts[:3], counts[len(counts) // 2], counts[-3:]))
expect("S3: overshoot past a soft pause is recorded and bounded by one request",
       all(0 <= run_["overshoot"] <= 4000 for run_ in runsF if "overshoot" in run_) and any("overshoot" in run_ for run_ in runsF))


# rev 6c: the user-approved stage-2 p90 cutoff (off by default): stage-2 items are dropped near the deadline, stage 1 never
rP = A.solve_all_r6(t30, o30, out_dir=tmp / "p90", deadline=time.monotonic() + 8, base_url="x", model_id="m", branches=2,
                    max_generated_tokens=400000, workers=4, first_exposure_tokens=8000, agent_cls=FakeSlow, min_admit_sec=0.3,
                    min_chunk_tokens=40000, fair_share=True, share_warmup_sec=0.3, stage2_p90_cutoff=True)
schP = dict(A.SCHED_LAST)
expect("6c p90 cutoff on: the run completes, recorded as on, and every task still got branch 0 (stage 1 exempt)",
       schP.get("stage2_p90_cutoff") is True and schP.get("p90_skipped", -1) >= 0
       and all(any(x["branch"] == 0 and x.get("generated_tokens", 0) > 0 for x in rP[t]) for t in o30),
       (schP.get("p90_skipped"), len(schP.get("durations") or [])))
_d = [100, 200, 300, 400, 800]
expect("6d cutoff rule (deterministic): skip when left < nearest-rank p90 (800 s here; capped at 900 s); needs >= 5 runs",
       A.stage2_cutoff_hit(500, _d, 240) and not A.stage2_cutoff_hit(850, _d, 240) and not A.stage2_cutoff_hit(10, _d[:4], 240)
       and A.stage2_cutoff_hit(899, _d + [5000] * 5, 240) and not A.stage2_cutoff_hit(901, _d + [5000] * 5, 240)
       and A.stage2_cutoff_hit(200, [1] * 5, 240))
expect("6c p90 cutoff off by default (recorded)", A.solve_all_r6.__defaults__ is None
       or A.solve_all_r6.__kwdefaults__.get("stage2_p90_cutoff") is False, A.solve_all_r6.__kwdefaults__)


# T7: inside class 2, tasks whose candidate carries an overfit sign get branch 1 first; the class is recorded
class FakeFlag(FakeAgent):
    def analyze(self, state_path, n, *, should_stop, **kw):
        if should_stop():
            return FakeResult()
        with FakeAgent.lock:
            FakeAgent.log.append((time.monotonic(), self.task_id, self.branch, self.generated_tokens))
        time.sleep(0.01)
        self.generated_tokens += 4000
        if not self.arc2_checked:
            flags = ["fixed_offset"] if int(self.task_id[1:]) % 2 == 0 and self.branch == 0 else []
            self.arc2_checked.append({"name": "transform", "accepted": True, "test_outputs": [[[self.branch]]],
                                      "t": time.time(), "overfit_flags": flags})
        return FakeResult()


FakeAgent.log = []
t6 = {f"t{i:03d}": {"train": [], "test": [{"input": [[0]]}]} for i in range(6)}
r7 = A.solve_all_r6(t6, sorted(t6), out_dir=tmp / "t7", deadline=time.monotonic() + 4, base_url="x", model_id="m",
                    branches=2, max_generated_tokens=12000, workers=1, first_exposure_tokens=4000, agent_cls=FakeFlag,
                    min_admit_sec=0.5)
b1_first = []
for t_, tid, b, tok in FakeAgent.log:
    if b == 1 and tid not in b1_first:
        b1_first.append(tid)
expect("T7: class 2 (one verified prediction): flagged tasks get branch 1 before unflagged ones",
       b1_first[:3] == ["t000", "t002", "t004"] and set(b1_first[3:]) == {"t001", "t003", "t005"}, b1_first)
expect("M1: branch 1 records carry the stage-2 class they were started in (yield by class)",
       all(x.get("stage2_class") == 2 for t in t6 for x in r7[t] if x["branch"] == 1), [x.get("stage2_class") for t in t6 for x in r7[t]])
expect("S6: the final snapshot keeps the candidates of branches paused at the deadline",
       all(any(c["accepted"] for c in x.get("checked") or []) for t in t6 for x in r7[t] if x["branch"] == 0))


# P4: a worker exception and a hung model request near the deadline
class FakeBoom(FakeAgent):
    def analyze(self, state_path, n, *, should_stop, **kw):
        if self.task_id == "t001":
            raise RuntimeError("boom")
        return super().analyze(state_path, n, should_stop=should_stop, **kw)


rB = A.solve_all_r6(t6, sorted(t6), out_dir=tmp / "boom", deadline=time.monotonic() + 3, base_url="x", model_id="m",
                    branches=1, max_generated_tokens=8000, workers=3, first_exposure_tokens=None, agent_cls=FakeBoom,
                    min_admit_sec=0.5)
expect("P4: a worker exception ends only its branch (recorded); every other task still runs",
       "boom" in rB["t001"][0]["note"] and all(rB[t] and rB[t][0]["generated_tokens"] > 0 for t in sorted(t6) if t != "t001"),
       {t: (rB[t][0].get("note"), rB[t][0].get("generated_tokens")) for t in sorted(t6)})
import socket  # noqa: E402
hang = socket.socket()
hang.bind(("127.0.0.1", 0))
hang.listen(8)
held = []
threading.Thread(target=lambda: [held.append(hang.accept()) for _ in range(8)], daemon=True).start()
sess = A.BranchSession(Agent, task_id="hang", task=task, branch=0, view="facts", queue_position=0, out_dir=tmp / "hang",
                       deadline=time.monotonic() + 4, base_url=f"http://127.0.0.1:{hang.getsockname()[1]}/v1",
                       model_id="qwen", save_request_logs=False, analyzer_timeout=1800, backoff=1.0)
tH = time.monotonic()
sess.run()
expect("P4: a request hanging at the server ends at the deadline (1,800 s analyzer timeout clamped), record written",
       time.monotonic() - tH < 4 + 4 and sess.status == "done" and (tmp / "hang" / "hang_b0" / "branch_result.json").exists(),
       round(time.monotonic() - tH, 1))

# ================================================================== rev 6d (items 1-5 of the three rev 6c audits)
mk = [f"ZQ{i:02d}X" for i in range(12)]   # fixed width: no marker is a substring of another
v_pass = A.isolation_verdict(mk, [f"code {m}" for m in mk])
v_leak = A.isolation_verdict(mk, [f"code {m}" for m in mk[:-1]] + [f"{mk[-1]} {mk[0]}"])
v_none = A.isolation_verdict(mk, ["" for _ in mk])
expect("6d C6-2: isolation PASS only with every own marker and no leak; a leak = FAIL; empty replies = INCONCLUSIVE",
       (v_pass["isolation_state"], v_leak["isolation_state"], v_none["isolation_state"]) == ("PASS", "FAIL", "INCONCLUSIVE")
       and v_pass["isolation_ok"] is True and v_leak["isolation_ok"] is False and v_none["isolation_ok"] is None,
       (v_pass, v_leak, v_none))
expect("6d C6-2: 12 workers only on PASS; FAIL / INCONCLUSIVE / error -> 6",
       [A.workers_for_isolation(x, 12) for x in (True, False, None)] == [12, 6, 6])
expect("6d A3-F3: nearest-rank p90 ([100, 200, 300, 400, 800] -> 800)",
       A.p90_nearest_rank([100, 200, 300, 400, 800]) == 800 and A.p90_nearest_rank([5]) == 5)
_over = [t for t, v in EV.items() if A.reasoning_tokens(A.arc2_facts_bounded(v)) > 800]
_miss = [t for t, v in EV.items() if A._facts_level(A.arc2_facts_bounded(v)) < 6
         and not all(f"TEST {j}" in A.arc2_facts_bounded(v) for j in range(len(v["test"])))]
expect("6d C6-5 / A2-1: facts within 800 tokens on all 120 eval tasks; every test input listed", not _over and not _miss,
       (_over[:5], _miss[:5]))
f4 = A.arc2_facts(EV["d8e07eb2"], level=4)
expect("6d: level 4 keeps shapes, color counts and changed cells, and says where the details are",
       "-> out" in f4 and "changed cells" in f4 and "inspect_pair" in f4 and A._facts_level(f4) == 4, f4[:300])
os.environ["E12_R6_FACTS_MAX_TOKENS"] = "5"
agO, _ = fresh(task, "over")
os.environ.pop("E12_R6_FACTS_MAX_TOKENS")
expect("6d: an impossible bound -> the counts-only level, flagged facts_over_target (never cut mid-line)",
       agO.arc2_rev6_events["facts_level"] == 6 and agO.arc2_rev6_events["facts_over_target"] is True
       and ag.arc2_rev6_events.get("facts_over_target") in (False, None), agO.arc2_rev6_events)

# C6-4: one absolute join cutoff; a stuck worker never delays the return or rewrites the records afterwards
class FakeStuck(FakeAgent):
    def analyze(self, state_path, n, *, should_stop, **kw):
        if self.task_id in ("t000", "t001", "t002"):
            time.sleep(4)                    # ignores should_stop, like a native call that does not return
        return super().analyze(state_path, n, should_stop=should_stop, **kw)


_pub = []
tJ = time.monotonic()
rJ = A.solve_all_r6(t6, sorted(t6), out_dir=tmp / "stuck", deadline=time.monotonic() + 1.0, base_url="x", model_id="m",
                    branches=1, max_generated_tokens=8000, workers=6, first_exposure_tokens=None, agent_cls=FakeStuck,
                    min_admit_sec=0.2, join_grace_sec=0.5, on_branch_done=_pub.append)
dJ = time.monotonic() - tJ
n_after_return = len(_pub)
snap_after = json.dumps(rJ, default=str, sort_keys=True)
time.sleep(4.5)
expect("6d C6-4: three stuck workers -> the call returns by deadline + grace (not 3 x 120 s); stragglers counted",
       dJ < 1.0 + 0.5 + 1.0 and A.SCHED_LAST.get("stragglers", 0) >= 1, (round(dJ, 2), A.SCHED_LAST.get("stragglers")))
expect("6d C6-4: a straggler finishing later never rewrites the published records",
       len(_pub) == n_after_return and json.dumps(rJ, default=str, sort_keys=True) == snap_after, (n_after_return, len(_pub)))
expect("6d A3-F4: the scheduler reports tasks exposed and stage-1 starts left",
       "tasks_exposed" in A.SCHED_LAST and "stage1_left" in A.SCHED_LAST, sorted(A.SCHED_LAST))

# ================================================================== rev 6e (fix list G4-1..G4-18)
# G4-5: arc_overview() never repeats the system-prompt facts
r, p = run("arc_overview()")
expect("G4-5: arc_overview() does not reprint the system-prompt facts",
       "ARC TASK FACTS" not in r.content and ("complete (not repeated here)" in r.content
                                              or "left out of the system prompt" in r.content), r.content[-300:])
fx, fb2 = A.arc2_facts_extra(EV["135a2760"]), A.arc2_facts_bounded(EV["135a2760"])
expect("G4-5: the extra facts are only lines the bounded block lacks (plus their TRAIN/TEST header)",
       fx and "largest" in fx and all(ln not in fb2.splitlines() or ln.startswith(("TRAIN ", "TEST "))
                                      for ln in fx.splitlines()), fx[:300])
expect("G4-5: nothing extra when the full facts fit", A.arc2_facts_extra(shape_task) == "")

# G4-10 / G4-16: candidate-first wording and helper examples in the prompt
expect("G4-10: candidate-first lines in the prompt",
       "Use the first Python call for evidence" in sp and "test your simplest current hypothesis" in sp
       and "Do not reconstruct grids by hand" in sp)
expect("G4-16: helper and check_many examples in the prompt",
       "Examples: `objs = components(g, ignore=modal_color(g))`" in sp and "check_many({'a': transform, 'b': transform_alt})" in sp
       and "a whole grid up to 30x30" in sp)

# G4-11: the branch-1 indexed view (show() layout), bounded
ip = A.arc2_system_prompt_r6(task, DP, 3072, view="indexed")
expect("G4-11: indexed view = facts + every grid with row/column indices", "ARC TASK FACTS" in ip
       and "Training pair 0 input (2x3):" in ip and "r00 | " in ip and "Test input 0" in ip, ip[-400:])
big = EV["135a2760"]
os.environ["E12_R6_B1_GRID_MAX_TOKENS"] = "200"
ib = A.arc2_indexed_grids(big)
os.environ.pop("E12_R6_B1_GRID_MAX_TOKENS")
expect("G4-11: over the bound -> large grids become a show() pointer, every grid still listed",
       "not shown here for size; use show(" in ib and all(f"Training pair {i} input" in ib for i in range(len(big["train"])))
       and "Test input 0" in ib, ib[:300])

# G4-6: one provisional-transform nudge, token-triggered
ag6, run6 = fresh(task, "nudge")
ag6._resume_after_yield, ag6._resume_reason = True, "yield_tools"
ag6._session_generated_tokens = 23000
expect("G4-6: no nudge below the threshold (24,000 since rev 6f)", not op(ag6).startswith(A.R6_TEXT["provisional"][:40]))
ag6._session_generated_tokens = 24500
o1 = op(ag6)
expect("G4-6: nudge once past 24,000 tokens without a solution function (opener path when no tool result came first)",
       o1.startswith(A.R6_TEXT["provisional"][:40]) and ag6.arc2_rev6_events["provisional_nudge_tokens"] == 24500
       and ag6.arc2_rev6_events["provisional_nudge_via"] == "opener", o1[:120])
expect("G4-6: sent only once", not op(ag6).startswith(A.R6_TEXT["provisional"][:40]))
ag7, run7 = fresh(task, "nudge2")
run7("def transform(g):\n    return [r[::-1] for r in g]")
ag7._resume_after_yield, ag7._resume_reason = True, "yield_tools"
ag7._session_generated_tokens = 40000
expect("G4-14 / G4-6: a defined transform records first_transform_tokens and suppresses the nudge",
       ag7.arc2_rev6_events["first_transform_tokens"] is not None and not op(ag7).startswith(A.R6_TEXT["provisional"][:40]))
ag8, run8 = fresh(task, "nudge3")
run8("def helper(g):\n    return g")
expect("G4-14: a helper-named function does not count as a transform", ag8.arc2_rev6_events["first_transform_tokens"] is None)
ag9, _ = fresh(task, "nudge4")
ag9._resume_after_yield, ag9._resume_reason = True, "yield_tools"
ag9._session_generated_tokens = 30000
ag9._arc2_cut_pending = True
expect("G4-6: a cut call keeps precedence over the nudge", op(ag9).startswith(A.R6_TEXT["cut"][:40]))

# G4-18: improvement of the same function vs a new hypothesis
agP, runP = fresh(task, "prog")
runP("def transform(g):\n    return g\ncheck(transform)")
runP("def transform(g):\n    return [r[::-1] for r in g]\ncheck(transform)")
runP("def transform_b(g):\n    return g\ncheck(transform_b)")
e = agP.arc2_rev6_events
expect("G4-18: one same-function improvement, two new hypotheses",
       e["progress_same_improved"] == 1 and e["progress_new_hypothesis"] == 2 and e["progress_reports"] >= 3, e)

# G4-15: per-request instrumentation (message-level prefix, trim flag, idle time, null cache = 0, server gauges)
class _U:
    def __init__(self, usage, finish="stop"):
        self.usage, self.finish_reason = usage, finish
        self.message = {"role": "assistant", "content": "ok", "tool_calls": []}


_seq = iter([_U({"prompt_tokens": 100}), _U({"prompt_tokens": 150, "prompt_tokens_details": {"cached_tokens": 90}}),
             _U({"prompt_tokens": 120})])
TA.ToolAgent._chat_completion = lambda self, m, **kw: next(_seq)
try:
    agR, _ = fresh(task, "req")
    A.SERVER_LAST.update(kv_usage=0.3, mamba_usage=0.6, running=11, queue=1)
    m1 = [{"role": "system", "content": "s"}, {"role": "user", "content": "u1"}]
    agR._chat_completion(m1, tools=None)
    m2 = m1 + [{"role": "assistant", "content": "a1"}, {"role": "user", "content": "u2"}]
    agR._chat_completion(m2, tools=None)
    agR._arc2_trimmed_flag = True
    agR._chat_completion([{"role": "system", "content": "s"}, {"role": "user", "content": "u3"}], tools=None)
finally:
    TA.ToolAgent._chat_completion = _orig
q1, q2, q3 = agR.arc2_requests
expect("G4-15: request 1 has no previous request; null cache detail = 0 cached, flagged as not reported",
       q1["prefix_ok"] is None and q1["cached"] == 0 and q1["cached_reported"] is False and q1["kv"] == 0.3
       and q1["mamba"] == 0.6, q1)
expect("G4-15: request 2 extends request 1 -> prefix intact; reported cache read", q2["prefix_ok"] is True
       and q2["prefix_msgs"] == 2 and q2["cached"] == 90 and q2["cached_reported"] and q2["idle_sec"] is not None, q2)
expect("G4-15: request 3 after a trim -> prefix broken, trimmed flag set", q3["prefix_ok"] is False and q3["trimmed"] is True, q3)

# G4-12: a branch 0 with partial progress is refined before a fresh branch 1 until a stage-2 round brings no gain
class FakeProg(FakeAgent):
    def analyze(self, state_path, n, *, should_stop, **kw):
        if should_stop():
            return FakeResult()
        with FakeAgent.lock:
            FakeAgent.log.append((time.monotonic(), self.task_id, self.branch, self.generated_tokens))
        time.sleep(0.002)
        self.generated_tokens += 4000
        self.total_tokens = self.generated_tokens
        grow = self.task_id.endswith(("0", "2", "4", "6", "8"))      # even tasks keep improving, odd ones stall
        acc = round(0.001 * self.generated_tokens, 3) if grow else 0.1
        if self.branch == 0:
            self.arc2_progress["best"] = {"name": "t", "k": 1, "n": 3, "acc": acc}
        return FakeResult()


FakeAgent.log = []
t10 = {f"p{i:02d}": {"train": [], "test": [{"input": [[0]]}]} for i in range(10)}
A.solve_all_r6(t10, sorted(t10), out_dir=tmp / "g412", deadline=time.monotonic() + 4.0, base_url="x", model_id="m",
               branches=2, max_generated_tokens=10 ** 9, workers=4, first_exposure_tokens=8000, agent_cls=FakeProg,
               min_admit_sec=0.2, min_chunk_tokens=8000, fair_share=True, share_warmup_sec=0.0)
b1_started = {tid for _, tid, b, _ in FakeAgent.log if b == 1}
grow_ids = {t for t in t10 if t.endswith(("0", "2", "4", "6", "8"))}
expect("G4-12: an improving partial branch 0 never gets a fresh branch 1 (deterministic)",
       not (b1_started & grow_ids), (sorted(b1_started), sorted(grow_ids)))
expect("G4-12: a stalled partial branch 0 gets branch 1 after a no-gain stage-2 round",
       bool(b1_started & (set(t10) - grow_ids)), sorted(b1_started))


# ================================================================== rev 6f (GPT rev 6e audits, H6 items)
# H6-1: the provisional nudge goes out in the next TOOL RESULT once past 24,000 tokens (G4B: no branch 0 started a new turn
# at >= 27k before the 28k pause, so an opener-borne nudge never reached stage 1)
agN, runN = fresh(task, "h61")
runN("pass")                          # opens Duck's session first (it resets the token counters)
agN._session_generated_tokens = 23000
rN = runN("print('inspect')")
expect("H6-1: no nudge in a tool result below 24,000", "harness_note" not in rN.content, rN.content[-200:])
agN._session_generated_tokens = 24500
rN = runN("print('inspect again')")
expect("H6-1: past 24,000 with no one-grid solution function and no check -> the nudge is in this tool result",
       "harness_note" in rN.content and "provisional `transform(grid)`" in rN.content
       and agN.arc2_rev6_events["provisional_nudge_via"] == "tool"
       and agN.arc2_rev6_events["provisional_nudge_tokens"] == 24500, rN.content[-300:])
rN = runN("print('third')")
agN._resume_after_yield, agN._resume_reason = True, "yield_tools"
expect("H6-1: sent once (not in the next tool result, not in a later opener)", "harness_note" not in rN.content
       and not op(agN).startswith(A.R6_TEXT["provisional"][:40]))
agT, runT = fresh(task, "h61b")      # audit 1's timeline: requests 0 -> 12,288 -> 36,864, no transform, then the pause
runT("pass")                          # the first tool call opens Duck's session (it resets the token counters)
agT._session_generated_tokens = 36864
rT = runT("print('late inspection')")
expect("H6-1: a tool call at 36,864 (the request that crosses the 28k pause) carries the nudge into the history",
       "harness_note" in rT.content, rT.content[-200:])
runN("def transform(g):\n    return [r[::-1] for r in g]")
expect("H6-18: first transform after the nudge recorded",
       agN.arc2_rev6_events["first_transform_after_nudge"] == 24500, agN.arc2_rev6_events)
agS, runS = fresh(task, "h61c")
runS("def transform(g):\n    return g")
agS._session_generated_tokens = 30000
expect("H6-1: a one-grid transform suppresses the tool-result nudge", "harness_note" not in runS("print(1)").content)

# H6-2: only a one-grid solution-named function counts (the auto-check predicate)
agQ, runQ = fresh(task, "h62")
runQ("def transform(a, b):\n    return a")
runQ("def solve_row(r, i):\n    return r[::-1]")
expect("H6-2: transform(a, b) and solve_row(r, i) are not a first transform", agQ.arc2_rev6_events["first_transform_tokens"] is None)
agQ._session_generated_tokens = 24100
expect("H6-2: so the nudge still goes out", "harness_note" in runQ("print(2)").content)
agQ._session_generated_tokens = 25000
runQ("def transform(g):\n    return g")
t1 = agQ.arc2_rev6_events["first_transform_tokens"]
agQ._session_generated_tokens = 26000
runQ("def transform(g):\n    return g")
expect("H6-2: a one-grid transform counts; redefining it unchanged does not reset the timestamp", t1 == 25000
       and agQ.arc2_rev6_events["first_transform_tokens"] == 25000, agQ.arc2_rev6_events["first_transform_tokens"])

# H6-9 / H6-11: program identity = source + dependencies; same name with a new source is logged
agK, runK = fresh(task, "h69")
runK("def transform(g):\n    return [r[::-1] for r in g]\ncheck(transform)")
k1 = [v.get("src_key") for v in agK.arc2_checked]
runK("def transform(g):\n    return [list(reversed(r)) for r in g]\ncheck(transform)")
k2 = [v.get("src_key") for v in agK.arc2_checked]
expect("H6-9: every verdict carries a source key; a new source under the same name gets a new key",
       len(k2) == 2 and all(k2) and k2[0] != k2[1] and k1 == k2[:1], k2)
expect("H6-11: the same name with a new source is counted", agK.arc2_rev6_events["progress_same_name_new_source"] == 1
       and (agK.arc2_progress.get("best") or {}).get("src") == k2[1], agK.arc2_rev6_events)

# H6-10: payload hash, character prefix and tools / template identity per request
_seq2 = iter([_U({"prompt_tokens": 100}), _U({"prompt_tokens": 150}), _U({"prompt_tokens": 160})])
TA.ToolAgent._chat_completion = lambda self, m, **kw: next(_seq2)
try:
    agH, _ = fresh(task, "h610")
    h1 = [{"role": "system", "content": "s"}, {"role": "user", "content": "u1"}]
    agH._chat_completion(h1, tools=[{"type": "function", "function": {"name": "python"}}])
    h2 = h1 + [{"role": "assistant", "content": "a1"}, {"role": "user", "content": "u2"}]
    agH._chat_completion(h2, tools=[{"type": "function", "function": {"name": "python"}}])
    agH._chat_completion(h2 + [{"role": "user", "content": "u3"}], tools=[{"type": "function", "function": {"name": "py2"}}])
finally:
    TA.ToolAgent._chat_completion = _orig
w1, w2, w3 = agH.arc2_requests
expect("H6-10: payload hash + characters; request 2 shares request 1's characters; tools unchanged",
       w1["payload_sha"] and w1["prefix_chars"] is None and w2["prefix_chars"] >= w1["chars"] - 2
       and w2["tools_same"] is True and w2["template_same"] is True and w2["payload_sha"] != w1["payload_sha"], (w1, w2))
expect("H6-10: a tools change is flagged", w3["tools_same"] is False, w3)

# H6-7: the indexed-view bound is hard, also when every grid is <= 400 cells
_g20 = [[(r * 7 + c * 3) % 10 for c in range(20)] for r in range(20)]
_t20 = {"train": [{"input": _g20, "output": _g20} for _ in range(10)], "test": [{"input": _g20} for _ in range(3)]}
_iv = A.arc2_indexed_grids(_t20)
expect("H6-7: 10 train + 3 test 20x20 -> within 12,000 tokens, every grid still listed (pointers for the rest)",
       A.reasoning_tokens(_iv) <= 12000 and all(f"Training pair {i} input" in _iv and f"Training pair {i} output" in _iv
                                                 for i in range(10)) and all(f"Test input {j}" in _iv for j in range(3))
       and "not shown here for size" in _iv, (A.reasoning_tokens(_iv), _iv.count("not shown here")))
expect("H6-7: a task within the bound is unchanged (no pointer)", "not shown here" not in A.arc2_indexed_grids(task))


# H6-8: the G4-12 deferral is one predicate, checked at queue time and again when a queued branch-1 start is popped
class _St:
    def __init__(self, best, checked=()):
        self.arc2_progress, self.arc2_checked, self.arc2_submissions = {"best": best}, list(checked), []


def _sess(b, best, runs, status="paused", checked=()):
    s_ = A.BranchSession(None, task_id="d", task={}, branch=b, view="facts", queue_position=0, out_dir=tmp, deadline=0,
                         base_url="x", model_id="m", save_request_logs=False)
    s_.agent, s_.status = _St(best, checked), status
    s_.record["runs"] = runs
    return s_


_prog = {"name": "t", "k": 1, "n": 3, "acc": 0.5}
s_imp = _sess(0, _prog, [{"stage": 1}, {"stage": 2, "improved": True}])
s_stall = _sess(0, _prog, [{"stage": 1}, {"stage": 2, "improved": False}])
s_none = _sess(0, None, [{"stage": 1}])
s_done = _sess(0, _prog, [{"stage": 2, "improved": True}], status="done")
s_ver = _sess(0, _prog, [{"stage": 2, "improved": True}], checked=[{"accepted": True, "test_outputs": [[[1]]]}])
expect("H6-8: defer branch 1 while a partial branch 0 improves; not when it stalled, has no progress, is done or verified",
       A.g412_defer_b1([s_imp], s_imp) and not A.g412_defer_b1([s_stall], s_stall)
       and not A.g412_defer_b1([s_none], s_none) and not A.g412_defer_b1([s_done], s_done)
       and not A.g412_defer_b1([s_ver], s_ver) and not A.g412_defer_b1([], None))
_src6 = open(A.__file__, encoding="utf-8").read()
expect("H6-8: the scheduler uses the predicate at queue time and at pop time (only while branch 0 is queued or running)",
       _src6.count("g412_defer_b1(") == 3 and "state[\"b1_deferred_at_pop\"] += 1" in _src6
       and "(tid, 0) in queued or (tid, 0) in active" in _src6)

# R6-P3 (no test until the rev 6f self-audit): the generalization note goes out once, with the first kept candidate
agG, runG = fresh(task, "p3")
rG1 = runG("def transform(g):\n    return [r[::-1] for r in g]\ncheck(transform)")
# a second DISTINCT kept candidate (exact on train, a different output on the 1-row test input), so the note could recur
rG2 = runG("def transform_v2(g):\n    return [r[::-1] for r in g] if len(g) > 1 else [list(r) for r in g]\ncheck(transform_v2)")
rG3 = runG("def solve_b(g):\n    return [r[::-1] for r in g]\ncheck(solve_b)")
_gen = A.R6_GENERALIZE.strip()[:60]
expect("R6-P3: the generalization note comes with the first kept candidate, never again (also not with a second distinct one)",
       _gen in rG1.content and "Kept `transform_v2`" in rG2.content and "2 distinct saved" in rG2.content
       and _gen not in rG2.content and _gen not in rG3.content and agG._arc2_generalize_sent,
       (rG1.content[-300:], rG2.content[-200:]))

# H6-14: each run records the new distinct verified predictions it produced
expect("H6-14: runs carry new_verified", all("new_verified" in x for v in recs.values() for r_ in v for x in r_.get("runs", []))
       and sum(x["new_verified"] for v in recs.values() for r_ in v for x in r_.get("runs", [])) > 0)


# H6-4: a straggler never rewrites branch_result.json after the scheduler returned (3 stuck workers; files frozen)
class FakeStuck2(FakeAgent):
    def analyze(self, state_path, n, *, should_stop, **kw):
        if self.task_id in ("t000", "t001", "t002") and self.generated_tokens >= 4000:
            time.sleep(4)                    # the second request hangs past deadline + grace, then returns tokens
        return super().analyze(state_path, n, should_stop=should_stop, **kw)


import hashlib as _hl  # noqa: E402
_pub2 = []
rF = A.solve_all_r6(t6, sorted(t6), out_dir=tmp / "stuck2", deadline=time.monotonic() + 1.0, base_url="x", model_id="m",
                    branches=1, max_generated_tokens=8000, workers=6, first_exposure_tokens=None, agent_cls=FakeStuck2,
                    min_admit_sec=0.2, join_grace_sec=0.5, on_branch_done=_pub2.append)
_files = {t: tmp / "stuck2" / f"{t}_b0" / "branch_result.json" for t in ("t000", "t001", "t002")}
_h0 = {t: _hl.sha256(f.read_bytes()).hexdigest() for t, f in _files.items() if f.exists()}
_n0, _s0 = len(_pub2), json.dumps(rF, default=str, sort_keys=True)
time.sleep(5)
_h1 = {t: _hl.sha256(f.read_bytes()).hexdigest() for t, f in _files.items() if f.exists()}
_valid = all(json.loads(f.read_text(encoding="utf-8")) for f in _files.values() if f.exists())
expect("H6-4: three stuck workers; 5 s after the return every branch_result.json is unchanged and valid JSON, the "
       "published records and callback count are unchanged", A.SCHED_LAST.get("stragglers", 0) >= 1 and len(_h0) == 3
       and _h0 == _h1 and _valid and len(_pub2) == _n0 and json.dumps(rF, default=str, sort_keys=True) == _s0,
       (A.SCHED_LAST.get("stragglers"), len(_h0), _h0 == _h1, len(_pub2), _n0))

finish()
