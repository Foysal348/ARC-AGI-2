"""GPT rev 6e audits (G4-11): does arc2_indexed_grids() keep the 12,000-token bound on the 120 eval tasks (Qwen INT4
tokenizer)? Also: what the audits' patch (drop the 400-cell condition) would hide."""
import json
import os
import sys
from pathlib import Path

os.environ["E12_ARC2_REV6"] = "1"
os.environ["E12_TOKENIZER_JSON"] = str(Path(__file__).resolve().parent.parent / "fixtures/tok_int4/tokenizer.json")
sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent / "duck_arc2"))
import arc2_duck as A  # noqa: E402

ch = json.load(open(Path(__file__).resolve().parent.parent / "fixtures/data/arc-agi_evaluation_challenges.json",
                    encoding="utf-8"))
LIMIT = 12000
over, rows = [], []
for tid, task in sorted(ch.items()):
    text = A.arc2_indexed_grids(task)
    n = A.reasoning_tokens(text)
    hidden = text.count("not shown here for size")
    grids = 2 * len(task["train"]) + len(task["test"])
    small = all(len(q[k]) * len(q[k][0]) <= 400 for q in task["train"] for k in ("input", "output")) and \
        all(len(q["input"]) * len(q["input"][0]) <= 400 for q in task["test"])
    rows.append((tid, n, hidden, grids, small))
    if n > LIMIT:
        over.append((tid, n, hidden, grids, small))
ns = sorted(r[1] for r in rows)
print("tasks", len(rows), "| indexed-view tokens p50", ns[len(ns) // 2], "p90", ns[int(.9 * len(ns))], "max", ns[-1])
print("tasks over the 12,000 bound:", len(over))
for r in over:
    print("  ", r[0], "tokens", r[1], "| grids hidden", r[2], "of", r[3], "| all grids <= 400 cells:", r[4])
print("tasks with any grid hidden:", sum(1 for r in rows if r[2]))
