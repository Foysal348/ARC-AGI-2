"""H6-1 evidence from the G4B rev 6d transcripts (branch 0, 12 runs).
(1) Openers: at which generated-token counts did a new turn ([USER PROMPT]) start? An opener-borne nudge at 27k can only
    go out with one, so: did any stage-1 opener fall at >= 27k before the stage-1 pause?
(2) Tool results (rev 6f): with the nudge in the next tool result at 24k, which runs would get it inside stage 1, and how
    many tokens before the pause? (no one-grid solution function defined earlier)
Usage: python h6_1_g4b_nudge_delivery.py [duck dir of the G4B run]"""
import ast
import json
import re
import sys
from pathlib import Path

D = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[2] / "runs/rev6d_EVAL12R6G4B/duck"
CALL = re.compile(r"<parameter=code>\n(.*?)\n</parameter>", re.S)
SOL = re.compile(r"^(transform|solve|solution|predict)\w*$|^\w+_(alt\w*|v\d+)$")


def one_grid_solution(code):
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return False
    for n in tree.body:
        if isinstance(n, ast.FunctionDef) and SOL.match(n.name):
            a = n.args
            if len(a.posonlyargs) + len(a.args) - len(a.defaults) == 1 and not a.kwonlyargs:
                return True
    return False


op_hits, tool_rows = 0, []
for d in sorted(D.glob("*_b0")):
    r = json.load(open(d / "branch_result.json", encoding="utf-8"))
    comp = [int(u.get("completion") or 0) for u in r.get("usage") or []]
    tx = (d / "transcript.txt").read_text(encoding="utf-8", errors="replace")
    st1 = [x for x in r.get("runs") or [] if x.get("stage") == 1][0]["tokens"]
    starts, s = [], 0
    for c in comp:
        starts.append(s)
        s += c
    k, openers = 0, []
    for m in re.findall(r"^\[(USER PROMPT|MODEL RESPONSE META)\]", tx, re.M):
        if m == "USER PROMPT":
            openers.append(starts[k] if k < len(starts) else s)
        else:
            k += 1
    in_win = [o for o in openers if 27000 <= o < st1]
    op_hits += bool(in_win)
    parts = re.split(r"^\[MODEL RESPONSE META\]", tx, flags=re.M)
    cum, got, tr = 0, None, None
    for i, c in enumerate(comp):
        cum += c
        if cum > st1:
            break
        codes = CALL.findall(parts[i + 1] if i + 1 < len(parts) else "")
        if tr is None and any(one_grid_solution(cd) for cd in codes):
            tr = cum
        if got is None and tr is None and codes and cum >= 24000:
            got = cum
    tool_rows.append((d.name, st1, tr, got))
    print(f"{d.name}: stage-1 {st1} | openers {openers} | opener >= 27k in stage 1: {in_win} | first one-grid transform "
          f"{tr} | 24k tool-result nudge at {got}" + (f" ({st1 - got} before the pause)" if got else ""))
print(f"opener-borne 27k nudge inside stage 1: {op_hits} of {len(tool_rows)}")
print(f"tool-result 24k nudge inside stage 1: {sum(1 for x in tool_rows if x[3])} "
      f"(> 0 tokens before the pause: {sum(1 for x in tool_rows if x[3] and x[1] - x[3] > 0)}); transform first: "
      f"{sum(1 for x in tool_rows if x[2] and not x[3])}; neither: {sum(1 for x in tool_rows if not x[2] and not x[3])}")
