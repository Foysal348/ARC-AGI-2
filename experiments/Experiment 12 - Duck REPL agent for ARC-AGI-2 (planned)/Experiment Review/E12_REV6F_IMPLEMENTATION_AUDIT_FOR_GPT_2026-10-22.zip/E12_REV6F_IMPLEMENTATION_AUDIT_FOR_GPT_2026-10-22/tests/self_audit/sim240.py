"""Rev 6e self-audit: 240-task capacity simulation of the REAL solve_all_r6 + BranchSession (fix-list CPU gates of G4-1,
G4-12, G4-17 and GPT A2 R6-S1: "a 240-task capacity test"). Virtual time (arc2_duck's time and threading.Condition waits are
scaled), a fake agent whose requests take tokens / per-stream rate.

Measured inputs (G4B rev 6d, fix list):
- aggregate decode 370.9 tok/s at 11-12 running, 321.4 at 6 (20-40k context bin) -> agg(n) = 371 * min(1, n/12) ** 0.21;
- 180 requests for 572,035 tokens -> about 3.2k tokens per request (random 1k-12k here);
- hidden solve window = 42,720 - 1,463 s start = 41,257 s; 12 workers; first exposure 28,000; 100k soft cap per branch;
- min_admit_sec 240; KV pool 866,744; per-stream window 72,228.
Assumed (not measured, so outcomes are about the SCHEDULER, not about accuracy): which branches solve and when, partial
progress, and the context-to-KV model (context = 6k + 0.5 x generated, capped at the window; G4B KV max was 0.44).

Usage: python sim240.py [min_chunk] [scale]"""
import os
import random
import statistics as st
import sys
import tempfile
import threading
import time as _rt
from pathlib import Path

os.environ["E12_ARC2_REV6"] = "1"
os.environ["ARC3_MAX_ACTIVE_STREAMS"] = "64"
sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent / "duck_arc2"))
sys.path.insert(1, str(Path(__file__).resolve().parent.parent.parent / "duck_arc2/vendor"))
import arc2_duck as A  # noqa: E402

MIN_CHUNK = int(sys.argv[1]) if len(sys.argv) > 1 else 12288
SCALE = float(sys.argv[2]) if len(sys.argv) > 2 else 400.0          # virtual seconds per real second
SEED = int(sys.argv[3]) if len(sys.argv) > 3 else 1
WINDOW_SEC, WORKERS, POOL, CTX_WIN = 41257.0, 12, 866744, 72228
R0 = _rt.monotonic()


class VTime:                       # arc2_duck's view of time
    @staticmethod
    def monotonic():
        return R0 + (_rt.monotonic() - R0) * SCALE

    @staticmethod
    def time():
        return 1.7e9 + (_rt.monotonic() - R0) * SCALE

    @staticmethod
    def sleep(x):
        _rt.sleep(max(0.0, x) / SCALE)

    perf_counter = monotonic


class VCondition(threading.Condition):
    def wait(self, timeout=None):
        return super().wait(None if timeout is None else timeout / SCALE)


class VThreading:
    Thread = threading.Thread
    Condition = VCondition
    Lock = threading.Lock


A.time = VTime
A.threading = VThreading
TA, _, _, _ = A._import_duck()
TA._priority_gate = lambda: None   # 12 workers <= 12 streams: the real gate never blocks; its clock is real time

LOCK = threading.Lock()
RUNNING: dict = {}                 # agent id -> context tokens of a request in flight
STATS = {"requests": 0, "kv_max": 0.0}


RATE = float(os.environ.get("SIM_RATE", "371"))   # GPT audit 2: G4B end-to-end was 277 (with the 12->6 bug)


def agg_rate(n):
    return RATE * min(1.0, n / 12.0) ** 0.21


class R:
    retryable_failure, yielded_control, step_executed = False, True, False


class FakeAgent:
    def __init__(self, *, task, task_id, branch, view, **kw):
        self.task_id, self.branch = task_id, branch
        self.generated_tokens = self.total_tokens = 0
        self.arc2_accepted, self.arc2_submissions, self.arc2_usage, self.arc2_checked = None, [], [], []
        self.arc2_rev5_events, self.arc2_rev6_events, self.arc2_requests = {}, {}, []
        self.arc2_progress = {"best": None, "first_check_tokens": None, "runs": 0}
        self._arc2_deadline = None
        h = random.Random(f"{SEED}:{task_id}")
        u = h.random()
        # assumed solve model: 35 % of tasks solvable by branch 0, 10 % only by branch 1 (representation hedge)
        if branch == 0:
            self.solve_at = h.uniform(15000, 90000) if u < 0.35 else None
        else:
            self.solve_at = h.uniform(20000, 70000) if u < 0.45 else None
        # partial progress for half of the unsolved branches: improves every ~15k tokens until a stall point
        rb = random.Random(f"{SEED}:{task_id}:{branch}")
        self.partial = (self.solve_at is None and rb.random() < 0.5)
        self.stall_at = rb.uniform(30000, 80000)
        self.rng = rb

    def analyze(self, state_path, n, *, should_stop=None, request_timeout_seconds=None, **kw):
        if should_stop is not None and should_stop():
            return R()
        tok = self.rng.randint(1000, 12000)
        with LOCK:
            ctx = min(CTX_WIN, 6000 + 0.5 * (self.generated_tokens + tok))
            RUNNING[id(self)] = ctx
            n_run = len(RUNNING)
            STATS["requests"] += 1
            STATS["kv_max"] = max(STATS["kv_max"], sum(RUNNING.values()) / POOL)
        per_stream = agg_rate(n_run) / n_run
        dur = tok / per_stream
        left = (self._arc2_deadline - VTime.monotonic()) if self._arc2_deadline else dur
        if dur > left:                                  # R6-S6: the request is clamped to the deadline
            tok = int(tok * max(0.0, left) / dur)
            dur = max(0.0, left)
        VTime.sleep(dur)
        with LOCK:
            RUNNING.pop(id(self), None)
        self.generated_tokens += tok
        self.total_tokens += tok
        g = self.generated_tokens
        if self.solve_at and g >= self.solve_at and not self.arc2_checked:
            self.arc2_checked.append({"name": "transform", "accepted": True, "test_outputs": [[[self.branch]]],
                                      "t": VTime.time()})
        elif self.solve_at and self.arc2_checked and g >= self.solve_at + 3000 and self.arc2_accepted is None:
            self.arc2_accepted = {"name": "transform"}
        elif self.partial and g >= 20000:
            k = 1
            acc = min(0.95, 0.5 + 0.05 * int(min(g, self.stall_at) / 15000))
            self.arc2_progress["runs"] += 1
            self.arc2_progress["best"] = {"name": "transform", "k": k, "n": 3, "acc": acc, "tokens": g}
        return R()


def kv_probe():
    with LOCK:
        kv = sum(RUNNING.values()) / POOL
        return {"kv_usage": kv, "mamba_usage": 0.6, "running": len(RUNNING), "queue": 1}


tasks = {f"t{i:03d}": {"train": [], "test": [{"input": [[0]]}]} for i in range(240)}
order = sorted(tasks)
t_real = _rt.monotonic()
start = VTime.monotonic()
wall0 = VTime.time()
recs = A.solve_all_r6(tasks, order, out_dir=Path(tempfile.mkdtemp()),
                      deadline=start + WINDOW_SEC, base_url="x", model_id="m", branches=2, max_generated_tokens=100000,
                      workers=WORKERS, first_exposure_tokens=28000, b1_view="indexed", min_admit_sec=240,
                      capacity_probe=kv_probe, agent_cls=FakeAgent, min_chunk_tokens=MIN_CHUNK, kv_admit_limit=0.95,
                      kv_poll_sec=5.0, join_grace_sec=60.0)
S = A.SCHED_LAST
ev = S.get("events") or []
rows = [r for v in recs.values() for r in v]
b0 = [r for r in rows if r["branch"] == 0]
b1 = [r for r in rows if r["branch"] == 1]
tok_task = [sum(int(r.get("generated_tokens") or 0) for r in v) for v in recs.values()]
runs = [x for r in rows for x in r.get("runs", [])]
st1 = [x for x in runs if x.get("stage") == 1]
st2 = [x for x in runs if x.get("stage") == 2]
solved = sum(1 for v in recs.values() if any(r.get("accepted") or any(c.get("accepted") for c in r.get("checked") or [])
                                            for r in v))
solvable = sum(1 for t in tasks if random.Random(f"{SEED}:{t}").random() < 0.45)
q = lambda v, f: sorted(v)[min(len(v) - 1, int(f * len(v)))] if v else None
shares = S.get("shares") or []
print(f"rate {RATE} | min_chunk {MIN_CHUNK} | scale {SCALE} | real {round(_rt.monotonic() - t_real)} s | virtual window {WINDOW_SEC:.0f} s")
print("tasks exposed", S.get("tasks_exposed"), "/ 240 | stage-1 starts left", S.get("stage1_left"), "| heap left",
      S.get("heap_left"), "| stragglers", S.get("stragglers"))
print("branch 1 started", sum(1 for r in b1 if (r.get("generated_tokens") or 0) > 0), "| b0 done", sum(1 for r in b0
      if r.get("status") == "done"), "paused", sum(1 for r in b0 if r.get("status") == "paused"))
print("tokens total", sum(tok_task), "| per task p10/p50/p90", q(tok_task, .1), q(tok_task, .5), q(tok_task, .9),
      "| tasks < 28k", sum(1 for x in tok_task if x < 28000), "| tasks < 60k", sum(1 for x in tok_task if x < 60000))
print("stage-1 runs", len(st1), "| stage-2 runs", len(st2), "| stage-2 tokens p50", q([x["tokens"] for x in st2], .5),
      "| stage-2 improved", sum(1 for x in st2 if x.get("improved")))
print("fair share: computed p10/p50/p90", q(shares, .1), q(shares, .5), q(shares, .9), "| below min chunk",
      sum(1 for s in shares if s < MIN_CHUNK), "of", len(shares))
print("solved (sim) ", solved, "of", solvable, "solvable by assumption | requests", STATS["requests"],
      "| KV max", round(STATS["kv_max"], 3), "| KV holds", S.get("kv_holds"), "hold sec", S.get("kv_hold_sec"),
      "| samples", S.get("kv_samples"), "missing", S.get("kv_missing"))
t0s = sorted(r["t0"] - wall0 for r in b0 if r.get("t0"))
print("stage 1: last branch-0 start at", round(t0s[-1]) if t0s else None, "s of", int(WINDOW_SEC),
      "| 50th start at", round(t0s[len(t0s) // 2]) if t0s else None)
print("events", {k: sum(1 for x in ev if x.get("kind") == k) for k in sorted({x.get("kind") for x in ev})})
b0_res = sum(1 for r in b0 if any(x.get("stage") == 2 for x in r.get("runs", [])))
print("branch 0 resumed in stage 2 at least once (G4-6 nudge deliverable):", b0_res, "of", len(b0))
