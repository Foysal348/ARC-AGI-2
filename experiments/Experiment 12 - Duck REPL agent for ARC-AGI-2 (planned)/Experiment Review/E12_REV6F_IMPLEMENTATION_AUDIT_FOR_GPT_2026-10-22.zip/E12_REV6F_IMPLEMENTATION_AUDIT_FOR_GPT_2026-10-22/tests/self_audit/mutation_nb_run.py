"""rev 6f self-audit, builder-level mutation testing: re-introduce H6-3 / H6-6 / H6-17 bugs into a COPY of the built
EVAL12R6 notebook and check that the harness check guarding each one FAILS (and that the clean copy passes)."""
import json
import os
import subprocess
import sys
from pathlib import Path

NB = Path(r"D:/ARC AGI 2/experiments/Experiment 12 - Duck REPL agent for ARC-AGI-2 (planned)/Experiment Notebooks/"
          r"Q27-XHIGH-E12_DUCK_REPL_SGLANG_EVAL12R6.ipynb")
H = Path(r"D:/ARC AGI 2/_scratch/session_1c6db7aa/e12_harness/harness_e12_rev4_nb.py")
OUT = Path(r"D:/DevCache/Temp/mutnb6f")
OUT.mkdir(parents=True, exist_ok=True)
M = {
    "clean": (None, None, []),
    "H6-3 diagnostic before solving": (
        '''        if P.get("parity"):          # R6-X1 diagnostic profile: no solving (the fallback submission stays)''',
        '''        E12_RUN["cache_diag_pre"] = _e12_cache_diag(budget_sec=60.0)   # MUTATION: churn before solving
        if P.get("parity"):          # R6-X1 diagnostic profile: no solving (the fallback submission stays)''',
        ["rev 6f H6-3"]),
    "H6-6 no window shift": (
        '''            _end = _e12_shifted_end(_end, _shift, HARD_STOP - E12_STOP_BEFORE_HARD_SEC)''',
        '''            pass   # MUTATION: no shift''', ["rev 6f H6-6"]),
    "H6-17 no isolation retry": (
        '''        if E12_RUN["rev6_preflight"].get("isolation_state") == "INCONCLUSIVE":''',
        '''        if False:   # MUTATION: no retry''', ["rev 6f H6-17"]),
}
res = {}
for name, (old, new, guards) in M.items():
    d = json.load(open(NB, encoding="utf-8"))
    if old:
        hits = 0
        for c in d["cells"]:
            if c["cell_type"] != "code":
                continue
            src = "".join(c["source"])
            if old in src:
                hits += src.count(old)
                c["source"] = src.replace(old, new).splitlines(keepends=True)
        if hits != 1:
            res[name] = {"error": f"anchor found {hits} times"}
            continue
    nb = OUT / (name.split()[0].replace("/", "_") + ".ipynb")
    json.dump(d, open(nb, "w", encoding="utf-8"), ensure_ascii=False)
    env = dict(os.environ, TEMP=r"D:/DevCache/Temp", TMP=r"D:/DevCache/Temp", PYTHONIOENCODING="utf-8")
    p = subprocess.run([sys.executable, str(H), str(nb), "r6"], capture_output=True, text=True, timeout=1500, env=env,
                       cwd=str(H.parent))
    out = p.stdout + p.stderr
    (OUT / (nb.stem + ".log")).write_text(out, encoding="utf-8")
    fails = [ln.strip()[5:] for ln in out.splitlines() if ln.strip().startswith("FAIL ")]
    summary = [ln for ln in out.splitlines() if "ok in" in ln][-1:]
    caught = {g: any(f.startswith(g) for f in fails) for g in guards}
    res[name] = {"summary": summary, "caught": caught, "fails": [f[:90] for f in fails]}
for k, v in res.items():
    good = (not v.get("fails") and not v.get("error")) if k == "clean" else (v.get("caught") and all(v["caught"].values()))
    print(("OK     " if good else "PROBLEM ") + k + " | " + json.dumps(v)[:500])
