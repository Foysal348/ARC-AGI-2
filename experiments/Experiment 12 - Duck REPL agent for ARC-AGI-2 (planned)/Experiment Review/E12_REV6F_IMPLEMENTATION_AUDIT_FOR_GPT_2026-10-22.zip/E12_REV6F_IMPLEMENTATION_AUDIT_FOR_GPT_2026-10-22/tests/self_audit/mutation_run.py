"""rev 6f self-audit, mutation testing: re-introduce each fixed bug (one at a time) into a COPY of the adapter and check
that the test meant to guard it FAILS. A mutation that leaves its guard green = a test that does not protect the fix.
Usage: python mutation_run.py [names...]   (default: all)"""
import json
import os
import shutil
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

E = Path(r"D:/ARC AGI 2/experiments/Experiment 12 - Duck REPL agent for ARC-AGI-2 (planned)")
S = Path(r"D:/ARC AGI 2/_scratch/session_1c6db7aa")
ROOT = Path(r"D:/DevCache/Temp/mut6f")
AD = (E / "duck_arc2/arc2_duck.py").read_text(encoding="utf-8")

# name: (old, new, test file, guard-test name prefixes that must FAIL)
M = {
    "G4-1 KV gate removed": ('''        return kv >= kv_admit_limit''', '''        return False''', "smoke_rev6.py", ["G4-1: KV 0.97"]),
    "G4-3/SA-2 guard reverted to rev 6d": (
        '''_GRID_ROW_RE = re.compile(r"(?i)^\\s*[\\[\\(]*\\s*\\d+(?:(?:\\s*,\\s*|\\s+)\\d+){3,}\\s*[\\]\\)]*\\s*,?\\s*$|^\\s*\\d{8,}\\s*$"''',
        '''_GRID_ROW_RE = re.compile(r"^\\s*[\\[\\(]*\\s*\\d+(?:(?:\\s*,\\s*|\\s+)\\d+){3,}\\s*[\\]\\)]*\\s*,?\\s*$|^\\s*\\d{8,}\\s*$"
                          r"|^ZZZNEVER"''', "smoke_rev6.py", ["G4-3: print(i, row)", "G4-3+: print(i, joined"]),
    "H6-1 tool-result nudge removed": ('''                if self._arc2_pending_submit is None and self._arc2_wants_nudge():''',
                                       '''                if False:''', "smoke_rev6.py", ["H6-1: past 24,000"]),
    "H6-2 one-grid predicate removed": ('''                    _R6_AUTOCHECK_RE.match(n) and before_kept.get(n) != src and _r6_single_grid_arg(src)
                    for n, src in (self._kept_functions or {}).items()):''',
                                        '''                    _R6_AUTOCHECK_RE.match(n) and before_kept.get(n) != src
                    for n, src in (self._kept_functions or {}).items()):''', "smoke_rev6.py", ["H6-2: transform(a, b)"]),
    "H6-4 freeze ignored": ('''            if self._frozen:
                return self._final''', '''            if False:
                return self._final''', "smoke_rev6.py", ["H6-4: three stuck workers"]),
    "H6-7 small grids exempt again": ('''        if reasoning_tokens(text) <= limit:
            break''', '''        if reasoning_tokens(text) <= limit or len(g) * len(g[0]) <= 400:
            break''', "smoke_rev6.py", ["H6-7: 10 train + 3 test"]),
    "H6-8 pop-time check removed": ('''                            if (g412_defer_b1([x for (t, _), x in sessions.items() if t == tid], sessions.get((tid, 0)))
                                    and ((tid, 0) in queued or (tid, 0) in active)):''',
                                    '''                            if False:''', "smoke_rev6.py", ["H6-8: the scheduler uses the predicate"]),
    "G4-6 threshold back to 27k": ('''            self._arc2_nudge_tokens = _env_int("E12_R6_NUDGE_TOKENS", 24000)''',
                                   '''            self._arc2_nudge_tokens = _env_int("E12_R6_NUDGE_TOKENS", 27000)''', "smoke_rev6.py",
                                   ["H6-1: past 24,000", "G4-6: nudge once past 24,000"]),
    "T8 per-request deadline clamp removed": ('''                kwargs["request_timeout_seconds"] = clamp''', '''                pass''', "smoke_rev6.py",
                                              ["T8: a request's read timeout"]),
    "G4-12 deferral removed": ('''    return (s0 is not None and s0.status == "paused" and not s0.stalled() and stage2_class(task_sessions) == 0)''',
                               '''    return False''', "smoke_rev6.py", ["G4-12: an improving partial", "H6-8: defer branch 1"]),
    "R6-P3 generalization every time": ('''                    if not self._arc2_generalize_sent:          # R6-P3: once per branch, after the first candidate''',
                                        '''                    if True:          # R6-P3: once per branch, after the first candidate''', "smoke_rev6.py",
                                        ["R6-P3: the generalization note"]),
    "G4-2 branch-1 first cap = 12,288": ('''            first = c["first_b1"] if self.arc2_view != "facts" else c["first"]''',
                                         '''            first = c["first"]''', "smoke_rev6.py", ["G4-2"]),
    "H6-9 src_key removed": ('''                v["src_key"] = self._arc2_closure_key(name)[:16]      # H6-9: program identity = source + dependencies''',
                             '''                pass''', "smoke_rev6.py", ["H6-9: every verdict carries a source key"]),
    "R5-2 cut call executed again": ('''                    calls = msg["tool_calls"] = [{"id": "arc2-cut-placeholder", "type": "function",
                                                  "function": {"name": "python", "arguments": ""}}]''',
                                     '''                    calls = None''', "smoke_rev5.py", ["R5-2"]),
    "G4-1 stale sample treated as fresh": ('''        if kv is None or t is None or time.monotonic() - t > kv_stale_sec:
            return False''', '''        if kv is None or t is None:
            return False''', "smoke_rev6.py", ["G4-1: a stale sample"]),
}

_i = AD.index(chr(10) + "_GRID_ROW_RE = re.compile(") + 1
_j = AD.index(chr(10) + "_GRID_ROW_MAX = ") + 1
_OLD6D = r"^\s*[\[\(]*\s*\d+(?:(?:\s*,\s*|\s+)\d+){3,}\s*[\]\)]*\s*,?\s*$|^\s*\d{8,}\s*$"   # the rev 6d pattern
M["G4-3/SA-2 guard reverted to rev 6d"] = (AD[_i:_j], '_GRID_ROW_RE = re.compile(r"' + _OLD6D + '")' + chr(10),
                                           "smoke_rev6.py", ["G4-3: print(i, row)", "G4-3+: print(i, joined"])


def run_one(name):
    old, new, test, guards = M[name]
    d = ROOT / name.split()[0].replace("/", "_")
    if d.exists():
        shutil.rmtree(d)
    (d / "duck_arc2").mkdir(parents=True)
    (d / "tests" / "runs").mkdir(parents=True)
    n = AD.count(old)
    if n != 1:
        return name, {"error": f"mutation anchor found {n} times"}
    (d / "duck_arc2/arc2_duck.py").write_text(AD.replace(old, new), encoding="utf-8")
    shutil.copytree(E / "duck_arc2/vendor", d / "duck_arc2/vendor")
    for f in ("smoke_adapter.py", "smoke_rev6.py", "smoke_rev5.py"):
        shutil.copy2(S / "e12_smoke" / f, d / "tests" / f)
    env = dict(os.environ, TEMP=r"D:/DevCache/Temp", TMP=r"D:/DevCache/Temp", PYTHONIOENCODING="utf-8")
    try:
        p = subprocess.run([sys.executable, test], cwd=d / "tests", capture_output=True, text=True, timeout=2400, env=env)
        out = p.stdout + p.stderr
    except subprocess.TimeoutExpired as e:
        out = (e.stdout or "") + "\nTIMEOUT"
    fails = [ln[5:] for ln in out.splitlines() if ln.startswith("FAIL ")]
    caught = {g: any(f.startswith(g) for f in fails) for g in guards}
    (ROOT / f"{d.name}.log").write_text(out, encoding="utf-8")
    return name, {"caught": caught, "all_guards_failed": all(caught.values()), "fails": [f[:100] for f in fails],
                  "crashed": "Traceback" in out and not fails}


names = sys.argv[1:] or list(M)
ROOT.mkdir(parents=True, exist_ok=True)
with ThreadPoolExecutor(3) as ex:
    res = dict(ex.map(run_one, names))
for k in names:
    v = res[k]
    ok = v.get("all_guards_failed")
    print(("CAUGHT  " if ok else "MISSED  ") + k + " | " + json.dumps(v)[:600])
print(f"{sum(1 for v in res.values() if v.get('all_guards_failed'))} of {len(res)} mutations caught by their guard tests")
