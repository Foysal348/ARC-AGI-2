# E12 Duck agent, rev 6f: implementation audit of the H6 fixes, before the next GPU run (2026-10-22)

**Project:** Kaggle ARC Prize 2026, ARC-AGI-2.
- **Model and stack:** Qwen3.8-27B, RedHat INT4 (W4A16 g128) + BF16 DFlash2 drafter, SGLang 0.5.21, TP 4 on 4×L4.
- **Agent:** Duck REPL (vendored, unchanged) + our ARC-2 adapter `duck_arc2/arc2_duck.py`.
- **Hidden run:** 240 tasks in one 12 h Kaggle session.

**Where this bundle stands:**
- **Previous round:** you audited rev 6e (`docs/previous_bundle_README_rev6e.md`) in three reports. We validated every claim, by **reproducing** it where possible (`tests/verify_h6.py`, `tests/self_audit/h6_1_g4b_nudge_delivery.py`). That gave items H6-1..H6-19 (`docs/E12 next fix list (running, 2026-10-20).md`, sections "GPT audits of the rev 6e bundle" to "Rev 6f").
- **The user's decision:** take the recommended set.
- **This bundle:** that code. **Nothing here has run on a GPU yet.**

## 1. What we ask you to do

Recompute every number from the files here; do not trust our summaries.

1. **Audit every H6 item in section 3:**
   - implemented as specified / partly / wrong / missing;
   - for a bug: file and line, a concrete trigger, and the fix;
   - whether the test proves the behaviour or only that the code runs.
2. **Regressions:** check against rev 6e and earlier: harvest and host verifier, pass@2, the deadline clamp, the KV ≥ 95 % admission rule, the stage-1 queue, sandbox security, context preservation. Especially:
   - the scheduler changes (`g412_defer_b1` at pop time, `BranchSession.freeze`);
   - the new tool-result nudge (H6-1).
3. **Test fixtures:** any fixture that assumes behaviour the real SGLang server or the real model does not have.
4. **GO / NO-GO per notebook**, with the blocking items.
5. **Answer the questions in section 6.**

**Output format:**
- one table for item 1 (`ID | verdict | evidence (file:line) | bug + trigger | fix`);
- then the missed problems, ranked by impact on the hidden-run score;
- then the GO / NO-GO;
- then the answers.
- Mark every statement **measured** (file / field / line) or **inferred**.

**Running the tests:**
- `pip install -r tests/requirements.txt` (`tokenizers`, `transformers`).
- **Without them:** the tokenizer-dependent checks are now **SKIPPED**, visibly, and the rest runs. Such a run ends with `INCOMPLETE … skipped`, exit 2, never ALL OK (H6-19).
- Last round none of you could run the full suites. Please say which suites you ran and whether they were complete.

**Constraints (the user's rules):**
- **Keep the setup:** Qwen3.8-27B on this stack; no fine-tuning, no API models, no other model.
- **Full coverage is a hard goal:** every one of the 240 hidden tasks gets a real attempt in 12 h. Hidden ≈ public eval in difficulty.
- **Token budget:** no cut below the current settings without the user's approval (floor 60,000 thinking tokens for single-pass pipelines).
  - Approved for rev 6: request caps 12,288 / 24,576 / 32,768, branch-1 first cap 24,576, the 28k soft first exposure, the 12,288 minimum stage-2 chunk, gate 4b, and (new) the provisional nudge at 24,000.
  - Say clearly if a proposal needs a new approval.
- **Ground truth:** never used at runtime.
- **Bundling:** one evidence-based release per GPU run.
- **No impossible claims:** never say LB 60+ is impossible or needs fine-tuning (teams reach 70–88 with Qwen3.8 + an optimized Duck and full coverage).
- **The user's KV rule stays:** "no new task or branch while KV usage ≥ 95 %". The idle override is kept by the user's decision (H6-12).

## 2. Notebooks

| Notebook | sha256 | Purpose | Status |
|---|---|---|---|
| `notebooks/Q27-XHIGH-E12_DUCK_REPL_SGLANG_EVAL12R6G4B_REBUILD.ipynb` | `913aef97556434e7f780c600c9741cc6b4fb3a94ac97f0b49ebefcb75e4c037e` | **Gate 4b:** the 12 EVAL12R5 tasks (19 inputs) at the hidden run's time per task (12 × (42,720 − solve start) / 240 ≈ 2,063 s). The first GPU screening run | built, not run |
| `notebooks/Q27-XHIGH-E12_DUCK_REPL_SGLANG_EVAL12R6.ipynb` | `ac7a46a81d409e89c62d22761ad10d15cad0eb8735bca3ec1e1a0de4710472bf` | The same 12 tasks with a 150-min solve window | built, not run |
| `notebooks/Q27-XHIGH-E12_DUCK_REPL_SGLANG_PARITYR6.ipynb` | `7d35d72b8b063be5490a51de5e30924acf6e3a38d0461dd81df870908c1025c7` | Serving diagnostic (DFlash vs target-only); no solving. The old PARITY fixes 6–8 are still deferred (user) | built, optional |
| `notebooks/reference_rev6d_kaggle_run/…EVAL12R6G4B.ipynb` | `1bdadd82…` | The rev 6d notebook that ran on Kaggle (results in `runs/rev6d_EVAL12R6G4B/`), reference only | ran 2026-10-21: 2/19 |

**Packaging (measured):**
- All three new notebooks embed `duck_arc2/arc2_duck.py` byte-identical (23-file package; vendor unchanged).
- Rev 6 behaviour is behind `E12_ARC2_REV6=1` + the `E12_R6_*` knobs (`source/build_e12_duck.py`, dict `E12_R6`).
- **Dual-mode:** the Kaggle rerun solves all hidden tasks and writes `submission.json`; a commit run solves the eval subset and scores it.

## 3. What changed since rev 6e (please audit each row)

**Diffs:**
- `source/diffs/arc2_duck.rev6e_selfaudit_to_rev6f.diff`, `source/diffs/build_e12_duck.rev6e_selfaudit_to_rev6f.diff` (this round);
- `*.rev6d_to_final.diff` (everything since the G4B run);
- full old files in `source/history/`.

| ID | Your finding (validated how) | What we built | Test |
|---|---|---|---|
| **H6-1** | The 27k nudge rode a new opener, so in G4B **0 of 12** branch-0 runs had a new turn at ≥ 27k before the 28k pause (**measured** on the transcripts). At the realistic 277 tok/s, 89 of 240 branch 0 would never be resumed (sim), so they would never get it | The nudge goes into the **next tool result** (`harness_note`, verbatim your text) once ≥ `E12_R6_NUDGE_TOKENS` **24,000** generated tokens with no one-grid solution function and no check; else the next opener; once. **G4B replay of this rule:** 7 of 12 inside stage 1, of which 4 come 3.1–9.9k tokens before the pause (247ef758, 62593bfd, 65b59efc, b5ca7ac4) and 3 at the pause request. 3 had a transform first. 2 (136b0064, f931b4a8) made no tool call between 24k and the pause, one long think, so nothing mid-turn reaches them | smoke: no note at 23k; note at 24.5k (via tool); once; audit 1's 12,288 → 36,864 timeline carries it; a one-grid transform suppresses it; opener path at 24.5k |
| **H6-2** | `transform(a, b)` / a helper `solve_row(r, i)` suppressed the nudge (**reproduced**) | `first_transform_tokens` and the nudge use `_r6_single_grid_arg` (the auto-check predicate) | smoke: neither counts, so the nudge still goes out; an unchanged redefinition keeps the timestamp |
| **H6-3** | The cache diagnostic churned the cache **before** solving; the hidden rerun never runs it | The diagnostic runs **after solving** (commit mode; its time comes from what is left before the output margin, never from the solve window; skipped under 90 s; `cache_diag.ran`) | harness: every diagnostic request comes after the last solver request; the rerun has none |
| **H6-4** | A straggler rewrote `branch_result.json` after the scheduler returned (**reproduced**: 399 → 544 bytes, 1,000 → 2,000 tokens) | `BranchSession`: I/O lock, atomic write (temp + replace), `freeze()` after the final snapshot; later writes are no-ops for both record and file | smoke: 3 stuck workers; 5 s after the return every file hash is unchanged, valid JSON, and records and callback count are unchanged |
| **H6-5** | `smoke_rev5.py` / `smoke_adapter.py` exited 0 on a FAIL | a shared `finish()`: FAIL → 1, skipped → 2, ALL OK → 0 | runs below |
| **H6-6** | SA-1 shifted only gate 4b; EVAL12R6's 150-min window lost the setup time | Every commit window (solve window or gate 4b) starts after the preflight: `_e12_shifted_end`, bounded by the hard stop (`e12_run.window_shift`). The rerun keeps its absolute end | harness r6 / g4b; `window_check.py` |
| **H6-7** | The indexed-view bound was not enforced when every grid is ≤ 400 cells (**reproduced**: 10 + 3 20×20 grids = 21,963 Qwen tokens, nothing hidden; your fallback numbers 12,073 / 13,136 matched exactly). The 120 eval tasks: max 11,719, none over | Grids are hidden largest first until within the bound; small grids are no longer exempt | smoke: ≤ 12,000 and every grid listed; a small task is unchanged; eval max unchanged |
| **H6-8** | A queued branch 1 could start after its branch 0 had improved. **Not reproduced with a correct measurement:** our first "reproduction" compared request-log order (a branch 1 popped before branch 0 improved logs its first request 3-73 ms later); at the real pop time, 0 cases in 7 + 20 scheduler runs on rev 6e and on rev 6f | Kept as a defensive change: `g412_defer_b1()`, one predicate used at queue time and again when a queued branch-1 start is popped, only while branch 0 is queued or running (so branch 1 is re-queued by branch 0's next run and never starved); `b1_deferred_at_pop` (0 in every run so far) | smoke: the predicate's cases; the scheduler uses it at both places; the G4-12 and 240-task sims pass |
| **H6-9 / H6-11** | Program counts mixed names, sources and predictions; "same transform" = same name | Every verdict carries `src_key` (source + transitive dependencies). Report: `verified_programs_by_source`, `verified_programs_per_task` (by source), `distinct_predictions_per_task`, `progress_same_name_new_source`; the best progress records its `src` | smoke; harness |
| **H6-10** | The message-level prefix is not the token prefix | Per request: `payload_sha`, `chars`, `prefix_chars` (serialized characters shared with the previous request), `tools_same`, `template_same`. Report: zero-hit later requests with a full character prefix / with tools or template changed; `cached_not_reported_requests`. **Still a proxy** (the server renders the template) | smoke; harness |
| **H6-12** | The idle override is an exception to the KV rule | **Kept** (user); `kv_idle_overrides` printed in the coverage line | harness |
| H6-13 | `arc_overview` extras could drop a line repeated under another header | **Not reproduced:** 0 lost lines on the 120 eval tasks, so no change | `verify_h6.py` |
| **H6-14** | The allocation decision needs a yield metric for all branches | Each run records `new_verified`; report `verified_yield` per 100k generated tokens: all / b0 / b1 / stage 1 / stage 2 | smoke; harness |
| H6-15 | Narrow labelled rows | Not built (optional) | — |
| **H6-16** | The SA-1 test was dominated by the harness's 300 s cap | `_e12_g4b_window` / `_e12_shifted_end` are functions; `tests/window_check.py` reads them from the built notebook and checks the real values (42,720 / 1,463 / 12 → 171.9 s and 2,063 s; a 35 s or 240 s setup leaves the full window; never past the hard stop; EVAL12R6 9,000 s) | 7/7 |
| **H6-17** | INCONCLUSIVE isolation dropped the run to 6 workers | One retry of the preflight on INCONCLUSIVE (`retry_of` recorded); a FAIL never retries | code; harness (PASS path only) |
| **H6-18** | Nudge efficacy could not be judged | Per branch `first_transform_after_nudge`, `first_check_after_nudge`. Report `nudge`: branches, via, tokens p50, transform / check after and tokens to them, accepted | smoke; harness |
| **H6-19** | No reviewer could run the suites (a module-level `tokenizers` import stopped `smoke_rev6.py`) | `expect_tok` → explicit SKIP; `tests/requirements.txt`. **Simulated without the package:** smoke_rev6 161 + 1 skipped (exit 2); smoke_rev5 52 + 4 skipped (exit 2); smoke_adapter 41 (exit 0) | `recorded_outputs/*_without_tokenizers.txt` |

**Unchanged:**
- the KV ≥ 95 % admission rule with fixed 12 workers;
- harvest and the host verifier; pass@2;
- the stage-1 queue and the 28k first exposure;
- the request caps and the 12,288 minimum chunk;
- the deadline clamps and context preservation;
- the vendored Duck.

## 4. Tests (2026-10-22, final files; Windows, Python 3.14, tokenizers 0.23.2, transformers 5.20.2)

```
cd tests
pip install -r requirements.txt
python smoke_adapter.py      # 41/41
python smoke_rev5.py         # 56/56
python smoke_rev6.py         # 163/163 (rev 6e: 143; + H6 tests + R6-P3)
python regex_check.py        # ALL OK
python facts_size.py         # 120 eval tasks: bounded facts p50 699 / p90 779 / max 798; deterministic
python kv_gate_replay.py     # 7/7 recorded server logs: holds only in E12 EVAL30 rev 1
python window_check.py       # 7/7 (H6-16)
python verify_h6.py          # reproductions of your rev 6e findings: on rev 6f every line reads NOT REPRODUCED;
                             # on rev 6e H6-2 / H6-4 / H6-7 read REPRODUCED (recorded_outputs/verify_h6_rev6e_out.txt)
python replay_rev6.py ../runs/rev5_EVAL6R5_xhigh/duck ../data/eval_challenges_12.json ../data/eval_solutions_12.json out.jsonl
python harness_e12_rev4_nb.py ../notebooks/Q27-XHIGH-E12_DUCK_REPL_SGLANG_EVAL12R6G4B_REBUILD.ipynb g4b   # 58/58
python harness_e12_rev4_nb.py ../notebooks/Q27-XHIGH-E12_DUCK_REPL_SGLANG_EVAL12R6.ipynb r6               # 57/57 (incl. H6-12 printed line, H6-17 retry)
python harness_e12_rev4_nb.py ../notebooks/Q27-XHIGH-E12_DUCK_REPL_SGLANG_EVAL12R6.ipynb rerun            # 23/23
python harness_e12_rev4_nb.py ../notebooks/Q27-XHIGH-E12_DUCK_REPL_SGLANG_EVAL12R6.ipynb launchfail       # 6/6
python harness_e12_rev4_nb.py ../notebooks/Q27-XHIGH-E12_DUCK_REPL_SGLANG_PARITYR6.ipynb parity           # 19/19
cd self_audit
python h6_1_g4b_nudge_delivery.py   # H6-1 evidence on the G4B transcripts
python g4_11_bound_check.py         # H6-7 on the 120 eval tasks
python sim240.py 12288 400 1        # 240-task scheduler sim (SIM_RATE=277 for the G4B end-to-end rate)
```

- **Replays** (`recorded_outputs/replay_rev6g_*`): rev 4 7/8, rev 5 xhigh 5/8, rev 5 low 10/19, identical per task to rev 6e.
- **Harness note:** my first harness check for H6-9 / H6-10 read fields from the report's branch rows, which do not hold them, and gave 2 false FAILs. It now reads the raw `branch_result.json`. The fake server's `/metrics` follows real values (queue 1, mamba 0.62) and it omits `prompt_tokens_details` at 0 cached, like SGLang 0.5.21.

## 4b. Our self-audit of rev 6f (docs: fix list "Rev 6f self-audit")

- **Fix IDs vs tests:** every fix-list ID was checked against a test. Three real gaps (R6-P3, H6-12, H6-17) got tests.
- **Static analysis:** pyflakes on the adapter, builder, harness and all built notebook code: no undefined names. nbformat validates all three notebooks.
- **Mutation testing:** 18 mutations put the old bugs back. **All 18 were caught** by their guard tests: 15 in the adapter (`tests/self_audit/mutation_run.py`) and 3 in the built notebook (`mutation_nb_run.py`).
  - Two guards were too weak and were fixed first:
    - R6-P3: its duplicate candidate never got the note anyway;
    - H6-6: an instant fake preflight made the shift about 0.
- **Regressions:** every earlier bug has a passing regression test (table in the fix list).
- **Timing flake:** one wall-clock bound flaked once under load (3.22 s vs 3.0 s) and was widened to 4 s; a deadlock would take ≥ 60 s.

## 5. Capacity (unchanged since rev 6e, recorded)

**240-task sim** (`recorded_outputs/sim240_*`):
- **Coverage:** 240/240 tasks exposed at both 371 and 277 tok/s.
- **Stage-1 end:** about 48 % of the window at 371 tok/s, 64 % at 277.
- **Tokens per task:** about 63k at 371 tok/s, 47.6k at 277.
- **Fair share is inert at 240 tasks:** the minimum chunk is the real allocation rule.

The G4B run will measure the real rate with fixed 12 workers (rev 6d's 277 tok/s included the 12 → 6 bug).

## 6. Questions

1. **H6-1:** is the tool-result nudge safe?
   - Can a note inside a tool result disturb an in-progress hypothesis? 1 of the 2 G4B solved branches (b5ca7ac4_b0) would get it about 1.9k tokens before its own transform.
   - The 2 branches that think through 24k → pause without any tool call: what, within the user's rules (no new token cut), would reach them?
2. **H6-8:** we could not reproduce your scenario with a correct (pop-time) measurement. Can you give a concrete trigger? Does deferring at pop create any starvation path (p90 cutoff off by default; deadline)?
3. **H6-4:** is freezing after the final snapshot enough, or can a straggler still change anything the report or submission reads?
4. **The G4B screening run:** which report fields should decide the next allocation rule (12,288 vs 24,576) and whether the nudge helped (`verified_yield`, `nudge`, `runs[].improved` / `new_verified`)?
5. **Anything else wrong** in code, tests or numbers.

## 7. File map

| Path | What |
|---|---|
| `duck_arc2/arc2_duck.py` | **The adapter, rev 6f** (embedded unchanged in all three notebooks) |
| `duck_arc2/vendor/` | Vendored Duck, unchanged since rev 4 |
| `source/build_e12_duck.py` | Notebook builder (CELL 3 knobs; CELL 6 preflight, scheduler wiring, post-solve diagnostic; CELL 7 report) |
| `source/push_e12_duck.py` | Push script (not run) |
| `source/diffs/`, `source/history/` | rev 6d → final, rev 6e → self-audit → rev 6f diffs and full older files |
| `notebooks/` | The 3 rev 6f notebooks + the rev 6d reference |
| `runs/` | Rev 6d G4B outputs (report, transcripts with full thinking, server log), rev 5 xhigh / low, rev 4 EVAL6, 3 server logs of 12-stream runs |
| `data/` | The 12 tasks and their solutions (analysis only) |
| `analysis/` | G4B analysis scripts and outputs |
| `docs/` | Running fix list (every audit, validation and decision; "Rev 6f" at the end), G4B / rev 5 / weakness analyses, verbatim GPT prompt drafts, the previous two bundle READMEs |
| `tests/` | Unit checks, `verify_h6.py`, `window_check.py`, KV-gate replay, notebook harness, fake SGLang server, fixtures, `requirements.txt`, `self_audit/`, `recorded_outputs/` |
