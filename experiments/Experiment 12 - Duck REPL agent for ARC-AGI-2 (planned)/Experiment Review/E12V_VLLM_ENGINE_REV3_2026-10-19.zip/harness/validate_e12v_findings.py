"""Validate the E12-V GPT audit claims without changing project code (our scripted test code only).
    python validate_e12v_findings.py think_markup     # B2: tool-call XML inside reasoning, no structured tool_calls
    python validate_e12v_findings.py smoke_gate       # B1: the CELL 5 smoke predicate on a cold-cache vLLM 0.19 reply
"""
import json
import os
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
E12 = Path(r"D:/ARC AGI 2/experiments/Experiment 12 - Duck REPL agent for ARC-AGI-2 (planned)/duck_arc2")
sys.path[:0] = [str(E12), str(E12 / "vendor"), str(HERE.parent / "e12_harness")]
sys.stdout.reconfigure(encoding="utf-8")
WHAT = sys.argv[1]

if WHAT == "smoke_gate":
    B = Path(r"D:/ARC AGI 2/experiments/Experiment 12 - Duck REPL agent for ARC-AGI-2 (planned)/Experiment Notebooks/Build/build_e12_duck.py").read_text(encoding="utf-8")
    line = next(l for l in B.splitlines() if '"ok": bool(gen) and isinstance(usage.get("prompt_tokens_details"), dict)' in l)
    # vLLM 0.19 chat_completion/serving.py:1601-1603: details only when num_cached_tokens is truthy -> cold reply:
    cold = {"choices": [{"message": {"content": "2 + 2 = 4."}}], "usage": {"prompt_tokens": 20, "completion_tokens": 8, "total_tokens": 28}}
    gen = cold["choices"][0]["message"]["content"].strip(); usage = cold["usage"]
    ok = bool(gen) and isinstance(usage.get("prompt_tokens_details"), dict)
    print(f"SMOKE_GATE: current predicate on a cold-cache vLLM 0.19 reply -> ok={ok} (False = engine rejected) | {line.strip()[:110]}")

if WHAT == "model_name":   # vLLM SMOKE1 run 1: every Duck request 404 "The model `pending` does not exist"
    if os.name == "nt":
        _real = subprocess.Popen
        _bdir = HERE / "_bootstrap"; _bdir.mkdir(exist_ok=True)

        class _Shim2(_real):
            def __init__(self, args, *a, **kw):
                if isinstance(args, list) and len(args) >= 5 and args[1:4] == ["-I", "-S", "-c"]:
                    f = _bdir / "sandbox_bootstrap.py"
                    if not f.exists() or f.read_text(encoding="utf-8") != args[4]:
                        f.write_text(args[4], encoding="utf-8")
                    args = [args[0], "-I", "-S", str(f)] + args[5:]
                super().__init__(args, *a, **kw)
        subprocess.Popen = _Shim2
    import arc2_duck as A
    from fake_openai import FakeOpenAI
    # = notebook CELL 3: duck_env(..., "pending", ...) puts the placeholder into LOCAL_ANALYZER_MODEL_ID
    env = A.duck_env("http://127.0.0.1:9/v1", "pending", 12)
    env["ARC3_REASONING_HISTORY_KEY"] = "reasoning"
    os.environ.update(env)
    TA, DP, _, wrs = A._import_duck()
    Agent = A.make_agent_class()
    flip = lambda g: [list(reversed(r)) for r in g]
    task = {"train": [{"input": g, "output": flip(g)} for g in ([[1, 2, 3], [4, 5, 6]], [[7, 0], [0, 8], [9, 9]])],
            "test": [{"input": [[3, 1], [2, 2]]}]}

    class StrictFake(FakeOpenAI):
        """Like vLLM: 404 unless the request names the served model."""
        served = None

        def _reply(self, body):
            if body.get("model") != self.served:
                return 404, {"error": {"message": f"The model `{body.get('model')}` does not exist.", "code": 404}}, None, -1
            return super()._reply(body)

    for served in ("qwen", "Qwen/Qwen3.8-27B-FP8"):
        ag = Agent(task=task, task_id="flip", branch=0, model=served, base_url="http://127.0.0.1:9/v1", provider="vllm")
        print(f"MODEL_NAME resolve: served={served!r} -> Duck sends model={ag._model.model_id!r}")
        code_def = "def transform(g):\n    return [list(reversed(r)) for r in g]\ncheck(transform)"
        fake = StrictFake(lambda t, r: [dict(kind="tool", code=code_def, ct=300), dict(kind="tool", code="submit(transform)", ct=300)],
                          single_conv=True)
        fake.served = served
        d = Path(tempfile.mkdtemp(dir=HERE))
        rec = A.run_branch(Agent, task_id="flip", task=task, branch=0, queue_position=0, out_dir=d,
                           deadline=time.monotonic() + 8, base_url=fake.base_url, model_id=served, save_request_logs=False,
                           backoff=0.2)
        st = sorted({rq["status"] for rq in fake.requests})
        print(f"MODEL_NAME e2e: served={served!r}: accepted={rec['accepted']} statuses={st} "
              f"models_sent={sorted({rq['body'].get('model') for rq in fake.requests})} note={rec.get('note')!r}")
        fake.close()

if WHAT == "think_markup":
    if os.name == "nt":
        _real = subprocess.Popen
        _bdir = HERE / "_bootstrap"; _bdir.mkdir(exist_ok=True)

        class _Shim(_real):
            def __init__(self, args, *a, **kw):
                if isinstance(args, list) and len(args) >= 5 and args[1:4] == ["-I", "-S", "-c"]:
                    f = _bdir / "sandbox_bootstrap.py"
                    if not f.exists() or f.read_text(encoding="utf-8") != args[4]:
                        f.write_text(args[4], encoding="utf-8")
                    args = [args[0], "-I", "-S", str(f)] + args[5:]
                super().__init__(args, *a, **kw)
        subprocess.Popen = _Shim
    import arc2_duck as A
    from fake_openai import FakeOpenAI
    env = A.duck_env("http://127.0.0.1:9/v1", "qwen", 12)
    env["ARC3_REASONING_HISTORY_KEY"] = "reasoning"          # E12-V setting
    os.environ.update(env)
    TA, DP, _, wrs = A._import_duck()

    class ThinkMarkupFake(FakeOpenAI):
        """vLLM 0.19 behaviour of issue 39056: the XML tool call sits inside <think>, so the reasoning parser puts it in
        `reasoning` and the tool parser (content only) returns no tool_calls."""
        def _reply(self, body):
            status, out, conv, i = super()._reply(body)
            if status == 200 and "tool_calls" in out["choices"][0]["message"]:
                m = out["choices"][0]["message"]
                code = json.loads(m["tool_calls"][0]["function"]["arguments"])["code"]
                markup = ("<tool_call>\n<function=python>\n<parameter=code>\n" + code + "\n</parameter>\n</function>\n</tool_call>")
                rc = m.pop("reasoning_content", "")
                m.pop("tool_calls")
                m["reasoning"] = rc + "\nI will call the tool now.\n" + markup + "\n" + markup   # duplicated on purpose
                m["content"] = None
                out["choices"][0]["finish_reason"] = "stop"
            return status, out, conv, i

    flip = lambda g: [list(reversed(r)) for r in g]
    task = {"train": [{"input": g, "output": flip(g)} for g in ([[1, 2, 3], [4, 5, 6]], [[7, 0], [0, 8], [9, 9]])],
            "test": [{"input": [[3, 1], [2, 2]]}]}
    code_def = "print('RUN_MARKER')\ndef transform(g):\n    return [list(reversed(r)) for r in g]\ncheck(transform)"
    fake = ThinkMarkupFake(lambda t, r: [dict(kind="tool", code=code_def, ct=300), dict(kind="tool", code="submit(transform)", ct=300)],
                           single_conv=True)
    Agent = A.make_agent_class()
    d = Path(tempfile.mkdtemp(dir=HERE))
    rec = A.run_branch(Agent, task_id="flip", task=task, branch=0, queue_position=0, out_dir=d, deadline=time.monotonic() + 60,
                       base_url=fake.base_url, model_id="qwen", save_request_logs=False, backoff=0.2)
    tools = [m for rq in fake.requests for m in rq["body"]["messages"] if m.get("role") == "tool"]
    runs = sum(str(m.get("content")).count("RUN_MARKER") for m in tools[:1])
    hist = [m for rq in fake.requests for m in rq["body"]["messages"] if m.get("role") == "assistant"]
    leaked = any("<tool_call>" in str(m.get("reasoning") or "") + str(m.get("content") or "") for m in hist)
    print(f"THINK_MARKUP: accepted={rec['accepted']} | requests={len(fake.requests)} | tool results={len(tools)} | "
          f"marker printed {runs}x in the first tool result (duplicated markup -> must run once) | "
          f"raw markup left in replayed history={leaked}")
    fake.close()
