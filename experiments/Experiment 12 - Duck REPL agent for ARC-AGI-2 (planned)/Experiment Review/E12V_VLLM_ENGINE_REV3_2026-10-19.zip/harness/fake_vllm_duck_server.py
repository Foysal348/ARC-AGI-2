"""Fake vLLM 0.19 OpenAI server for the E12-V notebook harness (CPU, no model). Launched by the REAL E12-V engine cell
with the REAL flags; refuses to start without Duck's vLLM launcher flags + the S1-60K engine flags. Serves /v1/models,
/health, /metrics (vllm: names), /v1/chat/completions (non-stream, OpenAI tool calls, reply reasoning in `reasoning` as
vLLM 0.19 does, usage with prompt_tokens_details). Prints vLLM-format KV and engine-stats log lines.
Scripted replies only (our code): role 0 submits a lookup-table transform built from the known solutions, role 1 submits
identity then inspects. Records which key carried prior reasoning in every request (vLLM reads only `reasoning`).
FAKE_SCEN: launchfail | thinkmarkup (the tool call XML only inside `reasoning`, no tool_calls: vLLM issue 39056) |
modelsfail (/v1/models answers once, then 503). Usage follows vLLM 0.19: prompt_tokens_details only when cached > 0
(chat_completion/serving.py:1601-1603). The KV / concurrency log values are SIMULATED (parser test only), taken from the
real formula: 337,600 tokens and ~1.035 M effective (12.63x at 81,920 in Q27-AGENT run 4) -> 7.66x at 135,168."""
import json
import os
import re
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "fixtures"))
import e12_fixtures as B  # noqa: E402

argv = sys.argv[1:]
SCEN = os.environ.get("FAKE_SCEN", "")
PORT = int(argv[argv.index("--port") + 1]) if "--port" in argv else 1234
print("(APIServer pid=1) INFO fake vllm args:", " ".join(argv), flush=True)
REQUIRED = [["--enable-auto-tool-choice"], ["--tool-call-parser", "qwen3_coder"], ["--reasoning-parser", "qwen3"],
            ["--generation-config", "vllm"], ["--enable-prefix-caching"],
            ["--default-chat-template-kwargs", json.dumps({"preserve_thinking": True})],
            ["--tensor-parallel-size", "4"], ["--kv-cache-dtype", "fp8_e4m3"],
            ["--speculative-config", json.dumps({"method": "mtp", "num_speculative_tokens": 3})],
            ["--max-num-batched-tokens", "4096"], ["--max-num-seqs", "16"], ["--gpu-memory-utilization", "0.9"],
            ["--language-model-only"], ["--disable-custom-all-reduce"], ["--enable-prompt-tokens-details"],
            ["--max-model-len", "135168"], ["--attention-backend", "FLASHINFER"], ["--served-model-name"]]
# like vLLM, any served name is accepted at launch; every request must then name it (404 otherwise, see do_POST)
for req in REQUIRED:
    i = argv.index(req[0]) if req[0] in argv else -1
    if i < 0 or (len(req) == 2 and argv[i + 1] != req[1]):
        print(f"ValueError: E12-V harness: missing / wrong vLLM flag {req}", flush=True)
        sys.exit(1)
if os.environ.get("VLLM_MEMORY_PROFILER_ESTIMATE_CUDAGRAPHS") != "1":
    print("ValueError: E12-V harness: VLLM_MEMORY_PROFILER_ESTIMATE_CUDAGRAPHS not set", flush=True)
    sys.exit(1)
if SCEN == "launchfail":
    print("ValueError: simulated permanent configuration error", flush=True)
    sys.exit(1)
print("(EngineCore pid=2) INFO [kv_cache_utils.py] GPU KV cache size: 337,600 tokens", flush=True)
print("(EngineCore pid=2) INFO [kv_cache_utils.py] Maximum concurrency for 135,168 tokens per request: 7.66x", flush=True)

CH, SOL, _, _ = B.load()
LOCK = threading.Lock()
LOG = {"chat": [], "history_keys": []}
CONV_STEP, CONV_META, TASK_ROLES, NEW_CONVS = {}, {}, {}, []
INFLIGHT = [0, 0]
SERVED = argv[argv.index("--served-model-name") + 1]   # like vLLM: requests must name it
MODELS_CALLS = [0]
T_READY = time.time() + 0.5
CONV_RE = re.compile(r"CONV=(\w+)")


def rows(g):
    return "\n".join(" ".join(str(v) for v in r) for r in g)


def task_of(system_text):
    head = system_text.split("Training pair 1 input:\n", 1)[-1].split("\nTraining pair 1 output:", 1)[0]
    for tid, t in CH.items():
        if rows(t["train"][0]["input"]) == head:
            return tid
    return None


def lookup_code(tid):
    t = CH[tid]
    table = {json.dumps(p["input"]): p["output"] for p in t["train"]}
    for qi, q in enumerate(t["test"]):
        table[json.dumps(q["input"])] = SOL[tid][qi]
    return ("def transform(g):\n    import json\n    table = " + json.dumps(table) + "\n"
            "    return table.get(json.dumps(g), g)\ncheck(transform)")


INSPECT = "print(len(train), len(test_inputs), [(len(p['input']), len(p['input'][0])) for p in train])"
IDENT = "def transform(g):\n    return [list(r) for r in g]\ncheck(transform)\nsubmit(transform)"


def program(tid, role):
    return [INSPECT, lookup_code(tid), "submit(transform)"] if role == 0 else [IDENT, INSPECT]


def chat_reply(body):
    msgs = body.get("messages") or []
    if not body.get("tools"):   # the engine cell's smoke (Duck's run_vllm_api_smoke_test)
        return {"id": "chatcmpl-smoke", "object": "chat.completion", "model": body.get("model"),
                "choices": [{"index": 0, "message": {"role": "assistant", "content": "2 + 2 = 4."}, "finish_reason": "stop"}],
                "usage": {"prompt_tokens": 20, "completion_tokens": 8, "total_tokens": 28}}   # cold: no details (vLLM 0.19)
    keys = sorted({k for m in msgs if m.get("role") == "assistant" for k in ("reasoning", "reasoning_content") if m.get(k)})
    tid = task_of(str(msgs[0].get("content", ""))) if msgs else None
    conv = None
    for m in msgs:
        if m.get("role") == "assistant":
            f = CONV_RE.search(str(m.get("reasoning") or ""))       # vLLM 0.19 reads only `reasoning`
            if f:
                conv = f.group(1)
    with LOCK:
        LOG["history_keys"].append(keys)
        if conv is None:
            role = TASK_ROLES.get(tid, 0)
            TASK_ROLES[tid] = role + 1
            conv = f"{tid}r{role}"
            CONV_META[conv] = (tid, role)
            CONV_STEP[conv] = 0
            NEW_CONVS.append([tid, role, time.time()])
        tid, role = CONV_META[conv]
        i = CONV_STEP[conv]
        CONV_STEP[conv] = i + 1
    steps = program(tid, role)
    code = steps[min(i, len(steps) - 1)]
    prompt = max(1, int(len(json.dumps({"messages": msgs, "tools": body.get("tools")})) / 3.2))
    msg = {"role": "assistant", "content": None, "reasoning": f"CONV={conv} THINK step {i} for {tid} role {role}.",
           "tool_calls": [{"id": f"chatcmpl-tool-{conv}-{i}", "type": "function",
                           "function": {"name": "python", "arguments": json.dumps({"code": code})}}]}
    finish = "tool_calls"
    if SCEN == "thinkmarkup":   # vLLM 0.19 + Qwen: XML emitted inside <think> -> in `reasoning`, tool parser sees no call
        markup = "<tool_call>\n<function=python>\n<parameter=code>\n" + code + "\n</parameter>\n</function>\n</tool_call>"
        msg["reasoning"] += "\nCalling the tool.\n" + markup
        msg.pop("tool_calls")
        finish = "stop"
    with LOCK:
        LOG.setdefault("markup_replies", 0)
        LOG["markup_replies"] += int(SCEN == "thinkmarkup")
    cached = int(prompt * 0.9) if i else 0
    usage = {"prompt_tokens": prompt, "completion_tokens": 400, "total_tokens": prompt + 400}
    if cached:                  # vLLM 0.19: details only when num_cached_tokens is truthy
        usage["prompt_tokens_details"] = {"cached_tokens": cached}
    return {"id": f"chatcmpl-{conv}-{i}", "object": "chat.completion", "model": body.get("model"),
            "choices": [{"index": 0, "message": msg, "finish_reason": finish}], "usage": usage}


class H(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):
        pass

    def _send(self, body, code=200, ctype="application/json"):
        b = body.encode() if isinstance(body, str) else body
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(b)))
        self.send_header("Connection", "close")
        self.end_headers()
        self.close_connection = True
        self.wfile.write(b)

    def do_GET(self):
        if self.path == "/health":
            return self._send("", 200 if time.time() >= T_READY else 503)
        if self.path == "/v1/models":
            if time.time() < T_READY:
                return self._send("{}", 503)
            with LOCK:
                MODELS_CALLS[0] += 1
                n_calls = MODELS_CALLS[0]
            if SCEN == "modelsfail" and n_calls > 1:   # the engine cell saw it; CELL 6's discovery then fails
                return self._send("{}", 503)
            return self._send(json.dumps({"object": "list", "data": [{"id": SERVED, "object": "model"}]}))
        if self.path == "/metrics":
            with LOCK:
                n = INFLIGHT[0]
            lines = [f'vllm:num_requests_running{{model_name="qwen"}} {n}', 'vllm:num_requests_waiting{model_name="qwen"} 0',
                     'vllm:kv_cache_usage_perc{model_name="qwen"} 0.12', 'vllm:prefix_cache_hits_total{model_name="qwen"} 90.0',
                     'vllm:prefix_cache_queries_total{model_name="qwen"} 100.0']
            return self._send("\n".join(lines) + "\n", ctype="text/plain")
        if self.path == "/fake_log":
            with LOCK:
                return self._send(json.dumps(dict(LOG, new_convs=NEW_CONVS, max_inflight=INFLIGHT[1])))
        return self._send("{}", 404)

    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0))
        req = json.loads(self.rfile.read(n) or b"{}")
        if self.path != "/v1/chat/completions":
            return self._send("{}", 404)
        if req.get("model") != SERVED:   # vLLM: "The model `x` does not exist." (404) -- vLLM SMOKE1 run 1 failed on this
            with LOCK:
                LOG.setdefault("model_404", []).append(req.get("model"))
            return self._send(json.dumps({"error": {"message": f"The model `{req.get('model')}` does not exist.",
                                                    "type": "NotFoundError", "param": "model", "code": 404}}), 404)
        with LOCK:
            INFLIGHT[0] += 1
            INFLIGHT[1] = max(INFLIGHT[1], INFLIGHT[0])
        try:
            out = chat_reply(req)
        finally:
            with LOCK:
                INFLIGHT[0] -= 1
        with LOCK:
            LOG["chat"].append({k: req.get(k) for k in ("model", "max_tokens", "temperature", "top_p", "top_k", "stream",
                                                        "chat_template_kwargs", "tool_choice")}
                               | {"n_messages": len(req.get("messages") or []), "id": out["id"], "tools": bool(req.get("tools"))})
        print(f"(APIServer pid=1) INFO [loggers.py] Engine 000: Avg prompt throughput: 900.0 tokens/s, Avg generation "
              f"throughput: 280.0 tokens/s, Running: {INFLIGHT[0] + 1} reqs, Waiting: 0 reqs, GPU KV cache usage: 12.0%, "
              f"Prefix cache hit rate: 88.0%", flush=True)
        return self._send(json.dumps(out))


srv = ThreadingHTTPServer(("127.0.0.1", PORT), H)
srv.daemon_threads = True
print(f"(APIServer pid=1) INFO Starting vLLM server on http://127.0.0.1:{PORT}", flush=True)
srv.serve_forever()
