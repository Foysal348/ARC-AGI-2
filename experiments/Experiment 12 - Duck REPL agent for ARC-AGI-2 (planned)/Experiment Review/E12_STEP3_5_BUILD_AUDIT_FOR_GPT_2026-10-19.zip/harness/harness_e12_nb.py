"""CPU harness for the E12 notebook: runs the REAL notebook cells (mode/fallback, config, install branch with
Q27X_SKIP_INSTALL, tokenizer + E11 tokenizer check, Duck package + sandbox self-test, tasks, SGLang engine cell with launch /
caps / smoke against fake_sgl_duck_server.py, the Duck solver, the report). Scripted model replies only.
usage: python harness_e12_nb.py <notebook> <scenario>      scenarios: smoke | rerun | launchfail"""
import json
import os
import shutil
import socket
import subprocess
import sys
import time
import urllib.request
import zipfile
from pathlib import Path

NB, SCEN = sys.argv[1], sys.argv[2]
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "e11_05_harness"))
import beh_e11_05 as B  # noqa: E402

sys.stdout.reconfigure(encoding="utf-8")
if os.name == "nt":   # Windows-only test shim (Duck passes a 65 KB bootstrap as -c; Linux allows it)
    _real = subprocess.Popen
    _bdir = HERE / "runs" / "_bootstrap"
    _bdir.mkdir(parents=True, exist_ok=True)

    class _Shim(_real):
        def __init__(self, args, *a, **kw):
            if isinstance(args, list) and len(args) >= 5 and args[1:4] == ["-I", "-S", "-c"]:
                f = _bdir / "sandbox_bootstrap.py"
                if not f.exists() or f.read_text(encoding="utf-8") != args[4]:
                    f.write_text(args[4], encoding="utf-8")
                args = [args[0], "-I", "-S", str(f)] + args[5:]
            super().__init__(args, *a, **kw)
    subprocess.Popen = _Shim

ROOT = HERE / "nbwork"
ROOT.mkdir(exist_ok=True)
WORK = ROOT / f"{SCEN}_{time.strftime('%H%M%S')}"
WORK.mkdir()
ch, sol, multi, single = B.load()
PICK = ["2ba387bc"] + multi[:2] + single[:2]
FP8 = HERE.parent / "e11_05_harness" / "work" / "fp8_tok"
assert (FP8 / "config.json").exists(), "run the E11-05 harness once to create the fp8_tok fixture"
DFL = ROOT / "dflash"; DFL.mkdir(exist_ok=True)
json.dump({"architectures": ["DFlash2DraftModel"]}, open(DFL / "config.json", "w"))
WH = ROOT / "wheelhouse"; WH.mkdir(exist_ok=True)
json.dump({"sglang": "0.5.21"}, open(WH / "BUILD_INFO.json", "w"))
(WH / "requirements.lock").write_text("", encoding="utf-8"); (WH / "SHA256SUMS").write_text("", encoding="utf-8")
ARC = WORK / "arc"; ARC.mkdir()
shutil.copy(B.DATA / "arc-agi_evaluation_challenges.json", ARC / "arc-agi_evaluation_challenges.json")
shutil.copy(B.DATA / "arc-agi_evaluation_solutions.json", ARC / "arc-agi_evaluation_solutions.json")
json.dump({t: {"train": ch[t]["train"], "test": [{"input": q["input"]} for q in ch[t]["test"]]} for t in PICK},
          open(ARC / "arc-agi_test_challenges.json", "w"))
with socket.socket() as s:
    s.bind(("127.0.0.1", 0)); PORT = s.getsockname()[1]
os.environ.update(Q27X_ARC_ROOT=str(ARC), Q27X_WORKING=str(WORK), Q27X_MODEL=str(FP8), Q27X_SKIP_INSTALL="1",
                  PYTHONIOENCODING="utf-8", E11_HARNESS="1", E11_PORT=str(PORT),
                  E11_FAKE_SERVER=str(HERE / "fake_sgl_duck_server.py"), E11_INT4=str(B.TOKDIR_INT4), E11_DFLASH=str(DFL),
                  E11_SGL_WHEELHOUSE=str(WH), FAKE_SCEN=SCEN, E12_DIR=str(WORK / "e12_duck"),
                  ARC3_HTTP_RETRY_BASE_SECONDS="0.05", ARC3_HTTP_RETRY_MAX_SECONDS="0.1")
if SCEN == "rerun":
    os.environ["KAGGLE_IS_COMPETITION_RERUN"] = "true"

nb = json.load(open(NB, encoding="utf-8"))
code = ["".join(c["source"]) for c in nb["cells"] if c["cell_type"] == "code"]
assert len(code) == 8 and "CELL 3 — E12: Duck package" in code[3] and "CELL 5 — engine: SGLang" in code[5], len(code)
G = {"__name__": "__main__"}
t0 = time.time()
for i in (0, 1):
    exec(compile(code[i], f"<cell{i}>", "exec"), G)
G["E12_SOLVE_WINDOW_SEC"] = 25 if SCEN != "rerun" else None
for i in (2, 3, 4, 5):
    exec(compile(code[i], f"<cell{i}>", "exec"), G)
if SCEN == "rerun":
    G["HARD_STOP"] = time.perf_counter() + 25 + G["E12_STOP_BEFORE_HARD_SEC"]
for i in (6, 7):
    exec(compile(code[i], f"<cell{i}>", "exec"), G)

checks = []


def check(label, cond, info=""):
    checks.append((label, bool(cond), "" if cond else str(info)[:800]))


rep = json.load(open(WORK / "q27x" / "e12_run_report.json", encoding="utf-8"))
sub = json.load(open(WORK / "submission.json", encoding="utf-8"))
test = json.load(open(ARC / "arc-agi_test_challenges.json", encoding="utf-8"))
check("submission schema = every test task, every test input",
      set(sub) == set(test) and all(len(sub[t]) == len(test[t]["test"]) for t in test), list(sub))
check("sandbox self-test ok", G["E10_SANDBOX_SELFTEST"].get("ok"), G["E10_SANDBOX_SELFTEST"])
if SCEN == "launchfail":
    check("engine not ready -> Duck not run", not G["ENGINE_READY"] and "not run" in str(rep["e12_run"]["error"]), rep["e12_run"])
    check("fallback submission = identity", all(a["attempt_1"] == q["input"] for t in test for a, q in zip(sub[t], test[t]["test"])), "")
else:
    flog = json.loads(urllib.request.urlopen(f"http://127.0.0.1:{PORT}/fake_log", timeout=10).read()) if G["E11_SERVER"].alive() else None
    check("engine ready with concurrency 12", G["ENGINE_READY"] and G["CONCURRENCY"] == 12, G["ENGINE_INFO"])
    check("e11 smoke passed (generate + abort)", G["E11_SGL"]["smoke"]["ok"], G["E11_SGL"]["smoke"])
    check("model id from /v1/models", rep["e12_run"]["model_id"] == "fake-int4", rep["e12_run"])
    check("no solver error", not rep["e12_run"]["error"], rep["e12_run"]["error"])
    n_br = len(G["TASK_IDS"]) * G["E12_BRANCHES"]
    check(f"all {n_br} branches finished", rep["e12_run"]["branches_done"] == n_br, rep["e12_run"])
    check("one accepted branch per task", rep["e12_run"]["branches_accepted"] == len(G["TASK_IDS"]), rep["e12_run"])
    check("usage recorded with cached_tokens", rep["usage_all"]["requests"] > 0 and rep["usage_all"]["cached_tokens"] > 0,
          rep["usage_all"])
    if SCEN == "smoke":
        check("profile SMOKE1 = 2ba387bc", G["PROFILE"] == "SMOKE1" and G["TASK_IDS"] == ["2ba387bc"], G["TASK_IDS"])
        check("eval scored: every query hit", rep.get("eval_query_hits") == rep.get("eval_query_total") and rep["eval_query_total"],
              (rep.get("eval_query_hits"), rep.get("eval_query_total")))
        check("task-norm 100 %", rep.get("eval_task_norm_pct") == 100.0, rep.get("eval_task_norm_pct"))
        check("evaluation keeps the test fallback in submission.json",
              all(a["attempt_1"] == q["input"] for t in test for a, q in zip(sub[t], test[t]["test"])), "")
    if SCEN == "rerun":
        check("rerun: TASK_IDS = test tasks", sorted(G["TASK_IDS"]) == sorted(test), G["TASK_IDS"])
        hit = sum(a["attempt_1"] == sol[t][qi] for t in test for qi, a in enumerate(sub[t]))
        check("rerun: submission carries the solved grids", hit == sum(len(test[t]["test"]) for t in test), hit)
    if flog:
        c0 = flog["chat"][0]
        check("chat request: preserve/enable thinking, 12288, 0.7/0.95/20, non-stream",
              (c0["chat_template_kwargs"] or {}).get("preserve_thinking") is True and c0["max_tokens"] == 12288
              and (c0["temperature"], c0["top_p"], c0["top_k"]) == (0.7, 0.95, 20) and not c0.get("stream"), c0)
        roles = [r for _, r, _ in flog["new_convs"]]
        check("first branches start before any second branch", roles == sorted(roles), flog["new_convs"])
        check("in-flight <= streams", flog["max_inflight"] <= 12, flog["max_inflight"])
    with zipfile.ZipFile(WORK / "Q27X_E12_DUCK_BUNDLE.zip") as z:
        names = z.namelist()
    trs = [n for n in names if n.endswith("transcript.txt")]
    check("bundle: report, submission, transcripts per branch, server log",
          {"e12_run_report.json", "submission.json"} <= set(names) and len(trs) == n_br
          and any(n.startswith("sglang_server_") for n in names), names[:20])
    with zipfile.ZipFile(WORK / "Q27X_E12_DUCK_BUNDLE.zip") as z:
        check("transcripts hold the thinking", all("THINK step" in z.read(n).decode("utf-8", "replace") for n in trs), "")
G["e11_kill_server"](wait=False)
bad = [c for c in checks if not c[1]]
print(f"\n[{SCEN}] {len(checks) - len(bad)}/{len(checks)} ok in {time.time() - t0:.0f} s")
for c in bad:
    print("   FAIL", c[0], "->", c[2])
print("@@NB_OK@@" if not bad else "@@NB_FAIL@@")
