"""Experiment 12 step 3: CPU harness for arc2_duck on top of the vendored (unmodified) Duck package.

Real Duck ToolAgent + real Duck sandbox + a scripted fake OpenAI server (fake_openai.py). Only our own scripted
code runs in the sandbox. Each scenario runs in a fresh subprocess, because Duck reads its settings at import.
    python harness_e12.py              # all scenarios
    python harness_e12.py --scenario solve
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import sys
import tempfile
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
E12 = Path(r"D:/ARC AGI 2/experiments/Experiment 12 - Duck REPL agent for ARC-AGI-2 (planned)/duck_arc2")
OUT = HERE / "runs"

# ------------------------------------------------------------------ synthetic tasks (ours)
flip = lambda g: [list(reversed(r)) for r in g]
TASKS = {
    "flip": {"train": [{"input": g, "output": flip(g)} for g in ([[1, 2, 3], [4, 5, 6]], [[7, 0], [0, 8], [9, 9]])],
             "test": [{"input": [[3, 1], [2, 2]]}, {"input": [[5, 6, 7]]}]},
    "recolor": {"train": [{"input": [[1, 0], [0, 1]], "output": [[2, 0], [0, 2]]},
                          {"input": [[0, 1, 1]], "output": [[0, 2, 2]]}],
                "test": [{"input": [[1, 3], [3, 0]]}]},
    "transpose": {"train": [{"input": [[1, 2], [3, 4]], "output": [[1, 3], [2, 4]]},
                            {"input": [[5, 6, 7]], "output": [[5], [6], [7]]}],
                  "test": [{"input": [[1, 0, 2], [0, 3, 0]]}]},
}

INSPECT = "print(len(train), [(len(p['input']), len(p['input'][0])) for p in train], len(test_inputs))"
FLIP_DEF = "def transform(g):\n    return [list(reversed(r)) for r in g]\ncheck(transform)"
SUBMIT = "submit(transform)"
IDENT_SUBMIT = "def transform(g):\n    return [list(r) for r in g]\ncheck(transform)\nsubmit(transform)"
REC_A = "def transform(g):\n    return [[2 if v == 1 else v for v in r] for r in g]\ncheck(transform)\nsubmit(transform)"
REC_B = ("def transform(g):\n    m = {1: 2, 3: 4}\n    return [[m.get(v, v) for v in r] for r in g]\n"
         "check(transform)\nsubmit(transform)")
BIG_PRINT = "print('x' * 10000)"


def T(code, ct=300, **kw):
    return dict(kind="tool", code=code, ct=ct, **kw)


GAME_WORDS = [r"current_frame", r"action\(actions\)", r"world model", r"(?<!top-)\blevel\b", r"\bgame\b",
              r"segmentation", r"valid_actions", r"\bRESET\b", r"\bboard\b"]


# ------------------------------------------------------------------ scenario runner (child process)
def child(name: str) -> dict:
    sys.path[:0] = [str(E12), str(E12 / "vendor"), str(HERE)]
    sys.stdout.reconfigure(encoding="utf-8")
    import arc2_duck as A
    from fake_openai import FakeOpenAI

    if os.name == "nt":  # Windows-only test shim, see e12_smoke/smoke_adapter.py (Linux passes -c fine)
        real = subprocess.Popen
        bdir = OUT / "_bootstrap"
        bdir.mkdir(parents=True, exist_ok=True)

        def shim(args, *a, **kw):
            if isinstance(args, list) and len(args) >= 5 and args[1:4] == ["-I", "-S", "-c"]:
                f = bdir / "sandbox_bootstrap.py"
                if not f.exists() or f.read_text(encoding="utf-8") != args[4]:
                    f.write_text(args[4], encoding="utf-8")
                args = [args[0], "-I", "-S", str(f)] + args[5:]
            return real(args, *a, **kw)
        subprocess.Popen = shim

    streams = {"gate": 2}.get(name, 12)
    env = A.duck_env("http://127.0.0.1:9/v1", "qwen-fake", streams)
    env.update({"ARC3_HTTP_RETRY_BASE_SECONDS": "0.05", "ARC3_HTTP_RETRY_MAX_SECONDS": "0.1",
                "ARC3_HTTP_RETRY_INITIAL_SECONDS": "5"})
    if name == "trim":
        env["LOCAL_ANALYZER_CONTEXT_WINDOW"] = str(40 * 1024)
    os.environ.update(env)

    programs = {
        "solve": lambda t, r: [T(INSPECT), T(FLIP_DEF), T(SUBMIT)],
        "wrong_then_fix": lambda t, r: [T(INSPECT), T(IDENT_SUBMIT), T(FLIP_DEF), T(SUBMIT)],
        "empty_code": lambda t, r: [T(""), T(SUBMIT), T(FLIP_DEF), T(SUBMIT)],
        "markup_leak": lambda t, r: [dict(kind="markup", code=INSPECT, ct=300), T(FLIP_DEF), T(SUBMIT)],
        "nudge": lambda t, r: [dict(kind="prose", ct=300), T(FLIP_DEF), T(SUBMIT)],
        "http500": lambda t, r: [T(INSPECT), T(FLIP_DEF), T(SUBMIT)],
        "yield": lambda t, r: [T(INSPECT, ct=1500), T(INSPECT, ct=1500), T(INSPECT, ct=300), T(FLIP_DEF), T(SUBMIT)],
        # short turns as in a real run (a yield every 2 completions), big tool outputs -> context trim
        "trim": lambda t, r: [T(FLIP_DEF, ct=1100)] + [T(BIG_PRINT, ct=1100)] * 20 + [T(SUBMIT)],
        "deadline": lambda t, r: [T(INSPECT)],
    }
    run_dir = Path(tempfile.mkdtemp(prefix=name + "_", dir=OUT))
    res: dict = {"scenario": name, "checks": []}

    def check(label, cond, info=""):
        res["checks"].append({"label": label, "ok": bool(cond), "info": "" if cond else str(info)[:600]})

    def all_texts(fake):
        for rq in fake.requests:
            b = rq["body"]
            for m in b.get("messages") or []:
                if m.get("role") in ("system", "user", "tool"):
                    yield m.get("role"), str(m.get("content") or "")
            for tl in b.get("tools") or []:
                yield "tooldesc", json.dumps(tl)

    def common(fake, recs):
        bodies = [rq["body"] for rq in fake.requests if rq["status"] == 200]
        check("requests served", bodies, len(fake.requests))
        b0 = bodies[0] if bodies else {}
        ctk = b0.get("chat_template_kwargs") or {}
        check("preserve_thinking + enable_thinking sent", ctk.get("preserve_thinking") is True
              and ctk.get("enable_thinking") is True, ctk)
        check("sampling 0.7/0.95/20, max_tokens 12288",
              (b0.get("temperature"), b0.get("top_p"), b0.get("top_k"), b0.get("max_tokens")) == (0.7, 0.95, 20, 12288),
              {k: b0.get(k) for k in ("temperature", "top_p", "top_k", "max_tokens")})
        check("system prompt = ARC-2 task", all("Training pair 1 input:" in str(b["messages"][0]["content"])
                                                for b in bodies), "")
        replay = any(any(m.get("role") == "assistant" and "THINK step" in str(m.get("reasoning_content") or "")
                         for m in b["messages"]) for b in bodies[1:])
        check("thinking replayed in later requests (reasoning_content)", replay, "")
        hits = sorted({(role, w) for role, txt in all_texts(fake) for w in GAME_WORDS if re.search(w, txt)})
        check("no game words reach the model", not hits, hits)
        for r in recs:
            tr = Path(r["run_dir"]) / "transcript.txt" if r.get("run_dir") else None
            if tr and tr.exists():
                check(f"transcript has full thinking ({r['task_id']} b{r['branch']})",
                      "THINK step" in tr.read_text(encoding="utf-8", errors="replace"), tr)

    t_start = time.time()
    if name == "gate":
        progs = {}

        def gate_prog(tkey, role):
            tid = fake.task_keys.get(tkey)
            if tid == "flip":
                return [T(FLIP_DEF), T(SUBMIT)]
            if tid == "recolor":
                return [T(REC_A if role == 0 else REC_B)]
            return [T(IDENT_SUBMIT, ct=1000), T(INSPECT, ct=1000)]
        progs = gate_prog
        fake = FakeOpenAI(progs, latency=0.05)
        Agent = A.make_agent_class()
        for tid, task in TASKS.items():
            fake.task_keys[fake.task_key(A.arc2_system_prompt(task, A._import_duck()[1], 3072))] = tid
        del Agent
        order = ["flip", "recolor", "transpose"]
        records = A.solve_all(TASKS, order, out_dir=run_dir, deadline=time.monotonic() + 120, base_url=fake.base_url,
                              model_id="qwen-fake", branches=2, max_generated_tokens=5000)
        flat = [dict(r, run_dir=str(run_dir / f"{r['task_id']}_b{r['branch']}")) for v in records.values() for r in v]
        common(fake, flat)
        check("gate: at most 2 requests in flight", fake.max_inflight <= 2, fake.max_inflight)
        roles = [r for _, r in fake.new_conv_order]
        check("gate: all first branches start before any second branch", roles == [0, 0, 0, 1, 1, 1], roles)
        tx = [r for r in records["transpose"]]
        check("token cap stops unsolved branches", all(not r["accepted"] and r["generated_tokens"] >= 5000
                                                       and r["generated_tokens"] < 9000 for r in tx),
              [(r["generated_tokens"], r["note"]) for r in tx])
        sub = A.build_submission(TASKS, records)
        ok_schema = set(sub) == set(TASKS) and all(
            len(sub[t]) == len(TASKS[t]["test"]) and all(A.valid_grid(a["attempt_1"]) and A.valid_grid(a["attempt_2"])
                                                        for a in sub[t]) for t in sub)
        check("submission schema (all tasks, every test, valid grids)", ok_schema, sub)
        check("flip: agreed program first", sub["flip"][0]["attempt_1"] == flip(TASKS["flip"]["test"][0]["input"])
              and sub["flip"][1]["attempt_1"] == flip(TASKS["flip"]["test"][1]["input"]), sub["flip"])
        a1, a2 = sub["recolor"][0]["attempt_1"], sub["recolor"][0]["attempt_2"]
        check("recolor: two distinct train-exact programs fill attempt_1/attempt_2",
              {json.dumps(a1), json.dumps(a2)} == {json.dumps([[2, 3], [3, 0]]), json.dumps([[2, 4], [4, 0]])}, (a1, a2))
        check("transpose: unsolved -> fallback grids", A.valid_grid(sub["transpose"][0]["attempt_1"]), sub["transpose"])
        res["detail"] = {"max_inflight": fake.max_inflight, "conv_order": fake.new_conv_order,
                         "requests": len(fake.requests)}
        fake.close()
        res["seconds"] = round(time.time() - t_start, 1)
        return res

    fake = FakeOpenAI(programs[name], latency=0.3 if name == "deadline" else 0.0, single_conv=True,
                      fail_first=2 if name == "http500" else 0)
    Agent = A.make_agent_class()
    task = TASKS["flip"]
    deadline = time.monotonic() + (6 if name == "deadline" else 120)
    rec = A.run_branch(Agent, task_id="flip", task=task, branch=0, queue_position=0, out_dir=run_dir,
                       deadline=deadline, base_url=fake.base_url, model_id="qwen-fake", save_request_logs=False,
                       backoff=0.2)
    rec["run_dir"] = str(run_dir / "flip_b0")
    common(fake, [rec])
    users = [str(m.get("content")) for rq in fake.requests for m in rq["body"]["messages"] if m.get("role") == "user"]
    tools = [str(m.get("content")) for rq in fake.requests for m in rq["body"]["messages"] if m.get("role") == "tool"]
    if name != "deadline":
        check("accepted", rec["accepted"], rec.get("note"))
        sub = A.build_submission({"flip": task}, {"flip": [rec]})
        check("test outputs = host-verified flip", [a["attempt_1"] for a in sub["flip"]]
              == [flip(q["input"]) for q in task["test"]], sub)
    if name == "solve":
        check("3 requests, 1 submission", len(fake.requests) == 3 and len(rec["submissions"]) == 1,
              (len(fake.requests), len(rec["submissions"])))
    if name == "wrong_then_fix":
        check("rejection opener sent", any("was not accepted" in u for u in users), users[-3:])
        check("2 submissions (1 rejected, 1 accepted)", [s["accepted"] for s in rec["submissions"]] == [False, True],
              [s["summary"] for s in rec["submissions"]])
    if name == "empty_code":
        check("empty code -> error to model", any("non-empty `code`" in t for t in tools), tools[:3])
        check("submit before define -> NameError to model", any("NameError" in t for t in tools), tools[:4])
    if name == "markup_leak":
        check("markup tool call recovered and executed", any("2 [(2, 3), (3, 2)] 2" in t for t in tools), tools[:3])
    if name == "nudge":
        nud = [u for u in users if "check(transform)" in u and "submit(transform)" in u and "Call the `python` tool" in u]
        check("no-tool reply -> ARC-2 nudge", nud, users)
    if name == "http500":
        check("two 500s retried in place", [rq["status"] for rq in fake.requests][:3] == [500, 500, 200],
              [rq["status"] for rq in fake.requests])
        check("no driver-level failure", rec["failures"] == 0, rec["failures"])
    if name == "yield":
        check("yield -> continuation opener", any(u.startswith("Nothing has been submitted") for u in users), users)
        check("several analyzer turns", rec["turns"] >= 2, rec["turns"])
    if name == "trim":
        sizes = [len(rq["body"]["messages"]) for rq in fake.requests]
        check("history trimmed (message count dropped)", any(b < a for a, b in zip(sizes, sizes[1:])), sizes)
        check("retained transform survives trim", rec["accepted"], rec.get("note"))
        check("task (system prompt) kept after trim", all(
            "Training pair 1 input:" in str(rq["body"]["messages"][0]["content"]) for rq in fake.requests), "")
        tr = (Path(rec["run_dir"]) / "transcript.txt").read_text(encoding="utf-8", errors="replace")
        res.setdefault("detail", {})["transcript_trim_lines"] = [l for l in tr.splitlines() if "trim" in l.lower()][:4]
        res.setdefault("detail", {})["message_counts"] = sizes
    if name == "deadline":
        el = rec["t1"] - rec["t0"]
        check("stops at the deadline", not rec["accepted"] and el < 9, el)
        res["detail"] = {"seconds": round(el, 1), "turns": rec["turns"], "requests": len(fake.requests)}
    fake.close()
    res["seconds"] = round(time.time() - t_start, 1)
    return res


SCENARIOS = ["solve", "wrong_then_fix", "empty_code", "markup_leak", "nudge", "http500", "yield", "trim",
             "deadline", "gate"]


def main():
    if "--scenario" in sys.argv:
        name = sys.argv[sys.argv.index("--scenario") + 1]
        r = child(name)
        print("@@RESULT@@" + json.dumps(r))
        return
    OUT.mkdir(exist_ok=True)
    total_ok = True
    summary = []
    only = sys.argv[1:] or SCENARIOS
    for name in only:
        p = subprocess.run([sys.executable, str(Path(__file__)), "--scenario", name], capture_output=True, text=True,
                           encoding="utf-8", errors="replace", timeout=600)
        line = next((l for l in p.stdout.splitlines() if l.startswith("@@RESULT@@")), None)
        if line is None:
            print(f"[{name}] CRASH rc={p.returncode}\n{p.stdout[-2000:]}\n{p.stderr[-3000:]}")
            total_ok = False
            continue
        r = json.loads(line[len("@@RESULT@@"):])
        bad = [c for c in r["checks"] if not c["ok"]]
        total_ok &= not bad
        summary.append((name, len(r["checks"]) - len(bad), len(r["checks"]), r.get("seconds")))
        print(f"[{name}] {len(r['checks']) - len(bad)}/{len(r['checks'])} ok  ({r.get('seconds')} s)"
              + (f"  detail={r.get('detail')}" if r.get("detail") else ""))
        for c in bad:
            print(f"    FAIL {c['label']}: {c['info']}")
    (OUT / "summary.json").write_text(json.dumps(summary), encoding="utf-8")
    print("ALL SCENARIOS OK" if total_ok else "SOME SCENARIOS FAILED")


if __name__ == "__main__":
    main()
