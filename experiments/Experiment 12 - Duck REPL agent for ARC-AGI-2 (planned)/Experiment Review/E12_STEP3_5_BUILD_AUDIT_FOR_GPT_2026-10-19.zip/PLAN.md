# Experiment 12: the Duck REPL agent for ARC-AGI-2. Plan (2026-10-19)

**User decision (2026-10-19):**
- **Option A:** Duck-style short requests with preserved, accumulating thinking. This is an approved exception to the 60k-per-request floor; the floor still holds for Poetiq/DIRECT and every rescue.
- **Adapt verbatim** whatever can be adapted verbatim. Write new code only where ARC-AGI-2 differs from ARC-AGI-3.

## 0. Sources (all Apache-2.0; keep LICENSE + attribution)

| Source | What we take | Status |
|---|---|---|
| `da-fr/arc-agi-3-solution`, Daniel Franzen's fork of Tufa's Duck harness at upstream 7652836 | `ARC3-Inference/inference/` package (`tool_agent.py` 7.3k lines, `python_tool_sandbox.py`, `retained_functions`, `priority_scheduler.py`, `prompts.py`, utils), CONFIGURATION.md, WRITEUP | **cloned** to `_scratch/ext/dafr` |
| `Tufalabs/duck-harness` @ 7652836 (the upstream) | for diffing: which parts are Tufa's originals | to clone |
| Kaggle `dfranzen/arc-agi-3-milestone-2-solution` | exact env switches, server args, the "harness patch" as submitted | to pull (Kaggle API) |
| Kaggle `jeroencottaar/tufa-labs-duck-harness-june-30-milestone-winner` + thread 717133 | Tufa's own settings and write-up | to pull |
| Kaggle dataset `keithtyser/taaf-duck-qwen38-serving-v1` (ARC Raiders, 68.33) | Duck serving for Qwen3.8-27B on 4×L4 | to pull and read |
| `madarshbb/arc-qwen-3-8-27b-agent` (Duck-modelled ARC-2 agent, 15.69) | reference only: how someone mapped train pairs to the REPL; what not to do | local copy exists |

## 1. What we adopt verbatim (no edits; imported as a vendored package)

| Piece | Where | Why verbatim |
|---|---|---|
| Chat request builder + retries | `ToolAgent._chat_completion`, `_post_with_retries`, `_http_retry_delay_seconds` | tools + `chat_template_kwargs` (`preserve_thinking`, `reasoning_effort`), 5xx/timeout recovery (the bugs that killed our Q27-AGENT) |
| Tool-call parsing + recovery | `_contains_tool_call_markup`, `_recover_tool_calls_from_markup`, `_extract_leaked_tool_calls`, `_extract_reasoning_text` | Qwen3.x tool calls leaking into content / reasoning |
| Yield / resume | `_yield_resume_prompt*`, yield at N generated tokens | Duck: yield at 2,048, max output 12,288 per request |
| Context estimation + trimming | `_estimate_tokens`, `_calibrate_from_usage`, `_trim_messages_for_context`, `_drop_oldest_history_block`, hysteresis / drain switches | 93 % prefix reuse in Duck; trimming in large blocks keeps the prefix cache-hot |
| Python sandbox | `python_tool_sandbox.run_sandboxed_python` (subprocess `-I -S`, SAFE_MODULES, timeouts, output caps, middle truncation, function retention) | proven isolation and retention; kills the empty-code / hang classes of bugs |
| Admission + priority gate | `_PriorityGate`, `_max_active_streams`, Duck's C-term (token fade, `t/62000`) | slots = server limit, cache-aware handover at eviction |
| Transcripts / request logs / viewer | `_append_transcript_section`, request snapshots, `viewer/` | full trace of every request (the save-all-thinking rule) |
| Sampling + limits | T 0.7, top_p 0.95, top_k 20; max output 12,288; context 128 Ki with drain to ~57 Ki; tool output ~3,072 tokens | exactly as in the milestone notebook (verify against the pulled notebook) |

Game-only features are switched **off with their own env switches**, not deleted:
- animations;
- frame_diff / auto diff;
- UNDO / RESET;
- noop, stale and terminal guards;
- death ledger;
- world-model sections;
- level-transfer guidance;
- images (phase 1; the image path is kept for phase 3).

## 2. The only new code: a thin ARC-AGI-2 adapter (target ≤ 400 lines)

1. **Subclass `ToolAgent` → `Arc2ToolAgent`.** Override only:
   - `_build_system_prompt`: ARC-2 objective. Duck's tool-usage wording is kept verbatim where it is not game-specific.
   - `_build_user_prompt`: the task as text, using the Duck/Poetiq digit-row format.
   - `_run_python_tool`: `initial_state` = the task, and `action_handler` = submit.
   
   Everything else is inherited.
2. **REPL globals (initial_state):**
   - `train` = a list of {input, output} grids;
   - `test_inputs`;
   - helper `check(transform)` → per-pair pass/fail, shape and a wrong-cell diff. The diff format is Poetiq's `poetiq_array_diff`, which we already run.
   - The helpers are model-visible source, kept with Duck's function-retention mechanism.
3. **`submit(transform)` = the host action.** It runs the program on every train pair and every test input in the sandbox:
   - all train pairs pass → record a candidate and end the branch;
   - otherwise → return the failure diff and continue.
   
   The episode cap is set by tokens and time (Duck's budgets), not by a fixed iteration count.
4. **Two independent branches per task** (different seeds) → attempt_1 / attempt_2.
   - Selection: (a) agreement of the test outputs across branches; (b) train pass.
   - Fallback: if no branch passes train, use the best partial program; else the test input. This is our existing `poetiq_two_attempts` logic.
5. **Notebook frame from our proven notebooks:**
   - CELL0 fallback submission;
   - RERUN = hidden;
   - commit = eval subset + score;
   - 12 h clock (admit / drain / hard stop);
   - the SGLang W1 engine (rev 3c: server 13 / client 12; `MAX_MODEL_LEN` 155,648);
   - the full-trace bundle.

## 2a. Rev 1: approved by the user on 2026-10-19 (blockers verified in the source; vendored code still unchanged)

The GPT reviews were checked against the code. Only real blockers were taken, and every fix stays in the adapter.

| # | Verified blocker | Source | Fix (adapter only) |
|---|---|---|---|
| 1 | `_build_system_prompt` is a module-level function called in `ToolAgent.__init__`, so a subclass method would never run | `tool_agent.py:2653, 3502` | `Arc2ToolAgent.__init__`: after `super().__init__()`, set `self._system_prompt = ARC2_SYSTEM_PROMPT` |
| 2 | The sandbox's `_refresh_state` exposes only fixed game keys; extra `initial_state` keys never reach the REPL | `python_tool_sandbox.py` `_refresh_state` | Prepend a trusted pure-Python prelude (task grids as literals + `check` / `submit` helpers) to the model's code, then call the verbatim `run_sandboxed_python` |
| 3 | The host callback is JSON IPC (`action_handler(actions, stale_after)`), so a function object cannot be submitted | `python_tool_sandbox.py:931` | `submit` runs the transform inside the sandbox and sends JSON (train results + test grids) through the existing action channel. The host re-verifies the program in a clean sandbox call (verbatim runner) and never trusts the self-report. |
| 4 | No numpy in the sandbox (SAFE_MODULES whitelist, `python -I -S`) | `SAFE_MODULES` | The sandbox stays unchanged. The system prompt requires a pure-Python list `transform(grid)`. |
| 5 | `analyze()` loads a game state file (`load_runtime_state`), and the python-tool description is game text | `tool_agent.py:6563+`, `runtime_state.py:113`, `_tools()` | Write a minimal state file with Duck's own `write_runtime_state` (session bridge); override `_tools()` with an ARC-2 tool description |

| 8 | `analyze()` writes an inline game-text nudge (world model, `current_frame`, `action(actions)`) when a reply has no tool call (user-approved 2026-10-19) | `tool_agent.py:7019-7037` | Override `_append_context_message`: for messages Duck marks as control kind "nudge", keep Duck's generic prefix (truncation / malformed JSON / markup sentences) and replace only the game tail with the ARC-2 instruction (`transform` → `check` → `submit`) + `TOOL_CALL_FORMAT_GUIDANCE` |

**Override points therefore become:** `__init__`, `_build_user_prompt`, `_run_python_tool`, `_tools`, plus the state-file bridge. The adapter is expected at about 400–600 lines (soft target).

**6. Selection order corrected:**
1. The program passes all train pairs (host-verified) with valid test grids.
2. Then agreement across branches.
3. Then distinct second grids for attempt_2.

Agreement never outranks train pass (the same logic as our Poetiq voting).

**7. Added step 3.5, a GPU smoke test** (1 task, 2 branches, 10–15 min) before EVAL30. It must show:
- structured tool calls;
- preserved thinking replayed in the next turn;
- function retention across tool calls;
- `cached_tokens` rising across turns;
- no server errors.

**Not adopted (would drift from the plan):**
- KV-aware admission (the server queue + Duck's gate stay);
- a numpy execution backend;
- forcing `reasoning_effort` per request (the template default is xhigh; the ladder is off by default);
- porting the prefix-cache patch before measuring;
- a new priority-formula design or a coverage-first branch policy beyond Duck's own all-admitted + priority gate.

**Checked, no change needed:**
- `ARC3_REASONING_HISTORY_KEY=reasoning_content` is already in the notebook settings.
- The yield is evaluated between completions; that is copied verbatim.

## 2b. Step 2 status (2026-10-19): done, gate passed

- `duck_arc2/arc2_duck.py` (538 lines): `Arc2ToolAgent` + prelude + host re-verification + driver (`run_branch` / `solve_all`, a line-by-line mirror of `play()` / `_play_inner()`) + `select_attempts`. **pyflakes clean.** The vendored `inference/` (20 files) **still hash-matches** da-fr @ 10882e33.
- **Offline smoke** (`_scratch/session_1c6db7aa/e12_smoke/smoke_adapter.py`; real Duck sandbox, our scripted code, synthetic flip task): **26/26 PASS**. It covers: task in the system prompt, no game words, globals, `check`, retention, wrong submit, the `train`-reading cheat refused, numpy refused, line numbers rebased, lambda refused, accept + host test outputs, forged marker ignored, nudge rewrite, resume opener, selection.
- **Small fixes found while coding, all inside the adapter's own text or helpers (no plan change):**
  - **Resume opener:** the milestone uses the 'full' resume mode, so `_build_user_prompt` runs after every 2,048-token yield. It now returns a continuation (Duck's own "nothing has been executed… your tool results above are still valid" wording) instead of "Start with…".
  - **Output noise:** `check` and `submit` no longer echo their return value through Duck's last-expression print. `check(..., verbose=False)` returns the list.
  - **Retention prompt was untrue:** a retained function cannot depend on the prelude globals, because the sandbox computes `_available_names` before the code runs. The prompt now says so.
  - **Wording:** "in this game" in retention notes → "on this task".
  - **Driver alignment with Duck:** the agent now receives `timeout=analyzer_timeout` (as Duck's solver passes it); the request timeout is `max(0.1, min(...))` as in Duck.
  - **Optional `max_generated_tokens` per branch:** this is Duck's `max_generated_tokens_per_game`. The default is None, as in the milestone hidden run.
- **Local-only note:** Duck passes its 65 KB sandbox bootstrap as `python -c`. Windows caps a command line at 32,767 characters (WinError 206); Linux/Kaggle allows 128 KiB per argument. The local harness therefore uses a test shim (the bootstrap written to a file). Vendored code is unchanged.
- **Open, measure in EVAL30:** in Duck a branch frees its gate slot only on accept or at its first context trim (~128k context). Unsolved branches may therefore each consume ~80–100k generated tokens before yielding. That is roughly 20M for 240 branch-0s, against ~14M per 12 h at 329 tok/s. If EVAL30 confirms this, the per-branch cap (`max_generated_tokens`) is the Duck-native lever, and its value is a user decision.

## 2c. Step 3 status (2026-10-19): CPU harness done, 10/10 scenarios (113 checks) pass

**Harness.** `_scratch/session_1c6db7aa/e12_harness/`:
- `fake_openai.py`: a scripted `/v1/chat/completions` server. It never generates or runs model code; it records every request and the in-flight count.
- `harness_e12.py`: real Duck `ToolAgent` + real sandbox; each scenario runs in a fresh subprocess, because Duck reads its settings at import.

**Scenarios and what each one checks:**

| Scenario | What it checks |
|---|---|
| solve | — |
| wrong_then_fix | the rejection opener is sent; 2 submissions |
| empty_code | + submit-before-define → NameError |
| markup_leak | leaked `<tool_call>` markup is recovered and executed |
| nudge | ARC-2 nudge text |
| http500 | two 500s retried in place; no driver failure |
| yield | continuation opener; several turns |
| trim | history trimmed; task kept; retained `transform` survives; accepted |
| deadline | stops at the deadline |
| gate | 2 slots, 3 tasks × 2 branches; ≤ 2 in flight; all first branches start before any second branch; the token cap stops unsolved branches; submission schema; agreement, distinct attempt_2, fallback |

**Common checks in every scenario:**
- `preserve_thinking` + `enable_thinking` are sent;
- sampling 0.7 / 0.95 / 20 and `max_tokens` 12,288;
- the system prompt is the ARC-2 task;
- thinking is replayed (`reasoning_content`);
- no game words reach the model;
- the transcript holds the full thinking.

**Adapter fixes found by the harness (all in our adapter):**
- **Wording:** Duck's opener note "retained functions … in this game" now reads "on this task" (`_retained_function_context`).
- **Deterministic first admission:** Duck's gate admits whoever arrives first while slots are free, so the first 12 admissions were a thread race. `solve_all` now holds every slot until all branches are queued, then releases them, so the first admissions follow the queue priority too.
- **Setup guard:** a branch that fails during setup no longer takes `solve_all` down.
- **New helper:** `build_submission` writes the full schema with fallbacks.

**Duck behaviour seen (verbatim, kept):** trimming drops whole earlier turns. With 2,048-token yields the turns are small, so trimming is gradual: message counts 22 → 9 → 7 …

## 3. Serving (our validated engine plus what Duck needs)

- **Server flags:** SGLang 0.5.21 W1 (INT4 + DFlash2, extra_buffer_lazy, fp16 SSM) **+ `--tool-call-parser qwen3_coder --reasoning-parser qwen3`**. Verify both exist in 0.5.21 and that the template honours `preserve_thinking`.
- **Request path:** the harness uses the OpenAI-compatible `/v1/chat/completions` (Duck provider mode "vllm" = an OpenAI-compatible request; it does not start vLLM).
- **Prefix reuse across turns is the critical risk on 0.5.21:** re-tokenization, and lazy mamba checkpoints at track intervals.
  - Measure `cached_tokens` per request in the first GPU run.
  - If it is low, port Franzen's patch #4 (keep the end-of-prefill Mamba checkpoint, LRU refresh) from Pennyroyal v2.5.3 to 0.5.21.
  - Patches #1–#3 (sm120 GEMM, sm120 SSM budget, Marlin MoE dtype) are sm120/MoE-specific and not needed on L4 with 27B.

## 4. Steps and gates

| # | Step | Gate (must pass before the next step) |
|---|---|---|
| 1 | Pull the remaining sources (§0); diff Franzen vs Tufa upstream; record the exact milestone env/config | the settings table is filled from the notebook, not from memory |
| 2 | Vendor `inference/` unchanged; write `Arc2ToolAgent` + REPL globals + submit | pyflakes clean; the vendored files hash-match the upstream clone |
| 3 | CPU harness: a fake OpenAI server that replays scripted tool calls (our own scripted code, never model code), with the real sandbox | scenarios: solve, wrong-then-fix, empty code, tool markup leak, HTTP 500 retry, yield/resume, context trim, deadline, 2-branch selection, rerun submission schema |
| 3.5 | GPU smoke: 1 task, 2 branches, 10–15 min (Rev 1 #7) | tool calls, thinking replay, function retention, rising `cached_tokens`, no server errors |
| 4 | GPU EVAL30 (the same 30 tasks as E11-05/E11-06) on one account | report: hits, tokens/task, turns, tool calls, submits, `cached_tokens` %, running 12, trace bundle |
| 5 | Decide the Flash-Next question separately (user); then the LB submission | — |

**Deadlines:** rosters lock 2026-10-26; final submission 2026-11-02. Target: step 4 on GPU by 2026-10-22.

## 5. What is not changed, and the open user decisions

- **Not changed:** xhigh; Qwen3.8-27B (Apache-2.0); the 60k floor for every non-agent path.
- **Open (user):**
  - Flash-Next (speed vs licence risk);
  - whether to run P1/S60 EVAL30 in parallel as the baseline.
