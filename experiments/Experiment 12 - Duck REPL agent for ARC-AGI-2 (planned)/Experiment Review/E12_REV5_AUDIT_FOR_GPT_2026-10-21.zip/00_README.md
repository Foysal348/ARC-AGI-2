# E12 rev 5 (Duck REPL agent, Qwen3.8-27B, ARC-AGI-2, 4xL4): pre-GPU audit (2026-10-21)

## Ask

Audit rev 5 before the GPU run. Report **blockers and bugs** (file:line), certain vs possible.

- Is every change correct and complete?
- Can it break the run or give a wrong conclusion?
- Does anything leak into the old (rev 4) behaviour?

**Out of scope:** new features, or a different plan. The user chose one bundled run with every evidence-based fix (no time / GPU for small runs).

## Why (evidence, all in `docs/`)

The rev 4 EVAL6 run (6 selected tasks) solved 3/6 (4/8 inputs). The weakness analysis and three GPT reports were validated claim by claim on all 43 branches of EVAL6 + EVAL30 (`docs/E12 next fix list (running, 2026-10-20).md`, sections "Deep re-validation" and "Rev 5 implementation"):

- **Correct functions lost.** 62593bfd_b1 and b5ca7ac4_b0 had train-exact, test-correct functions that were never submitted. The real-sandbox replay shows they would be recovered.
- **The reply just made was dropped from the next prompt.** 5 resets cost about 279k tokens. The real tokenizer proves the next prompt would have fitted (65-69k ≤ 70,560), but Duck's grid-calibrated estimate said 77-111k.
- **Repetition loops.** They take 29 % of thinking characters, start early, and fill the rest of the reply.
- **Output size.** No productive reply exceeded 44,779 tokens, and the 7 replies that hit 60k had no tool call.
- **attempt_2 wasted.** It was the test input in 56/56 slots; 4/11 accepts were test-wrong.
- **Cut tool calls executed.** A tool call cut at the output limit still ran (5 times in EVAL30).
- **Thinking instead of testing.** 22/24 (EVAL30) and 5/8 (EVAL6) failed branches never ran `check()`, and there were hand misreads of grids.

## What changed (`diffs/arc2_duck_rev4_to_rev5.diff`, `diffs/build_rev4_to_rev5.diff`)

**Scope:**
- Only `duck_arc2/arc2_duck.py` and the builder changed.
- **The 20 vendored Duck files are byte-identical** (package manifest in the notebook).
- Every adapter change is behind `E12_ARC2_REV5=1`, which only the R5 builds set.

| # | Change | Main code |
|---|---|---|
| B1 | When the prelude's `check()` finds every pair exact, it sends `CHECKED:<name>` via the existing action channel (like `submit`). After retention is updated, the host re-runs the existing clean `_verify_submission(name)` and keeps the verdict in `arc2_checked`. A short note goes back to the model. Dedupe: (name, sha of all retained sources). Cap: 24 verifications per branch. **No auto-stop** (EVAL30 247ef758: the first exact version was test-wrong, a later one correct). Explicit `submit()` keeps today's end | `_HELPERS_SRC_R5`, `_handle_action`, `_arc2_harvest_checks` |
| B2 | `select_attempts_r5`: per branch, its latest accepted submission, else its latest accepted check; grouped by output; then other accepted, then partial, then the test input. attempt_2 = the next distinct grid | `select_attempts_r5`, `build_submission` |
| B3 | Assistant reasoning (≥ 2,000 chars) is counted with the served model's `tokenizer.json` in `_estimate_request_input_tokens`; `_calibrate_from_usage` removes the reasoning from the ratio measurement | `reasoning_tokens`, two overrides |
| B4 | Resume text without the false "tool results still valid". After a trim, the kept resume opener says older messages were removed | `ARC2_RESUME_R5/TRIMMED`, `_trim_messages_for_context` |
| B5 | Output per request 60,000 → **49,152** (input budget 81,408) | builder |
| B6 | On `finish_reason=length`, tool-call arguments are made invalid, so Duck's own cut-off path drops them. **Harness finding:** with the 2,048-token yield, Duck's "cut off" note is never sent (the turn yields first), so the next resume opener says it | `_chat_completion`, `ARC2_RESUME_CUT` |
| B7/B8 | Four exact-text prompt edits: code-first, a lookup is valid, compare test outputs when rules disagree, "check early" instead of "Investigate until your code has a clear plan", `train` usage example. No reasoning template | `_R5_EDITS` |
| B9(a) | Temperature 0.7 → **1.0** (Qwen3.8 model card, thinking mode) | `duck_env`, builder |
| — | Report: `checked_verified`, `checked_kept`, `rev5_events` per branch; `harvested_programs(_correct)` per query | CELL 7 |

**Not taken:**
- Presence / repetition penalty: SGLang 0.5.21 DFlash never accumulates penalty tokens (EAGLE does, `eagle_utils.py:1056-1058`), so it would need an SGLang patch; there is also a language-mixing risk.
- Streaming loop-abort (big change).
- Coverage routing (needs this run's metrics).
- Judges / ensembles.

**Unchanged:**
- Window 131,072, 6 live = 6 streams (6 x 131k = 786k ≤ KV 866,744).
- 100k soft per-branch cap, request timeout 1,800 s.
- Engine and serving flags.
- Sandbox, the same tasks.

## Notebooks (`notebook/`)

| File | sha256 | Profile |
|---|---|---|
| `Q27-XHIGH-E12_DUCK_REPL_SGLANG_EVAL6R5.ipynb` | `e1887ac16a46f17fead9293bd27fa6c5e7f2958bdf642ab1d8ccfd09e417a474` | the 6 rev 4 tasks; 90 min solving, 125 min budget |
| `Q27-XHIGH-E12_DUCK_REPL_SGLANG_EVAL30R5.ipynb` | `70aff0195fd80adf6d5db5d24029a9a61cb00fdaa2798ee23fddaf5ffbc1e04a` | the same 30 seed tasks as EVAL30; 330 min solving, 6 h budget |

In an R5 build the rev 5 knobs also apply to the hidden rerun profile. Coverage for 240 tasks is **not** solved: about 10.4 min/task means about 66 tasks in 11 h. These notebooks are for measurement.

## Local evidence (`tests/`)

**Unit checks, real Duck sandbox, no server (`tests/unit/smoke_rev5.py` → `smoke_rev5.txt`): 40/40.**
- B1:
  - exact → kept, branch not stopped;
  - duplicate → not re-verified;
  - changed source;
  - `verbose=False`;
  - non-exact → nothing kept;
  - exact but not retained → rejected with a reason;
  - forged `CHECKED:` for a wrong function → host rejects;
  - cap;
  - check + submit verified once.
- B2: distinct / latest-first / dedupe / partial / fallback / invalid grid never selected.
- B3: the recorded 60,000-token reply of EVAL6 62593bfd_b1 at budget 70,560 and ratio 1.40. The old estimate is over budget, so the reply is dropped (the bug is reproduced); the rev 5 estimate is within, so it is kept. Calibration stays at the grid ratio.
- B4: trimmed / untrimmed.
- B6: arguments invalid, a normal call untouched, the next resume says "cut" once, trimmed + cut.
- B9: env.

**Regression with rev 5 off:** the old adapter checks `smoke_adapter.py` → 41/41 (`smoke_rev5_flagoff.txt`).

**Notebook harness** (`tests/harness/harness_e12_rev4_nb.py` + `fake_sgl_duck_server.py`: the real notebook cells against a fake SGLang):

| Notebook / scenario | Result | What it covers |
|---|---|---|
| EVAL6R5 / `r5` | 30/30 | see below |
| EVAL6R5 / `rerun` | 21/21 | hidden mode with rev 5 |
| EVAL6R5 / `launchfail` | 6/6 | engine fails → fallback submission |
| rebuilt rev 4 EVAL6 / `eval6` | 25/25 | regression |
| SMOKE1_REV4 / `smoke` | 22/22 | regression |

The `r5` scenario, in the fake server:
- **branch 0** checks the right function but never submits;
- **branch 1** is first cut at the output limit with a tool call, then checks a train-exact / test-wrong function, and never submits.

Its checks:
- knobs;
- every request has max_tokens 49,152 and temperature 1.0;
- the rev 5 prompt;
- ≤ 6 in flight;
- 0 submissions, yet every branch keeps ≥ 1 verified candidate;
- the cut call never ran and the model was told;
- the rev 5 resume text;
- **every query is hit, with one right and one wrong candidate per task**;
- harvested counts appear in the report.

**End-to-end replay** (`tests/replay/replay_rev5.py`): all recorded tool calls of both branches of every task go through the real rev 5 agent and sandbox (the hook harvests by itself), then `build_submission`. Results:
- **EVAL6: 5/6 tasks, 7/8 inputs** (recorded run: 3/6, 4/8);
- **EVAL30: unchanged, 4 tasks, 7/48** (branch 1 never ran there).

This is a retrospective replay of recorded code, not a model run. The truth is used only for scoring. `replay_real_sandbox.py` is the earlier per-branch version.

**Not provable locally:**
- real 49k generations;
- the effect of temperature 1.0;
- real KV / speed;
- whether the prompt edits change behaviour.

## Pre-run capacity check

| Run | Branches | KV | Tokens | Time / quota |
|---|---|---|---|---|
| EVAL6R5 | 12; 6 live / 6 streams | 6 x 131,072 = 786k ≤ 866,744 | soft cap ~100-150k per branch → ≤ ~1.8M; 90 min x 368 tok/s ≈ 1.99M | 125 min → about 4.2 h of quota |
| EVAL30R5 | 60; 6 live | same | ~6-9M; 330 min x 368 tok/s ≈ 7.3M; later tasks may get less exposure (report it) | 6 h → about 12 h of quota |

hosen42 has about 29 h of quota left.

## Questions

1. **B1 hook.** Can `CHECKED:` be abused, or break the action channel / stale-state logic (`python_tool_sandbox.py:489-570`)? Is verifying after `_record_retained_functions` always the right order? Is the cost bounded (24 x ≤ 60 s)?
2. **B3.** Is overriding `_estimate_request_input_tokens` / `_calibrate_from_usage` consistent with every Duck caller (trim, persistent history, overflow recovery)? Is there an under-count risk past the server context (155,648)?
3. **B4/B6.** Is rewriting the resume opener inside `_trim_messages_for_context` safe for Duck's control-message handling and prefix caching? Are the B6 invalid arguments guaranteed never to reach history (`tool_agent.py:6862-6887`)?
4. **B2.** Can the selection put an invalid or wrong-shaped grid in the submission, or lose an accepted submission?
5. **Old behaviour.** Does anything change with `E12_ARC2_REV5` unset?
