# E12 rev 6c: implementation audit bundle (2026-10-21)

**Stack:** E12 Duck REPL agent for ARC-AGI-2 on Qwen3.8-27B RedHat INT4 with a BF16 DFlash2 drafter, SGLang 0.5.21, Kaggle 4×L4, 12 h, 240 hidden tasks.

**What changed since 6b (your previous bundle):** the user approved four things. Only the items marked "built" were built:
- gate 4b — built;
- 12 streams — built;
- target-only parity — built;
- "the rest", meaning the p90 cutoff and the engine settings — the p90 cutoff is built as an off-by-default knob; the engine settings are unchanged, with the numbers below.

Nothing has run on GPU and nothing is pushed.

## Notebooks (`notebook/`)

All three are dual mode. In a competition rerun every hidden task is solved with the normal rev 6 settings; the gate-4b window and the parity mode apply to commit mode only.

| File | sha256 | Commit-mode purpose |
|---|---|---|
| `…_EVAL12R6.ipynb` | `7d69e502…` | The 12 EVAL12R5 tasks, 150 min of solving, **12 workers** (was 10 in `fe51d1d4`) |
| `…_EVAL12R6G4B.ipynb` | `f70c3228…` | **Gate 4b:** the same 12 tasks with the hidden run's compute per task. Solve window = 12 × (42,720 s hidden solve end − this run's measured solve start) / 240 ≈ 175 s per task ≈ 35 min |
| `…_PARITYR6.ipynb` | `f3876b40…` | **R6-X1 target-only parity:** 4 tasks, no solving. 8 probes (rev 6 system prompt + first opener, with tools, T 0, batch size 1, 2,048 tokens, thinking on and off): 2 rounds on DFlash2 (the control), then a relaunch from the same command without the 4 `--speculative-*` flags. Compared on equality, common prefix, tool-call presence and arguments, finish and tokens |

## Decisions made in 6c

These are the points to check.

1. **KV share for 12 streams = 1.0 × KV / 12 = 73,444 per stream.**
   - The history budget is 48.4k at the 24,576 cap and 60.6k at 12,288.
   - At 0.9, as in your review Q-1, the window would be 66.1k, which leaves 41.0k of history at the 24,576 cap. That is below rev 5's median prompts of 41.6–51.9k, so trims would be frequent.
   - Evidence for 1.0: D66 ran 12 slots at context 155,648 with a KV peak of 90 % and 0 preemptions.
   - The server-queue probe still steps 12 → 10 → 8 → 6.
   - **Is 1.0 acceptable, or should it be 0.9 with the trim cost?**
2. **Stage-2 p90 cutoff: built, tested, off by default.**
   - Every request and verification is already clamped to the deadline.
   - A 24,576-token fair-share chunk at about 25–30 tok/s per stream takes about 14–16 min, so a p90 cutoff would idle up to 12 workers for the last ~15 min.
   - Stage 1 is always exempt.
3. **Engine unchanged.**
   - Mamba cache 56: this engine needs 4 slots per request, so 12 streams need 48.
   - The CUDA-graph list 1–8, 10, 12: batches of 9 and 11 pad up, which is normal SGLang behaviour.
   - The real running maximum and acceptance length are in the report for GPU verification.
4. **Gate 4b is a time share, not a token cap.** The scheduler, request caps and fair share behave as in the hidden run, and the tokens per task come from the measured throughput.
   - One difference from the hidden run: only 12 tasks queue, so stage 2 starts earlier than with 240.

## Source (`source/`)

- `arc2_duck.rev6b_to_rev6c.diff` (64 lines): the p90 knob in `solve_all_r6`.
- `build_e12_duck.rev6b_to_rev6c.diff` (235 lines): the new profiles, 12 workers, KV share 1.0, gate-4b window, parity diagnostic and header text.
- Also included: the earlier diffs (rev 6a→6b, rev 5→6c) and the full source files.

## Tests (`tests/`)

- `smoke_rev6_out.txt`: **93/93**, including the p90 cutoff and that it is off by default.
- `smoke_rev5_out.txt` 56/56; `smoke_adapter_out.txt` 41/41.
- **Notebook harness** (real cells, fake SGLang):
  - EVAL12R6 `h11_EVAL12R6_r6.txt`: **43/43**. 12 workers, window 73,444, 12 isolation markers, ≤ 12 in flight, p90 off, no g4b window.
  - EVAL12R6 rerun 22/22; launchfail 6/6.
  - **EVAL12R6G4B g4b 44/44:** the window formula and the deadline (the smaller of the two windows).
  - **PARITYR6 parity 19/19:**
    - the spec flags are removed and the relaunch is ready;
    - the control is identical 8/8;
    - the fake target-only server differs on purpose on one task, and the comparison finds it (6/8 identical);
    - tool calls and finish agree 8/8;
    - the target-only log is bundled.
- The 6b regression replays (`replay_rev6b_*.jsonl`) still apply: 6c does not change the agent.

## Questions

1. **KV share 1.0 at 12 streams** (decision 1): acceptable?
2. **Parity:** is the probe design enough to detect #38009-type divergence? (T 0, batch size 1, first 2,048 tokens, thinking on/off, judged on what Duck acts on.) Should any probe be longer?
3. **Gate 4b:** is the time-share definition right for predicting LB/eval? Is the "12 tasks start stage 2 earlier" difference a problem?
4. **GPU readiness:** anything blocking a GO for EVAL12R6 + EVAL12R6G4B + PARITYR6?
