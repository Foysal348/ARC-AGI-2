"""Rev 6 unit checks for arc2_duck (E12_ARC2_REV6=1), real Duck sandbox, no server. Our own scripted code only.
Covers the fix-list traps T1-T8 and items R6-V/P/K/S/Q/D (fix list 'Rev 6 gap check' + the two plan reviews)."""
import json
import os
import re
import sys
import threading
import time
from pathlib import Path

os.environ["E12_ARC2_REV6"] = "1"
os.environ["E12_DUCK_TEMPERATURE"] = "1.0"
os.environ["E12_CHECK_VERIFY_CAP"] = "6"
os.environ["E12_AUTOCHECK_CAP"] = "3"
os.environ["E12_DUCK_CONTEXT_WINDOW"] = "78000"
TOK = Path(r"D:/ARC AGI 2/_scratch/session_1c6db7aa/e12_harness/fixtures/tok_int4/tokenizer.json")
os.environ["E12_TOKENIZER_JSON"] = str(TOK)
_HERE = Path(__file__).resolve().parent
src = open(_HERE / "smoke_adapter.py", encoding="utf-8").read().split("# 1 system prompt carries the task")[0]
exec(src)                      # A, TA, DP, Agent, task (row flip), ag, run, expect, flip, tmp, state

# ------------------------------------------------------------------ R6-V2 facts (deterministic, shape-aware)
shape_task = {"train": [{"input": [[1, 1], [1, 2]], "output": [[1, 2, 3]]},
                        {"input": [[0, 3, 3], [0, 0, 0]], "output": [[0, 3, 3], [0, 0, 5]]}],
              "test": [{"input": [[2, 2], [0, 2]]}, {"input": [[7]]}, {"input": [[1, 0, 1]]}]}
f1 = A.arc2_facts(shape_task)
expect("facts: deterministic", f1 == A.arc2_facts(json.loads(json.dumps(shape_task))))
expect("facts: shape change -> no cellwise diff", "shape changed 2x2 -> 1x3" in f1 and "TRAIN 0" in f1, f1[:600])
expect("facts: same-shape pair -> changed cells + transitions", "changed cells 1" in f1 and "(0, 5, 1)" in f1, f1)
expect("facts: every test input covered (3)", all(f"TEST {j}" in f1 for j in range(3)))
expect("facts: 'modal', never 'background'", "modal" in f1 and "background" not in f1.lower())
os.environ["E12_R6_FACTS_MAX_CHARS"] = "200"
fb = A.arc2_facts_bounded(shape_task)
expect("facts: over the bound -> lists dropped with an explicit notice", "largest (color" not in fb and "omitted for size" in fb)
os.environ.pop("E12_R6_FACTS_MAX_CHARS")

# ------------------------------------------------------------------ R6-V1/P1 prompt
sp = ag._system_prompt
expect("V1: facts view has no raw grid rows", "Training pair 0 input:" not in sp and "ARC TASK FACTS" in sp)
gp = A.arc2_system_prompt_r6(task, DP, 3072, view="grids")
expect("V1 hedge: grids view shows the rows + facts", "Training pair 0 input:" in gp and "ARC TASK FACTS" in gp)
expect("P1: helpers + check_many + auto-check + submit-ends-branch described",
       all(s in sp for s in ("components(g", "check_many", "checks it automatically", "ends this branch", "crop(g, r0, c0, r1, c1)")))
bad = [w for w in (r"current_frame", r"action\(actions\)", r"\bgame\b", r"segmentation", r"Investigate first")
       if re.search(w, sp)]
expect("P1: no game words", not bad, bad)
expect("P1: rigid V3.1 stage text absent", "By your second Python execution" not in sp)

# ------------------------------------------------------------------ R6-V3 / T1 helpers usable inside transform
r, p = run("def transform(g):\n    return flip_h(crop(g, 0, 0, len(g) - 1, len(g[0]) - 1))\ncheck(transform)")
expect("T1: helper-using transform is retained", "transform" in (ag._kept_functions or {}), (ag._kept_functions, r.content[-600:]))
expect("T1: ... and host-verified as a candidate", len(ag.arc2_checked) == 1 and ag.arc2_checked[0]["accepted"], ag.arc2_checked)
expect("T1: trusted helpers stay hidden from the model's retained list",
       not (set(ag._kept_functions) & A.R6_HELPER_NAMES), sorted(ag._kept_functions))
r, p = run("print(grid_shape(train[0]['input']), len(components(train[0]['input'])))")
expect("T1: helpers available in later calls", "(2, 3)" in r.content, r.content[-300:])
r, p = run("def leak(g):\n    return [list(reversed(x)) for x in g] if g != train[0]['input'] else train[0]['output']\ncheck(leak)")
expect("T1: a function that reads `train` is still rejected", not any(v["name"] == "leak" and v["accepted"] for v in ag.arc2_checked),
       r.content[-500:])

# helpers correctness (trusted source executed on the host)
ns = {}
for s in A.R6_HELPER_SOURCES:
    exec(s, ns)
g8 = [[1, 0], [0, 1]]
expect("components: 4-conn splits a diagonal, 8-conn joins it",
       len(ns["components"](g8, color=1)) == 2 and len(ns["components"](g8, color=1, connectivity=8)) == 1)
expect("crop inclusive in bbox order", ns["crop"]([[1, 2, 3], [4, 5, 6]], 0, 1, 1, 2) == [[2, 3], [5, 6]])
expect("diff_summary: different shapes -> no invented diff", ns["diff_summary"]([[1]], [[1, 2]])["changed_cells"] is None
       and ns["diff_summary"]([[1]], [[1]])["changed_cells"] == 0 and ns["diff_summary"]([[1]], [[2]])["changed_cells"] == 1)
expect("rot90 clockwise", ns["rot90"]([[1, 2], [3, 4]]) == [[3, 1], [4, 2]])
expect("modal_color tie -> smallest", ns["modal_color"]([[3, 1], [1, 3]]) == 1)

# ------------------------------------------------------------------ R6-K2 check output + progress
r, p = run("def ident(g):\n    return g\ncheck(ident)")
expect("K2: verdict line first + identity flag + test inputs status",
       re.search(r"check\(ident\): 0/2 train pairs exact; returns the input unchanged on pair\(s\) \[0, 1\]; test inputs: ok, ok",
                 r.content) is not None, r.content[-500:])
r, p = run("def boom(g):\n    x = 1\n    return g[99]\ncheck(boom)")
expect("K2: an error names the function and its line", "(in boom, line 3)" in r.content, r.content[-500:])
expect("S4: progress recorded per single function", ag.arc2_progress["runs"] >= 3
       and ag.arc2_rev6_events["first_check_tokens"] is not None, ag.arc2_progress)
best = ag.arc2_progress["best"]
expect("S4: best = the exact transform (identity scores 0 changed-cell accuracy)", best["name"] == "transform" and best["k"] == 2, best)

# ------------------------------------------------------------------ R6-K1 auto-check
n0 = len(ag.arc2_checked)
r, p = run("def transform2(g):\n    return [row[::-1] for row in g]")
expect("K1: transform2 defined without check -> auto-checked + harvested",
       "checked `transform2` automatically" in r.content and len(ag.arc2_checked) == n0 + 1, r.content[-600:])
expect("K3: same outputs as a saved candidate -> noted, no new distinct candidate",
       ag.arc2_checked[-1].get("dup_of") == "transform" and "equal the saved" in r.content, (ag.arc2_checked[-1], r.content[-400:]))
r, p = run("print(1)")
expect("K1: unchanged source -> no second auto-check", "automatically" not in r.content)
r, p = run("def rotate(g):\n    return [list(x) for x in zip(*g)]")
expect("K1: helper-like name (rotate) not auto-checked", "automatically" not in r.content)
r, p = run("def solve_two(g, k):\n    return g")
expect("K1: two required args -> not auto-checked", "automatically" not in r.content)
r, p = run("def transform_alt(g):\n    return [list(reversed(x)) for x in g] if len(g) > 1 else [[9] * len(g[0])]")
expect("K1: transform_alt auto-checked; distinct test outputs -> a second distinct candidate",
       "`transform_alt`" in r.content and ag.arc2_checked[-1]["accepted"] and "dup_of" not in ag.arc2_checked[-1]
       and len(ag._arc2_accepted_sigs) == 2, (ag.arc2_checked[-1], r.content[-500:]))
r, p = run("def transform2(g):\n    return [row[::-1] for row in g]\ncheck(transform2)")
expect("K3: re-check of an unchanged closure -> trusted verdict reused (no new verify)",
       ag.arc2_rev5_events["checks_skipped_dup"] >= 1 and len([v for v in ag.arc2_checked if v["name"] == "transform2"]) == 1)
r, p = run("def unrelated(x):\n    return x + 1\nprint(2)")
r, p = run("check(transform2)")
expect("K3: a new unrelated function does not change transform2's key", len([v for v in ag.arc2_checked if v["name"] == "transform2"]) == 1)
# auto cap = 3: transform2, transform_alt used 2; one more auto, then exhausted; explicit check still verifies
r, p = run("def transform_v2(g):\n    return [list(reversed(x)) for x in g]\n")
r, p = run("def transform_v3(g):\n    out = [list(reversed(x)) for x in g]\n    return out")
expect("K3: auto cap reached -> neutral note (no 'submit your best')", "limit of 3 automatic" in r.content
       and "submit your best" not in r.content, r.content[-500:])
r, p = run("check(transform_v3)")
expect("K3: explicit check still verifies after the auto cap", any(v["name"] == "transform_v3" for v in ag.arc2_checked),
       r.content[-400:])

# ------------------------------------------------------------------ R6-V4 grid print guard
r, p = run("for row in [[1, 2, 3, 4, 5]] * 12:\n    print(*row)")
expect("V4: a long grid print is collapsed with the note", "more grid rows not shown" in r.content
       and ag.arc2_rev6_events["grid_rows_suppressed"] >= 10, r.content[-400:])
r, p = run("print([[0] * 30 for _ in range(30)])")
expect("V4: one long nested-list line is cut", "(nested list)" in r.content, r.content[-300:])
_t0 = time.monotonic()
_g, _d = A.guard_grid_prints(("[" + ", ".join(["0"] * 100) + "], [1\n") * 3)
expect("V4: a near-row line (old pattern backtracked exponentially) is classified in linear time",
       time.monotonic() - _t0 < 1.0 and _d == 0, round(time.monotonic() - _t0, 3))
r, p = run("show(train[0]['input'])")
expect("V4: show() small crop allowed with indices", "r00 | 1 2 3" in r.content, r.content[-300:])
r, p = run("show([[0] * 30 for _ in range(30)])")
expect("V4: show() over the limit refused", "the limit is 150" in r.content, r.content[-300:])

# ------------------------------------------------------------------ R6-P2 resumes
ag2 = Agent(task=task, task_id="flip", branch=1, view="grids", model="qwen", base_url="http://127.0.0.1:9/v1", provider="vllm")
op = lambda a: a._build_user_prompt(1, valid_actions=[])
expect("P2: first opener", op(ag2).startswith(A.R6_TEXT["first"]))
ag2._resume_after_yield, ag2._resume_reason = True, "yield_bare"
expect("P2: no tool, no evidence -> notool", op(ag2).startswith(A.R6_TEXT["notool"]))
ag2._arc2_length_pending = True
expect("P2: length cut without a call", op(ag2).startswith(A.R6_TEXT["length"][:40]))
ag2._arc2_cut_pending = True; ag2._arc2_length_pending = True
expect("P2: cut call has precedence", op(ag2).startswith(A.R6_TEXT["cut"][:40]))
ag2._resume_reason = "timeout"
expect("P2: timeout", op(ag2).startswith(A.R6_TEXT["timeout"][:40]))
ag2._resume_reason = "yield_tools"
expect("P2: tools ran, no evidence -> neutral continue", op(ag2).startswith(A.R6_TEXT["continue"]))
ag2.arc2_progress["best"] = {"name": "t1", "k": 1, "n": 2, "acc": 0.5}
expect("P2: partial progress", "`t1`, is exact on 1 of 2" in op(ag2))
ag._resume_after_yield, ag._resume_reason = True, "yield_tools"
expect("P2: verified candidate beats partial", "is host-verified" in op(ag), op(ag))
ag2._resume_after_yield = False
ag2.arc2_submissions.append({"name": "t1", "accepted": False, "summary": "wrong on training pair 1."})
expect("P2: a new turn after a rejected submit names the rejection (not the first-turn text)",
       op(ag2).startswith("Your submission `t1` was not accepted: wrong on training pair 1. Continue"), op(ag2))
ag2.arc2_submissions.pop()
msgs = [{"role": "system", "content": "s"}, {"role": "user", "content": "a" + A.R6_COMPLETE},
        {"role": "assistant", "content": "x"}, {"role": "user", "content": "b" + A.R6_COMPLETE}]
out = ag2._arc2_rewrite_resume(msgs + [{"role": "assistant", "content": "y"}], msgs)
expect("P2/T2: trim rewrites only the newest opener", out[3]["content"].startswith("b") and A.R6_TRIMMED in out[3]["content"]
       and A.R6_COMPLETE in out[1]["content"])
expect("T2: facts stay in the (never trimmed) system prompt", "ARC TASK FACTS" in ag2._system_prompt)
msgs = []
ag2._append_context_message(msgs, {TA._CONTROL_MESSAGE_KEY: "nudge", "role": "user",
                                   "content": "You have not acted yet. Investigate first. Then investigate and revise ..."})
expect("T6: Duck's 'Investigate first' nudge replaced", msgs and "Investigate first" not in msgs[-1]["content"]
       and msgs[-1]["content"].startswith(A.R6_TEXT["notool"]), msgs)

# ------------------------------------------------------------------ R6-Q1 / R6-D1 dynamic caps
ag3 = Agent(task=task, task_id="flip", branch=0, model="qwen", base_url="http://127.0.0.1:9/v1", provider="vllm")
c = ag3._arc2_apply_cap()
expect("Q1: 12,288 before the first successful tool call; D1 reserve and budget follow",
       c == 12288 and ag3._reply_reserve_tokens == 12288 and ag3._context_budget_tokens == 78000 - 12288 - 512,
       (c, ag3._reply_reserve_tokens, ag3._context_budget_tokens))
ag3._arc2_tool_ok = True
expect("Q1: 24,576 after tool progress", ag3._arc2_apply_cap() == 24576 and ag3._context_budget_tokens == 78000 - 24576 - 512)
ag3._arc2_nocall_cuts = 2
expect("Q1: 32,768 rescue after two no-call cuts", ag3._arc2_apply_cap() == 32768 and ag3._max_output_tokens == 32768)

# ------------------------------------------------------------------ R6-S6 / T8 deadline clamps
seen = {}
_orig = TA.ToolAgent._chat_completion


class _R:
    finish_reason, message, usage = "stop", {"role": "assistant", "content": "ok", "tool_calls": []}, {}


def _fake(self, messages, **kw):
    seen.update(kw)
    return _R()
TA.ToolAgent._chat_completion = _fake
try:
    ag3._arc2_deadline = time.monotonic() + 10
    ag3._chat_completion([{"role": "user", "content": "x"}], tools=None, request_timeout_seconds=1800)
    expect("T8: a request's read timeout is clamped to the deadline", seen["request_timeout_seconds"] <= 10.0, seen)
    ag3._arc2_deadline = time.monotonic() - 1
    ag3._chat_completion([{"role": "user", "content": "x"}], tools=None, request_timeout_seconds=1800)
    expect("T8: past the deadline -> minimal timeout", seen["request_timeout_seconds"] == 0.5, seen)
finally:
    TA.ToolAgent._chat_completion = _orig
ag._arc2_deadline = time.monotonic() - 1
v = ag._verify_submission("transform")
expect("S6: no verification after the deadline", v.get("skipped") and not v["accepted"], v)
ag._arc2_deadline = None

# ------------------------------------------------------------------ R6-S1..S5 scheduler simulation (fake agents)
class FakeResult:
    retryable_failure, yielded_control, step_executed = False, True, False


class FakeAgent:
    """Emulates Duck's analyze(): one request per call (yield after 2,048 tokens), should_stop checked before it."""
    log = []
    lock = threading.Lock()

    def __init__(self, *, task, task_id, branch, view, **kw):
        self.task_id, self.branch, self.view = task_id, branch, view
        self.generated_tokens = self.total_tokens = 0
        self.arc2_accepted, self.arc2_submissions, self.arc2_usage, self.arc2_checked = None, [], [], []
        self.arc2_rev5_events, self.arc2_rev6_events = {}, {}
        self.arc2_progress = {"best": None, "first_check_tokens": None, "runs": 0}
        self._arc2_deadline = None
        h = sum(map(ord, task_id))
        self.solve_at = None if h % 3 == 0 else (8000 + (h % 5) * 9000)     # some tasks never solve
        self.oid = id(self)

    def analyze(self, state_path, n, *, should_stop, **kw):
        if should_stop():
            return FakeResult()
        with FakeAgent.lock:
            FakeAgent.log.append((time.monotonic(), self.task_id, self.branch, self.generated_tokens))
        time.sleep(0.002)
        self.generated_tokens += 4000
        self.total_tokens = self.generated_tokens
        if self.solve_at and self.generated_tokens >= self.solve_at and not self.arc2_checked:
            self.arc2_checked.append({"name": "transform", "accepted": True, "test_outputs": [[[self.branch]]], "t": time.time()})
        return FakeResult()


tasks240 = {f"t{i:03d}": {"train": [], "test": [{"input": [[0]]}]} for i in range(240)}
order = sorted(tasks240, key=lambda t: (sum(map(ord, t)) % 7, t))          # stand-in for ORDER2
os.environ["ARC3_MAX_ACTIVE_STREAMS"] = "10"
done = []
t_start = time.monotonic()
recs = A.solve_all_r6(tasks240, order, out_dir=tmp / "sched", deadline=time.monotonic() + 120, base_url="x", model_id="m",
                      branches=2, max_generated_tokens=100000, workers=10, first_exposure_tokens=28000,
                      on_branch_done=done.append, agent_cls=FakeAgent, min_admit_sec=1)
first_req = {}
for t, tid, b, tok in FakeAgent.log:
    first_req.setdefault((tid, b), t)
b0_starts = sorted((first_req[(t, 0)], t) for t in order)
stage2 = [first_req[k] for k in first_req if k[1] == 1]
expect("S1: every one of 240 tasks got branch 0", all((t, 0) in first_req for t in order))
rank = {t: i for i, (_, t) in enumerate(b0_starts)}
expect("S1: branch-0 admission follows the given order (ORDER2, within the 10 concurrent workers)",
       max(abs(rank[t] - i) for i, t in enumerate(order)) < 20, max(abs(rank[t] - i) for i, t in enumerate(order)))
expect("S1: no stage-2 work before the last task's first exposure starts", min(stage2) >= max(x for x, _ in b0_starts) - 0.05,
       (min(stage2), max(x for x, _ in b0_starts)))
r0 = [x for x in recs[order[0]] if x["branch"] == 0][0]
expect("Q2: branch 0 paused at the first-exposure budget, then resumed (2 runs)",
       len(r0["runs"]) >= 1 and r0["runs"][0]["status"] in ("paused", "done"), r0["runs"])
paused_then = [t for t in order if any(x["branch"] == 0 and len(x.get("runs", [])) >= 2 for x in recs[t])]
expect("Q2: resumed branches keep their agent (tokens continue past the pause)",
       paused_then and all(max(x["generated_tokens"] for x in recs[t] if x["branch"] == 0) > 28000 for t in paused_then[:20]),
       len(paused_then))
solved_b0 = [t for t in order if any(x["branch"] == 0 and any(c["accepted"] for c in x.get("checked") or []) for x in recs[t])]
expect("S2: tasks with one candidate still get branch 1 (about 1/3 of accepts are test-wrong)",
       any(any(x["branch"] == 1 for x in recs[t]) for t in solved_b0))
expect("S: every record published per (task, branch), replaced not appended", all(len({x["branch"] for x in recs[t]}) == len(recs[t])
                                                                                  for t in order))
print("scheduler sim:", round(time.monotonic() - t_start, 1), "s,", len(FakeAgent.log), "fake requests,",
      sum(len(v) for v in recs.values()), "branch records")

# deadline: a short run must stop admitting and return promptly
FakeAgent.log = []
t0 = time.monotonic()
recs2 = A.solve_all_r6(tasks240, order, out_dir=tmp / "sched2", deadline=time.monotonic() + 3, base_url="x", model_id="m",
                       branches=2, max_generated_tokens=100000, workers=10, first_exposure_tokens=28000,
                       agent_cls=FakeAgent, min_admit_sec=1)
expect("S6: returns shortly after the deadline", time.monotonic() - t0 < 3 + 2.5, round(time.monotonic() - t0, 2))
expect("S6: no request after the deadline", max(t for t, *_ in FakeAgent.log) <= t0 + 3.05)

# capacity fallback: a probe that always reports a server queue lowers the workers 10 -> 8 -> 6 (and never below)
import arc2_duck as _A2
calls = []
_sleep = _A2.time.sleep
orig_sleep = time.sleep


class _FastTime:
    def __getattr__(self, k):
        return getattr(time, k)

    @staticmethod
    def sleep(s):
        orig_sleep(0.01 if s >= 60 else s)
_A2.time = _FastTime()
try:
    recs3 = A.solve_all_r6(tasks240, order[:40], out_dir=tmp / "sched3", deadline=time.monotonic() + 4, base_url="x",
                           model_id="m", branches=1, max_generated_tokens=400000, workers=10, first_exposure_tokens=None,
                           agent_cls=FakeAgent, min_admit_sec=1, capacity_probe=lambda: {"queue": 3}, min_workers=6)
finally:
    _A2.time = time
ev = A.SCHED_LAST.get("events")
expect("S5: queued server -> controlled fallback 10 -> 8 -> 6, never below", ev and ev[0]["allowed"] == 8
       and A.SCHED_LAST["allowed"] == 6, A.SCHED_LAST)

# ================================================================== rev 6b (gap check against the problem -> fix map)
def fresh(t, tid="x", b=0):
    st = Path(tempfile.mkdtemp(prefix="r6b_", dir=str(tmp))) / TA.RUNTIME_STATE_FILENAME
    write_runtime_state(st, current_frame=None, history=[])
    a = Agent(task=t, task_id=tid, branch=b, model="qwen", base_url="http://127.0.0.1:9/v1", provider="vllm")
    return a, (lambda code: a._run_python_tool(st, {"code": code}))


import tempfile  # noqa: E402

# R6-V2 / Q-5: token-bounded facts (both plan reviews: 600-800 Qwen tokens first)
EV = json.load(open(r"D:/ARC AGI 2/_scratch/session_1c6db7aa/e12_harness/fixtures/data/arc-agi_evaluation_challenges.json",
                    encoding="utf-8"))
f_full, f_b = A.arc2_facts(EV["135a2760"]), A.arc2_facts_bounded(EV["135a2760"])
expect("Q-5: a block over 800 tokens is reduced to <= 800 with an explicit omission note",
       A.reasoning_tokens(f_full) > 800 and A.reasoning_tokens(f_b) <= 800 and "omitted for size" in f_b,
       (A.reasoning_tokens(f_full), A.reasoning_tokens(f_b)))
f3 = A.arc2_facts(EV["d8e07eb2"], level=3)
expect("Q-5: the smallest level keeps the core facts (shape, colors, changed cells) and says what is omitted",
       "components:" not in f3 and "colors" in f3 and "TRAIN 0" in f3 and "all component facts omitted" in f3)

# R6-V3: object-level diff
o = ns_obj = {}
for s_ in A.R6_HELPER_SOURCES:
    exec(s_, ns_obj)
od = ns_obj["object_diff"]([[0, 0, 0, 0, 0], [0, 1, 1, 0, 0], [0, 0, 0, 0, 2], [3, 0, 0, 0, 0]],
                           [[0, 0, 0, 0, 0], [0, 0, 0, 1, 1], [0, 0, 0, 0, 5], [0, 0, 0, 0, 0]])
expect("V3: object_diff finds moved (with offset), recolored and removed objects",
       od["moved"]["examples"][0]["offset"] == (0, 2) and od["recolored"]["examples"][0]["new_color"] == 5
       and od["removed"]["count"] == 1 and od["added"]["count"] == 0, od)
expect("V3: object_diff is listed in the prompt and usable inside transform (trusted helper)",
       "object_diff(a, b)" in ag._system_prompt and "object_diff" in A.R6_HELPER_NAMES)

# M1: label-free overfit flags (never the test truth)
t20 = {"train": [{"input": [[0] * 20 for _ in range(4)], "output": [[0] * 20 for _ in range(4)]}],
       "test": [{"input": [[0] * 7 for _ in range(3)]}]}
fl = A.overfit_flags(t20, "def transform(g):\n    return [[g[r][(c + 10) % len(g[0])] for c in range(len(g[0]))] for r in range(len(g))]",
                     [[[0] * 7 for _ in range(3)]])
expect("M1: overfit signs: fixed offset tied to the train width, test output equal to its input",
       {"fixed_offset", "offset_tied_to_train_dims", "test_output_equals_input"} <= set(fl), fl)
agF, runF = fresh(task, "flipF")
runF("def transform(g):\n    k = 0 + 3 - 3\n    return [list(reversed(r)) for r in g]\ncheck(transform)")
vF = [v for v in agF.arc2_checked if v["accepted"]]
expect("M1/T7: a host-verified candidate carries its overfit signs and source size (scheduler + report)",
       vF and "fixed_offset" in vF[-1].get("overfit_flags", []) and vF[-1].get("source_chars", 0) > 0, vF)
runF("def transform(g):\n    return [list(reversed(r)) for r in g]\ncheck(transform)")
e6 = agF.arc2_rev6_events
expect("M1: per-branch events: tool calls, redefinitions, facts size and level",
       e6["tool_calls"] == 2 and e6["redefinitions"] == 1 and e6["facts_tokens"] > 0 and e6["facts_level"] is not None, e6)
sh = A.reasoning_shares("I count: 0 1 2 3 4\n[1, 2, 3, 4]\nthe same long sentence here\nthe same long sentence here")
expect("M1: hand-reading and loop proxies per reply", sh["grid"] > 0 and sh["repeat"] == len("the same long sentence here"), sh)

# R6-K2: harness limits are labelled as such
agF._python_timeout = 2
rT = runF("while True:\n    pass")
expect("K2: a sandbox time limit is labelled a harness limit (not a verdict on the rule)",
       "[harness limit" in rT.content and agF.arc2_rev6_events["infra_errors"] == 1, rT.content[-400:])

# Q-3: a transform using an unavailable global is not retained and never becomes a candidate
agQ, runQ = fresh(task, "flipQ")
rQ = runQ("def transform(g):\n    return missing_helper(g)\n")
expect("Q-3: a transform calling an unavailable global is rejected by retention, no candidate",
       "transform" not in (agQ._kept_functions or {}) and not agQ.arc2_checked, (agQ._kept_functions, rQ.content[-300:]))

# 2 exact pairs + 1 timeout -> rejected (pending since rev 2/3)
t3 = {"train": [{"input": [[1, 2], [3, 4]], "output": [[2, 1], [4, 3]]}, {"input": [[5, 6]], "output": [[6, 5]]},
                {"input": [[1, 1, 1], [2, 2, 2], [3, 3, 3]], "output": [[1, 1, 1], [2, 2, 2], [3, 3, 3]]}],
      "test": [{"input": [[7, 8]]}]}
ag3b, run3b = fresh(t3, "slow")
ag3b._python_timeout = 2
run3b("def transform(g):\n    while len(g) == 3:\n        pass\n    return [list(reversed(r)) for r in g]\n")
v3 = ag3b._verify_submission("transform")
expect("regression: exact on 2 pairs + a timeout on the 3rd -> rejected, timeout recorded",
       not v3["accepted"] and v3["train_exact"][:2] == [True, True] and v3.get("verify_timed_out"), v3)

# R6-D3: reasoning-only blocks are dropped first; blocks stay whole; the newest block stays
H = [{"role": "user", "content": "u1"},
     {"role": "assistant", "content": "", "tool_calls": [{"id": "c1", "type": "function", "function": {"name": "python", "arguments": "{}"}}]},
     {"role": "tool", "tool_call_id": "c1", "content": "r1"},
     {"role": "user", "content": "u2"}, {"role": "assistant", "content": "long reasoning, no call"},
     {"role": "user", "content": "u3"},
     {"role": "assistant", "content": "", "tool_calls": [{"id": "c3", "type": "function", "function": {"name": "python", "arguments": "{}"}}]},
     {"role": "tool", "tool_call_id": "c3", "content": "r3"},
     {"role": "user", "content": "u4"}]


def paired(h):
    for i, m in enumerate(h):
        if m["role"] == "tool" and not any(c.get("id") == m["tool_call_id"] for x in h[:i] if x["role"] == "assistant"
                                           for c in (x.get("tool_calls") or [])):
            return False
    return True


agD, _ = fresh(task, "trim")
h1 = list(H)
agD._drop_oldest_history_block(h1, preserve_recent=1)
expect("D3: the reasoning-only block goes first; the tool-result blocks stay paired",
       [m["content"] for m in h1 if m["role"] == "user"] == ["u1", "u3", "u4"] and paired(h1), h1)
agD._drop_oldest_history_block(h1, preserve_recent=1)
expect("D3: then Duck's oldest-block rule; calls and results still paired; newest block kept",
       [m["content"] for m in h1 if m["role"] == "user"] == ["u3", "u4"] and paired(h1)
       and agD.arc2_rev6_events["trim_reasoning_only_blocks"] == 1, h1)


# R6-S3 fair share: long stage-2 branches pause softly and are re-queued, so more tasks get stage-2 compute
class FakeSlow(FakeAgent):
    def __init__(self, **kw):
        super().__init__(**kw)
        self.solve_at = None

    busy_violations = []

    def analyze(self, state_path, n, *, should_stop, **kw):
        if should_stop():
            return FakeResult()
        if getattr(self, "_busy", False):
            FakeSlow.busy_violations.append((self.task_id, self.branch))
        self._busy = True
        time.sleep(0.05)
        self.generated_tokens += 4000
        self.total_tokens = self.generated_tokens
        self._busy = False
        return FakeResult()


t30 = {f"t{i:03d}": {"train": [], "test": [{"input": [[0]]}]} for i in range(30)}
o30 = sorted(t30)


def fair(flag):
    r = A.solve_all_r6(t30, o30, out_dir=tmp / f"fair{int(flag)}", deadline=time.monotonic() + 7, base_url="x", model_id="m",
                       branches=2, max_generated_tokens=400000, workers=4, first_exposure_tokens=8000, agent_cls=FakeSlow,
                       min_admit_sec=0.5, min_chunk_tokens=8000, fair_share=flag, share_warmup_sec=0.3)
    st2 = {t for t in o30 for x in r[t] for run_ in x.get("runs") or [] if run_.get("stage") == 2}
    return r, st2, dict(A.SCHED_LAST)


rF, st2F, schF = fair(True)
rN, st2N, _ = fair(False)
runsF = [run_ for t in o30 for x in rF[t] for run_ in x.get("runs") or []]
expect("S3: with fair share more tasks get stage-2 compute than without (no starvation by long branches)",
       len(st2F) > len(st2N) and len(st2F) >= 20, (len(st2F), len(st2N)))
expect("S3: stage-2 runs pause softly at their share and resume later (rounds), with the same agent",
       any(len(x.get("runs") or []) >= 3 for t in o30 for x in rF[t]) and schF.get("shares"), schF.get("shares", [])[:5])
expect("S3: a branch is never driven by two workers at once (re-queue skips running sessions)",
       not FakeSlow.busy_violations, FakeSlow.busy_violations[:5])
counts = sorted(sum(r_.get("tokens", 0) for x in rF[t] for r_ in x.get("runs") or [] if r_.get("stage") == 2) for t in o30)
expect("S3: round robin: stage-2 tokens are spread over the tasks (max task <= 4x the median)",
       counts[len(counts) // 2] > 0 and counts[-1] <= 4 * counts[len(counts) // 2], (counts[:3], counts[len(counts) // 2], counts[-3:]))
expect("S3: overshoot past a soft pause is recorded and bounded by one request",
       all(0 <= run_["overshoot"] <= 4000 for run_ in runsF if "overshoot" in run_) and any("overshoot" in run_ for run_ in runsF))


# rev 6c: the user-approved stage-2 p90 cutoff (off by default): stage-2 items are dropped near the deadline, stage 1 never
rP = A.solve_all_r6(t30, o30, out_dir=tmp / "p90", deadline=time.monotonic() + 5, base_url="x", model_id="m", branches=2,
                    max_generated_tokens=400000, workers=4, first_exposure_tokens=8000, agent_cls=FakeSlow, min_admit_sec=0.3,
                    min_chunk_tokens=40000, fair_share=True, share_warmup_sec=0.3, stage2_p90_cutoff=True)
schP = dict(A.SCHED_LAST)
expect("6c p90 cutoff: stage-2 items are skipped near the deadline; every task still got branch 0 (stage 1 exempt)",
       schP.get("p90_skipped", 0) > 0 and schP.get("stage2_p90_cutoff") is True
       and all(any(x["branch"] == 0 and x.get("generated_tokens", 0) > 0 for x in rP[t]) for t in o30), schP.get("p90_skipped"))
expect("6c p90 cutoff off by default (recorded)", A.solve_all_r6.__defaults__ is None
       or A.solve_all_r6.__kwdefaults__.get("stage2_p90_cutoff") is False, A.solve_all_r6.__kwdefaults__)


# T7: inside class 2, tasks whose candidate carries an overfit sign get branch 1 first; the class is recorded
class FakeFlag(FakeAgent):
    def analyze(self, state_path, n, *, should_stop, **kw):
        if should_stop():
            return FakeResult()
        with FakeAgent.lock:
            FakeAgent.log.append((time.monotonic(), self.task_id, self.branch, self.generated_tokens))
        time.sleep(0.01)
        self.generated_tokens += 4000
        if not self.arc2_checked:
            flags = ["fixed_offset"] if int(self.task_id[1:]) % 2 == 0 and self.branch == 0 else []
            self.arc2_checked.append({"name": "transform", "accepted": True, "test_outputs": [[[self.branch]]],
                                      "t": time.time(), "overfit_flags": flags})
        return FakeResult()


FakeAgent.log = []
t6 = {f"t{i:03d}": {"train": [], "test": [{"input": [[0]]}]} for i in range(6)}
r7 = A.solve_all_r6(t6, sorted(t6), out_dir=tmp / "t7", deadline=time.monotonic() + 4, base_url="x", model_id="m",
                    branches=2, max_generated_tokens=12000, workers=1, first_exposure_tokens=4000, agent_cls=FakeFlag,
                    min_admit_sec=0.5)
b1_first = []
for t_, tid, b, tok in FakeAgent.log:
    if b == 1 and tid not in b1_first:
        b1_first.append(tid)
expect("T7: class 2 (one verified prediction): flagged tasks get branch 1 before unflagged ones",
       b1_first[:3] == ["t000", "t002", "t004"] and set(b1_first[3:]) == {"t001", "t003", "t005"}, b1_first)
expect("M1: branch 1 records carry the stage-2 class they were started in (yield by class)",
       all(x.get("stage2_class") == 2 for t in t6 for x in r7[t] if x["branch"] == 1), [x.get("stage2_class") for t in t6 for x in r7[t]])
expect("S6: the final snapshot keeps the candidates of branches paused at the deadline",
       all(any(c["accepted"] for c in x.get("checked") or []) for t in t6 for x in r7[t] if x["branch"] == 0))


# P4: a worker exception and a hung model request near the deadline
class FakeBoom(FakeAgent):
    def analyze(self, state_path, n, *, should_stop, **kw):
        if self.task_id == "t001":
            raise RuntimeError("boom")
        return super().analyze(state_path, n, should_stop=should_stop, **kw)


rB = A.solve_all_r6(t6, sorted(t6), out_dir=tmp / "boom", deadline=time.monotonic() + 3, base_url="x", model_id="m",
                    branches=1, max_generated_tokens=8000, workers=3, first_exposure_tokens=None, agent_cls=FakeBoom,
                    min_admit_sec=0.5)
expect("P4: a worker exception ends only its branch (recorded); every other task still runs",
       "boom" in rB["t001"][0]["note"] and all(rB[t] and rB[t][0]["generated_tokens"] > 0 for t in sorted(t6) if t != "t001"),
       {t: (rB[t][0].get("note"), rB[t][0].get("generated_tokens")) for t in sorted(t6)})
import socket  # noqa: E402
hang = socket.socket()
hang.bind(("127.0.0.1", 0))
hang.listen(8)
held = []
threading.Thread(target=lambda: [held.append(hang.accept()) for _ in range(8)], daemon=True).start()
sess = A.BranchSession(Agent, task_id="hang", task=task, branch=0, view="facts", queue_position=0, out_dir=tmp / "hang",
                       deadline=time.monotonic() + 4, base_url=f"http://127.0.0.1:{hang.getsockname()[1]}/v1",
                       model_id="qwen", save_request_logs=False, analyzer_timeout=1800, backoff=1.0)
tH = time.monotonic()
sess.run()
expect("P4: a request hanging at the server ends at the deadline (1,800 s analyzer timeout clamped), record written",
       time.monotonic() - tH < 4 + 4 and sess.status == "done" and (tmp / "hang" / "hang_b0" / "branch_result.json").exists(),
       round(time.monotonic() - tH, 1))

print("ALL OK" if ok else "SOME FAILED")
sys.exit(0 if ok else 1)
