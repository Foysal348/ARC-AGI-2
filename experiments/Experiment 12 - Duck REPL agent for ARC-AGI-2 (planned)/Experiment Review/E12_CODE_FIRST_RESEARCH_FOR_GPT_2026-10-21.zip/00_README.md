# E12 Duck agent, rev 6 research brief: "compute in code from the first token" (2026-10-21)

**Goal (fixed):**
- **Model and harness:** keep the same Qwen3.8-27B (RedHat INT4 + BF16 DFlash2 drafter on SGLang 0.5.21, TP4, 4×L4) and the same Duck REPL harness.
- **Coverage:** solve all 240 hidden tasks (about 344 test inputs) inside the 12 h Kaggle run.
- **Accuracy:** raise it at the same time.
- **The lever:** make the model compute every fact in Python (the sandbox) instead of in its thinking, and cut the tokens it spends per task.

**Given as fact by the user (not to be argued):**
- The top ARC-AGI-2 teams run Qwen3.8 + an optimized Duck harness with full coverage, at 70–88 LB and 80+ on eval.
- The question is only HOW.

**You already have the notebooks** (EVAL6R5 and EVAL12R5_LOW, rev 5). This bundle adds four things:
1. today's measurements of where our tokens go;
2. a reading of all our earlier experiments, journals and PDFs (12 agents read every file);
3. what competitors and public notebooks do;
4. the verbatim prompts of the ARC-AGI-3 Duck winners.

Each claim below says whether it is **measured** (M), **inferred** (I) or **someone else's claim** (C).

---

## 1. Constraints (user rules)

| Rule | Meaning for proposals |
|---|---|
| **60k thinking floor** | Thinking per attempt must stay ≥ 60,000 tokens unless the user approves a change. **Any change to per-request output length (`max_tokens`), a per-turn thinking cap or an early stop needs explicit approval.** Splitting the same total budget into many short requests is allowed to be proposed, but it must be flagged for approval. History: the ARC-AGI-3 Duck default is 12,288 per request. The user approved it as an exception on 2026-10-19 (EVAL30). We later raised it to 60k (rev 4) and then 49,152 (rev 5) |
| **Bundled changes** | One bundled, evidence-backed change set per run. No one-variable LB ablations. Lead with the biggest lever |
| **Full coverage** | Duck runs on every task. Never propose solving only a subset |
| **Same model** | Never claim the model "cannot" do it, or that fine-tuning/RL is required |
| **Latest stack** | SGLang 0.5.21; do not steer to older versions |
| **Keep full traces** | Every GPU run keeps the full thinking of every request |

---

## 2. Where we are (M)

| Run | Inputs | Tasks | Generated tokens | Per branch | Solve time | tok/s |
|---|---|---|---|---|---|---|
| EVAL30 rev 1 (12,288/request, all 60 branches admitted) | 7/48 | 4/30 | 2.36 M | — | 3.9 h | 187 |
| EVAL6 rev 4 (60k/request) | 4/8 | 3/6 | 1.22 M | 101k | 62 min | 325 |
| **EVAL6R5 xhigh** (49,152/request, T 1.0) | **5/8** | **4/6** | 846k | 70.5k | 58 min | 244 |
| **EVAL12R5_LOW** (`reasoning_effort` low) | **10/19** | **7/12** | 1.74 M | 72.7k | 110 min | 265 |

**EVAL30 notes:** branch 1 never started in 29/30 tasks; the KV cache thrashed.

**Coverage arithmetic (M + I):**
- **Per task (2 branches):** about 141–145k tokens and 9–10 min.
- **Need:** 240 tasks in about 11.3 h is about 2.8 min per task, so we are **about 3.4× short**.
- **Budget:** at 330–430 tok/s the run has about 13–17 M tokens, i.e. **about 55–72k tokens per task for both attempts**.
- **Streams:** we run 6 while the engine runs 12. Measured engine totals: 4 → 257, 8 → 364, 12 → 416 tok/s (E11-04). A known bug runs only 11 of 12 (about −8 %).

**A cap alone does not work (M, `evidence/our_runs/budget_sim.py`):**

| Cap per branch | xhigh tasks | low tasks |
|---|---|---|
| 35k | 1/6 | 2/12 |
| 70k | 4/6 | 5/12 |
| none | 4/6 | 7/12 |

The reason is that the first `check()` arrives too late.

---

## 3. Where the tokens go today (M, `evidence/our_runs/`)

All 36 branches of both rev 5 runs were read by two readers and then measured by a script (`precheck_behaviours.py`).

| Measure | xhigh (12) | low (24) |
|---|---|---|
| First `check()`, median tokens | **55.1k** | **53.7k** |
| Pre-check tokens generated *after* the response's first "use code / in Python / stop guessing" phrase | **37 %** | 20 % |
| Branches where the model itself notices a misread of its hand counting before the first check | **12/12** | **23/24** |
| xhigh first reply before any tool call | p50 33.6k, p75 47.9k | (low: about 200 tokens, but a median 8.5 requests to reach check) |

**Behaviours** (readers' line references are in `reader_xhigh.md` and `reader_low.md`; spot-checked):
1. **Hand reading and counting** of grids in thinking. Wrong counts lead to wrong rules, which are then debated.
   - Cost: about 45k in 4c3d4a41, 31k in 135a2760, 25k in 62593bfd.
   - 135a2760_b1, L2511: "The data is completely different from my visual reading".
2. **Stated intent to use code, followed by more thinking.**
   - 62593bfd_b0 xhigh: the first intent comes at about 3k tokens (L289); the model repeats it 43 times; the rule comes at about 37k.
   - Counter-example: 4c3d4a41_b0 L1241, "stop hand-simulating and actually use Python". It ran 3 count calls and had the rule within about 7k.
3. **Rule found, check delayed:** test-output simulation and alternatives cost about 18k in 62593bfd and about 26k in 65b59efc (low). Our own prompt line "when you see that, compare their test outputs" invites this.
4. **Own comparison against `p['output']` instead of check(),** and settling variants by hand: about 24k (cbebaa4b), about 25k (135a2760, refuted by one check).
5. **Error loops:** disallowed `sys` / `traceback` imports and IndexErrors (898e7135_b0: 6 of 15 calls failed).
6. **Context loss from the output reserve** (low 4c3d4a41_b0).
   - The prompt was 66,189 tokens with a 16,365-token reply.
   - With the 49,152 output reserve that exceeds the 131,072 window, so the history was trimmed and the prompt fell to 19,856.
   - The next reply accepted a hard-coded (overfit) transform.
7. **Fast branches** (136b0064, bf45cf4b, 247ef758, b5ca7ac4): the first real call after a think is transform + check, even when imperfect, and check settles the open details.

**The rev 5 prompt already says this, and it did not help:**
- "Read exact grid values, sizes, counts and coordinates with Python rather than counting cells or simulating outputs by hand."
- "Write and check a candidate `transform` as soon as you have a plausible rule."
- The model still hand-counted in 35/36 branches. The full current prompt is in `evidence/current_adapter/arc2_duck.py` (`arc2_system_prompt`, `_R5_EDITS`) and in `evidence/past_work_reviews/exp12_all_docs.md` §4.

**Structural cause, documented in our PIV notebook (M):** "Qwen3.8's template places tool calls after `</think>`, so under XHIGH the model must finish a full solve before it can act."
- Our ARC-2 adapter puts every training and test grid in the system prompt as digit rows (`arc2_duck.py` L327-330).
- The ARC-AGI-3 Duck does the opposite: "The raw numeric grid is intentionally not exposed."

---

## 4. What we tried before, and the lessons (all M unless marked)

Full notes with paths are in `evidence/past_work_reviews/`.

| When | What | Result | Lesson |
|---|---|---|---|
| 09-14 P0 REPL, xhigh, 12,288 tokens | Stateful REPL | **0/8 tool use**: all tokens went into the first `<think>`; median ~275 "row/col N" references per task | xhigh solves in its head before it can act |
| 09-15 effort ablation (8 tasks) | low / medium / xhigh + forced close at 3,072 | Tool use 0.875 / 0.125 / 0.875; median think 715 / 2,560 / 3,072 | Forced close or low effort makes it act; **medium is worst** |
| 10-03 PIV v1.3 EVAL120 (low, 8,192) | REPL agent | LB 1.67; **49/120 tasks never used the tool**, spending 6,144 tokens transcribing grids row by row; 0 tool calls → 0/36 train-exact, ≥1 → 3/42 | Hand transcription is the failure mode |
| 10-04 **V3.1** (archive) | "# Workflow (STRICT)": "Never transcribe … grids are already in `puzzle` … first Python execution should call `arc_overview()` … by the second execution define `solution`". Preloaded `arc_overview()` (shapes, colour counts, changed cells, top colour changes, component counts; never prints grids), helper library, auto-verify whenever `solution` changes, backfill. **Low effort, `</think>` forced at 2,048, 12k per task** | 0/12 zero-tool tasks (was 49/120); 12/12 first turns ended in a tool call after a **median 664 thinking tokens**; solves unchanged (1/12) | **Plumbing fixed, depth cut.** The workflow + helpers were **never tested at xhigh with a full ≥60k budget**. Verbatim in `evidence/prompt_excerpts_verbatim.md` §4 |
| 10-04 EVO12 | 4 "lens" candidates + 2 repairs, medium, 3,072 cap | 0/12; 0/80 natural closes | Short caps alone add nothing |
| Exp 2 R6 code loop | 49k think → `solve()` → 3 repairs without the earlier reasoning | 2/22; 46/47 forced closes; repairs flat | Repairs need the context |
| Exp 4 run 4 (Duck clone, vLLM) | `IN_PYTHON_RULE` "Never read, count, index or transcribe grid cells in your head…" + 10,240/turn + THINKCAP hint + effort drop | **17/24 first turns hit 10,240 with no tool call** despite the rule; **after the cut + "[harness] Stop analysing… call python", 17/17 second turns called a tool**, about 1k tokens per tool turn. 0/22, but other fatal bugs (59 empty forced submits, HTTP 500 from forced `tool_choice`) | **A prompt rule alone is ignored at xhigh; a structural cut + terse order works mechanically.** Never force a named `tool_choice` |
| Exp 5 | 49k `thinking_token_budget`, no tools | 10/12 thought to the 57k cap | **vLLM + MTP silently ignores the server thinking budget** (and min_p, logit_bias). Never rely on it; control on the host |
| E10 Poetiq R5 EVAL120 | Code-verify, no tool during thinking | 48.61 % eval, **LB 21.39** (coverage). 22.7 % of thinking is digit/coordinate tokens; the first `def transform` comes at about 60 % of a solved trace; **35 % of solved-trace thinking is mental re-checking after it**; 58/104 capped traces never wrote code | **Code written by 30k: 77 % solved vs 30 % without** (AUC 0.80 for a solve) |
| E11-06 P1 prompt (Poetiq) | "no hand execution, no writing out grids, write the code and stop" | 7/22 vs 5/22 (n.s.); 89 % still hit the 60k cap | Prompt-only again weak |
| Coverage levers (10-17) | Early stop of "hopeless" thinking, grid-repeat stop, pause/resume | AUC 0.51–0.64, saves 2.7–4 %; 0/22 repeat stops correct; pause/resume worse at every budget | **Avoid** text-heuristic early stops |
| W3H low effort (direct) | low | 9.88 %; 78 % EOS mid-thinking | In the direct setting low ≠ cheaper and better. In Duck low was 7/12 but not cheaper per branch |

**A metric correction.** The 10-16 note "digit hand-reading is only 6.4 % of R5 thinking, fact sheet downgraded" used a narrow line metric: only lines with ≥ 4 digits that are ≥ 60 % digits, i.e. raw grid rows (`common.py:is_digit_heavy`). The same traces give 22.7 % at token level and 45–50 % at paragraph level (grid checking). Two more reasons that note does not apply here:
- R5 had no tool during thinking.
- Duck has a tool and the model does not use it.

The fact sheet was ranked #3 on 10-15; the literature gives about +5–10 points (KAAR, Xu, Greenblatt).

**Literature in our PDFs** (`pdfs_journals_papers.md`):
- PiVOTools, same model ± a Python REPL: GPT-OSS-120B 6.11 → 26.38 %, GPT-5.2 59.81 → 73.36 %.
- CoreThink: "Do not make the LLM perform raw perception arithmetic."
- Johan Land (arXiv 2606.31543):
  - CSV grids beat 8 other formats; a poor format cost about 10 %.
  - Prescriptive step templates hurt the hardest tasks, a "compliance tax".
  - One-shot code is cheap and contributes unique solutions.
- Portability notes §7.8 name our symptom, "model repeatedly re-derives the same facts", as an agent-loop failure.

---

## 5. Competitors and coverage evidence (`evidence/competitors/`)

**Public LB, 2026-10-21 (top 40 in `LB_top40_2026-10-21.txt`):**

| Rank | Team | LB |
|---|---|---|
| 1 | Tufa Labs | 88.06 |
| 2 | Yi-Chia Chen | 84.72 |
| 3 | rabbithole | 80.83 |
| 4 | nvbanana | 79.17 |
| 5 | Majkel1337 | 75.56 |
| 13 | mikelou1 | 66.39 |
| 24 | Daniel Franzen (author of the Duck fork we vendor) | 57.64 |
| 87 | Us (Hack2Publish) | 34.58 |

The October jump wave (_hans, ALbert, Majkel, Dawid at +15–40) came right after the ARC-AGI-3 Milestone-2 Duck solutions were open-sourced (Sep 30).

**Discussion statements (C unless stated; threads in `kaggle_discussions_2026-10-21/`):**
- **User (fact):** the top teams use Qwen3.8 + an optimized Duck with full coverage.
- **mikelou1:**
  - "With time constraints at around 4xL4 speed I got Qwen to **87 %** (and from reasoning traces it got the rule to almost every problem)."
  - LB 25 → 36 → 40 → **66.39**, "Not a NVARC ensemble"; 40 → 66 came from "a tiny kernel issue".
- **Kris Dreemurr:** "median **70k tokens for pass@2 (35k per slot)**" at xhigh, about 45 % (52/120) in CV; "I cant fit it in the box".
- **NguyenThanhNhan:** pure reasoning, 1 pass, 65k, forced commit at 49k → 23.33; "you could solve many more tasks within 12 hours by implementing a **simple harness**". Now 52.08 (method unknown). He posted his SGLang flags (EAGLE 3/1/4, extra_buffer, fp8 KV).
- **Anil Thomas:** 330 queries × 64k / 350 tok/s × 42 % ≈ 30 LB for pure reasoning.
- **TheDivine Aurora:** "at around 300–500 tps I had ~19–20 % … only attempted half the dataset".
- **Adarsh:** "a python repl should do almost all of the thinking for qwen and reduce the token usage".
- **Hiểu Vy:** Qwen3.8-27B "80 %" on the 120 eval tasks (time limit not stated).

**ARC-AGI-3 Duck winners (M from code; `arc3_dfranzen_forks.md`, `prompt_excerpts_verbatim.md`):**
- **Short calls:** our own ARC-3 P1_SPARSE run with the Tufa config averaged **1,477 generated tokens per model call** (1,340 calls, 54 per game).
- **dfranzen's submitted settings:**
  - 12,288 `max_tokens` per request;
  - a turn yields after 2,048 generated tokens;
  - thinking is kept in history (`preserve_thinking`);
  - context 128k with a 58k drain (hysteresis protects the prefix cache);
  - tool output 3,072 with head/tail truncation;
  - persistent functions;
  - priority gate with 10 active streams; `lpm`, `--page-size 64`, `--mamba-track-interval 64`.
- **Grids are never text:** "The raw numeric grid is intentionally not exposed. Use `current_frame.segmentation` …"; "Always inspect … from Python instead of reasoning from the raw board by eye"; "Never print or echo full board frames."
- **Written but OFF in his config:**
  - PREFER_TOOL_CALLS: "prefer another tool call over more reasoning: … running it is faster than thinking your way to the same answer". His rationale: "a turn spent 18,012 characters reasoning, hit the output cap, and executed nothing".
  - The board print guard: "character counting is unreliable for you".
  - The effort ladder.
- **Fork 05 (df-wm):** the model writes `simulate()` and `check_sim()` returns only accuracy plus 3–5 mismatched cells. This is our `check()`.
- **Fable handbook:** "Add facts, not advice". Advice blocks lowered scores (6.42 → 4.16); keeping the agent's own history raised them (+8.0).

**Public ARC-2 Qwen notebooks** (no logs or scores in any of them; `public_agents_A.md`, `public_notebooks_B.md`):
- **madarshbb:** a Duck clone with IN_PYTHON_RULE, "Submit EARLY and often", a nudge every 6 calls and THINKCAP_HINT. Its code comments record "failures parse and count grids IN THE REASONING, cell by cell, often filling a whole 16k-token turn before any tool call" and "solves used 2-3k tokens a turn". The published run is "direct" mode.
- **khoinguyennguyen:** persistent Jupyter with a `verify_all` helper, 2 branches per task, compression at 80 % of context, presence_penalty 1.5.
- **delongyang:** medium effort, shortest-first, a `|` separator every 4 cells on wide rows.
- **HyperQwen:** "W4A16/MTP3, TP4/C4, FP8 KV, 60K/xhigh" (sealed code).
- **yukailiu / johntaylorai (NVARC):** cheap-first ordering with a cost model; fair-share budget = remaining time / remaining tasks. A fixed cap above fair share (1,200 s vs 705 s available) leaves 20–41 % of tasks unattempted.

---

## 6. Candidate catalogue: every way we found, with evidence and status

**Legend:**
- ✅ allowed without approval (no change to thinking length)
- ⚠️ needs the user's approval (60k floor)
- ⛔ avoid (measured negative)

### A. Code-first from the first token: change what the model sees

| ID | Change | Evidence | Status |
|---|---|---|---|
| A1 | **Do not put grids as text in the system prompt** (or only a compact header: shapes, colours). Keep them in `train` / `test_inputs`; add "The raw grids are intentionally not shown; inspect them from Python instead of reasoning from the grid by eye". Possibly show grids once in a compact form, or only small ones | ARC-3 Duck design; PIV / P0 / EVAL120 transcription; 35/36 misreads | ✅ (biggest untested lever, I) |
| A2 | **Harness-computed facts block** before the first token: per grid dims, background, colour counts; per component colour, size, bbox, shape string; per pair diff count / changed bbox / colour map; symmetry; periodicity; separators; size ratio. **The vendored Duck already ships `segment_layer` and `compute_frame_diff`** (`vendor/inference/utils/segmentation.py:120`, `frame_diff.py:82`); our adapter sets `current_frame=None` | V3.1 `arc_overview`; CoreThink; the 22.7 % / 45–50 % digit share; R6-1 | ✅ |
| A3 | **Preloaded helpers in the prelude:** `objects(g)`, `diff(a, b)`, `components`, `bbox`, `crop`, `rot/flip`, `periodicity`, `symmetry`; auto-print the last expression (Duck has it) | V3.1 library; madarshbb `show/diff/objects`; khoinguyennguyen `verify_all` | ✅ |
| A4 | **Zero-GPU pre-pass:** a CPU rule library (hosen42 arc-reasoning-engine: 21 rules at 18–33 ms per task; ArunSehrawat: 383 verified training programs). An exact hit costs 0 tokens; partial hits go into the facts | Portability notes; reference notebooks | ✅ |
| A5 | Grid format for whatever is still shown: CSV, (R×C) header, row indices, `|` every 4 cells | Johan Land (CSV best, ±10 %); delongyang; madarshbb | ✅ (A/B) |
| A6 | Grid images (Qwen3.8 is a VLM; Tufa credits multimodality; about 400 tokens per image) | Duck supports it; our serving path is unverified for images | ✅ (needs a check) |

### B. Make the model act early: control structure

| ID | Change | Evidence | Status |
|---|---|---|---|
| B1 | **Short requests with continuation, same total ≥ 60k**: e.g. `max_tokens` 12,288 per request (Duck default), thinking kept in history, per-attempt total unchanged | ARC-3 Duck (1,477 tokens per call); Exp 4 17/17 tool calls after a cut; rev 1 EVAL30 at 12,288 had 29/30 first requests cut (with grids in the prompt) | ⚠️ |
| B2 | **Reason-specific resume texts.** Our adapter always sends one neutral resume ("continue from them"). Use the Duck texts per reason: no tool call → "Stop deliberating and call the `python` tool NOW …"; cut tool call → "CUT OFF … emit the `python` tool call early"; tool results → "do NOT restart … next: transform + check". (In dfranzen's default 'full' mode the opener is re-sent instead; `tool_agent.py:776-845`) | Duck source; Exp 4 | ✅ (text only) |
| B3 | **Code-intent stop:** after about 3k reasoning tokens a phrase such as "in code / use Python / stop guessing" ends the stream. The resume says "your reasoning is kept; run the code you planned" | 37 % (xhigh) / 20 % (low) of pre-check tokens come after the intent | ⚠️ (needs streaming; pause/resume was negative in DIRECT, but that is a different setting) |
| B4 | **Auto-run `check()`** whenever a call defines or changes `transform`, and append the compact result (V3.1 auto-verify) | V3.1; behaviour 3 | ✅ |
| B5 | `check({'A': fA, 'B': fB})`: one line per variant; error messages show the failing line inside transform; the allowed imports are listed | Behaviours 4–5 | ✅ |
| B6 | Prompt lines: PREFER_TOOL_CALLS adapted; "When one rule explains every training pair, call check(transform) in the same reply; compare test outputs only after check is exact, in Python"; replace the current "compare their test outputs" | Behaviour 3; dfranzen | ✅ |
| B7 | Board-print guard adapted to digit rows; nudge after N python calls without a check | dfranzen (OFF); madarshbb | ✅ |
| B8 | Effort ladder after a truncation | dfranzen (OFF), madarshbb; ARC Prize: medium 13.2 < low 22.8 < xhigh 42.4 | ⚠️ (risky) |
| B9 | Forced named `tool_choice` | Exp 4: empty code + HTTP 500 | ⛔ |
| B10 | Server `thinking_token_budget` (vLLM + MTP ignored it). Check SGLang + DFlash before any use | Exp 4/5 | ⛔ as the only control |
| B11 | Text-heuristic early stop / pause-resume of "hopeless" thinking | Coverage levers | ⛔ |

### C. Prompt content

| ID | Change | Evidence | Status |
|---|---|---|---|
| C1 | **"Facts, not advice"**: shorten the prompt to the tool contract plus facts; no reasoning templates | Johan Land; Fable / rellik13 | ✅ |
| C2 | The V3.1 workflow block (verbatim in excerpts §4), adapted to `transform` / `check`, **at xhigh with ≥ 60k** | Never tested at full budget | ✅ |
| C3 | IN_PYTHON_RULE (madarshbb) and Tufa's "inspect from Python instead of by eye" | Alone not enough (rev 5, Exp 4); use together with A/B | ✅ |

### D. Context and KV

| ID | Change | Evidence | Status |
|---|---|---|---|
| D1 | **The 49,152 output reserve forces trims at about 82k context.** That dropped tool results and caused an overfit accept (4c3d4a41 low). Reserve vs window needs a fix (shorter requests in B1 would also fix it) | M | ⚠️ if the cap changes |
| D2 | Keep tool results after a no-tool turn; protect retained facts across trims | Readers | ✅ |
| D3 | Keep the prefix stable: tool definitions on every request, append-only resumes, drain hysteresis (uncached prefill 0.97M > generated 0.85M in xhigh) | dfranzen; E11 | ✅ |

### E. Throughput and coverage scheduling

| ID | Change | Evidence | Status |
|---|---|---|---|
| E1 | 6 → 10–12 streams (10 fit KV at p90 context; shorter contexts from A/B would allow 12) | E11-04: 4/8/12 → 257/364/416 tok/s | ✅ |
| E2 | Fix the 11-of-12 admission (about −8 %) | E11-05 | ✅ |
| E3 | `--schedule-policy lpm`, `--page-size 64`, `--mamba-track-interval 64` (Franzen; never measured on our stack) | — | ✅ (measure) |
| E4 | **Attempt-major scheduling:** branch 0 of every task before any branch 1. Branch 1 runs only while time remains, or on unsolved tasks | madarshbb, russcore; D66 ∪ L66 = 50 vs 28/34 | ✅ |
| E5 | **Fair-share per-task budget** = remaining tokens / remaining tasks, recomputed live; ORDER2 + cheap-first | yukailiu, johntaylorai; ORDER2 +4–7 | ⚠️ if it ever goes below 60k thinking |
| E6 | Priority by progress (best check score improving), drain stuck branches (shiiin9 D': 31.54 vs about 27.6, n=1) | ARC-3 forks | ✅ |
| E7 | Zero-GPU fallbacks for unreached tasks (constant, identity, most common train output, CPU rules) | delongyang, hosen42 | ✅ |

### F. Selection and overfit

| ID | Change | Evidence | Status |
|---|---|---|---|
| F1 | 4c3d4a41: every branch accepted a train-exact but test-wrong program (hard-coded coordinates). Add an anti-hard-code / transfer check (Imbue fitness 0.90 / 0.07 / 0.03) and prefer agreement across branches | M; Imbue | ✅ |
| F2 | attempt_2 from a different branch / mechanic (in xhigh, 3 of 5 hits came from attempt_2) | M | ✅ (done in rev 5) |

---

## 7. Questions for you (GPT)

1. **Design a bundled "code-first" rev 6** that makes the model compute every fact in the sandbox from the first token. Target: first `check()` at a median ≤ 15–25k tokens, about 35k per attempt, full 240-task coverage in 12 h, and accuracy ≥ rev 5. Which A–F items, in what form, and in what order of impact?
2. **A1 (grids not in the text prompt) is our biggest untested change.** What is the risk that Qwen3.8-27B reasons worse without seeing the grids? What hybrid would you use: compact header only, small grids only, an image, or CSV?
3. **B1 (short requests, same total).** Rev 1 at 12,288 had 29/30 first requests cut. That was with full grids in the prompt and no facts block. Would A1 + A2 + B2 change that? Propose the exact per-request cap and resume texts. Flag that this needs the user's approval.
4. **Fact block (A2):** which features, in what format, and at what token cost? Which existing Duck functions (`segment_layer`, `compute_frame_diff`) should be exposed, and how?
5. **Throughput:** what concurrency and scheduler settings, given shorter contexts? Is attempt-major plus a fair-share budget the right coverage policy?
6. **Verification:** what should GPU smoke tests assert before a full run? Examples: first tool call within N tokens on a real task; check auto-runs; real running count equals 12.
7. **Which of our past negative results** (V3.1 no gain, Exp 4 0/22, E11-06 n.s.) do NOT transfer to this design, and why?
8. **Anything we missed:** search the web (ARC Prize 2026 write-ups, the Tufa Duck blog, the da-fr repo, Kaggle threads) for how the top Qwen3.8 + Duck teams get short traces on ARC-AGI-2.

For every proposal, give the evidence: a file and line in this bundle or the notebooks, or a URL. Say whether it is measured or inferred.

---

## 8. File map

| Path | What |
|---|---|
| `01_PROMPT_FOR_GPT.md` | The prompt to paste |
| `evidence/our_runs/` | Rev 5 runs analysis, the running fix list (rev 6 candidates R6-1..R6-6 at the end), the two transcript-reader reports, the pre-check behaviour script and its output, `budget_sim.py` |
| `evidence/current_adapter/` | `arc2_duck.py` (current ARC-2 adapter, rev 5), the Duck milestone-2 exact settings |
| `evidence/prompt_excerpts_verbatim.md` | Tufa / dfranzen / madarshbb / our V3.1 prompts, copied from source |
| `evidence/past_work_reviews/` | 12 reading notes covering every experiment (Exp 1–13), the archive (PIV, V3, V3.1, EVO), all journals and PDFs, the reference notebooks, the ARC-3 Duck code and forks, the public notebooks, the full E12 doc review (incl. the full current prompt text) |
| `evidence/prior_docs/` | Weakness analysis vs top teams, ranked improvement ideas, coverage levers, D66/L66 findings |
| `evidence/competitors/` | LB top 40 (2026-10-21), the October wave, Kaggle threads (2026-10-21), public-notebook analyses |
