# Prompt to paste (attach `E12_CODE_FIRST_RESEARCH_FOR_GPT_2026-10-21.zip`; you already have the rev 5 notebooks)

---

You are a senior research engineer reviewing our ARC Prize 2026 ARC-AGI-2 Kaggle solver. Read `00_README.md` in the attached zip fully, then every file it points to, before answering. Do not skim. You already have our rev 5 notebooks (EVAL6R5 xhigh, EVAL12R5_LOW).

## Setup

**Model and engine:**
- Qwen3.8-27B (RedHat INT4 weights + BF16 DFlash2 drafter) on SGLang 0.5.21.
- TP4 on 4× NVIDIA L4.
- One 12-hour Kaggle run.
- 240 hidden tasks, about 344 test inputs, about as hard as the public evaluation set.

**Solver:** the Duck REPL harness (vendored from da-fr/arc-agi-3-solution), adapted to ARC-AGI-2:
- one `python` tool;
- `check(transform)` / `submit(transform)`;
- two branches per task give attempt_1 and attempt_2.

**Fixed:**
- We keep this model and this harness.
- The top ARC-AGI-2 teams run Qwen3.8 + an optimized Duck harness with full coverage (70–88 LB, 80+ eval). Treat that as fact. The question is only how.

## The problem (measured; see README §2–§3)

**Coverage:**
- We need about 2.8 min per task for full coverage; we are at 9–10 min, about 3.4× short.
- About 70k generated tokens per branch.

**Where the thinking goes:**
- The first `check()` comes only after a median of about 55k tokens of thinking.
- In 35 of 36 branches the model reads and counts grid cells in its head, then notices its own misreads.
- 20–37 % of the tokens before that first check come after the model has already written "let me do this in code".
- Our prompt already tells it to read values with Python; it did not help.
- The structural cause is documented: Qwen3.8 places tool calls after `</think>`, so at xhigh it solves in its head first.
- Our adapter also puts every grid as digit rows in the system prompt. The ARC-AGI-3 Duck winners never show the raw grid as text, and average about 1.5k generated tokens per model call.

## What I want: the user's vision

From the very first token, every fact the model needs should be computed by code in the sandbox, not in its thinking:
- counts, sizes, positions, objects, diffs;
- checking a rule against the training pairs;
- simulating test outputs.

The model's thinking should hold only hypotheses and plans. Use every way that works: what the model sees, harness control, prompt wording, helpers, verification, context handling, scheduling, throughput.

## Tasks

1. **Validate the README's evidence.** For each claim you rely on, check it against the bundle (file:line) or the notebooks. Say where you disagree, and why.
2. **Research.** Search the web for how Qwen3.8 + Duck-style agents get short traces and full coverage on ARC-AGI-2. Sources to cover:
   - ARC Prize 2026 write-ups and Kaggle discussions;
   - the Tufa Labs "Duck" material and the da-fr repo;
   - Qwen3.8 tool-use and thinking behaviour;
   - program-synthesis / REPL agent papers.
   
   Cite URLs. Mark anything you cannot verify.
3. **Design one bundled "code-first" rev 6** from the catalogue in README §6 (A–F) plus anything new you find. For each item give:
   - (a) the exact change: prompt text verbatim, helper signatures, harness rule, setting values;
   - (b) the evidence;
   - (c) the expected effect on tokens to first check, tokens per task, coverage and accuracy, each marked measured or inferred;
   - (d) the risk;
   - (e) whether it needs the user's approval under the 60k thinking-floor rule.
   
   **Approval rule:** any change to per-request output length, per-turn thinking caps or early stopping needs approval. Splitting the same ≥ 60k total into short requests may be proposed, but must be flagged.
4. **Answer the 8 questions in README §7.** Above all:
   - the risk and best form of not showing grids as text (A1);
   - the facts block contents (A2), and which existing Duck functions to expose;
   - short requests with continuation (B1/B2);
   - concurrency and coverage scheduling (E1–E5).
5. **GPU verification plan.** List the smallest GPU tests to run before a full submission, with pass/fail assertions. Examples:
   - first tool call within N tokens on a real task;
   - `check` auto-runs when `transform` changes;
   - real running requests equal the configured streams;
   - median tokens to first check ≤ 25k on EVAL12;
   - accuracy not below rev 5 (EVAL6R5 4/6, EVAL12R5_LOW 7/12).

## Rules for your answer

- Do not propose solving only a subset of tasks; Duck runs on every task.
- Do not say the model cannot do it or that fine-tuning or RL is required.
- Do not recommend older software versions.
- **Do not re-propose these measured negatives without new evidence:**
  - a forced named `tool_choice` (empty code + HTTP 500 in our Exp 4);
  - relying on a server-side thinking budget (silently ignored under vLLM + MTP);
  - text-heuristic early stop or pause/resume of "hopeless" thinking (AUC ≈ 0.5–0.64);
  - medium effort.
- **Explain any past negative result you think does not transfer.** For example:
  - V3.1 fixed tool use but ran at low effort with 12k per task;
  - Exp 4 had unrelated fatal bugs.
- **Output format:**
  1. one table of the proposed bundle (ID, change, evidence, expected effect, approval needed);
  2. the verbatim new system prompt and resume/nudge texts;
  3. the helper and facts-block spec;
  4. the scheduler settings;
  5. the GPU test plan;
  6. the open risks.
