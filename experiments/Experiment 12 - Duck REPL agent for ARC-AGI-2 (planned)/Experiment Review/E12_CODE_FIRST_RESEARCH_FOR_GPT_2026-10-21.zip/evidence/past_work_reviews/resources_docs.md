# Past optimisation review: resources/ documents (read 2026-10-21)

Scope read in full: `resources/Analysis and Journals/` (all .md/.txt + both .docx, text-extracted to `_scratch/session_1c6db7aa/past_opt_review/docx_txt/`; PDFs skipped), `Kaggle discussions (2026-10-21)/` (all 10 files), `Planning and Prompts/`, `Puzzle Capability Ledger/` (README, summary.json, CSV schemas + aggregates), `Puzzle Ordering (NVARC 32.22 ref)/README.md`, `Eval Subset (EDA mirror)/` (README, proxy48.json, EDA notebook outputs). To resolve the 6.4 % conflict I also opened the scripts behind it (`_scratch/session_1c6db7aa/agent_ideas_traces/`, `e11_05_runs/sim_tokens.py`) and one E10 analysis md.

---

## 1. The hand-reading share: three numbers, three methods (this is the conflict)

| Number | Source | Unit / definition | Data |
|---|---|---|---|
| **6.4 %** of thinking ("digit-heavy lines") | `Improvement ideas - consolidated and ranked (2026-10-16).md` row "Digit hand-reading"; raw: `_scratch/session_1c6db7aa/agent_ideas_traces/trace_findings.txt` Q6, `b_poetiq_analyze.py`, `common.py:is_digit_heavy` | **Line level**, outside code blocks: a line counts only if it has >= 4 digits AND >= 60 % of its non-space chars are digits. Tokens from a pure-Python BPE replica rescaled to logged counts (median +0.45 % error) | Poetiq R5 EVAL120, 172 iterations, 11.65 M tokens: 721,689 digit-heavy tokens = 6.384 %; E8 direct 10.4 % (16.7 % at a 40 % threshold) |
| **22.7 %** of thinking ("digit tokens") | `experiments/Experiment 10 .../Analysis/Where tokens and time go - Poetiq R5 + web research (2026-10-15).md` Part A; repeated in `Qwen3.8-27B LB and run deep analysis (2026-10-16).md` §9 ("prompts that stop hand-simulating grids (22.7 % of thinking is digit tokens)") | **Token level**: every digit token (cell values, coordinates) counted; 22.8 coordinate mentions per 1k tokens | Same R5 traces. 24-25 % in failed/forced traces vs 19.6 % in passed ones |
| **45-50 %** of thinking ("hand-checking grids") | `Weakness analysis vs top teams (2026-10-19).md` W1; script `_scratch/session_1c6db7aa/e11_05_runs/sim_tokens.py` | **Paragraph level**: a paragraph is "grid-heavy" if >= 50 % of its non-empty lines are written grid rows, carry >= 2 cell coordinates, >= 3 r/c refs, or >= 6 numbers with >= 30 % digits. Classes: A test-input simulation 4 %, B code dry-run 6-7 %, C train-grid checking 33-39 % | E11-05 EVAL30 (and R5/D66/L66 traces) |

**Why the 6.4 % downgrade does not contradict the new Duck finding:**
- The 6.4 % metric only catches raw number dumps (grid rows). Prose cell-by-cell reasoning ("r4 c13 = 9, so the bar at column 13 ..."), coordinates inside sentences, counting and re-checking are not digit-heavy *lines*, so they were excluded. The same traces score 22.7 % at token level and the paragraph classifier puts 45-50 % of thinking inside grid-checking paragraphs.
- The downgrade was also a counterfactual of *deleting digit-heavy tokens only*: "Removing every digit-heavy token from the forced, unsolved R5 iterations would save at most 0.43 M. Not a lever." It did not model removing the reasoning that hand-reading triggers (re-checks, self-corrections after misreads) or replacing it with a tool call.
- The digit-share AUCs were weak (forced 0.59, solved 0.41), but in the same analysis **code share was the strongest whole-trace signal: AUC 0.87 for natural close, 0.80 for solved**. That is direct support for "compute in code".
- R5 was Poetiq single-shot with no tool (the model could not run code), so its hand-reading had no alternative. The Duck finding (35/36 branches self-detect misreads; 20-37 % of pre-check tokens come after "let me do this in code") is about a setting where a tool exists and is not used.
- The resulting "Avoid: suppressing digit reading" (Improvement ideas §B) and "Fact sheet (downgraded)" (item 19) rested on the narrowest metric. The 10-15 E10 doc had ranked the fact sheet #3 ("Literature: +5-10 points", KAAR, Xu, Greenblatt) and in-thinking code execution #2.

## 2. Code during thinking, early exit, hopeless-stop (measured)

From `trace_findings.txt` (R5 Poetiq, 172 iterations) via `Improvement ideas` and the E10 doc:
- **Early exit on in-thinking train pass: downgraded.** 71/172 iterations passed train; the final program (similarity >= 0.90) was already in the thinking in 44/71, first appearing at p10/p25/p50/p75/p90 = 32.0k / 41.0k / 48.8k / 61.7k / 73.2k tokens = a **median of 91 % of the thinking** (p25 86 %, p75 95 %). Stopping there saves 0.33-0.36 M (2.9-3.1 %), upper bound 1.44 M (12.3 %) "only if drafts pass earlier". Its value was judged to be "more in feedback on the median 4 drafts (569k-token stretch)". Note this measures Poetiq where code was written late; it does not measure what happens if code is written early.
- **Code written by 30k predicts success:** with code 26 iterations, 81 % close naturally, 77 % solved; without 136 iterations, 29 % / 30 %. Past 49k, code-writing iterations yield **50.7 hit inputs per M tokens** vs **7.7 per M** without code (run average 6.7). 58/104 capped R5 traces never wrote `def transform`.
- **35 % of solved-trace thinking comes after the first `def transform`** (median 5 drafts per solved trace, first draft at 60 % of the trace) = mental re-checking of code a sandbox does in 0.3 s. Code inside thinking 9.2 %; grid rows copied line by line 1.7 %; reflection words 1.4-1.7 per 1k tokens.
- **Hopeless-thinking stop: NEGATIVE** (`Coverage levers - hopeless thinking and task order (2026-10-17).md`). Features at 30k/40k/49k/60k (zlib, duplicate lines, grid dumps, churn words, 8-grams, `def transform` count, fences). zlib AUC 0.51-0.56; best = churn AUC 0.61-0.64, saves only 2.7-4.0 % tokens at <= 5 % solve loss; out of sample it lost 12/65 train passes and 7/32 test-correct for 1.8 M saved. Grid-repeat stop 0/22 correct, convergence stop 0/28. Pause-resume worse at every budget (70 %: 31.7 straight vs 25-27).
- Forced close only exits thinking, it does not guarantee a tool call or code (journal §C). Forced `tool_choice` gave empty code or HTTP 500 (LB deep analysis §9). In PIV v1.7 "Qwen calls tools only after `</think>`": 8/8 tasks used all 12,288 tokens in first-turn thinking, 0/8 tool calls.
- PIV EVAL120 (archive A14): **49/120 zero-tool tasks spent their 6,144 tokens on row-by-row transcription**; only 3/173 tool calls ran `solution()` on train. This is the same "reads grids instead of computing" failure, at a small budget.
- V3 ALLFIX (A17) had exactly the prompt now needed: "no grid transcription, auto-verify after each tool call, verbatim commit, helper library". It never ran (reviewer NO-GO); V3.1 S12 (A18) ran it only with thinking forced closed at 2,048, so it was never tested at a realistic budget.

## 3. Thinking length and productivity (measured)

- Thinking needed by solved units: ORDER2 DIRECT 34.5 % <= 32k, **67.2 % <= 49,152**, 79.3 % <= 65,536; Poetiq R5 3.8 % / 23.1 % / 61.5 %. Ledger `solved_by_tokens.csv`: 60 units, 41 (68 %) solved at <= 49,152 at least once; <= 20k 8, 20-30k 11, 30-40k 11, 40-49k 11.
- Productivity, R5 iteration 1 (correct inputs per M tokens): natural <= 49k 22.9; 49-65.5k 16.7; 65.5-77.8k 11.3; **forced 2.9**.
- Natural vs forced hits: EVAL12 natural 7/16 (44 %), forced at 49k 1/72 (1.4 %); all runs natural 16/31 (52 %) vs forced 2/98 (2 %); "natural close before 40k thinking ~67 % hits, forced ~2 %" (ledger). R5 train pass: natural 75 %, forced 20-21 %.
- Token sinks: ORDER2 75.4 % of tokens on unsolved units; forced closes 56.6 % of tokens for 8 % hits; pooled 9 runs, 59.7 % of 32.5 M tokens went to forced closes with no hit (53.9 % under the trace agent's own definition). About 180k tokens per solved unit (ORDER2).
- L66 (122.9k cap): 78-123k natural closes 39 requests, 12 train pass, only 3 fully right: long natural closes are mostly wrong.
- Six ARC-Prize-solved tasks closed early and wrong in ORDER2 (6e453dd6 26k, edb79dae 27k, dbff022c 32k, 7c66cb00 37k, db695cfb 38k, d35bdbdc): confident failure, more tokens would not help.
- LB vs cap: R5 77.8k LB 21.39; S1-60K LB **34.58** (confounded: + ORDER2, S1 fixes, KV gate, +11 min). Memory: S49 49k LB 32.08 < 60k. User floor = 60,000.

## 4. Coverage arithmetic (all docs)

- Hidden = 240 tasks; eval-like set = ~344 test inputs (1.43 per task). Public LB = 120 tasks; LB x 1.2 = tasks solved; noise sd ~1.5 (NVARC notebook x10: 27.36-32.64, sd 1.65).
- LB / eval at same cap = share of hidden finished: 49k direct 1.06-1.10; 86k direct 0.62; Poetiq 0.44.
- Scheduling time ~680 min (admission to 11:34 minus ~13 min setup). Engine to 11:34: 11.5-12.5 M tokens (vLLM era); R5 produced 11.65 M.
- `Kaggle discussions/00_SUMMARY.md`: solve time ~11.3 h at 330-430 tok/s = 13-17 M tokens = **55-72k tokens per task (both attempts)** for 240 tasks. Rev 4 Duck EVAL6 used ~200k per task (2 x ~100k) = ~3x over. 6 -> 12 running gave only 368 -> 431 tok/s on this engine.
- Speed-up tables: LB deep analysis §3 (86k direct needs 1.54x -> ~37; Poetiq R5 2.04x -> ~49; union 3.57x -> ~57). D66/L66 §8: R5-style first pass over 240 tasks takes 16.6 h at 1.0x; >= 1.5x for one pass, ~2x before iterations/second attempts fit.
- Others: Kris Dreemurr median **70k per task for pass@2 (35k per slot), ~45 % = 52/120**, "can't fit it in the box"; Anil Thomas back-of-envelope 42*12*3600/(64*1024*330/350) ~ 30; ARC Prize xhigh ~173k per task (~60k per generation mean, 2 attempts x 1.43 inputs); Terminal-Bench output 45.6k/46.8k/63.5k for low/medium/xhigh; TheDivine Aurora "300-500 tps ~19-20 %, only half attempted; 40 % possible at 600-800 tps".
- Weakness analysis: ~1,000 tok/s needed to give 240 tasks 2 x 85k; we have ~330 (SGLang INT4 + DFlash2; DFlash acceptance 4.43 -> 3.77 over context).
- Direct only: one request per multi-test task would save 2.97-3.23 M = 28-31 % of ORDER2 (never built). Not relevant to Duck (one agent per task already) except that multi-test inputs must all come from one program.

## 5. Ordering (measured)

- NVARC `get_puzzle_priority` (tier rules + fine score), copied verbatim in `Puzzle Ordering .../puzzle_order.py`. Eval: 65/51/4 tiers; placeholder test 178/52/10.
- NVARC fine vs Qwen solved AUC **0.435** (reversed). ARC Prize xhigh per category: easy_static 25 %, dynamic 41 %, high_ratio 45 %, multi_query 26.5 %, low_train 20.6 %.
- ORDER2 vs random under a coverage budget: +4-7 points (DIRECT 50 %/70 % budget 25.8/32.5 vs 19.0/26.5; R5 29.2/37.9 vs 24.5/34.2). Tie-breaker "smaller total cells first within ORDER2 group" +0.7 to +4.0 (expected LB ~+1). Cost not predictable from task JSON (LOO r 0.62 DIRECT, -0.08 R5); oracle 36.9/48.6.
- Ledger honest ordering rule: score = [>= 3 train examples] + [1 test input], nested-CV AUC 0.570 (solve rate 58 % / 43 % / 20 % for score 2/1/0). Greedy 80-feature search overfit (0.681 in-sample, 0.521 honest).
- Poetiq iteration-1 ORDER2 vs alphabetical on the hidden clock: 26.7 % -> 31.2 % (+4.5).
- Oracle tiers (after R5): A 30 / B 20 / C 35 / D 35; 85/120 tasks solved by some method; 13 previously never-solved tasks fell to Poetiq ("not a model ceiling").

## 6. Prompts and grid formats on record

- Project journal: V3 "no grid transcription / define solution() early" (never run at length); PIV REPL with puzzle preloaded and protected; Poetiq feedback (solved marks, shape mismatch, cell diff pred/correct, soft score, verbatim errors).
- Public notebooks: delongyang direct, compact digit rows, `|` separator every 4 cells for wide rows (against column-count errors), medium effort, T 0, shortest prompt first; madarshbb grids with explicit (R x C) size; khoinguyennguyen agent: Python workspace, records observations, tests laws on every train pair, 2 branches/task, T 0.9, top_p 0.95, presence_penalty 1.5, preserve_thinking, compress at 80 % context into <= 32k summary; Dominic compact format `ex1i 586 586 586 ex1o 192 ...`; Tufa Duck: image + ASCII grid, live REPL, context eviction.
- Portability notes v10 (docx): Johan Land "CSV grid serialization performed well in the reported prompt ablations"; Noemon compact line-separated rows + optional shape + colour counts metadata ("ablate; keep only if accuracy or token efficiency improves"); PiVOTools "Preload puzzle in Python so the model can inspect dimensions, colors, components and invariants without rewriting arrays into code", "Explicitly discourage printing the entire puzzle. Ask for targeted slices, counts, object summaries and helper functions", "Encourage reusable functions because the REPL is persistent"; Athanor: exploratory `run_code` scratchpad for counts/connectivity/symmetry/colour maps/coordinates/invariants, "Keep tool stdout canonical and compact; raw NumPy dumps ... should not consume context"; CoreThink "Deterministic object layer ... Do not make the LLM perform raw perception arithmetic"; ARCgentica: do not mandate `scipy.ndimage.label`, expose libraries not obligations; PiVOTools failure signature "Model repeatedly re-derives the same facts, forgets successful helper functions" = agent-loop failure.
- Grid-format A/B (CSV or (R x C)) is listed in Tier 3 of `Improvement ideas` and §9 of the LB deep analysis as **never run**.

## 7. External evidence relevant to code-first agents

- PiVOTools same-model REPL lift: GPT-OSS-120B 6.11 -> 26.38 %, MiniMax M2.1 3.06 -> 10.56 %, GPT-5.2 XHigh 59.81 -> 73.36 % (107-task slice).
- Topic 733501: program synthesis beats no-reasoning (GPT-5.6-Sol 2/12 vs 0/12 at effort none).
- Adarsh: "python repl should do almost all of the thinking for qwen and reduce the token usage". NguyenThanhNhan: pure reasoning "quite token-inefficient ... a simple harness" solves many more tasks. mikelou1: 87 % at 4xL4 speed in CV, LB 66.39. Public Qwen agents are weak (15-27), "implementation quality decides".
- Eric Pang library: execute frozen public-training programs on train pairs, retrieve top 2 as priors; ArunSehrawat corpus: 383 verified ARC-AGI-2 training programs (222 manual, 158 BARC, 37 LLM). Dominic: 67-function library checked before any GPU reasoning.
- Not useful: low effort / many short traces (ARC Prize low 22.8 vs xhigh 42.4; medium 13.2); NoWait / answer-probe exits; reasoning_effort "high" invalid.

## 8. Recommendations on record that were never executed

1. Prompting against hand-simulation at full budget (V3 ALLFIX ideas; E10 Part D #2 "code execution during reasoning").
2. Fact sheet / pre-computed facts in the prompt (objects per colour, bounding boxes, changed cells, shape rule; literature +5-10) - downgraded on the 6.4 % metric.
3. Grid-format A/B: CSV or explicit (R x C); `|` every 4 cells.
4. Verified checkpoint at 49k (force a program, run on train, resume on fail; ~0.35 M net; gives code to 52 forced traces that never write any).
5. Forced-close salvage (program from cached prefix, train-checked).
6. Shape guard + answer-only rewrite (29/114 misses had wrong shape).
7. Gold-free safety checks after train pass (program contains train outputs literally; test output == test input; shape/colour rule broken).
8. Temperature A/B 0.6 vs 1.0 (MTP 3.01 vs 2.67 tokens/step, ~+13-17 % speed); MTP k=4; presence_penalty 1.5.
9. Rule-based fallback for unreached tasks (constant output / identity / most common train output).
10. Protect code-writing units from preemption; KV admission gate <= 0.85; compile/JIT cache dataset (-4 to -5 min); clock from container start.
11. Ordering: smaller-cells tie-breaker; [>=3 train]+[1 test] score.
12. Label-blind selector (agreement 12/18 right when two first answers agreed; natural close; train fit; code length: train-perfect-wrong programs longer, L66 median 11,096 vs 6,545 chars).
13. Second independent attempt after a train pass (overfit tasks: fresh attempt 5/23 = 22 % right; feedback never runs there); near misses first for feedback (27 % vs 17 % fresh).
14. Frozen program library retrieval (LIB-Q27-E0), Noemon test-blind induction, Athanor artifact-only reviewer, compact research-state schema (current_hypothesis, verified_invariants, disproven_hypotheses, key_experiments, current_solve_code, train_failure_signature ...).

---

## Ideas relevant to making Duck compute in code from the start and cutting tokens per task

Constraint reminder (memory): thinking floor 60,000 applies to THINK_BUDGET, admission guard and rescues; any cut needs user approval. Ideas below avoid per-turn thinking cuts unless marked.

1. **Re-measure hand-reading on Duck traces with the paragraph metric (`sim_tokens.py`), not the 6.4 % line metric.** The 6.4 % downgrade used a narrow definition (>= 4 digits and >= 60 % digits per line, outside code) on a no-tool method. Token-level 22.7 % and paragraph-level 45-50 % are on record. Report per branch: tokens before first tool call, tokens in grid-heavy paragraphs before first check(), and tokens after "let me do this in code".
2. **Make the first action a tool call, by prompt and by preloaded state.** Evidence: code by 30k -> 77 % solved vs 30 %; code share AUC 0.80-0.87; 50.7 vs 7.7 hits per M past 49k. Qwen tends to call tools only after `</think>` (PIV v1.7), so the instruction has to come before thinking starts: "Do not read or count cells in your head; every count, coordinate, colour, diff and shape is computed with the Python tool; your first step is a tool call that prints a summary". This is V3 ALLFIX's never-tested idea, now at full budget.
3. **Give the REPL a ready fact layer so the first call is cheap and exact** (CoreThink "do not make the LLM perform raw perception arithmetic"; PiVOTools preload; KAAR/Xu/Greenblatt +5-10): helpers such as `summary(i)` (shapes, colour counts, background), `diff(i)` (changed cells as coordinate lists for same-size pairs), `objects(grid)` (components with bbox, colour, size), `shape_rule()`, `check(fn)` returning per-pair cell diffs. Put the one-screen output of these in the first user turn or have the model call them first. This is the "fact sheet", moved from prompt text into tool output.
4. **Cap and compact tool stdout** (Athanor/PiVOTools): block full-grid prints, return targeted slices and summaries, so code use does not itself inflate context and prefill (R5 prefill 4.18 M vs 1.14 M, KV 99.5 %).
5. **Grid format A/B in the Duck prompt** (never run): CSV or `R x C` header + row indices, `|` every 4-5 cells for wide grids. Cheap to test, targets misreads directly (35/36 branches).
6. **Encourage reusable helper functions and early, frequent check()** (PiVOTools): R5 shows 35 % of solved-trace thinking was mental re-checking after the first draft and a median of 5 drafts; auto-verify after every tool call (V3 ALLFIX) replaces that.
7. **Stop at first all-train pass, but use a second independent branch only when unsolved or for overfit insurance** (Kaggle summary lever 3; D66/L66 §7). One branch first, second branch for unsolved tasks keeps tokens/task near the 55-72k budget while keeping the union benefit (D66 ∪ L66 50 vs 28/34).
8. **Do not spend on text-heuristic early stops or pause/resume** (measured negative). Spend instead on protecting code-writing branches from preemption and on ordering (ORDER2 + smaller-cells tie-breaker; [>=3 train]+[1 test]).
9. **Frozen public-training program library as a zero-GPU first pass** (Eric Pang, Dominic, ArunSehrawat 383 programs): run on train pairs before the agent; a passing program costs no tokens and frees time for coverage. Low expected hit rate on eval-like tasks, but free.
10. **Rule-based fallback for unreached tasks and attempt_2** (delongyang), free.
11. **Context compaction with a fixed state schema** (khoinguyennguyen 80 % -> <= 32k; Athanor schema) to stop KV thrash seen in E12 EVAL30 (b1 never ran).
12. **Sampling for speed:** T 0.6 vs 1.0 A/B (MTP acceptance 3.01 vs 2.67 tokens/step) and presence_penalty 1.5 (khoinguyennguyen); both untested here, both throughput levers that do not cut thinking.
