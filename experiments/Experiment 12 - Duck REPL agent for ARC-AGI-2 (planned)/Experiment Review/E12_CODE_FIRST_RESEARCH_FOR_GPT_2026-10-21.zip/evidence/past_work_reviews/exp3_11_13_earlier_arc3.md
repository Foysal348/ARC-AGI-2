# Past optimization review: Exp 3, 11, 12-FP8, 13, Earlier Qwen3.8 work, ARC-AGI-3 Duck

Written 2026-10-21, read-only review. **[M]** = measured in a run log/report, **[I]** = inferred/estimate/plan.
Root paths: `X = D:/ARC AGI 2/experiments/`, `A = D:/ARC AGI 2/archive/Earlier Qwen3.8 experiments (2026-09-13 to 2026-10-04)/`, `R = D:/ARC AGI 2/resources/ARC-AGI-3 related/`.

---

## 1. Experiment 11: SGLang 0.5.21 + RedHat INT4 + DFlash2 (the engine E12 Duck runs on)

Files: `X/Experiment 11 .../README.md`; `Experiment Results/E11-03 run1 analysis (2026-10-17).md`, `E11-04 run1 analysis (2026-10-18).md`, `E11-05 run1 analysis (2026-10-18).md`, `E11-06 P1-60K EVAL14 run1 analysis (2026-10-19).md`; `Kaggle Runs/E11-03 .../e11_03/report.md`, `Kaggle Runs/E11-04 .../e11_04/report.md`; `Experiment Review/*.md`, `E11_05_ADMISSION_11_OF_12_FOR_GPT/README_FOR_GPT.md` + `derived_state_timeline.txt`.

### 1a. E11-03 (sweep, short ~4.3k prompts, 4,096 new tokens) [M]
- SGLang silently capped running requests via the mamba state cache. Slots per request: radix off 1, no_buffer 3, extra_buffer+overlap 5, extra_buffer_lazy 4. Real caps: A INT4 22, B +MTP 10, C +DFlash2 fp32 SSM **6**, D +DFlash2 fp16 SSM 13. `/get_server_info` still said 32; only the log warning shows the cap.
- Total tok/s at real concurrency:

| running | A INT4 | B +MTP(NEXTN 3/topk1/4) | C DFlash2 fp32 | D DFlash2 fp16 SSM |
|---|---|---|---|---|
| 1 | 45.6 | 55.1 | 93.7 | **107.5** |
| 4 | 145 | 205 | 250 | **278** |
| 8 | 229 | 297 | (cap 6) | **356** |
| 12 | 289 | (cap 10) | (cap 6) | **404** |
| 16 | 347 | — | — | (cap 13) 381 |

- Per-request rate D: 107.5 (1) / 72.1 (4) / 48.6 (8) / 34.8 (12) tok/s.
- Accept length: MTP ~3.1; DFlash2 (block 8) 3.9–4.95, typically 4.5–4.8. Long 12x24,576: A 282, B 262, C 258 (B/C capped, cold prefix).
- Memory D per GPU: weights 4.62, drafter 1.49, mamba 3.26, target KV 2.94, draft KV 0.92, prefill graph 2.60, verify graphs 0.88, **free 4.39 GB** (auto mem_fraction 0.62). KV only 387k (vLLM FP8 1.35M).
- Custom allreduce disabled on >2 PCIe GPUs → NCCL (64 MB in 20.9 ms). TP2 would allow it (untested).
- contcache: forced-close continuation cached ≥0.979, warm 11x faster than cold. longctx: 4 x 85.5k ctx at 238 tok/s server decode, KV usage 0.87 (only ~4 x 85k fit in 395k). Cold prefill ~1,400 tok/s.
- temp: T0.6 vs T1.0 = 0.846x speed, accept 4.60 vs 4.34 (capped at 6 running, inconclusive).
- Greedy drift: spec vs non-spec common prefix ~152–166/512 tokens; contam = batch non-determinism, not leakage.
- Launch: first 601 s (prefill-graph JIT 447 s), later 136–166 s.
- Sanity C: 7/8 (FP8 expect 6.74).

### 1b. E11-04 (capacity fix) [M]
- Config W1 = `--mamba-radix-cache-strategy extra_buffer_lazy --max-mamba-cache-size 56 --mamba-ssm-dtype float16 --disable-prefill-cuda-graph --mem-fraction-static 0.83 --max-running-requests 12`, DFLASH 8 draft tokens, `--speculative-draft-model-quantization unquant` (mandatory; else drafter inherits INT4, accept ~1.0), fp8_e4m3 KV, TP4, chunked prefill 4096.
- Result: **12 real running, KV 881,336 tokens**, 2.22 GB free. fp32 SSM arm: KV only 598,712.
- PROD closed loop (12 in flight, ARC prompts, ≤60k thinking, T1.0): **W1 fp16 416.5 tok/s**, W2 bf16 412.1. By mean context at 12: <10k 458, 10–20k 413, 20–40k 388 (≥40k not reached in 10 min).
- Short sweep at "12" really ran 11 (staggered prefill). Sweep W1: 1→110.6, 4→257.5, 8→363.8.
- Sanity W1 8/8, W2 7/8; marker leak test PASS; first launch 567 s, later ~75 s.

### 1c. E11-05 S49 Poetiq on SGLang, EVAL30 (production workload) [M]
- **328.9 tok/s over the whole solver** at 12 set / **11 really running** (vLLM FP8+MTP-3: R5 280.9 at 16, D66/L66 255.8/254.1).
- Decode by context at 11 running: <10k 429, 10–20k 372, 20–40k 340, **40–60k 323** (≈25 % below short context). Accept median 4.55. No retractions.
- **11-of-12 admission bug**: 2,358 decode lines at 11 running + 1 queued vs 114 at 12; the 12th waits until a request finishes (up to 24 min queue waits). Not memory: mamba 33–35/56, token usage ~0.49. Cost ~8 % throughput. Root cause NOT verified (candidates: ReqToTokenPool row held after abort/finish, PrefillAdder gate). Candidate fixes: `--max-mamba-cache-size 64`, server max-running 13 with client 12 (the E12 settings doc says E12 uses "server 13 / client 12").
- Prefix cache: forced-close phase 2 98.1 % cached (4.77M prompt tokens); phase-1 iteration ≥2 only 10.6 % (Poetiq reshuffles example order), iteration 1 18.4 %.
- Drain: aborted phase-1 → phase-2 hit cache 52–99.7 % only when the client waited for the aborted stream to end; all drained answers ≤83 s.
- Accuracy: 11/48 (task-norm 23.3 %) vs R5 16/48 on same tasks; 83/88 iterations force-closed at 49,152; 7/15 train-verified overfit (b5ca7ac4: hit the cap while hand-simulating the test grid, then hard-coded lanes).
- `--stream-interval` must be 1 with DFLASH (interval 8 can hold back deltas, `output_streamer.py:427-436`).

### 1d. E11-06 P1 prompt redesign (Poetiq, 60k) [M]
- Solver template 1,248 → 429 tokens; iteration-2 message 9,204 → 6,392 tokens. Prefill 0.89M vs decode 4.25M tokens in EVAL30: prompt length is not the speed lever; **generated thinking is**. Measured: test-grid simulation + code dry-runs = 10–11 % of thinking (`_scratch/session_1c6db7aa/e11_05_runs/sim_tokens.py`).
- P1 rules: "sandbox checks your code", no hand execution, no writing out grids, no computing the Challenge output, "write the code and stop", 2-program feedback (not 5), stable example order.
- EVAL14: 7/22 vs 5/22, task-norm 35.7 % vs 28.6 % (+1 task, sd ~1.7 → not significant); train-verified precision 5/6 vs ~4.5/8; still 89 % forced closes at 60k (natural closes median 35k); **379.9 tok/s, 87.2 % cached prompt tokens** (stable order raised cache from ~11–18 %), max 12 active.

## 2. Experiment 12 (FP8 kernel tuning on L4), planned, never run
File: `X/Experiment 12 - FP8 kernel tuning on L4 (planned)/README.md`. [I] vLLM 0.19 runs all 5 block-FP8 GEMM shapes (N,K = 8704x5120, 5120x4352, 5120x1536, 4096x5120, 3584x5120) with the untuned default Triton config ("Performance might be sub-optimal"); FP8 Marlin disabled on cc ≥ 8.9 unless `VLLM_TEST_FORCE_FP8_MARLIN=1`. Notebook E12-K1 built (tuner + engine bench) but no results. Relevant only to the vLLM FP8 path, not the SGLang INT4 path.

## 3. Flash-Next (Exp 3 closed, Exp 13 planned)
Files: `X/Experiment 3 .../README.md`, `Experiment Results/Kaggle Runs/FN_PROBE_v421_run1/fn_smoke/fn_smoke_report.json`, `Build/FN_FP8PLE_build_R1/*`; `X/Experiment 13 .../PLAN.md`, `VALIDATION.md`, `Experiment Review/*.md`.
- **E3 [M]** (Pennyroyal 0.5.19, Intel W4A16 AutoRound + FP8 PLE overlay, TP4+EP4, 4xL4): `--weight-loader-prefetch-checkpoints` cut weight load to 345 s (124.8 GB); ready 862 s (~7 min Triton/TileLang JIT); 19.06 GB weights/GPU, 2.55 GB free after load, 0.66 GiB free after warm-up; KV 118k bf16 tokens; output garbage ("!!!!", token 0; TileLang data-race warning); ~6 tok/s single-stream eager (96 tokens in 17.8 s). Closed as not viable.
- **E13 [I]** (never run on GPU): SGLang 0.5.21 + Franzen patch #3 + classic FA2 decode (upstream sm89 parity 16/16) + NEXTN off, chunk 2048, mem 0.93, 4 running; estimated KV 150–210k fp8 tokens (6 KiB/token/rank) → **2–4 resident Duck contexts** at E12's p50 47.9k / p90 97.7k prompts; to beat 27B W1 (~420 tok/s) Flash-Next needs 420/210/140 tok/s per stream at 1/2/3 streams. Host RAM: BF16 PLE 107.6 GB pinned of 202.6 GB. Session ~60–70 min to measure.
- **Elsewhere [M]**: ARC-3 Flash-Next NVFP4 on RTX PRO 6000 via vLLM: ~248 tok/s at ~3 running (KV 5 GiB, max_num_seqs 8) vs Franzen's Pennyroyal SGLang TP1 + NEXTN + FR-Spec 590–617 tok/s on the same GPU class (2.4x from engine/KV config alone). Forum (memory, user-relayed): "Flash-Next on L4 (Triton) is not fast". amn 70.28 was first labelled Flash-Next, later corrected to "not shown" (VALIDATION #23).

## 4. Earlier Qwen3.8 work (2026-09-13 → 10-04)
Files: `A/V3 EVAL120 Baseline and S12 Subset/Experiment Results/CANONICAL_BASELINE_EVAL120_2026-10-03.md`, `PIV_Q27_V31_S12_RESULT_2026-10-04.md`, `Experiment Review/PIV_Q27_V3*_REVIEW_BUNDLE*.zip` (PROMPT_FOR_REVIEWER.md, docs/V31_CHANGES_VS_V3_REVIEW.md); `A/TP Throughput Probe/Experiment Results/TP_Q27_PROBE_V124_SMOKE_MASTER_EVIDENCE_*.zip` (REPORT.md, analysis/*.csv); `A/EVO Program Evolution/Experiment Results/Kaggle Runs/EVO12_run/eval120/evo_report.json`; memory `arc-agi2-qwen27b-project.md` lines 13-17.
- **Engine history [M]**: Q1 vLLM enforce_eager: 6 tok/s/seq, 51 aggregate. TP probe v1.2.4 SMOKE: C0 eager 37.7 tok/s @16; CUDA graphs 48.95 @16 (+30 %); custom allreduce at TP4 0.9995x (no effect); prefix caching + max_num_seqs 64 → EngineDeadError/timeout; TP2 KV only 17,248 tokens → failed. KV 160–168k tokens then.
- **PIV REPL baseline EVAL120 [M]** (ACT-LOW, 8,192 tok/task, conc 12): 1.67 %; **49/120 zero-tool tasks: all 49 first turns spent all 6,144 tokens with row-by-row grid transcription**; only 3/173 tool calls defined and ran `solution()` on train pairs; exploration 65.3 tok/s at mean active 4.75; 29.1 % of wave time with ≤2 active requests.
- **V3.1 fix [M]** (low effort + forced `</think>` after 2,048 thinking tokens + prompt forbidding transcription + auto-build/verify a candidate module after every tool call + preloaded helper library + backfill): **0/12 zero-tool, 12/12 first turns end in a tool call, think p50 664 tokens**, 0/10 finalizer truncations, 7/7 REPL-vs-fresh fidelity. But Strict 1/12 = baseline: low budget + low effort did not find rules; "near misses" were identity-level.
- **PIV-P0 [M]**: at xhigh, 8/8 tasks hit 12,288 inside the first `<think>`, 0 tool calls (the template only allows a tool call after `</think>`).
- **ACT probe [M]**: low effort first tool call after ~21 think tokens median (engagement 0.875) but 4/7 second turns >3,072 think; medium 8/8 first turns >3,072 think (0.125); forced close at 3,072 worked 7/8.
- **EVO12 [M]** (medium, 3,072 think cap, vLLM graphs, no prefix cache): 0 natural closes, 0 train-exact; 172 → 141 → 101 tok/s as rounds emptied (occupancy).
- Effort reference (memory `arcprize-qwen38-effort-scores.md`): xhigh 42.4 % semi / ~60k out tok/request; low 22.8 %; medium 13.2 %; our W3H low = 9.88 %, 78 % EOS mid-thinking.

## 5. ARC-AGI-3 Duck (how Duck stays token-efficient)
Files: `R/P1_SPARSE_RUN_EVIDENCE.zip` and `(1).zip` (extracted copies in `_scratch/session_1c6db7aa/past_opt_review/p1zip/a|b/`), `R/notebook6e705f697b1.ipynb`, `R/ARC3_top10_kv/01_dfranzen__.../arc-agi-3-milestone-2-solution.ipynb` (cell 2 patch, 10,087 lines), `X/Experiment 12 - Duck REPL agent .../Duck milestone-2 exact settings (from dfranzen notebook).md`.
- **Our ARC-3 runs [M]** (vLLM Flash-Next NVFP4, RTX PRO 6000, ctx 32,768, T0.6/top-p 0.95/top-k 20, MTP 3, prefix caching OFF, KV 5 GiB, max_num_seqs 8, solver concurrency 28, 25 games x 7,920 s): B0 6.49 (32 lv); P1_SPARSE (prompt-only, +351 chars) 6.91 (35 lv) and 6.81 (39 lv).
  - Per run: 1,340/1,353 model calls, **1,477/1,430 generated tokens per call**, ~54 calls/game, 2.9/2.5 actions per call, 1.98M/1.93M generated tokens (~248 tok/s), 56.6k/49.6k tokens per level.
  - **Prompt tokens 27.6M vs 1.98M generated (14:1) with prefix caching off**; 1,366 stop / 7 length finishes; 20 preemptions.
  - MTP: 712,659 draft steps, 2.14M drafted, 1.27M accepted (59 %; per position 0.76/0.58/0.45) → ~2.78 tokens per step.
- **Duck prompt/tool design [M, from prompt text]**: the raw numeric grid is not exposed; `segmentation` objects are the primary view; "Always inspect ... from Python instead of reasoning from the raw board by eye"; "Never print or echo full board frames"; tool output capped 1,024 tokens (Franzen 3,072); 30 s per call; "Do not ration tool calls"; batch actions inside Python; write BFS/search code.
- **Franzen milestone-2 harness [M, source]**: `LOCAL_ANALYZER_YIELD_TOKENS 2048` (after ≥2,048 generated tokens in a turn, the turn ends at the next request boundary and resumes with "your tool results are still valid, continue"; a no-tool turn gets "Stop deliberating and call the python tool NOW"); `MAX_OUTPUT 12,288` per request; context window 131,072 with drain at 58k; persistent (retained) functions across calls; `preserve_thinking`; streaming; priority scheduler with MAX_ACTIVE_STREAMS 10 and tail fade; optional `ARC3_REASONING_EFFORT_LADDER` (step effort down after a truncated generation, restore after progress); T0.7. SGLang flags: `--schedule-policy lpm --enable-cache-report --mamba-track-interval 64 --page-size 64 --reasoning-parser qwen3 --tool-call-parser qwen3_coder`.

---

## Lessons relevant to throughput and token efficiency for the Duck REPL agent on 4xL4

1. **The engine ceiling is ~1.6x what 6 streams use [M + I].** W1 gives 416 tok/s at 12 real (short/medium ctx) and 323 at 40–60k ctx with 11 running; the sweep gives ~257 at 4 and ~364 at 8, so the E12 Duck's 244–265 at 6 streams with ~50k contexts is roughly what the engine delivers at 6. Going to 11–12 streams is worth about +30–60 %. It needs resident context ≤ ~881k/12 ≈ 70k per stream, so a Duck context cap/drain near Franzen's 58k drain is needed. Otherwise you get KV thrash (E12 EVAL30: 8.4M re-prefill tokens).
2. **Fix the 11-of-12 admission (≈8 %)** with server max-running 13 / client 12 or `--max-mamba-cache-size 64`, and assert the real running count from the decode log on every run [M bug, I fix].
3. **Prefix cache is the hidden cost in multi-turn [M].** Cold prefill is ~1,400–1,650 tok/s for the whole engine, so one 50k re-prefill costs ~30–35 s of engine time. Keep earlier turns byte-stable (P1's stable order: 11–18 % → 87 % cached). Wait for aborted streams to end before resubmitting (52–99.7 % vs 0 % cached). Avoid ARC-3's mistake: caching off, 14:1 prompt:generated.
4. **Spec/engine flags to keep [M]:** DFLASH block 8 with an `unquant` drafter (accept ~4.5 vs MTP ~3.1); fp16 SSM (2x mamba slots vs fp32, sanity 8/8); extra_buffer_lazy (4 slots/request); no prefill CUDA graph (frees 2.6 GB → KV 387k → 881k); `--stream-interval 1`. Untested options: lpm, page-size 64 / track-interval 64, TP2x2 replicas with custom allreduce.
5. **Hand-reading grids is an old, known failure with a known mechanical fix [M].** PIV: 49/120 first turns burned the whole budget on row-by-row transcription. Forcing an early `</think>`, forbidding transcription and auto-verifying code → 12/12 first-turn tool calls (think p50 664). Caveat: low effort and short forced budgets alone did not add solves (V3.1, EVO12, W3H). The fix must move thinking into code, not cut it. The user's 60k thinking floor applies; Duck's 12,288 per-request cap is an approved exception.
6. **Copy the ARC-3 Duck mechanics that keep calls at ~1.4k tokens [M design, I transfer]:** do not show full grids in the prompt text; give them as Python variables plus object summaries. Add a per-turn yield after ~2k generated tokens with a "continue from your tool results" resume. Add a no-tool nudge ("call python NOW"). Use retained functions, compact tool output (≤1–3k tokens) and no full-grid printing. Optional: an effort ladder on truncation.
7. **Flash-Next is not a near-term throughput fix on 4xL4 [M + I].** E3: garbage and ~6 tok/s. E13 is unrun, with an estimated 150–210k KV, i.e. only 2–4 Duck contexts. It needs >140–420 tok/s per stream to beat 27B W1.
8. **Occupancy has repeatedly cost 20–40 % [M]:** PIV 29 % of time at ≤2 active; EVO 172 → 101 tok/s; E12 branch 1 never started. Admit new work immediately (backfill / priority scheduler), with a per-branch cap.
