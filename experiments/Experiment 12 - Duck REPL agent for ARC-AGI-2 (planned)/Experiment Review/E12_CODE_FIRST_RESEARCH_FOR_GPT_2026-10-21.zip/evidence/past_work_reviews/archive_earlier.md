# Archive review: earlier Qwen3.8 experiments (2026-09-13 to 2026-10-04)

Scope read: `D:/ARC AGI 2/archive/README.md` and everything under
`D:/ARC AGI 2/archive/Earlier Qwen3.8 experiments (2026-09-13 to 2026-10-04)/`: all .md docs, every zip bundle
(extracted to `_scratch/session_1c6db7aa/past_opt_review/extract/`: REPORT_FOR_CHATGPT, measurement/arm jsons,
review prompts, ledgers, rendered prompt, helper library, builder `make_v3.py`), EVO12 run outputs, and the
markdown + outputs of all 49 notebooks (dumps in `past_opt_review/nbclean/`), plus the prompt/config code of the
V3.1-S12 and EVO notebooks. Harness logs (`h*_*.txt`, `v3*_*.txt`, `sub_*.txt`) are fake-engine control-flow tests,
not model behaviour; read for what they test only.

Labels: **M** = measured on real GPU / from run files; **I** = inferred; **H** = fake-engine harness only.
Setting of all of this: Qwen3.8-27B-FP8, vLLM 0.19, TP4, 4xL4, budgets 8k-32k tokens/task (far below today's 60k floor).

---

## 1. Q1 Direct baseline (PROXY48), 2026-09-13
Path: `.../Q1 Direct Baseline (PROXY48)/` (bundle `Q1_DIR_Q27_PROXY48_BUNDLE.zip`, run v1.2 `20260913T134749Z`)
- What: direct grid answer, no tools; OFF (4,096 cap, batch 16) vs XHIGH (12,288 cap, batch 8), 48 eval tasks / 56 outputs.
- M: OFF 0/56, XHIGH 0/56, union 0. XHIGH: 48/48 hit 12,288 (`length`), parse-valid 0 %, never closed `</think>`.
  OFF: parse-valid 60.4 %, 37.5 % length-capped, avg 2,217 tokens. Total 233.5 min; XHIGH 589,824 tokens.
- Lesson (journal): raw generation insufficient; use program + fresh verifier as authority.

## 2. PIV-P0 Stateful REPL agent v1.0-v1.7, 2026-09-14
Path: `.../PIV-P0 Stateful REPL Agent/`; real run = Kaggle `experiment-1... (11).ipynb`, bundle `PIV_Q27_P0_SMOKE_GPU_BUNDLE.zip`, run `20260914T122911Z`.
- What: PiVOTools/gutfeeling source prompt ported to vLLM + Qwen tool XML, persistent REPL with `puzzle` preloaded,
  fresh-process all-train verifier, XHIGH, 6 calls / 12 turns / 12,288 tokens.
- M (v1.7 SMOKE8): tool engagement 0/8, final programs 0/8, 8/8 used all 12,288 tokens inside the FIRST `<think>`.
  0.160 s/output token (eager engine).
- M (my re-analysis of the bundle traces): the XHIGH first-turn thinking is hand-reading grids: per task median
  ~275 "row N / col N" references, ~122 "(r,c)" coordinate tuples, ~6 % of characters are pure digit-row lines
  (e.g. "Row 0: 2 0 2 0 6 0 6 4 ..."). Every trace opens with "First, let's start by examining the puzzle data"
  and then never calls the tool.
- Root cause stated: Qwen3.8 template puts tool calls after `</think>`; under XHIGH the model must finish solving
  in its head before it can act. "XHIGH natural reasoning is a retired path under this budget."

## 3. ACT reasoning-activation ablation v1.8/v1.9d, 2026-09-15
Path: `.../ACT Reasoning-Activation Ablation/`; bundle `PIV_Q27_ACT_V19_PROBE_GPU_BUNDLE.zip`, run `20260915T124541Z`
(PROBE budget 3,072/turn, 5,120 total, 2 calls, 8 tasks).
| arm | tool engagement | first-turn tool call | think tok/turn p50 | gen tok/task |
|---|---|---|---|---|
| XHIGH natural (ref) | 0.00 | 0 | 12,288 | 12,288 |
| LOW natural | 0.875 | 0.625 | 715 | 3,011 |
| MEDIUM natural | 0.125 | 0.00 | 2,560 | 5,083 |
| XHIGH + forced close at 3,072 | 0.875 | 0.875 | 3,072 | 4,819 |
- M: `reasoning_effort="low"` (template injects "keep your thinking brief") and forced `</think>` both make the
  model act; medium does not (medium < low again, consistent with ARC Prize's medium 13.2 % < low 22.8 %).
- Mechanism kept: byte-exact Qwen stop text `"\n\nConsidering the limited time by the user, I have to give the
  solution based on the thinking directly now.\n</think>\n\n"`, token-exact continuation via `prompt_token_ids`,
  ACTION_RESERVE so the forced turn still has room to emit a tool call. `"high"` is not a valid effort.
- Lesson: "forced close only exits thinking; it does not guarantee a tool call or final code"; activation != solving.

## 4. TP throughput probe v1.0-v1.2.4, 2026-09-16
Path: `.../TP Throughput Probe/`; bundle `TP_Q27_PROBE_V124_SMOKE_MASTER_EVIDENCE_...zip`.
- M: eager C0 48.3 tok/s agg @8; CUDA graph (enforce_eager=False) 129 tok/s @8 long decode (2.67x); custom
  all-reduce no gain; prefix caching @64 seqs and TP2 runs died (EngineDeadError/OOM); KV 160-168k tokens.
- Greedy-prefix "numerics" gate retired (C0 repeated against itself scored 0.19).

## 5. C1 terminal-commit and repair v2.0-v2.5B, 2026-09-17/18
Path: `.../C1 Terminal-Commit and Repair Solver/`; v2.4G journal notebook
`PIV-Q27-C1-v2_4G-EXECUTED-ANNOTATED-PROJECT-JOURNAL.ipynb` (canonical chronology); audit
`Experiment Review/PIV_Q27_C1_V25_FAKE_ENGINE_AUDIT_2026-09-18.md`.
- v2.3 C1 quality smoke (M, run `20260917T114401Z`, LOW + XHIGH-forced-3072, 12,288 budget): tool use 7/8 and 8/8,
  but **0/16 final programs**; budget death 100 %; LOW spent ~92 % of generation in thinking; forced close led to
  more tool calls / malformed actions, not a program. 0.046 s/token (C1 engine).
- v2.4G (M, run `20260918T104631Z`): exploration hard cap 8,192 + protected 4,096 non-thinking no-tool JSON
  finalizer: 16/16 final programs, syntax-valid, verified; **0/16 all-train-exact**; best was LOW 291dc1e1 2/4 pairs.
  LOW 9,180 tok/task, 17/17 tool calls OK; BUDGET3072 9,371 tok/task, 5 actions cut at exactly 768 tokens.
  78.2 min total. Lesson: plumbing fixed; semantic rule discovery is the blocker.
- v2.5/2.5A (H): one non-thinking verifier-feedback repair call (<=600-token diff feedback: dims, wrong-cell
  count, sample mismatches, identity flag). Audit found two P0 crash bugs before GPU. Repair cap was the leftover of
  the same 12,288 budget (1,229-3,256 tokens), smaller than candidate #1's own JSON for 3/8 LOW tasks.

## 6. PIV-SUB hidden-test submission v1.0-v1.3 + EVAL120 measurement, 2026-10-02/03 (LB 1.67)
Paths: `.../PIV-SUB Hidden-Test Submission (LB 1.67)/` (handoff, v1.1/v1.2 review responses, Kaggle runs review zip
with `analysis/ANALYSIS_SUMMARY.md`); `.../V3 EVAL120 Baseline and S12 Subset/Experiment Results/CANONICAL_BASELINE_EVAL120_2026-10-03.md`.
- Recipe: ACT-LOW natural, 8,192 tokens = 6,144 explore + 2,048 finalizer, 6 calls / 12 turns, concurrency 12, repair on.
- M EVAL120: Train-Verified 3/120, Strict 2/120, **1.67 %**; LB 1.67 (matched). 4.56 h wall (16,405 s).
  Exploration 716,922 tokens at 65.3 tok/s, mean 4.75 active; finalizer 38.8 tok/s; 29.1 % of wave time with <=2
  active requests (synchronous waves, no backfill). Think share of generated tokens 72 %.
- M: **49/120 zero-tool tasks; every one = first turn 6,144 tokens, `length`, no `</think>`, row-by-row grid
  transcription.** My trace re-analysis: those 49 first turns have median 113 row/col references, 51 coordinate
  tuples, ~10.5 % of characters pure grid rows. The other 71 tasks called the tool after a median of **173 tokens**
  (p90 2,916). Think tokens/turn bimodal: p50 94, p90 6,144.
- M: 0 tool calls -> 0/36 train-exact; >=1 tool call -> 3/42. Only 3 of 173 tool calls defined AND ran a full
  `solution()` on the train pairs (one per verified task); `puzzle.keys()` (the source prompt's mandated first call)
  was in 65/173 calls, 11 calls were only that. Verified tasks used 2-3 tool calls and 2,390-6,744 tokens.
- M: 38/120 finalizers truncated at exactly 2,048 (successful median 929.5, max 1,824); failed finalizers were
  ~65 % comment lines (reasoning moved into code comments). Repair: 52/79 parse failures, 0 new verified.
- M: same pipeline on the 240 training-copy placeholder test = 113/259 = 43.6 % (training-level tasks are easy).
- Sampling: agent temp 1.0, top_p 0.95, top_k 20, min_p 0 (Qwen thinking defaults); finalizer temp 0.7 -> 0.1 in V3.

## 7. V3 / V3.1 all-fix and V3.1-S12, 2026-10-03/04  <-- "the optimization done before"
Paths: `.../V3 EVAL120 Baseline and S12 Subset/Experiment Notebooks/PIV-Q27-V3_1-S12-EVAL-SUBSET.ipynb`,
`Experiment Results/PIV_Q27_V31_S12_RESULT_2026-10-04.md`, review zips (contain `build/make_v3.py`,
`build/piv_library.py`, `docs/rendered_user_prompt_1818057f.txt`, `docs/V31_CHANGES_VS_V3_REVIEW.md`).
Changes aimed exactly at "think in code, not in the head":
1. Prompt `# Workflow (STRICT)`: "Never transcribe, restate or enumerate grid rows or cell values in your reasoning.
   The grids are already in `puzzle`; inspect them with Python instead." / "Keep your thinking short. Your first
   Python execution should call `arc_overview()`." / "By your second Python execution at the latest, define a
   complete `solution(grid)`..." / "Do not put reasoning into code comments." Removed `puzzle.keys()` instruction.
2. Preloaded tested helper library in the REPL (and prepended to every verified program): `arc_overview()`
   (per-pair shapes, colour counts, changed-cell count, top in->out colour changes, component counts, test shapes,
   no grids printed), `verify_solution()`, `components()`, `bbox`, `crop`, `rot90/flip/transpose`, `color_counts`,
   `background_color`, `grid_shape`, `diff_cells`.
3. Auto-verify: after every tool call that defines/changes `solution`, a standalone module is built from REPL
   history (symtable-based dependency builder) and fresh-verified; the PASS/DIMS/wrong-cell report is appended to
   the tool output; REPL-vs-fresh fidelity check.
4. Verbatim commit when train-exact AND test runs (task ends, no finalizer rewrite).
5. ACT-LOW-FORCED: low effort + forced `</think>` at 2,048 think tokens per turn; full 2,048 action reserve.
6. Finalizer 4,096, code-only, temp 0.1, structured handoff = best candidate + verifier report.
7. Dynamic backfill of finished slots; near-miss-aware candidate ranking; repair OFF.
- M (S12, 12 tasks, 12,288 budget, run `20261003T173130Z`): zero-tool tasks 49/120 -> **0/12**; first turn ends in
  a tool call **12/12, think p50 664 tokens**; finalizer truncation 38/120 -> 0/10; auto-verified 4/12 tasks
  (7 runs, 7/7 fidelity match); 2 verbatim commits. Loop 1,553 s for 12 tasks (~38 min wall incl. 643 s setup);
  projection 3.5-4 h for 120.
- M: Train-Verified 2/12 and Strict 1/12, identical to baseline; **0 new solves**. The baseline "near misses" were
  identity-level (wrong-cell fraction of the program ~= that of returning the input).
- Stated lesson: "The plumbing is fixed: the model now acts, tests, finalizes and commits as designed. The bottleneck
  is rule discovery: on hard tasks Qwen3.8-27B at this budget does not find the transformation. Only 4/12 tasks ever
  produced a solution() worth testing." I (inference): at low effort + 2k forced close, the token cut came with a
  reasoning-depth cut; the later xhigh/60k results (34.58 LB) show depth is what solves.

## 8. EVO program evolution EVO12 (GPU) / EVO24 (built, not run), 2026-10-04
Paths: `.../EVO Program Evolution/` (`EXPERIMENT_PLAN_2026-10-04.md`, `Build/EVO24_build/cell_evo.py`,
REVIEW_LEDGER/RESPONSE R1-R3, DUAL_MODE_CHANGE; results `Experiment Results/Kaggle Runs/EVO12_run/eval120/evo_report.json`).
Note: archive README says "no GPU result", but EVO12 did run (`20261004T174414Z`).
- What: per task 4 independent no-tool candidates (lenses: none / objects / geometry / colours-counts), each writes
  `## Rule` + `solution()`; fresh verify; 2 repair generations on top-2 parents with wrong cells marked `*`;
  per-query pass@2. Medium effort, phase-1 think <=3,072 then forced close, answer <=2,048, cap 32,768/task,
  temp 1.0 / top_p 0.95 / top_k 20.
- M: 0/12 solved, 0 train-exact candidates; **natural think close 0/80 calls** (medium never closed within 3,072);
  code extracted 80 %; 29,307 tokens/task; 31 repair parents with gain <= 0 vs identity. Aggregate throughput
  172 tok/s (48 parallel single-shot calls) vs 65 tok/s for the multi-turn agent. Verdict WEAK / REDESIGN.

---

## Cross-cutting measured facts
- Thinking budget vs action: XHIGH natural never acts within 12k; low acts (median 173-715 think tokens) but
  ~40 % of low tasks still runaway-transcribe (6,144 cap) unless forced close + explicit no-transcription prompt.
- The single most effective prompt fix for "compute in code" was V3.1's workflow block + `arc_overview()` first call:
  first-turn tool call 12/12, think p50 664. Measured only at low effort with forced close; never measured at xhigh.
- Prompt text itself pushes transcription: the source prompt renders grids as space-separated digit rows and the model
  copies them ("Row 0: ...") into its thinking; the tool mandated by the source prompt (`puzzle.keys()`) wasted calls.
- Auto-verification after every `solution` definition worked mechanically (4/12 tasks, 7/7 fidelity) and is the closest
  ancestor of today's check().
- Reasoning leaks into code comments (65 % of failed finalizer text) when thinking is cut.
- Throughput: synchronous waves wasted 29 % of time at <=2 active; backfill fixed it (H, then M in S12). Single-shot
  batched calls ran 2.6x faster aggregate than multi-turn agent turns (172 vs 65 tok/s, different load).
- Medium effort is the worst setting (activation 0.125, never closes in 3k).

## Ideas relevant to making Duck compute in code from the start and cutting tokens per task
1. Re-use the V3.1 workflow block verbatim in the Duck system/user prompt (no transcription, inspect with Python,
   first call = an overview helper, `solution` defined by the 2nd call, no reasoning in comments). It turned 49/120
   zero-tool runaways into 0/12 and put the first tool call at ~664 think tokens. It was never tested at xhigh/60k;
   test it there (do not combine with low effort or a 2k forced close, which cut depth and gained 0 solves).
2. Preload the tested helper library into Duck's REPL and make the first action an automatic `arc_overview()` call
   whose output is injected into the first prompt as a precomputed fact sheet (shapes, colour counts, changed cells,
   in->out colour changes, components, test shapes). Then the model starts with computed facts instead of counting.
   Extend the sheet (symmetry, periodicity, object list per colour, diff bbox) since counting is what it does by hand.
3. Do not render full digit grids in the thinking-visible prompt as the only representation, or render them once in a
   compact form and say they are already in `puzzle`; the model copies "Row 0: ..." lines into thinking. Measured
   symptom: ~10 % of runaway-turn characters were pure grid rows plus 100+ row/col references. (Format A/B untested.)
4. Remove any prompt-mandated trivial first call (`puzzle.keys()` cost 65/173 calls); make the first call do real work.
5. Auto-check: every time `solution` changes, run check() automatically and append the report (V3.1 mechanism); verbatim
   commit when train-exact and test runs. This removes the "decide to call check()" step that today arrives at ~55k.
6. Detect runaway transcription online: the 49 failures were all first turns that never closed `</think>`. A streaming
   detector (digit-row lines or "Row N:" density in thinking, or N tokens without a tool call) could inject a nudge or
   a forced close into a tool call instead of letting 55k pass. The archive measured forced close at 2-3k as activation-
   positive but quality-neutral; a late one (e.g. no tool by 15-20k) with the stop text + "now write code" was never tried.
   Keep within the 60k thinking-floor rule: this changes when code starts, not the floor.
7. Keep thinking out of code comments and keep the finalizer code-only (65 % comment share in failed commits).
8. Throughput: backfill slots immediately; prefer batched independent calls where possible (172 vs 65 tok/s measured).
9. Identity-relative metrics: measure near-miss progress against the identity program (S12 lesson), so cheap-token
   variants are not mistaken for progress.
10. Avoid medium effort entirely (worst activation and closure, matches ARC Prize medium 13.2 % < low 22.8 %).
