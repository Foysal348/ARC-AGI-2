# Past-optimization review: PDFs in "Analysis and Journals" + "Research Papers"

Reviewer: subagent, 2026-10-21. Read-only review.

## Method and coverage

- The Read tool could not render PDFs here (no poppler). I extracted the full text of every page with pypdf and read every page in full. Extracted text is in the scratchpad (`pdftxt/d1..d9.txt`).
- Page numbers below (`p.N`) are physical PDF pages.
- Several PDFs use a Bengali + English mix: the Deep Audit, the Handoff, most of the Canonical Journal header, and all of High_Score_Systems. Their extracted text has the English words run together. Every number and English claim was still readable.
- **Duplicates:**
  - `ARC_AGI2_Qwen38_Canonical_Project_Journal_2026-09-18.pdf` and `... (1).pdf` are **byte-identical** (same MD5 41343f20...). I read it once.
  - `Portability_Notes_v10_Source_Verified_ENGLISH.docx` has **the same content** as `Portability_Notes_v10_Final_English.pdf`. I checked section by section and the v10 audit appendix matches. I read the clean docx text and took page numbers from the PDF.
  - `Experiment_Master_Plan.docx` has **the same content** as `Experiment_Master_Plan.pdf`. I compared the headings and all sections.
- Labels used below:
  - **[MEASURED]**: an internal executed result, or a result an external source reports as measured.
  - **[PROPOSED]**: a recommendation or plan.
  - **[NEVER-EXECUTED]**: a recommendation these documents say had not been run yet. They date from Sep 2026; later runs are not covered here.

---

## 1. ARC_AGI2_Agentic_Solver_Portability_Notes_v10 (52 pp, 2026-09-13), plus its identical docx

**Summary.** A source-verified audit of 12 external high-score ARC-AGI-2 systems. It keeps only the mechanisms that can be ported to offline 4xL4 Qwen3.8-27B (at the time: FP8, vLLM 0.19, ~30K "practical context"). For each system it gives an experiment ladder, keep/drop metrics, and a "do NOT port" list.
- The document itself is all [PROPOSED].
- The numbers it quotes from external sources are [MEASURED] by those sources (public/self-reported unless stated otherwise).

**Key numbers (external, as reported):**
- Confluence 97.92% public eval (p.2).
- Squeeze-Evolve 97.5% (N=4, K=2, T=10) (p.3).
- Athanor 113.83/119 = 95.7%. This is an upper envelope of selected checkpoints: 89/119 used the final prompt and 30 used earlier drafts (p.6, p.10).
- Imbue 95.1%: fitness = 0.90·correctness + 0.07·transfer + 0.03·simplicity; sharpness 10, p99, novelty 0.2, up to 16 iterations (pp.11-14).
- Noemon 92.5%, with the public split label inconsistent (Eval vs Train) (p.15).
- ARCgentica 85.28% (Opus 4.6, about $6.94/task). Up to 10 agents allowed but **2.6 agents per attempt on average**; delegation is triggered by uncertainty. Two attempts, 5 s transform timeout (pp.20-21).
- **PiVOTools same-model REPL lift** (p.26):

  | Model | Plain | Agentic coding |
  |---|---|---|
  | GPT-OSS-120B High (self-hosted vLLM) | 6.11% | 26.38% |
  | MiniMax M2.1 | 3.06% | 10.56% |
  | GPT-5.2 XHigh (107-task slice) | 59.81% | 73.36% |
  | GPT-5.2 (all 120) | 53.33% | 68.33% |

- Poetiq 54.0% semi-private, ARC Prize verified. Released defaults: max_iterations=10, max_solutions=5 (pp.31-33).
- Johan Land: candidate oracle 144/167 = 86.23% vs selected 128/167 = 76.65%; 22 generation failures and 17 selection failures (pp.33-36).
- CoreThink 24.4%, ensemble 30.8% (p.37).
- Berman 29.4% semi-private (p.39).
- Eric Pang 26.0% semi-private; 538 stored programs from 1,000 training tasks (pp.41-42, p.47).
- ArunSehrawat corpus: verified programs for **383 public-training task IDs** (222 manual, 158 BARC, 37 LLM-assisted) (p.51).
- An ARC-AGI-1 study reports selection captures about 95% of the candidate ceiling, i.e. the system is generation-bound (p.52).

**Ideas relevant to tokens, code-first, REPL and verification (page refs):**
- **Program as candidate; execution is authoritative**. Take the final grid from code, never from prose (p.2).
- **Exploration code is not the final code.** A `run_code` scratchpad deterministically checks object counts, connectivity, symmetry, colour maps, coordinates and invariants. A stateful runtime reuses helpers "avoiding repeated regeneration of the same analysis code" (§3.1 p.7).
- **Tool stdout must be canonical and compact.** Raw NumPy dumps or huge logs should not consume context. Cap long stdout and errors, save the full artifact to disk, and feed back only a compact tail (§3.1 p.7, §3.6 p.9).
- **PiVOTools loop** (§7.2 p.26): the puzzle is preloaded as a Python variable; imports and helpers persist; finish with one self-contained `solution(grid)`; a fresh process runs the all-train exact gate.
- **Interface details** (§7.4 p.27, §7.7 p.28):
  - Protect the puzzle object and suppress whole-puzzle printing.
  - "Explicitly discourage printing the entire puzzle. Ask for targeted slices, counts, object summaries and helper functions."
  - "Encourage reusable functions because the REPL is persistent."
  - Keep the tool timeout well below PiVOTools' 120 s.
- **Tool errors are evidence** (§7.6 p.28):
  - Python syntax/runtime error: return a short traceback tail.
  - Train mismatch: return the mismatch index plus a compact shape/cell-diff summary.
  - Timeout: say which call timed out.
  - Malformed tool call: send one correction.
  - Infrastructure errors are never fed back as puzzle evidence.
- **Preserved-thinking failure signature** (§7.8 p.29): "Model repeatedly re-derives the same facts, forgets successful helper functions or terminates right after first tool call". These should be counted as agent-loop failures, not "model cannot solve ARC".
  - Proposed ablation PRESERVE vs COMPACT: after verified milestones, compress the old trace into invariants + helper code + failure signatures.
  - [NEVER-EXECUTED] in these docs.
- **PIV-Q27 ladder** (p.29-30), [PROPOSED]:
  - P0: about 6-8 tool calls.
  - P1: about 12 calls, on the hard subset only.
  - P2: a detailed-priors prompt vs a minimal tool-oriented prompt.
  - P3: preserve vs compact.
  - P4: an adaptive second lineage only for disagreement, near-miss or hard cases.
- **Poetiq (PTQ)** (§8, pp.31-32):
  - Each iteration is a fresh call. The puzzle is re-serialized, plus the top-K partial programs with deterministic feedback (solved flags, shape mismatch, cell diff "pred/correct", soft score, verbatim errors), shown in improving order. Train order is shuffled per iteration.
  - Stop immediately when a program is train-exact.
  - "The model should never score its own train correctness."
  - PTQ-T0: 3-4 rounds, K=1.
- **Imbue mutation prompt** (§4.3 p.11-12):
  - For same-shape tasks, render the input/output differences explicitly "so changed cells are easy to inspect"; failed predictions show pred/correct cell diffs.
  - Mutation strength is randomized: half the calls ask for a local repair, half for a rethink of the rule.
  - Once a parent is train-perfect, the objective becomes generalization on the test inputs.
  - Test predictions are shown back "without pretending they are correct".
- **CoreThink** (§10.1 p.37): "Deterministic object layer (HIGH): compute connected components, bounding boxes, centroids, colors, holes, symmetry, relative positions locally. **Do not make the LLM perform raw perception arithmetic.**"
  - Give the symbolic hint to ONE branch only, so the branches do not lose diversity.
  - Do not start with 5 repeated XHIGH calls; begin with deterministic features plus 2-3 bounded proposals (p.37).
- **Eric Pang library / LIB-Q27-E0** (§12 pp.41-42): execute library programs on the current task's train inputs; rank by exact count, then cell score; put the top 1-3 diverse programs in the prompt as priors. A keep metric is "Token/time savings: whether a retrieved prior reduces Qwen iterations/tool calls". [NEVER-EXECUTED]
- **ARCgentica prompt warning** (§6.7 p.23):
  - Do NOT copy the mandatory `scipy.ndimage.label` wording. "Expose the library, not the obligation."
  - Keep the constraints that matter: a general transform, verify every train pair, avoid arbitrary constants, debug by execution, prefer simple rules.
  - Keep a minimal-prompt variant in every ablation.
- **ARCgentica selection bug**: train-failing programs still took pass@2 slots. Gate on `train_exact_fit == 1.0`, dedup canonical grids, and keep near-miss programs as repair seeds (p.22).
- **Scoped child context** (§6.5 p.22): never clone the parent transcript; the child gets a packet of role_goal, train_pairs, hypothesis, code, failures and the specific question.
- **Squeeze routing** (§2.2-2.5 pp.3-4): consensus costs nothing; disagreement goes to the strong profile. With K=2 the routing is binary. The generic router has the direction reversed, so do not reuse it.
- **Noemon** (§5 pp.15-19):
  - Hide the test input until the rule is validated (an anti-overfit ablation).
  - Probe validation (2 examples) before the full sweep.
  - Invalidate cached passes whenever the rule changes; never claim train-exact from a union of passes across revisions.
  - Exact duplicates count as strong evidence only when their provenance differs.
  - Stage-wave execution: batch the same stage across tasks.
- **Johan** (§9.6-9.7 p.34-35): do not copy the raw-consensus stop (>25%, ≥11, others count 1). Prescriptive templates and shared hints reduce diversity. CSV serialization is worth a controlled Qwen test.
- **Implementation order** (pp.43, 52): PIV-P0 vs PTQ-T0 first, then LANG, then CORE/LIB, then JUD only when the oracle gap is real, then the heavier mechanisms. Official metric: output-weighted pass@2; label every denominator.

---

## 2. ARC_AGI2_Qwen38_Canonical_Project_Journal_2026-09-18 (14 pp; the "(1)" copy is identical)

**Summary.** The project journal up to the PIV v2.4G run. The harness bottleneck was solved; semantic program quality became the blocker. All [MEASURED] unless noted.

**Key numbers:**
- **v2.4G real 4xL4 run** (p.2-3):
  - 16/16 final programs, 16/16 syntax-valid, 16/16 verifier executions, 0 infrastructure failures, 0 budget deaths, **0/16 all-train-exact**.
  - 78.19 min total; model load 8.25 min.
  - Mean generated tokens per task: LOW 9,180, BUDGET3072 9,371.
  - Proxy-48 projection: 4.75 h (LOW), 3.64 h (BUDGET).
  - Best near-miss: 291dc1e1 (LOW) matched 2/4 train pairs; 136b0064 timed out in the train verifier (p.3).
- **v1.7 XHIGH**: 8/8 tasks consumed the full 12,288 tokens in first-turn thinking; 0/8 tool engagement, 0/8 programs (p.4).
- **v1.9d activation probe**: LOW 7/8, BUDGET3072 7/8, MEDIUM 1/8, XHIGH 0/8 (p.5). `reasoning_effort="high"` is invalid; only xhigh, medium and low exist (p.5).
- **Throughput v1.2.4**: C0 48.30 tok/s vs C1 (graph, no AR) 129.17 tok/s at long@8, about 2.67x; custom all-reduce gave no gain (p.5).
- **v2.3**: LOW put about 92% of its generation into thinking; 0/16 programs. "Bottleneck moved from can the model act to can it commit a standalone program" (p.6).
- **v2.4 design**: 12,288 tokens per task; exploration ≤8,192; protected final reserve 4,096; a non-thinking, tool-free structured finalizer (p.6).
- **LOW arm**: 17/17 tool calls OK; median unused budget after candidate #1 about 2,646 (worst case about 1,229). **BUDGET arm**: 22 calls (19 OK, 3 exceptions), 17 forced-close turns, 5 action-cap hits, median unused about 2,758 (p.8).
- Runtime estimate was 2.5-3.5 h; actual was ~78.2 min (p.9).

**Relevant lessons:**
- "Tool engagement is diagnostic only", i.e. not progress (p.9).
- "Forced close only exits thinking; it does not guarantee a tool call or final code" (p.5).
- The next mechanism was **one compact verifier-feedback repair round**: failed indices, execution error, bounded pred-vs-expected diagnostics. A hash check confirms the feedback is actually in the repair prompt (p.11). [PROPOSED] in this doc.
- "One major mechanism per experiment" (p.10). The user later revised this (see memory "bundle changes").

---

## 3. ARC_AGI2_Qwen38_Deep_Audit_Reference_2026-09-17 (14 pp, Bengali/English)

**Summary.** An audit of the evidence bundles before the C1 real-solver smoke. [MEASURED].

**Key numbers:**
- **v1.7 XHIGH SMOKE** (p.4-5): 8 tasks; 0% tool engagement; 100% budget death at 12,288 tokens; 0.16014 s per output token; Proxy-48 projection 4.06 h. "Dominant blocker was template/budget interaction: XHIGH remained in thinking until the entire task budget was exhausted."
- **v1.9d probe** (cheap canary: 3,072 tokens/turn, 5,120 total, 2 turns), p.5-6:

  | | XHIGH | LOW | MEDIUM | BUDGET3072 |
  |---|---|---|---|---|
  | Tool engagement | 0% | 87.5% | 12.5% | 87.5% |
  | First-turn tool call | — | 62.5% | — | 87.5% |
  | Median think tok/turn | 12,288 | **715** | 2,560 | 3,072 |

  - LOW: 9/9 executed calls OK; 0 exceptions, 0 timeouts, 0 guard rejects, 0 malformed; **3,011 mean tokens/task**.
  - BUDGET: 5/9 OK, 3 exceptions, 1 timeout, 2 guard rejections, 3 malformed; 4,819 tokens/task.
  - "LOW used about 37.5% fewer generated tokens per task than BUDGET3072 ... produced much cleaner executed tool calls" [INFERENCE in the doc: not a solving-quality verdict].
- **Throughput rows** (p.6-7): C0 37.68 / 23.59 / 48.30; C1 graph-noAR 48.95 / 31.45 / 129.17 (fixed@16 / mixed@16 / long@8). Fixed +29.8%, mixed +32.6%.
- **Failed rows** (p.7-8): Prefix64, TP2 noAR and TP2 AR OOMed. They burned **175.1 min = 68.0%** of the 4.29 h run because the parent did not fail fast.
- The greedy-prefix numerics gate was invalid: an unchanged C0 repeat scored only 0.1875 against a ≥0.50 threshold (p.7).
- Frozen engine config (p.11): max_num_seqs 16, max_num_batched_tokens 32768, max_model_len 29,696, gpu_mem 0.90.

**Lessons:** a passing self-test means nothing unless it exercises the property it claims to test (p.4). A passing PREFLIGHT says nothing about the model's behaviour (p.9).

---

## 4. ARC_AGI2_Qwen38_Experiment_Master_Plan_2026-09-13 (16 pp; docx has the same content)

**Summary.** Priority-ordered experiment plan: Q0 load, then Q1 Direct, then Q2 PIV-P0, then Q3 PTQ-T0, then Q4 code decision, then LANG / CORE / LIB / JUD, then NVARC integration B0-B4. All [PROPOSED].

**Relevant items:**
- **Q2 PIV-P0** (p.7): one XHIGH lineage, bounded tool calls ("start around 6-8"), a self-contained solution, a fresh-subprocess all-train gate.
- **Q3 PTQ-T0** (p.7): fresh calls, 3-4 rounds, one best partial program plus compact deterministic feedback; "start far below the released Poetiq 10-iteration budget".
- **Q7 LIB-Q27-E0** (p.9): a frozen public-program library ranked by exact count + cell-soft + validity; top 1-3 programs as priors; keep it "if it reduces Qwen search cost". [NEVER-EXECUTED in these docs]
- **Q6 CORE** (p.8-9): deterministic object/feature extraction, then bounded mechanics, then cross-example rejection.
- **NVARC diagnostic facts** (p.11): GT in pool 55/172 = 32.0%; selected 33.50 vs oracle 41.17; raw-candidate duplication about 37.8%; NVARC scorers 0.961 rank-correlated.
- **Mandatory metrics** (p.3): tokens and wall-clock per test output; duplicate ratio; all-train-exact program rate.
- **Routing features** (p.12): dynamic shape, multi-query, size ratio, colour count, separators, object count; NVARC duplicate ratio and score margin. Never route on GT near-miss signals.
- Runtime constraints at the time (p.3): 12 h with a 30 min reserve; max_model_len 18,432-32,768.

---

## 5. ARC_AGI2_Qwen38_Noemon_Research_Dossier_2026-09-09 (29 pp)

**Summary.** The research record from the 4B TTT baseline through EXP-0, EXP-1 direct Qwen and the Noemon port preflight. Thesis: "verifier-grounded heterogeneous candidate generation". Results are [MEASURED]; P0-P10 are [PROPOSED].

**Key numbers:**
- 4B baseline (p.8): Probmul top-1 26.00, top-2 33.50, Kgmon top-2 34.83. GT in pool 55/172 (32.0%); oracle 41.17 (+7.67). Rank of GT when present: 37 at rank 1, 10 at rank 2, 4 at rank 3, 3 at rank 5, 1 at rank 9.
- EDA (p.9): Test split has 240 tasks and 259 queries; 17 multi-query tasks; n_train 2:45, 3:132, 4:43, 5:14, 6:4, 7:1, 8:1. Outputs reach 900 cells; many grow >10x. "Executable transformations are attractive: a short program can describe a very large output deterministically."
- **Simple-rule demo-fit study** (p.9): 72 training tasks were fitted by simplistic rules; only **about 28.6%** of those were correct on held-out targets. Exact demo fit is necessary but not sufficient.
- EXP-0 (p.10): Eval vs Test AUC 0.888229; ESS 32.57/120.
- Throughput envelope (p.11, forced generation, batch 16): 800 tasks/h at 256 tokens, 309 at 1,024, 168 at 2,048, 87.6 at 4,096. Direct target JSON: median about 974 tokens, P95 about 3,070.5, max about 3,608.
- **EXP-1** (p.12-14), 7 tasks:
  - XHIGH: 7/7 hit 12,288 tokens, 0 reasoning end, 0 parse-valid, 1,963.1 s.
  - OFF: 1/7 parse-valid, 5/7 length-limited, 3,195.7 mean tokens, 678.2 s.
  - Near-miss 981571dc: **896/900 cells correct (99.56%)** in 1,807 tokens, still scored 0.
  - OFF ignored "final JSON only" and wrote long prose.
- EXP-2A Noemon static preflight (p.15-16): 51/52 gates passed; 19/1,032 context overflows; worst case 46,908 tokens vs 29,696 available (Reasoner R3).
- Budget plan (p.16): R1-R3 xhigh, 3,072 think each; Validator medium 1,024; Final xhigh 2,048; Judge 1,024.

**Ideas:**
- "Q27 latent ability is real; move it to artifact/program roles where exactness can be checked" (p.19).
- Combined reading of Land and Noemon (p.18): refinement helps when it is bounded and driven by objective external failure evidence; when it stagnates, widen to a fresh hypothesis.
- **Why agentic coding fits Qwen** (p.18): "reason briefly, act by executing code, inspect objective evidence, then reason again. A program also compresses large grid outputs."
- P6 (p.23): use held-out-demonstration falsification for n_train ≥3; use multi-start for 2-demo tasks; AB-MCTS-style WIDER/DEEPER control. [NEVER-EXECUTED in these docs]

---

## 6. ARC_AGI2_Qwen38_Project_Handoff_2026-09-16 (12 pp, Bengali/English)

**Summary.** Handoff snapshot (pipeline about 60-65%, solver readiness about 40-45%). [MEASURED]

**Key numbers:**
- **Q1 Direct on Proxy-48** (p.3-4):

  | | OFF | XHIGH |
  |---|---|---|
  | Exact | 0/56 | 0/56 |
  | Task parse-valid | 29/48 = 60.42% | 0/48 |
  | Hit length cap | 18/48 | 48/48 |
  | Generated tokens | 106,438 | 589,824 |

  - Runtime 14,007 s (3 h 53 m).
  - XHIGH spent about 84.7% of all generated tokens and about 84.8% of generation time for 0 usable candidates.
  - "Blindly raising 12k→16k was not evidence-based."
  - Dynamic, Tier-3, high-ratio, extreme-ratio and multi-query slices collapsed disproportionately.
  - Raw cell match is inflated by unchanged background; use exact changed-cell diagnostics.
- PIV v1.7 SMOKE (p.5): 12,288/12,288 tokens per task, 0/8 tool engagement, generation wave 1,967.8 s (≈32.8 min).
- Activation (p.5): LOW engagement 0.875, first tool after about 21 think tokens(?), later turns sometimes cut; MEDIUM 0.125; BUDGET3072 0.875 with 7/8 producing substantive code in phase 2.
- Throughput (p.6): C1 129.17 vs 48.30 tok/s; KV tokens C0 = 159,936, C1 = 166,992, C2 = 167,776; TP2 KV 17,248 tokens ≈ 2.17x max concurrency at 29,696 (p.7).
- About 2.92 h (about 68%) of a 4.29 h run was wasted on failed rows without fail-fast (p.7).
- P1_SPARSE (ARC-AGI-3 side branch) 6.8091 vs B0 6.4940 (p.7).

**Lessons** (p.8-10):
- "Tunnel vision: first-turn cap was the dominant signal; activation should have been measured earlier."
- Gate ladder: Integrity → Activation → Productivity → Quality → Serving safety → Compute → Diversity.

---

## 7. Research paper: Johan Land, "Modality-Driven Search with Holistic Trace Judging for ARC-AGI-2" (37 pp, arXiv 2606.31543)

**Summary.**
- 29 independent candidates (Text 8, Image 10, Code 11), then 3 holistic GPT-5.2 judges with 2/1-point scoring.
- 72.9% semi-private at $38.99/task; 76.11% public at $19.69/task.
- Results are [MEASURED] by the author: a single run, post-hoc ablations.

**Key numbers:**
- Pipeline (p.8-11): up to 29 candidates; adaptive early stopping; ARC-AGI-1 94.5% at $11.40/task.
- **Minimal base prompt** (p.11): "infer the transformation and apply it ... respond with explanation ... MUST respond with the completed output grid". No template, no fixed format.
- **CSV chosen after benchmarking 9 grid formats; a poor format costs about 10%** relative to CSV. Compact sparse/binary formats were much worse (p.11).
- **Two code regimes** (p.12-14): tool-integrated (iterative sandbox) and **one-shot code with no tools**. One-shot "is substantially cheaper and can still contribute unique solutions, but it is less robust on tasks that benefit from iterative debugging." The semi-private run had to use one-shot code (ZDR disables tools); this is part of the explanation for the 3-point gap (p.18).
- Judge prompt is 30k-80k input tokens (p.17).
- **Early stop** (p.21): 37 instances stopped after 8 candidates (the initial Text + Code probe); **36/37 correct (97.3%) vs 92/130 (70.8%)** for full-coverage instances. The one miss (dbff022c) was groupthink.
- Instance level (p.21): 128/167 = 76.65%; oracle 144/167 = 86.23%; 22 generation failures (13.17%), 17 selection failures (10.18%). Tasks: 86 fully solved, 11 partially, 23 unsolved.
- Complementarity (n = 130, p.23): exclusive solves are Text 2, Image 6, Code 7. 13e47133 was solved only by Code (7/11 and 2/11).
- Judge +7 over majority vote, all minority recoveries; synthesis +1 (21897d95:2), invoked 17 times (p.23-29).
- Cost (p.29): generation 87.1%, judging 12.9%. **Code family is 48.9% of generation cost**, mostly tool-integrated code.
- Even on the public run, 2,216 of 14,106 GPT-5.2 API attempts succeeded (84% failure rate) (p.20).

**Negative results** (§8 pp.32-33), all measured qualitatively by the author:
- Hint → solver collapses diversity.
- Object ID → transformation ID → solver: brittle handoffs.
- Strict JSON output underperformed.
- **Synthetic augmentation (colour permutation / rotation) for validating code was discarded**: little signal, and it breaks orientation semantics.
- **Extensive prompt engineering degraded the hardest tasks.** This covers prescribed templates, step scaffolds and domain heuristics ("look for symmetry ..."). The mechanism is a **"compliance tax on reasoning"**: the model spends reasoning budget following instructions.

**Unperformed ablations** listed by the author (p.30-31): candidate budget scaling; independent vs sequential refinement at matched compute; 1 vs 3 judges; trace vs output-only judging; early-stop threshold tuning.

---

## 8. Research paper: ARC_AGI_2_High_Score_Systems_SOURCE_FIRST_2026 (5 pp, 2026-10-06, Bengali/English)

**Summary.** A catalogue of high-score systems with evidence labels (VERIFIED, PAPER, REPO, TRACES, SELF-REPORT, CAVEAT).

**Numbers** (p.1-4):
- Johan Land 72.9% semi-private / 76.1% public.
- Confluence 97.92% at about $11.77/task.
- SqueezeEvolve 97.5% at about $5.93/task.
- Athanor 95.7% at about $3.12/task.
- Imbue 95.1% at about $8.71/task (Gemini 3.1 Pro). The same framework gets Flash 61.4% and **open-weight Kimi K2.5 34.0%**.
- Noemon 92.5% at about $3.90/task.
- ARCgentica 85.28% at about $6.94/task (GPT-5.2 XHigh 70.27%).
- **Agentic Coding / stateful REPL**: 68.33% full 120 (73.36% on 107-task subset). **Open-weight variants: GPT-OSS-120B 26.39%, MiniMax M2.1 10.56%.**
- Multi-Stage Rule Chaining: manuscript claim of 230/240 test outputs and 995/1000 training. Not rankable and not independently verified.
- Caveat: none of these are 2026 Kaggle offline private scores; Kaggle has no internet (p.4).

**Relevance:** these are the only open-weight data points. A REPL lifts open-weight models 3-4x over plain reasoning. Evolutionary code search (Imbue) gets 34% with Kimi K2.5.

---

## 9. Research paper: ARC_REPL_Strategy (16 pp)

**Summary.** An internal strategy doc for "evidence capture and base-notebook integration" for the Duck/REPL loop. It is about what to log and how to use successes and failures. All [PROPOSED]; its "Current status" column (p.6-7) marks many artifacts as "Must add".

**Relevant items:**
- **Python probes** (§3.3 p.4): compute components, histograms, symmetry scores, bounding boxes, colour frequencies and object correspondences. "**Keep outputs compact and place essential values first so truncation does not hide them**. Avoid expensive or unbounded probe code."
- **Candidates** (§3.4-3.5 p.4): no input mutation; minimise unexplained literals. Capture compile, runtime, shape, exact-pair count, cell accuracy and mismatch summaries. **Deduplicate candidates by observed behaviour**, not code text. Use mismatch masks to decide between repair and branching to a new hypothesis.
- **Success levels** (p.4-5): train_all_exact does not prove test correctness.
- **Failure taxonomy** (p.5-6), with actions:
  - HTTP timeout → separate it from tool timeouts.
  - Tool timeout → simplify the probe.
  - No candidate → look for loop stagnation.
  - Compile failure → auto-repair prompt.
  - Shape mismatch → shape predictor.
  - Partial accuracy → mismatch-mask, parent-child repair.
  - Duplicate behaviour → spend the budget on another branch.
  - Train-exact but test-wrong → anti-overfit selector.
- **Timeouts** (§6 p.6): PYTHON_TOOL 30 s, HTTP 600 s, CANDIDATE 30 s, never sharing one variable. Example config: tool_steps 8, tool_output_tokens 1024, max_output_tokens 4096 (p.7).
- **Runtime/throughput data** (§16 p.11-12):
  - Set budgets from measured per-request tokens and latency.
  - Use timeout count and repeated action index for **stuck-loop detection**.
  - "**Use time-to-first-exact-candidate for early stopping.**"
  - Measure duplicate-candidate time as wasted compute; use tool duration to cap probe complexity.
  - Use KV/queue metrics to tell a server bottleneck from long generations.
  - HTTP timeout = max(min, p95 latency × safety factor).
- **Anti-overfit scoring** (§15 p.11): reward cross-pair consistency, simplicity, colour-role consistency and test-shape plausibility; penalise literals, code size and duplicate signatures.
- **Compact verifier-grounded lessons** (§11 p.9): never inject raw transcripts; lessons carry features, operators and failed abstractions with best_accuracy.
- **Base-solver flow** (§13 p.10): extract structural features, retrieve generic lessons (no task ID), propose independent hypotheses (object / geometry / relation / sequence / direct), verify, dedup by behaviour, anti-overfit rank.
- **Success metrics** (§24 p.15): **tokens per solved task, time to first exact candidate**, duplicate-behaviour rate, no-candidate rate.

---

## Cross-document: what was tried, and what was measured

**Tried and measured** (Sep 2026, on the old FP8 vLLM 0.19 stack with a 12,288-token budget):
- Direct XHIGH, unbounded: 48/48 and 7/7 hit the cap; 0 usable output; 84.7% of tokens wasted.
- XHIGH inside a REPL (v1.7): 0/8 tool calls; all thinking in the first turn.
- reasoning_effort=low inside a REPL: 87.5% engagement, 715 median think tokens/turn, clean calls, about 3.0k tokens/task. It still produced 0 programs at the canary budget, and later 16/16 programs but 0/16 train-exact at 12k.
- A thinking-budget + forced-close design (3,072): engagement equal to LOW but dirtier calls and 37.5% more tokens.
- A protected terminal reserve (exploration ≤8,192 + 4,096 final): fixed artifact production (16/16) but not correctness.
- Serving: CUDA graphs gave 2.67x on long decode.

**Recommended in these docs but [NEVER-EXECUTED] as of their dates** (later status: see memory / other reviews):
- PTQ fresh-call repair paired with PIV at matched budget (Poetiq was later run as E10 R5 per memory).
- PIV-P2 detailed-prior vs minimal tool prompt.
- PIV-P3 preserved vs compacted thinking.
- Test-blind vs test-aware induction.
- CSV vs current serialization.
- CORE deterministic object layer.
- LIB frozen-program retrieval (ArunSehrawat 383 programs, Pang-style execution ranking).
- Noemon LOO validator.
- Athanor artifact-only reviewer with EXPAND_CANDIDATES.
- Imbue diff-rendered mutation.
- Provenance-aware early stop.
- Adaptive second lineage.
- Time-to-first-exact early stop.
- Stuck-loop detection by repeated action.
- Behaviour-signature dedup.
- Anti-overfit selector.

---

## Ideas relevant to making Duck compute in code from the start and cutting tokens per task

Each item gives its source. "Status" means status in these docs. User constraints are respected: no total-thinking cut below 60k; keep Qwen3.8-27B + Duck; bundle evidence-backed changes.

1. **Hand the model the facts instead of letting it derive them** (CoreThink p.37: "Do not make the LLM perform raw perception arithmetic"; REPL_Strategy §3.1/§3.3 p.4; Master Plan Q6 p.8).
   - Before the first token, the harness computes and injects a compact, deterministic per-pair fact sheet: shapes, colour histograms, background, components with bboxes and sizes, the in/out diff (changed-cell coordinates and colours), symmetry flags, separators/subgrids, size ratio, and colour mapping candidates.
   - This removes the hand-counting phase that causes 35/36 misreads, at zero generation cost.
   - Status: PROPOSED, never executed.
   - Caution (Johan §8.6 p.33, ARCgentica §6.7 p.23): present it as facts and tools, not as prescribed hypotheses or an obligatory decomposition. Give any *hypothesis* hint to one branch only (CoreThink p.37).
2. **Preload the grids as Python objects and say so in one line; forbid re-printing them** (PiVOTools §7.4/§7.7 pp.27-28).
   - Keep the puzzle protected, suppress whole-puzzle printing, encourage targeted slices, counts and helpers, and reusable functions across calls.
   - This is the PiVOTools interface behind the open-weight 3-4x lift (GPT-OSS-120B 6.11→26.38; MiniMax 3.06→10.56) (p.26; High-Score p.3-4).
3. **Treat "re-derives the same facts" as a harness failure** (Portability §7.8 p.29), not a model limit.
   - Detect "let me do this in code" followed by more prose counting, and inject or force a tool turn. REPL_Strategy §16 p.11 recommends stuck-loop detection via the repeated action index.
   - Pairs with idea 1.
4. **Interleave thinking and acting at the turn level** (Journal p.4-6; Audit p.5; Handoff p.5).
   - Measured: monolithic XHIGH never left first-turn thinking (12,288/12,288, 0 tool calls). LOW acted after a median of 715 think tokens per turn with clean calls. Forced close works as an action transition but does not guarantee a tool call.
   - Implication for 60k-out Duck: a **per-turn** thinking segment cap (not a total cut) that forces a tool or check() turn would move the first check() from about 55k toward the start, while the total budget stays at ≥60k.
   - Needs user approval: it touches THINK_BUDGET semantics (memory: no cuts below 60k; a per-turn cap is not a total cut but must be cleared with the user).
5. **Verifier, not model, scores train correctness; return compact diffs** (Poetiq §8.2 p.31; Imbue §4.3 pp.11-12; Journal p.11).
   - check() output should carry the per-pair solved flag, the shape mismatch, and for equal shapes only the wrong cells as (r,c,pred→want) plus a soft score, with essential values first (REPL_Strategy p.4).
   - The model should never re-verify by eye.
6. **Compact tool stdout and cap it** (Athanor §3.1/§3.6 pp.7-9; REPL_Strategy p.4): caps on stdout and errors, a tail summary, the full artifact on disk. This cuts prefill and context growth per turn.
7. **Minimal prompt; remove instruction-following overhead** (Johan §8.6 p.33, measured qualitatively).
   - Prescriptive templates and heuristic lists hurt the hardest tasks: the "compliance tax".
   - Keep only the tool contract ("compute every fact in code; finish with solution(grid)"), not a reasoning checklist. Athanor's port note says "retain only tool contract + concise solving objective" (§3.9 p.10). Keep a minimal-prompt arm (§6.7 p.23).
8. **Serialization ablation: CSV vs current format** (Johan p.11: about 10% performance spread across 9 formats; CSV was best for long grids, "representation consumes a large share of the reasoning budget").
   - Cheap, prompt-only. Also consider not putting full grids in text when they are preloaded in Python, except once.
9. **Program-library retrieval before the LLM** (Pang/LIB §12 pp.41-42; Master Plan Q7 p.9; ArunSehrawat 383 verified programs, p.51).
   - Execute a frozen public-training program set on the train pairs, in CPU seconds. An exact hit gives a free verified candidate (zero tokens); a top 1-3 partial hit gives priors that can cut iterations.
   - Status: NEVER-EXECUTED. A direct lever on tokens per task and coverage.
10. **One-shot code pass as a cheap first stage** (Johan p.14: one-shot code is "substantially cheaper and can still contribute unique solutions"; early-stop data p.21: 36/37 early-stopped instances correct).
    - Escalate to the full Duck loop only when no train-exact program appears, or when attempts disagree. Supports the 2.8 min/task coverage target.
11. **Time-to-first-exact early stop and provenance-aware stopping** (REPL_Strategy §16 p.11; Squeeze consensus-is-free p.3-4; Johan p.21).
    - Once a branch is train-exact, stop or skip sibling branches unless a disagreement signal remains. Guard against groupthink: require two independent provenances, or verified code plus agreement (Portability p.6, p.34).
12. **Adaptive second lineage / delegation only on uncertainty** (ARCgentica average 2.6 agents vs a 10 cap, p.21; PIV-P4 p.29-30; Poetiq second seed only for unresolved cases, p.32).
13. **Fresh-context compaction instead of ever-growing history** (Poetiq stateless top-K partials p.31; Athanor compact research-state schema p.8; PIV-P3 p.29).
    - After verified milestones, restart with the puzzle plus invariants, helper code, best program and failure signature. This reduces prefill and KV pressure and limits stale-context circling. Matches the memory finding that "iteration 2 pays".
14. **Behaviour-signature dedup and changed-output gate** (REPL_Strategy §3.5 p.4; Imbue verify_mutation p.12): skip candidates or repairs whose outputs do not change on any train/test input; count duplicate time as waste.
15. **Anti-overfit gate on train-exact programs** (Dossier p.9: only 28.6% of demo-fitted simple rules were correct; REPL_Strategy §15 p.11; Athanor reviewer pp.7-8).
    - Penalise literals and size-specific constants, and check test-shape plausibility. Spend the second attempt on a mechanic-diverse alternative (EXPAND_CANDIDATES, p.8; Johan's dfadab01 edge-handling hedge, p.24).
16. **Engineering hygiene that recovers wall-clock** (Audit p.7-8; Handoff p.7): fail-fast on terminal worker failures (68% of a 4.29 h run was lost); separate tool, HTTP and candidate timeouts; keep tool timeouts low (PiVOTools 120 s was judged too high, p.29; REPL_Strategy 30 s, p.6).
