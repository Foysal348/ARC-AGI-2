# ARC-3 related / Reference Notebooks / NVARC / public pulls: review (PARTIAL, 2026-10-21)

Status: PARTIAL. Only the NVARC section has been read and verified. The ARC-3, Reference Notebooks and public-pull
sections were handed to four parallel readers, and the run had to hand back before any of them reported.
Nothing below makes claims about those sources.

## Prepared inputs (scratchpad, code+markdown cells + truncated outputs, no execution)
- Extractions: C:/Users/hp/AppData/Local/Temp/claude/d--ARC-AGI-2/1c6db7aa-c78b-4b3a-b97a-5c67187fe52f/scratchpad/ext/
- Fork diffs vs dfranzen base: .../scratchpad/forkdiff/ (03 shiiin9 166 diff lines, 04 sigeward 197, 05 df-wm 3695,
  06 skarin 337, 07 amatlas 61, 08 bang1850 259, 10 manwithacat 139; 09 hknight3-0 is byte-identical to 01 dfranzen)
- P1_SPARSE text evidence: .../scratchpad/p1zip/
- Structural facts checked: the dfranzen notebook is about 10k lines of harness patch (cell 2, `%%writefile /kaggle/harness-changes.patch`)
  against the unchanged Tufa Duck bundle, plus setup and run cells. Model is Qwen3.8-Flash-Next W4A16 AutoRound + quantized MTP draft on an RTX PRO 6000.
  The patch has image-token accounting (an image is charged by its pixel size, not by base64 length; see the docstring at ext line ~4101),
  a zlib-compressibility check (~line 2937), PNG board renders (~7868-7967), and EXPOSE_RESET / EXPOSE_UNDO env switches.
- notebook6e705f697b (1) vs notebook6e705f697b1: 350 diff lines.

## NVARC family (D:/ARC AGI 2/resources/NVARC family/)
- README.md: 34 foysalemonshanto notebooks, all on `sorokin/qwen3_4b_grids15_sft139` (Qwen3-4B grid SFT) + unsloth.
  LB noise about +/-2.5 (the same v331102752 scored 27.36-32.64 over 10 subs; mean 29.36). Best single 32.64 = dual-mode reference.
  Cost: about 4.6-4.75 h wall per 120 tasks on 4xL4, about 17 GB per L4. Only `arc-2026d-with-codex` covered all 120 eval tasks
  (33.5/120 = 27.9 %). The 32.64 notebook's commit run trained only 35 puzzles (1.62 h).
  Anil Thomas (discussion 750546): 35 -> 45 by ensembling NVARC with a Qwen3.8-27B run.
- Pipeline (v2 notebook): per-task LoRA test-time training on 16 augmentations (shuffled keys), 1 epoch, max_seq 8192.
  Then turbo-DFS decoding (MAX_BEAM_CANDIDATES=5, max_score cutoff), 2 eval augmentations, and reranking of candidates by
  augmented-score (probmul / kgmon). The deadline is 12 h from starter start.
- Solved-task comparison (EVAL120, pass@2 task-norm): NVARC 27.92 %, Q27 DIRECT 86k 36.94 %, Q27 Poetiq R5 48.61 %, Q27 union 56.81 %,
  NVARC + Q27 union 61.81 %. Only 7 tasks are NVARC-only. Poetiq attempt_1 + NVARC attempt_1 as attempt_2 = 54.72 % (+6.1).
  NVARC LB/eval is about 1.0 (it finishes); Poetiq LB/eval is 0.44 (coverage binds).
- Tick table: 33 tasks solved by both, 6 NVARC-only, 43 Q27-only, 38 solved by neither (10 of those 38 solved by ARC Prize xhigh).
- Relevance: NVARC runs on fixed compute (about 2.3 min/task on 4xL4), so it covers all 240 tasks. As an attempt_2 filler it is the only
  measured hidden-coverage insurance. It needs about 4.75 h per 120, i.e. about 9.5 h per 240 in sequence, so it cannot share 12 h with Q27 as-is.

## Concrete techniques to copy into our ARC-2 Duck
Not written yet. They depend on the unread prompt, loop and eviction details of the Duck forks and the public Qwen3.8 agent notebooks.
Rerun the review over the prepared extractions above to fill this section.
