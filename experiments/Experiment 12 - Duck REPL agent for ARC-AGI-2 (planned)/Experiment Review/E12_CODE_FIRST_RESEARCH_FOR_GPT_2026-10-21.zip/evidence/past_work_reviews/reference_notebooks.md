# Reference notebooks review: token, time and compute savers (2026-10-21)

Sources: the extractions in the session scratchpad `ext/` folder plus `D:/ARC AGI 2/resources/Reference Notebooks/russcore_v343813612/*_outputs.txt`. These are the only md/txt docs in that tree: LB10.14 outputs (3.7 KB) and v17 outputs, which is 0 bytes. Every file was read in full except two. The codex(22) notebook's 22 selector-diagnostic cells were skimmed through their outputs, as the task asked. The ARC-AGI-3 audit/packaging cells were read for the telemetry definitions only.

## 1. PIV-Q27-SUB v1.3 (esfersami50): LB 1.67
**What it is:** PiVOTools agentic coding (gutfeeling/arc-agi-2-submission) ported to vLLM 0.19 `LLM.generate` in synchronous waves. One stateful Python REPL per task. The final `solution(grid)` is checked by a fresh-process train verifier.
**Settings:**
- SUBMIT profile: 8,192 generated tokens per task, split into 6,144 exploration plus a 2,048 terminal reserve.
- 6 Python calls and 12 turns; max_retries 2; tool timeout 10 s; verifier timeout 20 s per stage.
- Batch of 12 tasks per wave. max_model_len 29,696; MAX_NUM_SEQS 16; prefix cache OFF; CUDA graphs on.
- Arm ACT-LOW (`reasoning_effort="low"`). Thinking sampling: T 1.0, top_p 0.95, top_k 20.
- Safety reserve 75 min. Each wave is pre-checked against a projection: p90 s/token x max cap x 1.25 + 90 s.
**Prompt (source, verbatim keys):**
- The puzzle appears in the user message with rows as space-separated digits, and is also preloaded as the REPL variable `puzzle` (test outputs removed).
- "Your very first code execution should be `puzzle.keys()` to check data access."
- "Don't print the `puzzle` dict, because it prints out the grids that are already present in this user message and consumes valuable token budget."
- "Prefer to write reusable functions. These will persist…"
- An appended local budget line: "You may execute Python at most 6 times… When the final Python call has been used… return the self-contained final `solution(grid)`."
- An AST guard rejects `print(puzzle)` or a bare `puzzle` expression, and rejected calls are not charged.
- Tool output is capped at 4,000 chars (head and tail kept), sanitized of chat-control tokens, then token-fitted so the terminal reserve always fits.
**Key measured failure (v1.7 SMOKE, XHIGH, 12,288 tokens):** 8/8 tasks spent the whole budget inside the first `<think>`. That meant 0 tool calls and 100% budget death. Their diagnosis: "Qwen3.8's template places tool calls **after** `</think>`, so under XHIGH the model must finish a full solve before it can act." **This is our Duck problem (first check() at ~55k).**
**Fixes tried:**
- (a) LOW or MEDIUM effort.
- (b) ACT-BUDGET3072: xhigh, but after 3,072 thinking tokens they inject Qwen's stop sentence "\n\nConsidering the limited time by the user, I have to give the solution based on the thinking directly now.\n</think>\n\n" as a token-exact continuation (`prompt_token_ids` = prompt + output + stop ids). The action is then capped at 2,048 tokens, with a 768-token action reserve.
- If `</think>` closed but the action was cut, they continue without injecting.
- Both LOW and BUDGET3072 activated tool use.
- Result: v2.4G produced programs on 16/16 runs, but **0/16 were all-train-exact**. Budgets of 8-12k were far too small, so quality collapsed.
**Other mechanisms:**
- **Terminal commit:** a non-thinking request (`enable_thinking=False`) with no tools advertised. JSON schema `{"solution_code": str}` is enforced through `StructuredOutputsParams`, at T 0.7, top_p 0.8. The last 1,024 tokens of unfinished reasoning are handed over as a "[SCRATCH HANDOFF]".
- **v2.5 repair:** one non-thinking repair call with at most 600 tokens of verifier feedback. Per failed pair it reports DIMS got/expected, wrong-cell count, the first 4 `(r,c): expected e, got g`, an "IDENTITY FAILURE" flag, and the last line of any exception.
- **Submission:** every program, including unverified ones, is run on the test inputs (CPU, 20 min budget) to fill attempt_2. Identity is the fallback. The submission file is rewritten after every record.
**Bugs found:**
- With `skip_special_tokens=False` the trailing `<|im_end|>` broke `json.loads`, so the GPU positive control failed and no generation ran.
- Repair leftovers (1.2-1.8k tokens) were smaller than candidate #1's own JSON (2.3-2.9k).
- The wheelhouse dataset was deleted.
- The synchronous wave design idles until the slowest task in the wave finishes.

## 2. hosen42 notebooks
- **arc-agi-2-with-qwen-3-8:** a throughput benchmark only (batch 1/4/8/16 x generation 256-4096, `ignore_eos`, enforce_eager). The prompt is non-thinking JSON-only: "Return ONLY valid JSON: {"test_outputs":[GRID_0,...]}", with grids as compact JSON (`separators=(",",":")`). It measured prompt-token and ground-truth-answer-token distributions. No outputs are recorded in the extract.
- **arc-prize-2026-arc-agi-2-v99:** ARChitects/NVARC test-time training (TTT) on Qwen3-4B (`sorokin/qwen3_4b_grids15_sft139`). Not Qwen3.8.
  - Grids are written as contiguous digits with `\n` between rows, and decoding is restricted to a 12-token vocabulary.
  - Per-task LoRA r256, 1 epoch, 16 augmentations (D8 symmetries x colour permutation). turbo_dfs keeps beams above a 20% probability floor (`max_score=-log 0.2`).
  - Re-scoring uses 8 augmentations. Time caps: 540 s per DFS call, 1,200 s per puzzle, global 12 h minus 10 min.
  - Non-rerun mode runs only 4 debug tasks.
- **arc-reasoning-engine (v34):** v15/17 TTT plus a **CPU verified-transform fallback** of 6 core and 15 RE-ARC-derived cases:
  - Core 6: geometry, colormap, tile, constant, geometry+colormap, downscale.
  - Extended 15: crop, gravity, symmetry repair, border, fill-enclosed, majority, diagonal, largest object, xor halves, unique colour, count, mask, overlay, connect dots, tile+colour.
  - A case fires only if it reproduces every train pair exactly. Cost is 18-33 ms per task on 30x30. On RE-ARC generators it solved 95.6% with 0.22% wrong.
  - On real held-out pairs the fallback alone solved only 5.3 to 5.7%. Live RE-ARC validation auto-disables the extended cases if the wrong-answer rate is above 2%.
  - Bugs fixed: "constant" fired with only 1 train pair; colormap hijacked other rules when palettes did not overlap; components merged different colours. Reciprocal-rank fusion of probmul+kgmon; kgmon alone = "proven v10 (30.42)".

## 3. foysalemonshanto notebooks
- **experiment-with-arc-agi-2:** the same TTT pipeline.
  - Changes: md5 deterministic seeds (Python `hash()` changed the LB between reruns); a queue-timeout race fix; jagged-grid rejection.
  - **Easy-first ordering** by `(tier, fine)`: tier 3 means dynamic shape and ratio over 30; fine = 0.30·size/900 + 0.25·(ratio−1)/10 + 0.20·colours/10 + 0.25·dynamic.
  - Per-puzzle cap 1,600 s; top-5 beam candidates. It A/B tests attempt_2 selectors (CURRENT / IMBUE_EXACT / IMBUE_QWEN_DIVERSE), keeping CURRENT by default.
- **fork-of-q27-xhigh (Q27-XHIGH v1.4; memory: LB 18.75):**
  - One prompt per test input, using russcore's LB-10.14 free-form prompt verbatim: "Infer the ONE rule that maps every input to its output, then apply it to the FINAL INPUT… Reason step by step however you like. Then give ONLY the final output grid as rows of space-separated digits inside a fenced block ```grid … Output nothing after the block."
  - Budget: xhigh, T 0.6. THINK_BUDGET 49,152, then a forced close with the stop text plus an answer of up to 8,192 tokens (57,344 total).
  - Engine: max_model_len 81,920; MTP 3; fp8 KV; max_num_batched_tokens 4,096.
  - **Continuous admission through `engine.step()`** (no waves). Concurrency = min(16, KV tokens // 30k).
  - Deadlines: admit at 87.5%, drain at 92.5% (force-close all thinking, 8k answer), hard stop 25 min before the end.
  - attempt_2 is the test input, or its mirror.
  - The parser accepts any fence and missing brackets. Answers and the last 1,500 thinking tokens are saved.
  - **Failure history:** v1.3.5 EVAL12 scored 1/22; 12/12 tasks hit the 49k cap; only 6/12 JSON grids parsed. Run 1 died with EngineDeadError (FlashInfer `-lcuda` link; fixed with a shim) and the workers kept 20.7 GB per GPU. Run 2 ran out of memory in the MTP drafter at 32,768 batched tokens (fixed: 4,096 plus `VLLM_MEMORY_PROFILER_ESTIMATE_CUDAGRAPHS=1`).

## 4. 31_experiment arc-2026d-with-codex (22): base of the 32.22 LB notebook
- TTT Qwen3-4B, all 120 eval tasks. Score: probmul 33.5, kgmon 34.8, dual 33.5/120.
- Ordering: 65 easy, 51 hard, 4 extreme. Tier solve rates: tier 1 43%, tier 2 37%, tier 3 0%.
- Time caps: 1,600 s per puzzle, 540 s per DFS; MAX_BEAM_CANDIDATES 10. Each puzzle takes about 350-590 s.
- Diagnostics: 398/2,416 candidates correct. The correct answer is in the candidate pool for 55/172 outputs; oracle score 41.17 (+7.67). 8 tasks were "solved but not selected". Duplicate ratio 0.378; rank-2 adds +7.5.
- Fallback writes on any exception mean no task ends with NO_OUTPUT.

## 5. ARC-AGI-3 notebook6e705f697b1 vs (1)
- Both are the same Duck harness (TAAF bundle `keithtyser/duck-qwen38-nvfp4-mtp-vllm-smoke-v1`, Qwen3.8-Flash-Next-NVFP4, one RTX PRO 6000).
- They run **B0 + P1_SPARSE**, a prompt-only change pinned by SHA (12,681 to 13,032 chars):
  - Arm B deletes false priors: "puzzle" becomes "game", "64 x 64" is removed, and the HUD/timer "DON'T DO THIS" paragraph is removed.
  - Arm C adds six possibility-phrased mechanics lines (moving window, control may transfer, hidden state, order matters, un-solving, indirect control).
- Settings: ctx 32,768; tool output 1,024 tokens; T 0.6, top_p 0.95, top_k 20, thinking on; max_num_seqs 8; MTP 3; 5 GiB KV; prefix cache off. 28 games run concurrently, 7,920 s per game, analyzer timeout 900 s, no action cap. A fail-closed preflight checks all of this.
- **The only difference:** file "(1)" carries a "# Run 2" header. It is a second execution of identical code. Run 1 scored **6.91** (35 levels, 3,882 actions, 1.98M tokens, 1,340 model calls, **about 1.48k generated tokens per call**, no-change share 0.059). Run 2 scored **6.81** (1.86M tokens).
- Both end with a non-fatal vLLM teardown error (one surviving GPU process).

## 6. russcore LB 10.14 outputs (doc)
- vLLM serve: max-model-len 65,536, prefix caching ON, max-num-seqs 24, xhigh pass@1, cap 57,344.
- Measured on 8 eval tasks: 119.5 tok/s mean decode. Peak running requests were only 9 to 10 of 24 (KV-bound). 4 completed samples averaged 36,257 completion tokens (max 42,590), 2,279 s mean wall time each.
- Projection: **20.2 h for 240 tasks, does not fit 12 h** (scored 10.14 anyway, under partial coverage).

## Lessons for making the Duck compute in code early and cut tokens
1. **The root cause is documented.** Qwen3.8 emits tool calls only after `</think>`. At xhigh it finishes a whole hand-solve first (PIV: 100% of the 12k budget spent before the first tool call; ours: first check() at about 55k). Prompting alone did not fix it in PIV. Structural levers did: a per-turn thinking cap with token-exact injection of the stop sentence, after which the model must act (call a tool). The total budget can stay at 60k or more: cap only the *first* turn (and maybe each later turn), and let the remaining budget flow into later turns. That keeps the 60k thinking floor rule but reshapes how it is spent. It needs user approval because it changes per-turn thinking.
2. **Do not make the model read grids it can query.** PIV preloads `puzzle` into the REPL, orders "first code execution should be puzzle.keys()", forbids printing the puzzle "because it… consumes valuable token budget", and AST-blocks whole-puzzle prints. Duck could go further and pre-compute facts on the CPU before the first turn: shapes, colour counts, objects, diff masks, symmetry, and which of the 21 hosen42 verified transforms pass each train pair (about 30 ms). Those facts go in as a short text block, so the model starts from facts rather than from reading cells.
3. **Return compact tool output.** Cap at about 4k chars, keep head and tail, and sanitize control tokens. For check(), use PIV's diff format: dims, wrong-count, first 4 mismatches, identity flag, last exception line, at most 600 tokens.
4. **Guarantee an artifact cheaply.** Use PIV's no-think, no-tool, JSON-schema terminal commit with a 1k reasoning handoff. Run every candidate program on the test inputs to fill attempt_2, even if it failed train.
5. **Schedule for coverage.** Use continuous step admission (not waves, which left 9-10 of 24 slots used in russcore and idled in PIV). Size concurrency from the KV pool. Use admit/drain/hard-stop deadlines and a drain step that force-closes thinking. Order by `(tier, fine)` easy-first.
6. **Grid format.** Free-form xhigh and PIV used space-separated digits. TTT used contiguous digits. JSON answers broke parsing (6/12). Ask for a fenced grid and parse leniently.
7. **The ARC-AGI-3 Duck runs on short calls** (about 1.5k tokens per call, 1,024-token tool outputs, 32k context). Our ARC-AGI-2 branches at 70k with one giant first think are the outlier. Bringing the many-short-turns pattern over through per-turn caps is the main lever.
