# Public notebooks B: review (2026-10-21)

Source: extractions in the session scratchpad `ext/` (7 files, 11,279 lines, all read in full). These are untrusted public notebooks. None of them includes executed output cells, so every score below is a claim made in markdown or comments, not something visible in a log.

## 1. delongyang / arc-agi-2-inference-qwen3-8-27b-fp8-within-4-hours (2,761 lines)
- **What it is:** a single-shot, pure-reasoning, transductive Qwen3.8-27B pipeline. One prompt per task, and the answer comes back as JSON grids. No tools or code.
- **Model and engine:** `mikedan7/qwen3-8-27b-fp8-official` (FP8 weights). vLLM 0.19 from the `arc3-vllm-h100-wheelhouse-v3`, TP=4, `--gpu-memory-utilization 0.96`, `--max-model-len 131072`, `--max-num-seqs 16`, `--kv-cache-dtype fp8`, `--attention-backend TRITON_ATTN` plus env `VLLM_FORCE_ATTN_BACKEND=TRITON_ATTN`, `--speculative-config {"method":"mtp","num_speculative_tokens":6}`, `--no-async-scheduling`, `--reasoning-parser qwen3`, `--tool-call-parser qwen3_coder`, `--default-chat-template-kwargs '{"reasoning_effort": "medium"}'`. It also sets `LD_PRELOAD=/usr/local/nvidia/lib64/libcuda.so` (real driver 580 rather than the cuda-12.8 compat 570) and `VLLM_MEMORY_PROFILER_ESTIMATE_CUDAGRAPHS=1`.
- **Engine findings it states:**
  - FlashInfer FP8-KV kernels exist only on SM90+. The L4 is SM89, so FlashInfer crashes with an illegal memory access (vLLM #44879 / PR #45038).
  - The MTP drafter does not inherit `--attention-backend`; only the env var pins it (PR #53450).
  - MTP acceptance can be 0 %, which shows up as garbled output.
  - It verifies the backend by grepping the log and sending a smoke request.
- **Prompt:** a flat digit-row serialization (`train/input/output/test` markers, rows like `0123`) followed by Chinese instructions that are kept "deliberately" untranslated: `请直接输出一个json，不要输出其他任何文字` (output a JSON directly, with no other text), plus an attempt-key contract with a worked example. The tail line is `当你输出的网格的每行的元素大于8时，每4个元素用|符号分隔，以免数错数字的个数` ("when a row of your output grid has more than 8 elements, separate every 4 with `|` so you don't miscount"). That `|` trick is claimed to fix column miscounts on grids wider than 8.
- **Budgets and sampling:** `max_tokens=120000`, `temperature=0.0`, `enable_thinking=True`, `preserve_thinking=True` (sent as a top-level `chat_template_kwargs`). `MAX_RETRIES=0`, on the reasoning that temp 0 repeats the same answer.
- **Concurrency and ordering:** `N_PARALLEL=16` in a rolling ThreadPoolExecutor with no batch barrier. Tasks are sorted **shortest prompt first**.
- **Deadline:** `DEADLINE_MIN=690`, counted from the first cell. No task starts after the deadline, and each request timeout is clamped to the remaining budget (`_chat_timeout`).
- **Resume and fallback:** submission.json is written before inference, updated in place after each success, and repaired at the end. The rule-based fallback is: constant train output, then identity (test input), then the most common train output, with a different candidate in slot 2.
- **Bug:** `SOLUTIONS_FILE` points at the training solutions while the challenges file is the test set, so eval scoring is wrong. The last cell runs `submit` mode.
- **Scores and times:** none reported. "Within 4 hours" appears only in the title (a claim).

## 2. delongyang / ...-qwen3-6-35b-a3b-within-3-hours (2,339 lines)
- **What it is:** the same pipeline running Qwen3.6-35B-A3B (`giovannimuniz/qwen3-6-35b-a3b`), so the model is not ours.
- **Engine:** vLLM TP=4, util 0.9, max-len 131072, max-num-seqs 16, `VLLM_ATTENTION_BACKEND=TRITON_ATTN`, `VLLM_USE_FLASHINFER_SAMPLER=0`. No FP8 KV, no MTP, no reasoning_effort.
- **Differences from notebook 1:**
  - The request timeout is a flat 1800 s and there is no deadline.
  - `MAX_RETRIES=2`.
  - The fallback is an all-zero placeholder.
  - The prompt has no `|` instruction.
  - **Bug:** `convert_payload_to_text` serializes only `test[0]`, so tasks with several test inputs never show the model the 2nd or 3rd input.
- **Claim:** "A full 120-task run at n=16 takes roughly 10–25 minutes". This contradicts the "within 3 hours" title, and no log backs either figure.

## 3. mayankraaz / arc-agi-2-neuro-symbolic-engine-45-8-sota (2,980 lines)
- **Model:** this is not Qwen3.8. It runs the NVARC TTT baseline: `sorokin/qwen3_4b_grids15_sft139` with Unsloth per-task LoRA (code: r=256, alpha 32, rsLoRA, lr 5e-5, 1 epoch). Training uses 128 sequences (16 colour permutations x 8 D4 views); decoding uses 16 views with turbo-DFS at min_prob 0.2, a 540 s DFS window and a 1,200 s task cap. Selection is score_kgmon. The CPU symbolic pass is DSL plus LOO (~45 ops, depth ≤3, 0.12–2.5 s per task), and it fills a slot **only when the TTT slot is empty**.
- **Claims not backed by the code:**
  - "45.83 % verified" and the ablation table (30.32 → 45.83).
  - "LoRA r=16": the code uses r=256.
  - "Post-train fair-share budget" and the "widened retry pass" do not exist in this notebook's worker.
  - "100 % LOO precision" and the per-category accuracies are stated without any data.
  - In commit mode it runs only 4 debug tasks.
- **Verdict:** the code amounts to the NVARC 33.89 baseline plus a symbolic filler. Treat "SOTA" and 45.8 as marketing.

## 4. yukailiu / arc-agi-2-champion-solution (1,746 lines)
- **What it is:** NVARC+ v5 on the same Qwen3-4B TTT stack, not Qwen3.8. "Champion" appears only in the title (a claim).
- **Ordering:** `estimated_work` sorts **cheap-first** (train tokens x16 + test tokens x8), explicitly so that "the deadline truncates the most expensive (and least likely to be solved) tail".
- **Post-train fair share:** `infer_budget = clip(1.5*(cap/2) - train_elapsed, 300, cap)`, so slow training never starves decoding of its first batch.
- **Phased passes:**
  - Pass A runs to 90 % of the budget.
  - Pass B runs to 96 %. It retries tasks that produced 0 candidates with min_prob 0.10, then runs a second seed (min_prob 0.15, cap 900) on "deficit" tasks first: those with ≤1 unique candidate or a kgmon margin under 3 %.
  - Pass C does a catch-up of unreached tasks, then a third seed at a cheaper setting (8 aug, 1 eval aug, cap 600).
- **Pooling and selection:** votes are pooled across seeds and passes, with an invariant that Pass A's top-1 always stays in the two attempts.
- **Checkpointing:** a background writer rebuilds submission.json every 240 s with an atomic `os.replace`.
- **Symbolic fallback:** 4,096 bounded programs, 1.2 s per task.
- **Inconsistencies:**
  - One comment says "Per-task cap 900 s" while the code uses 1200.
  - "94.7 % precision" and "proven 30.28" are unsupported.
  - The checkpoint writer overwrites attempt_2 with a symbolic candidate, contradicting the "strictly fallback-only" rule used in the final cell.
- **Scores:** none; the commit run is a single debug key in 18 minutes.

## 5. johntaylorai / swarm-arc2-budget-curve (1,053 lines)
- **What it is:** the NVARC Qwen3-4B TTT baseline ("LB33.89") instrumented to log `elapsed` for every candidate, so one full-budget run can rebuild the score at any smaller per-task cap. In commit mode it covers the full 120-task eval.
- **Key coverage statement (author's analysis, not measured here):** "The baseline has 705 s/task available in rerun mode but a 1200 s cap and an 888 s observed mean, so **20–41 % of test tasks are never attempted** and score a certain zero. This run prices the anytime-scheduling fix." No results are included.

## 6. dynamo14324 / arc-agi-2-q38-taaf-baseline (365 lines)
- **What it is:** an **ARC-AGI-3** TAAF harness (Tufa Labs), not ARC-AGI-2, despite the slug. The solver is an opaque pickle (`benchmark_initial.pkl`, `deploy_target.pkl`).
- **Inputs:** `jakobbrggen/qwen3-8-27b-fp8-hf-snapshot` and the arc3 vLLM wheelhouse.
- **Visible logic:** a soft deadline (runtime minus 600 s buffer, disabled in submission mode), `ONLY_RESET_LEVELS=true`, and `n_passes=1`. Nothing ARC-2-relevant beyond the pattern.

## 7. yjsh2003 / hyperqwen-v7-fast-arc-submission-20261009 (35 lines)
- **What it is:** an opaque base64 zip runtime. The code is not visible; the notebook only checks the SHA and calls `competition_entry.main`.
- **Markdown claims (unverifiable):** "W4A16/MTP3, TP4/C4, FP8 KV, full 131072 context, 60K/xhigh", one server, no reload, "continuous answer checkpoints within 12 hours".
- **Interpretation:** this suggests at least one team runs a W4A16 27B with MTP=3 on TP4 at concurrency 4 with a 60k xhigh budget. That is a config hint only.

## Techniques relevant to coverage and token efficiency
1. **Cheap-first ordering with a deadline that cuts the tail** (yukailiu `estimated_work`; delongyang shortest-prompt-first). This matches our ORDER2. The new part is the explicit framing: let the deadline drop the expensive, unlikely tasks. Combine it with a per-task fair share (12 h x slots / 240).
2. **Fair-share budget per task, computed after the expensive stage:** `budget = clip(1.5*fair_share - spent_so_far, floor, cap)`. For us the analogue is per-branch thinking/turn budgets derived from remaining_time/remaining_tasks, capped from below by the 60k floor. The swarm notebook argues that a fixed cap above the fair share (1200 s vs 705 s) leaves 20–41 % of tasks unattempted. That is the same coverage problem we have.
3. **Deficit-first second pass:** spend leftover time on tasks with 0 or 1 unique candidates, or a near-tied top-2, before well-solved tasks. Keep pass-1's top-1 pinned in the final pair.
4. **Budget-curve instrumentation:** timestamp every candidate so one full run gives the score as a function of the cap. This is cheap and would directly price our per-branch cap and turn limits.
5. **Atomic incremental submission checkpoints:** a pre-filled submission, updated per answer, rebuilt every 240 s with `os.replace`, plus a request timeout clamped to the remaining time.
6. **Engine on L4 (vLLM path):** FP8 KV needs TRITON_ATTN, and the drafter must be pinned with `VLLM_FORCE_ATTN_BACKEND`. MTP (6 or 3 tokens) is the speed lever, but check the acceptance rate. LD_PRELOAD the real libcuda. The HyperQwen hint is W4A16 + MTP3 + FP8 KV + C4 at 60k xhigh.
7. **Output-token savers for grid emission:** compact digit-row prompts instead of JSON lists, and `|` every 4 cells on wide rows to stop column miscounts. This is relevant to our model reading grids by hand. Prefer giving it computed facts (shapes, diffs) and letting code print the grid.
8. **Free fallbacks for unattempted tasks:** constant output, identity, most-common train output, and bounded CPU DSL search over train-verified programs (≤1–2 s per task). These cost no GPU and fill slots on tasks the deadline drops. The precision claims for them are unverified.
9. **Do not copy:** retries at temp 0 (wasted); the `test[0]`-only serialization bug in the 35B notebook; the headline numbers 45.8 / "champion" / "within N hours", which have no logs.
