# Experiment 12 (Duck REPL agent for ARC-AGI-2): every doc, run, fix item and unused Duck feature

Compiled 2026-10-21 (read-only review). Sources read in full:
- `Experiment Review/` (9 .md docs; 13 zips listed only),
- `Experiment Results/` (5 run analyses, 4 weakness readers, 2 precheck readers, every analysis-script output, every `e12_run_report.json`, the E12 summary lines of every kernel log; transcripts not read),
- `PLAN.md`, `Duck milestone-2 exact settings (from dfranzen notebook).md`,
- `duck_arc2/arc2_duck.py` (1,033 lines, in full) and the relevant parts of the vendored Duck package (`tool_agent.py`, `prompts.py`, `python_tool_sandbox.py`, `vision_context.py`, `utils/segmentation.py`, `utils/frame_diff.py`).

Note: `duck_arc2/` has **no README**. The only text doc there is `vendor/NOTICE.txt` (Apache-2.0, vendored verbatim from da-fr/arc-agi-3-solution @ 10882e33, a fork of Tufa Labs' duck-harness @ 7652836; 20 files with a sha256 manifest).

---

## 1. Timeline of E12 runs

### 1a. Build and audit timeline (no GPU)

| Date | Step | Result |
|---|---|---|
| 2026-10-19 | User picks "Option A": Duck-style short requests with accumulating thinking. This is an approved exception to the 60k floor (floor kept for Poetiq/DIRECT). | PLAN §0-2 |
| 10-19 | Rev 1: 5 verified blockers fixed in the adapter only, plus #6 selection order, #7 GPU smoke step, #8 nudge rewrite | PLAN §2a |
| 10-19 | Step 2 adapter (538 lines). pyflakes clean. Vendored code hash-matches. Offline smoke 26/26 | §2b |
| 10-19 | Step 3 CPU harness: 10 scenarios, 113 checks | §2c |
| 10-19 | Step 3.5 notebooks (SMOKE1 sha ac3c706c, EVAL30 22e09634). Whole-notebook harness: smoke 15/15, rerun 13/13, launchfail 4/4. GPT audit zip | §2d |
| 10-19 | Rev 2: two GPT audits validated, 9 fixes | §2e |
| 10-19 | Rev 3: GPT re-audits; prlimit fail-closed | rev 2 audit docs |
| 10-19 | E12-V vLLM build, then rev 2 and rev 3 | §2f |
| 10-20 | Rev 4: EVAL6 bundle; 3 GPT audits validated | rev 4 docs |
| 10-20 | Weakness analysis, 3 GPT reports, fix list F1-F12 | fix list |
| 10-21 | Rev 5: B1-B8 + B9(a), then R5-1..R5-5; LOW variant | fix list |
| 10-21 | Rev 6 candidates R6-1..R6-6 (nothing built) | fix list |

### 1b. GPU runs (all Kaggle 4xL4, Qwen3.8-27B)

Unless noted, the engine is **SGLang 0.5.21 W1**:
- RedHat INT4 w4a16-g128 + DFlash2 bf16 draft, `extra_buffer_lazy`, mamba cache 56;
- KV 866,744 tokens, server context 155,648, engine effective_running 12;
- the Duck flags `--reasoning-parser qwen3 --tool-call-parser qwen3_coder --default-chat-template-kwargs {"preserve_thinking":true} --schedule-policy lpm --enable-cache-report`.

Tokens below are generated (completion) tokens.

| Run (account, date) | Config | Tasks / inputs solved | Tokens; requests | Time | Speed | Cache | Failures / notes |
|---|---|---|---|---|---|---|---|
| **SGLang SMOKE1** (foysalemonshanto, 10-19; nb 0fea4d0c; scriptVersionId 359922347) | Milestone settings: max_output 12,288, T 0.7, 2 branches, 12 streams, window 900 s. Task 2ba387bc | **1/1** (both branches accepted at first submit, train 4/4) | 10,812 in 10 req. b0: 4,905 tok, 2 turns, 60 s. b1: 5,907 tok, 2 turns, 73 s | engine load 677.5 s; solve 728-802 s (74 s) | decode median 204 tok/s at 2 running (159.6 at 1); DFlash accept 5.2 | 80.8 % (per request up to 99 %) | All step-3.5 gates passed: 10/10 replies `finish_reason=tool_calls`, thinking replayed, function retention, rising `cached_tokens`, no server errors. RLIMIT_AS verified on Linux. b1 once called a tool named `submit` ("Unknown tool"), fixed next turn. SGLang omits `prompt_tokens_details` when nothing is cached |
| **E12-V vLLM SMOKE1 run 1** (esfersami50, 10-19; nb 6af38987) | vLLM 0.19.0, FP8 repack, TP4, fp8_e4m3 KV, MTP-3, FlashInfer, 4096 batched, 16 seqs, 0.90 mem, max-model-len 135,168, served name `qwen` | **0/1** | **0 requests** | load 560.9 s (server ready 450 s); 100 s of failures | — | — | Every Duck request got **404 "The model `pending` does not exist"**. Duck treats `qwen` as a preset alias and sends `LOCAL_ANALYZER_MODEL_ID` = placeholder `pending`. "analyzer failed 11 times consecutively" in both branches. KV 337,600 tokens, 8.46x at 135,168 (about 1.14 M effective). The rev 2 smoke fix worked (`prompt_tokens_details: null` accepted) |
| **E12-V vLLM SMOKE1 run 2** (esfersami50, 10-19; nb e85b69c2) | Same as run 1, served name `Qwen/Qwen3.8-27B-FP8` | **1/1** (2/2 branches accepted) | 35,543 in 12 req. b0: 22,060 tok, 4 turns, 455 s. b1: 13,483 tok, 2 turns, 301 s | load 540.8 s (ready 435 s); solve 649-1,104 s (455 s) | **91.4 tok/s** all busy (2 running); MTP accept 3.5 | 73.4 % (75.4 % of reported requests; detail coverage 0.917) | Works, but about 3.3x more tokens and about 2.2x slower decode than SGLang on the same task (SGLang b0/b1 4.9k/5.9k tokens in 60/73 s). **No vLLM EVAL30 was ever run**; the SGLang path continued |
| **SGLang EVAL30 run 1** (hosen42 v1, 10-19; nb b65fb9dc) | Milestone: 12,288 output, T 0.7, 12 streams, all 60 branches admitted (no live pool), no per-branch cap, deadline 13,367 s | **4/30 tasks, 7/48 inputs, task-norm 13.3 %** (pass2 0). Solved: bf45cf4b, f931b4a8, 247ef758 (2/2; no other run fully solved it), 65b59efc | 2,357,584 in 454 req (0 failures). Prompt 23.78 M, cached 14.18 M, **uncached 9.60 M** | load 680.8 s; solve 733-14,779 s (ran 1,412 s past the deadline); about 3.9 h of solving | about 187 tok/s over the solve window (2.36 M / 12.6 ks); decode 431 tok/s median at 12 running, 420 at 11-12 even at ≥ 60k context; accept 5.1 | 59.6 % | **Branch 1 never started in 29/30 tasks.** b0 ran 12-20 turns, 61k-124k tokens, 0 submissions. **KV thrash:** 144 of 423 later requests < 50 % cached → 8.39 M of the 9.6 M uncached; prompt p50 47.9k, p90 97.7k, max 117.3k. 122/454 (27 %) requests hit 12,288; completion median 2,983; 29/30 first requests cut. **40 request timeouts** in 21/31 branches (28 full 900 s + 12 deadline-bounded, about 31,000 stream-seconds; first written as 4, corrected). 7 accepts, 3 test-wrong (3dc255db, b5ca7ac4, 4c3d4a41). Comparison on the same 30 tasks: S49 11/48, R5 Poetiq 16/48, ORDER2 DIRECT 86k 12/48, NVARC codex 10/48, ARC Prize xhigh 8/30 tasks |
| **SGLang EVAL6 (rev 4)** (hosen42 v1, 10-20; nb 53a66856) | 60,000 output, T 0.7, 6 live branches / 6 streams, task-major order, 100k soft cap per branch, read timeout 1,800 s, 90 min window, 125 min budget. 6 tasks that S49/R5/DIRECT solved and EVAL30 Duck did not | **3/6 tasks, 4/8 inputs, 50 %** (136b0064, 135a2760, 4c3d4a41). Baseline on these 6: 0 | 1,217,904 in 96 req (101k per branch); prompt 3.67 M, 78.8 % cached, uncached 0.78 M | load 758.3 s; solve 811-4,555 s (3,744 s = 62 min); about 110 min wall | 325 tok/s overall; decode 373-472 at 6 running; running=1 in 184 of 1,154 decode lines (tail); accept 5.5 | 78.8 % | 12/12 branches ran: 4 accepted, 8 stopped by the soft cap. 0 timeouts. 10 trims. Branch 0 accepted 0/6, branch 1 4/6 (Fisher p ≈ 0.06). 10 replies hit 60,000. **No accepted branch had a 60k reply.** 1 wrong accept (b5ca7ac4 b1). Cap overshoot up to 159,464. **11 of 84 later requests dropped the previous reply** (426,781 tokens; 5 were 60k replies reset to a system-only prompt). Repeat share 29.4 % of thinking characters. About 10 GPU-min per task → 240 tasks ≈ 40 h |
| **SGLang EVAL6R5 (rev 5, xhigh)** (hosen42 v1, 10-20; nb f4fed1ac) | Rev 5: 49,152 output, **T 1.0**, harvest + new selection + tokenizer estimate + truthful resume + cut-call drop + prompt edits + serializer guard; otherwise as EVAL6 | **4/6 tasks, 5/8 inputs, 66.7 %** (pass1 2, **pass2 3**). Hits: 136b0064, 135a2760, b5ca7ac4 (via attempt_2), 62593bfd (2/2 via attempt_2). Missed: 898e7135; 4c3d4a41 (both branches accepted wrong programs) | **846,080 (−30 %)** in 127 req; 70.5k per branch; prompt 6.17 M, uncached 0.97 M (> generated 0.85 M) | load 659.8 s; solve 702-4,166 s (58 min); 69 min notebook | **244 tok/s** overall; decode 306-408 at 6 running; running=1 in 130 of 987 lines; accept 4.3 | 84.3 % | 9/12 accepted. 0 timeouts, 0 cut calls, ≤ 1-2 trims per branch, no system-only resets. Estimate vs server prompt tokens: median +0.4 % (p10 −3.8 %, p90 +1.7 %); 1 over by 5 %; max prompt 78,158. Loop share 0-3 % (rev 4: 29 %). 2 replies hit 49,152. Per task 141k tokens, 9.7 min. Context per request p50 58k, p90 74k, max 95k. First check median 55.1k tokens (56.6k by another count); 1/12 never checked |
| **SGLang EVAL12R5_LOW (rev 5, effort low)** (foysalemonshanto v1, 10-20; nb 26fff41e) | Rev 5 + `reasoning_effort=low`. 12 tasks = EVAL6 six + 4 EVAL30-Duck-solved + 2 mid (9385bd28, cbebaa4b). 9,000 s window, 11,100 s budget, 6 live / 6 streams | **7/12 tasks, 10/19 inputs, 58.3 %** (pass1 9, pass2 1). **898e7135 solved for the first time by Duck.** Kept all 4 EVAL30-Duck tasks; 2 mid tasks 0/2; of the 6 shared, 3/6. Union with xhigh R5 on the 6: 5/6 (only 4c3d4a41 missing) | 1,743,889 in **449 req**; 72.7k per branch; prompt 17.98 M, cached 88.7 %, uncached 2.03 M | load 745.4 s; solve 799-7,369 s (110 min); 123 min notebook | **265 tok/s** overall; decode 312-442 at 6 running; accept 4.7 | 88.7 % | 17/24 accepted (wrong accepts include 4c3d4a41 b0+b1, b5ca7ac4 b0+b1, 9385bd28 b0, 62593bfd b1). Estimate median +0.5 % (p10 −1.3 %, p90 +3.5 %); 21 over by 5 %; max prompt 81,536. Loop 0-8 %. 2 replies hit 49,152. Per task 145k tokens, 9.1 min: **low is not cheaper** (first reply about 200 tokens, but a median 8.5 requests to the first check; first check median 53.7k; 3/24 never checked). Context p50 46k, p90 75k, max 115k |

**Never run:** `EVAL30R5` (sha 415a68f2; 30 tasks, 330 min window, 6 h budget). `EVAL6R5_LOW` (sha cce9cb8f): the run used the EVAL12R5 profile instead, and the fix list does not record that switch.

**Quota:** hosen42 used 30.79-31.29 of 60 h at rev 5 build time.

### 1c. Analysis results (simulations and replays)

**rev4_simulator** (EVAL30, model time):
- measured run: prefill 9.59 M + gen 2.35 M → 12,018 s (the real window was 12,634 s);
- without thrash: prefill 0.39 M → 5,706 s.

Hidden projection at a per-branch cap C (240 tasks × 2 branches in 40,200 s):

| C | Covered |
|---|---|
| none | 106 tasks |
| 100k | 113 |
| 80k | 130 |
| 70k | 143 |
| 60k | 160 |
| 50k | 186 |
| 40k | 222 |
| 30k | 240 (but 1 correct kept) |

Resident contexts: about 9 fit KV at p90, 18 at p50.

**Real-sandbox replay with the rev 5 hook:**
- EVAL6: 5/6 tasks, 7/8 inputs (actual 3/6, 4/8);
- EVAL30: unchanged 4 tasks, 7/48 (branch 1 never ran).

**budget_sim** (soft per-branch cap, rev 5 runs):

| Cap | xhigh tasks / inputs | xhigh tokens/task | xhigh 240-task need | low tasks / inputs | low tokens/task | low 240-task need |
|---|---|---|---|---|---|---|
| 15k | 0/6, 0/8 | 70.9k | 19.3 h | 1/12, 1/19 | 49.8k | 12.5 h |
| 25k | 0/6, 0/8 | 73.4k | 20.0 h | 1/12, 1/19 | 67.1k | 16.9 h |
| 35k | 1/6, 1/8 | 90.9k | 24.8 h | 2/12, 3/19 | 83.3k | 20.9 h |
| 50k | 2/6, 2/8 | 105.8k | 28.9 h | 4/12, 6/19 | 98.9k | 24.8 h |
| 70k | 4/6, 5/8 | 125.3k | 34.2 h | 5/12, 8/19 | 123.6k | 31.0 h |
| none | 4/6, 5/8 | 141.0k | 38.5 h | 7/12, 10/19 | 145.3k | 36.5 h |

Reading the table:
- Full coverage needs about **2.8 min per task**. We are at 9-10 min, i.e. about 3.4x short.
- Kris Dreemurr (discussion) uses about 35k tokens per attempt; ours is about 70k per branch.
- A cap alone fails because the first `check()` comes at about 55k tokens.
- The first verified candidate per branch is at a median 58k (xhigh) / 56k (low). The first correct candidate is at 32-62k (xhigh) / 14-98k (low).

**precheck_thinking** (36 branches):

| Group | Branches | Tokens to first check |
|---|---|---|
| fast (< 35k) | 8 | 26k |
| 35-55k | 8 | 48k |
| > 55k | 15 | 65k |
| never checked | 5 | 107k |

Grid-row text in thinking is only 0.6-3.3 %. Coordinates appear about 1-24 per 1k tokens. Code lines in thinking are about 0.

**precheck_behaviours:**
- **xhigh:** pre-check tokens 741,660; **272,653 (37 %) come after the first code-intent phrase** in the same response. Misreads before the check in 12/12 branches. Own output comparison 0/12. Cap hit before check in 2/12.
- **low:** pre-check 1,393,683; 279,007 (20 %) after the intent. Misreads 23/24. Own compare 2/24. Cap hit 2/24.

---

## 2. Every weakness / fix item ever listed, with status

### 2a. PLAN Rev 1 (2026-10-19): all DONE

| # | Item | Status |
|---|---|---|
| 1 | `_build_system_prompt` is module-level, so the system prompt is set after `super().__init__` | done |
| 2 | Extra `initial_state` keys never reach the REPL | done: a trusted prelude (grids as literals + check/submit) is prepended |
| 3 | No function objects over IPC | done: `submit` sends a name through the action channel; the host re-verifies in a clean sandbox |
| 4 | No numpy | done: the sandbox is unchanged; the prompt says pure lists |
| 5 | Game state file and game tool text | done: a minimal state file + an ARC-2 tool description |
| 6 | Selection order: train-pass > agreement > distinct attempt_2 | done |
| 7 | GPU smoke step 3.5 | done (SMOKE1 passed) |
| 8 | Game nudge tail | done: replaced with the ARC-2 tail; Duck's generic prefix kept |

**Not adopted** (would drift from the plan):
- KV-aware admission (later partly done as rev 4 `live_branches`);
- a numpy backend;
- forcing `reasoning_effort` (later done as the LOW variant);
- porting the prefix-cache patch before measuring;
- a new priority formula or a coverage-first branch policy.

### 2b. Step 2 / step 3 adapter fixes: all DONE

- resume opener = continuation;
- no echo of check/submit return values;
- `verbose=False`;
- the retention prompt corrected ("not the provided globals");
- "in this game" → "on this task";
- `timeout=analyzer_timeout`;
- optional `max_generated_tokens` per branch;
- deterministic first admission (hold all slots until queued);
- setup guard;
- `build_submission`;
- `difflib` added to the module list;
- per-request usage recording.

### 2c. Step 3.5 GPT audits (rev 2/3, 2026-10-19)

| Item | Status |
|---|---|
| 1 concurrent `submission.json` race (reproduced: 478 failed writes, 6 broken reads) | done: lock + `mkstemp` + `os.replace` |
| 2 forgery via a patched `print` | done: one sandbox per grid, structured `result`; 6 attacks rejected |
| 3 900 s first-request grace ignores the deadline (> 90 s at a 5 s deadline) | done: `_http_initial_grace_used = True` |
| 4 gate wait / held slots | done: try/finally (partly valid) |
| 5 480 threads | **rejected**: not reproduced (495 threads, fine) |
| 6 no sandbox memory limit | done: RLIMIT_AS 4 GB via prlimit after Popen. Rev 3 H1: **fail-closed** (kill + OSError) |
| 7 request logs off | done: `E12_REQUEST_LOGS` (SMOKE1 on) |
| 8 seeds | wording only (SGLang ignores the per-request seed without deterministic mode) |
| 9 mirror fallback | removed |
| 10 harness not self-contained | done: fixtures |
| H2 verification just before the deadline can pass HARD_STOP | done: `E12_STOP_BEFORE_HARD_SEC` = 180 (configs show 180) |
| GPT 2 BLOCKER: `json.dumps` spoof | **not fixed then** (score is truth-checked; equal to a lookup; never observed; the guard is partial). Later **done in rev 5 R5-1** behind the rev 5 flag |
| MEDIUM: the 2 × 30 s verify budget can reject slow programs | proposal "record `verify_sec` / `verify_timeouts`": **not seen implemented** (pending) |
| Mixed case test (2 exact + 1 timeout must be rejected) | "sensible, add to smoke": status not recorded |

### 2d. E12-V vLLM audits (2026-10-19)

| Item | Status |
|---|---|
| B1 smoke rejects the cold start (`prompt_tokens_details` omitted, vLLM #44377) | done |
| Model-id fallback `qwen` | done |
| Cache report: unknown ≠ 0 | done |
| Harness: thinkmarkup / modelsfail | done |
| B2 tool-call XML inside `<think>` (vLLM #39056) | handled by Duck's recovery |
| B3/B4 "337,600 KV ⇒ 28k per stream" | **rejected** (real 8.46-12.63x) |
| B5 MTP + prefix + tool calls corruption (#50188), #53504, #38979 | measure on GPU: **open**. Only the smoke ran, 12 requests, fine |
| Rev 3 root cause: served name `qwen` → Duck sends `pending` → 404 | done (`Qwen/Qwen3.8-27B-FP8`; strict fake 404) |
| Harness read its log after the server stopped | done |
| vLLM EVAL30 | **never run** |

### 2e. EVAL30 analysis levers (10-19) → rev 4

| Lever | Status |
|---|---|
| Per-branch token cap + fair start for branch 1 | done (100k soft cap, task-major order) |
| Resident contexts ≤ KV (live pool 6) | done |
| Lower context drain | **rejected** in the rev 4 audit (#5: trims on every turn kill the prefix cache) |
| E13 risk: Flash-Next KV holds only 2-4 Duck contexts | noted |

### 2f. Rev 4 audits (10-20)

| Item | Status |
|---|---|
| 1 900 s read timeout too short for 60k | done: 1,800 s |
| 2 100k cap is soft (up to about 160k) | kept soft; report actual tokens |
| 3 clamp `max_tokens` to the remaining budget | **rejected** (cuts reasoning). Revived in the rev 5 analysis as the only way to really bound tokens: pending |
| 4 input budget 70,560 | accepted caveat |
| 5 drain 11,168 | **rejected** |
| 6 trims = caveat | report |
| 7 not all branches get compute in 60 min | done: window 90 min / budget 125 min |
| 8 wording "60k floor" | fixed |
| 9 selected tasks are biased | stated |
| 10-11 analysis fields | analysis only |
| 12 deadlock | PASS |
| 13 KV | PASS |
| 14 fake ≠ long requests | accepted |
| Own change: window 154,624 with 5 live | **reverted** (hook removed) |
| Final audit GPT 3: `json.dumps` spoof | not fixed in rev 4 (grep of accepted code instead: none found) |

### 2g. Weakness analysis W1-W8 (10-20) and candidate fixes 1-6

| Item | Finding | Status |
|---|---|---|
| W1 | correct functions never submitted (62593bfd_b1, b5ca7ac4_b0) | done: B1 harvest |
| W2 | fresh reply dropped (35 % of EVAL6 tokens) | done: B3/B4 |
| W3 | loops | done in part: B5 49k cap + B9(a) T 1.0. Penalty, detector and early cancel pending |
| W4 | head-thinking, misreads, lookup refusal | done in part: B7. Rev 6 pending |
| W5 | overfit accepts; attempt_2 wasted 56/56 | done: B2. Overfit itself remains |
| W6 | dict trap, retention NameErrors, stub executed, timeouts | done: B8, B6, 1,800 s |
| W7 | coverage | **pending** (F7) |
| W8 | independent branches | F8 "not now" |

Candidate fix 1 included "auto-submit"; that part was **rejected** (247ef758: the first exact version was test-wrong). Fix 5 (`train_pairs` alias) was **rejected** in favour of the doc example (B8).

### 2h. Fix list F1-F12 (GPT G1/G2/G3 validated)

| ID | Item | Status |
|---|---|---|
| F1 / F1-a | runtime `check()` hook + host verify; prove it in the real sandbox | **done** (B1). G2's passive harvest **rejected** (missed 2 of 12, added 0). G3's AST scan not chosen |
| F2 (a, b) | token estimate + truthful resume | **done** (B3, B4) |
| F2 (c) | `ARC3_CONTEXT_DRAIN_FLOOR` as an optional test | **not done** |
| F2-a | capacity trade-off | resolved via B5 |
| F3 (a) | temperature 1.0 | **done** (B9a) |
| F3 (b) | shorter output | **done**: 49,152 |
| F3 (c) | presence penalty | **not taken**. It is inactive under DFlash in SGLang 0.5.21 (#28180) and needs a 2-line SGLang patch; HF warns of language mixing |
| F3 (d) | loop detection / early cancel | **deferred** (needs streaming) |
| F4 | prompt wording | **done** (B7) |
| F5 | portfolio selection | **done** (B2). A Poetiq candidate when Duck has none: later |
| F6 | `train` example | **done** (B8). The F6-b stub execution was done as B6 |
| F7 | coverage / routing, Duck as a complement to Poetiq | **pending**. P0 for a submission. 247ef758 is Duck-only (0/12 other runs) |
| F8 | branch sharing | not now (merge candidate pools, not contexts) |
| F9 | judge / reviewer | later |
| F10 | trusted serializer | done in R5-1 |
| F11 | analysis hygiene | always |
| F12 | do not copy wholesale | note. No 29-candidate ensemble, multi-agent, templates, augmentation or streaming rewrite. Imbue Darwinian Evolver is AGPL-3.0, so ideas only |

### 2i. Rev 5 bundle B1-B9: done and run (EVAL6R5, EVAL12R5_LOW)

| # | Change |
|---|---|
| B1 | `CHECKED:<name>` hook; dedupe on (name, sha of the retained sources); cap 24 per branch (`E12_CHECK_VERIFY_CAP`); the branch continues; the verdict note goes back to the model |
| B2 | `select_attempts_r5` |
| B3 | reasoning counted with `tokenizer.json` (fallback 1.9 chars/token); calibration excludes reasoning |
| B4 | `ARC2_RESUME_R5` / `ARC2_RESUME_TRIMMED` |
| B5 | 49,152 output |
| B6 | `length`-cut calls made invalid; `ARC2_RESUME_CUT` |
| B7 | 4 prompt edits |
| B8 | `train` example |
| B9 (a) | temperature 1.0: **done** |
| B9 (b) | presence penalty: **not taken** |

Local tests:
- rev 5 unit 53/53, flag-off 41/41;
- harness r5 32/32, rerun 21/21, launchfail 6/6;
- regressions eval6 25/25, smoke 22/22.

The "metrics for every future run" list is partly implemented (`checked_verified`, `rev5_events`, `prompt_estimates`).

### 2j. Rev 5 audits

| Item | Status |
|---|---|
| R5-1 serializer guard | done |
| R5-2 block markup recovery on `length` | done |
| R5-3 resume rewrite in `_force_reduce_messages` | done |
| R5-4 tokenizer status recorded and printed (no assert) | done |
| R5-5 estimate-vs-actual metric | done |
| R5-6 one sentence asking for distinct names per tested version | **not taken** (0 of 405 recorded calls redefine a name) |
| N1 same-name redefinition after an exact check | known limit |
| R1 verification worst case 24 × 60 s | measured 0.75-2.71 s each, ≤ 3 per branch; keep cap 24 |
| B4 resume adds about 50-110 tokens after the trim | negligible |
| Cap counts rejected verifications | known limit |
| B2 a branch's submission outranks its checks | kept |
| B3 is a hybrid estimate | accepted; metric added |

**LOW variant:** `_harness_template_kwargs` adds `reasoning_effort` when `E12_REASONING_EFFORT` is xhigh, medium or low. Unit 56/56; harness on LOW 33/33. **Done** (run as EVAL12R5_LOW).

### 2k. Rev 5 runs analysis: next levers (all PENDING, user decision)

1. More concurrency, 10-12 streams. 10 fit up to p90 (750k). Rev 4 measured 6 → 12 running as 368 → 431 tok/s.
2. Per-branch cap. Failed branches burn 105-115k; accepted branches finish at 14-98k; some accepts came at 88-98k.
3. Prefill share: keep prefixes stable (uncached prefill 0.97 M > 0.85 M generated in xhigh).
4. Overfit and selection order. 4c3d4a41 failed in both runs; b5ca7ac4 and 62593bfd in low. In xhigh the correct answer was attempt_2 twice.
5. A hard per-attempt budget (clamp `max_tokens` to the remaining budget) to really bound tokens.

### 2l. Rev 6 candidates (10-21): nothing built; target is the first check at ≤ 25k median instead of about 55k

| ID | Change | Approval |
|---|---|---|
| R6-1 | **Facts block** in the first user message, computed by the harness. Per grid: dims, background, colour counts. Per component: colour, cells, bbox, shape string. Per pair: diff count. Plus "use only numbers printed by Python or this block; never count cells by hand". Evidence: misreads in 35/36 branches | normal |
| R6-2 | "When one rule explains every training pair, call check(transform) in the same reply; compare test outputs only after check is exact, and in Python." Replaces "compare their test outputs" | normal |
| R6-3 | "Never compare against p['output'] yourself; write a transform for that part and check it; if two variants fit, check both in one call" + `check({'A': fA, 'B': fB})` | normal |
| R6-4 | `check()` errors print the failing line inside transform; the prompt lists the allowed imports (evidence: sys/traceback import loops) | normal |
| R6-5 | **Code-intent stop:** after about 3k reasoning tokens a code-intent phrase ends the stream; resume with "your reasoning is kept; emit the python call you planned". Alternative: cap only the first request at about 12k | **user approval (60k-floor rule)**. The earlier "pause-resume negative" result calls for a measured test |
| R6-6 | Output reserve vs context: count the 49k reserve against KV, not the window, or lower it only when history > 80k (low 4c3d4a41_b0: 66k + 16k + 49k > 131k → trim → overfit accept) | approval if any cap changes |

**Reader proposals not yet in the R6 list:**
- auto-run `check()` whenever a call defines `transform` (low reader #3);
- a stream watchdog at about 10k reasoning tokens since the last tool call (low #1, = R6-5);
- "if you are about to verify on > 2 objects, compute it in Python" (low #4);
- keep tool results in history after a no-tool turn (low #1).

### 2m. PLAN open items

| Item | Status |
|---|---|
| Port Franzen patch #4 (end-of-prefill Mamba checkpoint, LRU refresh) if the cache is low | not done |
| `--mamba-track-interval 64` / `--page-size 64` (`E12_MAMBA_TRACK_64` = false in every run) | not tested |
| An ARC-2 progress signal (best train score) for Duck's priority formula | not done |
| Grid images (phase 3) | not done |
| Flash-Next E13 | separate |
| P1/S60 EVAL30 baseline in parallel | open |

### 2n. Documentation inconsistencies found

1. The fix-list header still says "rev 5 implemented and tested locally (not run on GPU)", but both rev 5 runs are complete.
2. The LOW section names `EVAL6R5_LOW` sha cce9cb8f, but the run was EVAL12R5 (12 tasks, sha 26fff41e).
3. First-check median for xhigh: 55.1k (precheck script) vs 56.6k (budget_sim); different definitions.
4. EVAL30 finished at 14,779 s against a 13,367 s deadline (overran by about 23 min). No doc explains this; likely the 900 s in-flight requests.

---

## 3. Unused Duck features and settings that could cut tokens or raise throughput

### 3a. Settings the adapter uses (from `DUCK_ENV`)

| Group | Values |
|---|---|
| Provider | vllm |
| Reasoning history key | `reasoning_content` (vLLM build: `reasoning`) |
| Thinking | on |
| Tool limits | TOOL_STEPS 0 (unlimited), TOOL_TIMEOUT 30 |
| Yield | YIELD_TOKENS 2048, YIELD_SECONDS 0 |
| Sampling | T 0.7 (rev 5: 1.0), top_p 0.95, top_k 20 |
| Context | CONTEXT_WINDOW 131,072; MAX_OUTPUT 12,288 (rev 4: 60,000; rev 5: 49,152); CONTEXT_DRAIN_TOKENS 59,392 |
| History | HISTORY_ASSISTANT_TURNS 150, TURN_DRAIN 30, DRAIN_COALESCE 1 |
| Tool output | 3,072 tokens; MIDDLE_TRUNCATION 1 |
| Memory sections | off |
| Persistent functions | on, scope game, imports 1 |
| Priority | REFRESH_QUEUE 1, PACE 0, TAIL_FADE 1 (0.2), TAIL_LOOKUP remaining, SCORE_NORMALIZATION 1 |
| HTTP | RETRY_INITIAL_SECONDS 900 (grace disabled in code) |
| Streams | MAX_ACTIVE_STREAMS = `E12_STREAMS` (12, then 6) |

Effective input budget = window − max_output − 512:
- 70,560 at 60k output;
- 81,408 at 49,152 output.

### 3b. Vendored but unused (all off by default unless noted)

1. **Segmentation and object diff in the sandbox, unreachable for ARC-2.**
   - `utils/segmentation.segment_layer` gives connected components with colour, translation-invariant hash, a rotation-canonical signature (rotation, symmetry order), pixel count and a boundary contour.
   - `utils/frame_diff.compute_frame_diff` gives an object-level diff with Hungarian matching.
   - Both are spliced into the sandbox bootstrap and exposed as `current_frame.segmentation` / `frame_diff()`.
   - The adapter passes `current_frame=None`, so the model cannot use them.
   - Exposing train inputs and outputs as frames, or adding these functions to the prelude, would give R6-1-style facts (objects, bboxes, shape hashes, per-pair object diff) **computed in code** at zero model tokens. This attacks the misreads seen in 35/36 branches and the 37 % of pre-check tokens spent after the model already said it would use code.
   - Duck's own nudge calls segmentation "the primary view".
2. **Images** (`vision_context.py`):
   - settings `MULTIMODAL_CONTEXT=current_grid`, `MULTIMODAL_UPSCALE` (milestone 10), `MULTIMODAL_RESAMPLE`, `ARC3_DIFF_IMAGE`, `ARC3_HISTORY_IMAGE_KEEP`, `ARC3_RESUME_PROMPT_IMAGES`, `ARC3_IMAGE_TOKEN_ESTIMATE`;
   - about 400 tokens per image at upscale 10;
   - the milestone ran with them on; Tufa credits multimodality;
   - E12 phase 1 left them off, and phase 3 was never done;
   - this is a possible fix for hand-perception errors;
   - it needs a VLM-capable server path (the vLLM cell uses `--language-model-only`).
3. **`ARC3_REASONING_EFFORT_LADDER`** (e.g. "medium,low"): after a truncated generation, steps one effort rung down, then resets once an action executes. It is unused (E12 used a fixed xhigh or low). It is cheaper than a fixed low: thinking is reduced only after a cap hit.
4. **Rolling summaries:**
   - `ARC3_SUMMARY_INTERVAL_TOKENS` (0 = off), `ARC3_SUMMARY_REPLACES_HISTORY`, `ARC3_DRAIN_STOP_AT_SUMMARIES`, `ARC3_HIDE_FOLLOWUP_SUMMARIES`, `ARC3_SUMMARY_MAX_GEN` (8192), `ARC3_SUMMARY_ENABLE_THINKING` (off), `ARC3_SUMMARY_TURN_CONTEXT`;
   - Duck measured 4.4-7.1k-character summaries that carried most of what evicted turns held;
   - for us they could replace dropped 50k+ reasoning blocks after trims (the low 4c3d4a41 overfit case);
   - the summary request itself costs one generation per interval.
5. **Context pruning:**
   - `ARC3_PRUNE_CONTROL_CONTEXT` (master), `ARC3_PRUNE_NUDGES`, `ARC3_PRUNE_RESUME_PROMPTS`, `ARC3_PRUNE_DEAD_STUBS`;
   - these drop tagged nudges and resume messages from stored history;
   - every yield adds a resume message; with 449 requests in low that is many duplicates.
6. **`ARC3_STUB_DEAD_REASONING`:** replaces reasoning-only replies (no tool call, no content) with a stub in-turn. It saves re-sending 30-49k dead traces, but conflicts with preserved thinking (the reply had a rule in 2 cases). The B3/B4 design chose to keep reasoning, so use it with care.
7. **Degeneracy detector:**
   - `ARC3_DEGENERACY_RATIO` defaults to 0.01 zlib; our loops measured 0.037-0.19, so 0 detections;
   - raising it (e.g. 0.03-0.05, with `ARC3_DEGENERACY_MIN_CHARS` 500) would stub looping replies out of context, post hoc;
   - it does not stop generation; early cancel needs streaming;
   - with T 1.0 loops fell to 0-8 %.
8. **`ARC3_PREFER_TOOL_CALLS`:**
   - `prompts.PREFER_TOOL_CALLS_LINE`: "prefer another tool call over more reasoning: the code answers what the reasoning would only guess at, and running it is faster than thinking";
   - it enters only Duck's own prompt, not `arc2_system_prompt`;
   - its wording can be reused (F4 noted this; the rev 5 edits are similar but omit the speed claim).
9. **Reason-specific resume texts:**
   - Duck records `_resume_reason` ('yield_bare' = no tool call, 'yield_tools', 'timeout', 'tool_steps');
   - `ARC3_YIELD_RESUME_PROMPT` short / state_only; `ARC3_YIELD_RESUME_TONE` commit / neutral / minimal;
   - Duck's bare-reasoning text is "Stop deliberating and call the `python` tool NOW";
   - the adapter's full-mode opener ignores the reason and always sends one text, so a reply that ended with "let me code this" and no call gets the same "continue" text. This is directly relevant to behaviour 2 (intent to code, then more thinking).
10. **Board-dump guard:**
    - `ARC3_BOARD_DUMP_GUARD` collapses full-width board rows in tool output and appends a "compute, don't count" note;
    - its detector requires ≥ 24-character alphanumeric rows with no spaces;
    - ARC-2 rows printed as lists or with spaces would not match, so it needs adaptation.
11. **`ARC3_CONTEXT_DRAIN_FLOOR`:** keeps a real floor after trims. It doubles the trim frequency and costs cache hits. F2(c) optional test, not done.
12. **`ARC3_OPENER_COMMIT_HINT` / `ARC3_STEP_VERIFICATION_HINT`:** game-oriented commit hints; ARC-2 equivalents could push "transform + check now".
13. **Priority scheduler:**
    - `_game_priority` uses level / actions / tokens (token fade C-term `t/62000` via `ARC3_PRIORITY_TOKEN_SCALE`), plus `ARC3_ENDGAME_START_MINUTES` and `ARC3_PRIORITY_TAIL_*`;
    - the adapter feeds no ARC-2 progress (best train score), so the priority is effectively queue order + token fade;
    - a progress signal could favour branches with partial checks and starve hopeless ones (coverage lever).
14. **`ARC3_PERSISTENT_FUNCTIONS_REPAIR_HINTS`** is off. It adds retention repair hints, which would help the NameError loops.
15. **Server flags** from the milestone, not used:
    - `--mamba-track-interval 64`, `--page-size 64` (`E12_MAMBA_TRACK_64` = false), `--watchdog-timeout 1800`;
    - Franzen patch #4 (Mamba end-of-prefill checkpoint, LRU refresh) for prefix reuse;
    - this matters because uncached prefill ≥ generated tokens in rev 5 xhigh.
16. **Throughput knobs set below capacity:**
    - `E12_STREAMS` / `E12_LIVE_BRANCHES` = 6, while the engine supports 12 running;
    - at 6 running, decode is 306-408 tok/s; at 11-12 it is 420-431;
    - rev 5 contexts (p90 74-75k) allow 10 resident.
17. **Yield at 2,048 tokens** (milestone): every request > 2k ends the turn and adds a resume message. A larger `LOCAL_ANALYZER_YIELD_TOKENS` would cut resume messages and turn churn (low: 449 requests). The gate rotates at yields, so this is a fairness trade-off.

Also kept from Duck and possibly counterproductive: the nudge prefix "**You have not acted yet. Investigate first.**". The adapter keeps Duck's generic prefix and replaces only the game tail. Nudges fire only when a turn continues without a yield, so they are rare at 2,048-token yields.

---

## 4. Current prompt and helper texts (rev 5, as rendered from `arc2_duck.py` with `E12_ARC2_REV5=1`)

### 4a. System prompt

Rendered with a dummy 1-pair task. Real tasks list every training pair as digit rows, then every test input. The chat template adds its effort sentence: xhigh is the default; low reads "Reasoning effort is set to low. Keep your thinking brief and focused, moving directly to the conclusion without unnecessary elaboration.".

```
You are a coding agent solving an ARC-AGI-2 grid puzzle.

Task:
- Each grid is a rectangular list of rows of integers 0-9 (colors). The training pairs below define one transformation from input grid to output grid.
- Find the single rule that maps every training input to its output, implement it as a Python function `transform(grid)` that takes and returns a list of lists of ints, and submit it. It is then applied to each test input; the test outputs are unknown to everyone.
- Prefer the simplest rule that explains all pairs and also fits the structure of the test inputs. Use a fixed coordinate, color or size only when the examples show it is part of the rule. A lookup table or case distinction keyed on what you read from the input is a valid rule when the examples support it. Different rules can fit every training pair yet disagree on a test input: when you see that, compare their test outputs.

Training pair 1 input:
0 1
1 0
Training pair 1 output:
1 0
0 1

Test input 1:
0 0
1 1


Python tool guidance:
- Provided globals in every `python` call: `train` (a list of {'input': grid, 'output': grid}), `test_inputs` (a list of grids), `check(transform)` and `submit(transform)`. Each `train` item is a dict: `for p in train: inp, out = p['input'], p['output']`.
- Read exact grid values, sizes, counts and coordinates with Python rather than counting cells or simulating outputs by hand.
- `check(transform)` runs your function on every training input and prints how many pairs are exact and, for each failing pair, the shape mismatch or the error, or a sample of wrong cells as (row, col, got, expected). `check(transform, verbose=False)` prints nothing and returns the per-pair results as a list.
- `submit(transform)` submits your final function. The harness re-runs it on every training pair in a clean sandbox; if all pairs are exact, its test outputs become your answer and the task ends. Otherwise you get the failures and continue. Submit only a function that `check` shows exact on every pair.
- Every time `check(transform)` is exact on every pair, the harness re-runs that function in a clean sandbox and keeps it as a candidate answer, even if you never submit it; later exact versions are kept too. So check a candidate as soon as you have a plausible rule.
- Work in pure Python lists: numpy is not available.
- The only importable standard-library modules are: bisect, collections, copy, difflib, fractions, functools, heapq, itertools, json, math, operator, random, re, statistics, string.
- Never print full grids unless they are small. Return compact derived summaries such as object lists, diffs, coordinates or counts.
- Use `print(...)` for compact summaries, or assign a final compact object to `result`.
- A strong default loop is: inspect the pairs in Python, form a hypothesis, write `transform`, run `check(transform)`, fix it from the reported cells, then `submit(transform)`.


Tool session rules:
- You have exactly one tool: `python`.
- When calling `python`, emit exactly the tool-call format shown elsewhere in this prompt for this model. Use only that format; do not add markdown fences, prose wrappers, or alternate tool-call syntax. Do not quote or place tool-call markup inside explanatory text; when you decide to call the tool, emit the tool call itself.
- Python variables reset between tool calls. Eligible functions you define are retained automatically for later calls on this task. Call your retained functions directly without repeating their definitions. Redefine a function when you need to change it.
- For a function to be retained, its dependencies must also be available next call. Pass snippet-specific data as arguments. You may use Python builtins and other retained functions (not the provided globals). Provided globals are refreshed for each call. Supported explicit top-level imports used by retained functions are restored with them; imports inside a function also work. Use plain top-level definitions without decorators or annotations, and literal defaults. Tool results report which functions were retained and explain any rejection.
- Functions that read `train` or `test_inputs` directly are not retained; pass the data as arguments.
- You can call the `python` tool as many times as you want. Write and check a candidate `transform` as soon as you have a plausible rule; do not wait for a perfect explanation.
- Each `python` tool call has a hard time limit of 30 seconds.
- Tool responses are capped to about 3072 tokens. If a response is cut off, the tool result will tell you that.
- Keep code snippets short and purpose-built rather than dumping large frameworks into one call.
```

**Pre-rev-5 lines replaced by `_R5_EDITS`** (still used when the rev 5 flag is off):
- "Prefer the simplest rule that explains all pairs, and make it general: derive positions, sizes, colors and counts from the input. Use a fixed coordinate, color or size only when the examples show it is part of the rule. Check that the rule also fits the structure of the test inputs."
- "You can call the `python` tool as many times as you want. Investigate until your code has a clear plan."
- (no `train` dict example, no "read exact values with Python" line, no "check keeps candidates" line).

### 4b. Tool description (`ARC2_TOOL_DESCRIPTION`)

"Run one Python snippet. Provided globals: `train` (list of {'input': grid, 'output': grid}), `test_inputs` (list of grids), `check(transform)` (prints and returns per-pair exactness on the training pairs) and `submit(transform)` (submits a top-level function; the harness verifies it). Grids are lists of lists of ints 0-9; numpy is not available. Use `print(...)` for compact output or assign final data to `result`."

### 4c. User openers and resume texts (`_build_user_prompt`)

**First turn:**
"Solve the task in the system prompt. Start with the `python` tool: inspect `train` and `test_inputs`, then build and `check` a `transform`."
Duck's retained-function note is appended, with "in this game" reworded to "on this task".

**After a rejected submit:**
"Your last submission (`<name>`) was not accepted: <summary> Continue from your earlier work: fix the rule or the code, run `check`, and submit again."

**Resume after a yield (every request > 2,048 tokens):**

| Variant | Text |
|---|---|
| rev ≤ 4 | "Nothing has been submitted since the message above, so it still holds. Your tool results above are still valid: continue from them rather than starting over." |
| rev 5 `ARC2_RESUME_R5` | "Nothing has been submitted yet. Your earlier reasoning and any tool results are above: continue from them rather than starting over." |
| rev 5 `ARC2_RESUME_CUT` (prepended once after a length-cut call) | "Your previous reply reached the output limit before its tool call was complete, so nothing was executed; emit the `python` tool call earlier this time. " |
| rev 5 `ARC2_RESUME_TRIMMED` (replaces R5 text when the trimmer or force-reduce removed messages) | "Nothing has been submitted yet. To fit the context window, older messages were removed, possibly including your latest reasoning and tool results. Functions you defined are still retained in the Python tool. Recover any fact you need by running Python rather than by re-deriving it by hand, then write or fix `transform`, `check` it, and submit it." |

**Nudge** (no tool call, turn continues): Duck's generic prefix, then the ARC-2 tail, then the tool-call format guidance.
- Prefix variants:
  - "You have not acted yet. Investigate first. ";
  - the "Your previous reply was CUT OFF … emit the `python` tool call early …" variant;
  - the malformed-JSON variant;
  - the `<tool_call>`-markup-in-text variant.
- ARC-2 tail (`ARC2_NUDGE_TAIL`): "Call the `python` tool: write or fix `transform(grid)`, run `check(transform)` on the training pairs, and `submit(transform)` once every pair is exact. "

**Harvest notes** (rev 5, in the tool result `candidate` field):
- "Kept `<name>` as a candidate answer: a clean re-run is exact on all N training pairs. Keep improving it if you are unsure (each exact version is kept), or call submit(<name>) to finish."
- "check() was exact, but the clean re-run did not keep `<name>`: <summary>"
- the cap note: "the limit of 24 candidate checks per task is reached; submit your best function."

### 4d. Helpers (trusted prelude, prepended to every tool call)

**Globals:**
- `train = [...]` and `test_inputs = [...]` as compact JSON literals;
- `_arc2_grid_ok(g)`: rectangular, 1-30 per side, ints 0-9.

**`check(transform, verbose=True)`:**
- per pair: exception → `{"pair", "ok": False, "error"}`; invalid grid → error; shape mismatch → shape / expected_shape; else `wrong_cells` + `wrong_sample_row_col_got_expected` (first 12);
- prints "check: k / n train pairs correct" and each failing record;
- `verbose=False` returns the list;
- rev 5: when every pair is exact, it sends `action({"action": "CHECKED:<name>"})` (try/except).

**`submit(transform)`:**
- requires a top-level `def` (not a lambda);
- sends `action({"action": "SUBMIT:<name>"})` and prints "submitted <name> - the harness now verifies it…".

**Host verify (`_verify_submission`):**
- one clean sandbox per grid, with the retained sources + that one input only;
- the value comes from the structured `result`;
- 2 × 30 s budget, stop after a timeout;
- rev 5 `json.dumps` guard;
- accept = all train exact and every test output a valid grid; test outputs always kept for the partial fallback.

**Selection:**
- rev ≤ 4 `select_attempts`: accepted submissions grouped by output > partial > test input.
- rev 5 `select_attempts_r5`: per branch, latest accepted submit else latest accepted check; grouped by output (more branches > explicit submit > latest); then other accepted (latest first); then partial; then the test input. attempt_2 = the next distinct grid.

### 4e. Settings by revision

| Knob | SMOKE1 / EVAL30 (rev 3) | EVAL6 (rev 4) | EVAL6R5 / EVAL12R5_LOW (rev 5) |
|---|---|---|---|
| max_output | 12,288 | 60,000 | 49,152 |
| temperature / top_p / top_k | 0.7 / 0.95 / 20 | 0.7 | 1.0 |
| effort | xhigh (template default) | xhigh | xhigh / **low** |
| window / drain | 131,072 / 59,392 | same | same |
| input budget | 118,272 | 70,560 | 81,408 |
| streams / live branches | 12 / all | 6 / 6 | 6 / 6 |
| per-branch cap | none | 100k soft | 100k soft |
| read timeout | 900 s | 1,800 s | 1,800 s |
| solve window | 900 s / 13,367 s | 5,400 s | 5,400 s / 9,000 s |
| check-verify cap | — | — | 24 |
| tokenizer.json | — | — | loaded (probe 2,400 chars = 441 tokens) |
| sandbox | RLIMIT_AS 4 GB | same | same |
| stop before hard stop | 180 s | 180 s | 180 s |
| request logs | SMOKE1 on | off | off |

---

## 5. Zip contents (listed only)

| Zip | Entries | Contents |
|---|---|---|
| `E12_STEP3_5_BUILD_AUDIT_FOR_GPT_2026-10-19` | 38 | AUDIT_REQUEST, milestone settings, Build, SGLang SMOKE1/EVAL30 nbs, PLAN, arc2_duck + vendor (22), harness (fake_openai, fake_sgl_duck_server, harness_e12, harness_e12_nb, nblogs, smoke_adapter), push script |
| `E12_STEP3_5_REV2_AUDIT…` | 58 | + GPT_AUDITS_VALIDATED, SHA256SUMS, fixtures (13), logs, validate_gpt_findings |
| `E12_STEP3_5_REV3_FOR_PUSH…` | 62 | + GPT_REAUDITS_VALIDATED_REV2, time_poetiq_programs, validate_rev2_findings |
| `E12V_VLLM_ENGINE_BUILD…` | 76 | + VLLM nbs, fake_vllm_duck_server, reference/duck_kaggle_vllm_launcher, vllm_v0.19.0 (7) |
| `E12V_VLLM_ENGINE_AUDIT_FOR_GPT…` | 77 | the same as BUILD + AUDIT_REQUEST_E12V |
| `E12V_VLLM_ENGINE_REV2…` | 81 | + GPT_AUDITS_VALIDATED_E12V, validate_e12v_findings |
| `E12V_VLLM_ENGINE_REV3…` | 82 | the same set, more logs |
| `E12_REV4_EVAL6_AUDIT_FOR_GPT_2026-10-20` | 24 | 00_AUDIT_REQUEST, eval30_request_stats, rev4_simulator, base EVAL30 nb, build/push, diffs, arc2_duck, harness rev4, EVAL6 nb, reference docs + EVAL30 run report |
| `E12_REV4_EVAL6_FINAL_AUDIT…` | 34 | + validated doc, audited versions, diffs, gpt_audits GPT-A/B/C.txt |
| `E12_AGENT_WEAKNESS_ANALYSIS_FOR_GPT_2026-10-20` | 267 | 00_README, adapter, agent_reports A-D, analysis scripts + outputs, data subsets, docs, runs EVAL30 (185) / EVAL6 (54) |
| `E12_REV5_AUDIT_FOR_GPT_2026-10-21` | 40 | 00_README, build/push, diffs rev4→rev5, docs, arc2_duck + vendor (9), EVAL6R5 / EVAL30R5 nbs, previous rev 4, tests harness / replay / unit |
| `E12_REV5_FINAL_FOR_GPT_2026-10-21` | 44 | + diffs audited→final, previous first-audit versions, tests/validators |
| `E12_REV5_RESULTS_FOR_GPT_2026-10-21` | 240 | 00_README, adapter, analysis eval6 + rev5, data 12-task subsets, **discussions** (00_SUMMARY + 9 Kaggle threads, incl. Qwen3.8 thread and topics 709522 … 748082), docs, EVAL12R5_LOW / EVAL6R5 nbs, runs EVAL12R5_low (101), EVAL6R5 (53), EVAL6 rev 4 (53) |
