# ARC-AGI-3 Duck winners (dfranzen milestone-2 + 7 top-10 forks) — how they make the model think less, act in code early, and run fast

Sources read in full (2026-10-21):
- EXT = `scratchpad/ext/resources_ARC-AGI-3_related_ARC3_top10_kv_01_dfranzen__arc-agi-3-milestone-2-solution_arc-agi-3-milestone-2-solution.ipynb.txt` (11,008 lines; cell 2 = the ~10k-line harness patch L25-10111; cells 4-22 = config/serving L10112-11008). `kv_09_hknight888` is byte-identical to it (`cmp`).
- `scratchpad/forkdiff/*.diff` (03, 04, 05, 06, 07, 08, 10).
- `scratchpad/p1zip/*` (our ARC-3 B0+P1_SPARSE run, 2026-09-15).
- Our adapter `D:/ARC AGI 2/experiments/Experiment 12 - Duck REPL agent for ARC-AGI-2 (planned)/duck_arc2/arc2_duck.py` (1,033 lines, read fully).

Line refs "EXT Lnnnn" are into the extraction file.

---------------------------------------------------------------------------------------------------
## 1. What dfranzen actually ran (the settings that matter; EXT L10173-10252, L10405-10430, L10668-10711, L10770-10790)

Analyzer env (cell 4, EXT L10188-10241) — only these are ON; many patch features stay OFF:
```
'ARC3_REASONING_HISTORY_KEY': 'reasoning_content',
'LOCAL_ANALYZER_ENABLE_THINKING': 'true',
'LOCAL_ANALYZER_TOOL_STEPS': '0',            # unlimited tool steps per turn
'LOCAL_ANALYZER_TOOL_TIMEOUT': '30',
'LOCAL_ANALYZER_YIELD_SECONDS': '0',
'LOCAL_ANALYZER_YIELD_TOKENS': '2048',       # turn ends after the reply/tool result that crosses 2,048 generated tokens
'LOCAL_ANALYZER_TEMPERATURE': '0.7', 'LOCAL_ANALYZER_TOP_P': '0.95', 'LOCAL_ANALYZER_TOP_K': '20',
'LOCAL_ANALYZER_CONTEXT_WINDOW': (116+12)*1024,
'LOCAL_ANALYZER_MAX_OUTPUT': 12*1024,        # <-- HARD per-request output cap (thinking + call) = 12,288
'ARC3_CONTEXT_DRAIN_TOKENS': 58*1024,
'ARC3_HISTORY_ASSISTANT_TURNS': 150, 'ARC3_HISTORY_TURN_DRAIN': 30, 'ARC3_HISTORY_DRAIN_COALESCE': '1',
'LOCAL_ANALYZER_TOOL_OUTPUT_TOKENS': '3072', 'ARC3_MIDDLE_TRUNCATION': '1', 'ARC3_ACTION_ECHO': '1',
'ARC3_EXPLAIN_GAMEPLAY_CHANGED': '1', 'ARC3_NEW_CHANGED_PROMPTS': '1', 'ARC3_LEVEL_TRANSFER_GUIDANCE': '1',
'ARC3_ACTION_INFO': '1', 'ARC3_DEDUPE_MULTICALL_LINE': '1', 'ARC3_FRAME_DIFF_HINT': '1',
'MULTIMODAL_CONTEXT': 'current_grid', 'MULTIMODAL_UPSCALE': '10', 'ARC3_DIFF_IMAGE': '1',
'ARC3_GAMEOVER_DIFF_IMAGE': '1', 'ARC3_ANIMATION': '1',
'ARC3_GUARDS_FROM_LEVEL': 2, 'ARC3_BATCH_NOOP_BLOCK': '1', 'ARC3_STALE_STATE_BLOCK': '1',
'ARC3_MEMORY_SECTIONS': 'off',
'ARC3_PERSISTENT_FUNCTIONS': '1', 'ARC3_PERSISTENT_FUNCTIONS_SCOPE': 'game', 'ARC3_PERSISTENT_FUNCTIONS_IMPORTS': '1',
'EXPOSE_UNDO': 'on',
# priority scheduling
'ARC3_MAX_ACTIVE_STREAMS': 10, 'ARC3_PRIORITY_REFRESH_QUEUE': '1', 'ARC3_PRIORITY_PACE': '0',
'ARC3_PRIORITY_TAIL_FADE': '1', 'ARC3_PRIORITY_TAIL_FADE_FRACTION': '0.2',
'ARC3_PRIORITY_TAIL_LOOKUP': 'remaining', 'ARC3_PRIORITY_SCORE_NORMALIZATION': '1',
```
NOT set (so OFF) in the winning config: `ARC3_PREFER_TOOL_CALLS`, `ARC3_OPENER_COMMIT_HINT`, `ARC3_REASONING_EFFORT_LADDER`, `ARC3_SUMMARY_INTERVAL_TOKENS`, `ARC3_BOARD_DUMP_GUARD`, `ARC3_STUB_DEAD_REASONING`, `ARC3_PRUNE_*`, `ARC3_AUTO_FRAME_DIFF`, `ARC3_YIELD_RESUME_PROMPT` (=> 'full'), `ARC3_YIELD_RESUME_TONE` (=> 'commit', but unused in full mode, see 3.2), `ARC3_DEATH_*`, `ARC3_NOOP_REPEAT_GUARD`. Also `ARC3_HTTP_RETRY_INITIAL_SECONDS=900`, `ARC3_WARMUP_ACTION_GAMES=1` (L10134-10135).

Solver (cell 16, L10770-10785): competition `concurrency = 120` games (110 hidden), `max_runtime_s_per_game = 532*60`, `analyzer_timeout = 900`, `max_actions_per_game = None`, n_passes 1. Demo v3: 25 games x 4 passes, budget scaled `532*60*concurrency//110`.

Server (cell 12, L10405-10430, L10668-10711) — SGLang "Pennyroyal" v2.5.3 fork, Qwen3.8-Flash-Next W4A16 AutoRound, RTX PRO 6000:
```
CTX=(116+12+8)*1024, MEMFRAC=0.96, MAXREQ=10, CUDAGRAPH_MAXBS=10, MAMBA_CACHE=60, CHUNK=8192, MAX_PREFILL=16384,
SPEC=True (NEXTN, --speculative-num-steps 3, eagle-topk 1, num-draft-tokens 4, accept thresholds 1.0/1.0),
FRSPEC=True (--speculative-token-map hot_tokens_64k.pt: draft lm-head restricted to 64k hot tokens),
KVDTYPE=fp8_e4m3 (also for draft KV), SSM_DTYPE=bfloat16, --mamba-radix-cache-strategy extra_buffer, --mamba-track-interval 64,
--page-size 64, --schedule-policy lpm, --cuda-graph-bs-decode 1 2 4 7 8 9 10,
--reasoning-parser qwen3 --tool-call-parser qwen3_coder --default-chat-template-kwargs '{"preserve_thinking":true}',
--enable-cache-report --enable-metrics, --weight-loader-prefetch-checkpoints, --weight-loader-drop-cache-after-load,
precache weights with 3 threads in parallel with server start (L10266-10331); SERVER_STARTUP_TIMEOUT 12 min.
```
Throughput evidence (fork 06 audit, diff L33, L224): v3 job = 100 trajectories, 10-request server, 8h10m56s, **17.50 M generated tokens** => ~595 tok/s aggregate on one RTX PRO 6000; peaks 94.5 GB GPU; 9 read timeouts, no OOM/overflow.

---------------------------------------------------------------------------------------------------
## 2. Prompts (verbatim)

### 2.1 Tufa base system prompt (our P1 copy `p1zip/sparse_p1_system_prompt_base.txt`, 96 lines; dfranzen edits it via the patch)
Key code-first lines (base L23, L63-L76, L79, L90-96):
- "The raw numeric grid is intentionally not exposed. Use `current_frame.segmentation` as your primary view of the board -- objects, colors, shapes, containment, adjacency, and cross-frame object hashes. Use `current_frame.ascii` only to read a small, specific region; do not scan the whole board with it."
- "Use `current_frame.ascii` only to read a small, specific region of the board when `segmentation` is not enough; never use it to scan or summarize the whole board."
- "Always inspect `current_frame`, `history`, and `valid_actions` from Python instead of reasoning from the raw board by eye."
- "IMPORTANT: Especially when the game is about making an agent navigate to a target, it is usually safer to write an explicit search algorithm such as BFS. ..."
- "Once the important state variables and action effects are sufficiently understood, stop probing and search in the inferred state space."
- "Inspect current and history frames from Python instead of describing frames freehand."
- "Never print or echo full board frames. Return only compact derived summaries such as object lists, diffs, coordinates, counts, or tiny local crops."
- "Keep tool-output context size minimal and decision-oriented so you can quickly compare before/after state. It's fine to write a lot of python code, just make the output short and interpretable"
- "A strong default loop is: summarize the board, infer the desired environment change, write a small scorer or search over candidate sequences, execute the best probe or plan with `action(...)`, then inspect again until you understand exactly what changed."
- "You can call the `python` tool as many times as you want per step. Investigate until your code has a clear probe or plan."
- "Do not ration tool calls when the state is unclear. ..."
- "Keep code snippets short and purpose-built rather than dumping large frameworks into one call."
- Multimodal: "User turns include an attached image of the current ARC grid. The image and `current_frame.ascii` are two representations of the same current frame."

=> In ARC-3 Duck the board is NEVER in the prompt as text: the model sees an image (EXT L10221-10222 upscale 10, ~402 tokens, L4033-4036) and must call Python to read any cell.

### 2.2 dfranzen prompt additions (EXT L434-750)
- PREFER_TOOL_CALLS_LINE (EXT L687-700; OFF in his run, ON in fork 08):
  "- Reading and computing cost nothing; only `action(...)` spends the level budget. When you are unsure, prefer another tool call over more reasoning: the code answers what the reasoning would only guess at, and running it is faster than thinking your way to the same answer.\n"
  Code comment (L688-695): "decode runs at tens of tokens per second per stream, while a tool call is a short generation plus a mostly-cached prefill, so 2,000 tokens of further reasoning costs far more wall-clock than running the code that would settle the question." Docstring L3147-3156: "...only ever compares them with other tool calls - never with reasoning, which is the trade the model actually makes when it writes twelve thousand characters of hypothesis before its first snippet. Observed: a turn spent 18,012 characters reasoning, hit the output cap, and executed nothing."
- PERSISTENT_FUNCTIONS_LINE (L706-716): "- Python variables reset between tool calls. Eligible functions you define are retained automatically {lifetime}. Call your retained functions directly without repeating their definitions. Redefine a function when you need to change it. ..."
- STEP_VERIFICATION_ADDENDUM (L642-653): "...If your search finds no solution under your current model of the game, remember that the game is solvable. Reconsider your mechanics, goal, search implementation, or search limits..."
- WORLD_MODEL_ADDENDUM / FREE (L655-668): "- Optimize for the shortest reliable sequence that advances the current goal. If confidence is low, program a discriminating probe and revise your approach from the result."
- SUMMARY_REQUEST_PROMPT (L736-750): "Summarize everything above: what you have established about this game, what you have ruled out, what you were in the middle of, and anything else a later turn would need. Keep uncertain ideas tentative, and preserve unresolved alternatives. Do not act and do not call any tool - write the summary only. Write it to stand completely on its own. Everything above this point will eventually be dropped and replaced by this summary, and earlier summaries go with it, so anything you leave out is gone. Length is not a problem here; leaving something out is." (OFF in run.)
- Level start (L443-456), level transfer guidance (L434-441) — game-specific.
- FRAME_DIFF_HINT (L631-640): object-level diff helper `frame_diff()` documented (ON).
- BOARD PRINT GUARD (L2846-2891, OFF): collapses >=6 consecutive full-width board rows, then appends: "[BOARD PRINT GUARD] Printing full boards is disallowed and character counting is unreliable for you. Compute over the grid in python (segmentation nodes, slicing, run-length checks, BFS) and print only coordinates, counts, and small crops."

### 2.3 Turn opener (EXT L5788-5886) — the message that opens every turn and, in 'full' resume mode, every resumption
Lines kept verbatim: "Only tool: `python`. It receives `current_frame`, ... `frame_diff(before, after)`, and `action(actions)`." / "Only letter-coded board views and lightweight metadata are exposed; raw numeric color IDs are not available." / "Keep tool output compact: use `current_frame.segmentation` as the primary view, and `current_frame.ascii` only for a small specific region; never print full boards." / with memory off: "Use Python to inspect the evidence from the newest history, and search or score candidate actions or short sequences against the current goal as you currently understand it." / first turn: "Ground yourself in `current_frame` before acting, but start with a compact structural summary rather than restating the full frame." / closing: "When ready, call `action(actions)` from inside the `python` tool with the best valid action or ordered batch selected by your code. If your code has found a reliable short sequence, prefer batching it in one call." + TOOL_CALL_FORMAT_GUIDANCE.
Optional commit hint (L3089-3104 + L5878-5886, OFF in run, ON in fork 08): "When your evidence supports a choice, call `action(actions)` with the sequence it supports. Probe with a single action when you genuinely need to distinguish two possibilities; otherwise batch the route you have." Evidence in docstring: batches after a resumption 6.73/6.91 actions vs after a fresh opener 5.43/3.91.
Stale-summary lines (L1627-1671): "Your last python snippet executed NO actions (it only computed or inspected state - that is fine)." / "Your previous exchange this turn produced no tool call and executed no actions."

### 2.4 Resume / nudge texts (EXT L1931-2105, L7484-7539)
- `_YIELD_RESUME_PROMPT_WITH_TOOLS` (commit): "You yielded control on the turn time budget. Your tool results above are still valid - do NOT restart your analysis or re-inspect the board from scratch. Continue from them and call `action(actions)` with your best next action or short batch."
- `_YIELD_RESUME_PROMPT_NO_TOOLS`: "You spent the entire turn budget reasoning without calling a tool. Stop deliberating and call the `python` tool NOW: inspect `current_frame.segmentation`, then call `action(actions)` with the best available action. Acting on a partial model beats another turn of analysis."
- neutral / minimal variants (L1938-1944, L1985-2020).
- `_RESUME_PROMPT_TIMEOUT`: "...Continue from them and call `action(actions)` with your best next action, keeping your reasoning short so the next request completes."
- `_RESUME_PROMPT_TOOL_STEPS_EXHAUSTED`: "You used every available tool step this turn without calling `action(actions)`. Your tool results above are still valid - do NOT begin a new investigation. Act NOW with the best option you already have."
- IMPORTANT: these texts are used only in `ARC3_YIELD_RESUME_PROMPT=short|state_only` (L7232-7244). dfranzen ran 'full' => after every yield the **full opener is re-sent** (2-3k tokens, L2043-2044) with the stale line + "When ready, call `action(actions)`...". Verified in our vendored tool_agent.py: `_yield_resume_prompt(` only at L6670/L6675 (state_only/short branches).
- Truncation follow-up (L7485-7494): "Your previous reply was CUT OFF before the tool call finished, so the call was incomplete and could not be executed. Keep your reasoning much shorter this time and emit the `python` tool call early enough that it completes within the output limit. Prefer one small snippet over a long analysis. "
- Malformed JSON follow-up (L7495-7500); no-tool nudge prefix "You have not acted yet. Investigate first. " + "Then investigate and revise your working world model ... Call the `python` tool with code that inspects ..." (L7484, L7520-7539).
- Dead/degenerate stubs (L2022-2027): "(previous attempt produced no tool call)" / "(previous reply was highly repetitive and has been omitted; do not continue that pattern - write concise plain prose)".

---------------------------------------------------------------------------------------------------
## 3. How thinking length is controlled

3.1 **Per-request cap 12,288 tokens** (`LOCAL_ANALYZER_MAX_OUTPUT`, L10201). Thinking + tool call must fit; reasoning is kept in history (`preserve_thinking` template kwarg L2581-2593 + server default L10689, `reasoning_content` key L10189, L2518-2534) so a cut reply is continued, not lost. Comment L688-691: "a truncated reply keeps its reasoning in history, and what is lost is only that nothing executed - ... truncation touched about 4% of replies." A cut tool call with broken JSON is dropped entirely and never enters history (L7373-7398), then the CUT OFF follow-up is sent.

3.2 **Yield by generated tokens = 2,048** (L1494-1500, L7276-7292; CONFIGURATION.md fork-05 L407: "Checked between completions; it is not a hard mid-stream token cutoff"). Checked at loop top, after a no-tool reply, and after each tool result (vendored tool_agent L6737, L6980, L7097). Effect: any response >2k ends the turn; the solver re-invokes on the same state; the new turn re-sends the full opener (+ image) ending with the commit line. So the model gets a fresh "call action with your best batch" every ~2k tokens of output. Rationale (L1494-1499): "A wall-clock budget is really a token budget with the throughput baked in..."

3.3 **Reasoning-effort ladder** (L2565-2578, L7351-7365, L7565-7572; OFF in run): on finish_reason=length step down `ARC3_REASONING_EFFORT_LADDER="medium,low"`; reset only when an action makes progress (made_progress, L3990-3995). Passed as chat_template_kwargs reasoning_effort (L5894-5910).

3.4 Per-game generated-token budget `max_generated_tokens_per_game` (L7978-7994, L8381-8403) — "what makes an offline run comparable with a Kaggle one" (None in the hidden run; fork 08 sets 750,000).

3.5 Stop conditions: should_stop (run not playing, actions cap, token cap; L8405-8414); consecutive analyzer failures >10 => give up game (L8080, L8484-8499); read timeout => yield with history preserved (L2120-2134, L7584-7618).

3.6 Measured scale: KM restricted-mean tokens per ARC-3 level 27k-67k (priority_pace_reference.json L270-285). Our P1 run: **1,477 generated tokens per model call**, 54 calls/game, 509 tokens/action, 56.6k tokens/level (p1_efficiency.json L1-18). Duck in ARC-3 thinks in many SHORT calls.

---------------------------------------------------------------------------------------------------
## 4. Context eviction / trimming / compression
- Token trimmer with **drain hysteresis** (L1529-1549): trigger at budget, drop until budget-58k, so evictions are rare and large (prefix cache is invalidated by ANY front removal). Floor mode (L1509-1526) off.
- Assistant-turn cap 150 with drain 30 and **coalesce** (L1552-1590, L6868-6894): take the deep turn cut in the same commit that already invalidated the prefix.
- Never drop the last user message (L6837-6850, "No user query found in messages" HTTP 400 bug).
- Context-overflow: SGLang wording recognised (L4230-4241) and force_drain on rejection (L7329-7350).
- Rolling summaries (L2225-2440, L6620-6812; OFF): scheduled every N new-context tokens, appended at end (keeps KV + recurrent state warm), summary thinking OFF by default with the template trick: "Forcing that conditional true (`{%- if true %}`) keeps the sentence unconditional and leaves only the tail block varying, which restores a byte-identical prefix" (L2405-2424; measured prefix reuse 75% -> 45% without it). Tools are always sent even for the summary request: "a request without them diverges from the first tokens ... measured at 15% shared prefix against 99% with them" (L7184-7192).
- Control-message pruning (L2443-2515), image history window (L2153-2222), stale summary marking (L6557-6560, L7676-7685) — off or n/a.
- Token estimate calibration from server prompt_tokens (L4039-4096, L6572-6618): chars/token clamp [1.0, 3.3]; images counted by PNG patches 32 px + 2 (L4033-4152), fallback 402 tokens for a 64-cell board at upscale 10; `ensure_ascii=False` (L4178-4193).
- Tool output 3,072 tokens, **middle truncation** keeps head 2/3 + tail 1/3 (L6036-6066) so the error/conclusion survives.

## 5. zlib degenerate check (L2907-2942, L4562-4575, L7420-7479)
`len(zlib.compress(text,6))/len(text) < 0.01` (min 500 chars) => degenerate (prose 0.20-0.28, coords 0.28, ASCII board 0.016, repeated sentence 0.008, mojibake 0.0016). A reasoning-only degenerate reply ("exactly 6144 '!' ... under speculative decoding") is replaced by the stub; keeping it "pushed the trimmer from 31 history messages to 12". Memory sections capped 8,000 chars (L2894-2904).

## 6. Tool design (sandbox L751-1348)
- One `python` tool; fresh subprocess per call (`python -I -S`), 30 s limit, safe module allowlist (+difflib) and more exception builtins (L789-825).
- REPL-style: the last expression is evaluated and printed (L1189-1207) — saves the model from writing print().
- Function retention across calls (retained_functions.py L9715-10021): only top-level, unannotated, literal-default, no-global-write defs; dependencies checked; imports optionally restored; the opener lists retained signatures (L5307-5328).
- `frame_diff()` object-level diff (Hungarian matching, rotation-aware hashes; L9244-9551, L10022-10111).
- Refusal exceptions derive from BaseException so `except Exception` in model code cannot swallow them (L920-993); terminal latch (L964-997); stale-state / repeat-state / known-noop / known-death guards (L80-263, L6123-6293, L8543-8616).
- Action echo printed into the snippet's stdout (L8185-8217).
- Leaked `<TOOLCALL>` text fallback (L1709-1767).
- Streaming SSE assembly decoding raw bytes (L6004-6017, L9619-9714); connect timeout 10 s separate from read (L5967-5975); retries with Retry-After floor (L1785-1926).

## 7. Concurrency and scheduling (L3159-3564, L6947-7047, L8416-8456)
- `_PriorityGate`: 10 active streams (= server MAXREQ 10), 120 game threads queued. A game **keeps its slot while its prefix is intact**; it hands over only when the trimmer invalidated the prefix ("the one moment when yielding is free"). Bands: untrimmed 2,000,000; warm 1,000,000; awaiting prefill 0..1,325.
- Priority (A+B)*C with A = level*efficiency, B = remaining-levels tail (8/7/5/0), C = blend of action and token decay (scale 62k tokens); tail fade over last 20%.
- Fork 03 shiiin9 "D'": priority = A·M·C + B·φ (pace-aware, unstarted games priced by the same formula, fade 0.4) — **LB 31.54 (n=1)** vs dfranzen 27.89 (his LB), 31.47 (best on page), 27.62 (unchanged resubmission). Fork 07 amatlas ports D'.
- Variance is large: fork 06 skarin, same immutable version: **27.80 then 21.01**; dfranzen v3 4x25 public mean 46.49, replicate means span 1.87 but ten games span >=40 points; 33/100 wins, 23/100 perfect.

## 8. Fork diffs (what each changed; reported LB)
| fork | change | LB stated |
|---|---|---|
| 03 shiiin9 affectify | only the slot-priority formula D' (A·M·C+B·φ), fresh games priced by formula, tail fade 0.4 | 31.54 (one sub) |
| 04 sigeward | wrapper robustness: input checks, 7-min startup, spec/FR-Spec graceful fallback, 120 s teardown reserve | none given |
| 05 vladimiryakunin DF-WM | "World model as code": `SimFrame`, `compare_grids`, `check_sim()` (verify `simulate(frame,action)` on all past transitions, accuracy + mismatches), `search()` BFS (max_depth 15, max_states 1500), `act_checked()` (predict each action, stop batch on divergence, `PredictionMismatchError`); persistent functions default game scope; adds CONFIGURATION.md inventory; soft end 15 min before 9 h | none given |
| 06 skarin | reproduction + 100-trajectory audit | 27.80 / 21.01 |
| 07 amatlas | dfranzen + D' port | cites 31.54 |
| 08 bang1850 "sovereign" | turns ON most optional flags: OPENER_COMMIT_HINT, PREFER_TOOL_CALLS, STEP_VERIFICATION_HINT, all guards + death ledger, AUTO_FRAME_DIFF (budget 800), upscale 12 bilinear, summaries no, PRUNE_CONTROL_CONTEXT, YIELD_SECONDS 90, tool timeout 60, max_generated_tokens 750k, tail fade 0.05; spec fallback restart | none given |
| 10 manwithacat | reproduction baseline (3 public games, 240 s) with its own Python 3.12 | none |
| 09 hknight888 | identical to dfranzen | — |

DF-WM prompt (diff 05 L1411-1423) verbatim: "Executable World Model Simulator:\n- When you understand game mechanics, express them as code: `def simulate(frame, action): ...` ... - Call `check_sim()` in Python to instantly verify your `simulate` function against past action transitions. It returns accuracy and any mismatched coordinates without spending game actions.\n- When `simulate` is verified, plan multi-step routes with `search(current_frame, simulate, is_goal_fn)` instead of manual guessing. ... - Execute multi-action batches with `act_checked(actions)`. It predicts the outcome of each move before executing it; if reality diverges from prediction, the batch stops immediately, preventing wasted actions.\n- Retained `simulate` functions persist across turns and levels. Redefine `simulate` whenever you discover new rules or level-specific mechanics.\n"

## 9. Our P1_SPARSE evidence (p1zip)
- B0+P1 = Tufa base prompt minus "64 x 64", "puzzle", the HUD/"DON'T DO THIS!" paragraph, plus a 6-line "mechanics" block (sparse_p1_prompt_diff.txt). Score 6.91 (score.json), 35 levels.
- Engine: vLLM, Flash-Next NVFP4, MTP 3, ctx 32,768, max_num_seqs 8, prefix caching OFF (`TAAF_VLLM_ENABLE_PREFIX_CACHING=0`), yield 60 s, MAX_OUTPUT 0 (unlimited), upscale 4 (p1_environment.json, taaf_setup_env.json).
- 1,340 model calls, 664 action-bearing, 3,882 actions, 1.98 M tokens over 25 games in ~2.2 h/game (7,920 s); **1,477 tokens/model call**, 5.8 actions/action-bearing call (p1_efficiency.json L1-18). Startup to preflight 574 s.

## 10. Our ARC-2 adapter vs dfranzen/Tufa (what we do NOT use)
1. **Grids as text in the system prompt** (arc2_duck.py L327-330: every train input/output and test input as digit rows). Tufa's core design is the opposite ("raw numeric grid is intentionally not exposed"; image + Python only). This invites hand-reading in thinking (our ~55k-token first check).
2. Per-request cap: we raised it to 60k (`E12_DUCK_MAX_OUTPUT`, L67-69, rev 4) vs dfranzen 12,288 => the CUT OFF/"keep reasoning much shorter" feedback loop and the effort ladder never act. (Rev 5 B6 handles cut calls, L600-622, L424-427.)
3. Resume text is neutral (L422-431, L497-502): "continue from them rather than starting over" — no commit pressure; dfranzen re-sends the full opener whose last line asks for the batch.
4. No structured views: prelude exposes only `train`, `test_inputs`, `check`, `submit` (L140-213); no segmentation/objects, no input-output diff helper (Tufa: segmentation + frame_diff), no image (MULTIMODAL_CONTEXT unset).
5. PREFER_TOOL_CALLS line, OPENER_COMMIT_HINT, BOARD_DUMP_GUARD (and its row test `isalnum()` would not match space-separated digit rows), STUB_DEAD_REASONING, summaries, effort ladder (comment L476-478 "Duck's effort ladder (unused here)") — all unused.
6. Kept from dfranzen: yield 2,048, temp 0.7 (rev 5 option 1.0), ctx 128k, drain 58k, turn cap 150/30/coalesce, tool output 3,072, middle truncation, memory sections off, persistent functions game scope + imports, priority gate, the no-tool nudge prefix (tail replaced, L413-418, L514-520), tool-call markup fallback.
7. Speed side (not in adapter but in plan memory): dfranzen's MTP 3-step + FR-Spec hot-vocab draft + fp8 KV + lpm + gate=MAXREQ; our stack is SGLang 0.5.21 INT4 + DFlash2 on 4xL4.

---------------------------------------------------------------------------------------------------
## Concrete techniques to copy into our ARC-2 Duck to cut tokens and act in code early

1. **Take the grids out of the prompt text.** Keep `train`/`test_inputs` in Python only and give shapes + a one-line structural summary (sizes, colour counts) in the prompt; optionally an image if the served Qwen3.8-27B build accepts images (unverified). Add Tufa's lines verbatim adapted: "The raw grids are intentionally not shown as text. Inspect them from Python instead of reasoning from the raw grid by eye." and "Never print or echo full grids. Return only compact derived summaries such as object lists, diffs, coordinates, counts, or tiny local crops." This is the single biggest structural difference from ARC-3 Duck (1,477 tokens/call there).
2. **Per-request output cap with continuation** (dfranzen 12,288) plus his verbatim CUT OFF follow-up ("Keep your reasoning much shorter this time and emit the `python` tool call early enough that it completes within the output limit. Prefer one small snippet over a long analysis."). Reasoning stays in history (preserve_thinking), so the branch's total thinking budget can stay >= 60k across several requests — the floor applies to the total, not one reply; still needs user approval because it changes the per-request cap.
3. **Commit pressure on every resumption**: after each yield (2,048 tokens) re-send a short opener whose last line is the ARC-2 analogue of dfranzen's closing line, e.g. "When ready, write `transform`, run `check(transform)`, and fix it from the reported cells; a checked candidate is kept automatically." Use the no-tool variant of `_YIELD_RESUME_PROMPT_NO_TOOLS` ("Stop deliberating and call the `python` tool NOW ... Acting on a partial model beats another turn of analysis.") when the turn made no tool call.
4. **PREFER_TOOL_CALLS line, verbatim with ARC-2 wording**: "Reading and computing cost nothing. When you are unsure, prefer another tool call over more reasoning: the code answers what the reasoning would only guess at, and running it is faster than thinking your way to the same answer." (dfranzen's own measured failure: 18,012 chars of reasoning, cap hit, nothing executed.)
5. **Structured helpers in the prelude** (Tufa segmentation + frame_diff, DF-WM check_sim): `objects(grid)` (4-connected components with colour, bbox, size, shape hash), `diff(a, b)` (changed cells grouped by colour transition), and keep `check()` as the "check_sim" analogue that returns wrong cells. One call replaces thousands of thinking tokens of cell counting.
6. **Board-dump guard adapted to ARC-2 rows** (dfranzen L2846-2891): collapse >=6 printed rows of digits/spaces and append "[BOARD PRINT GUARD] Printing full grids is disallowed and character counting is unreliable for you. Compute over the grid in python ... and print only coordinates, counts, and small crops."
7. **REPL last-expression print, middle truncation, action echo** are already inherited — keep tool output 3,072 with head/tail truncation so the check() verdict survives.
8. **zlib degenerate stub** (ratio < 0.01, >= 500 chars) for reasoning-only replies so repetition loops do not occupy context; consider `ARC3_STUB_DEAD_REASONING` only if traces show dead 30k replays (ARC-2 continuation value is higher than ARC-3's, so measure first).
9. **Speed**: gate active streams = server max running requests, handover only at trims, drain hysteresis (58k) + coalesce, always send tools (99% vs 15% shared prefix), summary thinking off with the `{%- if true %}` template trick if summaries are used; MTP/DFlash with a hot-vocab draft head (FR-Spec 64k) and fp8 KV; `--schedule-policy lpm`; prefetch weights while the server starts.
10. **Scheduling**: D' (pace-aware priority, fresh tasks priced by the same formula) was the only fork change with an LB gain (31.54 vs 27.6-27.9, n=1, run-to-run noise ~7 points); ARC-2 analogue = rank branches by expected value (tasks with a near-exact check first) instead of a fixed order.
