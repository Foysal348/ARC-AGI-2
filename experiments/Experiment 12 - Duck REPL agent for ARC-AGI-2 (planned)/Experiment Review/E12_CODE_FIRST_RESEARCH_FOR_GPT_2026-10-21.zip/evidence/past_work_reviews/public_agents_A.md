# Public agents A: khoinguyennguyen, madarshbb, russcore (read in full, 2026-10-21)

Sources (scratchpad/ext): khoinguyennguyen `arc-agi-2-agentic-multi-turn-reasoning` (3155 lines, no outputs); madarshbb `arc-qwen-3-8-27b-agent` (2080 lines; the lb_monitor and LB_compare copies are byte-identical; no outputs); russcore v343813612 `russcore_LB10.14` (751 lines, has a 1 h diagnostic output) and `latest_pulled` (2862 lines, no outputs). The aggregator embedded in both russcore versions has the same selection policy.

No file reports a hidden-LB score except the russcore filename (LB 10.14 = the direct, pass@1 version). None reports eval accuracy.

## 1. khoinguyennguyen: "Explorer of Mini Realities" (persistent Jupyter, 2 tools)
- **Serving:** vLLM, Qwen3.8-27B FP8, TP4, max_model_len 262144, fp8 KV, TRITON_ATTN (plus VLLM_FORCE_ATTN_BACKEND so the MTP drafter also uses Triton), MTP speculation with 3 tokens (the markdown says 6), max_num_seqs 16, prefix caching, qwen3_coder/qwen3 parsers, `--no-async-scheduling`, gpu util 0.96.
- **Template and sampling:** `chat_template_kwargs {"enable_thinking": True, "preserve_thinking": True}`. No reasoning_effort is set, so the template default applies (madarshbb notes the default is xhigh). Sampling is temp 0.9, top_p 0.95, **presence_penalty 1.5**, seed 42+branch (the same seed every turn).
- **Budgets:** max_output_tokens 65536 per request. Compression fires when the prompt reaches 0.80×(262144−65536−512) = 157,056 tokens; the summary gets 32,768 tokens at temp 0.5. per_task_timeout 4 h, request_timeout 3600 s, python_timeout 120 s, max_turns 256, solve stop at 41,400 s.
- **Concurrency:** task_parallel 8 × branches 2 = 16 = max_num_seqs.
- **Tools:**
  - `python` is a persistent Jupyter kernel with numpy, scipy.ndimage, sympy, `train_pairs`, `test_inputs` and the helpers `print_grid, color_counts, grid_diff, verify_all(fn, train_pairs)` (PASS/FAIL per pair plus the first differing cell), `find_pattern` (dihedral template match) and `color_lines`. Tool description: "Always use print() to see output. Default timeout 30s, max 120s." Output is truncated to 8192 chars (head and tail).
  - `cognitive_activity(activity, content, preserve_across_reincarnation)` is a lab notebook.
- **System prompt (key lines, verbatim):**
  - "Your task is not to recall a familiar pattern ... reconstruct the mini-reality's transformation law"
  - "1. Observe exactly. Print dimensions, color counts, changed cells, repeated structures."
  - "4. Experiment. Implement the candidate in Python and apply it to every training pair. Read the actual PASS/FAIL results, not the ones you expected."
  - "Before predicting, verify against the least convenient training pair, not the easiest one."
  - It also includes 12 "Cognitive Enhancement Principles" (e.g. "3. Non-Force Principle: when effort stops producing information, change the view or the experiment.").
  - Answer format: `SOLUTION: \boxed{[[row1], ...]}` (or SOLUTION_i for several tests).
- **User prompt:** compact digit rows with headers like `train[i].input (HxW):`, ending with "The same transformation law explains every training pair. Predict the output for each test input."
- **Only nudge (when the reply is empty):** "Continue your investigation. Use the python tool to explore the training pairs, and use cognitive_activity to record what you find."
- **Compression prompt (verbatim core):** "Your context window is nearly full. Write a handoff summary for the next instance of yourself. The Python kernel state ... WILL BE PRESERVED ... 1. Current hypothesis ... 2. Facts verified with code — exact values ... 3. Approaches tried and why each failed. 4. Best guess for each test output ... 5. Exact Python variable names ... 6. The single next step." The rebuilt conversation is: system, task, "[PRESERVED COGNITIVE ACTIVITIES FROM PREVIOUS LIFE]", then "[HANDOFF FROM PREVIOUS LIFE] ... do not redefine existing variables."
- **Answer selection:** a branch stops at its first complete SOLUTION. Branch 0 gives attempt_1 and branch 1 gives attempt_2. Train verification is not enforced.
- **Flaws found:**
  - The markdown promises a "verification round", but the code has none.
  - The assistant message is rebuilt from content and tool_calls only, so the reasoning is never re-sent. `preserve_thinking` therefore has no effect.
- Token counting uses vLLM `/v1/chat/completions/render`.
- No measurements are reported.

## 2. madarshbb: "ARC agent sub q38 direct"
- **The submitted config is DIRECT mode, not the REPL:**
  - `mode "direct"`, samples 2, concurrency 10, max_model_len 81920, max_num_seqs 16, `template_kwargs {"reasoning_effort":"xhigh"}`.
  - temp 1.0, top_p 0.95, top_k 20, **thinking_token_budget 40960** (forces `</think>`; needs `--reasoning-config {"reasoning_start_str":"<think>","reasoning_end_str":"</think>"}`), max_tokens 49152, rescue_tokens 8192, min_start_s 600, deadline = start + 12 h − 35 min.
  - Server ladder: first rung is fp8 KV + `--language-model-only` + `qwen3_5_mtp` speculation with 2 tokens. Also `--generation-config vllm`, gpu util 0.90, and the overlay wheels `taaf-duck-qwen38-serving-v1`.
  - Order: cheapest prompts first (by JSON length), sample-major. attempt_1 is the first answer; attempt_2 is the next *different* one.
- **Direct prompts (verbatim):**
  - System: "You are an expert at solving ARC-AGI puzzles. Each puzzle has a few input->output example pairs that share one hidden transformation rule. Grids are 2D arrays of digits 0-9 (colours); 0 is usually the background."
  - Instructions: "Solve this ARC puzzle. ... Work out the rule, check it against every example, then apply it to the test input(s). At the very end of your answer, give each test output grid as rows of digits inside its own ```grid code block..."
  - RESCUE (thinking off, effort low, last 16,000 chars of notes): "## Your notes so far (they were cut off) {notes} Stop analysing now. Apply the rule you were converging on and give the final test output grid(s)..."
  - Grids are shown as digit rows with no separators plus explicit "(RxC)", because "reasoning models miscount rows and columns of long digit strings otherwise."
- **REPL agent (in the notebook, modelled on Tufa's Duck; not the submitted mode):**
  - **Tools:**
    - `python(code)`: a fresh subprocess per call, numpy arrays preloaded. Preamble: "Preloaded in every `python` call ...: `np`, `train_inputs`, `train_outputs`, `test_inputs` ..., helpers `show(g)`, `diff(a, b)`, `objects(g, bg=None, diagonal=False, multicolor=False)` ... Print compact summaries, never whole large grids." Timeout 30 s; output capped at 4000 chars.
    - `submit(code)`: "It is run on every example input; you are told which examples it reproduces. When it reproduces all of them it is accepted and you are done." Feedback shows up to 2 failed examples, each as the Expected grid plus "Your output, with CORRECT cells shown as '.'" (up to 900 cells) and "N of M cells are wrong."
  - **REPL_INSTRUCTIONS (verbatim):** "Work like a scientist: use the `python` tool to measure the examples (objects, colours, sizes, positions, differences between input and output), form a hypothesis, and test it in code. Then call `submit` ... Submit EARLY and often: submitting is free, and a failing submission tells you exactly which examples and which cells are wrong -- that is the fastest way to find the rule. Do not wait for certainty."
  - **IN_PYTHON_RULE (verbatim, its own arm):** "Never read, count, index or transcribe grid cells in your head. Do ALL of that with the `python` tool -- the grids are already loaded as numpy arrays. Keep your own reasoning to hypotheses and plans; let code do the looking."
  - **NUDGE every 6 python calls:** "[harness] You have run {n} python calls without submitting. Submitting is free and returns a cell-level diff against every example. Submit your current best transform now, then refine it from the diff."
  - **THINKCAP_HINT, sent when a turn is cut at the per-turn cap:** "[harness] You hit the per-turn thinking limit. Stop analysing. In your next reply, call `python` to test your current best hypothesis in code, or `submit` a transform implementing it -- a failing submit shows exactly which cells are wrong."
  - TIMEOUT_HINT: "Your previous reply took too long and was abandoned. Keep your reasoning short: call `python` ... or `submit`."
  - Other hints: when no tool is called, "Use the `python` tool to explore, or `submit` your transform program."; on a cut without the cap arm, "Your reply was cut off. Be more concise."
  - **Options:**
    - `force_submit_after` sets `tool_choice={"function":"submit"}` (guided decoding).
    - `effort_ladder` steps down medium/low after a cut and restores the original effort after progress.
    - `retain_functions` replays top-level defs as source into later calls and submits.
    - `keep_reasoning` and `trim` keep the system prompt and task, then drop the oldest groups. The char/3 estimate is checked against context_budget 24–28k; `keep_recent=6`.
    - Hysteresis trim (`trim_drain`) keeps a byte-identical prefix so the prefix cache keeps hitting.
    - The degenerate guard flags a reply when its zlib ratio is below 0.01.
    - An answer given as a bare code block is treated as an implicit submit.
  - **Budgets:** max_turns 40; per-attempt token cap = clamp(tok_per_s × time_left / n_tasks × 1.3, 15k, 60k). Visible replies have the reasoning stripped (`visible_reply`, last 6000 chars).
  - **Aggregation:** verified programs vote first; the rest are ranked by best train n_ok, then by vote count.
- **Measured findings in the code comments (verbatim):**
  - "probe24: every failed attempt spent 30-73k tokens exploring and never submitted once, so it never saw a diff."
  - "probe9q38: every failed attempt had 1-3 turns cut at 16k tokens mid-thought, while solves used 2-3k tokens a turn."
  - "probe9q38 transcripts: failures parse and count grids IN THE REASONING, cell by cell, often filling a whole 16k-token turn before any tool call ("col 7=8, 8=0, 9=0 ...")."
  - "mini2arm: the text nudge was read and ignored." This is the reason for force-submit.
  - "30-38% of all function code the model wrote re-defined a function it had already written, and 19 of 20 ab3q36 submits re-typed functions first written in a python call."
  - "Qwen3.8 otherwise spends whole 16k turns thinking."
  - "exp06: the NLL scorer prefers a wrong grid over the injected truth for 83 % of missed outputs."
  - "reasoning-only reply of 6,144 '!' under speculative decoding."

## 3. russcore v343813612
- **LB10.14 (pure direct, pass@1):**
  - temp 0.6, top_p 0.95, top_k 20, max_tokens 57,344, enable_thinking True. reasoning_effort is **not** sent ("vLLM rejects"), so the template default applies.
  - Context 65,536; max-num-seqs = concurrency = 24; one sample per query; attempt_2 = the mirror floor.
  - Prompt (verbatim): "You are solving an abstract reasoning puzzle ... Infer the ONE rule that maps every input to its output, then apply it to the FINAL INPUT. ... Reason step by step however you like. Then give ONLY the final output grid as rows of space-separated digits inside a fenced block: ```grid```". Grids are space-separated; each test query is solved separately.
  - recover_grid (thinking off, 4096 tokens, last 8000 chars of reasoning): "You hit the token limit mid-reasoning. Do NOT reason further. Based on the reasoning above, output ONLY your best-guess final grid now..."
  - Admission: a 40-min prior until 8 samples have finished, then 1.1×p90 + 60 s, clamped to 10–60 min.
  - **Measured (1 h diagnostic, 8 eval tasks / 11 queries):** 4 samples finished. Mean **36,257** completion tokens (max 42,590); mean wall **2279 s** (max 2680). Decode averaged 119.5 tok/s (peak 166.5) with only ~7.5 requests running. KV peak 44%. Projection: 20.2 h for 240 tasks.
  - Comments: the "v7 probe C=24 ~255 tok/s sustained, 97.2% KV, zero preemption, ~27K-token xhigh samples"; the "v8 ... 6/11 samples hit the cap [49,152] with no grid".
- **Latest (v11 agentic):**
  - vLLM 0.19.0, context 65,536, C=24, 2 samples per query, max_turns 10, Python-tool concurrency 4.
  - Pass policies: xhigh = turn_max_tokens 40,960, episode cap 3600 s; medium = 20,480 tokens, 1800 s.
  - Budget contract: 259 queries / 24 = 11 waves × 60 min = 11.0 h. The episode cap shrinks if needed to keep universal coverage. The medium + Python attempt_2 runs only after all xhigh work is done, ordered by risk (missing grid > abnormal finish/tool error > tokens > wall).
  - **Agent prompt (verbatim):** "You have a Python tool `run_python`. The task is preloaded there as `train` ... and `test_input` ... Use it however you find helpful -- to inspect grids, test a transformation against every example, or compute the answer -- or just reason directly. It is entirely your choice." The tool is optional and nothing pushes the model to use it.
  - Tool: a fresh process per call (no state), 20 s wall, 12 CPU-s, 4 GiB, 8000-char output. Reasoning is replayed in the assistant `reasoning` field.
  - Forced final turn (last turn, or less than 8 min left): "Final answer turn: do not call tools or do more analysis. Using your work above, output only your best final grid in a ```grid fenced block." It runs with thinking off, effort low, tool_choice none, cap 4096.
  - A grid emitted alongside a tool call is kept as best_grid. A live preflight checks the full tool cycle.
  - Claim, with no numbers: "hypothesize->execute->verify->answer ... solved tasks xhigh-alone missed."

## Techniques to copy into our ARC-2 Duck
1. **Put IN_PYTHON_RULE verbatim in the system/user prompt**, alongside "Print compact summaries, never whole large grids." It targets the hand-reading that delays our first check() to about 55k tokens.
2. **Push early-check wording:** "Submit EARLY and often ... Do not wait for certainty." Our check() plays the role of their submit.
3. **Turn text nudges into hard pushes.** Their text nudge was ignored, so after K python calls (or N tokens) without a check(), force the next turn with `tool_choice={"type":"function","function":{"name":"check"}}`.
4. **Add a per-turn thinking cap with THINKCAP_HINT on a cut** ("Stop analysing ... call `python` ... or `submit`"). Their solves used 2–3k tokens a turn, while failures had 16k cut turns. **This is a per-turn limit, not a cut to the total budget, but it touches our 60k thinking floor rule and needs user approval before use.**
5. **Preload numpy arrays plus `objects()/diff()/show()` helpers and state them in the tool description.** Use the '.'-masked expected/got diff format for check() feedback, with at most 2 failing examples and the wrong-cell count.
6. **Retain functions:** replay top-level defs as source into later calls and into check(). This removes the 30–38% re-typed code and the cost of re-sending it.
7. **Control the context:** strip reasoning from replayed turns (`visible_reply`) or keep it deliberately. Trim with hysteresis so prefix-cache hits survive.
8. **Add a degenerate-loop guard (zlib < 0.01).** MTP can produce runs like '!'×6144.
9. **Recover from cuts:** use a forced final turn or a thinking-off rescue from the reasoning tail (last 8–16k chars) so a truncated branch still emits a grid.
10. **Schedule coverage-first:** cheapest prompts first, p90 predictive admission, and medium-effort second passes only after full coverage, ordered by risk.
11. **Select answers by vote:** train-verified programs vote first, then rank by train cells/pairs passed. attempt_2 is the next *distinct* grid.
