# Verbatim prompt and harness excerpts (copied from the source files, 2026-10-21)

Line numbers refer to the source files named in each heading.

## 1. Tufa Duck ARC-AGI-3 base system prompt (our P1_SPARSE evidence: `sparse_p1_system_prompt_base.txt`, lines 20-30, 60-80, 88-93)
```
- `current_frame.step` is the current environment step count.
- `current_frame.level` is the current level number.
- `current_frame.shape` is a `(rows, cols)` tuple.
- The raw numeric grid is intentionally not exposed. Use `current_frame.segmentation` as your primary view of the board -- objects, colors, shapes, containment, adjacency, and cross-frame object hashes. Use `current_frame.ascii` only to read a small, specific region; do not scan the whole board with it.
- `history` is a chronological list of action/frame snapshots.
- `history` is a Python list of objects, not a dict.
- Each history entry exposes only `.action` and `.frame`; entries are not subscriptable like `entry['action']`.
- Each `history[i].frame` is the frame after `history[i].action`; each frame exposes only `.ascii`, `.step`, `.level`, `.shape`, and `.segmentation`.
- Important history semantics: when `history` is non-empty, `history[-1].frame` is the same latest/post-action board as `current_frame`. It is not the previous board. To inspect the state before the latest action, use `previous_frame` or `history[-2].frame` when available.
- `previous_frame` is the frame before the most recent real environment action, or `None` if no previous frame is available.
- `last_action` is the most recent real environment action name/display, or `None` before any real action.

Python tool guidance:
- Use `current_frame.segmentation` as your primary view of the board -- objects, colors, containment, adjacency, and cross-frame object hashes.
- Use `current_frame.ascii` only to read a small, specific region of the board when `segmentation` is not enough; never use it to scan or summarize the whole board.
- Every `python` tool call starts fresh. Re-import modules or re-define any custom utility logic you need.
- The only importable standard-library modules are: bisect, collections, copy, fractions, functools, heapq, itertools, json, math, operator, random, re, statistics, string.
- The only tool is `python`; call it with one ephemeral `code` string.
- Always inspect `current_frame`, `history`, and `valid_actions` from Python instead of reasoning from the raw board by eye.
- For the most recent change, compare `previous_frame` to `current_frame`, or `last_transition.before_frame` to `last_transition.after_frame`. `history[-1].frame` is the current frame, so comparing it to `current_frame` only compares the board to itself.
- Maintain a compact working world model: what entities or regions exist, what actions seem to do, what the goal likely is, what remains uncertain, and what plan best fits the evidence so far.
- IMPORTANT: Especially when the game is about making an agent navigate to a target, it is usually safer to write an explicit search algorithm such as BFS. More generally, when the objective is understood but the best action order is unclear, pathfinding, flood fill, BFS, DFS, beam search, shortest-path search, limited action-sequence search, or custom heuristics are all valid.
- Optimize for the shortest reliable sequence that advances the current goal as described by your world model. If confidence is low, program a discriminating probe and revise the world model from the result.
- Once the important state variables and action effects are sufficiently understood, stop probing and search in the inferred state space.
- Inspect current and history frames from Python instead of describing frames freehand.
- Never print or echo full board frames. Return only compact derived summaries such as object lists, diffs, coordinates, counts, or tiny local crops.
- Keep tool-output context size minimal and decision-oriented so you can quickly compare before/after state. It's fine to write a lot of python code, just make the output short and interpretable
- A strong default loop is: summarize the board, infer the desired environment change, write a small scorer or search over candidate sequences, execute the best probe or plan with `action(...)`, then inspect again until you understand exactly what changed.
- For object tracking, match objects by color, overlap, bounding box proximity, area change, and edge contact rather than by exact coordinates alone.
- For frame diffs, summarize changed cells, color transitions, appearing/disappearing components, movement candidates, and small local row slices around the changed region.
- After every action, verify whether gameplay objects changed or whether only a timer, progress bar, or remaining-step bar moved. Do not treat HUD-only changes as evidence that the move worked.
- Use `print(...)` for compact summaries, or assign a final compact object to `result`.
- You have exactly one tool: `python`.
- When calling `python`, emit exactly the tool-call format shown elsewhere in this prompt for this model. Use only that format; do not add markdown fences, prose wrappers, or alternate tool-call syntax. Do not quote or place tool-call markup inside explanatory text; when you decide to call the tool, emit the tool call itself.
- The `python` tool code is not saved between calls, so rewrite any custom utility logic you still need.
- You can call the `python` tool as many times as you want per step. Investigate until your code has a clear probe or plan.
- Do not ration tool calls when the state is unclear. Spend extra tool calls to confirm what changed between frames and whether the last action affected gameplay state or only HUD elements such as countdown bars.
- After `action(...)` returns, the structured runtime state is refreshed before the next Python statement and before the next tool call. Inspection-only Python calls do not clear `last_action_result`.
```

## 2. dfranzen ARC-AGI-3 Milestone 2 patch (Kaggle `dfranzen/arc-agi-3-milestone-2-solution`, text extraction)

### PREFER_TOOL_CALLS_LINE, lines 687-700 (defined, OFF in his submitted config)
```
+PREFER_TOOL_CALLS_LINE = (
+    # The closing clause used to warn that a long chain "wastes the whole turn".
+    # That overstated it - a truncated reply keeps its reasoning in history, and
+    # what is lost is only that nothing executed - and it aimed at the tail,
+    # since truncation touched about 4% of replies. The speed claim is the
+    # stronger one and it is true: decode runs at tens of tokens per second per
+    # stream, while a tool call is a short generation plus a mostly-cached
+    # prefill, so 2,000 tokens of further reasoning costs far more wall-clock
+    # than running the code that would settle the question.
+    "- Reading and computing cost nothing; only `action(...)` spends the level budget. When you "
+    "are unsure, prefer another tool call over more reasoning: the code answers what the "
+    "reasoning would only guess at, and running it is faster than thinking your way to the "
+    "same answer.\n"
+)
```

### Why it exists, lines 3147-3156
```
+def _prefer_tool_calls() -> bool:
+    """State the cost asymmetry: tool calls are free, actions are not.
+
+    The prompt already says not to ration tool calls, but only ever compares
+    them with other tool calls - never with reasoning, which is the trade the
+    model actually makes when it writes twelve thousand characters of
+    hypothesis before its first snippet. Observed: a turn spent 18,012
+    characters reasoning, hit the output cap, and executed nothing.
+    """
+    return _get_env_bool("ARC3_PREFER_TOOL_CALLS", False)
```

### Yield resume when a turn made no tool call, lines 1977-1983 (used only with ARC3_YIELD_RESUME_PROMPT=short|state_only; his config uses the default "full" mode, which re-sends the whole opener)
```
+_YIELD_RESUME_PROMPT_NO_TOOLS = (
+    "You spent the entire turn budget reasoning without calling a tool. Stop "
+    "deliberating and call the `python` tool NOW: inspect "
+    "`current_frame.segmentation`, then call `action(actions)` with the best "
+    "available action. Acting on a partial model beats another turn of "
+    "analysis."
+)
```

### Cut-off tool call follow-up, lines 7485-7494 (ON)
```
+                    if truncated_tool_call:
+                        # the only signal the model gets that LENGTH, not
+                        # formatting, is why its call vanished
+                        followup_prefix = (
+                            "Your previous reply was CUT OFF before the tool call finished, so the "
+                            "call was incomplete and could not be executed. Keep your reasoning "
+                            "much shorter this time and emit the `python` tool call early enough "
+                            "that it completes within the output limit. Prefer one small snippet "
+                            "over a long analysis. "
+                        )
```

### Board print guard, lines 2884-2891 (OFF)
```
+    if suppressed:
+        out.append(
+            "[BOARD PRINT GUARD] Printing full boards is disallowed and "
+            "character counting is unreliable for you. Compute over the grid "
+            "in python (segmentation nodes, slicing, run-length checks, BFS) "
+            "and print only coordinates, counts, and small crops."
+        )
+    return "\n".join(out), suppressed
```

### Submitted analyzer settings, lines 10188-10211
```
    ########## analyzer config ##########
    'ARC3_REASONING_HISTORY_KEY': 'reasoning_content',
    'LOCAL_ANALYZER_ENABLE_THINKING': 'true',
    'LOCAL_ANALYZER_TOOL_STEPS': '0',
    'LOCAL_ANALYZER_TOOL_TIMEOUT': '30',
    'LOCAL_ANALYZER_YIELD_SECONDS': '0',
    'LOCAL_ANALYZER_YIELD_TOKENS': '2048',
    'LOCAL_ANALYZER_TEMPERATURE': '0.7',
    'LOCAL_ANALYZER_TOP_P': '0.95',
    'LOCAL_ANALYZER_TOP_K': '20',

    ########## context pruning ##########
    'LOCAL_ANALYZER_CONTEXT_WINDOW': (116+12)*1024,
    'LOCAL_ANALYZER_MAX_OUTPUT': 12*1024,
    'ARC3_CONTEXT_DRAIN_TOKENS': 58*1024,
    'ARC3_HISTORY_ASSISTANT_TURNS': 150,
    'ARC3_HISTORY_TURN_DRAIN': 30,
    'ARC3_HISTORY_DRAIN_COALESCE': '1',

    ########## tool output ##########
    'LOCAL_ANALYZER_TOOL_OUTPUT_TOKENS': '3072',
    'ARC3_MIDDLE_TRUNCATION': '1',
    'ARC3_ACTION_ECHO': '1',
    
```

## 3. madarshbb public notebook `arc-qwen-3-8-27b-agent` (REPL agent built, but the published config runs mode "direct"), lines 1103-1137
```
REPL_INSTRUCTIONS = """Solve this ARC puzzle. The examples below share one hidden transformation rule.

Work like a scientist: use the `python` tool to measure the examples (objects, colours, sizes, positions, differences between input and output), form a hypothesis, and test it in code. Then call `submit` with the full source defining `transform(grid)`. Use only the standard library and numpy.

Submit EARLY and often: submitting is free, and a failing submission tells you exactly which examples and which cells are wrong -- that is the fastest way to find the rule. Do not wait for certainty. If a submission fails, study the diff and fix the rule rather than special-casing examples."""

# probe24: every failed attempt spent 30-73k tokens exploring and never submitted
# once, so it never saw a diff. After this many python calls without a submit,
# the tool output carries a reminder.
NUDGE_EVERY = 6
NUDGE = ("\n\n[harness] You have run {n} python calls without submitting. Submitting is free "
         "and returns a cell-level diff against every example. Submit your current best "
         "transform now, then refine it from the diff.")

# probe9q38: every failed attempt had 1-3 turns cut at 16k tokens mid-thought, while
# solves used 2-3k tokens a turn. The thinking-cap treatment lowers the per-turn cap
# and, when a turn is cut, orders the model to act instead of resuming the analysis.
THINKCAP_HINT = ("[harness] You hit the per-turn thinking limit. Stop analysing. In your next "
                 "reply, call `python` to test your current best hypothesis in code, or "
                 "`submit` a transform implementing it -- a failing submit shows exactly "
                 "which cells are wrong.")


# The probe24 wording, kept verbatim so a run with the nudge off matches it exactly.
REPL_INSTRUCTIONS_V1 = """Solve this ARC puzzle. The examples below share one hidden transformation rule.

Work like a scientist: use the `python` tool to measure the examples (objects, colours, sizes, positions, differences between input and output), form a hypothesis, and test it in code. When you have a program that you believe reproduces EVERY example, call `submit` with the full source defining `transform(grid)`. Use only the standard library and numpy. If a submission fails, study the diff and fix the rule rather than special-casing examples."""


# probe9q38 transcripts: failures parse and count grids IN THE REASONING, cell by cell,
# often filling a whole 16k-token turn before any tool call ("col 7=8, 8=0, 9=0 ...").
# Tufa's harness says the same thing to its model. Optional, its own arm.
IN_PYTHON_RULE = """

Never read, count, index or transcribe grid cells in your head. Do ALL of that with the `python` tool -- the grids are already loaded as numpy arrays. Keep your own reasoning to hypotheses and plans; let code do the looking."""
```

## 4. Our own archived V3.1 ALLFIX prompt + helper (2026-10-03/04; ran only at LOW effort with </think> forced at 2,048 tokens; 12 tasks: 12/12 first turns called the tool after a median 664 thinking tokens; solves unchanged 1/12)

Source: `archive/.../V3 EVAL120 Baseline and S12 Subset/` review bundle, `PIV-Q27-V3_1-EVAL120-ALLFIX.ipynb` (JSON lines 1421-1446 and 2039-2057)
```
V3_HELPERS_BULLET = (\n",
    "- Exploration-only helpers (use them in the notebook; NEVER call them inside `solution`, they read `puzzle`): "\n",
    "`arc_overview()` prints per-pair shapes, colors, changed-cell counts and component counts without printing grids; "\n",
    "`verify_solution(fn=None)` runs `fn` (default `solution`) on every training pair and prints PASS / DIMS / wrong cells.\\n"\n",
    "- Grid helpers that are also available inside your final `solution` (do not redefine them): "\n",
    "`components(grid, color=None, diag=False, background=None)` returns connected same-colour components as dicts "\n",
    "with keys color, cells, bbox=(r0, c0, r1, c1), size; `bbox(grid, ignore=None)`; `crop(grid, r0, c0, r1, c1)`; "\n",
    "`rot90(grid)` (clockwise), `flip_h(grid)`, `flip_v(grid)`, `transpose(grid)`; `color_counts(grid)`; "\n",
    "`background_color(grid)` (the most common colour: a heuristic, pass `background=` explicitly when unsure); "\n",
    "`grid_shape(grid)`; `diff_cells(a, b)` -> list of (r, c, a_value, b_value)."\n",
)\n",
V3_WORKFLOW = (\n",
    "# Workflow (STRICT)\\n\\n"\n",
    "- Never transcribe, restate or enumerate grid rows or cell values in your reasoning. The grids are already in "\n",
    "`puzzle`; inspect them with Python instead.\\n"\n",
    "- Keep your thinking short. Your first Python execution should call `arc_overview()`.\\n"\n",
    "- By your second Python execution at the latest, define a complete `solution(grid)` for your current best "\n",
    "hypothesis. Every time a Python execution defines or changes `solution` (or a helper it uses), the environment "\n",
    "automatically runs it on all training examples in a fresh process and appends the result to the tool output.\\n"\n",
    "- Use that feedback to revise `solution` until every training example passes and it also runs cleanly on the "\n",
    "test input(s). When both hold, the task is submitted automatically.\\n"\n",
    "- Define `solution` with `def`. Everything it depends on must be a top-level import, a function or class "\n",
    "definition, or a constant; it must never depend on `puzzle` or on variables computed from `puzzle`.\\n"\n",
    "- Do not put reasoning into code comments."\n",
)\n",
\n",
def arc_overview():\n",
    # Compact per-pair structure of the preloaded puzzle, without transcribing any grid.\n",
    lines = []\n",
    for i, ex in enumerate(puzzle["train"]):\n",
        a, b = ex["input"], ex["output"]\n",
        sa, sb = grid_shape(a), grid_shape(b)\n",
        line = "train %d: in %dx%d -> out %dx%d" % (i, sa[0], sa[1], sb[0], sb[1])\n",
        line += " | in colors %s | out colors %s" % (dict(sorted(color_counts(a).items())), dict(sorted(color_counts(b).items())))\n",
        if sa == sb:\n",
            d = diff_cells(a, b)\n",
            line += " | changed cells %d/%d" % (len(d), sa[0] * sa[1])\n",
            if d:\n",
                line += " | top in->out changes %s" % (_PIV_Counter((x[2], x[3]) for x in d).most_common(4),)\n",
        line += " | components in %d out %d" % (len(components(a)), len(components(b)))\n",
        lines.append(line)\n",
    for j, t in enumerate(puzzle["test"]):\n",
        s = grid_shape(t["input"])\n",
        lines.append("test %d: in %dx%d | colors %s" % (j, s[0], s[1], dict(sorted(color_counts(t["input"]).items()))))\n",
    print("\\n".join(lines))\n",
```
