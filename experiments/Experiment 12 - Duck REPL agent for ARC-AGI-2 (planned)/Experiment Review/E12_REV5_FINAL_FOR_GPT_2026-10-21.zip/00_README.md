# E12 rev 5 (final): the three audit fixes applied and re-validated (2026-10-21)

## Ask

Final check before the GPU run.

1. Confirm the five fixes below are correct and complete.
2. Confirm nothing else changed.

Report blockers only (file:line), certain vs possible. No new features or plans: the user chose one bundled run.

## Background

- **Rev 5 contents:** B1-B8 + temperature 1.0 (see `docs/E12 next fix list (running, 2026-10-20).md`).
- **First audit:** three GPT audits of the first rev 5 zip (EVAL6R5 sha `e1887ac1…`):
  - **GPT 1:** GO.
  - **GPT 2:** NO-GO (serializer spoof).
  - **GPT 3:** NO-GO (B6 markup bypass).
- **Validation:** every claim was checked. Both blockers were **reproduced** on that code before fixing.
- **Decision:** the user approved R5-1..R5-5; R5-6 is not taken.

## The five fixes (`diffs/arc2_duck_rev5_audited_to_final.diff`, adapter only; vendor unchanged)

| # | Problem (reproduced) | Fix | Test |
|---|---|---|---|
| R5-1 | A wrong function that reassigns `json.dumps` forged the sandbox's result payload. It was host-accepted via `CHECKED:` **and** via `submit()` | `_grid_call_code(name, grid, guard=rev5)`: keep the original `json.dumps`, restore it in `finally`, raise if it was reassigned. Only the verification code changes | `tests/validators/validate_spoof_r5.py`: forged CHECKED False, spoof submit False, correct json-user kept True, identity False. Unit: the same + control (rev 5 off unchanged) |
| R5-2 | On `finish_reason=length` with no parsed `tool_calls`, Duck recovered a call from `<tool_call>` markup in content / reasoning (tool_agent.py:6842-6849) and ran it | In `_chat_completion`: if `length`, no parsed calls and markup present, insert one placeholder call with `arguments=""`. Duck's malformed path drops it and recovery is skipped | `tests/validators/validate_b6_markup.py`: content / reasoning / parsed → DROPPED; stop + markup → still EXECUTES. Unit: + incomplete markup never executes, plain reasoning = no call |
| R5-3 | `_force_reduce_messages` (Duck's last resort after a server rejection) skipped the truthful-resume rewrite | Override → the same `_arc2_rewrite_resume` | unit |
| R5-4 | A missing tokenizer fell back silently to 1.9 chars/token | `tokenizer_status()` → `CONFIG["e12"]["rev5_tokenizer"]` + print in CELL 3 (R5 builds). **Never fatal:** the fallback still works | unit: present → loaded; missing (subprocess) → not loaded + reason. Harness: recorded and loaded |
| R5-5 | B3 could not be checked on GPU | `rev5_events["prompt_estimates"]`: [our estimate, server `prompt_tokens`] per request (≤ 400 per branch) | unit + harness (every branch) |

**Not taken:** R5-6, a prompt sentence on distinct function names. The edge (same-name redefinition after `check()` in one call) occurred in 0 of 405 recorded calls.

**Builder change:** CELL 3 records the tokenizer status, plus a comment correction.

## Notebooks (`notebook/`)

| File | sha256 |
|---|---|
| `Q27-XHIGH-E12_DUCK_REPL_SGLANG_EVAL6R5.ipynb` | `f4fed1ac5ee332ad3a69eda841a8d7679d39b9a96f68e0b6777e2a6eb87d32a1` |
| `Q27-XHIGH-E12_DUCK_REPL_SGLANG_EVAL30R5.ipynb` | `415a68f27ed9108024206d03cf4124ae3952aa1e8acee04ad88a6490ce7facd9` |

## Re-validation (all re-run after the fixes)

**Unit checks** (`tests/unit/`, real Duck sandbox):
- **rev 5: 53/53** (40 before + 13 new);
- **rev 5 off: 41/41.**

**Notebook harness** (`tests/harness/`, real cells + fake SGLang):

| Notebook / scenario | Result | What it covers |
|---|---|---|
| EVAL6R5 / `r5` | **32/32** | +2 new: tokenizer status in the report, estimate metric on every branch |
| EVAL6R5 / `rerun` | **21/21** | hidden mode |
| EVAL6R5 / `launchfail` | **6/6** | |
| rebuilt rev 4 EVAL6 / `eval6` | **25/25** | regression |
| SMOKE1_REV4 / `smoke` | **22/22** | regression |

**End-to-end replay** (`tests/replay/replay_rev5.py`: recorded tool calls of both branches through the real rev 5 agent, then `build_submission`):
- EVAL6 **5/6 tasks, 7/8 inputs** (recorded run 3/6, 4/8);
- EVAL30 4 tasks, 7/48 (unchanged).

This replays recorded code; it is not a prediction of the GPU run.

**Integrity:**
- pyflakes clean;
- the embedded `arc2_duck.py` is byte-identical to `duck_arc2/arc2_duck.py` in both notebooks;
- 0 of the vendor files differ from the Kaggle-run rev 4 notebook (23 files in the package);
- the Kaggle-run originals are untouched (EVAL6 `53a66856…`, SMOKE1 `0fea4d0c…`, EVAL30 `b65fb9dc…`).

**Check-only on the run account (hosen42):**
- account, 3 models and 2 datasets: OK;
- both shas: OK;
- quota: 30.79 of 60 h used.

## Pre-run capacity check (unchanged from the first audit)

- **EVAL6R5:**
  - 12 branches, 6 live / 6 streams;
  - KV 6 x 131,072 = 786k ≤ 866,744;
  - tokens ≤ ~1.8M vs ~1.99M in 90 min;
  - 125 min budget → about 4.2 h of quota.
- **EVAL30R5:**
  - 60 branches;
  - 330 min solving, 6 h budget → about 12 h of quota;
  - late tasks may get less exposure (report it).
- **Verification cost:** measured on recorded candidates at 0.75-2.71 s each, ≤ 3 per branch (`tests/validators/time_verify.py`).

## Files

| Path | What |
|---|---|
| `duck_arc2/arc2_duck.py`, `duck_arc2/vendor_inference_agent/` | Final adapter; vendored Duck (unchanged) |
| `previous/` | rev 4 adapter, builder and Kaggle-run notebook; the first-audit rev 5 adapter and notebook |
| `diffs/` | rev 4 → final (adapter, builder); first-audit rev 5 → final (adapter) |
| `build/` | Builder, push script |
| `tests/` | unit, harness, replay, validators + logs |
| `docs/` | Fix list with every validation table (three weakness reports, three rev 5 audits), weakness analysis, EVAL6 run analysis |
