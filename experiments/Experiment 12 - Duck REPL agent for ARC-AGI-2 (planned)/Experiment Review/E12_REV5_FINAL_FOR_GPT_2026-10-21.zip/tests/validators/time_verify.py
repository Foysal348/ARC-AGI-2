"""Time the rev 5 host verification (_verify_submission) of every exact check() in the recorded branches (real sandbox)."""
import json, os, re, sys, tempfile, time
from pathlib import Path
os.environ["E12_ARC2_REV5"] = "1"
sys.argv, ARGS = sys.argv[:1], sys.argv[1:]
exec(open(Path(__file__).with_name("smoke_adapter.py"), encoding="utf-8").read().split("flip = lambda g")[0])
tx_path, task_id, ch = ARGS
task = json.load(open(ch))[task_id]
codes = re.findall(r"\[TOOL CALL: python\]\n<tool_call>\n<function=python>\n<parameter=code>\n(.*?)\n</parameter>",
                   Path(tx_path).read_text(encoding="utf-8", errors="replace"), re.S)
tmp = Path(tempfile.mkdtemp(prefix="tv_", dir=str(Path(__file__).with_name("runs"))))
state = tmp / TA.RUNTIME_STATE_FILENAME
write_runtime_state(state, current_frame=None, history=[])
ag = Agent(task=task, task_id=task_id, branch=0, model="qwen", base_url="http://127.0.0.1:9/v1", provider="vllm")
orig = ag._verify_submission
times = []
def timed(name):
    t = time.perf_counter(); v = orig(name); times.append(round(time.perf_counter() - t, 2)); return v
ag._verify_submission = timed
for code in codes:
    if ag.arc2_accepted is not None:
        break
    ag._run_python_tool(state, {"code": code})
print(json.dumps({"task": task_id, "verifications": len(times), "sec": times, "grids": len(task["train"]) + len(task["test"])}))
