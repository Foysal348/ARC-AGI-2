"""End-to-end replay of rev 5 B1+B2 in the REAL sandbox: every recorded tool call of both branches of a task goes
through the rev 5 agent (the check() hook signals, the host verifies and keeps candidates by itself); then
build_submission (select_attempts_r5) picks two attempts per test input; scored with the truth (analysis only).
Usage: python replay_rev5.py <run duck dir> <task_id> <challenges.json> <solutions.json>"""
import json, os, re, sys, tempfile
from pathlib import Path
os.environ["E12_ARC2_REV5"] = "1"
sys.argv, ARGS = sys.argv[:1], sys.argv[1:]
exec(open(Path(__file__).with_name("smoke_adapter.py"), encoding="utf-8").read().split("flip = lambda g")[0])
duck_dir, task_id, ch, so = ARGS
task = json.load(open(ch))[task_id]; truth = json.load(open(so))[task_id]
recs = []
for b in (0, 1):
    tx_path = Path(duck_dir) / f"{task_id}_b{b}" / "transcript.txt"
    if not tx_path.exists() or not tx_path.stat().st_size:
        continue
    tx = tx_path.read_text(encoding="utf-8", errors="replace")
    codes = re.findall(r"\[TOOL CALL: python\]\n<tool_call>\n<function=python>\n<parameter=code>\n(.*?)\n</parameter>", tx, re.S)
    tmp = Path(tempfile.mkdtemp(prefix="r5_", dir=str(Path(__file__).with_name("runs"))))
    state = tmp / TA.RUNTIME_STATE_FILENAME
    write_runtime_state(state, current_frame=None, history=[])
    ag = Agent(task=task, task_id=task_id, branch=b, model="qwen", base_url="http://127.0.0.1:9/v1", provider="vllm")
    for code in codes:
        if ag.arc2_accepted is not None:      # the real branch ends at an accepted submit
            break
        ag._run_python_tool(state, {"code": code})
    recs.append({"branch": b, "submissions": ag.arc2_submissions, "checked": ag.arc2_checked})
sub = A.build_submission({task_id: task}, {task_id: recs})[task_id]
hits = [att["attempt_1"] == g or att["attempt_2"] == g for att, g in zip(sub, truth)]
print(json.dumps({"task": task_id, "inputs": len(truth), "hits": sum(hits), "full": all(hits),
                  "checked_kept": [sum(1 for v in r["checked"] if v["accepted"]) for r in recs],
                  "submitted": [len(r["submissions"]) for r in recs]}))
