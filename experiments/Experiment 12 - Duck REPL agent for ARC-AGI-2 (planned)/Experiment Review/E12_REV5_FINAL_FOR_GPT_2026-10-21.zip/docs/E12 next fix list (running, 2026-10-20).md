# E12 Duck agent: next fix list (running)

> **Status 2026-10-21: rev 5 implemented and tested locally (not run on GPU).**
> - The user chose one bundled run with B1-B8 + B9(a) temperature 1.0; B9(b) presence penalty is not taken.
> - Notebooks:
>   - `Q27-XHIGH-E12_DUCK_REPL_SGLANG_EVAL6R5.ipynb` (sha `f4fed1ac…`, rev 5 + R5-1..R5-5);
>   - `…EVAL30R5.ipynb` (sha `415a68f2…`).
> - Details: section "Rev 5 implementation (2026-10-21)" at the end.

**Rule (user, 2026-10-20):**
- Read every GPT report in full and validate every claim.
- Add the validated items here.
- Change no code until the user says so.

**Sources:**
- **W**: my weakness analysis (`Experiment Results/E12 agent weakness analysis (2026-10-20).md`, zip `E12_AGENT_WEAKNESS_ANALYSIS_FOR_GPT_2026-10-20.zip`).
- **G1**: GPT "Deep Root-Cause Analysis".
- **G2**: GPT "দুর্বলতা, Root Cause ও উন্নয়ন পরিকল্পনা" (Weakness, Root Cause and Improvement Plan).
- **G3**: GPT "Deep Weakness Analysis & ARC-AGI-2 Adaptation".

All three were read in full on 2026-10-20.

## Where the three agree

- **No redesign:** keep Duck's transport, sandbox, retention, gate and transcript.
- **Order of work:**
  1. candidate harvest + two-attempt selection;
  2. context retention + truthful resume;
  3. reasoning efficiency (tool use, sampling, output size, loops);
  4. coverage/routing (Duck as a complement to Poetiq, not a replacement).
- **All three ask for isolated, measured steps.** This conflicts with the user's "bundle changes, big jumps" rule, so the order of testing is the **user's decision**.

## Fix list

| ID | Problem | Fix (validated choice) | Sources | Validation / evidence | Priority |
|---|---|---|---|---|---|
| **F1** | Train-exact (and test-correct) functions are lost when not submitted | **Runtime `check()` hook** (G1): when `check()` finds every pair exact inside the sandbox, the helper sends an action with the function name. The host re-verifies with the existing clean `_verify_submission`, stores the verdict, and **does not stop the branch**. An explicit `submit()` keeps today's end. Dedupe by source and test outputs; bounded verification cost | W1, G1 §4-5, G2 §3, G3 W1 | **Verified:** `select_attempts` reads only `submissions` (arc2_duck.py:556). Lost: 62593bfd_b1, b5ca7ac4_b0 (both test-correct by replay). **No auto-stop** (G1, verified): EVAL30 247ef758_b0 first exact (L1760) was test-wrong; the model fixed it and submitted a correct one (L2190). **Method chosen by data:** G2's passive harvest of retained `transform*/solver*` functions was replayed over all 43 branches. It found **no** exact function beyond `check()` and **missed 2** (135a2760_b1, 247ef758_b0: exact functions under other names). G3's AST scan of `check(name)` in the code would also verify non-exact checks (more cost) and can see unreached calls. The runtime hook sees only executed, exact checks; a forged signal only triggers a clean host verify | **P0** |
| F1-a | Proof of F1 | Validate with the real Duck sandbox and adapter (re-run the 62593bfd_b1 / b5ca7ac4_b0 / 247ef758_b0 sources), never with `replay_all.py` | G1, G2 §11B, G3 | **True:** `replay_all.py` runs host `exec` with every callable kept (no sandbox, no retention rules). Its 7/8 is a retrospective oracle estimate, not a production number | with F1 |
| **F2** | The reply just generated is dropped from the next prompt; the resume says "your tool results above are still valid" | (a) Correct the token estimate for reasoning text: the pinned Qwen tokenizer + chat template (G2 preferred) or the server's `completion_tokens` for assistant messages. Validate the estimate against the server's `usage.prompt_tokens`. (b) **Truthful resume:** the resume text is the adapter's own (arc2_duck.py:330-332); Duck sets `_context_was_trimmed` / `_has_evicted` in `_note_history_evicted` (tool_agent.py:6307), so the adapter can say "earlier reasoning was trimmed; reuse retained functions…". (c) `ARC3_CONTEXT_DRAIN_FLOOR` only as an optional test (the donor keeps it off because it costs cache hits, tool_agent.py:221-224) | W2, G1 §6, G2 §4, G3 W2 | **Verified, mechanism read in code.** After a tool-less reply, history = [opener, reply, resume]. Over budget, `_drop_oldest_history_block` (tool_agent.py:6222-6258) pops the opener and everything up to the next user message, so the reply goes. The estimate uses one chars/token ratio from the served prompt (`_calibrate_from_usage`, :5962-6008): 1.40-1.72 on grid prompts, later 2.26 / 2.43 (G2, true). 11 of 84 EVAL6 later requests (426,781 tokens) were not carried; 5 were full 60k replies reset to a system-only prompt (G3's independent count of 5 matches: 135a2760_b0, 62593bfd_b0 x2, 62593bfd_b1, 898e7135_b1). G2/G3: the share due to calibration vs the real 70,560 limit is unproven until a tokenizer check (accepted) | **P0** |
| F2-a | Capacity trade-off | 60k reserve → 70,560 input budget; a 60k reasoning + 9k prompt barely fits even when estimated exactly | G1, G3 | True (arithmetic) | decide with F3 |
| **F3** | Repetition loops in long thinking | Separate arms, not all at once (G2/G3): (a) **temperature: 0.7 (Duck) vs 1.0 (official Qwen3.8 thinking)**; (b) shorter per-request output (G1 32-40k, G2 24-32k) — **needs the user's approval (60k floor rule)**; (c) presence penalty only if loops persist; (d) better loop detection later (early cancel needs streaming, a big change, deferred) | W3, G1 §7, G2 §6, G3 W3 | **Verified on HF model card** (huggingface.co/Qwen/Qwen3.8-27B): thinking = temperature 1.0, top_p 0.95, top_k 20, min_p 0, presence 0, repetition 1.0; presence 0-2 reduces repetition but risks language mixing. **My "0.6 Qwen-like" was wrong**; our earlier DIRECT pipelines used 0.6, a separate data point. Duck's detector threshold is 0.01 zlib (tool_agent.py:1643-1657); our long blocks are 0.037-0.19, so 0 detections. Repeat share EVAL6 29.4 % (G3 independently 29.2 %), EVAL30 5.2 %; this is characters, not tokens (G2, accepted). **SGLang #28180** (verified): repetition penalty ineffective under DFlash; fix PRs not confirmed merged → check 0.5.21 before any penalty arm | **P1**; user decision on (b) |
| **F4** | Thinking in the head instead of testing in code; hand misreads; refusing a lookup that fits | Short wording changes only, no multi-stage template (G1/G2/G3, supported by Johan Land's abstract: prescriptive templates reduce diversity; verified on arXiv 2606.31543). Replace "Investigate until your code has a clear plan." (arc2_duck.py:266) and soften "derive positions, sizes, colors and counts from the input" with: use Python for exact grid values; implement and check a plausible rule early; an input-derived lookup / case split is valid; do not drop a train-exact candidate for lack of an elegant explanation; keep alternatives when ambiguous. Duck's `ARC3_PREFER_TOOL_CALLS` exists (tool_agent.py:1879) but **does not reach our prompt** (the adapter builds its own `arc2_system_prompt`); its wording (prompts.py:285) can be reused | W4, G1 §8, G2 §5, G3 W4 | Prompt lines verified. Failed-branch pattern measured (22/24 EVAL30, 5/8 EVAL6 without `check()`). G2: "median 100 % of tokens before the first check" is censored (most never check) and is not a timing estimate (accepted). G3 failure taxonomy (no candidate / partial / exact-no-submit / exact-wrong / correct-unselected) adopted for reporting | **P1** |
| **F5** | attempt_2 wasted; overfit accepts | Portfolio selection over submissions + F1 candidates. Two distinct train-exact predictions → both attempts, without letting a weak majority drop a minority. Identical grids deduplicated. Train-exact > partial > fallback. No invented confidence. Later, possibly a Poetiq candidate when Duck has none (G3) | W5, G1 §9, G2 §7, G3 W5 | **Verified:** attempt_2 = the test input in 56/56 slots (EVAL6 8 + EVAL30 48); 4/11 accepts test-wrong. Kaggle scoring: either attempt exact counts. b5ca7ac4 (EVAL6) would be rescued with b0's function as attempt_2 | **P0** with F1 |
| **F6** | `train` dict-unpack trap; retention NameErrors; a tool call cut at the cap executed as a stub | G3 prefers a **documentation fix first**: show `for p in train: inp, out = p["input"], p["output"]` in the tool guidance (smaller surface than a new global). G1/G2 propose a `train_pairs` alias. Small inspection helpers optional. Stub execution: audit the parser condition first (G3) | W6, G1 §10, G2 §8, G3 W6 | Dict trap verified (3 of 4 EVAL30 tasks read, 62593bfd_b0); `train` is a list of dicts (arc2_duck.py:127-131). Stub execution is reported by reader C (EVAL30 136b0064 L3550), not yet checked in code | P2 |
| **F7** | Coverage: about 10.4 min/task → 240 tasks ≈ 41 h vs about 11 h | Treat Duck as a **complement to Poetiq**. Measure Duck's unique solves and opportunity cost first. First-pass budget about 2.75 min/task (G2 arithmetic) if Duck ran alone | W7, G1 §11, G2 §12, G3 §5 | Arithmetic true. **G3's complementarity signal verified** in our ledger: 247ef758 query 1 was solved by Duck EVAL30 and by **0 of 12** other runs (`Puzzle Capability Ledger/ledger_units.csv`) | P0 for a submission, after F1-F5 |
| F8 | Branch sharing | **Not now.** Merge candidate pools, not reasoning contexts (diversity) | G3 W8, G1 | opinion, consistent with the paper's diversity point | — |
| F9 | Reviewer/judge (Athanor / Johan Land style) | Later, only when F1/F5 produce conflicting portfolios; frontier-API results are not transferable | G1, G2, G3 | Paper abstract verified (holistic judging recovers minority hypotheses). G1's numbers (144/167 vs 128; Table 4) are not visible in the abstract → unverified | later |
| F10 | Trusted serializer (json.dumps spoof) | Revisit before hidden submission with harvesting. Decided 2026-10-19 not to fix (the score is truth-checked, never observed, a lookup is equivalent); with harvesting, a forged candidate could take an attempt slot in a hidden run. Still never observed in 43 transcripts | G2 §11A | Source fact verified (`_grid_call_code` unchanged) | P2, decision |
| F11 | Analysis hygiene | No truth in production paths; replay claims re-checked in the real sandbox; report characters vs tokens and censored statistics properly | G1, G2, G3 | accepted | always |
| F12 | Do not copy wholesale | No 29-candidate ensemble, no multi-agent API orchestration, no rigid templates, no generic augmentation, no streaming rewrite now. Imbue Darwinian Evolver is **AGPL-3.0** (verified) → ideas only | G1, G2, G3 | AGPL verified | note |

## Metrics for every future run (merged G1 §13 + G3 §8)

- Correct outputs and fully solved tasks.
- Any train-exact program found.
- Host-verified candidates (harvested vs submitted).
- Correct candidate generated but not selected.
- Distinct predictions per test input.
- Tokens before the first `check()` (censored).
- Repeat share (characters).
- Reply tokens dropped / newest reply retained rate.
- Prompt-cache %.
- Train-exact / test-wrong rate.
- Unique correct outputs per 4xL4 wall-hour.
- Duck-only solves vs Poetiq.

## Corrections to my own earlier statements (found through these reviews)

1. "No failed branch got even one train pair exact" (weakness README W4): **wrong** (G1). 62593bfd_b1 2/2, b5ca7ac4_b0 3/3, EVAL30 135a2760_b0 1/2. Fixed in the doc.
2. "The newest block always stays" (pre-run validation): **wrong** for tool-less replies (code read above).
3. "Sampling closer to the Qwen recommendation (temperature 0.6)": **wrong**. The official thinking setting is 1.0.

## Claim-by-claim tables

### G1

| Claim | Verdict |
|---|---|
| README W4 wrong | True |
| Selection only from submissions | True |
| 247ef758 → no auto-stop | True |
| `replay_all.py` is not the sandbox | True |
| Calibration at :5962-6008 | True |
| Calibration share is a hypothesis | Partly resolved in code (the estimate exceeds the budget only with the grid ratio); tokenizer proof pending |
| 70,560 trade-off | True |
| Degenerate threshold 0.01 misses loops | True |
| Non-streaming, so no mid-request recovery | True |
| SGLang #28180 | True; fix status unknown |
| Prompt line :266 | True |
| 4/11 wrong accepts | True |
| Poetiq 16/48 | True |
| 10.4 min/task | True |
| Paper numbers 144/167, 128, Table 4 | Unverified (not in the abstract; PDF not available to me) |
| AGPL | True |
| Athanor and other donors | Ideas, not checked |
| `check()` → `action()` feasible | True; note verification sandboxes refuse actions |

### G2

| Claim | Verdict |
|---|---|
| `_run_python_tool` appends only pending submits (arc2_duck.py:361-474) | True |
| Passive harvest via `keepable_functions` is feasible | True (name/source exist, tool_agent.py:4614-4627), but **replay shows it misses 2 of 12 and adds 0** → not chosen |
| Calibration 1.40 → 2.26 / 2.43 | True |
| Exact cause unproven without tokenization | Accepted |
| Tokenizer counting preferred; constant bump rejected | Accepted |
| "Prefer the simplest rule … derive … from the input" | True (system prompt) |
| Johan Land §8.6: prescriptive prompts hurt | Abstract confirms the general claim; section number not checked |
| Qwen3.8 thinking: temperature 1.0, top_p 0.95, top_k 20, presence 0, repetition 1.0 | **True** (HF card) |
| Presence penalty caveat | True |
| 56/56 attempt_2 = input | True |
| Majority vs holistic, 7 extra instances | Abstract confirms the principle; "7" unverified |
| `train` dict trap + alias | True |
| Serializer guard absent | True (decided earlier, revisit = F10) |
| `replay_all.py:17-27` keeps all callables | True |
| 62.4 min / 6 = 10.4; 240 tasks = 41.6 h; 2.75 min/task target | True (arithmetic) |
| Censored median, characters vs tokens | Accepted |
| Vendored tree not byte-compared to upstream (by G2) | Note; our earlier manifest check showed 23/23 hash match to our vendored copy |

### G3

| Claim | Verdict |
|---|---|
| 12 branches / 96 requests / 1,217,904 tokens; soft cap stopped most failures | True |
| 62593bfd_b1 / b5ca7ac4_b0 lost | True |
| Do not auto-submit every check | Agrees with G1 |
| AST-based `checked_function_names` sketch | Feasible; the runtime hook chosen instead (only executed + exact checks; the AST also catches non-executed calls, G3 notes it) |
| At least 5 system-only resets | True (5 identified) |
| Mechanism (1.40 ratio, 126k chars ≈ 90k) | True (code read) |
| Donor knobs `ARC3_CONTEXT_DRAIN_FLOOR`, `ARC3_STUB_DEAD_REASONING`, `ARC3_PRUNE_CONTROL_CONTEXT`, `ARC3_SUMMARY_REPLACES_HISTORY` | Exist in the vendored tool_agent.py; none set by the adapter |
| `ARC3_PREFER_TOOL_CALLS` | Exists (:1879), but only enters Duck's own prompt; our adapter prompt does not use it |
| Resume text at arc2_duck.py:330-332 | True (adapter text) |
| Repeat share 29.2 % / 5.2 %, 11 of 96 blocks | True (matches) |
| Qwen temperature 1.0 | True |
| Degenerate stubbing at :6945-6979 | True; post-hoc only |
| Early cancel needs streaming | True (`stream=False`) |
| `train` = list of dicts (:127-131); documentation-first fix | True; recorded as F6 option |
| 247ef758 Duck-only signal | **True** (ledger: query 1 solved 0/12 by other runs) |
| 62 / 6 x 240 = 41.3 h; Kaggle 12 h / 4xL4 quota cost | True |
| b0 0/6 vs b1 4/6 not a branch effect | Agreed |
| Johan Land pp. 32-33 negative results | Abstract confirms the principle; pages not checked |
| Not-now list (judge, multi-agent, templates, augmentation, check-stdout trust, sharing, streaming, extra judges) | Accepted as F12/F8/F9 |

## Deep re-validation (2026-10-21, all 43 branches; user: one bundled run, evidence-based changes only)

| Check | Method | Result |
|---|---|---|
| **A. F1 in the real sandbox** | `e12_smoke/replay_real_sandbox.py`: every recorded tool call of all 43 branches through the REAL `Arc2ToolAgent._run_python_tool` (Duck sandbox, prelude, retention); at each exact `check()`, the adapter's `_verify_submission` | 62593bfd_b1: host-accepted, both tests correct. b5ca7ac4_b0 `transform2`: host-accepted, test correct. 247ef758_b0: call 9 host-accepted but test half-wrong; calls 12 and 14 correct. **New: 136b0064_b1 call 4**: the model's `check()` printed exact but the host verify **rejected** it (`patmap` not retained), and the model fixed it later. So the host verify is required, and a failed harvest verify must be reported back to the model. 3dc255db_b0 (EVAL30) found too (wrong on test) |
| **Simulated F1 + F5** | latest host-accepted function per branch first, then earlier ones; two attempts; scored with truth | **EVAL6: 5/6 tasks, 7/8 inputs** (actual 3/6, 4/8). **EVAL30: unchanged 4 tasks, 7/48** (branch 1 never ran there, so no second candidate) |
| **B. F2 with the real tokenizer** | Qwen INT4 `tokenizer.json`; reply tokens vs Duck estimate vs budget 70,560 | Reply = exactly 60,000 tokens (= server). The 4 system-only resets would really have been 65,203-69,461 tokens (**fit**), but Duck estimated them at 77,269-111,375 (over). Kept case (ratio 2.10): estimate 70,042, just under |
| **All 11 drops classified** | prev prompt + reply vs budget (tool result ≤ 3.3k) | **5 avoidable** (the system-only resets: 135a2760_b0, 62593bfd_b0 x2, 62593bfd_b1, 898e7135_b1; about 279k reply tokens), caused only by the estimate. **6 real overflows** mid-run (prev + reply = 75.5-84.2k > 70,560). At a 49,152 output cap the budget is 81,408, so 4 of the 6 would fit (75.5k, 76.3k, 79.4k, 80.8k + tool) |
| **C. Output-cap evidence** | completion by finish reason (EVAL6) | Tool-call replies (87): p50 2.3k, p90 31.6k, p95 35.6k, max 58.2k; **> 40,960: 3 (one in a solved branch: 4c3d4a41_b1 first reply 44,779); > 49,152: 1** (898e7135_b0, failed). The 7 `length` replies (all at 60,000) had **no** tool call. No solved-branch reply exceeded 44,779 → **a 49,152 cap cuts no productive reply seen; 40k would have cut one solved reply** |
| **Loop position** | repeated-line share per sixth of each >60k-char reply | Loops start early (by about 1/6-2/6 of the reply) and then fill the rest at ~100 %. One solved branch (4c3d4a41_b1) escaped a mid-reply loop. A cap trims only the tail; a loop stop or penalty is needed to save the bulk |
| **SGLang 0.5.21 DFlash penalties (static read)** | `sgl_src` 0.5.21 | EAGLE accumulates penalty output tokens each decode step (`eagle_utils.py:1056-1058` → `batch.cumulate_penalty_output_tokens()`); the DFlash path (`spec_utils.spec_prepare_for_decode` → `dflash_info_v2.prepare_for_decode`) never calls it. `dflash_utils.py:255-285` applies only linear penalties. So **presence/frequency/repetition penalties are effectively inactive with DFlash2 in 0.5.21** (= SGLang #28180). A penalty arm needs a 2-line SGLang patch mirroring EAGLE |
| **E. Truncated tool call executed** | finish `length` with a tool call | EVAL30: 5 cases executed (e.g. 136b0064_b0 L2895: `length`, arguments `def block_pattern(...): H=len(inp)` executed and retained); EVAL6: 0. Duck flags truncation only when the arguments fail to parse (tool_agent.py:6887); SGLang's parser returns closed JSON, so it runs. Relevant again with a 49k cap |
| **D. Sweep for missed issues** | all tool results / statuses / server log | Tool errors EVAL6: NameError 4 (3x `patmap` retention, 1x `collections`), ValueError 4, ImportError 1 (`inspect`), IndexError 1. **EVAL30 request timeouts: 40** in 21 of 31 branches (28 full 900 s + 12 deadline-bounded; about 31,000 stream-seconds). I had written "4", which was **wrong**; fixed by the 1,800 s timeout (EVAL6: 0). Server log: no OOM / errors (benign `wrapt` sitecustomize, 1 early abort). Decode log: 184 of 1,154 lines with 1 running, 358 with < 6 → an EVAL-tail effect (12 branches / 6 live), small for 240 tasks |

## Bundle for the next run (evidence-based; for the user's decision)

| # | Change | Evidence | Scope |
|---|---|---|---|
| B1 | **F1** runtime `check()`-exact hook → host clean verify → candidate stored; branch continues; explicit `submit()` keeps today's end. The verify result goes back to the model (accepted / why rejected) | 2 lost solves (real sandbox), 247ef758 (no auto-stop), 136b0064_b1 (host reject) | adapter |
| B2 | **F5** two attempts from distinct host-verified candidates, latest per branch first, then earlier ones, then partial, then fallback | b5ca7ac4 rescue; 56/56 wasted attempt_2; 247ef758 (latest = correct) | adapter |
| B3 | **F2a** real token accounting for history: the server's usage (`prompt_tokens` + `completion_tokens`) or the tokenizer, instead of one grid-calibrated ratio | 5 avoidable resets, about 279k tokens, tokenizer-proven | adapter override of the estimate (vendor untouched if possible) |
| B4 | **F2b** truthful resume when history was trimmed (Duck flags `_context_was_trimmed`) | restarts after trims + the false "still valid" text | adapter |
| B5 | **F3** output cap 60,000 → **49,152** (input budget 70,560 → 81,408) | no productive reply > 44,779; 7 dead 60k replies; 4 of 6 real overflows would fit. The user approved evidence-based cuts (2026-10-21) | config |
| B6 | **F6-b** a `length`-cut tool call is not executed; "cut off" feedback instead | 5 executed stubs in EVAL30; more likely at 49k | small vendor/adapter change |
| B7 | **F4** prompt wording: replace "Investigate until your code has a clear plan."; soften "derive …"; code-first; an exact lookup is valid; keep alternatives | 22/24 + 5/8 failed branches without `check()`; misreads; lookup refusal (136b0064) | adapter prompt |
| B8 | **F6** `train` usage example in the tool guidance | dict trap in ≥ 4 branches | adapter prompt |
| B9 | **Loops: user decision.** (a) temperature 0.7 → **1.0** (official Qwen3.8 thinking setting; no A/B data of ours). (b) presence penalty **only with** the 2-line SGLang DFlash patch; HF warns of language mixing; no data of ours. Loops are the largest remaining waste (29 % of thinking characters) | loops measured; remedies unmeasured on our stack | config / SGLang patch |
| — | Not in the bundle | F7 coverage/routing (needs this run's metrics), F8-F12 | — |

## Rev 5 implementation (2026-10-21; user: B1-B8 + B9(a) temperature 1.0)

All in `duck_arc2/arc2_duck.py` (the vendored Duck files are unchanged) and the builder. Every change sits behind `E12_ARC2_REV5=1`, which only the R5 builds set, so SMOKE1 / EVAL30 / EVAL6 keep their exact behaviour (regression below).

| # | How | Where |
|---|---|---|
| B1 | The prelude `check()` sends `CHECKED:<name>` through the same action channel as `submit()` when every pair is exact (try/except: refused inside verification). After retention is updated, the host runs the existing `_verify_submission(name)`. The verdict goes to `arc2_checked` (not `submissions`, so the opener still reports only real submissions) and a short note goes back to the model (kept / why not). Dedupe on (name, sha of all retained sources); cap 24 verifications per branch (`E12_CHECK_VERIFY_CAP`). The branch is **not** stopped; an explicit `submit()` still ends it | `_HELPERS_SRC_R5`, `_handle_action`, `_arc2_harvest_checks`, `run_branch` record (`checked`, `rev5_events`) |
| B2 | `select_attempts_r5`: per branch, its latest accepted submission, else its latest accepted check; grouped by output (more branches > explicit submit > latest); then other accepted (latest first); then partial; then the test input. attempt_2 = the next distinct grid. Invalid grids are never selected | `select_attempts_r5`, `build_submission` |
| B3 | `_estimate_request_input_tokens`: assistant reasoning (≥ 2,000 chars) is counted with the served model's `tokenizer.json` (`E12_TOKENIZER_JSON`; fallback 1.9 chars/token); `_calibrate_from_usage` then removes the reasoning from the ratio measurement, so the ratio describes the non-reasoning text it is applied to | `reasoning_tokens`, overrides |
| B4 | Resume text without the false "tool results still valid". When Duck's trimmer removed messages, the resume opener it keeps says older messages (possibly the latest reasoning / tool results) were removed and asks to recover facts with Python | `ARC2_RESUME_R5`, `ARC2_RESUME_TRIMMED`, `_trim_messages_for_context` |
| B5 | `E12_DUCK_MAX_OUTPUT` 49,152 (input budget 81,408) | builder |
| B6 | `_chat_completion`: on `finish_reason=length`, tool-call arguments are made invalid, so Duck's own path drops them. **Found by the harness:** with the 2,048-token yield, Duck's "cut off" note is never sent (the turn yields first), so the next resume opener now says the call was cut and nothing ran | `_chat_completion`, `ARC2_RESUME_CUT` |
| B7 | Four exact-text prompt edits: the simplest-rule line softened (+ lookup valid + compare test outputs when rules disagree); "read exact values with Python"; "check() keeps candidates"; "write and check a candidate early" instead of "Investigate until your code has a clear plan." | `_R5_EDITS` |
| B8 | `train` usage example in the tool guidance | `_R5_EDITS` |
| B9(a) | `E12_DUCK_TEMPERATURE` 1.0 → `LOCAL_ANALYZER_TEMPERATURE` | `duck_env`, builder |
| — | Report: per-branch `checked_verified` / `checked_kept` / `rev5_events`; per query `harvested_programs(_correct)` | CELL 7 |
| — | Profiles: `EVAL6R5` (6 tasks, 90 min solving, 125 min budget) and `EVAL30R5` (the same 30 seed tasks as EVAL30, 330 min solving, 6 h budget). The rev 5 knobs apply to every profile of an R5 build, including the hidden rerun | builder |

### Local evidence (rev 5)

- **Rev 5 unit checks (`smoke_rev5.py`, real Duck sandbox): 40/40.**
  - Harvest: exact / dup / changed source / `verbose=False` / non-exact / not-retained / forged signal / cap / check+submit.
  - Selection: two distinct / latest first / dedupe / partial / fallback / invalid grid.
  - B3: the recorded 60,000-token 62593bfd_b1 reply, at the EVAL6 budget of 70,560 and ratio 1.40. Old estimate over budget, so the reply is dropped (the bug is reproduced); rev 5 estimate within budget, so the reply is kept. Calibration stays at the grid ratio.
  - B4: trimmed and untrimmed.
  - B6: invalid args; normal call untouched; the next resume says "cut", once; trimmed + cut.
  - B9 env.
- **End-to-end real-sandbox replay with the rev 5 hook** (`replay_rev5.py`, all recorded tool calls of both branches, then `build_submission`):
  - **EVAL6: 5/6 tasks, 7/8 inputs** (recorded run 3/6, 4/8);
  - **EVAL30: 4 tasks, 7/48** (unchanged: branch 1 never ran there).
- **Notebook harness (real cells + fake SGLang):**
  - **`r5` on EVAL6R5: 30/30.** Covered: knobs; every request 49,152 / temperature 1.0; rev 5 prompt; ≤ 6 in flight; no branch submits yet every branch keeps ≥ 1 verified candidate; the cut call never ran and the model was told; rev 5 resume; every query hit with one right + one test-wrong candidate per task; harvested counts in the report.
  - **`rerun` on EVAL6R5 (hidden mode with rev 5): 21/21.** `launchfail`: 6/6.
- **Regression:**
  - `eval6` on the rebuilt rev 4 EVAL6: 25/25.
  - `smoke` on SMOKE1_REV4: 22/22.
  - Adapter unit checks with rev 5 off: 41/41.
  - The Kaggle-run notebooks are untouched: EVAL6 `53a66856…`, SMOKE1 `0fea4d0c…`, EVAL30 `b65fb9dc…`. The builder now never overwrites EVAL6 (`_REBUILD`).
- **Check-only on hosen42:** both R5 notebooks passed on the previous build (account, inputs, quota 30.8 of 60 h used). It will be re-run with the final shas at push time; `--sha` is mandatory.

**Validation before GPU:** extend the CPU harness and unit checks:
- harvest (exact / non-exact / rejected-by-host / duplicate / forged signal);
- selection (two distinct, identical, latest-first);
- estimate vs the recorded usage of the 11 drop cases;
- truthful resume;
- cut tool call not executed;
- `replay_real_sandbox.py` on all 43 branches as a regression.

## Rev 5 audit, GPT 1 (2026-10-21): GO for EVAL6R5. Validated

| GPT 1 claim | Validation | Verdict / action |
|---|---|---|
| Notebook shas match; only `arc2_duck.py` changed in the embedded package (1/23); both notebooks compile | Agrees with our build and manifest | true |
| B1-B9(a) correctly placed; legacy smoke with rev 5 off passes | Agrees with our tests (rev 5 unit 40/40, flag-off 41/41, harness r5 30/30, rerun 21/21, launchfail 6/6) | true |
| **N1:** redefining the same name after an exact `check()` in one tool call loses the exact version (retention keeps only the final definition) | True by design: the hook sends only the name, and retention happens after the call. **Frequency in our data: 0** of 405 recorded tool calls (84 EVAL6 + 321 EVAL30) redefine a name, or redefine it after checking it (AST scan) | real edge, never observed. Options: one prompt sentence ("give each version its own name, e.g. transform_v1/_v2"), or nothing. **Doc wording fixed:** "exact checks of the retained (final) definition are kept", not "every exact check" |
| **R1:** verification worst case 24 x 60 s per branch | Measured in the real sandbox on recorded candidates (7 branches, 16 verifications): **0.75-2.71 s each, ≤ 3 per branch** (Windows) | worst case real, observed cost negligible; keep cap 24; report `checks_verified` |
| **R2:** tokenizer fallback (1.9 chars/token) if `tokenizer.json`/`tokenizers` missing | The Kaggle EVAL6 run loaded exactly this file with `tokenizers` in CELL 2 (`tokenizer_check ok: True`, `/kaggle/input/models/foysalemonshanto/qwen3-8-27b-int4-redhat/...`). The E12 block reads `SGL_MODEL_PATH` after `_e11_discover` (same cell, appended later) | low risk. Optional: a report field "tokenizer loaded / fallback" (today only a log warning) |
| **R3:** B6 could drop a complete, valid call cut at the limit | All **5** EVAL30 length-cut tool calls were incomplete: 3 parse (stubs: `H=len(inp)`, an import line, a loop body), 2 syntax errors. EVAL6: 0. No complete call was ever cut | no evidence of loss; keep B6 |
| B2 cannot select an invalid grid; replay 5/6 is retrospective, not a prediction | True (`valid_grid` filter; tested) | agreed; keep that wording in the report |
| B3 does not keep all reasoning forever (budget 81,408 + hysteresis) | True | agreed |
| Interpretation table (5-6 / 3-4 / 0-2 of 6; exposure) and "bundle, so no per-fix attribution" | Consistent with our plan | adopted for the run report |
| EVAL30R5: late tasks may get less compute; run EVAL6R5 first | Consistent with the capacity check | adopted |

## Rev 5 audit, GPT 2 (2026-10-21): NO-GO until 1 fix (P0) + tokenizer preflight. Validated

| GPT 2 claim | Validation | Verdict / action |
|---|---|---|
| **P0:** a wrong function that patches `json.dumps` is host-accepted, now also through a forged `CHECKED:` | **Reproduced on the current rev 5 code** (`Analysis scripts/weakness/validate_spoof_r5.py`, real sandbox): forged CHECKED accepted=True **and** the same spoof via `submit()` accepted=True. A correct function that uses `json.dumps` is kept; a wrong identity function is rejected. Not new: the same path was found on 2026-10-19 (submit) and left open (truth-scored eval, never observed: 0 in 43 transcripts). The CHECKED path does not widen it (equal to submit) | **GPT's guard tested as a prototype:** forged CHECKED → rejected; spoof submit → rejected; correct json-using function → still kept; identity → rejected. Adapter-only, a few lines in `_grid_call_code`; it covers `json.dumps` reassignment, not every possible tamper (GPT says so too). **Recommend taking it** (cheap, no false rejects seen), behind the rev 5 flag so old profiles stay identical |
| **HIGH:** B3 silently falls back to 1.9 chars/token if the tokenizer is missing | True (a log warning only). On Kaggle the same file loaded with `tokenizers` in the EVAL6 run (`tokenizer_check ok`) | **Recommend a preflight that records + prints** (`rev5_tokenizer`: loaded / path / probe tokens) in CONFIG and the report. GPT proposes an `assert`; that would turn a fallback (the run still works) into a dead solver, so record rather than assert. User decision |
| B1 limits: same-name redefinition (= GPT 1 N1); the cap also counts rejected verifications | Both true (keys are added before verifying). N1: 0 of 405 recorded calls | accepted as known limits |
| B4: the rewritten resume adds tokens after the trim computed its budget | True: +216 characters (≈ 50-110 tokens) over `ARC2_RESUME_R5`. Duck window 131,072 vs server context 155,648 leaves about 24k of margin | negligible; no change |
| B6 invalid args never reach history | Agrees (tool_agent.py:6862-6887 drops all calls of the reply; harness: the cut code never ran) | true |
| EVAL30R5's 330-min window ≠ EVAL30's 4 h | True | report the runtime difference when comparing with 7/48 |
| Hidden 240-task coverage not solved | True | known (F7) |

## Rev 5 audit, GPT 3 (2026-10-21): CONDITIONAL NO-GO (1 fix). Validated

| GPT 3 claim | Validation | Verdict / action |
|---|---|---|
| Integrity: shas, embedded adapter, vendor byte-identical to rev 4; flag-off 41/41 rerun on Linux | Agrees | true |
| **B6 bypass:** on a `length` reply with **no** parsed `tool_calls`, Duck recovers a call from `<tool_call>` markup in content/reasoning (tool_agent.py:6842-6849) and executes it; the rev 5 override only touches parsed calls | **Reproduced** (`Analysis scripts/weakness/validate_b6_markup.py`, Duck's exact sequence): length + markup in content → EXECUTES; length + markup in reasoning → EXECUTES; length + parsed call → dropped; stop + markup → recovered as designed. **In the recorded runs: 0** responses had markup in text (EVAL6 + EVAL30) | real gap in B6's invariant. **Fix:** on `length` with no parsed calls but markup present, insert one placeholder call with invalid arguments, so Duck's malformed path drops it and skips recovery. Adapter-only |
| **B4 edge:** `_force_reduce_messages` (used only when a server rejection was not fixed by the forced trim, tool_agent.py:6809-6818) bypasses the resume rewrite | True (code read) | **Fix:** same rewrite in an override of `_force_reduce_messages` (tiny) |
| B3 is a hybrid (reasoning by tokenizer, the rest by the calibrated ratio), not exact chat-template accounting | True | accepted. **Add a metric:** estimate vs the server's `prompt_tokens` per request, to validate B3 on GPU |
| B1 verification worst case 24 x 60 s | Same as GPT 1 R1; measured 0.75-2.71 s per verification, ≤ 3 per branch | keep |
| B2 deliberate trade-off (a branch's submission ranks over its checks) | True; not a bug | keep |
| B5 / B7 / B8 / B9(a) OK; bundle means no per-fix attribution | Agrees | report wording |

## Consolidated pre-run change list from the three rev 5 audits (awaiting the user's approval)

| # | Change | From | Evidence | Recommendation |
|---|---|---|---|---|
| R5-1 | Serializer guard in `_grid_call_code` (`json.dumps` reassignment rejected), behind the rev 5 flag | GPT 2 (P0) | reproduced: forged CHECKED and spoof submit both accepted today; guard rejects both and keeps a correct json-using function | **take** |
| R5-2 | B6: block markup recovery on `length` replies | GPT 3 | reproduced (content and reasoning markup execute today) | **take** |
| R5-3 | B4: resume rewrite also in `_force_reduce_messages` | GPT 3 | code read | **take** (tiny) |
| R5-4 | Record + print the tokenizer state (loaded / path / probe tokens); no assert | GPT 1 R2, GPT 2 | fallback is silent today; it loaded on Kaggle before | **take** (record, do not assert) |
| R5-5 | Estimate-vs-actual prompt tokens per request in `rev5_events` | GPT 3 | needed to validate B3 on GPU | **take** (measurement only) |
| R5-6 | One prompt sentence: distinct names for versions tested in one call | GPT 1 N1, GPT 2 | 0 of 405 recorded calls | optional (no evidence of loss) |

Regression to add: spoof via CHECKED / submit / correct json-user; length + markup (content / reasoning / incomplete); stop + markup still recovered; forced-reduce resume; tokenizer record (present / missing); estimate metric present. Then rebuild both notebooks and rerun every suite (unit rev 5 + flag-off, harness r5 / rerun / launchfail / eval6 / smoke, e2e replay).


## R5-1..R5-5 applied (user 2026-10-21: "take them, validate again"); R5-6 not taken (no evidence)

| # | Applied as | Test |
|---|---|---|
| R5-1 | `_grid_call_code(..., guard=self._arc2_rev5)`: restores `json.dumps` after the call and fails verification if it was reassigned | unit: forged CHECKED spoof rejected; submit spoof rejected; a correct json-using function still kept; control with rev 5 off unchanged. `validate_spoof_r5.py` now: all three False/False/True/False |
| R5-2 | `_chat_completion`: on `length` with no parsed call but `<tool_call>` markup, a placeholder call with invalid arguments → Duck's malformed path drops it and skips markup recovery | unit: complete markup in content / reasoning dropped; incomplete markup never executes; plain reasoning = no call; stop + markup still recovered. `validate_b6_markup.py` now: DROPPED / DROPPED / DROPPED / EXECUTES (stop) |
| R5-3 | `_force_reduce_messages` override → the same resume rewrite | unit |
| R5-4 | `tokenizer_status()` in CELL 3 → `CONFIG["e12"]["rev5_tokenizer"]` + print; never fatal | unit: present → loaded; missing (subprocess) → not loaded + reason + fallback count; harness: recorded and loaded in the report |
| R5-5 | `rev5_events["prompt_estimates"]`: [estimate, server prompt_tokens] per request (≤ 400) | unit; harness: present for every branch |

**Final validation (2026-10-21):**
- **Unit checks:**
  - rev 5: 53/53;
  - rev 5 off: 41/41.
- **Notebook harness:**
  - r5: 32/32;
  - rerun: 21/21;
  - launchfail: 6/6;
  - rebuilt rev 4 eval6: 25/25;
  - SMOKE1_REV4: 22/22.
- **End-to-end real-sandbox replay:** EVAL6 5/6 tasks, 7/8 inputs; EVAL30 4 tasks, 7/48.
- **Package and originals:**
  - pyflakes clean;
  - embedded `arc2_duck.py` == source in both R5 notebooks;
  - 0 vendor files changed vs the Kaggle-run rev 4 notebook (23 files);
  - Kaggle-run originals untouched (EVAL6 `53a66856…`, SMOKE1 `0fea4d0c…`, EVAL30 `b65fb9dc…`).
- **Check-only on hosen42:** OK for EVAL6R5 `f4fed1ac5ee332ad3a69eda841a8d7679d39b9a96f68e0b6777e2a6eb87d32a1` and EVAL30R5 `415a68f27ed9108024206d03cf4124ae3952aa1e8acee04ad88a6490ce7facd9`. Quota used 30.79 of 60 h.
