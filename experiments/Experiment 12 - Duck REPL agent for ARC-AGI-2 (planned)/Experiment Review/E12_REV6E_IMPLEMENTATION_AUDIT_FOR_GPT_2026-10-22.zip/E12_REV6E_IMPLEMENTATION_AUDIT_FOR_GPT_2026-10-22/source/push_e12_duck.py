"""E12 (Duck REPL agent on the E11-06 SGLang W1 engine): QUICK_SAVE (no run) or --commit. Variant: SMOKE1 (default) | --eval30.
Push only after the user's go. Account = the one in the credentials used (default ~/.kaggle -> foysalemonshanto);
pass --owner <name> to assert a different account. L4 x4, internet OFF, pinned image (= S49 / E11-04).
--check-only: account, inputs and quota only."""
import hashlib, json, os, sys
from pathlib import Path

ESFER = "--esfer" in sys.argv               # esfersami50 (token read in-process, never printed; = push164)
if ESFER:
    os.environ["KAGGLE_API_TOKEN"] = Path(r"C:/Users/hp/.kaggle-esfer/access_token").read_text().strip()
HAMID = "--hamid" in sys.argv               # hosen42 (token read in-process from the user's file, never printed)
if HAMID:
    import re as _re
    os.environ["KAGGLE_API_TOKEN"] = _re.search(r"KGAT_[A-Za-z0-9_\-]+", Path(r"C:/Users/hp/hamid vai/kaggle token.txt").read_text(encoding="utf-8-sig")).group(0)
COMMIT = "--commit" in sys.argv             # SAVE_AND_RUN_ALL (commit run) instead of QUICK_SAVE

from kaggle.api.kaggle_api_extended import KaggleApi
from kagglesdk import KaggleClient
from kagglesdk.kernels.types.kernels_api_service import ApiSaveKernelRequest
from kagglesdk.kernels.types.kernels_enums import KernelExecutionType

VARIANT = ("EVAL12R6G4B" if "--eval12r6g4b" in sys.argv else "EVAL12R6" if "--eval12r6" in sys.argv else
           "PARITYR6" if "--parity" in sys.argv else
           "EVAL6R5" if "--eval6r5" in sys.argv else "EVAL30R5" if "--eval30r5" in sys.argv else
           "EVAL12R5" if "--eval12r5" in sys.argv else
           "EVAL6" if "--eval6" in sys.argv else "EVAL30" if "--eval30" in sys.argv else "SMOKE1")
ENG = "VLLM" if "--vllm" in sys.argv else "SGLANG"
EFF = ("_LOW" if "--low" in sys.argv else "") + ("_S12" if "--s12" in sys.argv else "")   # rev 5 low-effort variant (same notebook, reasoning_effort low)   # E12-V: the same Duck notebook on the S1-60K vLLM engine
NB = (r"D:/ARC AGI 2/experiments/Experiment 12 - Duck REPL agent for ARC-AGI-2 (planned)/Experiment Notebooks/"
      f"Q27-XHIGH-E12_DUCK_REPL_{ENG}_{VARIANT}{EFF}.ipynb")
if VARIANT == "EVAL12R6G4B" and "--rev6d" not in sys.argv:   # rev 6e: the Kaggle-run rev 6d G4B (1bdadd82) is kept as is;
    NB = NB.replace(".ipynb", "_REBUILD.ipynb")                # the current build is *_REBUILD (same Kaggle slug, a new version)
EXPECT_SHA = sys.argv[sys.argv.index("--sha") + 1] if "--sha" in sys.argv else None
OWNER = "esfersami50" if ESFER else ("hosen42" if HAMID else "foysalemonshanto")
SLUG = f"{OWNER}/q27-xhigh-e12-duck-repl-{ENG.lower()}-{VARIANT.lower()}{EFF.lower().replace('_', '-')}"
TITLE = f"Q27 XHIGH E12 Duck REPL {'vLLM' if ENG == 'VLLM' else 'SGLang'} {VARIANT}{EFF.replace('_', ' ')}"
MODELS = ["foysalemonshanto/qwen3-8-27b-int4-redhat/PyTorch/w4a16-g128/1",      # = E11-04
          "foysalemonshanto/qwen3-8-27b-dflash2/PyTorch/bf16/1",                # = E11-04
          "foysalemonshanto/qwen3-8-27b-fp8-repacked-v1/PyTorch/hf-fp8/1"]      # = S49 (tokenizer + fallback)
DATASETS = ["foysalemonshanto/sglang-0-5-21-cu13-wheelhouse",                   # = E11-04
            "mirzamilanfarabi/arc3-vllm-h100-wheelhouse-v3"]                    # = S49
DOCKER = "gcr.io/kaggle-private-byod/python@sha256:37c64f7dd9c54116ecd1bcc88817c5469b88387388fade02bfa8bf3fc647d461"

api = KaggleApi(); api.authenticate()
ok = True
owners = sorted({str(getattr(k, "ref", "")).split("/")[0] for k in api.kernels_list(mine=True, page_size=5)})
print("authenticated kernels owner(s):", owners)
if owners and owners != [OWNER]:
    ok = False; print("WRONG ACCOUNT, expected", OWNER)
for m in MODELS:
    try:
        api.model_instance_get(m.rsplit("/", 1)[0]); print("model OK", m)
    except Exception as e:
        ok = False; print("model ERR", m, repr(e)[:160])
for d in DATASETS:
    try:
        files = api.dataset_list_files(d)
        print("dataset OK", d, len(getattr(files, "files", None) or []), "files")
    except Exception as e:
        ok = False; print("dataset ERR", d, repr(e)[:160])
try:
    q = api.quota_view().gpu_quota
    print("gpu quota used h", round(q.time_used.total_seconds() / 3600, 2), "of", round(q.total_time_allowed.total_seconds() / 3600, 2))
except Exception as e:
    print("quota ERR", repr(e)[:120])
raw = open(NB, "rb").read(); text = raw.decode("utf-8"); json.loads(text)
sha = hashlib.sha256(raw).hexdigest()
print("notebook sha256", sha[:16], "OK" if (EXPECT_SHA and sha == EXPECT_SHA) else "MISMATCH / not given (--sha)")
if not EXPECT_SHA or sha != EXPECT_SHA:
    ok = False
if not ok or "--check-only" in sys.argv:
    sys.exit(0 if ok else 1)
r = ApiSaveKernelRequest()
r.slug = SLUG
r.new_title = TITLE
r.text = text; r.language = "python"; r.kernel_type = "notebook"
r.is_private = True; r.enable_gpu = True; r.enable_tpu = False; r.enable_internet = False
r.machine_shape = "NvidiaL4"
r.model_data_sources = MODELS
r.dataset_data_sources = DATASETS
r.kernel_data_sources = []
r.competition_data_sources = ["arc-prize-2026-arc-agi-2"]
r.docker_image = DOCKER
r.docker_image_pinning_type = "original"
r.kernel_execution_type = KernelExecutionType.SAVE_AND_RUN_ALL if COMMIT else KernelExecutionType.QUICK_SAVE
with KaggleClient() as cl:
    resp = cl.kernels.kernels_api_client.save_kernel(r)
print("saved" + (" + commit run queued:" if COMMIT else " (quick save):"), r.slug, "version", getattr(resp, "version_number", None), "url", getattr(resp, "url", None),
      "error", getattr(resp, "error", None))
