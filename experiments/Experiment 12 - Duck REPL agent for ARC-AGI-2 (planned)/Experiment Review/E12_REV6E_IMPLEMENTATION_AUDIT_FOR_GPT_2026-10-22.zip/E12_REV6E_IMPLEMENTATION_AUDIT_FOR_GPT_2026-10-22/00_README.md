# E12 Duck agent, rev 6e: implementation audit before the next GPU run (2026-10-22)

**Project:** Kaggle ARC Prize 2026, ARC-AGI-2.
- **Model and stack:** Qwen3.8-27B, RedHat INT4 (W4A16 g128) + BF16 DFlash2 drafter, SGLang 0.5.21, TP 4 on 4×L4.
- **Agent:** Duck REPL (vendored, unchanged) + our ARC-2 adapter `duck_arc2/arc2_duck.py`.
- **Hidden run:** 240 tasks in one 12 h Kaggle session.

**Where this bundle stands:**
- **Last bundle:** you reviewed the rev 6d G4B GPU results (`docs/previous_bundle_README_rev6d_G4B_results.md`, with the same run outputs in `runs/`). Your two audits produced fix items G4-1..G4-18, and the user accepted all of them.
- **This bundle:** the code that implements them (rev 6e), plus a self-audit that found and fixed two more defects. **Nothing here has run on a GPU yet.**

## 1. What we ask you to do

Please do all of this, in this order. Recompute every number from the files here; do not trust our summaries.

1. **Implementation audit, item by item.** For every row of the table in section 3 (G4-1..G4-18 and SA-1/SA-2), read the code and the test, then answer:
   - implemented as specified / partly / wrong / missing;
   - for a bug: the file and line, a concrete input that triggers it, and the fix;
   - whether the CPU test really proves the item, or only that the code runs.
2. **Find what we missed.** Look for:
   - regressions against rev 6d and rev 5 (harvest, host verifier, deadline clamp, pass@2, context preservation, sandbox security);
   - races in the scheduler (`solve_all_r6`, `BranchSession`);
   - test fixtures that assume behaviour the real SGLang server does not have. That is how the rev 6d probe bug got through: the fake server said queue = 0.
3. **GO / NO-GO per notebook** (section 2), with the blocking items for each NO-GO.
4. **Answer the open questions in section 6.**

**Output format we would like:**
- one table per item 1 (`ID | verdict | evidence (file:line) | bug + trigger | fix`);
- then the missed problems, ranked by impact on the hidden-run score;
- then the GO / NO-GO;
- then the answers to section 6.
- Mark every statement as **measured** (file / field / line) or **inferred**.

**Constraints for any proposal (the user's rules):**
- **Keep the setup:** Qwen3.8-27B on the same stack. No fine-tuning, no API models, no other model.
- **Full coverage is a hard goal:** every one of the 240 hidden tasks gets a real attempt inside 12 h. Hidden tasks are about as hard as the public eval set.
- **Token budget:** thinking per task must not be cut below the current settings without the user's explicit approval. The user's floor is 60,000 thinking tokens for single-pass pipelines. Approved for rev 6:
  - per-request caps 12,288 / 24,576 / 32,768 (and 24,576 for branch 1's first request);
  - the 28k soft first exposure;
  - the 12,288 minimum stage-2 chunk;
  - gate 4b.

  Say clearly if a proposal needs a new approval.
- **Ground truth:** never used at runtime (analysis only).
- **Bundling:** changes go into one evidence-based release per GPU run, not one-change ablations.
- **No impossible claims:** do not say a score target (LB 60+) is impossible or needs fine-tuning. The user knows teams reach 70–88 with Qwen3.8 + an optimized Duck harness and full coverage. Focus on how.
- **The KV rule is the user's decision:** "no new task or branch while KV usage ≥ 95 %". Review its implementation, do not replace it.

## 2. Notebooks

| Notebook | sha256 | Purpose | Status |
|---|---|---|---|
| `notebooks/Q27-XHIGH-E12_DUCK_REPL_SGLANG_EVAL12R6G4B_REBUILD.ipynb` | `94a54754815db4658ffb34996fb607c4bd41293ff1f85b7117ffb47d9bd943e2` | **Gate 4b**: the 12 EVAL12R5 tasks (19 inputs) at the hidden run's time per task (12 × (42,720 − solve start) / 240 ≈ 2,063 s). Same Kaggle slug as the rev 6d run, a new version | built, not run |
| `notebooks/Q27-XHIGH-E12_DUCK_REPL_SGLANG_EVAL12R6.ipynb` | `c036215efaf92c1edf1e099f627e4f5df05b32f89e4678cc29b9be81d743e9f1` | The same 12 tasks without the gate-4b limit (12 workers) | built, not run |
| `notebooks/Q27-XHIGH-E12_DUCK_REPL_SGLANG_PARITYR6.ipynb` | `bc9e2bc2f7d4d18af014ddccf8e277515448c3effec0b66b9432b827c86bd49c` | Serving diagnostic (DFlash vs target-only); no solving. Your earlier PARITY fixes 6-8 were not taken (user) | built, optional |
| `notebooks/reference_rev6d_kaggle_run/…EVAL12R6G4B.ipynb` | `1bdadd82…` | The rev 6d notebook that ran on Kaggle (results in `runs/rev6d_EVAL12R6G4B/`). Reference only | ran 2026-10-21: 2/19 |

**Packaging (measured):**
- All three new notebooks embed `duck_arc2/arc2_duck.py` byte-identical.
- Every rev 6e behaviour is behind `E12_ARC2_REV6=1` plus the `E12_R6_*` knobs printed in CELL 3 (`source/build_e12_duck.py`, dict `E12_R6`).
- **Every notebook is dual-mode:**
  - a Kaggle **rerun** solves all hidden tasks and writes `submission.json` (the cache diagnostic never runs there);
  - a **commit** run solves the profile's eval subset and scores it.

## 3. What changed since rev 6d (please audit each row)

Diffs: `source/diffs/arc2_duck.rev6d_to_final.diff`, `source/diffs/build_e12_duck.rev6d_to_final.diff`. Only the self-audit part: `*.rev6e_to_final_selfaudit.diff`. Full old files: `source/history/`.

| ID | Problem in G4B (measured, `runs/rev6d_EVAL12R6G4B/`) | What we built | CPU test |
|---|---|---|---|
| **G4-1** | Capacity probe stepped 12 → 10 → 8 → 6 workers on queue = 1 at KV 13–31 % (SGLang's steady state with 12 in flight); decode 371 → 321 tok/s | **The step-down is removed.** Workers stay fixed (12). One rule: **no new task or branch is admitted while `sglang:full_token_usage` ≥ `E12_R6_KV_ADMIT` 0.95**; running requests are never touched. The probe polls every 5 s and takes one synchronous sample before the first admission. A missing / NaN / out-of-range / stale (> 30 s) sample admits, with a counter and one warning per outage. With nothing running, a hold is released (no deadlock). Builder probe: exact metric names (`sglang:full_token_usage`, `sglang:mamba_usage`, `num_running_reqs`, `num_queue_reqs`), max over TP ranks, never `sglang:token_usage` (= max of pools) | smoke: steady state → no hold, 12 concurrent; 0.97 → hold; < 0.95 → release; missing / invalid / exception / stale → fail-open; deadline while held. `tests/kv_gate_replay.py` on 7 recorded server logs: holds only in E12 EVAL30 rev 1 (the real KV-thrash run, 18.2 min). Fake server now reports **queue 1 always**. 240-task sim (section 5) |
| **G4-2** | All 4 branch-1 first requests (12,288 cap) were cut before any tool call (first call at 12.4–18.0k) | Branch 1 (any grids view) first cap `E12_R6_CAP_FIRST_B1` 24,576; branch 0 keeps 12,288 | smoke; harness: no b1 request at 12,288 |
| **G4-3** + **SA-2** | Print guard leaked `print(r, row)` rows | `_GRID_ROW_RE` covers: bracketed rows with an index (`N [..]`, `N: [..]`, `row N: [..]`, `r N: [..]`, tuples); **index + joined digits** (`0 0000000000…`, SA-2); `N: 0 0 5 2`; case-insensitive; linear time. `show()` rows (`r03 | …`) are exempt | see SA-2 below |
| **G4-4** | `show()` refused whole grids (150-cell limit), so the model printed raw rows | `show(g)` prints a whole grid up to `E12_R6_SHOW_MAX_CELLS` 900 cells with row/column indices; per python call at most `E12_R6_SHOW_CALL_CELLS` 1,000 shown cells, then it says which `show(g, r0=…)` to call next (paging). A 30×30 show = 2,033 Qwen tokens (tool cap 3,072) | smoke: whole 30×30; paging; > 900 refused; crop keeps indices; a full call < 3,072 tokens (real Qwen tokenizer) |
| **G4-5** | 14/16 branches called `arc_overview()` first, which repeated the system-prompt facts | `arc_overview()` prints only the facts lines the bounded block left out (with their TRAIN/TEST header), else a one-line pointer | smoke |
| **G4-6** | 7/12 branch-0 runs never defined a `transform` | One "provisional transform" resume (your verbatim text, `R6_TEXT["provisional"]`) when a branch has generated ≥ `E12_R6_NUDGE_TOKENS` 27,000 tokens with no solution-named function defined and no `check()`. **Threshold from a replay:** the 2 solved branches defined `transform` at 18,383 / 26,228 tokens; the 10 that never did all passed 29k. Precedence: cut > length > timeout > provisional > verified / partial | smoke: not below 27k; once at 27.5k; suppressed by a transform; a cut keeps precedence |
| **G4-7 / G4-13** | `accepted_candidates` counted check + submit of one program twice; the first-check median was censored | Report: `accepted_events`, `unique_verified_programs` (key task, branch, name, outputs), `distinct_test_predictions` (task, outputs), per-task programs; overfit flags on unique programs; first check: observed median, observed b0 median, checked branches, the censored proxy kept | harness |
| **G4-8** + **SA-1** | Cache hit 75.0 % vs 84.3 / 88.7 % in rev 5; 20/180 requests with 0 cached | `_e12_cache_diag` (CELL 6, commit mode only, ≤ 240 s, before solving): about 9k-token prompt A warm → exact replay → 2 divergent suffixes → 12 distinct long prompts at once (churn) → replay + divergent suffix. Records cached / prompt / time / KV / mamba per step → `report.rev6.cache_diag` | harness: every step, warm 0 cached, replay > 0 |
| G4-9 | — | Not built (by design): no radix-cache / mamba-strategy / kernel change until G4-8 / G4-15 show the cause | — |
| **G4-10** | Long verbal reasoning before any executable hypothesis | Prompt: the first call gathers evidence the facts lack; an executable hypothesis comes before a complete verbal explanation; after several inspections, test the simplest hypothesis; no hand reconstruction | smoke (text) |
| **G4-11** | Branch 1 (raw grids view) produced 0 candidates in 123,560 tokens | Branch-1 view `indexed` (`E12_R6_B1_VIEW`): facts + every grid in the `show()` layout. Bounded by `E12_R6_B1_GRID_MAX_TOKENS` 12,000: grids over 400 cells become a `show(train[i]['input'])` pointer, largest first, and every grid is still listed | smoke; harness (facts + indexed views) |
| **G4-12** | Stage 2 started a fresh branch 1 while branch 0 had partial progress (247ef758_b0, 1/3 pairs) | A class-0 task (branch 0 has partial progress, no verified candidate) gets no new branch 1 while each stage-2 round of branch 0 improves its best single-function progress; after a no-gain round (`BranchSession.stalled`) branch 1 is queued | smoke: improving b0 → never b1 (deterministic); stalled b0 → b1 |
| **G4-14** | Metrics did not show where branches stall | Per branch `first_transform_tokens`. Report: observed / censored medians, branches with a transform within 20k, best single-function pairs histogram, b1 distinct verified per 100k tokens, nudges | smoke; harness |
| **G4-15** | The cause of the cache misses could not be separated (prompt changed vs cache state lost) | Per request (`branch_result.json` → `requests`, ≤ 600): message-level prefix match vs the branch's previous request, trimmed flag, idle seconds, prompt / cached (null = 0, flagged) / completion / finish, server KV / mamba / running / queue at the start. Report: zero-hit later requests split by intact prefix / trimmed / idle / mamba. Concurrency telemetry from the server log: decode tok/s by running count, split by "a prefill batch just before". Scheduler gauges every 30 s | smoke; harness |
| **G4-16** | Helpers underused (`check_many` 0, `object_diff` 1) | Prompt: usage examples (`components(g, ignore=modal_color(g))`, `object_diff`, `diff_summary`, `check_many` for two hypotheses) | smoke (text) |
| **G4-17** | Every computed fair share (3.8–7.5k) was below the 24,576 minimum chunk, so fair share did nothing | Minimum stage-2 chunk 12,288 (`E12_R6_MIN_CHUNK`) | smoke; harness; 240-task sim (section 5: still inert at 240 tasks) |
| **G4-18** | Progress could not tell "the same transform improved" from "a new hypothesis" | Events `progress_same_improved` vs `progress_new_hypothesis`; each run records best before / after and `improved`; report: stage-2 runs improved | smoke |
| **SA-1** (self-audit) | **G4-8 ate the G4B window:** CELL 6 fixed the gate-4b end **before** the preflight and the cache diagnostic (≤ 240 s, about 12 % of the 2,063 s window). The hidden rerun never runs the diagnostic, so the screening run would have been biased | For gate 4b only, the end is shifted by the time the preflight and diagnostic took, still bounded by `HARD_STOP`; recorded as `g4b.shift_sec` / `g4b.window_start_sec`. The per-task compute is unchanged | harness g4b: new check (full window left at the solve start) |
| **SA-2** (self-audit) | **G4-3 was incomplete:** in G4B, **646 grid rows in 8 branches** reached the model (our earlier "173 in 3" counted only the bracket form). The rest were `print(r, ''.join(map(str, row)))` rows. Rev 5 also leaked `r 0: [..]` | Two more alternatives in `_GRID_ROW_RE`: an index + ≥ 8 joined digits, and `N: 0 0 5 2` (colon required). `|` is never a separator | Scan of all recorded transcripts with the real guard semantics (`tests/self_audit/guard_leak_compare.py`): G4B rows reaching the model, rev 6d 646 → rev 6e 480 → **now 1**. Over our 149 transcripts 1,564 → 438; the rest are ≤ 7-wide joined rows, kept on purpose (an 8-digit floor avoids hiding counts). This bundle holds 64 of those transcripts (the 4 runs in `runs/`); on those 64 the script gives 865 → 210 |

**Kept unchanged:**
- rev 5 security: the sandbox and the host verifier;
- candidate harvest and pass@2 selection;
- the stage-1 queue (every task's branch 0 before any stage-2 item);
- the 28k soft first exposure;
- the deadline clamp on every request and verification;
- the context preservation.

## 4. Tests (run 2026-10-22 on the final files; Windows, Python 3.14, `tokenizers` 0.23.2, `transformers` 5.20.2)

Recorded outputs are in `tests/recorded_outputs/`.

```
cd tests
python smoke_adapter.py      # 41/41  (rev 5 and 6 off: legacy behaviour)
python smoke_rev5.py         # 56/56
python smoke_rev6.py         # 143/143 (rev 6d had 104; G4 items + 4 SA-2 tests)
python regex_check.py        # ALL OK (classification + linear time on adversarial lines)
python facts_size.py         # 120 eval tasks: bounded facts p50 699 / p90 779 / max 798 tokens; deterministic
python kv_gate_replay.py     # 7/7 recorded server logs: holds only in E12 EVAL30 rev 1
python replay_rev6.py ../runs/rev5_EVAL6R5_xhigh/duck ../data/eval_challenges_12.json ../data/eval_solutions_12.json out.jsonl
python harness_e12_rev4_nb.py ../notebooks/Q27-XHIGH-E12_DUCK_REPL_SGLANG_EVAL12R6G4B_REBUILD.ipynb g4b   # 53/53
python harness_e12_rev4_nb.py ../notebooks/Q27-XHIGH-E12_DUCK_REPL_SGLANG_EVAL12R6.ipynb r6               # 51/51
python harness_e12_rev4_nb.py ../notebooks/Q27-XHIGH-E12_DUCK_REPL_SGLANG_EVAL12R6.ipynb rerun            # 22/22
python harness_e12_rev4_nb.py ../notebooks/Q27-XHIGH-E12_DUCK_REPL_SGLANG_EVAL12R6.ipynb launchfail       # 6/6
python harness_e12_rev4_nb.py ../notebooks/Q27-XHIGH-E12_DUCK_REPL_SGLANG_PARITYR6.ipynb parity           # 19/19
cd self_audit
python guard_leak_compare.py # SA-2 on the 64 bundled transcripts
python sim240.py 12288 400 1 # section 5 (about 100 s per run)
```

**Replay corpus** (`replay_rev6f_*`): every recorded tool call of the rev 4 / rev 5 runs through the final agent.
- **Measured:** rev 4 EVAL6 **7/8**, rev 5 xhigh **5/8**, rev 5 low **10/19**. Hits and kept candidates per task are identical to rev 6e.
- **Only change:** grid rows suppressed in the low run went 1,051 → 1,161 (SA-2).

**Platform notes:**
- **Linux:** the Windows-only shims in the harness and the smoke tests are skipped automatically.
- **Dependencies:** the harness needs `transformers` (the notebook's tokenizer cell), and `smoke_rev5.py` / `facts_size.py` need `tokenizers`.
- **What the tests do not cover:** the real model and server. The fake server is scripted; since rev 6e its `/metrics` copies real values (queue 1, mamba 0.62), and it omits `prompt_tokens_details` at 0 cached, like SGLang 0.5.21 (`usage_processor.py:13-15`).

## 5. 240-task capacity simulation (`tests/self_audit/sim240.py`, output `recorded_outputs/sim240_out.txt`)

**Setup:** the real `solve_all_r6` + `BranchSession` run with virtual time (arc2_duck's clock and condition waits scaled 400×) and a fake agent.
- **Measured inputs:**
  - 371 tok/s aggregate at 12 running (321 at 6);
  - about 3.2k tokens per request;
  - a 41,257 s solve window;
  - 12 workers, 28k first exposure, 100k soft cap per branch, `min_admit_sec` 240.
- **Assumed:**
  - which branches solve and when (35 % of tasks by branch 0 at 15–90k tokens, 10 % only by branch 1);
  - partial progress;
  - the context → KV model.
- **What the numbers mean:** coverage and allocation are scheduler facts; solve counts only show a direction.

| | min chunk 12,288 (rev 6e) | 24,576 (rev 6d) |
|---|---|---|
| Tasks exposed / stage-1 starts left | 240 / 0 (both seeds) | 240 / 0 |
| Last branch-0 start | 19,757 / 20,018 s of 41,257 | 19,728 / 20,018 s |
| Branch 1 started | 177 / 181 | 103 / 103 |
| Tokens per task p10 / p50 / p90 | 49.6k / 62.8k / 72.1k | 30.5k / 62.2k / 91.2k |
| Tasks with < 60k tokens in total | 89 / 90 | 101 / 110 |
| Stage-2 runs | 433 / 442 | 276 / 273 |
| Queue items never served | 389 / 390 | 383 / 382 |
| Solved under the assumed model | 30 / 35 | 37 / 36 |
| KV holds | 0 | 0 |

**Findings:**
- **Fair share is inert at 240 tasks:** in the last 200 stage-2 runs the computed share was below the minimum chunk every time (p50 about 4k). The minimum chunk is therefore the real allocation rule.
- **Budget:** about 15M tokens / 240 = 63k per task; about 385 stage-2 items are never served.
- **Not modelled:** the re-prefill cost of the extra resumes at 12,288 (about +160).

## 6. Open questions

1. **Allocation at 240 tasks** (section 5).
   - Which rule should replace the inert fair share: a 12,288 or 24,576 minimum chunk, the remaining candidates, or a priority by progress?
   - What measurement in the next G4B run would decide it?
2. **SA-2 residual:** should the guard also hide narrow joined rows (≤ 7 digits, e.g. `r2: 388883`), at the risk of hiding counts?
3. **G4-6 threshold** (27,000, from 12 branches):
   - is a single nudge enough?
   - should it depend on the view (branch 1 starts later)?
4. **G4-15 granularity:** the prefix match is per message (JSON), not per token. Is that enough to separate "the prompt changed" from "the cache state was lost"? If not, what should we log?
5. **G4-18 proxy:** "same transform" means the same function name. Is a source-similarity rule worth it, or would it mislead the scheduler?
6. **Anything in our code, tests or numbers that is wrong** and not listed.

## 7. File map

| Path | What |
|---|---|
| `duck_arc2/arc2_duck.py` | **The adapter, final rev 6e + self-audit**, embedded unchanged in all three notebooks |
| `duck_arc2/vendor/` | Vendored Duck (`inference/…`), unchanged since rev 4 |
| `source/build_e12_duck.py` | Notebook builder (CELL 3 knobs, CELL 6 probe / cache diagnostic / scheduler wiring, CELL 7 report) |
| `source/push_e12_duck.py` | Push script (QUICK_SAVE or commit; `--eval12r6g4b` → `_REBUILD`) — not run |
| `source/diffs/`, `source/history/` | rev 6d → final and rev 6e → final diffs; full rev 6d and pre-audit rev 6e files. `build_e12_duck_rev6e_before_selfaudit.py` is reconstructed (the final file without the SA-1 block) |
| `notebooks/` | The 3 rev 6e notebooks + the rev 6d reference |
| `runs/` | Rev 6d G4B outputs (report, transcripts with full thinking, server log), rev 5 xhigh / low, rev 4 EVAL6, 3 server logs of 12-stream runs |
| `data/` | The 12 tasks and their solutions (analysis only) |
| `analysis/` | The G4B analysis scripts and outputs (from the previous bundle) |
| `docs/` | Running fix list (every audit and decision; "Rev 6e" and "Rev 6e self-audit" at the end), G4B analysis, rev 5 analysis, weakness analysis, verbatim GPT prompt drafts, problem → fix map (Bengali), the previous bundle's README |
| `tests/` | Unit checks, KV-gate replay, notebook harness, fake SGLang server, fixtures, `self_audit/`, `recorded_outputs/` |
