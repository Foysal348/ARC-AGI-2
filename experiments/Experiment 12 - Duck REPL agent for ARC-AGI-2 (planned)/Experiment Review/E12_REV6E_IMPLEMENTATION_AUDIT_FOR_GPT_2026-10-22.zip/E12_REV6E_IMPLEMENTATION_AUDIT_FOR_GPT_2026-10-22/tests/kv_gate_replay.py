"""G4-1 CPU gate (fix list): replay the full-attention KV usage of recorded SGLang logs through the rev 6e admission rule
(arc2_duck._finite01 + the 0.95 limit), sampled every 5 s like the probe. Expected: holds only in E12 EVAL30 rev 1 (the
real KV-thrash run); none in the healthy runs (G4B, E11-05, E11-06, rev 4, rev 5 x2).
Usage: python kv_gate_replay.py <dir with the runs/ folder of the review bundle>"""
import datetime as dt
import os
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "duck_arc2"))
os.environ.setdefault("E12_ARC2_REV6", "1")
import arc2_duck as A  # noqa: E402

root = Path(sys.argv[1] if len(sys.argv) > 1 else Path(__file__).resolve().parent.parent)
LIMIT, POLL = 0.95, 5.0
TS = re.compile(r"^\[(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d)")
KV = re.compile(r"full token usage: ([\d.]+)")
logs = sorted(root.glob("runs/*/sglang_server_try0.log")) + sorted(root.glob("runs/server_logs_12_streams/*.log"))
ok, rows = True, []
for f in logs:
    series = []
    for ln in open(f, encoding="utf-8", errors="replace"):
        if "TP0]" not in ln:
            continue
        m, k = TS.match(ln), KV.search(ln)
        if m and k:
            series.append((dt.datetime.strptime(m.group(1), "%Y-%m-%d %H:%M:%S").timestamp(), float(k.group(1))))
    if not series:
        continue
    t, i, last, samples, holds = series[0][0], 0, None, 0, 0
    while t <= series[-1][0]:            # the probe reads the latest value every 5 s
        while i < len(series) and series[i][0] <= t:
            last = series[i][1]
            i += 1
        v = A._finite01(last)
        samples += 1
        holds += int(v is not None and v >= LIMIT)
        t += POLL
    name = f.relative_to(root).as_posix()
    expect_hold = "E12_EVAL30_rev1" in name
    good = (holds > 0) == expect_hold
    ok &= good
    rows.append((name, samples, holds, round(holds * POLL / 60, 1), max(v for _, v in series), good))
for r in rows:
    print(("PASS" if r[5] else "FAIL") + f" {r[0]}: {r[1]} samples, {r[2]} held ({r[3]} min), KV max {r[4]:.2f}")
print("ALL OK" if ok and len(rows) == 7 else f"SOME FAILED ({len(rows)} logs)")
sys.exit(0 if ok and len(rows) == 7 else 1)
