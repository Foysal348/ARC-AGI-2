"""Fake SGLang 0.5.21 server for the E12 notebook harness (CPU, no model). Launched by the REAL engine cell with the REAL
flags. Serves what the E11 engine cell needs (launch log with the capacity lines, /health, /metrics, /generate for the
two smoke requests, /abort_request) plus what Duck needs (/v1/models, /v1/chat/completions, non-stream, OpenAI tool
calls, reasoning_content, usage with prompt_tokens_details.cached_tokens).
Scripted replies only (our code): role 0 of a task submits a lookup-table transform built from the known solutions
(exercises the host verification + scoring path); role 1 submits identity, then inspects until the deadline.
FAKE_SCEN: launchfail (every launch fails)."""
import json
import os
import re
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "fixtures"))
import e12_fixtures as B  # noqa: E402  (self-contained fixtures next to this file)

argv = sys.argv[1:]
SCEN = os.environ.get("FAKE_SCEN", "")
if SCEN == "g4b":     # gate 4b notebook: the rev 6 scripted program
    SCEN = "r6"
PORT = int(argv[argv.index("--port") + 1]) if "--port" in argv else 30000
K = int(argv[argv.index("--max-mamba-cache-size") + 1]) if "--max-mamba-cache-size" in argv else 56
print("[2026-10-19 10:00:00] fake sglang server args:", " ".join(argv), flush=True)
REQUIRED = [["--reasoning-parser", "qwen3"], ["--tool-call-parser", "qwen3_coder"], ["--schedule-policy", "lpm"],
            ["--enable-cache-report"], ["--default-chat-template-kwargs", json.dumps({"preserve_thinking": True})]]
for req in REQUIRED:
    i = argv.index(req[0]) if req[0] in argv else -1
    if i < 0 or (len(req) == 2 and argv[i + 1] != req[1]):
        print(f"ValueError: E12 harness: missing Duck serving flag {req}", flush=True)
        sys.exit(1)
if SCEN == "launchfail":
    print("ValueError: simulated permanent configuration error", flush=True)
    sys.exit(1)
for tp in range(4):
    print(f"[2026-10-19 10:00:02 TP{tp}] Load weight end. elapsed=2.4 s, type=Qwen3_5ForConditionalGeneration, quant=compressed-tensors, avail mem=17.10 GB, mem usage=4.62 GB.", flush=True)
    print(f"[2026-10-19 10:00:03 TP{tp}] Mamba Cache is allocated. max_mamba_cache_size: {K}, conv_state size: 0.04GB, ssm_state size: 1.00GB intermediate_ssm_state_cache size: 1.83GB", flush=True)
    print(f"[2026-10-19 10:00:03 TP{tp}] KV Cache is allocated. dtype: torch.float8_e4m3fn, #tokens: 881336, K size: 3.36 GB, V size: 3.36 GB", flush=True)
print("[2026-10-19 10:00:04 TP0] Capture target verify CUDA graph begin. backend=full, num_tokens_per_req=8, bs=[1, 2, 3, 4, 5, 6, 7, 8, 10, 12], avail mem=5.27 GB", flush=True)
print("[2026-10-19 10:00:05 TP0] Capture draft verify CUDA graph end. elapsed=1.0 s, mem usage=0.38 GB, avail mem=2.22 GB.", flush=True)

CH, SOL, _, _ = B.load()
LOCK = threading.Lock()
LOG = {"chat": [], "generate": []}
CONV_STEP, CONV_META, TASK_ROLES, NEW_CONVS = {}, {}, {}, []
PREFIX, PREFIX_CUT = {}, {}
INFLIGHT = [0, 0]
ABORT = set()
T_READY = time.time() + 0.5
CONV_RE = re.compile(r"CONV=(\w+)")


def rows(g):
    return "\n".join(" ".join(str(v) for v in r) for r in g)


def _counts(g):
    d = {}
    for r in g:
        for v in r:
            d[v] = d.get(v, 0) + 1
    return dict(sorted(d.items()))


def _r6_sig(t):   # rev 6 facts view: no grid rows in the prompt; the facts line of the first pairs identifies the task
    out = []
    for p in t["train"][:2]:
        for tag, g in (("in ", p["input"]), ("out", p["output"])):
            out.append(f"  {tag} {len(g)}x{len(g[0])} colors {_counts(g)}")
    return out


def task_of(system_text):
    if "Training pair 1 input:\n" in system_text:
        head = system_text.split("Training pair 1 input:\n", 1)[-1].split("\nTraining pair 1 output:", 1)[0]
        for tid, t in CH.items():
            if rows(t["train"][0]["input"]) == head:
                return tid
    if "Training pair 0 input:\n" in system_text:          # rev 6 grids view (0-based)
        head = system_text.split("Training pair 0 input:\n", 1)[-1].split("\nTraining pair 0 output:", 1)[0]
        for tid, t in CH.items():
            if rows(t["train"][0]["input"]) == head:
                return tid
    if "ARC TASK FACTS" in system_text:
        hits = [tid for tid, t in CH.items() if all(s in system_text for s in _r6_sig(t))]
        if len(hits) == 1:
            return hits[0]
        # rev 6d compact facts (levels 4-5): "TRAIN i: in HxW {counts} -> out HxW {counts}..." / "TRAIN i: HxW -> HxW"
        hits = [tid for tid, t in CH.items() if all(
            f"TRAIN {i}: in {len(p['input'])}x{len(p['input'][0])} {_counts(p['input'])} -> out {len(p['output'])}x"
            f"{len(p['output'][0])} {_counts(p['output'])}" in system_text for i, p in enumerate(t["train"][:2]))]
        if len(hits) == 1:
            return hits[0]
    return None


def lookup_code(tid):
    t = CH[tid]
    table = {json.dumps(p["input"]): p["output"] for p in t["train"]}
    for qi, q in enumerate(t["test"]):
        table[json.dumps(q["input"])] = SOL[tid][qi]
    return ("def transform(g):\n    import json\n    table = " + json.dumps(table) + "\n"
            "    return table.get(json.dumps(g), g)\ncheck(transform)")


INSPECT = "print(len(train), len(test_inputs), [(len(p['input']), len(p['input'][0])) for p in train])"
IDENT = "def transform(g):\n    return [list(r) for r in g]\ncheck(transform)\nsubmit(transform)"


def lookup_train_only(tid):     # train-exact, test = identity (a wrong candidate for rev 5 selection)
    t = CH[tid]
    table = {json.dumps(p["input"]): p["output"] for p in t["train"]}
    return ("def transform2(g):\n    import json\n    table = " + json.dumps(table) + "\n"
            "    return table.get(json.dumps(g), [list(r) for r in g])\ncheck(transform2)")


CUT_CODE = "print('CUT_CODE_RAN')"


NOCALL = "@@NOCALL@@"      # r6: a reply cut at the output limit with reasoning only (no tool call)


def lookup_r6(tid, name="transform"):     # rev 6: a lookup that also calls a trusted helper; NO check() (auto-check)
    t = CH[tid]
    table = {json.dumps(p["input"]): p["output"] for p in t["train"]}
    for qi, q in enumerate(t["test"]):
        table[json.dumps(q["input"])] = SOL[tid][qi]
    return (f"def {name}(g):\n    import json\n    table = " + json.dumps(table) + "\n"
            "    return table.get(json.dumps(g), flip_h(flip_h(g)))")


def lookup_train_only_r6(tid):     # rev 6: train-exact / test = identity, named *_alt, NO check() (auto-check)
    t = CH[tid]
    table = {json.dumps(p["input"]): p["output"] for p in t["train"]}
    return ("def transform_alt(g):\n    import json\n    table = " + json.dumps(table) + "\n"
            "    return table.get(json.dumps(g), [list(r) for r in g])")


INSPECT_R6 = "print(grid_shape(train[0]['input']), len(components(train[0]['input'])))\ninspect_pair(0)"


def program(tid, role):
    if SCEN == "r6":   # rev 6: role 0 (branch 0, facts view) is cut once with no call, inspects with the trusted helpers,
        # defines a right transform without check(); role 1 (branch 1, grids view) is cut inside a tool call (must not
        # run), then defines a train-exact / test-wrong transform_alt without check(). Neither submits.
        return ([NOCALL, INSPECT_R6, lookup_r6(tid), INSPECT_R6] if role == 0
                else [CUT_CODE, lookup_train_only_r6(tid), INSPECT_R6])
    if SCEN == "r5":   # rev 5: role 0 checks the right function but never submits; role 1 is first cut at the output
        # limit with a tool call (must not run), then checks a train-exact / test-wrong function, never submits
        return [INSPECT, lookup_code(tid), INSPECT] if role == 0 else [CUT_CODE, lookup_train_only(tid), INSPECT]
    if role == 0:
        return [INSPECT, lookup_code(tid), "submit(transform)"]
    return [IDENT, INSPECT]


def _usage(prompt, completion, cached):
    u = {"prompt_tokens": prompt, "completion_tokens": completion, "total_tokens": prompt + completion}
    if cached:          # SGLang 0.5.21 sends prompt_tokens_details only when something was cached
        u["prompt_tokens_details"] = {"cached_tokens": cached}
    return u


DIAG_SEEN = set()


def chat_reply(body):
    msgs = body.get("messages") or []
    last = str(msgs[-1].get("content", "")) if msgs else ""
    first = str(msgs[0].get("content", "")) if msgs else ""
    if not body.get("tools") and first.startswith("E12-CACHE-DIAG"):     # rev 6e G4-8 cache diagnostic
        prompt = max(1, int(len(json.dumps(msgs)) / 3.2))
        with LOCK:
            seen = first in DIAG_SEEN
            DIAG_SEEN.add(first)
            LOG.setdefault("cache_diag", []).append([first[:30], last[:30], body.get("max_tokens")])
        return {"id": "chatcmpl-diag", "object": "chat.completion", "model": body.get("model"),
                "choices": [{"index": 0, "message": {"role": "assistant", "content": "ok"}, "finish_reason": "length"}],
                "usage": _usage(prompt, 1, int(prompt * 0.9) if seen else 0)}
    if not body.get("tools") and "Reply with exactly this code and nothing else: " in last:   # rev 6 isolation preflight
        mark = last.split("Reply with exactly this code and nothing else: ", 1)[1].strip()
        with LOCK:
            LOG.setdefault("preflight", []).append(mark)
        return {"id": f"chatcmpl-pre-{mark}", "object": "chat.completion", "model": body.get("model"),
                "choices": [{"index": 0, "message": {"role": "assistant", "content": mark}, "finish_reason": "stop"}],
                "usage": _usage(20, 8, 0)}
    tid = task_of(str(msgs[0].get("content", ""))) if msgs else None
    if SCEN == "parity" and body.get("tools"):   # R6-X1 probes: deterministic per (task, thinking); target-only differs on one task
        spec = "--speculative-algorithm" in argv
        think = (body.get("chat_template_kwargs") or {}).get("enable_thinking", True)
        rs = f"PARITY {tid} thinking={think}" + ("" if spec or tid != "136b0064" else " (target-only path differs)")
        with LOCK:
            LOG.setdefault("parity", []).append([tid, think, spec])
        return {"id": f"chatcmpl-par-{tid}", "object": "chat.completion", "model": body.get("model"),
                "choices": [{"index": 0, "finish_reason": "tool_calls",
                             "message": {"role": "assistant", "content": "", "reasoning_content": rs,
                                         "tool_calls": [{"id": "call_par", "type": "function",
                                                         "function": {"name": "python", "arguments": json.dumps({"code": INSPECT_R6})}}]}}],
                "usage": _usage(3000, 40, 0)}
    conv = None
    for m in msgs:
        if m.get("role") == "assistant":
            f = CONV_RE.search(str(m.get("reasoning_content") or ""))
            if f:
                conv = f.group(1)
    with LOCK:
        if conv is None:
            role = TASK_ROLES.get(tid, 0)
            TASK_ROLES[tid] = role + 1
            conv = f"{tid}r{role}"
            CONV_META[conv] = (tid, role)
            CONV_STEP[conv] = 0
            NEW_CONVS.append([tid, role, time.time()])
        tid, role = CONV_META[conv]
        i = CONV_STEP[conv]
        CONV_STEP[conv] = i + 1
    if SCEN == "r6":   # R6-D2 prefix invariant: request n+1 starts with request n's messages + its reply (unless trimmed)
        def _k(m):
            return [m.get("role"), m.get("content") or "", m.get("reasoning_content") or "",
                    [c.get("id") for c in (m.get("tool_calls") or [])]]
        with LOCK:
            pf = LOG.setdefault("r6_prefix", {"ok": 0, "trimmed": 0, "after_cut": 0, "break": 0, "sys_changed": 0,
                                              "examples": []})
            prev = PREFIX.get(conv)
            if prev is not None:
                cur = [_k(m) for m in msgs]
                if cur[0] != prev[0]:
                    pf["sys_changed"] += 1
                if cur[:len(prev)] == prev:
                    pf["ok"] += 1
                elif any("older messages were removed" in str(m.get("content") or "") for m in msgs):
                    pf["trimmed"] += 1
                elif PREFIX_CUT.get(conv) and cur[:len(prev) - 1] == prev[:-1]:
                    pf["after_cut"] += 1   # the previous reply was cut at the output limit: Duck drops its broken call
                else:
                    pf["break"] += 1
                    if len(pf["examples"]) < 3:
                        pf["examples"].append([conv, len(prev), len(cur)])
    steps = program(tid, role)
    code = steps[min(i, len(steps) - 1)]
    rendered = json.dumps({"messages": msgs, "tools": body.get("tools")})
    prompt = max(1, int(len(rendered) / 3.2))
    cached = int(prompt * 0.9) if i else 0
    msg = {"role": "assistant", "content": "", "reasoning_content": f"CONV={conv} THINK step {i} for {tid} role {role}.",
           "tool_calls": [{"id": f"call_{conv}_{i}", "type": "function",
                           "function": {"name": "python", "arguments": json.dumps({"code": code})}}]}
    fin = "length" if (SCEN in ("r5", "r6") and code == CUT_CODE) else "tool_calls"
    if code == NOCALL:
        msg = {"role": "assistant", "content": "", "reasoning_content": f"CONV={conv} THINK step {i} for {tid} role {role} "
               "(cut at the output limit, no tool call)."}
        fin = "length"
    if SCEN == "r6":
        with LOCK:
            r6 = LOG.setdefault("r6", {"sys_facts": 0, "sys_grids": 0, "sys_r6": 0, "max_tokens": {}, "resume": {},
                                       "task_none": 0, "trimmed": 0})
            sysc = str(msgs[0].get("content", "")) if msgs else ""
            r6["sys_r6"] += "You are a Python coding agent solving an ARC-AGI-2 grid task." in sysc
            r6["sys_grids" if "Training pair 0 input" in sysc else "sys_facts"] += 1   # grids or indexed view (G4-11)
            r6["task_none"] += tid is None
            mt = str(body.get("max_tokens"))
            r6["max_tokens"][mt] = r6["max_tokens"].get(mt, 0) + 1
            u = [m for m in msgs if m.get("role") == "user"]
            if u:
                c = str(u[-1].get("content") or "")
                key = ("cut" if c.startswith("Your previous reply hit the output limit") else
                       "length" if c.startswith("Your previous reply reached this request's output limit") else
                       "verified" if "is host-verified on every training pair" in c else
                       "partial" if c.startswith("Your best function so far") else
                       "notool" if c.startswith("Your previous reply ended without running Python") else
                       "first" if c.startswith("Solve the task in the system prompt") else
                       "rejected" if c.startswith("Your submission `") else
                       "continue" if c.startswith("Continue from your work above") else "other")
                r6["resume"][key] = r6["resume"].get(key, 0) + 1
    with LOCK:
        LOG.setdefault("r5", {"sys_rev5": 0, "sys_old": 0, "cut_off_notes": 0, "cut_code_ran": 0, "resume_r5": 0})
        sysc = str(msgs[0].get("content", "")) if msgs else ""
        LOG["r5"]["sys_rev5" if "keeps it as a candidate answer" in sysc else "sys_old"] += 1
        for m in msgs:
            c = str(m.get("content") or "")
            if m.get("role") == "user" and ("CUT OFF" in c or "reached the output limit" in c):
                LOG["r5"]["cut_off_notes"] += 1
            if m.get("role") == "user" and c.startswith("Nothing has been submitted yet."):
                LOG["r5"]["resume_r5"] += 1
            if m.get("role") == "tool" and "CUT_CODE_RAN" in c:
                LOG["r5"]["cut_code_ran"] += 1
    if SCEN == "r6":
        with LOCK:
            PREFIX[conv] = [_k(m) for m in msgs] + [_k(msg)]
            PREFIX_CUT[conv] = fin == "length"
    return {"id": f"chatcmpl-{conv}-{i}", "object": "chat.completion", "model": body.get("model"),
            "choices": [{"index": 0, "message": msg, "finish_reason": fin}],
            # r5: > 2,048 so every request yields and the resume opener is exercised
            "usage": _usage(prompt, (2100 if SCEN in ("r5", "r6") else 400), cached)}


class H(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):
        pass

    def _send(self, body, code=200, ctype="application/json"):
        b = body.encode() if isinstance(body, str) else body
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(b)))
        self.send_header("Connection", "close")
        self.end_headers()
        self.close_connection = True
        self.wfile.write(b)

    def do_GET(self):
        if self.path == "/health":
            return self._send("" if time.time() >= T_READY else "loading", 200 if time.time() >= T_READY else 503)
        if self.path == "/v1/models":
            return self._send(json.dumps({"object": "list", "data": [{"id": "fake-int4", "object": "model"}]}))
        if self.path == "/metrics":
            with LOCK:
                n = INFLIGHT[0]
            kv = os.environ.get("FAKE_KV", "0.3")
            # rev 6e: SGLang's steady state at 12 in flight is 11 running + 1 queued (G4B log); the KV gate must ignore it
            lines = [f'sglang:num_running_reqs{{model_name="int4"}} {n}', 'sglang:num_queue_reqs{model_name="int4"} 1',
                     'sglang:token_usage{model_name="int4"} 0.62', f'sglang:full_token_usage{{model_name="int4"}} {kv}',
                     'sglang:mamba_usage{model_name="int4"} 0.62',
                     'sglang:gen_throughput{model_name="int4"} 300.0', 'sglang:cache_hit_rate{model_name="int4"} 0.9']
            return self._send("\n".join(lines) + "\n", ctype="text/plain")
        if self.path == "/fake_log":
            with LOCK:
                return self._send(json.dumps(dict(LOG, new_convs=NEW_CONVS, max_inflight=INFLIGHT[1])))
        return self._send("{}", 404)

    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0))
        req = json.loads(self.rfile.read(n) or b"{}")
        if self.path == "/abort_request":
            with LOCK:
                ABORT.add(req.get("rid"))
            return self._send("", 200)
        if self.path == "/v1/chat/completions":
            with LOCK:
                INFLIGHT[0] += 1
                INFLIGHT[1] = max(INFLIGHT[1], INFLIGHT[0])
            try:
                out = chat_reply(req)
            finally:
                with LOCK:
                    INFLIGHT[0] -= 1
            with LOCK:
                LOG["chat"].append({k: req.get(k) for k in ("model", "max_tokens", "temperature", "top_p", "top_k", "stream",
                                                            "chat_template_kwargs", "tool_choice")}
                                   | {"n_messages": len(req.get("messages") or []), "id": out["id"]}
                                   | ({} if req.get("tools") else {"tools": False}))   # rev 6 preflight: no tools
            print(f"[2026-10-19 10:01:00 TP0] Decode batch, #running-req: 1, #full token: 5000, full token usage: 0.01, "
                  f"accept len: 3.50, cuda graph: True, gen throughput (token/s): 300.00, #queue-req: 0", flush=True)
            return self._send(json.dumps(out))
        if self.path != "/generate":
            return self._send("{}", 404)
        rid, sp = req["rid"], req["sampling_params"]
        with LOCK:
            LOG["generate"].append(rid)
        total = 16 if rid == "e11-smoke-a" else int(sp["max_new_tokens"])
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Transfer-Encoding", "chunked")
        self.send_header("Connection", "close")
        self.end_headers()
        self.close_connection = True

        def emit(b):
            self.wfile.write(f"{len(b):x}\r\n".encode() + b + b"\r\n")
            self.wfile.flush()
        sent, fin = 0, None
        while fin is None:
            with LOCK:
                ab = rid in ABORT
            if ab:
                fin, chunk = {"type": "abort"}, []
            else:
                chunk = [11] * min(8, total - sent)
                sent += len(chunk)
                if sent >= total:
                    fin = {"type": "length", "length": total}
            meta = {"id": rid, "finish_reason": fin, "prompt_tokens": 10, "completion_tokens": sent, "cached_tokens": 0}
            emit(b"data: " + json.dumps({"output_ids": chunk, "meta_info": meta}).encode() + b"\n\n")
            if rid == "e11-smoke-b":
                time.sleep(0.01)
        emit(b"data: [DONE]\n\n")
        self.wfile.write(b"0\r\n\r\n")
        self.wfile.flush()


srv = ThreadingHTTPServer(("127.0.0.1", PORT), H)
srv.daemon_threads = True
print(f"[2026-10-19 10:00:06] The server is fired up and ready to roll! port {PORT}", flush=True)
srv.serve_forever()
