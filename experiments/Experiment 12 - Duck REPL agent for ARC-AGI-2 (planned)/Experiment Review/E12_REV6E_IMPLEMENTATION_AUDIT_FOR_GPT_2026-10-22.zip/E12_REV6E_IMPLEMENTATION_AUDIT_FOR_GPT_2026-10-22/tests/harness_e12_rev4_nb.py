"""CPU harness for the E12 notebook: runs the REAL notebook cells (mode/fallback, config, install branch with
Q27X_SKIP_INSTALL, tokenizer + E11 tokenizer check, Duck package + sandbox self-test, tasks, SGLang engine cell with launch /
caps / smoke against fake_sgl_duck_server.py, the Duck solver, the report). Scripted model replies only.
usage: python harness_e12_nb.py <notebook> <scenario>      scenarios: smoke | rerun | launchfail | thinkmarkup | modelsfail (the last two: vLLM notebooks)"""
import json
import os
import shutil
import socket
import subprocess
import sys
import time
import urllib.request
import zipfile
from pathlib import Path

NB, SCEN = sys.argv[1], sys.argv[2]
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / "fixtures"))
import e12_fixtures as B  # noqa: E402  (self-contained fixtures next to this file)

sys.stdout.reconfigure(encoding="utf-8")
if os.name == "nt":   # Windows-only test shim (Duck passes a 65 KB bootstrap as -c; Linux allows it)
    _real = subprocess.Popen
    _bdir = HERE / "runs" / "_bootstrap"
    _bdir.mkdir(parents=True, exist_ok=True)

    class _Shim(_real):
        def __init__(self, args, *a, **kw):
            if isinstance(args, list) and len(args) >= 5 and args[1:4] == ["-I", "-S", "-c"]:
                f = _bdir / "sandbox_bootstrap.py"
                if not f.exists() or f.read_text(encoding="utf-8") != args[4]:
                    f.write_text(args[4], encoding="utf-8")
                args = [args[0], "-I", "-S", str(f)] + args[5:]
            super().__init__(args, *a, **kw)
    subprocess.Popen = _Shim
    if not hasattr(os, "killpg"):      # Duck kills a timed-out child's process group (Linux only)
        import signal as _sig
        os.killpg = lambda pid, sig: os.kill(pid, 9)
        if not hasattr(_sig, "SIGKILL"):
            _sig.SIGKILL = 9

ROOT = HERE / "nbwork"
ROOT.mkdir(exist_ok=True)
WORK = ROOT / f"{SCEN}_{time.strftime('%H%M%S')}"
WORK.mkdir()
ch, sol, multi, single = B.load()
PICK = ["2ba387bc"] + multi[:2] + single[:2]
FP8 = B.TOKDIR_FP8
assert (FP8 / "config.json").exists(), FP8
DFL = ROOT / "dflash"; DFL.mkdir(exist_ok=True)
json.dump({"architectures": ["DFlash2DraftModel"]}, open(DFL / "config.json", "w"))
WH = ROOT / "wheelhouse"; WH.mkdir(exist_ok=True)
json.dump({"sglang": "0.5.21"}, open(WH / "BUILD_INFO.json", "w"))
(WH / "requirements.lock").write_text("", encoding="utf-8"); (WH / "SHA256SUMS").write_text("", encoding="utf-8")
ARC = WORK / "arc"; ARC.mkdir()
shutil.copy(B.DATA / "arc-agi_evaluation_challenges.json", ARC / "arc-agi_evaluation_challenges.json")
shutil.copy(B.DATA / "arc-agi_evaluation_solutions.json", ARC / "arc-agi_evaluation_solutions.json")
json.dump({t: {"train": ch[t]["train"], "test": [{"input": q["input"]} for q in ch[t]["test"]]} for t in PICK},
          open(ARC / "arc-agi_test_challenges.json", "w"))
with socket.socket() as s:
    s.bind(("127.0.0.1", 0)); PORT = s.getsockname()[1]
os.environ.update(Q27X_ARC_ROOT=str(ARC), Q27X_WORKING=str(WORK), Q27X_MODEL=str(FP8), Q27X_SKIP_INSTALL="1",
                  PYTHONIOENCODING="utf-8", E11_HARNESS="1", E11_PORT=str(PORT),
                  E11_FAKE_SERVER=str(HERE / "fake_sgl_duck_server.py"), E11_INT4=str(B.TOKDIR_INT4), E11_DFLASH=str(DFL),
                  E11_SGL_WHEELHOUSE=str(WH), FAKE_SCEN=SCEN, E12_DIR=str(WORK / "e12_duck"),
                  ARC3_HTTP_RETRY_BASE_SECONDS="0.05", ARC3_HTTP_RETRY_MAX_SECONDS="0.1",
                  E12_VLLM_PORT=str(PORT), E12_FAKE_VLLM_SERVER=str(HERE / "fake_vllm_duck_server.py"))
if SCEN == "rerun":
    os.environ["KAGGLE_IS_COMPETITION_RERUN"] = "true"
    os.environ["E12_R6_MIN_ADMIT_SEC"] = "5"   # rev 6 admits a branch only with >= 240 s left; the fake rerun window is 25 s
if SCEN in ("eval6", "r5"):     # rev 4/5: tiny per-branch cap so the fake run ends by cap (branches that never submit)
    os.environ["E12_MAX_GEN"] = "2000" if SCEN == "eval6" else "7000"   # r5 replies are 2,100 tokens (yield every request)
if SCEN in ("r6", "g4b", "parity"):   # rev 6: replies 2,100 tokens; first exposure pauses branch 0 after 2 replies; cap after 5
    os.environ.update(E12_MAX_GEN="10000", E12_R6_FIRST_EXPOSURE="4000", E12_R6_MIN_ADMIT_SEC="5")
SMOKELIKE = ("smoke", "thinkmarkup", "modelsfail")   # SMOKE1 profile; the fake server varies its behaviour

nb = json.load(open(NB, encoding="utf-8"))
code = ["".join(c["source"]) for c in nb["cells"] if c["cell_type"] == "code"]
VLLM = "CELL 5 — engine: vLLM 0.19 OpenAI server (E12-V)" in code[5]   # E12-V notebook (same Duck, vLLM engine)
assert len(code) == 8 and "CELL 3 — E12: Duck package" in code[3] and ("CELL 5 — engine: SGLang" in code[5] or VLLM), len(code)
G = {"__name__": "__main__"}
t0 = time.time()
for i in (0, 1):
    exec(compile(code[i], f"<cell{i}>", "exec"), G)
G["E12_SOLVE_WINDOW_SEC"] = ({"eval6": 90, "r5": 90, "r6": 300, "g4b": 300, "parity": 300}.get(SCEN, 25)) if SCEN != "rerun" else None
for i in (2, 3, 4, 5):
    exec(compile(code[i], f"<cell{i}>", "exec"), G)
if SCEN == "rerun":
    G["HARD_STOP"] = time.perf_counter() + 25 + G["E12_STOP_BEFORE_HARD_SEC"]
exec(compile(code[6], "<cell6>", "exec"), G)
# read the fake server's request log NOW: CELL 7 stops the server at its end (before rev 3 every flog check was skipped)
FLOG = None
try:
    if G.get("E11_SERVER") is not None and G["E11_SERVER"].alive():
        FLOG = json.loads(urllib.request.urlopen(f"http://127.0.0.1:{PORT}/fake_log", timeout=10).read())
except Exception as _e:
    print("fake_log read failed:", repr(_e))
exec(compile(code[7], "<cell7>", "exec"), G)

checks = []


def check(label, cond, info=""):
    checks.append((label, bool(cond), "" if cond else str(info)[:800]))


rep = json.load(open(WORK / "q27x" / "e12_run_report.json", encoding="utf-8"))
sub = json.load(open(WORK / "submission.json", encoding="utf-8"))
test = json.load(open(ARC / "arc-agi_test_challenges.json", encoding="utf-8"))
check("submission schema = every test task, every test input",
      set(sub) == set(test) and all(len(sub[t]) == len(test[t]["test"]) for t in test), list(sub))
check("sandbox self-test ok", G["E10_SANDBOX_SELFTEST"].get("ok"), G["E10_SANDBOX_SELFTEST"])
_mem = G["E10_SANDBOX_SELFTEST"].get("memory_limit") or {}
if os.name == "nt":
    check("memory-limit evidence reported (Windows: unavailable, run continues)",
          "not available" in str(_mem.get("limit", {}).get("last_error")) and _mem.get("ok") is False, _mem)
else:
    check("memory limit verified (read-back, 5 GiB rejected, 128 MiB ok)", _mem.get("ok") is True, _mem)
check("HTTP cold-start grace disabled in the notebook's agents", "_http_initial_grace_used = True" in
      (Path(G["E12_DIR"]) / "arc2_duck.py").read_text(encoding="utf-8"), "")
if SCEN == "launchfail":
    check("engine not ready -> Duck not run", not G["ENGINE_READY"] and "not run" in str(rep["e12_run"]["error"]), rep["e12_run"])
    check("fallback submission = identity", all(a["attempt_1"] == q["input"] for t in test for a, q in zip(sub[t], test[t]["test"])), "")
else:
    flog = FLOG
    check("harness: fake server request log captured before CELL 7 stops the server", flog is not None, "")
    check("engine ready with concurrency 12", G["ENGINE_READY"] and G["CONCURRENCY"] == 12, G["ENGINE_INFO"])
    if VLLM:
        vi = G["ENGINE_INFO"]["vllm"]
        check("E12-V rev 2: cold smoke reply without prompt_tokens_details is accepted (vLLM 0.19, issue 44377)",
              vi["smoke"]["ok"] and vi["smoke"]["cache_details_present"] is False, vi.get("smoke"))
        check("E12-V: KV + concurrency parsed from the vLLM log (SIMULATED values, parser test only)",
              vi.get("kv_tokens_logged") == 337600 and vi.get("max_concurrency_logged", {}).get("x") == 7.66, vi)
        ua = rep["usage_all"]
        check("E12-V rev 2: cache report keeps 'not reported' apart (coverage < 1, reported-only rate present)",
              ua.get("cache_detail_coverage") is not None and ua["cache_detail_coverage"] < 1
              and ua.get("cached_pct_reported_only") is not None, ua)
        check("E12-V: history key = reasoning", G["os"].environ.get("ARC3_REASONING_HISTORY_KEY") == "reasoning", "")
        check("model id from /v1/models", rep["e12_run"]["model_id"] == "Qwen/Qwen3.8-27B-FP8", rep["e12_run"])
        ds = rep.get("e11", {}).get("decode_summary") or {}
        check("E12-V: engine stats summarised from the vLLM log", ds.get("n_lines", 0) > 0 and
              ds.get("prefix_cache_hit_pct_last") == 88.0, ds)
    else:
        check("e11 smoke passed (generate + abort)", G["E11_SGL"]["smoke"]["ok"], G["E11_SGL"]["smoke"])
        check("model id from /v1/models", rep["e12_run"]["model_id"] == "fake-int4", rep["e12_run"])
    check("no solver error", not rep["e12_run"]["error"], rep["e12_run"]["error"])
    n_br = 0 if SCEN == "parity" else len(G["TASK_IDS"]) * G["E12_BRANCHES"]   # parity: no solving
    check(f"all {n_br} branches finished", rep["e12_run"]["branches_done"] == n_br, rep["e12_run"])
    if SCEN not in ("r5", "r6", "g4b", "parity"):   # rev 5/6 fake model never submits: candidates come from check()/auto-check (below)
        check("one accepted branch per task", rep["e12_run"]["branches_accepted"] == len(G["TASK_IDS"]), rep["e12_run"])
    if SCEN != "parity":
        check("usage recorded with cached_tokens", rep["usage_all"]["requests"] > 0 and rep["usage_all"]["cached_tokens"] > 0,
              rep["usage_all"])
    if SCEN == "eval6":
        T6 = ["136b0064", "898e7135", "135a2760", "b5ca7ac4", "4c3d4a41", "62593bfd"]
        check("rev 4: profile EVAL6 = the 6 tasks", G["PROFILE"] == "EVAL6" and sorted(G["TASK_IDS"]) == sorted(T6), G["TASK_IDS"])
        check("rev 4 (audit): live 6 / streams 6 / 60k output / timeout 1,800 / cap 2000 (harness)",
              (G["E12_LIVE_BRANCHES"], G["E12_STREAMS"], G["E12_DUCK_MAX_OUTPUT"],
               G["E12_DUCK_REQUEST_TIMEOUT"], G["E12_MAX_GEN_PER_BRANCH"]) == (6, 6, 60000, 1800, 2000), "")
        check("rev 4 (audit): Duck env keeps the milestone window 131,072 and carries output 60,000 (read by Duck at import)",
              G["os"].environ.get("LOCAL_ANALYZER_CONTEXT_WINDOW") == "131072" and G["os"].environ.get("LOCAL_ANALYZER_MAX_OUTPUT") == "60000",
              (G["os"].environ.get("LOCAL_ANALYZER_CONTEXT_WINDOW"), G["os"].environ.get("LOCAL_ANALYZER_MAX_OUTPUT")))
        if flog:
            mt = sorted({c.get("max_tokens") for c in flog["chat"] if c.get("tools", True)})
            check("rev 4: every Duck request asks max_tokens 60000", mt == [60000], mt)
            check("rev 4: at most 6 requests in flight (live branches)", flog.get("max_inflight", 99) <= 6, flog.get("max_inflight"))
            first6 = [t for t, _, _ in flog["new_convs"][:6]]
            check("rev 4: the first 6 conversations = first 3 tasks x both branches (fair start)",
                  sorted(first6) == sorted(G["E12_ORDER"][:3] * 2), (first6, G["E12_ORDER"][:3]))
        check("rev 4: eval scored, every query hit (role-0 lookup)", rep.get("eval_query_hits") == rep.get("eval_query_total"),
              (rep.get("eval_query_hits"), rep.get("eval_query_total")))
    if SCEN == "r5":
        T6 = ["136b0064", "898e7135", "135a2760", "b5ca7ac4", "4c3d4a41", "62593bfd"]
        if G["PROFILE"] == "EVAL12R5":
            T6 = T6 + ["247ef758", "bf45cf4b", "f931b4a8", "65b59efc", "9385bd28", "cbebaa4b"]
        env = G["os"].environ
        check(f"rev 5: profile {G['PROFILE']} = its {len(T6)} tasks, rev 5 build", G["PROFILE"] in ("EVAL6R5", "EVAL12R5")
              and sorted(G["TASK_IDS"]) == sorted(T6) and G["_E12_REV5"] is True, (G["PROFILE"], G["TASK_IDS"]))
        _live = 12 if "_S12" in Path(NB).name else 6
        check(f"rev 5: live {_live} / streams {_live} / output 49,152 / timeout 1,800 / temperature 1.0 / cap 7000 (harness)",
              (G["E12_LIVE_BRANCHES"], G["E12_STREAMS"], G["E12_DUCK_MAX_OUTPUT"], G["E12_DUCK_REQUEST_TIMEOUT"],
               G["E12_DUCK_TEMPERATURE"], G["E12_MAX_GEN_PER_BRANCH"]) == (_live, _live, 49152, 1800, 1.0, 7000), "")
        check("rev 5: Duck env carries 49,152 output, temperature 1.0, window 131,072; rev 5 flag + tokenizer path set",
              (env.get("LOCAL_ANALYZER_MAX_OUTPUT"), env.get("LOCAL_ANALYZER_TEMPERATURE"), env.get("LOCAL_ANALYZER_CONTEXT_WINDOW"),
               env.get("E12_ARC2_REV5")) == ("49152", "1.0", "131072", "1") and Path(env.get("E12_TOKENIZER_JSON", "")).is_file(),
              (env.get("LOCAL_ANALYZER_MAX_OUTPUT"), env.get("LOCAL_ANALYZER_TEMPERATURE"), env.get("E12_TOKENIZER_JSON")))
        if flog:
            ch_ = [c for c in flog["chat"] if c.get("tools", True)]
            check("rev 5: every Duck request asks max_tokens 49152 and temperature 1.0",
                  sorted({c.get("max_tokens") for c in ch_}) == [49152] and sorted({c.get("temperature") for c in ch_}) == [1.0],
                  (sorted({c.get("max_tokens") for c in ch_}), sorted({c.get("temperature") for c in ch_})))
            r5 = flog.get("r5") or {}
            check("rev 5 B7/B8: every request carries the rev 5 system prompt", r5.get("sys_rev5", 0) > 0 and r5.get("sys_old") == 0, r5)
            check("rev 5 B6: the cut tool call never ran; the model was told it was cut off",
                  r5.get("cut_code_ran") == 0 and r5.get("cut_off_notes", 0) > 0, r5)
            check("rev 5 B4: resume openers use the rev 5 text", r5.get("resume_r5", 0) > 0, r5)
            _eff = G.get("E12_REASONING_EFFORT") or None
            _got = sorted({str((c.get("chat_template_kwargs") or {}).get("reasoning_effort")) for c in ch_})
            check(f"rev 5: reasoning_effort in every request = {_eff or 'not sent (model default xhigh)'}",
                  _got == [str(_eff)], _got)
            check(f"rev 4/5: at most {_live} requests in flight (live branches)", flog.get("max_inflight", 99) <= _live,
                  flog.get("max_inflight"))
        br = rep["branches"]
        check("rev 5 B1: no branch submitted, yet every branch kept >= 1 host-verified candidate from check()",
              rep["e12_run"]["branches_accepted"] == 0 and all(b.get("checked_kept", 0) >= 1 for b in br), [(b["task"], b["branch"],
              b.get("checked_kept"), b.get("checked_verified")) for b in br])
        check("rev 5 B6: every role-1 branch dropped exactly its cut tool call",
              sum((b.get("rev5_events") or {}).get("cut_tool_calls_dropped", 0) for b in br) == len(G["TASK_IDS"]),
              [(b["task"], b["branch"], b.get("rev5_events")) for b in br])
        check("rev 5 B2: every query hit although one candidate per task is test-wrong (two distinct attempts)",
              rep.get("eval_query_hits") == rep.get("eval_query_total") and rep["eval_query_total"] > 0,
              (rep.get("eval_query_hits"), rep.get("eval_query_total")))
        ur = rep.get("eval_unit_records") or []
        check("rev 5 report: harvested programs counted per query (2 per task: one right, one wrong)",
              ur and all(u.get("harvested_programs") == 2 and u.get("harvested_programs_correct") == 1 for u in ur), ur[:3])
        tk = (rep.get("configuration", {}).get("e12") or {}).get("rev5_tokenizer") or {}
        check("rev 5 R5-4: tokenizer status recorded in the report (loaded from the model dir)",
              tk.get("loaded") is True and tk.get("path", "").endswith("tokenizer.json") and tk.get("probe_tokens", 0) > 0, tk)
        check("rev 5 R5-5: per-request prompt estimate vs actual recorded",
              all((b.get("rev5_events") or {}).get("prompt_estimates") for b in br), [(b["task"], b["branch"]) for b in br
              if not (b.get("rev5_events") or {}).get("prompt_estimates")])
        check("rev 5: evaluation keeps the test fallback in submission.json",
              all(a["attempt_1"] == q["input"] for t in test for a, q in zip(sub[t], test[t]["test"])), "")
    if SCEN in ("r6", "g4b"):
        S = 12      # rev 6c (user 2026-10-21): 12 streams
        _prof = {"r6": "EVAL12R6", "g4b": "EVAL12R6G4B"}[SCEN]
        T12 = ["136b0064", "898e7135", "135a2760", "b5ca7ac4", "4c3d4a41", "62593bfd",
               "247ef758", "bf45cf4b", "f931b4a8", "65b59efc", "9385bd28", "cbebaa4b"]
        env = G["os"].environ
        check(f"rev 6: profile {_prof} = its 12 tasks, rev 6 build (rev 5 fixes included)",
              G["PROFILE"] == _prof and sorted(G["TASK_IDS"]) == sorted(T12) and G["_E12_REV6"] is True
              and G["_E12_REV5"] is True, (G["PROFILE"], G["TASK_IDS"]))
        check(f"rev 6: streams {S} / first-request cap 12,288 / timeout 1,800 / temperature 1.0 / rev 6 + rev 5 flags",
              (G["E12_STREAMS"], G["E12_DUCK_MAX_OUTPUT"], G["E12_DUCK_REQUEST_TIMEOUT"], G["E12_DUCK_TEMPERATURE"],
               env.get("E12_ARC2_REV6"), env.get("E12_ARC2_REV5")) == (S, 12288, 1800, 1.0, "1", "1"), "")
        r6run = rep.get("rev6") or {}
        check(f"rev 6c R6-S5: context window = 100 % of the KV pool / {S} streams (fake KV 881,336 -> 73,444)",
              r6run.get("window") == min(131072, int(1.0 * G["ENGINE_INFO"].get("kv_tokens", 0) / S)) and r6run["window"] < 131072,
              (r6run.get("window"), G["ENGINE_INFO"].get("kv_tokens")))
        pf = r6run.get("preflight") or {}
        check(f"rev 6 R6-X1: isolation preflight ok ({S} distinct markers, each reply its own, no leak); drafter config read",
              pf.get("isolation_ok") is True and pf.get("isolation_own_marker") == S and "drafter_target_layer_config" in pf, pf)
        check(f"rev 6: {S} workers after the preflight", r6run.get("workers") == S, r6run.get("workers"))
        if flog:
            r6 = flog.get("r6") or {}
            mts = r6.get("max_tokens") or {}
            check("rev 6 R6-Q1: requests use 12,288 first, 24,576 after a successful Python call (only these caps)",
                  set(mts) <= {"12288", "24576", "32768"} and mts.get("12288", 0) > 0 and mts.get("24576", 0) > 0, mts)
            check("rev 6 R6-V1 / 6e G4-11: branch 0 got the facts view, branch 1 the indexed grids view; every request "
                  "identified its task",
                  r6.get("sys_facts", 0) > 0 and r6.get("sys_grids", 0) > 0 and r6.get("task_none") == 0
                  and r6.get("sys_r6", 0) == r6.get("sys_facts", 0) + r6.get("sys_grids", 0), r6)
            rs = r6.get("resume") or {}
            check("rev 6 R6-P2: resume states seen: first, length (cut, no call), cut (tool call), verified",
                  all(rs.get(k, 0) > 0 for k in ("first", "length", "cut", "verified")), rs)
            check("rev 6: the cut tool call never ran", (flog.get("r5") or {}).get("cut_code_ran") == 0, flog.get("r5"))
            check(f"rev 6: at most {S} requests in flight", flog.get("max_inflight", 99) <= S, flog.get("max_inflight"))
            roles = [(r, ts) for _, r, ts in flog["new_convs"]]
            first_b1 = min((t for r, t in roles if r == 1), default=None)
            last_b0 = max((t for r, t in roles if r == 0), default=None)
            check("rev 6 R6-S1: every task's branch 0 started before any branch 1 (coverage first)",
                  first_b1 is not None and last_b0 is not None and last_b0 <= first_b1, (last_b0, first_b1))
        br = rep["branches"]
        check("rev 6 R6-K1/T1: no branch submitted, yet every branch kept a host-verified candidate via AUTO-check "
              "(the transform calls a trusted helper)", rep["e12_run"]["branches_accepted"] == 0
              and all(b.get("checked_kept", 0) >= 1 for b in br) and len(br) == 24, [(b["task"], b["branch"], b.get("checked_kept"))
                                                                                     for b in br])
        check("rev 6 R6-Q2: branch 0 paused at the first exposure, resumed later with the same agent (>= 2 runs, tokens continue)",
              all(b["branch"] != 0 or (len(b.get("runs") or []) >= 2 and (b["runs"][0] or {}).get("status") == "paused")
                  for b in br), [(b["task"], b["branch"], b.get("runs")) for b in br if b["branch"] == 0][:3])
        check("rev 6 R6-S2: every task got branch 1 (one candidate -> a fresh attempt)", sum(1 for b in br if b["branch"] == 1) == 12, "")
        check("rev 6 R6-V3: the two views are recorded per branch", {b.get("view") for b in br} == {"facts", "indexed"},
              {b.get("view") for b in br})
        check("rev 6: every query hit with one right (b0) + one test-wrong (b1) candidate per task",
              rep.get("eval_query_hits") == rep.get("eval_query_total") and rep["eval_query_total"] > 0,
              (rep.get("eval_query_hits"), rep.get("eval_query_total")))
        m = r6run.get("metrics") or {}
        check("rev 6 R6-M1: metrics in the report (exposed 12, meaningful 12, autocheck > 0, first tool/check tokens, caps, resumes)",
              m.get("tasks_exposed") == 12 and m.get("tasks_meaningful") == 12 and m.get("autocheck_functions", 0) >= 24
              and m.get("first_tool_tokens_median") is not None and m.get("caps") and m.get("resumes")
              and m.get("length_cut_no_call", 0) >= 12, m)
        check("rev 6b R6-X1: parity control (same request twice at T 0, batch size 1) recorded and identical",
              (pf.get("parity_control") or {}).get("identical") == 2 and (pf.get("parity_control") or {}).get("own_marker") == 2, pf)
        check("rev 6b R6-M1: facts tokens bounded (p50 <= 800, max <= 1,500), hand-reading / loop / redefinition shares, "
              "uncached prefill, real running <= 12, branch-1 yield by class (12 branches)",
              m.get("facts_tokens_p50") is not None and m["facts_tokens_p50"] <= 800 and m.get("facts_tokens_max", 9e9) <= 1500
              and m.get("hand_reading_grid_row_share") is not None and m.get("reasoning_repeat_share") is not None
              and m.get("tool_calls", 0) > 0 and m.get("redefinition_share") is not None and m.get("uncached_prompt_tokens", 0) > 0
              and m.get("real_running_max") is not None and m["real_running_max"] <= S
              and sum(c["branches"] for c in (m.get("branch1_yield_by_stage2_class") or {}).values()) == 12
              and isinstance(m.get("overfit_flags"), dict), {k: m.get(k) for k in (
                  "facts_tokens_p50", "facts_tokens_max", "hand_reading_grid_row_share", "reasoning_repeat_share", "tool_calls",
                  "redefinition_share", "uncached_prompt_tokens", "real_running_max", "branch1_yield_by_stage2_class",
                  "overfit_flags")})
        check("rev 6b: every branch-1 row carries its stage-2 class; overfit flags per branch in the report",
              all(b.get("stage2_class") is not None for b in br if b["branch"] == 1) and all("overfit_flags" in b for b in br),
              [(b["task"], b.get("stage2_class")) for b in br if b["branch"] == 1][:4])
        if flog:
            px = flog.get("r6_prefix") or {}
            check("rev 6b R6-D2: request n+1 = request n + its reply (prefix kept) in every conversation; system prompt "
                  "never changes; no conversation driven by two workers (the 12 cut replies: only the broken call is dropped)", px.get("ok", 0) > 0 and px.get("break") == 0 and px.get("after_cut") == 12
                  and px.get("sys_changed") == 0, px)
            check("rev 6 R6-M1: the caps histogram counts each request once (= the server's max_tokens histogram)",
                  {k: v for k, v in (m.get("caps") or {}).items()} == (flog.get("r6") or {}).get("max_tokens"),
                  (m.get("caps"), (flog.get("r6") or {}).get("max_tokens")))
        check("rev 6: scheduler summary in the report (all sessions done, nothing left queued)",
              (r6run.get("scheduler") or {}).get("heap_left") == 0 and set(((r6run.get("scheduler") or {}).get("sessions") or {}).values())
              == {"done"}, r6run.get("scheduler"))
        check("rev 6: evaluation keeps the test fallback in submission.json",
              all(a["attempt_1"] == q["input"] for t in test for a, q in zip(sub[t], test[t]["test"])), "")
        check("rev 6d C6-2: isolation verdict PASS (12/12 own markers, no leak) -> 12 workers",
              pf.get("isolation_state") == "PASS" and pf.get("isolation_ok") is True and r6run.get("workers") == S, pf)
        sc6 = r6run.get("scheduler") or {}
        check("rev 6d A3-F4 / C6-4: coverage fields reported (12 tasks exposed, 0 stage-1 starts left, 0 stragglers); "
              "no capacity event on a healthy server; facts over target 0",
              sc6.get("tasks_exposed") == 12 and sc6.get("stage1_left") == 0 and sc6.get("stragglers") == 0
              and sc6.get("events") == [] and m.get("facts_over_target") == 0, (sc6.get("tasks_exposed"), sc6.get("stage1_left"),
                                                                                sc6.get("stragglers"), sc6.get("events"),
                                                                                m.get("facts_over_target")))
        # ---------------------------------------------------------------- rev 6e (fix list G4-1..G4-18)
        check("rev 6e G4-1: the fake server reports queue 1 at all times (the G4B steady state) -> workers stay 12, "
              "no KV hold, KV sampled from sglang:full_token_usage",
              sc6.get("workers") == S and sc6.get("allowed") == S and sc6.get("kv_holds") == 0
              and sc6.get("kv_samples", 0) > 0 and sc6.get("kv_missing") == 0,
              {k: sc6.get(k) for k in ("workers", "allowed", "kv_holds", "kv_samples", "kv_missing")})
        b1caps = [set((b.get("rev6_events") or {}).get("caps") or {}) for b in br if b["branch"] == 1]
        b0caps = [set((b.get("rev6_events") or {}).get("caps") or {}) for b in br if b["branch"] == 0]
        check("rev 6e G4-2: branch 1 never uses the 12,288 first cap (it starts at 24,576); branch 0 starts at 12,288",
              b1caps and all("12288" not in c and "24576" in c for c in b1caps) and all("12288" in c for c in b0caps),
              (b1caps[:3], b0caps[:3]))
        cd = r6run.get("cache_diag") or {}
        _steps = {"warm", "replay_exact", "divergent_1", "divergent_2", "replay_after_churn", "divergent_after_churn"}
        check("rev 6e G4-8: the cache diagnostic ran before solving (commit mode) and recorded every step; a missing "
              "prompt_tokens_details reads as 0 cached",
              cd.get("summary") and set(cd["summary"]) == _steps
              and any(x.get("step") == "churn" and x.get("n") == S and x.get("errors") == 0 for x in cd.get("steps", []))
              and cd["summary"]["warm"][0] == 0 and cd["summary"]["replay_exact"][0] > 0, cd.get("summary"))
        check("rev 6e G4-7/13: accepted events vs unique programs vs distinct predictions; observed first-check median",
              m.get("accepted_events", 0) >= m.get("unique_verified_programs", 0) > 0 and m.get("distinct_test_predictions", 0) > 0
              and m.get("first_check_tokens_median_observed") is not None and m.get("checked_branches", 0) > 0
              and m.get("overfit_flags_counted_on") == "unique programs",
              {k: m.get(k) for k in ("accepted_events", "unique_verified_programs", "distinct_test_predictions",
                                     "first_check_tokens_median_observed", "checked_branches")})
        check("rev 6e G4-14/15/18: transform, request-prefix, progress and concurrency telemetry in the report",
              m.get("branches_with_transform", 0) > 0 and m.get("requests_instrumented", 0) > 0
              and m.get("later_prefix_intact_share") is not None and isinstance(m.get("concurrency"), dict)
              and m.get("progress_reports", 0) > 0 and "stage2_runs_improved" in m
              and "b1_new_distinct_verified_per_100k_tokens" in m and "later_zero_hit_prefix_intact" in m,
              {k: m.get(k) for k in ("branches_with_transform", "requests_instrumented", "later_prefix_intact_share",
                                     "progress_reports", "concurrency")})
        check("rev 6e knobs: KV gate 0.95, min chunk 12,288 (G4-17), show 900 / 1,000 cells (G4-4), nudge 27,000 (G4-6), "
              "branch-1 view indexed (G4-11), branch-1 first cap 24,576 (G4-2)",
              tuple(G["E12_R6"][k] for k in ("E12_R6_KV_ADMIT", "E12_R6_MIN_CHUNK", "E12_R6_SHOW_MAX_CELLS",
                                             "E12_R6_SHOW_CALL_CELLS", "E12_R6_NUDGE_TOKENS", "E12_R6_B1_VIEW",
                                             "E12_R6_CAP_FIRST_B1"))
              == (0.95, 12288, 900, 1000, 27000, "indexed", 24576), "")
        check("rev 6c: stage-2 p90 cutoff off by default (user-approved option, recorded)",
              (r6run.get("scheduler") or {}).get("stage2_p90_cutoff") is False and G["E12_R6"]["E12_R6_P90_CUTOFF"] == 0,
              r6run.get("scheduler"))
        g4 = r6run.get("g4b")
        if SCEN == "r6":
            check("rev 6c: the EVAL12R6 run has no gate-4b window", g4 is None, g4)
        else:
            _ra = G["PROFILE_TABLE"]["RERUN_ALL"]
            _hid = _ra["time_budget_sec"] - _ra["hard_margin_sec"] - G["E12_STOP_BEFORE_HARD_SEC"]
            check("gate 4b: window = 12 x (hidden solve seconds from the measured start / 240), recorded",
                  g4 and g4["hidden_tasks"] == 240 and g4["hidden_solve_end_sec"] == _hid
                  and abs(g4["window_sec"] - 12 * (_hid - g4["solve_start_sec"]) / 240) <= 2
                  and 170 <= g4["sec_per_task"] <= 180, g4)
            check("gate 4b: the solve deadline is the smaller of the gate-4b window and the profile window (harness 300 s)",
                  rep["e12_run"]["deadline_in_sec"] <= 300 and g4["window_sec"] > 300, (rep["e12_run"]["deadline_in_sec"], g4))
            check("rev 6e self-audit: the gate-4b window starts after the preflight and the cache diagnostic (the full "
                  "window is left at the solve start; the shift is recorded)",
                  g4.get("shift_sec") is not None and g4["shift_sec"] >= 0
                  and g4.get("window_start_sec", -1) >= rep["e12_run"]["started_sec"]
                  and abs(rep["e12_run"]["deadline_in_sec"] - min(300, g4["window_sec"])) <= 3
                  and (r6run.get("cache_diag") or {}).get("summary"),
                  (g4, rep["e12_run"]["deadline_in_sec"], rep["e12_run"]["started_sec"]))
    if SCEN == "parity":
        par = (rep.get("rev6") or {}).get("parity") or {}
        su = par.get("summary") or {}
        check("parity: profile PARITYR6 = 4 tasks, no solving (no branch)", G["PROFILE"] == "PARITYR6" and len(G["TASK_IDS"]) == 4
              and not rep["branches"], (G["PROFILE"], len(rep["branches"])))
        tl = par.get("target_only_launch") or {}
        check("parity: the server was relaunched without the 4 --speculative-* flags", tl.get("ok") is True
              and sorted(tl.get("spec_flags_removed") or []) == sorted(["--speculative-algorithm", "--speculative-draft-model-path",
                                                                        "--speculative-draft-model-quantization",
                                                                        "--speculative-num-draft-tokens"]), tl)
        check("parity: 8 probes (4 tasks x thinking on/off); DFlash control identical 8/8; the planted target-only "
              "difference on one task is found (6/8 identical); tool-call presence and finish agree 8/8",
              su == {"probes": 8, "control_identical": 8, "target_identical": 6, "same_tool_call_presence": 8, "same_finish": 8,
                     "compared": 8}, su)
        if flog is not None:
            check("parity: the log read before CELL 7 is the relaunched server's: 8 probes, all without --speculative-*",
                  len(flog.get("parity") or []) == 8 and not any(sp for _, _, sp in flog.get("parity") or []), flog.get("parity"))
        check("parity: the target-only server log is written (bundled)", (WORK / "q27x" / "sglang_server_target_only.log").exists(), "")
        check("parity: the fallback submission stays",
              all(a["attempt_1"] == q["input"] for t in test for a, q in zip(sub[t], test[t]["test"])), "")
    if SCEN in SMOKELIKE:
        check("profile SMOKE1 = 2ba387bc", G["PROFILE"] == "SMOKE1" and G["TASK_IDS"] == ["2ba387bc"], G["TASK_IDS"])
        check("eval scored: every query hit", rep.get("eval_query_hits") == rep.get("eval_query_total") and rep["eval_query_total"],
              (rep.get("eval_query_hits"), rep.get("eval_query_total")))
        check("task-norm 100 %", rep.get("eval_task_norm_pct") == 100.0, rep.get("eval_task_norm_pct"))
        check("evaluation keeps the test fallback in submission.json",
              all(a["attempt_1"] == q["input"] for t in test for a, q in zip(sub[t], test[t]["test"])), "")
    if SCEN == "rerun":
        check("rerun: TASK_IDS = test tasks", sorted(G["TASK_IDS"]) == sorted(test), G["TASK_IDS"])
        # rev 2 (GPT audits): concurrent submission writes are serialized; every intermediate file parses
        import threading as _th
        errs, bad_reads, stop = [], [0], _th.Event()

        def _w():
            for _ in range(20):
                try:
                    G["e12_write_submission"]()
                except Exception as e:
                    errs.append(f"{type(e).__name__}: {e}")

        def _r():
            while not stop.is_set():
                try:
                    json.loads((WORK / "submission.json").read_text(encoding="utf-8"))
                except (ValueError, OSError):
                    bad_reads[0] += 1
        # concurrent readers only on Linux: Windows refuses os.replace onto a file another handle has open
        rt = _th.Thread(target=_r if os.name != "nt" else (lambda: None)); rt.start()
        ws = [_th.Thread(target=_w) for _ in range(12)]
        [t.start() for t in ws]; [t.join() for t in ws]; stop.set(); rt.join()
        sub2 = json.load(open(WORK / "submission.json", encoding="utf-8"))
        leftovers = [p.name for p in WORK.iterdir() if p.name.endswith(".tmp")]
        check("12 concurrent writers x 20: no error, every read parses, same final content, no temp files",
              not errs and bad_reads[0] == 0 and sub2 == sub and not leftovers, (errs[:3], bad_reads[0], leftovers))
        hit = sum(a["attempt_1"] == sol[t][qi] for t in test for qi, a in enumerate(sub[t]))
        check("rerun: submission carries the solved grids", hit == sum(len(test[t]["test"]) for t in test), hit)
    if SCEN == "rerun" and G.get("_E12_REV6"):   # fake branch 1 submits identity (rejected), then inspects
        rs = ((rep.get("rev6") or {}).get("metrics") or {}).get("resumes") or {}
        check("rev 6 R6-P2: one first-turn opener per branch; the turn after a rejected submit names the rejection",
              rs.get("first") == len(rep["branches"]) and rs.get("rejected", 0) >= 1, rs)
    if flog and SCEN == "thinkmarkup":   # vLLM issue 39056: XML only in `reasoning`; Duck recovers it
        check("E12-V: tool calls inside reasoning recovered by Duck (task solved)", flog.get("markup_replies", 0) > 0
              and rep["e12_run"]["branches_accepted"] == len(G["TASK_IDS"]), (flog.get("markup_replies"), rep["e12_run"]))
    if SCEN == "modelsfail":
        check("E12-V rev 2: /v1/models failing in CELL 6 -> model id falls back to the served name",
              rep["e12_run"]["model_id"] == "Qwen/Qwen3.8-27B-FP8" and rep["e12_run"]["branches_accepted"] == len(G["TASK_IDS"]), rep["e12_run"])
    if flog and SCEN != "parity":
        c0 = [c for c in flog["chat"] if c.get("tools", True)][0]   # E12-V: skip the engine smoke request
        if VLLM:
            check("E12-V rev 3: every request names the served model (no 404)", not flog.get("model_404"),
                  flog.get("model_404", [])[:3])
        if VLLM:   # vLLM 0.19 reads prior reasoning only from `reasoning` (chat_utils.py:1512)
            hk = [k for k in flog["history_keys"] if k]
            check("E12-V: prior reasoning sent back under `reasoning` only", hk and all(k == ["reasoning"] for k in hk), hk[:5])
        _mt, _tp = ((12288, 1.0) if G.get("_E12_REV6") else (49152, 1.0) if G.get("_E12_REV5")
                    else {"eval6": (60000, 0.7)}.get(SCEN, (12288, 0.7)))
        check(f"chat request: preserve/enable thinking, {_mt}, {_tp}/0.95/20, non-stream",
              (c0["chat_template_kwargs"] or {}).get("preserve_thinking") is True and c0["max_tokens"] == _mt
              and (c0["temperature"], c0["top_p"], c0["top_k"]) == (_tp, 0.95, 20) and not c0.get("stream"), c0)
        roles = [r for _, r, _ in flog["new_convs"]]
        if n_br > G["E12_RUN"]["streams"] and not G.get("E12_LIVE_BRANCHES"):   # old order; rev 4 live pool = task-major (checked above)
            check("first branches start before any second branch", roles == sorted(roles), flog["new_convs"])
        else:                                 # every branch is admitted at once: first-request order is a thread race
            check(f"all {n_br} branches started (slots {G['E12_RUN']['streams']} >= branches)", len(roles) == n_br, flog["new_convs"])
        check("in-flight <= streams", flog["max_inflight"] <= 12, flog["max_inflight"])
    with zipfile.ZipFile(WORK / "Q27X_E12_DUCK_BUNDLE.zip") as z:
        names = z.namelist()
    trs = [n for n in names if n.endswith("transcript.txt")]
    check("bundle: report, submission, transcripts per branch, server log",
          {"e12_run_report.json", "submission.json"} <= set(names) and len(trs) == n_br
          and any(n.startswith("vllm_openai_server" if VLLM else "sglang_server_") for n in names), names[:20])
    with zipfile.ZipFile(WORK / "Q27X_E12_DUCK_BUNDLE.zip") as z:
        check("transcripts hold the thinking", all("THINK step" in z.read(n).decode("utf-8", "replace") for n in trs), "")
        reqs = [n for n in names if n.startswith("duck/") and n.endswith("requests.jsonl")]   # not E11's sglang_requests
        if SCEN in SMOKELIKE:   # rev 2: request snapshots for the smoke (exact messages sent, incl. replayed thinking)
            snap = [json.loads(l) for n in reqs for l in z.read(n).decode("utf-8").splitlines() if l.strip()]
            replay = any(any(m.get("role") == "assistant" and "THINK step" in str(m.get("reasoning" if VLLM else "reasoning_content") or "")
                             for m in (s.get("messages") or [])) for s in snap)
            check("smoke: request snapshots bundled, with replayed reasoning_content",
                  len(reqs) == n_br and replay, (reqs, len(snap)))
        else:
            check("rerun: request snapshots off by default", not reqs, reqs)
G["e11_kill_server"](wait=False)
bad = [c for c in checks if not c[1]]
print(f"\n[{SCEN}] {len(checks) - len(bad)}/{len(checks)} ok in {time.time() - t0:.0f} s")
for c in bad:
    print("   FAIL", c[0], "->", c[2])
print("@@NB_OK@@" if not bad else "@@NB_FAIL@@")
