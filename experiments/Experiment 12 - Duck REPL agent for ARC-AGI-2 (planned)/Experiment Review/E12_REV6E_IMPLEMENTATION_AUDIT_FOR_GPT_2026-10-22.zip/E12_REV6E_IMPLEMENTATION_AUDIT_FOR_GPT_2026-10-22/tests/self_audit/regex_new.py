import re, sys, time
sys.path.insert(0, str(__import__("pathlib").Path(__file__).resolve().parent.parent.parent / "duck_arc2"))
import arc2_duck as A
OLD = A._GRID_ROW_RE
NEW = re.compile(r"(?i)^\s*[\[\(]*\s*\d+(?:(?:\s*,\s*|\s+)\d+){3,}\s*[\]\)]*\s*,?\s*$|^\s*\d{8,}\s*$"
                 r"|^\s*(?:(?:row|r)\s*)?\d+\s*[:=]?\s*[\[\(]\s*\d(?:\s*,\s*\d){3,}\s*[\]\)]\s*,?\s*$"
                 r"|^\s*(?:(?:row|r)\s*)?\d+(?:\s*[:=]\s*|\s+)\d{8,}\s*$"
                 r"|^\s*(?:(?:row|r)\s*)?\d+\s*[:=]\s*\d(?:\s+\d){3,}\s*$")
must = ["0 [0, 0, 5, 2, 1]", "0: [0, 0, 5, 2]", "row 3: [1, 2, 3, 4]", "0 (0, 0, 5, 2)", "  r 0: [0, 0, 0, 0, 0, 0]",
        "0 0000000000000000000000", " 0  555555555555555555555555555555", "row 2: 00520000", "R 1 = 0 0 5 2 1",
        "3: 0 0 5 2 1", "[0, 0, 5, 2]", "0 0 5 2 1", "00520000", "Row 12: [3, 3, 3, 3]"]
never = ["r03 | 0 0 5 2 1 1", "r00 | 0 0 0 0", "{'a': 1, 'b': 2}", "[1, 2]", "(0,5): 0 -> 3",
         "at (0,0) color 2: [[2, 0, 2], [2, 0, 2]]", "0 2 (0, 2, 0, 3)", "IN 2 [(0, 3), (1, 3), (2, 3), (3, 3)]",
         "train 0: in (10, 10) colors {0: 90}", "pairs exact 2/3", "1 16 (0, 0, 3, 3)", "12345", "step 3: 5 cells",
         "(0, 0, 0, 3) [0]", "grid 30x30, rows 0..29, cols 0..29"]
ok = True
for s in must:
    if not NEW.match(s): ok = False; print("MISS", repr(s))
for s in never:
    if NEW.match(s): ok = False; print("FALSE", repr(s))
# linear time on adversarial lines
for s in ["0 " + "0" * 590 + "x", "r" + " 0" * 290 + " x", "0: " + "0 " * 290 + "x", "0" + ", 0" * 190 + "x", "1" * 599 + " x"]:
    t = time.perf_counter(); NEW.match(s); dt = time.perf_counter() - t
    if dt > 0.05: ok = False
    print("time %.4f s" % dt, s[:20])
print("ALL OK" if ok else "FAILED")
