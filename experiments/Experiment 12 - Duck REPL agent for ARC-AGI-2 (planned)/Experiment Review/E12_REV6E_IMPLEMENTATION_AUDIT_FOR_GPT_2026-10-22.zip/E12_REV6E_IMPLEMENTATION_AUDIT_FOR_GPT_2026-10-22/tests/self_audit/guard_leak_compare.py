"""Self-audit G4-3: rows that reach the model in runs of >= 6 grid-like lines, with the rev 6e regex (OLD) and the
widened regex (NEW, now in arc2_duck). Real guard semantics: guard_grid_prints() on each tool result."""
import re, sys, collections, importlib
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent / "duck_arc2"))
import arc2_duck as A
OLD = re.compile(r"(?i)^\s*[\[\(]*\s*\d+(?:(?:\s*,\s*|\s+)\d+){3,}\s*[\]\)]*\s*,?\s*$|^\s*\d{8,}\s*$|^\s*(?:row\s*)?\d+\s*[:=]?\s*[\[\(]\s*\d(?:\s*,\s*\d){3,}\s*[\]\)]\s*,?\s*$")
NEW = A._GRID_ROW_RE
roots = [Path(__file__).resolve().parent.parent.parent / "runs"]   # the bundle has the 64 transcripts of 4 runs; our full scan also read 85 more from the experiment folder (149)
files = sorted({p.resolve() for r in roots for p in r.rglob("transcript.txt")})
GRIDISH = re.compile(r"^\s*(?:(?:row|r)\s*)?\d*\s*[:=]?\s*[\[\(]?\s*\d(?:(?:\s*,\s*|\s*)\d){3,}\s*[\]\)]?\s*,?\s*$", re.I)
def blocks(f):
    txt = f.read_text(encoding="utf-8", errors="replace").split("\n")
    i = 0
    while i < len(txt):
        if txt[i].startswith("[TOOL RESULT: python]"):
            j = i + 1
            while j < len(txt) and not re.match(r"^\[(ANALYZER|MODEL|TOOL CALL|USER|SYSTEM|ASSISTANT)", txt[j]):
                j += 1
            yield txt[i + 1:j]; i = j
        else:
            i += 1
def leaked(blk, rx):
    """rows of a grid-like run (>= 6 GRIDISH lines, show() rows excluded) that rx does not hide"""
    n, k, fmt = 0, 0, collections.Counter()
    while k < len(blk):
        m = k
        while m < len(blk) and len(blk[m]) <= 600 and GRIDISH.match(blk[m]) and "|" not in blk[m][:6]:
            m += 1
        if m - k >= 6:
            # the guard collapses runs of >= 6 consecutive rx matches
            run, a = blk[k:m], 0
            while a < len(run):
                b = a
                while b < len(run) and rx.match(run[b]):
                    b += 1
                if b - a >= 6:
                    a = b
                else:
                    n += 1; fmt[re.sub(r"\d+", "9", run[a].strip())[:14]] += 1; a += 1
            k = m
        else:
            k += 1
    return n, fmt
for tag, sel in (("G4B rev 6d", lambda f: "rev6d_EVAL12R6G4B" in str(f)), (f"all {len(files)}", lambda f: True)):
    for name, rx in (("rev 6e regex", OLD), ("widened", NEW)):
        tot, br, fm = 0, set(), collections.Counter()
        for f in files:
            if not sel(f):
                continue
            for blk in blocks(f):
                n, fmt = leaked(blk, rx)
                if n:
                    tot += n; br.add(f.parent.name + "@" + f.parts[-4]); fm.update(fmt)
        print(f"{tag:11s} {name:13s}: {tot:5d} grid rows reach the model, {len(br)} branches; top formats {fm.most_common(4)}")
