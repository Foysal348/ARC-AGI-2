"""Rev 6e self-audit: scan every recorded transcript's python tool results for runs (>= 6 lines) of grid-like rows that
the rev 6e guard (arc2_duck._GRID_ROW_RE) does NOT catch. Broad detector: >= 4 single-digit cells and the line is mostly
digits / separators. Reports the leaked formats with samples."""
import re, sys, collections
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent / "duck_arc2"))
import arc2_duck as A
roots = [Path(__file__).resolve().parent.parent.parent / "runs"]   # the bundle has the 64 transcripts of 4 runs; our full scan also read 85 more from the experiment folder (149)
files = sorted({p.resolve() for r in roots for p in r.rglob("transcript.txt")})
def broad(ln):
    s = ln.strip()
    if not s or len(s) > 600 or s.startswith("r") and "|" in s[:6]:
        return False
    cells = re.findall(r"(?<!\d)\d(?!\d)", s)
    joined = re.search(r"\d{8,}", s)
    frac = sum(ch.isdigit() or ch in " ,[]()|:=-" for ch in s) / len(s)
    return (len(cells) >= 4 or joined) and frac >= 0.8
leak = collections.Counter(); samples = {}; blocks = 0; caught = 0
for f in files:
    txt = f.read_text(encoding="utf-8", errors="replace").split("\n")
    i = 0
    while i < len(txt):
        if txt[i].startswith("[TOOL RESULT: python]"):
            j = i + 1
            while j < len(txt) and not re.match(r"^\[(ANALYZER|MODEL|TOOL CALL|USER|SYSTEM|ASSISTANT)", txt[j]):
                j += 1
            blk = txt[i + 1:j]; blocks += 1
            k = 0
            while k < len(blk):
                m = k
                while m < len(blk) and broad(blk[m]):
                    m += 1
                if m - k >= 6:
                    miss = [l for l in blk[k:m] if not A._GRID_ROW_RE.match(l)]
                    caught += (m - k) - len(miss)
                    if len(miss) >= 6:
                        key = re.sub(r"\d", "9", miss[0].strip())[:40]
                        leak[key] += len(miss)
                        samples.setdefault(key, (f.parent.name, f.parts[-4] if len(f.parts) > 4 else "", miss[0][:120]))
                    k = m
                else:
                    k += 1
            i = j
        else:
            i += 1
print("transcripts", len(files), "tool-result blocks", blocks, "rows in runs caught by the guard", caught)
print("uncaught grid-like rows in runs of >= 6:", sum(leak.values()))
for k, n in leak.most_common(30):
    print(n, repr(k), samples[k])
