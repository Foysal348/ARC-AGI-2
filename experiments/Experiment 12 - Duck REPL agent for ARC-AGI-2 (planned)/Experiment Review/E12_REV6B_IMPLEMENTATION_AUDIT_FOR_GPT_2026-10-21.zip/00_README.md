# E12 rev 6b: implementation audit bundle (2026-10-21)

**What this is.** This is the second build of rev 6 of the Experiment 12 Duck REPL agent for ARC-AGI-2:
- Qwen3.8-27B RedHat INT4 with a BF16 DFlash2 drafter, on SGLang 0.5.21;
- Kaggle 4×L4, 12 h, 240 hidden tasks.

**How 6b came about.** After the first rev 6 build, the user asked me to check every row of the "problem → fix map" (`docs/problem_to_fix_map_bn.md`, in Bengali) against the code, add whatever was missing, and validate again.
- 6b adds the missing parts and two scheduler fixes found while doing so.
- Your two plan reviews asked for four things before a GPU GO: the diff, regressions, the scheduler simulation and GPU readiness. All four are here.

**Status:** nothing has run on GPU and nothing is pushed. The notebook is `notebook/Q27-XHIGH-E12_DUCK_REPL_SGLANG_EVAL12R6.ipynb`, sha256 `fe51d1d4…`.
- Dual mode: commit = 12 eval tasks; competition rerun = all hidden tasks.
- It supersedes the rev 6 build `cef11ad3` audited in the previous bundle.

## Files

| Path | What |
|---|---|
| `source/arc2_duck.py` | Adapter, rev 6b. All rev 6 code sits behind `E12_ARC2_REV6=1`. |
| `source/arc2_duck_rev6a.py`, `source/arc2_duck_rev5.py` | The first rev 6 build and the rev 5 adapter. |
| `source/arc2_duck.rev6a_to_rev6b.diff` (530 lines) | **What changed in 6b. Start here.** |
| `source/arc2_duck.rev5_to_rev6b.diff` | The full rev 6 change. |
| `source/build_e12_duck.py` + `*.diff` | The notebook builder and its diffs (rev 6a→6b, rev 5→6b). |
| `tests/smoke_rev6.py` + `_out.txt` | 91 checks, including the scheduler simulations. |
| `tests/smoke_rev5_out.txt`, `tests/smoke_adapter_out.txt` | Rev 5 (56/56) and flag-off (41/41) regressions. |
| `tests/regex_check.py`, `tests/facts_size.py` + `_out.txt` | Grid-row regex check; facts size on the 120 eval tasks with the Qwen tokenizer, plus a hash-seed determinism check. |
| `tests/harness_e12_rev4_nb.py`, `tests/fake_sgl_duck_server.py`, `tests/h10_EVAL12R6_*.txt` | The real notebook cells against a fake SGLang server: r6 41/41, rerun 22/22, launchfail 6/6. |
| `tests/replay_rev6.py`, `tests/replay_rev6b_{rev4,xhigh,low}.jsonl` | Every recorded GPU tool call of three earlier runs, replayed through the 6b agent in the real sandbox. |
| `docs/E12 next fix list (running, 2026-10-20).md` | The full fix list. The sections "Rev 6 implementation" and "Rev 6b" are the build records. |
| `docs/E12 rev 6 prompt and resume drafts from GPT (verbatim, 2026-10-21).md` | Your drafts, verbatim. |

## What 6b adds

The IDs are the fix list's R6 IDs.

- **R6-S3 fair share** (missing in 6a, where a stage-2 branch ran to the 100k cap while others waited).
  - A stage-2 run pauses softly at a request boundary after max(24,576, share) tokens.
  - share = measured aggregate tok/s × usable time left / items still to serve.
  - A paused run is re-queued **round robin**: fewer stage-2 rounds first, then the evidence class, the overfit flag, then ORDER2.
  - A pause is not a cut. The same agent object resumes while time remains, up to 100k per branch.
  - Overshoot past each pause and the re-prefill of each resume are recorded.
- **R6-D3 trim order.** Duck always drops the oldest user-delimited block. Now the oldest complete block with no tool result (a reasoning-only reply) is dropped first. Blocks are removed whole, so a call and its result are never split, and the newest block is never dropped.
- **T7.** Inside stage-2 class 2 (exactly one verified prediction), a task whose candidate carries an overfit sign gets branch 1 first.
- **R6-M1 label-free overfit signs** on every host-verified candidate. They use only the candidate source, the train data and the candidate's own test predictions, never the truth.
  - Signs: train-output row literal, fixed offset, offset tied to the train dimensions, test output equal to its input, test shape or palette outside the train pattern, source longer than 9,000 characters.
  - They are never used to reject a candidate.
- **R6-M1 report additions:**
  - facts tokens;
  - hand-reading (grid-row), digit and repeat (loop) shares of reasoning;
  - redefinition share;
  - infrastructure errors;
  - reasoning-only trims;
  - cross-branch agreement;
  - branch-1 yield by stage-2 class;
  - overshoot;
  - re-prefill per resume;
  - estimate vs actual prompt tokens;
  - uncached prompt vs generated tokens;
  - the real running maximum and acceptance length from the decode log.
- **R6-V2 / Q-5 facts size.** On the 120 eval tasks the 6a block was p50 1,237 / p90 1,752 Qwen tokens; both plan reviews agreed on 600–800 first.
  - Now the block is token-bounded with four levels and an explicit "omitted for size: call inspect_pair / inspect_test" note: **p50 736, p90 837, max 1,396**.
  - It is smaller than the raw grid text on 120/120 tasks and identical under three PYTHONHASHSEED values.
- **R6-V3 `object_diff(a, b)`.** A trusted helper that classifies objects as kept, recolored, moved (with its offset), removed or added (the donor `compute_frame_diff` idea). Also `inspect_pair(i, 'objects')`.
- **R6-K2.** Sandbox time and memory stops are labelled as harness limits, not as verdicts on the rule.
- **R6-X1 parity control.** The same request twice at T 0, batch size 1, recorded in the preflight. Target-only parity needs its own server launch and is not run in production.
- **New tests:**
  - the P4 deadline set: a request hanging at the server ends at the deadline with its record written; a worker exception ends only its branch; paused branches keep their candidates in the final snapshot;
  - Q-3: a transform calling an unavailable global is never a candidate;
  - 2 exact pairs + 1 timeout → rejected;
  - R6-D2 prefix invariant in the fake server (request n+1 = request n + its reply).

## Two defects I made while building 6b, and fixed before the tests passed

1. **A paused branch could be re-queued while still running, so two workers drove one Duck agent.** A negative control without the fix shows 24 concurrent entries. Two tests now guard against it: an analyze-reentry check in the simulation, and the prefix invariant in the fake server.
2. **The first fair-share draft starved later tasks.** Re-queued items kept their ORDER2 rank. With round robin, 30 of 30 tasks get stage-2 work (24k–72k tokens each). Without fair share only 3–4 tasks do, and one of them took 792k.

## Regressions

- **Rev 4 EVAL6:** 7/8 inputs, including 4c3d4a41 2/2 (the recorded run had 4/8).
- **Rev 5 xhigh:** 5/8; **rev 5 low:** 10/19. Both equal the 6a replay.
- On every branch, candidates kept by 6b ≥ those kept by rev 5.
- The Kaggle-run notebooks are byte-identical.

## Not built (the user decides)

- **Gate 4b**, a hidden-equivalent-compute eval profile at about 43k tokens per task. It would cut thinking below the user's 60k floor.
- **A p90 last-admission cutoff.** Requests and verifications are already clamped to the deadline, and the cutoff would drop late coverage.
- **Target-only parity**, which needs a second launch.
- **Engine-side settings are unchanged:** 56 mamba slots for 10 streams; the CUDA-graph batch list pads 9 to 10. The report now records the real running maximum, so this can be verified on GPU.

## Questions for you

1. **6a → 6b diff.** Is the round robin with soft pauses safe? Specifically:
   - Can it starve stage 1? (Stage 2 waits until every stage-1 start has been admitted.)
   - Can it lose a candidate?
   - Can a session ever be queued twice? (The `active` / `queued` sets exist to prevent this.)
2. **Fair-share defaults.** Is a 24,576-token minimum chunk right, given that each resume pays its uncached re-prefill (now measured)? Would you raise it?
3. **D3.** Does dropping a middle reasoning-only block instead of the oldest block break any Duck invariant?
   - Duck's `_drop_until_first_user_message` still runs after it.
   - The truthful-trim rewrite marks the newest opener.
4. **Overfit signs.** Are these signs sensible label-free warnings? Should any of them change the stage-2 order beyond class 2?
5. **GPU readiness.** Is anything still blocking a GO for one EVAL12R6 GPU run?
