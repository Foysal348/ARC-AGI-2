"""R6-V2 / Q-5: facts-block size on all 120 eval tasks with the Qwen INT4 tokenizer (p50/p90/p99, bounded vs full),
plus the raw-grid text it replaces. Determinism check (R6-D2): the facts text must not depend on PYTHONHASHSEED."""
import json
import os
import statistics
import subprocess
import sys
from pathlib import Path

E12 = Path(r"D:/ARC AGI 2/experiments/Experiment 12 - Duck REPL agent for ARC-AGI-2 (planned)")
sys.path.insert(0, str(E12 / "duck_arc2"))
os.environ.setdefault("E12_ARC2_REV6", "1")
import arc2_duck as A  # noqa: E402
from tokenizers import Tokenizer  # noqa: E402

HERE = Path(__file__).resolve().parent
tok = Tokenizer.from_file(str(HERE.parent / "e12_harness/fixtures/tok_int4/tokenizer.json"))
ch = json.load(open(HERE.parent / "e12_harness/fixtures/data/arc-agi_evaluation_challenges.json", encoding="utf-8"))
n = lambda s: len(tok.encode(s).ids)
rows = []
for tid, t in sorted(ch.items()):
    full, bounded = A.arc2_facts(t, lists=True), A.arc2_facts_bounded(t)
    raw = "".join(A.grid_rows(p["input"]) + A.grid_rows(p["output"]) for p in t["train"]) + "".join(
        A.grid_rows(q["input"]) for q in t["test"])
    rows.append((tid, n(full), n(bounded), n(raw), bounded != full))


def pct(v, q):
    v = sorted(v)
    return v[min(len(v) - 1, int(q * len(v)))]


for label, k in (("facts full", 1), ("facts bounded (shipped)", 2), ("raw grid text (rev 5 prompt)", 3)):
    v = [r[k] for r in rows]
    print(f"{label:30s} n={len(v)} p50={pct(v, .5)} p90={pct(v, .9)} p99={pct(v, .99)} max={max(v)} mean={statistics.mean(v):.0f}")
print("tasks where the lists were dropped:", sum(r[4] for r in rows), "of", len(rows))
print("bounded > 800 tokens:", sum(r[2] > 800 for r in rows), "| > 1500:", sum(r[2] > 1500 for r in rows))
print("bounded smaller than raw grids:", sum(r[2] < r[3] for r in rows), "of", len(rows))
# R6-D2: deterministic under different hash seeds
code = ("import sys,json,os,hashlib;sys.path.insert(0,%r);os.environ['E12_ARC2_REV6']='1';import arc2_duck as A;"
        "ch=json.load(open(%r,encoding='utf-8'));"
        "print(hashlib.sha256(''.join(A.arc2_facts_bounded(ch[t])+A.task_prelude_r6(ch[t]) for t in sorted(ch)).encode()).hexdigest())"
        % (str(E12 / "duck_arc2"), str(HERE.parent / "e12_harness/fixtures/data/arc-agi_evaluation_challenges.json")))
hs = set()
for seed in ("0", "1", "12345"):
    env = dict(os.environ, PYTHONHASHSEED=seed)
    hs.add(subprocess.run([sys.executable, "-c", code], env=env, capture_output=True, text=True).stdout.strip())
print("R6-D2 facts + prelude identical under PYTHONHASHSEED 0/1/12345:", len(hs) == 1 and "" not in hs, sorted(hs)[0][:16])
