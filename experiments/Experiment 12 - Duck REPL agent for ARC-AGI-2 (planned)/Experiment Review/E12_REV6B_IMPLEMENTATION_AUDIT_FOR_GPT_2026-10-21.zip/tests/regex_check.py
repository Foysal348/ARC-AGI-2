"""Check _GRID_ROW_RE: same classification as the old pattern on normal rows, linear time on pathological lines."""
import re
import time

src = open(r"D:/ARC AGI 2/experiments/Experiment 12 - Duck REPL agent for ARC-AGI-2 (planned)/duck_arc2/arc2_duck.py",
           encoding="utf-8").read()
NEW = re.compile(re.search(r'_GRID_ROW_RE = re\.compile\(r"(.*?)"\)\n', src).group(1))
OLD = re.compile(r"^\s*[\[\(]*\s*\d+(\s*,?\s+\d+|\s*,\s*\d+){3,}\s*[\]\)]*\s*,?\s*$|^\s*\d{8,}\s*$")
cases = {"0 1 2 3": 1, "[0, 1, 2, 3],": 1, "  [1,2,3,4]": 1, "(1, 2, 3, 4)": 1, "12345678": 1, "0 1 2": 0,
         "r00 | 1 2 3 4": 0, "a 1 2 3 4": 0, "1 2, 3 4": 1, "[[1, 2, 3, 4], [5": 0, "1 ,2 , 3,4": 1,
         " ".join(["7"] * 30): 1, str(list(range(10, 40))): 1, "0 1 2 3 x": 0}
ok = True
for c, e in cases.items():
    n, o = bool(NEW.match(c)), bool(OLD.match(c))
    good = n == bool(e) and n == o
    ok &= good
    print("PASS" if good else "FAIL", repr(c[:40]), "new", n, "old", o)
for t in (str([[0] * 30 for _ in range(30)]), "[" + ", ".join(["0"] * 2000) + "] x", "0 " * 5000 + "x",
          "[" + ", ".join(["0"] * 25) + "], [1"):
    t0 = time.time()
    NEW.match(t)
    dt = time.time() - t0
    ok &= dt < 0.05
    print("PASS" if dt < 0.05 else "FAIL", "len", len(t), "sec", round(dt, 4))
print("ALL OK" if ok else "SOME FAIL")
