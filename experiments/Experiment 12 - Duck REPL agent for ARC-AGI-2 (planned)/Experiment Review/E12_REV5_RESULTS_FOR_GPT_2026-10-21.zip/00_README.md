# E12 rev 5 results (Duck REPL agent, Qwen3.8-27B INT4 + DFlash2 on SGLang, 4xL4): analysis request (2026-10-21)

## Ask

Analyse the two rev 5 runs below and advise what to change next to reach **full 240-task coverage at high accuracy in 12 h**.

- **Premise (from the user):** the top ARC-AGI-2 teams use Qwen3.8 + an optimized Duck harness with full coverage, at 70-88 LB.
- **What to propose:** concrete, evidence-based changes for one bundled next run, so that it closes the gap.
- **For every claim:** say whether it is measured (file:line or numbers from this bundle) or inferred.

## What ran

| Run | Folder | Setup |
|---|---|---|
| **EVAL6R5 (xhigh)** | `runs/EVAL6R5_xhigh_q27x/` | rev 5, xhigh (model default), 6 tasks |
| **EVAL12R5_LOW (low)** | `runs/EVAL12R5_low_q27x/` | rev 5, `reasoning_effort` low, 12 tasks = the same 6 + 6 more |
| Baseline: rev 4 EVAL6 (xhigh) | `runs/EVAL6_rev4_xhigh_q27x/` | before the rev 5 fixes |

**Rev 5** (details in `docs/E12 next fix list (running, 2026-10-20).md`):
- **B1 harvest:** every `check()` that is exact on all pairs is host-verified and kept as a candidate; no auto-stop.
- **B2 selection:** two attempts from distinct verified candidates.
- **B3 token estimate:** reasoning counted with the tokenizer.
- **B4 truthful resume.**
- **B5 output:** 49,152 per request.
- **B6 cut calls:** a tool call cut at the output limit is not executed.
- **B7/B8 prompt edits.**
- **Temperature 1.0.**
- **R5-1..5 audit fixes:** serializer guard, markup recovery blocked, forced-reduce resume, tokenizer status, estimate metric.

**Unchanged:**
- 6 live branches = 6 streams; 2 branches per task;
- 100k soft cap per branch;
- Duck context window 131,072;
- request timeout 1,800 s.

The notebooks are in `notebooks/`, the adapter and the vendored Duck in `adapter/`.

## Results (`docs/E12 rev 5 runs analysis (2026-10-21).md`, `analysis/rev5_analysis_output.txt`)

| Run | Inputs | Fully solved | Task-norm | Accepted branches | Generated tokens | Per branch | Solve time |
|---|---|---|---|---|---|---|---|
| rev 4 EVAL6 xhigh | 4/8 | 3/6 | 50.0 % | 4/12 | 1,217,904 | 101k | 62 min |
| **EVAL6R5 xhigh** | **5/8** | **4/6** | **66.7 %** | 9/12 | 846,080 | 70.5k | 58 min |
| **EVAL12R5_LOW** | **10/19** | **7/12** | **58.3 %** | 17/24 | 1,743,889 | 72.7k | 110 min |

**What the fixes did:**
- **attempt_2:** 3 of 5 xhigh hits came from attempt_2 (before rev 5: 0 of 56).
- **Loops:** repeated-line share 0-3 % (rev 4: 29 %).
- **Prompt-estimate error:** median +0.4 %.
- **Errors:** 0 timeouts, 0 cut calls.
- **Tokenizer:** loaded in both runs.

**Problems:**
- **Overfit:** 4c3d4a41 (both runs: every branch accepted a train-exact, test-wrong program), plus b5ca7ac4 and 62593bfd in low.
- **Low is not cheaper per branch:** 72.7k vs 70.5k; it makes more, shorter requests.

## The coverage gap (measured)

- **Speed:** about 9-10 min per task (2 branches, about 141-145k tokens per task).
- **Need:** 240 tasks in about 11.3 h requires about 2.8 min per task, so we are about **3.4x** short.
- **Throughput:** 244 tok/s (xhigh) and 265 (low) overall vs 325 in rev 4.
  - Uncached prefill ≈ generated tokens (0.97M vs 0.85M in xhigh).
  - The small-run tail has 1-5 running.
- **Context per request (prompt + reply):** p50 46-58k, p90 about 75k, max 95-115k.
  - 10 streams fit the KV of 866,744 at p90; 12 fit at p50.
  - Measured earlier: 6 → 12 running gives 368 → 431 tok/s.
- **Branch tokens:** failed branches burn 105-115k (soft cap); accepted ones finish at 14-98k.
- **Discussion references** (`discussions/`):
  - Kris Dreemurr: about **35k tokens per attempt** (70k per task, pass@2) → about 45 % in CV.
  - mikelou1: 87 % CV "at around 4xL4 speed", LB 66.39.
  - Daniel Franzen (author of this Duck fork): LB 57.64.

## Questions

1. What explains the 3.4x gap: tokens per attempt (70k vs about 35k), throughput (6 streams, prefill share), or both? Which levers are worth most?
2. Concurrency: 10 or 12 streams given the measured context distribution? Any Duck setting to keep contexts smaller without losing the B3 gain (drain, history turns)?
3. Per-branch budget: how to cut failed branches (105-115k) without losing late accepts (88-98k)? Any signal in the transcripts that separates them early?
4. Overfit (4c3d4a41 etc.): what in the transcripts would let selection or the prompt avoid these accepts without new expensive judges?
5. xhigh vs low: on the shared 6 tasks xhigh got 4/6, low 3/6, union 5/6, with similar tokens. Would mixing (e.g. branch 0 xhigh, branch 1 low) be justified by this data?
6. Anything in the transcripts (`runs/*/duck/*/transcript.txt`, full thinking) that shows where tokens are still wasted?

## Files

| Path | What |
|---|---|
| `runs/` | Three runs: `e12_run_report.json`, `e12_generated_attempts.json`, `submission.json`, SGLang logs, `duck/<task>_b<k>/transcript.txt` + `branch_result.json` (per-request usage, harvested candidates, `rev5_events` with prompt estimates) |
| `data/eval_challenges_12.json`, `eval_solutions_12.json` | The 12 tasks with truth |
| `analysis/` | `rev5_analysis.py` + output; earlier EVAL6 analysis |
| `docs/` | Rev 5 runs analysis, EVAL6 rev 4 analysis, weakness analysis, fix list (every validation table) |
| `discussions/` | Kaggle threads read 2026-10-21 + summary |
| `notebooks/`, `adapter/` | The notebooks that ran; adapter + vendored Duck |
