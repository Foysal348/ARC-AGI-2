"""E12 (Duck REPL agent on the E11-06 SGLang W1 engine): QUICK_SAVE (no run) or --commit. Variant: SMOKE1 (default) | --eval30.
Push only after the user's go. Account = the one in the credentials used (default ~/.kaggle -> foysalemonshanto);
pass --owner <name> to assert a different account. L4 x4, internet OFF, pinned image (= S49 / E11-04).
--check-only: account, inputs and quota only."""
import hashlib, json, os, sys
from pathlib import Path

ESFER = "--esfer" in sys.argv               # esfersami50 (token read in-process, never printed; = push164)
if ESFER:
    os.environ["KAGGLE_API_TOKEN"] = Path(r"C:/Users/hp/.kaggle-esfer/access_token").read_text().strip()
COMMIT = "--commit" in sys.argv             # SAVE_AND_RUN_ALL (commit run) instead of QUICK_SAVE

from kaggle.api.kaggle_api_extended import KaggleApi
from kagglesdk import KaggleClient
from kagglesdk.kernels.types.kernels_api_service import ApiSaveKernelRequest
from kagglesdk.kernels.types.kernels_enums import KernelExecutionType

VARIANT = "EVAL30" if "--eval30" in sys.argv else "SMOKE1"
NB = (r"D:/ARC AGI 2/experiments/Experiment 12 - Duck REPL agent for ARC-AGI-2 (planned)/Experiment Notebooks/"
      f"Q27-XHIGH-E12_DUCK_REPL_SGLANG_{VARIANT}.ipynb")
EXPECT_SHA = sys.argv[sys.argv.index("--sha") + 1] if "--sha" in sys.argv else None
OWNER = "esfersami50" if ESFER else "foysalemonshanto"
SLUG = f"{OWNER}/q27-xhigh-e12-duck-repl-sglang-{VARIANT.lower()}"
TITLE = f"Q27 XHIGH E12 Duck REPL SGLang {VARIANT}"
MODELS = ["foysalemonshanto/qwen3-8-27b-int4-redhat/PyTorch/w4a16-g128/1",      # = E11-04
          "foysalemonshanto/qwen3-8-27b-dflash2/PyTorch/bf16/1",                # = E11-04
          "foysalemonshanto/qwen3-8-27b-fp8-repacked-v1/PyTorch/hf-fp8/1"]      # = S49 (tokenizer + fallback)
DATASETS = ["foysalemonshanto/sglang-0-5-21-cu13-wheelhouse",                   # = E11-04
            "mirzamilanfarabi/arc3-vllm-h100-wheelhouse-v3"]                    # = S49
DOCKER = "gcr.io/kaggle-private-byod/python@sha256:37c64f7dd9c54116ecd1bcc88817c5469b88387388fade02bfa8bf3fc647d461"

api = KaggleApi(); api.authenticate()
ok = True
owners = sorted({str(getattr(k, "ref", "")).split("/")[0] for k in api.kernels_list(mine=True, page_size=5)})
print("authenticated kernels owner(s):", owners)
if owners and owners != [OWNER]:
    ok = False; print("WRONG ACCOUNT, expected", OWNER)
for m in MODELS:
    try:
        api.model_instance_get(m.rsplit("/", 1)[0]); print("model OK", m)
    except Exception as e:
        ok = False; print("model ERR", m, repr(e)[:160])
for d in DATASETS:
    try:
        files = api.dataset_list_files(d)
        print("dataset OK", d, len(getattr(files, "files", None) or []), "files")
    except Exception as e:
        ok = False; print("dataset ERR", d, repr(e)[:160])
try:
    q = api.quota_view().gpu_quota
    print("gpu quota used h", round(q.time_used.total_seconds() / 3600, 2), "of", round(q.total_time_allowed.total_seconds() / 3600, 2))
except Exception as e:
    print("quota ERR", repr(e)[:120])
raw = open(NB, "rb").read(); text = raw.decode("utf-8"); json.loads(text)
sha = hashlib.sha256(raw).hexdigest()
print("notebook sha256", sha[:16], "OK" if (EXPECT_SHA and sha == EXPECT_SHA) else "MISMATCH / not given (--sha)")
if not EXPECT_SHA or sha != EXPECT_SHA:
    ok = False
if not ok or "--check-only" in sys.argv:
    sys.exit(0 if ok else 1)
r = ApiSaveKernelRequest()
r.slug = SLUG
r.new_title = TITLE
r.text = text; r.language = "python"; r.kernel_type = "notebook"
r.is_private = True; r.enable_gpu = True; r.enable_tpu = False; r.enable_internet = False
r.machine_shape = "NvidiaL4"
r.model_data_sources = MODELS
r.dataset_data_sources = DATASETS
r.kernel_data_sources = []
r.competition_data_sources = ["arc-prize-2026-arc-agi-2"]
r.docker_image = DOCKER
r.docker_image_pinning_type = "original"
r.kernel_execution_type = KernelExecutionType.SAVE_AND_RUN_ALL if COMMIT else KernelExecutionType.QUICK_SAVE
with KaggleClient() as cl:
    resp = cl.kernels.kernels_api_client.save_kernel(r)
print("saved" + (" + commit run queued:" if COMMIT else " (quick save):"), r.slug, "version", getattr(resp, "version_number", None), "url", getattr(resp, "url", None),
      "error", getattr(resp, "error", None))
