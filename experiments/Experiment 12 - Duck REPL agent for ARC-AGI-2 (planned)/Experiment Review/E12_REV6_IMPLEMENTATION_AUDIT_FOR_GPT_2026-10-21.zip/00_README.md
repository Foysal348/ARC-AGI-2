# E12 rev 6: implementation audit bundle (2026-10-21)

**What this is.** This bundle is the built rev 6 of the Experiment 12 Duck REPL agent for ARC-AGI-2:
- Qwen3.8-27B RedHat INT4 with a BF16 DFlash2 drafter, on SGLang 0.5.21;
- Kaggle 4×L4, 12 h, 240 hidden tasks.

Your two plan reviews (P1–P10, Q-1..Q-6) asked for four things before a GPU GO: the source diff, regressions, the scheduler simulation and GPU readiness. They are all here.

Nothing has run on GPU and nothing is pushed.

## Files

| Path | What |
|---|---|
| `notebook/Q27-XHIGH-E12_DUCK_REPL_SGLANG_EVAL12R6.ipynb` | The notebook to run (sha256 `cef11ad3…`). Dual mode: commit = the 12 eval tasks below; competition rerun = all hidden tasks. |
| `source/arc2_duck.py` | The rev 6 adapter (all rev 6 code behind `E12_ARC2_REV6=1`; rev 5 stays on under rev 6). |
| `source/arc2_duck_rev5.py` | The adapter before rev 6. |
| `source/arc2_duck.rev5_to_rev6.diff` | Unified diff of the two. |
| `source/build_e12_duck.py`, `source/build_e12_duck.diff` | The notebook builder and its rev 6 diff (rev 6 `once()` patches in CELL 6/7, the `EVAL12R6` profile and knobs). |
| `tests/smoke_rev6.py` + `_out.txt` | 68 unit/integration checks plus the scheduler simulation (240 fake tasks, 12,000 requests). |
| `tests/smoke_rev5_out.txt`, `tests/smoke_adapter_out.txt` | Rev 5 regressions (56/56) and flag-off regressions (41/41). |
| `tests/harness_e12_rev4_nb.py`, `tests/fake_sgl_duck_server.py` | Run the real notebook cells against a fake SGLang server. |
| `tests/h9_EVAL12R6_{r6,rerun,launchfail}.txt` | Harness logs: 37/37, 22/22, 6/6. |
| `tests/replay_rev6.py`, `tests/replay_rev6_{xhigh,low}.jsonl` | Replay of every recorded rev 5 GPU tool call through the rev 6 agent. |
| `tests/regex_check.py` | Equivalence and linear-time check of the new grid-row regex. |
| `docs/E12 next fix list (running, 2026-10-20).md` | The full running fix list. The last section, "Rev 6 implementation", is the build record; "Rev 6 gap check" has the R6-xx ID map. |
| `docs/E12 rev 6 prompt and resume drafts from GPT (verbatim, 2026-10-21).md` | Your drafts, verbatim. |

## What rev 6 changes

The change IDs come from the fix list's ID map.

**Views, prompt and helpers (R6-V, R6-P)**
- A deterministic facts block goes into the system prompt. Branch 0 sees facts only; branch 1 sees grids plus facts.
- 12 trusted helpers (`components`, `bbox`, `crop`, `diff_summary`, …) are injected as retained sources. This fixes T1: a `transform` that calls a helper is still retained and verified.
- An ARC-2 grid-print guard.
- A merged short prompt and state-aware resume openers.

**Checking and candidates (R6-K)**
- Auto-check of `transform*`, `solve*`, `*_alt` and `*_vN` functions that take one grid argument, so a candidate is saved without `check()` or `submit()`.
- `check` prints its verdict first; `check_many` checks several functions at once.
- A verify cache keyed by the dependency-closure hash, dedupe by output signature, and separate caps.

**Scheduler and time (R6-S)**
- `BranchSession` pauses and resumes the same agent.
- Stage 1 gives every task's branch 0 a first exposure of 28k tokens. Stage 2 is then ordered by evidence class.
- A capacity probe drops workers from 10 by 2 at a time when the server queue grows (floor 6).
- The deadline is clamped per request (the T8 root cause) and per verification.

**Caps and context (R6-Q, R6-D)**
- Request caps: 12,288 until a Python call succeeds, then 24,576; 32,768 after two consecutive no-call cuts.
- Duck's reply reserve and context budget are re-derived from the same cap.
- The context window is 0.9 × KV / 10 streams.

**Preflight and metrics (R6-X1, R6-M1)**
- A preflight reads the drafter config and runs a 10-request isolation smoke.
- A metrics contract is written to `report["rev6"]`.

## Three defects found during testing (fixed; each now has a test)

1. **Exponential regex backtracking.** The old `_GRID_ROW_RE` separators `(\s*,?\s+\d+|\s*,\s*\d+)` overlap, so a long non-matching `print(grid)` line hung `guard_grid_prints`. The smoke hung for more than 11 minutes, and on Kaggle this would freeze an agent thread.
   - New pattern: disjoint separators `(?:\s*,\s*|\s+)\d+`; lines longer than 600 characters skip the regex.
   - Same verdicts on 14 row forms; under 6 ms on 10k-character lines.
2. **Wrong opener after a rejected `submit`.** A rejected submit is an executed step, so Duck starts a new turn without the resume flag, and rev 6 sent the first-turn text. Now a `rejected` opener names the host's reason.
3. **The caps metric counted trimmer calls, not requests.** It is now counted once per request. The harness checks it against the server's histogram.

## Evidence that nothing regressed

- **Replay of the real rev 5 GPU tool calls** (model output fixed, agent swapped to rev 6):
  - xhigh: 5/8 inputs, the same as rev 5;
  - low: 10/19, the same as rev 5;
  - on every branch, candidates kept by rev 6 ≥ those kept by rev 5 (+1 on 9385bd28_b0 via auto-check).
- **Flag-off tests:** the adapter smoke (41/41) and the rev 5 smoke (56/56) pass with the rev 6 file.
- **Kaggle-run notebooks:** byte-identical (sha checked after every build).

## Capacity (pre-run check for EVAL12R6)

- Rev 5 low generated 1.744M tokens in 6,570 s at 6 streams, about 265 tok/s.
- Rev 6 needs an expected ≈ 24 branches × 70k ≈ 1.7M tokens; the worst case is 24 × 100k = 2.4M.
- The solve window is 9,000 s.
- 10 resident histories × 79,320 fit in 0.9 × KV.
- 10-stream throughput is not yet measured on this stack.

## Questions for you

1. **Diff review.** Read `source/arc2_duck.rev5_to_rev6.diff` in full. Does any rev 6 path change behaviour when `E12_ARC2_REV6` is unset? Is any Duck invariant broken: retention, the prefix-cache-stable history, trimming, or yield/resume?
2. **Scheduler.**
   - Can `solve_all_r6` deadlock, starve stage 2, or leave a session un-written when the deadline hits mid-request?
   - Is the capacity probe's workers −2 rule safe when the queue is transient?
3. **Auto-check.** Can auto-check harvest a function that is train-exact only by leaking `train` (for example through a closure or a default argument)? The rule: the read set comes from the AST closure, and functions that read `train` are rejected.
4. **Openers.** Is the precedence (cut > length > timeout > verified/partial > notool > continue; `rejected` on a new turn) right for every Duck exit path (`yield_bare`, `yield_tools`, `timeout`, `tool_steps`, submit)?
5. **GPU readiness.** What else must the first GPU run log so that we learn the most from one EVAL12R6 run?
