"""Rev 6 unit checks for arc2_duck (E12_ARC2_REV6=1), real Duck sandbox, no server. Our own scripted code only.
Covers the fix-list traps T1-T8 and items R6-V/P/K/S/Q/D (fix list 'Rev 6 gap check' + the two plan reviews)."""
import json
import os
import re
import sys
import threading
import time
from pathlib import Path

os.environ["E12_ARC2_REV6"] = "1"
os.environ["E12_DUCK_TEMPERATURE"] = "1.0"
os.environ["E12_CHECK_VERIFY_CAP"] = "6"
os.environ["E12_AUTOCHECK_CAP"] = "3"
os.environ["E12_DUCK_CONTEXT_WINDOW"] = "78000"
TOK = Path(r"D:/ARC AGI 2/_scratch/session_1c6db7aa/e12_harness/fixtures/tok_int4/tokenizer.json")
os.environ["E12_TOKENIZER_JSON"] = str(TOK)
_HERE = Path(__file__).resolve().parent
src = open(_HERE / "smoke_adapter.py", encoding="utf-8").read().split("# 1 system prompt carries the task")[0]
exec(src)                      # A, TA, DP, Agent, task (row flip), ag, run, expect, flip, tmp, state

# ------------------------------------------------------------------ R6-V2 facts (deterministic, shape-aware)
shape_task = {"train": [{"input": [[1, 1], [1, 2]], "output": [[1, 2, 3]]},
                        {"input": [[0, 3, 3], [0, 0, 0]], "output": [[0, 3, 3], [0, 0, 5]]}],
              "test": [{"input": [[2, 2], [0, 2]]}, {"input": [[7]]}, {"input": [[1, 0, 1]]}]}
f1 = A.arc2_facts(shape_task)
expect("facts: deterministic", f1 == A.arc2_facts(json.loads(json.dumps(shape_task))))
expect("facts: shape change -> no cellwise diff", "shape changed 2x2 -> 1x3" in f1 and "TRAIN 0" in f1, f1[:600])
expect("facts: same-shape pair -> changed cells + transitions", "changed cells 1" in f1 and "(0, 5, 1)" in f1, f1)
expect("facts: every test input covered (3)", all(f"TEST {j}" in f1 for j in range(3)))
expect("facts: 'modal', never 'background'", "modal" in f1 and "background" not in f1.lower())
os.environ["E12_R6_FACTS_MAX_CHARS"] = "200"
fb = A.arc2_facts_bounded(shape_task)
expect("facts: over the bound -> lists dropped with an explicit notice", "largest (color" not in fb and "omitted for size" in fb)
os.environ.pop("E12_R6_FACTS_MAX_CHARS")

# ------------------------------------------------------------------ R6-V1/P1 prompt
sp = ag._system_prompt
expect("V1: facts view has no raw grid rows", "Training pair 0 input:" not in sp and "ARC TASK FACTS" in sp)
gp = A.arc2_system_prompt_r6(task, DP, 3072, view="grids")
expect("V1 hedge: grids view shows the rows + facts", "Training pair 0 input:" in gp and "ARC TASK FACTS" in gp)
expect("P1: helpers + check_many + auto-check + submit-ends-branch described",
       all(s in sp for s in ("components(g", "check_many", "checks it automatically", "ends this branch", "crop(g, r0, c0, r1, c1)")))
bad = [w for w in (r"current_frame", r"action\(actions\)", r"\bgame\b", r"segmentation", r"Investigate first")
       if re.search(w, sp)]
expect("P1: no game words", not bad, bad)
expect("P1: rigid V3.1 stage text absent", "By your second Python execution" not in sp)

# ------------------------------------------------------------------ R6-V3 / T1 helpers usable inside transform
r, p = run("def transform(g):\n    return flip_h(crop(g, 0, 0, len(g) - 1, len(g[0]) - 1))\ncheck(transform)")
expect("T1: helper-using transform is retained", "transform" in (ag._kept_functions or {}), (ag._kept_functions, r.content[-600:]))
expect("T1: ... and host-verified as a candidate", len(ag.arc2_checked) == 1 and ag.arc2_checked[0]["accepted"], ag.arc2_checked)
expect("T1: trusted helpers stay hidden from the model's retained list",
       not (set(ag._kept_functions) & A.R6_HELPER_NAMES), sorted(ag._kept_functions))
r, p = run("print(grid_shape(train[0]['input']), len(components(train[0]['input'])))")
expect("T1: helpers available in later calls", "(2, 3)" in r.content, r.content[-300:])
r, p = run("def leak(g):\n    return [list(reversed(x)) for x in g] if g != train[0]['input'] else train[0]['output']\ncheck(leak)")
expect("T1: a function that reads `train` is still rejected", not any(v["name"] == "leak" and v["accepted"] for v in ag.arc2_checked),
       r.content[-500:])

# helpers correctness (trusted source executed on the host)
ns = {}
for s in A.R6_HELPER_SOURCES:
    exec(s, ns)
g8 = [[1, 0], [0, 1]]
expect("components: 4-conn splits a diagonal, 8-conn joins it",
       len(ns["components"](g8, color=1)) == 2 and len(ns["components"](g8, color=1, connectivity=8)) == 1)
expect("crop inclusive in bbox order", ns["crop"]([[1, 2, 3], [4, 5, 6]], 0, 1, 1, 2) == [[2, 3], [5, 6]])
expect("diff_summary: different shapes -> no invented diff", ns["diff_summary"]([[1]], [[1, 2]])["changed_cells"] is None
       and ns["diff_summary"]([[1]], [[1]])["changed_cells"] == 0 and ns["diff_summary"]([[1]], [[2]])["changed_cells"] == 1)
expect("rot90 clockwise", ns["rot90"]([[1, 2], [3, 4]]) == [[3, 1], [4, 2]])
expect("modal_color tie -> smallest", ns["modal_color"]([[3, 1], [1, 3]]) == 1)

# ------------------------------------------------------------------ R6-K2 check output + progress
r, p = run("def ident(g):\n    return g\ncheck(ident)")
expect("K2: verdict line first + identity flag + test inputs status",
       re.search(r"check\(ident\): 0/2 train pairs exact; returns the input unchanged on pair\(s\) \[0, 1\]; test inputs: ok, ok",
                 r.content) is not None, r.content[-500:])
r, p = run("def boom(g):\n    x = 1\n    return g[99]\ncheck(boom)")
expect("K2: an error names the function and its line", "(in boom, line 3)" in r.content, r.content[-500:])
expect("S4: progress recorded per single function", ag.arc2_progress["runs"] >= 3
       and ag.arc2_rev6_events["first_check_tokens"] is not None, ag.arc2_progress)
best = ag.arc2_progress["best"]
expect("S4: best = the exact transform (identity scores 0 changed-cell accuracy)", best["name"] == "transform" and best["k"] == 2, best)

# ------------------------------------------------------------------ R6-K1 auto-check
n0 = len(ag.arc2_checked)
r, p = run("def transform2(g):\n    return [row[::-1] for row in g]")
expect("K1: transform2 defined without check -> auto-checked + harvested",
       "checked `transform2` automatically" in r.content and len(ag.arc2_checked) == n0 + 1, r.content[-600:])
expect("K3: same outputs as a saved candidate -> noted, no new distinct candidate",
       ag.arc2_checked[-1].get("dup_of") == "transform" and "equal the saved" in r.content, (ag.arc2_checked[-1], r.content[-400:]))
r, p = run("print(1)")
expect("K1: unchanged source -> no second auto-check", "automatically" not in r.content)
r, p = run("def rotate(g):\n    return [list(x) for x in zip(*g)]")
expect("K1: helper-like name (rotate) not auto-checked", "automatically" not in r.content)
r, p = run("def solve_two(g, k):\n    return g")
expect("K1: two required args -> not auto-checked", "automatically" not in r.content)
r, p = run("def transform_alt(g):\n    return [list(reversed(x)) for x in g] if len(g) > 1 else [[9] * len(g[0])]")
expect("K1: transform_alt auto-checked; distinct test outputs -> a second distinct candidate",
       "`transform_alt`" in r.content and ag.arc2_checked[-1]["accepted"] and "dup_of" not in ag.arc2_checked[-1]
       and len(ag._arc2_accepted_sigs) == 2, (ag.arc2_checked[-1], r.content[-500:]))
r, p = run("def transform2(g):\n    return [row[::-1] for row in g]\ncheck(transform2)")
expect("K3: re-check of an unchanged closure -> trusted verdict reused (no new verify)",
       ag.arc2_rev5_events["checks_skipped_dup"] >= 1 and len([v for v in ag.arc2_checked if v["name"] == "transform2"]) == 1)
r, p = run("def unrelated(x):\n    return x + 1\nprint(2)")
r, p = run("check(transform2)")
expect("K3: a new unrelated function does not change transform2's key", len([v for v in ag.arc2_checked if v["name"] == "transform2"]) == 1)
# auto cap = 3: transform2, transform_alt used 2; one more auto, then exhausted; explicit check still verifies
r, p = run("def transform_v2(g):\n    return [list(reversed(x)) for x in g]\n")
r, p = run("def transform_v3(g):\n    out = [list(reversed(x)) for x in g]\n    return out")
expect("K3: auto cap reached -> neutral note (no 'submit your best')", "limit of 3 automatic" in r.content
       and "submit your best" not in r.content, r.content[-500:])
r, p = run("check(transform_v3)")
expect("K3: explicit check still verifies after the auto cap", any(v["name"] == "transform_v3" for v in ag.arc2_checked),
       r.content[-400:])

# ------------------------------------------------------------------ R6-V4 grid print guard
r, p = run("for row in [[1, 2, 3, 4, 5]] * 12:\n    print(*row)")
expect("V4: a long grid print is collapsed with the note", "more grid rows not shown" in r.content
       and ag.arc2_rev6_events["grid_rows_suppressed"] >= 10, r.content[-400:])
r, p = run("print([[0] * 30 for _ in range(30)])")
expect("V4: one long nested-list line is cut", "(nested list)" in r.content, r.content[-300:])
_t0 = time.monotonic()
_g, _d = A.guard_grid_prints(("[" + ", ".join(["0"] * 100) + "], [1\n") * 3)
expect("V4: a near-row line (old pattern backtracked exponentially) is classified in linear time",
       time.monotonic() - _t0 < 1.0 and _d == 0, round(time.monotonic() - _t0, 3))
r, p = run("show(train[0]['input'])")
expect("V4: show() small crop allowed with indices", "r00 | 1 2 3" in r.content, r.content[-300:])
r, p = run("show([[0] * 30 for _ in range(30)])")
expect("V4: show() over the limit refused", "the limit is 150" in r.content, r.content[-300:])

# ------------------------------------------------------------------ R6-P2 resumes
ag2 = Agent(task=task, task_id="flip", branch=1, view="grids", model="qwen", base_url="http://127.0.0.1:9/v1", provider="vllm")
op = lambda a: a._build_user_prompt(1, valid_actions=[])
expect("P2: first opener", op(ag2).startswith(A.R6_TEXT["first"]))
ag2._resume_after_yield, ag2._resume_reason = True, "yield_bare"
expect("P2: no tool, no evidence -> notool", op(ag2).startswith(A.R6_TEXT["notool"]))
ag2._arc2_length_pending = True
expect("P2: length cut without a call", op(ag2).startswith(A.R6_TEXT["length"][:40]))
ag2._arc2_cut_pending = True; ag2._arc2_length_pending = True
expect("P2: cut call has precedence", op(ag2).startswith(A.R6_TEXT["cut"][:40]))
ag2._resume_reason = "timeout"
expect("P2: timeout", op(ag2).startswith(A.R6_TEXT["timeout"][:40]))
ag2._resume_reason = "yield_tools"
expect("P2: tools ran, no evidence -> neutral continue", op(ag2).startswith(A.R6_TEXT["continue"]))
ag2.arc2_progress["best"] = {"name": "t1", "k": 1, "n": 2, "acc": 0.5}
expect("P2: partial progress", "`t1`, is exact on 1 of 2" in op(ag2))
ag._resume_after_yield, ag._resume_reason = True, "yield_tools"
expect("P2: verified candidate beats partial", "is host-verified" in op(ag), op(ag))
ag2._resume_after_yield = False
ag2.arc2_submissions.append({"name": "t1", "accepted": False, "summary": "wrong on training pair 1."})
expect("P2: a new turn after a rejected submit names the rejection (not the first-turn text)",
       op(ag2).startswith("Your submission `t1` was not accepted: wrong on training pair 1. Continue"), op(ag2))
ag2.arc2_submissions.pop()
msgs = [{"role": "system", "content": "s"}, {"role": "user", "content": "a" + A.R6_COMPLETE},
        {"role": "assistant", "content": "x"}, {"role": "user", "content": "b" + A.R6_COMPLETE}]
out = ag2._arc2_rewrite_resume(msgs + [{"role": "assistant", "content": "y"}], msgs)
expect("P2/T2: trim rewrites only the newest opener", out[3]["content"].startswith("b") and A.R6_TRIMMED in out[3]["content"]
       and A.R6_COMPLETE in out[1]["content"])
expect("T2: facts stay in the (never trimmed) system prompt", "ARC TASK FACTS" in ag2._system_prompt)
msgs = []
ag2._append_context_message(msgs, {TA._CONTROL_MESSAGE_KEY: "nudge", "role": "user",
                                   "content": "You have not acted yet. Investigate first. Then investigate and revise ..."})
expect("T6: Duck's 'Investigate first' nudge replaced", msgs and "Investigate first" not in msgs[-1]["content"]
       and msgs[-1]["content"].startswith(A.R6_TEXT["notool"]), msgs)

# ------------------------------------------------------------------ R6-Q1 / R6-D1 dynamic caps
ag3 = Agent(task=task, task_id="flip", branch=0, model="qwen", base_url="http://127.0.0.1:9/v1", provider="vllm")
c = ag3._arc2_apply_cap()
expect("Q1: 12,288 before the first successful tool call; D1 reserve and budget follow",
       c == 12288 and ag3._reply_reserve_tokens == 12288 and ag3._context_budget_tokens == 78000 - 12288 - 512,
       (c, ag3._reply_reserve_tokens, ag3._context_budget_tokens))
ag3._arc2_tool_ok = True
expect("Q1: 24,576 after tool progress", ag3._arc2_apply_cap() == 24576 and ag3._context_budget_tokens == 78000 - 24576 - 512)
ag3._arc2_nocall_cuts = 2
expect("Q1: 32,768 rescue after two no-call cuts", ag3._arc2_apply_cap() == 32768 and ag3._max_output_tokens == 32768)

# ------------------------------------------------------------------ R6-S6 / T8 deadline clamps
seen = {}
_orig = TA.ToolAgent._chat_completion


class _R:
    finish_reason, message, usage = "stop", {"role": "assistant", "content": "ok", "tool_calls": []}, {}


def _fake(self, messages, **kw):
    seen.update(kw)
    return _R()
TA.ToolAgent._chat_completion = _fake
try:
    ag3._arc2_deadline = time.monotonic() + 10
    ag3._chat_completion([{"role": "user", "content": "x"}], tools=None, request_timeout_seconds=1800)
    expect("T8: a request's read timeout is clamped to the deadline", seen["request_timeout_seconds"] <= 10.0, seen)
    ag3._arc2_deadline = time.monotonic() - 1
    ag3._chat_completion([{"role": "user", "content": "x"}], tools=None, request_timeout_seconds=1800)
    expect("T8: past the deadline -> minimal timeout", seen["request_timeout_seconds"] == 0.5, seen)
finally:
    TA.ToolAgent._chat_completion = _orig
ag._arc2_deadline = time.monotonic() - 1
v = ag._verify_submission("transform")
expect("S6: no verification after the deadline", v.get("skipped") and not v["accepted"], v)
ag._arc2_deadline = None

# ------------------------------------------------------------------ R6-S1..S5 scheduler simulation (fake agents)
class FakeResult:
    retryable_failure, yielded_control, step_executed = False, True, False


class FakeAgent:
    """Emulates Duck's analyze(): one request per call (yield after 2,048 tokens), should_stop checked before it."""
    log = []
    lock = threading.Lock()

    def __init__(self, *, task, task_id, branch, view, **kw):
        self.task_id, self.branch, self.view = task_id, branch, view
        self.generated_tokens = self.total_tokens = 0
        self.arc2_accepted, self.arc2_submissions, self.arc2_usage, self.arc2_checked = None, [], [], []
        self.arc2_rev5_events, self.arc2_rev6_events = {}, {}
        self.arc2_progress = {"best": None, "first_check_tokens": None, "runs": 0}
        self._arc2_deadline = None
        h = sum(map(ord, task_id))
        self.solve_at = None if h % 3 == 0 else (8000 + (h % 5) * 9000)     # some tasks never solve
        self.oid = id(self)

    def analyze(self, state_path, n, *, should_stop, **kw):
        if should_stop():
            return FakeResult()
        with FakeAgent.lock:
            FakeAgent.log.append((time.monotonic(), self.task_id, self.branch, self.generated_tokens))
        time.sleep(0.002)
        self.generated_tokens += 4000
        self.total_tokens = self.generated_tokens
        if self.solve_at and self.generated_tokens >= self.solve_at and not self.arc2_checked:
            self.arc2_checked.append({"name": "transform", "accepted": True, "test_outputs": [[[self.branch]]], "t": time.time()})
        return FakeResult()


tasks240 = {f"t{i:03d}": {"train": [], "test": [{"input": [[0]]}]} for i in range(240)}
order = sorted(tasks240, key=lambda t: (sum(map(ord, t)) % 7, t))          # stand-in for ORDER2
os.environ["ARC3_MAX_ACTIVE_STREAMS"] = "10"
done = []
t_start = time.monotonic()
recs = A.solve_all_r6(tasks240, order, out_dir=tmp / "sched", deadline=time.monotonic() + 120, base_url="x", model_id="m",
                      branches=2, max_generated_tokens=100000, workers=10, first_exposure_tokens=28000,
                      on_branch_done=done.append, agent_cls=FakeAgent, min_admit_sec=1)
first_req = {}
for t, tid, b, tok in FakeAgent.log:
    first_req.setdefault((tid, b), t)
b0_starts = sorted((first_req[(t, 0)], t) for t in order)
stage2 = [first_req[k] for k in first_req if k[1] == 1]
expect("S1: every one of 240 tasks got branch 0", all((t, 0) in first_req for t in order))
rank = {t: i for i, (_, t) in enumerate(b0_starts)}
expect("S1: branch-0 admission follows the given order (ORDER2, within the 10 concurrent workers)",
       max(abs(rank[t] - i) for i, t in enumerate(order)) < 20, max(abs(rank[t] - i) for i, t in enumerate(order)))
expect("S1: no stage-2 work before the last task's first exposure starts", min(stage2) >= max(x for x, _ in b0_starts) - 0.05,
       (min(stage2), max(x for x, _ in b0_starts)))
r0 = [x for x in recs[order[0]] if x["branch"] == 0][0]
expect("Q2: branch 0 paused at the first-exposure budget, then resumed (2 runs)",
       len(r0["runs"]) >= 1 and r0["runs"][0]["status"] in ("paused", "done"), r0["runs"])
paused_then = [t for t in order if any(x["branch"] == 0 and len(x.get("runs", [])) >= 2 for x in recs[t])]
expect("Q2: resumed branches keep their agent (tokens continue past the pause)",
       paused_then and all(max(x["generated_tokens"] for x in recs[t] if x["branch"] == 0) > 28000 for t in paused_then[:20]),
       len(paused_then))
solved_b0 = [t for t in order if any(x["branch"] == 0 and any(c["accepted"] for c in x.get("checked") or []) for x in recs[t])]
expect("S2: tasks with one candidate still get branch 1 (about 1/3 of accepts are test-wrong)",
       any(any(x["branch"] == 1 for x in recs[t]) for t in solved_b0))
expect("S: every record published per (task, branch), replaced not appended", all(len({x["branch"] for x in recs[t]}) == len(recs[t])
                                                                                  for t in order))
print("scheduler sim:", round(time.monotonic() - t_start, 1), "s,", len(FakeAgent.log), "fake requests,",
      sum(len(v) for v in recs.values()), "branch records")

# deadline: a short run must stop admitting and return promptly
FakeAgent.log = []
t0 = time.monotonic()
recs2 = A.solve_all_r6(tasks240, order, out_dir=tmp / "sched2", deadline=time.monotonic() + 3, base_url="x", model_id="m",
                       branches=2, max_generated_tokens=100000, workers=10, first_exposure_tokens=28000,
                       agent_cls=FakeAgent, min_admit_sec=1)
expect("S6: returns shortly after the deadline", time.monotonic() - t0 < 3 + 2.5, round(time.monotonic() - t0, 2))
expect("S6: no request after the deadline", max(t for t, *_ in FakeAgent.log) <= t0 + 3.05)

# capacity fallback: a probe that always reports a server queue lowers the workers 10 -> 8 -> 6 (and never below)
import arc2_duck as _A2
calls = []
_sleep = _A2.time.sleep
orig_sleep = time.sleep


class _FastTime:
    def __getattr__(self, k):
        return getattr(time, k)

    @staticmethod
    def sleep(s):
        orig_sleep(0.01 if s >= 60 else s)
_A2.time = _FastTime()
try:
    recs3 = A.solve_all_r6(tasks240, order[:40], out_dir=tmp / "sched3", deadline=time.monotonic() + 4, base_url="x",
                           model_id="m", branches=1, max_generated_tokens=400000, workers=10, first_exposure_tokens=None,
                           agent_cls=FakeAgent, min_admit_sec=1, capacity_probe=lambda: {"queue": 3}, min_workers=6)
finally:
    _A2.time = time
ev = A.SCHED_LAST.get("events")
expect("S5: queued server -> controlled fallback 10 -> 8 -> 6, never below", ev and ev[0]["allowed"] == 8
       and A.SCHED_LAST["allowed"] == 6, A.SCHED_LAST)

print("ALL OK" if ok else "SOME FAILED")
sys.exit(0 if ok else 1)
