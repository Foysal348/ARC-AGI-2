# E28 W4 audit: GO / NO-GO for a 6-hour EVAL120 GPU commit

You are auditing ONE Kaggle notebook before a 6-hour GPU commit (4x L4, Kaggle). Answer **GO** or **NO-GO**, then list every
**blocker** (anything that would crash the run, lose the submission, corrupt the score, or silently not apply a lever), then
the non-blocking issues. Cite file:line for every item. Read every file in full; do not skim.

## What the notebook is
`Q27-XHIGH-E28_W4_EVAL120_6H.ipynb` (sha256 72ddda58…, 388,984 B, Kaggle limit ~407 kB). It is the CPU-kit-proven NB6Q
SUBMIT notebook (sha 499a4319; Qwen3.8 Flash-Next W4A16 on Merlin = a vLLM 0.32 fork, TP2 x PP2, FP8 KV with static scales, MTP
K3, the Q-defer patch, #60490, the Duck REPL agent for ARC-AGI-2) plus the E28 changes (user decisions, see README_E28.md):
1. Commit profile E28EVAL120: all 120 eval tasks, 412-min budget -> HARD_STOP 410 min, a fixed 6-h solve window, a deadman at
   HARD_STOP + 5 min (the E26 K100Q deadman code, names changed). The hidden rerun stays RERUN_PROD (12 h - 3 min).
2. C12: `--max-num-seqs 12` on every pin rung; workers = 12 regardless of the pool rule.
3. I8: `DRAFT_HEAD=int8` into Merlin's build() (as NB4T did); the pin ladder starts at RC2 + 0.75 GiB = 3,285,145,068 B.
4. T1 = 120,000 tokens per attempt; B2 (cap-cut re-run) = 200,000; server `--max-model-len 262144`; A / B1 / C keep the
   131,072 cap and the 130,560 Duck window.
5. The A -> B -> C scheduler (`e28_sched_patch.py`, patches the Duck payload's arc2_duck.py in CELL 3) for the commit AND the
   rerun; no ORDER2; answer slots per the scheduler.
6. Admission = NB6Q's "slots" (12 workers, one slot per attempt, the engine schedules KV; preemptions recorded at run level
   and per attempt); request timeout 7,200 s (B2 12,000 s, set explicitly via E28_B2_REQUEST_TIMEOUT). Scheduler rev 2 (sha 47ab9874, N1-N4).
7. The I8 boot GATE (W20-W22): after ready, DRAFT_HEAD=int8 must read back ENGAGED (NB4T's read-back), else
   I8_READBACK_UNVERIFIED: the server stops and the SAME pin is retried with the BF16 head; only a failed BF16 retry steps down.
8. `--language-model-only` (NB4T's flags). Size-only packings W16 / W17 / W18 (verbatim text, lzma + base85, sha-checked).

GPU push folders: foysalemonshanto (reference) and esfersami50 (the GPU run, user decision): the same notebook and sources.

## How to read it
- `e28w4_review_diff_vs_nb6q.diff` = the whole change vs NB6Q in plain text (the size-only packings undone by
  `e28w4_unpack.py`). Every hunk is marked "E28". `build_e28_w4.py` documents each edit W1-W19 + SCHED.
- `e28w4_code_export.py` = the notebook's code cells as built (packed form).
- `e28w4_unit_tests.py` + the local log (all PASS, 1 POSIX-only skip; see the log); `nb6q_S2S4_on_e28w4_local.txt` (NB6Q's own
  Q-defer block tests on this notebook, 31 / 31).
- CPU kits (Kaggle, Py3.12, not yet run): `build_e28_w4_cpu_kit.py` + `e28w4_kit_inject.py` (wraps the proven NB6Q kit
  builder `build_e25_nb6q_cpu_kit.py`, included) and the four kit notebooks.

## CPU kits v1 (Kaggle, notebook 809cb2ad) and the v2 fixes
units ALL OK; e2e-commit / e2e-rerun / real NOT OK. Every failure was a KIT defect (the notebook is unchanged): V2-1 the F_log
tolerance at max-model-len 262144 (the 2-decimal concurrency factor), V2-2 the argparse probe written as argparse.py shadowed the
stdlib for every later probe (torch circular import, GradBucket, IndexError), V2-3 rerun vs commit plans differ only by the two
--port values, V2-4 the fallback-submission check expected NB6COMMIT, V2-5 the inherited E28 env in the server process is now
recorded instead of asserted absent. The v1 reports are in kits_v1_*.json. Check that none of these fixes hides a real defect.

## Questions you must answer explicitly
1. With slots admission and 12 workers on a ~197-block I8 pool (4,096-token blocks, F ~5): at what mean context do the 12
   resident attempts exhaust the pool (12 x (ceil(ctx / 4096) + 5) > 197 -> ~60k), how often will vLLM preempt (recompute)
   at T1 120k and with 200k B2s, and is the throughput loss acceptable? Quantify.
2. I8 + C12 together were never measured (NB4T measured each alone at 8k / 40k; I8 needed the lower pin). With CAPS16
   captures up to 64 (NB4T used Merlin's default up to 32) and `--max-model-len 262144`: OOM risk at boot, and does the
   ladder (0.75 -> 0.5 -> 0 GiB, <= 3 tries, 30 / 15 / 15 min) cover it within the 6-h window?
3. 200k context on Flash-Next was never validated (RC2 validated 120k). Is anything in the B2 path (N1 / N2 / N4 + W19 caps,
   the E21 clamp 262144, the B2 window 261,632, the 12,000-s timeout) wrong?
4. Is the deadman safe (commit only, fires after HARD_STOP, cannot kill the submission write)? Is the 6-h window correct
   when the boot is late (shortened, never skipped)?
5. Dual mode: the rerun path = every hidden test task, identity fallback, E15B writer, E18 R2 CELL 0 unchanged?
6. The scheduler failure path: the COMMIT raises NO_GO_E28_SCHED in CELL 3 (before any boot; CELL 0's fallback submission
   stays); the hidden RERUN restores the original arc2_duck.py and falls back to NB6Q's scheduler. Is either path broken?
7. Anything in the CPU kits that would give a false ALL OK or a false NOT OK?

Output: `VERDICT: GO` or `VERDICT: NO-GO`, then `BLOCKERS:` (numbered, file:line, fix), then `OTHER:`.


## FINAL (coordinator, 2026-11-01)
Kit results on THIS notebook e7c2c942: units / e2e-rerun / e2e-commit ALL OK (KITS_FINAL_v4__*); real ALL OK on the previous build (checks unchanged since). Decisions since earlier prompts: T1 104k / B2 120k / max-model-len 131072; C12 only on the I8 start rung + its same-pin BF16 retry; I8 gate (I8_ENGAGED required, same-pin BF16 retry); relaunch = K100Q fix D (NB5_ACTIVE_BOOT); scheduler 108bb75c (classification order fix, INCONCLUSIVE_CONTEXT_LENGTH -> B2). Answer GO / NO-GO first, then blockers only.
