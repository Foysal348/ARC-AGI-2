# Qwen3.8-27B on ARC-AGI-2: digest of the archive (2026-09-13 to 10-04) and Experiments 2-5

Compiled 2026-10-16. Read-only research; nothing under `D:\ARC AGI 2` was changed.

## Path keys used in citations

| Key | Path |
|---|---|
| ARCH | `D:\ARC AGI 2\archive\Earlier Qwen3.8 experiments (2026-09-13 to 2026-10-04)\` |
| E1 … E11 | `D:\ARC AGI 2\experiments\Experiment N - …\` (E1 = "Experiment 1 - Q27-XHIGH Direct Reasoning (LB 18.75 and 26.94)", E2 = "Experiment 2 - R6 Code Loop", E3 = "Experiment 3 - Flash-Next Feasibility (FN)", E4 = "Experiment 4 - Q27-AGENT REPL Agent and HYBRID (v1 to v1.8.3)", E5 = "Experiment 5 - Q27-AGENT v1.9 Long-Think Synthesis (planned)", E10 = "Experiment 10 - Q27-XHIGH Poetiq Code-Verify attempt_2 (planned)") |
| RES | `D:\ARC AGI 2\resources\` |
| AJ | `RES\Analysis and Journals\`: MP = Experiment_Master_Plan_2026-09-13.pdf, PN = Agentic_Solver_Portability_Notes_v10_Final_English_2026-09-13.pdf, ND = Noemon_Research_Dossier_2026-09-09.pdf, HO = Project_Handoff_2026-09-16.pdf, DA = Deep_Audit_Reference_2026-09-17.pdf, CJ = Canonical_Project_Journal_2026-09-18.pdf (the "(1)" copy is byte-identical), JMD = `ARC_AGI2_Qwen38_Project_Journal_through_v2.4G_2026-09-18.md` |
| PCL | `RES\Puzzle Capability Ledger\README.md` (+ `summary.json`, `solved_by_tokens.csv`) |
| SCR | `C:\Users\hp\AppData\Local\Temp\claude\d--ARC-AGI-2\1c6db7aa-c78b-4b3a-b97a-5c67187fe52f\scratchpad\agent_archive\`: detailed extraction notes `notes_early_families.md`, `notes_late_families.md`, `notes_reference_notebooks.md`, `notes_journals_pdfs.md` (bundle extractions in `unzipped\`, `unzipped2\`, PDF text in `pdftext\`) |

Labels: **[M]** measured on GPU, **[CPU]** harness/fake engine only, **[I]** inference.

---

## 0. Ten-line summary

1. **Every September program-synthesis/agent rejection ran at 3k-12k tokens per task or turn** (Q1 12,288; PIV v1.7 12,288; ACT 3,072/turn; C1 8,192 explore; EVAL120 6,144+2,048; EVO12 3,072 think at effort medium). Qwen3.8 hits come almost only from *natural* thinking closes at ~26-45k (PCL; E1 README). Those negatives are **budget-confounded**, not evidence against code/verify methods [I]. E10 Poetiq at 77.8k thinking per iteration later scored 78/172 on EVAL120 vs 58/172 for direct (E10 `Experiment Results\Analysis\GPU EVAL120 Poetiq R5 analysis (2026-10-15).md`).
2. Archive best: PIV-SUB v1.3 **LB 1.67**, identical to its EVAL120 measurement (ARCH `V3 …\Experiment Results\CANONICAL_BASELINE_EVAL120_2026-10-03.md`).
3. Experiments 2-5 all scored at or below DIRECT on EVAL12: R6 2/22, Exp4 agent 0/22, Exp5 agent 1/22, vs DIRECT 2-3/22. Each failure has a concrete mechanical cause (12k repair caps; forced named tool_choice; server thinking budget not enforced under MTP).
4. The single most important stack bug: **vLLM 0.19 + MTP silently ignores `thinking_token_budget`** (also `min_p`, `logit_bias`; vLLM #39573). The host-side forced close (stop sentence + `</think>`, token-exact continuation) is the only proven way (E5 `Experiment Review\README_v1_9_1_GPU_BUG_REVIEW.md`; E6 README).
5. Coverage drives DIRECT LB: v1.4 → v1.4.4 (+8.19 LB) came only from prefix caching + admission until 11:34 (E1 README); 86k for every unit dropped LB to 22.92 (E10 README, line 199).
6. Public Qwen3.8 notebooks in the workspace all score below 27.92: NguyenThanhNhan 23.33 (SGLang+EAGLE, pure reasoning, forced commit at 49k), madarshbb ~21.5→13 (direct per task, T=1.0, 2 independent samples), russcore 10.14 (free-form per query, no MTP). No primary source for the "~60 with the same model" recipe exists in the workspace (SCR `notes_reference_notebooks.md` §4).
7. Never-run candidates with the most support: adequate-budget code-verify + DIRECT complement (E10 R5 policy table: 55.14 % task-norm), per-task prompting, temperature A/B, CSV/dims grid encoding, SGLang+EAGLE+mamba radix cache, KV-guarded concurrency with fp16 SSM state, independent second sample scheduled after coverage, repair with its own full budget, NVARC∪Qwen union.

---

## 1. Every Qwen3.8-27B experiment / notebook (archive + Experiments 2-5)

Common archive engine unless stated (Q1/PIV/ACT): vLLM 0.19.0, TP=4, `enforce_eager=True`, custom AR off, prefix cache off, no MTP, `max_num_seqs` 16, `max_num_batched_tokens` 32,768, `gpu_memory_utilization` 0.90, `max_model_len` 29,696, KV auto = 159,936 tokens, `language_model_only=True`, thinking sampling T 1.0 / top_p 0.95 / top_k 20 (SCR `notes_early_families.md` §1). C1/EVAL120/SUB/EVO: same but CUDA graphs on (KV 166,992) (SCR `notes_late_families.md` §1).

### 1a. Archive (2026-09-13 → 10-04)

| # | Experiment / version (date) | Method | Budget / settings | Where it ran | Measured result | LB | Failure mode / lesson | Source |
|---|---|---|---|---|---|---|---|---|
| A1 | Q1-DIR SMOKE16 (09-13) | Direct JSON answer, thinking OFF vs XHIGH | XHIGH cap 1,024, OFF 512 | GPU, SMOKE16 | 0/19 exact; 2/16 XHIGH "valid" grids were false positives parsed out of truncated reasoning | – | Added a truncation guard | ARCH `Q1 Direct Baseline (PROXY48)\Experiment Results\Kaggle Runs\experiment-1-arc-agi-2-with-qwen-3-8 (7).ipynb`; `Q1_DIR_Q27_SMOKE_GPU_BUNDLE.zip` |
| A2 | Q1-DIR v1.2 (09-13) [M] | Direct JSON `{"test_outputs":…}`; OFF vs XHIGH | XHIGH 12,288 (T1.0); OFF 4,096 (T0.7, top_p 0.8, presence_penalty 1.5) | GPU, PROXY48 (48 tasks / 56 outputs) | **0/56** OFF, XHIGH and union. XHIGH 48/48 `length`, 0 `</think>`; OFF 31/56 valid grids, 18/48 hit 4,096 in prose; ~51 tok/s aggregate, 0.156 s/token/seq; 233.5 min | – | XHIGH needs far more than 12k; OFF writes prose | ARCH `Q1…\Kaggle Runs\…(8).ipynb`; `Q1_DIR_Q27_PROXY48_BUNDLE.zip` (`mode_summary.csv`, `raw_generations.jsonl`); HO p3-4 |
| A3 | PIV-P0 v1.0-v1.6 (09-14) [CPU] | PiVOTools-style stateful REPL + fresh train verifier | per-turn 2,048 (v1.0) → 4,096 (v1.3) → remaining-of-12,288 (v1.4+) | CPU PREFLIGHT only (v1.5) | harness only | – | Many harness fixes (retry vs restart, train-perfect not erased by test failure) | ARCH `PIV-P0…\Experiment Results\PIV_Q27_P0_PREFLIGHT_BUNDLE.zip`; JMD §1B |
| A4 | PIV-P0 v1.7 SMOKE_GPU (09-14) [M] | Same, xhigh + python tool | 12,288/task, 6 calls / 12 turns | GPU, SMOKE8 (0934a4d8 16b78196 2c181942 271d71e2 136b0064 cb2d8a2c 291dc1e1 28a6681f) | 8/8 one 12,288-token think, **0 tool calls, 0 `</think>`, 0 programs**; 49.96 tok/s, 0.160 s/token/seq | – | Qwen emits tool XML only after `</think>`; xhigh never closes within 12k. PROXY48 gate failed, never run | ARCH `PIV-P0…\Kaggle Runs\…(11).ipynb`; `PIV_Q27_P0_SMOKE_GPU_BUNDLE.zip` |
| A5 | ACT v1.8 (09-15) | 3-arm effort ablation | – | never executed | – | – | Superseded by v1.9 | SCR `notes_early_families.md` §3 |
| A6 | ACT v1.9 PROBE_GPU (09-15) [M] | LOW / MEDIUM / BUDGET3072 (xhigh + forced close at 3,072) | 3,072/turn, 5,120/task, 2 calls, 2 turns, action 2,048 (reserve 768) | GPU, SMOKE8 | tool engagement LOW 0.875, MEDIUM 0.125, BUDGET3072 0.875; **0 programs, 0 exact**; s/token 0.168/0.169/0.185 | – | Activation ≠ solving; MEDIUM injects no instruction and never closes; exact stop text validated (25 tokens) | ARCH `ACT…\Kaggle Runs\…11_1.ipynb` (= (12), (13)); `PIV_Q27_ACT_V19_PROBE_GPU_BUNDLE2.zip` (`arm_comparison.csv`, `probe_verdict.json`) |
| A7 | TP v1.0 / v1.2.1 / v1.2.2 [CPU] | Engine ladder design | – | PC fake-engine self-tests only | synthetic tok/s (do not cite) | – | v1.2.1 had a `{{…}}` TypeError | ARCH `TP Throughput Probe\Experiment Results\TP_Q27_PROBE_SELFTEST_BUNDLE_pc.zip`, `…V122_SELFTEST…_pc.zip` |
| A8 | TP v1.2.4 SMOKE_GPU (09-16) [M] | Throughput ladder, 8 configs | decode@N 256 tok; long@8 3-4k | GPU | eager C0 48.30 tok/s → CUDA graphs C1 **129.17** (2.67×; KV 166,992); custom AR 0.9995×; prefix+mns64, TP2, TP2+AR all CUDA OOM at first prefill, two hung to the 4,500 s timeout; greedy-prefix numerics gate invalid (identical repeat 0.1875) | – | Use graphs; fail fast on EngineDead; full PROBE (mns64/128, fp8 KV, align prefix, MTP-1, gpu 0.95) never ran | ARCH `TP…\Experiment Results\TP_Q27_PROBE_V124_SMOKE_MASTER_EVIDENCE_20260916T091344Z.zip`; `…\Kaggle Runs\…12_1.ipynb`; HO p6-7; DA p7-8 |
| A9 | C1 v2.0, v2.3 PREFLIGHT (09-17) [CPU] | Solver + C1 engine | – | CPU | harness passes | – | – | ARCH `C1…\Kaggle Runs\…(14).ipynb`, `…14_1.ipynb` |
| A10 | C1 v2.3 C1_QUALITY_SMOKE (09-17) [M] | REPL agent, LOW vs BUDGET3072, CUDA graphs | 12,288/task, 6 calls/12 turns, batch 8, no terminal commit | GPU, SMOKE8 | **0 final programs / 16**; budget death 8/8 both arms; LOW think p90 8,044; 0.046 / 0.063 s/token | – | Explores, never commits → build terminal commit | ARCH `C1…\Kaggle Runs\…(15).ipynb`; `PIV_Q27_C1_V23_QUALITY_SMOKE_BUNDLE.zip`; CJ p6 |
| A11 | C1 v2.4A-F (09-17/18) | Terminal commit fixes | – | never on GPU (v2.4E on a PC fake engine) | – | – | `int(phase)` crash, gate false-pass, cap-guard blast radius… | ARCH `C1…\Build\harness_c1_v24e_fake_engine.py`; JMD §3 |
| A12 | C1 v2.4G ADAPTIVE_SMOKE (09-18) [M] | Explore ≤8,192, then no-tools/no-think **structured-JSON finaliser** (`StructuredOutputsParams`) 4,096 | 12,288/task; LOW + BUDGET3072 | GPU, PILOT2 → SMOKE8 | **16/16 programs, 16/16 parsed, 0/16 all-train-exact** (best 291dc1e1 2/4 pairs); ~9.2-9.4k tok/task; 4,691 s | – | Plumbing solved; semantic quality is the blocker; 768-token action reserve truncated late tool calls (5 cases) | ARCH `C1…\Kaggle Runs\…12_2.ipynb`; `PIV_Q27_C1_V24G_ADAPTIVE_SMOKE_BUNDLE.zip`; JMD §0, §4 |
| A13 | C1 v2.5 / v2.5A / v2.5B (09-18 → 10-02) | Candidate-first verifier-feedback repair (1 no-think round) | repair cap = leftover of 12,288 | never standalone on GPU; v2.5B code ran inside A14/A15 | see A14 | – | v2.5: two P0 crashes (self-test assert; `_mk_finalizer_params` NameError after 78 min); leftover cap < own candidate for 3/8 tasks | ARCH `C1…\Experiment Review\PIV_Q27_C1_V25_FAKE_ENGINE_AUDIT_2026-09-18.md`; SCR `notes_late_families.md` §0, §1 |
| A14 | PIV-Q27-EVAL120-MEASUREMENT (10-02) [M] | PIV v2.5B, ACT-LOW, repair on | **6,144 explore + 2,048 finaliser = 8,192/task**, batch 12 | GPU, all 120 eval tasks | **TV 3/120, strict 2/120 = 1.67 %** (2/172 queries); 38/120 finaliser JSON truncated at exactly 2,048; 49/120 zero-tool tasks (6,144 tokens of row-by-row transcription); 3/173 tool calls ran `solution()` on train; repair 79 → 52 parse failures, 0 new TV; 0 PIV-only solves vs NVARC; 4.55 h; 29 % of waves ≤2 active | – (= LB of A15) | Finaliser cap too small; fixed waves waste time; "near misses" later shown identity-level | ARCH `V3 EVAL120 Baseline and S12 Subset\Experiment Results\CANONICAL_BASELINE_EVAL120_2026-10-03.md`; ARCH `PIV-SUB…\Experiment Review\PIV_Q27_KAGGLE_RUNS_REVIEW_2026-10-03.zip` (`kaggle_outputs/eval120/`) |
| A15 | PIV-Q27-SUB v1.3 SUBMIT (10-02 → 10-03) [M] | A14 recipe + unverified-program test pass + identity fallback + atomic submission | 8,192/task, batch 12, ACT-LOW | Commit run on the 240-task placeholder (training copies); hidden rerun | Placeholder: 220 programs, 103 TV, **113/259 = 43.6 %** (scored against training solutions); 6.2 h. Hidden: **LB 1.67** | **1.67** | First end-to-end submission; LB matched EVAL120, not the training-copy placeholder | ARCH `PIV-SUB Hidden-Test Submission (LB 1.67)\…\PIV_Q27_KAGGLE_RUNS_REVIEW_2026-10-03.zip` (`analysis/ANALYSIS_SUMMARY.md` line 17, `kaggle_outputs/submission_run/run_report.json`); ARCH README |
| A16 | PIV-SUB v1.0-v1.2 (10-02) [CPU] | Submission machinery hardening | SUBMIT_FAST 4,096; SUBMIT 8,192 | fake engine only | 7 + 6 review findings fixed | – | Positive-control P0 would have skipped every sweep | ARCH `PIV-SUB…\Experiment Review\PIV_Q27_SUB_V10_AND_V25A_HANDOFF_2026-10-02.md`, `…V11_REVIEW_RESPONSE…`, `…V12_REVIEW_RESPONSE…` |
| A17 | V3 ALLFIX (10-03) | Forced close at 2,048, no grid transcription, auto-verify after each tool call, verbatim commit, helper library, code-only finaliser T0.1, backfill slots | 12,288 = 8,192 + 4,096 | never ran (reviewer NO-GO, 7 patches) | – | – | – | ARCH `V3…\Experiment Review\PIV_Q27_V3_REVIEW_BUNDLE_2026-10-03.zip` (`PROMPT_FOR_REVIEWER.md`) |
| A18 | V3.1 S12 (10-03) [M] | V3.1 ALLFIX (commit gate, repair off, symtable builder, REPL-vs-fresh fidelity) | ACT-LOW-FORCED think closed at 2,048; 8,192 + 4,096; T_final 0.1 | GPU, S12 (1818057f 7b5033c1 e376de54 88e364bc dd6b8c4b 8b7bacbf 5961cc34 291dc1e1 62593bfd 97d7923e a47bf94d 7491f3cf) | TV 2/12, strict 1/12 = baseline; 0 zero-tool tasks, 0/10 finaliser truncations, fidelity 7/7; ~38 min | – | **"Near misses" were identity-level** (wrong-cell % ≈ return-input %); bottleneck = rule discovery. Full EVAL120 blocked by pre-registered rule | ARCH `V3…\Experiment Results\PIV_Q27_V31_S12_RESULT_2026-10-04.md` |
| A19 | EVO12 (10-04) [M] | Imbue-style evolution: 4 organisms (lenses), 2 parents, 2 repair gens with error maps, no REPL | effort **medium**, 3,072 think + 2,048 answer per call, 32,768/task, T1.0 | GPU, 12 eval tasks (9 NVARC misses) | **0/12**, 0 train-exact; 0/80 natural closes; 26/80 answers truncated; 64/80 had code; 351,688 tokens; 172/141/101 tok/s by round; 3,174 s | – | Verdict WEAK/REDESIGN → pivot to direct xhigh. (Archive README's "no GPU result" is wrong for EVO12) | ARCH `EVO Program Evolution\Experiment Results\Kaggle Runs\EVO12_run\eval120\evo_report.json`; `…\piv-q27-evo12-evolution.ipynb` |
| A20 | EVO24 (10-04) | Same, 24 tasks, dual mode | – | never ran (4 review rounds) | – | – | Replaced by EVO12 | ARCH `EVO…\Build\EVO24_build\REVIEW_LEDGER.md`, `make_evo24.py`; `EXPERIMENT_PLAN_2026-10-04.md` |

### 1b. Current phase, Experiments 1-5 (with Exp1 context rows)

| # | Experiment / version (date) | Method | Budget / settings | Where | Measured result | LB | Failure mode / lesson | Source |
|---|---|---|---|---|---|---|---|---|
| B1 | E1 Q27-XHIGH v1.3.2 run 1 (10-05) | Offline engine, fp8 KV, MTP3 | – | GPU | 0 tasks ran: FlashInfer JIT `cannot find -lcuda` → EngineDeadError; GPU memory not released after `LLM()` raised | – | libcuda shim + link probe; kill children after failed engine | E1 `Experiment Results\Kaggle Runs\Q27X_run1\RUN1_ANALYSIS.md` |
| B2 | E1 v1.3.4 run 2 | same | `max_num_batched_tokens` 32,768 | GPU | MTP drafter OOM on first prefill | – | Use 4,096 batched tokens + `VLLM_MEMORY_PROFILER_ESTIMATE_CUDAGRAPHS=1` | E1 README |
| B3 | E1 v1.3.5 run 3 (10-06) [M] | 49k host-forced close → `solution(grid)` + JSON grids, one prompt per **task** | 49,152 think + 16,384 answer, **T1.0**, MTP3, prefix cache off | GPU, EVAL12 (12 tasks / 22 inputs) | **1/22**; 12/12 force-closed; 1 TV program (4c3d4a41, wrong on test); 6/12 JSON missing outer `[`; 307 tok/s at 12 active; each forced close re-prefilled ~52k (13.8 % of wall) | – | Earliest adequate-budget code test; one sample, no feedback loop | E1 `Experiment Results\Kaggle Runs\Q27X_run3\README.md` |
| B4 | E1 v1.4 run 4 (10-06) [M] | russcore free-form grid prompt, one prompt per **test input** | 49,152 + 8,192, T0.6/0.95/20, MTP3 | GPU, EVAL12 | **2/22**; 4 natural closes (26-42k) → 2 hits + 2 one-cell-off; 18 forced → 0; 373 tok/s at 16 | **18.75** | Rule search runs out of budget; outputs computed by hand; ragged rows | E1 `…\Q27X_run4\OUR_ANALYSIS.md`; E1 README |
| B5 | E1 v1.4.1 run 6 | + prefix cache (mamba `align`) | same | GPU, EVAL12 | 2/22; 285 tok/s; prefix hit 0.786 | – | Prefix cache works with MTP on the offline engine | E1 `v1.4.4 vs all experiments - remaining issues (2026-10-12).md` §1 |
| B6 | E1 v1.4.4 run 7 (10-10) [M] | + admission until 11:34, drain 11:36, hard stop 11:44 | same | GPU, EVAL12 | **3/22**; 19/22 forced at 49,175; 274.6 tok/s; KV 1,353,600 tokens, peak 78.7 %; 0 preemptions | **26.94** | Coverage = score | E1 README; same issues doc §0 |
| B7 | **E2 R6 code loop v1.1 run 5** (10-06) [M] | xhigh think → `solve(grid)` → run on train → feedback → repair turns | 49,152 first turn; **repair turns 12,288 think**; ≤4 turns; grid fallback 16,384; T0.6; MTP3; 16 seqs | GPU, EVAL12 | **2/22** (9.09 %, task-norm 12.5 %); hits 136b0064, 247ef758 from verified code; 47 turns, **46 force-closed**; 35 repair turns → 1 verify; 4 TV tasks, 3 of them wrong on test; **92.7k tokens/task** (p50 107k); 220.7 tok/s; 28 h hidden projection | – | Repair caps below the natural-close length never close; repair without prior reasoning restarts; train verification weak on 2-5 pairs | E2 README; E2 `Experiment Results\Kaggle Runs\Q27X_run5_R6\bundle\q27x\run_report.json` |
| B8 | E3 Flash-Next FN v3-v4.2.1 (10-05 → 10-11) | Other model (Qwen3.8-Flash-Next W4A16 + FP8 PLE) on SGLang | – | GPU probes | MoE runner failure (v3.x); weight-load timeouts (v4); v4.2.1: server ready 862 s, KV 118k, **garbage output** ("!!!!"), ~6 tok/s single stream | – | Not the 27B; dropped | E3 README |
| B9 | E4 Q27-AGENT v1.4 run 1 (10-11) | madarshbb REPL agent (python + `submit(transform)`) via vLLM server | thinking 6,144/turn, turn 8,192 | GPU, EVAL12 | infra OK; **every request HTTP 400** ("Unexpected reasoning effort high") | – | Template accepts only xhigh/medium/low | E4 README; E4 `Experiment Results\GPT Outputs\1_GPT_deep_audit_DIRECT_vs_AGENT_v1_5.md` |
| B10 | E4 v1.7 run 2 (10-12) | + HYBRID DIRECT rescue, audit-hook guard | caps 24k/36k | GPU | crashed after 14 min: `KeyError: 'base_url'` in rescue probe | – | Integration test with the exact launcher cfg | E4 README |
| B11 | E4 v1.8 run 3 (10-12) | rescue = LB-26.94 DIRECT | – | GPU | server up but never detected (`import urllib.request` inside a branch made `urllib` local); cancelled ~40 min | – | Execute GPU-only paths locally; pyflakes gate | E4 README |
| B12 | **E4 v1.8.3 run 4** (10-12) [M] | REPL agent, forced named `tool_choice=submit`, effort ladder, MTP3 server | 6,144 think/turn (not enforced), 10,240 turn cap, 24k/36k per attempt | GPU, EVAL12 | **Agent 0/22** (DIRECT ref 3/22); server 510 s, MTP acc 0.736, KV peak 31 %; 304 turns, 22 at the 10,240 cap; 82 submits **all forced**: 59 empty code, 22 nonportable exploration code, 1 verified (0/2); **5/24 attempts died on HTTP 500** (`assert content is not None` in the tool parser on forced turns); ladder stepped down in 22/24 attempts; 0 `def transform` in 191 snippets | – | Model never submits voluntarily; forced tool choice + thinking is broken in vLLM 0.19; turns far below base | E4 README; E4 `Experiment Results\Analysis\summary.json`, `per_attempt_table.md`, `http500_traceback_excerpt.txt` |
| B13 | E5 v1.9.0 (10-12) [CPU] | GPT build: long-think synthesis, no tools | 49,152 + 8,192 | CPU | 8 findings (macro vs micro score, timeout retry, rescue_min_think 4,096…) | – | – | E5 `Experiment Review\v1.9.0 validation and v1.9.1 changes.md` |
| B14 | **E5 v1.9.1 GPU EVAL12** (10-12) [M] | One request per task, xhigh, no tools, write `transform(grid)`; verify; merge with recorded DIRECT | server `thinking_token_budget` 49,152, `max_tokens` 57,344, T0.6; MTP3 server, prefix cache, 81,920 ctx | GPU, EVAL12, 56 min | **Agent 1/22** (136b0064, also DIRECT), DIRECT 3/22, hybrid 3/22; **10/12 thought to 57,344 with empty content** (budget not enforced), 4c3d4a41 cut at 56,238, 136b0064 closed naturally at 49,982; commit request fed only the last 7,000 chars of 116-182k chars → 8 train_mismatch, 2 no_program; KV 1,353,600, peak 68 % at 12×60k; MTP 0.634; ~297 tok/s | – | Not a fair test of long-think→program; phase 3 repair never built | E5 README; E5 `Experiment Results\Analysis\GPU EVAL12 v1.9.1 analysis (2026-10-12).md`; E5 `Experiment Review\README_v1_9_1_GPU_BUG_REVIEW.md` |

### 1c. Later-phase rows (context only; affects which ideas are "untried")

| Experiment | Result | Source |
|---|---|---|
| E6 dual answer from same reasoning | primary 1/22, dual 1/22: second answer +0; 12/22 second answers ragged/invalid | E6 `Experiment Results\Analysis\GPU EVAL12 dual v2 analysis (2026-10-12).md` |
| E7 ORDERING_ONLY (v1.4.4 + NVARC ordering) | **LB 27.92** (best) | E10 `Experiment Review\CPU validation ORDER2 COVERFIRST (2026-10-15)\README.md` line 13 |
| E8 thinking-mined candidates + 8-view NLL scoring for attempt_2 | PROXY48 10/56, gain 0; truth in 0/31 full thinkings; `prompt_logprobs` OOM (790 MiB all_gather) killed 15 in-flight units | `D:\ARC AGI 2\experiments\Experiment 8 - …\E8_FINAL_REPORT.md` |
| E9 86k + tail resample | EVAL12 4/22 (best EVAL12); resample gain 0; **LB 22.92** | `…\Experiment 9 - …\README.md`; E10 README line 199 |
| E10 ORDER2 86k DIRECT EVAL120 | 58/172, task-norm 36.94 %; 19 of 58 hits after 49,152 thinking | E10 `Experiment Results\Analysis\GPU EVAL120 ORDER2 86k analysis (2026-10-14).md` |
| E10 Poetiq R5 EVAL120 (1 expert, ≤10 iterations, 77,824 think/iteration, T1.0) | **78/172, task-norm 48.61 %**; union with DIRECT 56.81 %; "Poetiq if verified, else +DIRECT" 55.14 %; 13 never-solved tasks solved; round 1 alone ran to ~540 min | E10 `Experiment Results\Analysis\GPU EVAL120 Poetiq R5 analysis (2026-10-15).md` |

---

## 2. What the public Qwen3.8 reference notebooks did (as documented)

Only two external public notebooks are stored; the other seven `LB_compare` folders are the team's own private kernels (kernel-metadata `is_private: true`) (SCR `notes_reference_notebooks.md` §0).

| Author / notebook | Method | Budget | Sampling | attempt_2 | Scheduling | Score | Source |
|---|---|---|---|---|---|---|---|
| **NguyenThanhNhan** "Qwen38 27B FP8 Inducer" (no code in workspace) | Pure reasoning, xhigh, one pass; **SGLang**: fp8_e4m3 KV, FlashInfer attn, triton linear-attn, chunked prefill 2048 / max prefill 4096, `--mamba-radix-cache-strategy extra_buffer`, mamba-full-memory-ratio 0.5, mamba-ssm fp32, **EAGLE** 3 steps / topk 1 / 4 draft tokens | ~65k total; "force the model to stop reasoning and commit with a solution grid after 49k" | unknown | unknown ("2x" in the label, unresolved) | unknown | **23.33 / 22.50** (screenshot); method = claim | E1 `Experiment Notebooks\Build\Q27X_build\sources\kaggle_discussion_745787.md`, `kaggle_discussion_745787_API_2026-10-06.md`, `nguyenthanhnhan_lb_2026-10-05.png` |
| **madarshbb** `arc-qwen-3-8-27b-agent` (public; submitted `mode: "direct"`) | Direct, one prompt **per task** (all test outputs in one reply); vLLM 0.19 server, **MTP×2** (`qwen3_5_mtp`), fp8 KV, prefix cache, 81,920 ctx, 16 seqs / 10 client threads | server `thinking_token_budget` 40,960 (likely not enforced under MTP [I]), `max_tokens` 49,152; no-think rescue with last 16k chars of notes, 8,192 tokens | **T 1.0** / 0.95 / 20; `--generation-config vllm` | **second independent sample, sample-major** (all sample 0 before any sample 1); next distinct grid, else test input | cheapest prompt first; stop 35 min before 12 h, no new sample in the last 600 s | **21.5, then 13 on a rerun** (secondary; different version slug "b98k-c16") | `RES\Reference Notebooks\LB_compare\madarshbb__arc-qwen-3-8-27b-agent\arc-qwen-3-8-27b-agent.ipynb` cells 0, 2, 9-12; E10 `…\Where tokens and time go - Poetiq R5 + web research (2026-10-15).md` |
| madarshbb REPL agent (same notebook, not submitted) | `python` tool + `submit(transform)` with train cell diff, effort ladder, hysteresis trimming, forced submit option | default max_gen 120k | – | – | – | author's own notes: "probe24: … never submitted", "mini2arm: the text nudge was read and ignored", "exp06: the NLL scorer prefers a wrong grid over the injected truth for 83 % of missed outputs" | same notebook |
| **russcore** `arcagi2-qwen38-freeform-direct` v10 | Free-form, one prompt **per test input**, space-separated digits, "give ONLY the final output grid … in a fenced ```grid block"; vLLM bf16, **no MTP**, C=24, 65,536 ctx, prefix cache; `reasoning_effort` not sent (template default = xhigh) | 57,344 total, no forced close; recovery = no-think turn with last 8k chars, 4,096 tokens | T 0.6 / 0.95 / 20 | left-right **mirror** of the test input | file order; predictive admission (p90 sample wall) | **10.14 / 7.78 / 8.61** (screenshot); "30-50 % locally" (claim) | `RES\Reference Notebooks\russcore_v343813612\russcore_LB10.14_code.py` lines 69-96, 229-345; `russell_kirk_lb_2026-10-04.png` |
| russcore v17 (`latest_pulled.ipynb`) | xhigh + optional `run_python` tool, ≤10 turns | 40,960 per turn, 3,600 s per query | 0.6 | pass 2 = **medium effort + python, risk-ordered** (no grid first), only after every query has attempt_1 | 11 waves of 24 | none documented | `russcore_v17_code.py` lines 59, 1748-2450 |
| phamtruongdat `notebookfa6c76ce70` | Non-thinking JSON direct | 4,096 out, ctx 16,384, eager | T0.7/0.8/20, n=2 | 2nd sample | – | none (expected ~0-2 %) | ARCH `PIV-SUB…\Experiment Review\PIV_Q27_SUB_V10_AND_V25A_HANDOFF_2026-10-02.md` §1 |
| Others (claims) | Anil Thomas: xhigh median ~64k, ~350 tok/s → ~30 LB estimate; juliencst 8.xx Qwen-only; Gladstone025 agent 13.75; 748082: 80 % local eval but 26.81 LB; mikelou1 ~25 → 36/38.75 closed source | – | – | – | – | – | E1 `…\sources\kaggle_discussion_745787*.md`; `RES\Planning and Prompts\GPT_DEEP_RESEARCH_PROMPT_ARC2_LB_JUMPS_2026-10-04.md`; E4 GPT audit line ~381 |
| ARC Prize official Qwen3.8-27B | xhigh 42.4 % semi-private; public eval 40/120 xhigh, 51/120 any level; ~173k output tokens per task | – | – | – | – | – | PCL "Sources" |
| NVARC Qwen3-4B TTT (team's 32.64 base) | per-puzzle LoRA r=256, DFS decoding, D8/colour augmentation, `get_puzzle_priority` easy-first | 1,200 s/puzzle | – | top-3 probmul ∪ top-3 kgmon, next unique | (tier, fine) ascending | eval 33.5/120; LB 32.22 / 32.64 | `RES\Reference Notebooks\31_experiment Notebook_arc-2026d-with-codex (22).ipynb`; `RES\Puzzle Ordering (NVARC 32.22 ref)\README.md` |

**Not in the workspace:** any primary evidence for a ~60 LB recipe with Qwen3.8-27B. Tufa Labs' duck harness is an ARC-AGI-3 harness; the journal corrected an earlier claim that Tufa used Qwen3.8 on ARC-AGI-2 (JMD §6 item 8; CJ p9, p14). The E1 R5 audit says the ~60 score "is not independently established by this bundle" (E1 `Experiment Results\R5 validate output\Validate output\r5_bundle\Q27X_RUN4_DEEP_AUDIT_2026-10-06.md` line 16). The research PDFs contain no Qwen3.8/4×L4 recipe; the Land paper (`RES\Research Papers\ARC AGI 2 research paper.pdf`) reports minimal prompts, tolerant parsing, CSV grid encoding best of 9 formats (~10 % loss for weaker formats) and independent candidates over hint chains (SCR `notes_reference_notebooks.md` §6).

**Differences from the 27.92 recipe that were never A/B-tested** (from the table): SGLang + EAGLE + mamba radix cache; T 1.0 vs 0.6; per-task vs per-query prompting; "digits + (RxC)" or CSV encoding; independent second sample after full coverage; medium+python risk-ordered second pass.

---

## 3. Recurring technical findings

### 3.1 Reasoning control and chat template
- `reasoning_effort` accepts only **xhigh / medium / low**; `"high"` raises (template contract in ARCH `ACT…\Kaggle Runs\…11_1.ipynb` cell 4; HO p4-5; cost a whole GPU run in E4 run 1).
- xhigh and low inject a system line ("Reasoning effort is set to xhigh. Please think carefully…"); **medium injects nothing**. The rendered prompt ends `assistant\n<think>\n` (SCR `notes_early_families.md` §1, §3). ARC Prize: medium used more tokens and scored lower than low (PCL "Sources").
- **Tool calls appear only after `</think>`**, so xhigh agents with ≤12k budgets never reach tools (A4). Low/forced-close activate tools but do not produce correct programs (A6, A10, A12).
- **"low" and "medium" are not short**: EVAL120 49/120 first turns ran the full 6,144 unclosed; SUB 119/240 first turns hit length; EVO12 medium 0/80 natural closes within 3,072 (SCR `notes_late_families.md` §5).
- Natural-close length: correct EVAL12 answers needed 26-37k thinking (E1 README); ledger: 68 % of solved units solved at ≤49,152, 32 % only above; natural closes hit 52 %, forced 2 % (PCL; `solved_by_tokens.csv`). E10 ORDER2: forced closes at 77.8k hit 6.8 %, natural ≤49k hit 72 %.
- **Exact forced-close text** (asserted in ACT v1.9 and used in v1.4.4): `"\n\nConsidering the limited time by the user, I have to give the solution based on the thinking directly now.\n</think>\n\n"` (25 tokens), continued token-exactly via `prompt_token_ids`; never re-render text (ARCH `ACT…\…11_1.ipynb` cell 1; HO p5-6; E5 bug review §4). An EOS before `</think>` must not precede the stop text (E5 bug review §4).
- Forced close only exits thinking; it does not guarantee a tool call or code (CJ p9; JMD §6).

### 3.2 vLLM 0.19 + MTP behaviour
- **`thinking_token_budget` is silently not enforced with MTP** (E5 v1.9.1: 10/12 requests to `max_tokens`; E4 run 4 turns at exactly 10,240 with empty content). vLLM #39573; possible workaround on newer builds `VLLM_USE_V2_MODEL_RUNNER=0` (memory note; not verified in workspace). The request-shape smoke test passed anyway (E5 `Experiment Review\README_v1_9_1_GPU_BUG_REVIEW.md` §2, §6 S6).
- With MTP on, vLLM 0.19 also ignores/rejects `min_p` and `logit_bias` (E6 README "Constraint"; E8 README "Facts checked"). `prompt_logprobs` is allowed but computes full-vocab logits per prompt token and OOM'd next to 16 long requests (E8_FINAL_REPORT §2).
- Forced named `tool_choice` with thinking on → empty `code` (59/89) and HTTP 500 `assert content is not None` in `_parse_tool_calls_from_content` when the output is all reasoning (E4 `Experiment Results\Analysis\http500_traceback_excerpt.txt`; E5 plan §0).
- MTP×3 acceptance 0.63-0.74 (E1 0.661, E4 0.736, E5 0.634, E2 0.678). MTP drafter OOM at `max_num_batched_tokens` 32,768 → use 4,096 (E1 README).
- Prefix caching: OOM in Sept at `max_num_seqs` 64 (capacity stress, A8); works with mamba `align` mode + MTP on the offline engine and removes ~50k re-prefill after each forced close (B5/B6). E10 research flags an untested risk: prefix caching + MTP silent output corruption on hybrid GDN models in newer vLLM (#43559, #53912) (E10 `…\Concurrency 16 to 25-30 - math and research (2026-10-15).md` §6).

### 3.3 Throughput, KV and concurrency
- Eager 48 tok/s → CUDA graphs 129 tok/s at 8 seqs (A8) → MTP3 + 16 seqs 249-373 tok/s (E1; E7 README) → 333 tok/s on EVAL120 (E10 ORDER2).
- KV: 159,936 tokens (eager, 29,696 ctx) → 166,992 (graphs) → **1,353,600 tokens** offline engine with fp8 KV at 81,920 (E1 run 7). Startup log lines of 337,600 / 342,400 tokens are per KV group; `/metrics` on the OpenAI server also showed 846 blocks × 1,600 = 1,353,600 (E5 bug review §6 S1). Measured peaks: 78.7 % at 16 × ~57k (E1 run 7), 68 % at 12 × 60k (E5), 91.4 % at 16 with 86k (E9 README), 0 preemptions in all.
- Fixed KV cost per running request ≈ 19-21k token-equivalents (GDN state, MTP k=3); safe concurrency today ≈ 18 DIRECT / 16 Poetiq; levers: `gpu_memory_utilization` 0.95, `mamba_ssm_cache_dtype="float16"` (bf16 unavailable in 0.19), INT4 weights (E10 concurrency doc §1-3).
- Fixed synchronous waves waste time: each wave waits for its longest member (aggregate halves with mixed lengths, A6); EVAL120 29 % of wall at ≤2 active (A14). Continuous admission fixed this (E1 v1.4+).
- TP=2 rows had only 17-18k KV and OOM'd (A8). Custom all-reduce ≈ no gain (A8). Default W8A8 block-FP8 kernel config warning on every L4 load, never tuned (SCR `notes_early_families.md` §1).
- Fail-fast: an OOM'd engine hung to a 75-min timeout and wasted 68 % of a 4.29 h run (HO p7; DA p8).
- Greedy decoding is not reproducible across restarts (identical repeat 0.1875 prefix agreement), and identical EVAL12 code scored 2, 2, 3, 1 (A8; E6 analysis). Treat ±1-2 EVAL12 hits as noise.

### 3.4 Output parsing and answer-format failures
- Strict JSON fails: v1.3.5 6/12 JSON blocks missing the outer `[` (B3); finaliser JSON truncated mid-string at a 2,048 cap (38/120, 20/183), fine at 4,096 (16/16) (A12, A14). Failed finalisers were ~65 % comment lines (A14).
- False-positive grids parsed out of truncated reasoning (A1).
- **Ragged grids**: 5/22 primary answers and 12/22 second answers in E6; 2 ragged + 2 one-cell-off in run 4 (E6 analysis; E1 run4 OUR_ANALYSIS).
- Action phase cut at the cap → malformed `<tool_call>`; code wrapped in `exec(compile(…))` blocked by the guard (A6).
- Commit/rescue requests given only the reasoning tail (7k chars of 116-182k) produce wrong programs (B14 S3).
- Near-miss metrics must be relative to the identity program (A18).

### 3.5 Crash causes seen on GPU
`-lcuda` link failure (B1); MTP drafter OOM (B2); effort `high` HTTP 400 (B9); `KeyError: base_url` (B10); local `urllib` import breaking readiness (B11); HTTP 500 on forced tool turns (B12); `prompt_logprobs` OOM killing the engine (E8); Kaggle default image moved to **Python 3.13** on 10-03 → pin `gcr.io/kaggle-private-byod/python@sha256:37c64f7d…` (ARCH `V3…\PIV_Q27_V31_S12_RESULT_2026-10-04.md`; ARCH `EVO…\Build\EVO24_build\push_kernel.py`); a transient Kaggle "system error" on v1.4 later re-scored 18.75 (E1 `v1.4.4 vs all experiments - remaining issues (2026-10-12).md` §1). Harness-only crashes caught before GPU: v2.4A `int(phase)`, v2.5 NameError after 78 min (A11, A13).

### 3.6 Sandbox constraints
- Archive sandbox: persistent subprocess worker + `sys.addaudithook` (blocks `/kaggle` FS, Popen, `os.system`, sockets) + AST guard (blocks os/subprocess/importlib…, open/exec/eval/getattr, dunders); tool timeout 10 s, verifier 20 s; **no rlimits or seccomp** (SCR `notes_early_families.md` §2).
- E4 added a PEP 578 audit hook, ctypes/cffi limits, `_posixsubprocess` neutralisation; GPT found programs could read the solutions file in eval mode (E4 GPT audit P0-B).
- Kaggle container (probe 2026-10-14): `unshare` and `mount` blocked (seccomp mode 2, no CAP_SYS_ADMIN); root with CAP_SETUID available → sandbox = subprocess + rlimits + seccomp + setuid nobody; numpy+scipy subprocess start ≈ 0.26 s (memory `kaggle-arc2-platform-limits.md`).
- Advertised libraries were only numpy/scipy/scikit-image/networkx/Pillow; PiVOTools' ortools/z3/shapely were absent (A4).

### 3.7 Measurement
- PIV LB 1.67 = its EVAL120 1.67 % exactly, while the same pipeline scored 43.6 % on the 240 *training-copy* placeholder tasks (A14, A15). Either training tasks are much easier or they are memorised [I]; either way the placeholder file is a poor proxy.
- DIRECT LB ≈ 2× EVAL12 (E1 README). EVAL12 mirror gap 25.4 pp; EVAL120 19.8 pp; EVAL20-B 1.3 pp (`RES\Eval Subset (EDA mirror)\README.md`).
- NVARC `fine` ordering does not predict Qwen solves (AUC 0.435); [≥3 train] + [1 test] rule AUC 0.57 (PCL).

---

## 4. Ideas: tried and failed vs never tried / abandoned for infrastructure reasons

### 4.1 Tried and failed (with the reason, and whether the test was fair)

| Idea | Where | Result | Fair test? |
|---|---|---|---|
| Direct answer at 12k (OFF / XHIGH) | A2 | 0/56 | No: budget far below natural-close length |
| Stateful REPL agent at xhigh, 12k | A4 | 0 tool calls | No: tools only after `</think>` |
| Effort low/medium to activate tools | A6, A10 | activation without quality; medium retired | Partly; low is not short in practice |
| Terminal commit + structured JSON finaliser | A12 | 16/16 programs, 0 correct | Plumbing works; quality budget-limited |
| One-round repair from leftover budget | A14 | 0 new TV, 52/79 truncated | No: repair cap median 1,103 tokens |
| Forced think close at 2,048 + helper library (V3.1) | A18 | = baseline | No: 2k thinking |
| Evolution, medium effort, 3k think | A19 | 0/12 | No: 0/80 natural closes |
| 49k forced close → code + JSON per task, T1.0, 1 sample | B3 | 1/22 | Fairer, but 12/12 forced, no feedback, one sample |
| Code loop with 12k repair turns | B7 | 2/22 at 92.7k tok/task | Repair turns below base; prior reasoning dropped |
| REPL agent, short turns, forced named submit, effort ladder | B12 | 0/22 | No: interface bugs + 6k turns + unenforced budget |
| Long-think synthesis via server thinking budget | B14 | 1/22 | No: budget bug, 10/12 no content |
| Flash-Next model on SGLang | B8 | garbage, 6 tok/s | Stack-specific |
| Same-reasoning second answer | E6 | +0 | Yes (EVAL12) |
| Thinking-mined candidates + NLL augmentation scoring | E8 | +0; truth absent in 0/31; OOM | Yes for candidate supply |
| Tail resample for attempt_2 | E9 | +0 on EVAL12 hard units (13/14 forced again) | Only on the hardest units; hidden unknown |
| 86k thinking for every unit in the hidden run | E9 | LB 22.92 < 27.92 | Yes: coverage binds |

### 4.2 Never tried, or dropped for infrastructure / sequencing reasons (candidates to revisit)

Ordered roughly by the strength of supporting evidence in the workspace. All keep ≥49,152 continuous thinking per request (the team rule).

1. **Code-verify (Poetiq-style) at full budget as the main path, DIRECT only where no program verifies.** September rejected program synthesis at 3-12k budgets; at 77.8k it reached 48.61 % task-norm on EVAL120, and the "Poetiq if verified, else +DIRECT" policy computed 55.14 % (E10 R5 analysis §5). Not yet run on the hidden set; round 1 alone used ~540 min on EVAL120, so time per task is the open risk (E10 R5 analysis §6). This is the realisation of the master plan's never-run PTQ rung (MP p7; HO p9).
2. **Repair with its own full budget.** v2.5 was pre-registered as a 12,288-token test but never ran standalone; every archive repair drew on leftovers (A13, A14). R6 repairs were capped at 12k (B7). In E10 R5 only 52 tasks got iteration 2 and none reached iteration 3 because of time (E10 R5 analysis §1). Feedback with preserved prior thinking (`keep_reasoning`/`preserve_thinking`) was proposed and never tested (E5 plan §2.3).
3. **K independent candidates per task with a verified pick** (SUB handoff "next quality lever"; PN p2, p32). Never done inside the REPL agent; only EVO's 4 organisms at 3k (A19). Union evidence: runs 4 ∪ 6 = 3/22 vs 2/22 each (E1 issues doc §1).
4. **Per-task prompting for DIRECT** (one reply for all test inputs). madarshbb does it; E10 Poetiq solved 14 multi-test tasks fully vs DIRECT's 5 (E10 R5 analysis §4). The only per-task run (B3) also changed answer format and temperature.
5. **Temperature A/B (0.6 vs 1.0)**, never compared fairly (E1 issues doc P10). madarshbb and Poetiq R5 use 1.0; the checkpoint default is 1.0 (SCR `notes_reference_notebooks.md` §7).
6. **Grid-encoding A/B**: CSV, or digits with explicit "(RxC)" dimensions. Planned in MP p6, never run; Land paper found CSV best of 9; madarshbb adds dims because "reasoning models miscount rows and columns". Ragged/one-cell-off answers (E6, B4) are the failure this targets.
7. **SGLang + EAGLE + mamba radix cache** (NguyenThanhNhan's 23.33 config). Planned as E11 with SGLang 0.5.21 + INT4 + DFlash2; not yet run (E11 README).
8. **KV-guarded concurrency above 16**: TP full PROBE (mns64/128, gpu 0.95, MTP-1, fp8 KV) never ran (A8); the E7 KV controller was built and shelved; fp16 SSM state + gpu 0.95 projects ~25 DIRECT streams (E10 concurrency doc §3).
9. **Independent second sample scheduled after full coverage, easy/risky-first** (madarshbb sample-major; russcore v17 medium+python pass on the riskiest units first). E9 tested only a tail resample on EVAL12's hardest units (E9 README).
10. **NVARC ∪ Qwen in one notebook / routing (master plan B1-B4).** Never run; the September unions added 0 only because the Qwen branch scored ~0. A frozen NVARC EVAL120 per-task map exists for an offline union check at no GPU cost: ARCH `EVO Program Evolution\Experiment Notebooks\Build\EVO24_build\nvarc_eval120_frozen.json`.
11. **Prompting against hand-simulation.** Traces spend 22.7 % of thinking on digit tokens and 35 % of solved-trace thinking after the first code draft; 58/104 capped Poetiq traces never wrote `def transform` (E10 `…\Where tokens and time go…md` Part A). V3's "no grid transcription / define solution() early" prompt only ran at 2k thinking (A17, A18).
12. **Shorter-thinking finetunes**: ThinkingCap-Qwen3.8-27B-FP8 (EVO plan 1a-3) and Swift-Qwen3.8-27b (memory) were never staged.
13. **Built in E10 but never run**: LOOPSTOP (degenerate-loop early close after 49k) and COVERFIRST (49k for all units first, then resume capped traces to 77.8k) (E10 README).
14. **Owning the runtime / newer stack**: own wheelhouse with sha manifest (SUB handoff §1) was never done; newer vLLM may fix #39573. `language_model_only=True` was already on from C1 v2.3 (SCR `notes_late_families.md` §0).
15. **Never run at any budget**: reviewer (Athanor), holistic judge (Land), LANG rule evolution, CORE DSL, LIB program retrieval, Squeeze routing, ARCgentica delegation, Noemon port (CPU preflight NO-GO on context at 29,696; context is now 81,920+), vision branch, self-consistency stop (MP p8-10; PN; ND p15-17; SCR `notes_journals_pdfs.md` §2).
16. **Small untested items**: OFF-mode `presence_penalty 1.5` on grid output (A2); tuned FP8 GEMM configs for L4 (A8); TP2×2 replicas (A8).

---

## 5. Corrections to existing workspace summaries

- ARCH README says EVO "built and reviewed; no GPU result": **EVO12 did run** (0/12; `EVO12_run\eval120\evo_report.json`).
- The v2.5/v2.5A/v2.5B "Kaggle runs" carry copied papermill metadata; the code ran on GPU only inside EVAL120-MEASUREMENT and SUB v1.3 at 8,192 tokens (SCR `notes_late_families.md` §0).
- The 10-03 review zip's ANALYSIS_SUMMARY says EVAL120 took ≈7 h; `run_metadata.json` says 16,379 s (4.55 h).
- Handoff advice to "test `language_model_only=True`" was moot: it was on in every GPU run from C1 v2.3.
- `Experiment Notebooks\` copies in PIV/ACT carry an inherited papermill block (09-13 06:17), not evidence of execution; TP `_pc.zip` self-test throughput numbers are synthetic.
