# LB-submitted notebooks: what the COMPETITION RERUN (hidden test) actually does

Scope: the six exact submitted sources (read cell by cell). Extracted code lives next to this file:
`nb1_piv13.txt` (PIV v1.3), `nb2_v14.txt` (v1.4), `nb3_v144.txt` (v1.4.4), `nb4_e7.txt` (E7), `nb5_e9.txt` (E9),
`nb6_r5.txt` (R5). Line numbers below refer to these files. "CELL n" = JSON cell index (code headers call it "CELL n-1").

Times are seconds from `NOTEBOOK_T0` (`time.perf_counter()` in the first code cell). Kaggle's 12 h clock also counts
container start + model mount before that cell (not visible in code).

Measured engine facts used below come from the GPU commit runs of the same code (same engine path as the rerun):
`Q27X_run6_v141`, `Q27X_run7_v144`, `GPU EVAL12 E9`, `GPU EVAL120 Poetiq R5` run reports under `D:\ARC AGI 2\experiments`.
The `e7_out` log in `lb_nbs` is truncated during pip install (0.74 min) and its submission.json is the commit-mode
identity file (259/259 attempt_1 == attempt_2), so it gives no engine evidence.

| measured (commit runs) | v1.4.1 run6 | v1.4.4 run7 | E9 EVAL12 | R5 EVAL120 |
|---|---|---|---|---|
| KV / attention / spec | fp8_e4m3 / FLASHINFER / MTP3 | same | same | same |
| prefix caching, mamba mode | on, `align` | on, `align` | on, `align` | on |
| kv_tokens (pool, all groups) | 1,353,600 | 1,353,600 | 1,353,600 | 1,353,600 |
| concurrency | 16 | 16 | 16 | 16 |
| model load / setup→scheduler | 581 s / 715 s | 611 s / 789 s | 573 s / 701 s | 600 s / n.a. |
| aggregate tok/s | 285 | 275 | 307 | 281 |
| MTP acceptance | 0.655 | 0.661 | 0.655 | n.a. |
| prefix-cache hit rate | 0.786 | 0.572 | 0.814 | n.a. |
| mean generated tokens / request | 47.3k | 48.2k | 66.7k | p1 mean 66.1k (median 77,824 = cap) |
| forced closes | 17/22 | 19/22 | 13/22 (+4 drained) | 104/172 |
| preemptions | 0 | 0 | 0 | n.a. |

---------------------------------------------------------------------------------------------------------------------

## 1. Per-notebook rerun behaviour

### 1.1 PIV-Q27-SUB v1.3 (LB 1.67): agentic Python-REPL program synthesis, tiny budget

Not dual-mode. `RUN_PROFILE = "SUBMIT"` is hard-coded (nb1:556), and every run (commit or rerun) solves the attached
`arc-agi_test_challenges.json` (TESTALL, all tasks, sorted ids; nb1:1756-1766).

**Method (per task, one lineage):** this is the PiVOTools agentic-coding loop. It has a system prompt with the Python
tool contract (10 s tool timeout, libraries probed live), the source agentic prompt containing all train pairs and all
test inputs (space-separated rows), and Qwen XML tool calls into a persistent subprocess REPL. Limits: 6 executed
calls, 12 turns, `max_retries` 2 (nb1:625-634).
- Exploration ends on a token cap, a turn slot or the tool budget. Then a **terminal commit** runs: no tools,
  `enable_thinking=False`, JSON-schema structured output `{"solution_code"}` (nb1:3936-4057).
- A fresh-process verifier checks train; **test is executed only if all train pairs are exact** (nb1:2387-2441).
- Cell 11 runs one repair round (non-thinking JSON with verifier feedback) for train-failed programs (nb1:5326-5533).
- Cell 12 runs a CPU pass that executes unverified programs on the test inputs (≤ 20 min, ≤ 3 programs/task;
  nb1:5553-5640).
- attempt_1 = best-ranked program output. Ranking (nb1:1061-1083): rank 2 train-verified > rank 1 unverified
  final_code > rank 0 rejected repair candidate, then train-exact pairs. attempt_2 = next distinct output, else
  **identity (test input)**. A task with no candidate gets identity for both.

**Budgets:** total generated tokens per task = **8,192** (nb1:631). Exploration cap 6,144 and finalizer reserve 2,048
(nb1:680-685). Per-turn cap = min(remaining exploration, context room, 8,192) (nb1:3487-3503). Repair cap =
min(2,048, leftover of the 8,192, context). `max_model_len` 29,696. Reasoning effort is **"low"** (arm ACT-LOW,
natural close, no forced close; nb1:665, 752). Nothing comes close to the 49k base.

**Engine (nb1:2915-2949, 3005):** TP4, **bf16 KV (no kv_cache_dtype)**, **no MTP**, **prefix caching OFF**,
enforce_eager False, custom all-reduce off, max_num_seqs 16, max_num_batched_tokens 32,768, gpu 0.90, attention backend
vLLM default (not set). Single `LLM()` attempt with no ladder; a bootstrap failure leaves the identity submission.

**Sampling:** exploration T 1.0, top_p 0.95, top_k 20, min_p 0. The seed is 3042 + retry nonce, so every task uses
the same seed (nb1:3114-3118, 4089). Finalizer and repair: T 0.7, top_p 0.8, top_k 20 (nb1:725-732).

**Scheduling:**
- Synchronous `LLM.generate` waves over batches of **12 tasks** (nb1:3760). A batch runs in lock-step: each wave
  waits for its slowest request, and the next batch starts only when all 12 tasks finish.
- First the 2 lowest-id tasks run as an **interface gate**. If either lacks a usable artifact or has any
  infrastructure failure, the other 238 tasks are skipped (nb1:5084-5195).
- Safety deadline = start + 43,200 − 4,500 = **38,700 s (10:45)** (nb1:855, 2890).
- Every wave is pre-checked: now + max_cap × max(0.20, p90 s/token) × 1.25 + 90 s. If that crosses 10:45, the
  remaining tasks of the batch are marked failed and **all later batches never start** (nb1:4105-4121). A full
  6,144-token wave projects to about 27 min, so generation stops around 10:18-10:45.
- The finalizer is pre-checked against 42,600 s. The repair round and the CPU pass are bounded by 38,700 s.
- Tasks never started keep identity.

**Limits on coverage:** lock-step waves (slots idle on the tail of every wave and batch), no MTP, bf16 KV, at least
75 min of reserve unused, the 2-task gate, and an 8k low-effort budget.

### 1.2 Q27-XHIGH v1.4 (LB 18.75, after a Kaggle "system error" and re-score): direct reasoning, 49k

**Method:**
- One prompt per **test input** (259 units, sorted task id then query; nb2:297-302, 788).
- Prompt: russcore LB-10.14 free-form ("Example i INPUT/OUTPUT … FINAL INPUT … give ONLY the final output grid …
  inside ```grid"; nb2:277-294). No system prompt; chat template `enable_thinking=True, reasoning_effort="xhigh"`.
- Parser: last fenced block holding a valid grid, else the last run of digit rows (nb2:395-415).
- **attempt_1 = model grid; attempt_2 = test input** (nb2:417-427). If the model returned the input, attempt_2 is
  its row-reversed mirror. With no grid: attempt_1 = test input, attempt_2 = mirror.
- Units never finished or never admitted: identity in both (cell 0 file, then the `write_submission` overlay;
  nb2:121-125, 705-713).

**Budgets:**
- Phase-1 `max_tokens` = min(**49,152**, 81,920 − prompt − 8,192 − 256) (nb2:150-160).
- If thinking never closes: EOS stripped, then `STOP_THINKING_TEXT` ("\n\nConsidering the limited time by the user, I
  have to give the solution based on the thinking directly now.\n</think>\n\n") appended token-exact. A second
  request (prompt + thinking + stop) gets ≤ **8,192** answer tokens (room ≥ 64 required) (nb2:726-740).
- If thinking closed but the answer was length-cut: continue ≤ 8,192.
- Drain answer cap 8,192. `MAX_MODEL_LEN` 81,920. Units with < 4,096 thinking room are skipped (identity).

**Engine (nb2:535-666):**
- TP4, fp8_e4m3 KV, MTP 3, ladder FLASHINFER (only if the `-lcuda` link probe passes) → TRITON_ATTN → bf16 FLASH_ATTN
  + MTP → bf16 without MTP.
- **prefix caching OFF**, gpu 0.90, max_num_batched_tokens 4,096, max_num_seqs 16, CUDA graphs on,
  `VLLM_MEMORY_PROFILER_ESTIMATE_CUDAGRAPHS=1`.
- Concurrency = max(4, min(16, kv_tokens // 30,000)), which is 16 at 1,353,600.
- Without prefix caching, every forced close re-prefills the whole ~50-57k context in 4,096-token chunks.

**Sampling:** T 0.6, top_p 0.95, top_k 20. Seeds SEED + 10·unit_index + phase.

**Scheduling (12 h budget, nb2:137, 185-191):** continuous admission via `engine.step()`.

| | sec | h:mm |
|---|---|---|
| ADMIT_DEADLINE | 37,800 | **10:30** |
| DRAIN | 39,960 | **11:06** (force-close in-flight thinking, answer ≤ 8,192) |
| HARD_STOP | 41,700 | **11:35** (abort; partial answers parsed) |

So 36 min pass with no new admissions while slots empty, followed by a 29-min answer window. Units not admitted by
10:30 keep identity.

### 1.3 Q27-XHIGH v1.4.4 (LB 26.94)

Identical to v1.4 except for three changes:
- **Prefix caching first.** The ladder is fp8 + FLASHINFER + PC → same without PC → fp8 TRITON → bf16 … (nb3:642-649).
  Measured: prefix caching resolved, mamba `align`.
- **New rerun clock.** Budget 42,600 s (11:50), hard margin 6 min, then fixed offsets (nb3:170-173, 224-231):

| | sec | h:mm |
|---|---|---|
| ADMIT | 41,640 | **11:34** |
| DRAIN | 41,760 | **11:36** |
| HARD_STOP | 42,240 | **11:44** |
| (VERIFY, unused) | 42,420 | 11:47 |

  Slots stay full until 11:34. At 11:36 everything still thinking is force-closed with 8 min to answer.
- Prefix-cache metrics are added to the report.

Method, attempts, budgets and sampling are unchanged.

### 1.4 E7 ORDERING ONLY v2 (LB 27.92, best)

v1.4.4 plus a single rerun change: the unit queue follows Codex/NVARC `get_puzzle_priority(tid, test_challenges)`,
sorted ascending by (tier, fine). Tier 1 (small, static) goes first and tier 3 (dynamic, ratio > 30) last; ties keep
file order (nb4:321-412, 907). Everything else is v1.4.4 (the commit-run profile PROXY48 does not affect the rerun).

### 1.5 E9 86k + tail resample (LB 22.92)

E7 minus the ordering (back to sorted ids, nb5:923), plus:
- **THINK_BUDGET 77,824**, answer 8,192, **MAX_MODEL_LEN 106,496** (nb5:191-203).
- `EXPECTED_LIVE_TOKENS_PER_SEQ` 43,000, which still gives 1,353,600 // 43,000 = 31, so **16** slots.
- **Tail resample (nb5:848-920, 944-949).** Only when the primary queue is empty and before 11:34, free slots run one
  new-seed resample per finished unit, at the same 77,824 cap. Priority: no grid > forced close/no room > natural
  close ≥ 70,041 think tokens. A valid grid different from both attempts **replaces attempt_2 only**.
- Same clock as v1.4.4 (11:34 / 11:36 / 11:44).
- Measured EVAL12: mean generated per unit 66.7k (v1.4.4: 48.2k), live tokens p90 85.4k, 0 preemptions.

### 1.6 E10 Poetiq R5 (EVAL120 commit; LB 21.39): program synthesis with iterative refinement

**Method:**
- Units = **tasks** (240), one prompt holding all train pairs (shuffled per iteration) and **all test inputs**
  ("Challenge #i"; nb6:281-312).
- Prompt: Poetiq donor SOLVER_PROMPT_1 verbatim (nb6:511-655, 883) asking for `transform(grid: np.ndarray)` in a
  ```python block.
- From iteration 2, a FEEDBACK block lists up to 5 best earlier programs (code + train diff feedback + soft score,
  worst→best).
- Each answer's code runs in the sandbox (UID 65534, seccomp, rlimits; one fresh subprocess per train input and per
  test input, 5 s timeout, 4-thread pool, asynchronous; nb6:360-460).
- The task stops when a program is train-exact and runs on all test inputs; otherwise it is re-queued, up to
  **10 iterations, 1 expert** (nb6:161-175, 1301-1332).
- **Attempts (nb6:492-506):** distinct valid grids from voted programs (expert best + other usable history).
  attempt_1 = first; **attempt_2 = second, else a duplicate of attempt_1**; with no usable program, **both = test
  input**. There is no direct-grid or mirror fallback. A program is usable only if it yields valid grids for *all*
  test inputs.

**Budgets:**
- Per iteration phase-1 = min(77,824, 106,496 − prompt − 8,448).
- Forced close works as in Q27 (stop text, answer/code ≤ 8,192).
- **Minimum 49,152**: if the cap falls below it, low-score feedback examples are trimmed; if still below, the task is
  marked `insufficient_context` and finished (nb6:1214-1245).
- Drain answer 8,192.

**Engine:** identical to E9 (ladder with prefix caching, fp8, MTP3, 16 slots). The ladder is emptied, and the run
falls back to identity, if the sandbox self-test fails (nb6:1065-1067). That self-test passed on the hidden run.

**Sampling:** **T 1.0**, top_p 0.95, top_k 20 (nb6:1204-1209). xhigh thinking, no system prompt.

**Scheduling:**
- Deque of 240 tasks in sorted order. A finished-but-unsolved task is appended to the **back** (nb6:1328), so
  iteration 2 of any task starts only after all 240 iteration-1 requests are admitted.
- Same 11:34 / 11:36 / 11:44 clock.
- At HARD_STOP, in-flight requests are aborted and their code is sent to verification. The harvest loop then waits
  `endwait = min(HARD_STOP, now + 10)`, which is already ≤ now, so **those verifications are never committed**
  (nb6:1392-1397, 1452-1456).
- The `with ThreadPoolExecutor` exit still waits for them to finish.
- Tasks never admitted: identity.

**Measured on EVAL120 (same clock, 120 tasks):**
- 172 requests: 120 iteration 1 + 52 iteration 2, none beyond. The last iteration-1 result came at about 32,400 s
  (9 h).
- Median request wall time 4,255 s (71 min) at 16 concurrent. 104/172 force-closed.
- Hits 78/172: pass1 77, pass2 69 (attempt_2 added +1). 49 tasks were still queued at the end.

---------------------------------------------------------------------------------------------------------------------

## A. Comparison table (competition rerun path)

| field | PIV v1.3 | v1.4 | v1.4.4 | E7 | E9 | R5 |
|---|---|---|---|---|---|---|
| LB | 1.67 | 18.75 | 26.94 | **27.92** | 22.92 | 21.39 |
| method | agentic REPL → code, fresh train verify, 1 repair, CPU test pass | direct grid, 1 pass / test input | = v1.4 | = v1.4.4 | direct grid + tail resample | Poetiq program synthesis, ≤10 sequential iterations / task |
| unit | task (240) | test input (259) | 259 | 259 | 259 (+ resamples) | task (240) |
| attempt_1 | best program output (verified > unverified) | model grid | model grid | model grid | model grid | 1st voted program grid |
| attempt_2 | next distinct program output, else identity | test input (mirror if grid == input) | same | same | resample grid if valid and different, else test input/mirror | 2nd distinct grid, else **duplicate of attempt_1** |
| no-answer fallback | identity ×2 | test input + mirror (no grid); identity ×2 (never admitted) | same | same | same | identity ×2 |
| thinking / request | low effort, total 8,192 per task (explore 6,144) | 49,152 | 49,152 | 49,152 | **77,824** | **77,824** per iteration |
| answer cap | finalizer 2,048 (non-thinking JSON) | 8,192 | 8,192 | 8,192 | 8,192 | 8,192 (code) |
| max_model_len | 29,696 | 81,920 | 81,920 | 81,920 | 106,496 | 106,496 |
| min budget rule | none (oversized prompts skipped) | skip if < 4,096 | same | same | same | skip task if < 49,152 after feedback trim |
| forced close | n/a (ACT-LOW natural) | stop text + `</think>`, 2nd request, full re-prefill | same + prefix cache reuse | same | same | same |
| KV dtype / spec | bf16 / none | fp8_e4m3 / MTP3 | same | same | same | same |
| attention ladder | vLLM default, single attempt | FI → TRITON → bf16 FA2 (+MTP) → bf16 no MTP | FI+PC → FI → TRITON → bf16 FA2 → bf16 no MTP | same | same | same (empty if sandbox self-test fails) |
| prefix caching | off | **off** | on (align) | on | on | on |
| max_num_seqs / slots | 16 / 12-task lock-step waves | 16 / 16 (continuous) | 16 / 16 | 16 / 16 | 16 / 16 | 16 / 16 |
| batched tokens / gpu mem | 32,768 / 0.90 | 4,096 / 0.90 | same | same | same | same |
| sampling | T 1.0 / 0.95 / 20 (finalizer 0.7 / 0.8 / 20) | T 0.6 / 0.95 / 20 | same | same | same | **T 1.0** / 0.95 / 20 |
| prompt | PiVOTools system + agentic prompt, tools | russcore free-form, grid fence | same | same | same | Poetiq SOLVER_PROMPT_1 + feedback |
| order | sorted ids, 12-task batches | sorted ids | sorted | **easy tier first** | sorted | sorted, round-robin iterations |
| admit stop | wave pre-check vs 10:45 (≈10:18-10:45) | 37,800 s = 10:30 | 41,640 s = 11:34 | 11:34 | 11:34 (resample too) | 11:34 |
| drain (force close) | n/a | 39,960 s = 11:06 | 41,760 s = 11:36 | 11:36 | 11:36 | 11:36 |
| hard stop | 38,700 s = 10:45 (finalizer ≤ 42,600) | 41,700 s = 11:35 | 42,240 s = 11:44 | 11:44 | 11:44 | 11:44 (pending verifications dropped) |
| extra load | repair round + CPU pass after sweep | none | none | none | resamples in tail slots | iterations re-queued after verification |

---------------------------------------------------------------------------------------------------------------------

## B. Code diffs between consecutive versions and the LB moves

Noise reference: identical notebooks have shown about ±3 LB run-to-run on this competition.

### v1.4 → v1.4.4 (18.75 → 26.94, +8.2)

Rerun-relevant diffs (full `diff nb2_v14.txt nb3_v144.txt`):
1. **Prefix caching on** (nb3:204-205, 642-675, 702-703). The first ladder rung adds `enable_prefix_caching=True`.
   The forced-close second request then reuses the KV/GDN state of prompt + thinking (all but the last partial
   1,600-token block) instead of re-prefilling about 50k tokens in 4,096-token chunks. The v1.4.1 note measured this
   re-prefill at about 12 % of scheduler time. Hit rate in later commit runs was 0.57-0.79.
2. **Rerun clock** (nb3:170-173, 224-231).

| | v1.4 | v1.4.4 |
|---|---|---|
| admit | 10:30 | **11:34** (+64 min of admission) |
| drain | 11:06 | **11:36** (+30 min of thinking for in-flight units) |
| hard stop | 11:35 | 11:44 |
| budget | 12:00 | 11:50 |

3. Metrics and reporting only (prefix-cache counters).

No change to prompt, budgets, sampling, parser or attempts.

Attribution: both real changes raise the number of hidden units that get a full-budget answer before the deadlines.
The +8.2 is well above the noise, so these diffs plausibly explain the move. The split between (1) and (2) cannot be
separated from code alone. Also note: v1.4's 18.75 came from Kaggle's re-score after a "system error". Whether that
re-score is fully comparable is unknown.

### v1.4.4 → E7 (26.94 → 27.92, +1.0)

The only rerun diff is queue order (nb4:321-376 `get_puzzle_priority`, 408-412 `ORDERED_UNITS`, 907 queue), plus
record fields and the commit profile PROXY48. Mechanism: the units truncated at the 11:36 drain or never admitted are
now the hardest tiers, which are least likely to be solved anyway. Easy units get the full 49k. **+1.0 is inside the
±3 noise.** The direction fits the mechanism, but the size is not established.

### E7 → E9 (27.92 → 22.92, −5.0)

Three bundled changes (diff nb4/nb5):
1. THINK 49,152 → **77,824**, MAX_MODEL_LEN 81,920 → 106,496 (nb5:191-203).
   `EXPECTED_LIVE_TOKENS_PER_SEQ` 30k → 43k has no effect (still 16 slots).
2. **Ordering removed** (sorted ids again; nb5:923).
3. **Tail resample** (nb5:848-949). It only changes attempt_2 and only runs once the primary queue is empty before
   11:34.

Attribution:
- On EVAL12 the per-unit generated tokens rose from 48.2k to 66.7k (+38 %) at similar aggregate throughput
  (275 → 307 tok/s). Each unit therefore holds a slot about 1.3-1.4× longer, so fewer hidden units finish inside the
  same 11:34/11:36 window. Unfinished units are identity, which scores 0.
- With ordering gone, the uncovered or drained tail is random difficulty, including easy units that E7 protected.
- The resample cannot reduce attempt_1. If the primary queue never empties before 11:34 on the hidden run, it never
  fires. That is plausible at 86k, but the hidden run's log was not seen.
- −5.0 exceeds the noise. It is consistent with the user's earlier conclusion that hidden coverage/time binds at 86k.
  How much belongs to (1) versus (2) is not separable (speculative).

### E9 → R5 (22.92 → 21.39, −1.5)

R5 replaces the direct scheduler and attempt policy completely:
- Cells 4-8 rewritten. Poetiq prompt and feedback, Python sandbox, per-task units with all test inputs in one prompt.
- Sequential iterations (≤10) re-queued round-robin. Temperature 1.0 (was 0.6).
- 49,152 minimum admission rule. Voting attempts with a duplicate attempt_2 and no grid or mirror fallback.
- Resample removed. Same 86k budget, engine and clock.

Attribution:
- −1.5 is inside the noise relative to E9. Relative to E7 (−6.5) it shares E9's 86k coverage problem.
- It adds: code-only answers (a task whose program fails to parse or crashes on any test input contributes nothing);
  refinement that the clock rarely reaches; a near-wasted attempt_2 (EVAL120: +1 hit from attempt_2); T 1.0.
- R5's eval advantage (EVAL120 task-norm 48.61 % vs ORDER2 DIRECT 36.94 %) was measured on **120** tasks within the
  hidden clock: 172 requests, 1.43 per task.
- The hidden set has **240** tasks. At eval-like request lengths, that is about 0.7 requests per task, so even
  iteration 1 would not cover every task, and almost no iteration 2 would run.
- Hidden puzzles are easier and shorter, so the real ratio is better than this. The direction of the effect is
  structural; its size is speculative.

---------------------------------------------------------------------------------------------------------------------

## C. Bugs / risky behaviours in the rerun path

1. **v1.4 dead tail (fixed in v1.4.4).** No admission after 10:30 while slots empty, and no prefix cache, so every
   forced close re-prefilled ~50-57k tokens.
2. **attempt_2 wasted in all direct versions** (v1.4-E9, except E9 resamples). attempt_2 = test input or mirror,
   which is almost never correct on ARC-AGI-2, so in practice only attempt_1 scores.
3. **R5 duplicates attempt_2** (nb6:502). With 1 expert and usually 1 usable program, attempt_2 == attempt_1.
   EVAL120: pass2 69, combined gain +1.
4. **R5 has no fallback answer.** No program, a parse failure, or failure on *any* test input
   (`test_usable = all(...)`, nb6:448) gives identity for every query of the task, even when the reasoning was right.
   Multi-test tasks lose all their queries when one input crashes.
5. **R5 round-robin starves refinement** (nb6:1328). Iteration k+1 of any task waits behind iteration k of all 240
   tasks. On EVAL120 iteration 1 alone took about 9 h for 120 tasks.
6. **R5 drops hard-stop verifications** (nb6:1452). `endwait = min(HARD_STOP, now + 10)` ≤ now at that point, so
   programs harvested at 11:44 are never scored. The pool exit then blocks until those subprocesses finish (wasted
   seconds after the hard stop).
7. **R5 sandbox gating** (nb6:1065-1067). Any self-test failure (root, libseccomp, the clone filter) empties the
   engine ladder, so LB = 0. It passed this time; this is a single point of failure.
8. **R5 parser takes the FIRST ```python block** (nb6:293-295). An illustrative snippet written before the real
   solution would be the one executed.
9. **Late admissions (v1.4.4+).** Units admitted at 11:00-11:34 get minutes of thinking before the 11:36 drain. They
   use a slot and prefill but rarely score. With sorted order (v1.4.4, E9, R5) these include easy units; E7's
   ordering mitigates it.
10. **8-min drain window (v1.4.4+).** 16 concurrent forced answers at about 290 tok/s give roughly 8.7k tokens per
    stream, which is enough for a ≤ 2.7k-token grid. Long prose before the grid, or long R5 code, can be cut at
    11:44. The hard-stop path then parses partial text; the "last digit-row run" rule can turn a half-written grid
    into attempt_1 (wrong but harmless).
11. **E9 KV head-room.** At ~94k live tokens a sequence needs about 59 attention + 12 GDN blocks. 16 × 71 = 1,136 is
    more than the 846-block pool, so preemption is possible when many long sequences coexist. EVAL12 showed
    0 preemptions. The `kv_tokens // EXPECTED_LIVE` rule divides the shared multi-group pool, so it never binds
    (always 16).
12. **E9 resample effects.** Resample only fires on an empty queue and keeps 16 streams busy, which slightly slows
    the last primaries before the drain (speculative, small). It never swaps a no-grid primary's test-input
    attempt_1, which has no score effect.
13. **PIV gate.** The 2 lowest-id hidden tasks gate the whole sweep (nb1:5093-5195). One pilot task without a usable
    artifact means 238 tasks stay identity.
14. **PIV throughput design.**
    - Lock-step 12-task waves: the slowest request sets each wave's time and a batch keeps its slots until all 12
      finish. No MTP, bf16 KV.
    - Deadline 10:45 plus a wave projection with ≥ 0.20 s/token stops generation around 10:18-10:45, and **later
      batches are never started** (`stop_all`).
    - 8k low-effort budget per task. The same seed (3042) is used for every task.
15. **Clock base.** Every deadline is measured from cell 0, not from container start. v1.4's 12 h budget ended at
    11:35 + outputs. The v1.4.2 note links its "system error" to running too close to the limit. v1.4.4+ keep about
    16 min before 12 h minus the pre-cell-0 time.

## D. Capacity arithmetic (bounds, not a hidden-run projection)

Measured commit-run aggregate rate is about 275-307 tok/s, with about 700-790 s setup. Generation up to the 11:34
admit deadline is about 40,900 s, so **≈ 11.5-12.5 M generated tokens**. R5's EVAL120 run actually produced
11.65 M.

Demand if every unit used its whole cap:

| config | demand |
|---|---|
| v1.4.4 / E7 | 259 × 57,344 ≈ 14.9 M |
| E9 | 259 × 86,016 ≈ 22.3 M |
| R5, iteration 1 only | 240 × 86,016 ≈ 20.6 M |

Hidden puzzles are easier, so their actual per-unit usage is lower; these numbers are not hidden-coverage estimates.
What is structural is that the 86k configurations need about 1.4-1.5× the tokens of the 49k ones per pass inside the
same clock. R5 also asks for further sequential passes on top of that.
