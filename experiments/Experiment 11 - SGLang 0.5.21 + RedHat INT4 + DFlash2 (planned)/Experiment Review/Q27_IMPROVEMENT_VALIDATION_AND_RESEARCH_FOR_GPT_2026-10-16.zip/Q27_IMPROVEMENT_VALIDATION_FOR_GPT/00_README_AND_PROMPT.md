# ARC Prize 2026 (ARC-AGI-2) · Qwen3.8-27B on Kaggle 4×L4 — validate our improvement ideas and research new solutions

You are reviewing a Kaggle team's work. Please do three jobs:

1. **Validate or refute** each improvement idea in section 4 against the data in this zip. Check the numbers in `02_data/` and the code in `03_notebooks/`. Do not trust our prose.
2. **Research.** Find other solutions to our bottlenecks on GitHub, Hugging Face, Kaggle (ARC Prize 2025 and 2026 notebooks, write-ups and discussions), the web, and research papers (2024–2026). Give links.
3. **Plan.** Recommend how to use our GPU run budget (section 2) for the largest leaderboard gain before the deadline.

Answer in the format of section 6. Cite a source for every external claim, mark speculation, and do not invent numbers.

---

## 1. The problem in one paragraph

Our best public LB with Qwen3.8-27B is **27.92**. That run used direct reasoning: one request per test input, 49,152 xhigh thinking tokens, a forced close, then a grid answer, with easy tasks first.

On the public evaluation set, the same model does much better:

| Method | Eval, task-normalised |
|---|---|
| Direct reasoning at 77,824 thinking tokens | 36.9 % |
| Poetiq-style program synthesis with train verification | 48.6 % |
| Union of the two runs | 56.8 % |

When we submitted those stronger methods, the LB fell to 22.92 and 21.39. The hidden puzzles are about as hard as eval: an earlier belief that they are easier came from a placeholder file and was wrong. So LB ÷ eval is the share of the hidden run that finished inside the 12 h limit:

| Run | LB ÷ eval |
|---|---|
| 49k direct | ≈ 1.0 |
| 86k direct | 0.62 |
| Poetiq | 0.44 |

The hidden rerun holds about **240 tasks** (public 120 + private 120). Our EVAL120 runs needed 534 min (86k direct) and 704 min (Poetiq) for 120 tasks. **The binding problem is finishing the work inside 12 h.** The model's per-task ability is not the limit.

## 2. Hard constraints

**Platform**
- Kaggle code competition: 4× NVIDIA L4 (24 GB each, sm_89), no internet, 12 h wall per hidden rerun including container start, model load and install.
- 2 attempts per test input; score is the task-normalised share of correct test outputs.
- Public LB = exactly 120 tasks (every LB score × 1.2 is a whole number or a ½, ⅓ or ⅙). The rerun also scores about 120 private tasks.
- Sandbox for code execution: a plain subprocess + rlimits + seccomp + setuid. `unshare` and `mount` are blocked; we are root without CAP_SYS_ADMIN.

**Model:** Qwen3.8-27B. It is hybrid: 64 layers = 48 Gated DeltaNet (linear attention) + 16 full-attention layers, with 4 KV heads × 256. It has an MTP head.
- The chat template supports `reasoning_effort` xhigh, medium or low only; "high" raises an error.
- **Today's stack:** FP8 checkpoint, vLLM 0.19.0, fp8 KV, MTP with 3 speculative tokens, at most 16 sequences, about 351 tok/s aggregate at 16 active.
- **Being tested tomorrow:** SGLang 0.5.21 + RedHat INT4 W4A16 (compressed-tensors) + the z-lab DFlash2 drafter (block 8). See `03_notebooks/E11_03_*` and `04_readmes/`.

**Team rules (please respect them)**
- The team's position is that Qwen3.8-27B can reach LB 60–80+. Another team reportedly reached about 60 with this model.
- Do not make "fine-tune the model" or "impossible" the answer. Focus on inference-time method, scheduling, throughput, prompting and use of the two attempts.
- No thinking budget below **49,152 tokens per request**. If you think a lower one helps, flag it as a proposal that needs approval.
- Keep code simple: one change at a time, measured.

**Run budget**
- **Today:** 2 × 12 h GPU runs.
- **After that:** about 4–5 × 12 h runs per week, once a week.
- **Deadline:** 2026-11-02, about 2.5 weeks away.
- **Submissions:** about 1 per 2 days, one pending per team, about 33 h queue.
- **LB noise:** identical notebooks scored sd 1.0–1.65 LB points (one notebook, submitted 10 times, scored 27.36–32.64).

## 3. Key measured facts (where to check them)

All numbers are in `01_analysis/Qwen3.8-27B LB and run deep analysis (2026-10-16).md`, recomputable from `02_data/`.

**LB history:** `02_data/lb_submissions_all.json`; code diffs in `01_analysis/LB_notebooks_rerun_analysis.md`.
- PIV 1.67 → v1.4 18.75 → v1.4.4 26.94 → E7 27.92 → E9 22.92 → R5 21.39.
- v1.4 → v1.4.4 changed only the clock (admission to 11:34) and the prefix cache: **+8.2**.

**Time model (section 3 of the main analysis):** each EVAL120 run's pace, scaled to 240 tasks and about 680 usable minutes.

| Method | Coverage today | Speed-up for full coverage | Expected LB |
|---|---|---|---|
| 86k direct | 65 % | 1.54× | ~37 |
| Poetiq R5 | 49 % | 2.04× | ~49 |
| Poetiq iteration 1 + direct on unverified tasks | — | 2.55× | ~52 |
| Both methods on every task | — | 3.57× | ~57 |

The model predicted the real LB within about 1–4 points.

**Where tokens go** (`02_data/units.csv`):
- 75 % of tokens go to units that are never solved.
- **59.7 % of all tokens went to forced closes that produced no hit.**
- Hit rates:

| Outcome | Hit rate |
|---|---|
| Direct, natural close at ≤ 49k | 72 % |
| Direct, natural close at 49–78k | 30 % |
| Direct, forced close | **8 %** |
| Forced Poetiq iteration that still wrote a train-passing program | 19 % |

- Direct solves needing ≤ 49k: 67 %. Poetiq solves needing ≤ 49k: 23 %.

**Token sinks in thinking** (`01_analysis/Where tokens and time go…`):
- 22.7 % of thinking is digit tokens (hand-reading grids cell by cell).
- 58 of 104 forced Poetiq traces never wrote any code.
- About 35 % of solved-trace thinking is mental re-checking of code.
- Loops: direct 4/172, Poetiq 0/172.

**Throughput** (`02_data/runs.csv`, `timeline.csv`):
- 6 → 16 sequences gave 1.73×; we have never run above 16.
- About −5 % per +10k live context per sequence.
- Poetiq at T = 1.0 ran about 16 % slower: MTP acceptance 0.557 vs 0.669, KV at 99.5 % evicted the prefix cache (4.18 M re-prefill tokens), and 9 preemptions.

**Variance** (`02_data/unit_outcomes.csv`):
- Each rerun is an independent sample despite fixed seeds.
- ORDER2 58 ∪ R5 78 = 92 units.
- A natural close predicts the hit: 89 % vs 14 % when forced.

**attempt_2 is wasted** in every submitted version:
- direct versions use the test input or its mirror;
- R5 copies attempt_1 when it has only one program.
- Measured so far: a same-reasoning second answer gave +0 (E6); NLL-ranked grids from thinking gave 0/31 (E8); a tail resample gave 0 (E9).

**Archive lesson** (`01_analysis/archive_qwen_digest.md`): every earlier program-synthesis or agent failure ran at 3k–12k tokens per task or turn, below Qwen's natural-close length of about 26–45k. At 77,824 per iteration, Poetiq works.

## 4. Ideas to validate

For each idea, give: **verdict** (confirmed / partly / refuted), the **evidence** (file + numbers), the **expected LB effect**, the **cost** (GPU-hours, engineering days), the **risk**, and a **minimal test** that fits our run budget.

- **I1 Throughput is the master lever (Experiment 11).**
  - SGLang 0.5.21 + INT4 W4A16 + DFlash2 (block 8, BF16 drafter with `--speculative-draft-model-quantization unquant`).
  - More than 16 concurrent sequences.
  - SSM state float32 vs float16, mamba radix cache `extra_buffer`.
  - Targets: 1.54× / 2.04× / 2.55× / 3.57× (table above). Are these speed-ups realistic on 4×L4 for this hybrid model? What do others measure?
- **I2 Code execution inside reasoning.** Stop generation at each python block, run it on the train pairs in the sandbox, feed the result back, resume; exit as soon as train passes. This targets the 22.7 % digit-reading, the code-free forced traces and the mental re-checks. Our earlier REPL-agent failures were at tiny budgets.
- **I3 A pre-computed fact sheet in the prompt:** objects per colour, bounding boxes, changed cells, size rule. We cite literature at +5–10 points.
- **I4 At a forced close, ask for a program instead of a grid** and verify it on train: 8 % (forced grid) vs 19 % (forced program).
- **I5 LOOPSTOP** (early stop of repetitive thinking). It is built and harness-tested. We expect a small gain: 4/172 direct loops.
- **I6 Make attempt_2 a real answer.** Options:
  - Poetiq iteration 1, plus a direct grid for tasks not train-verified (51.8 % computed on EVAL120);
  - the second distinct program;
  - an independent second sample.
  - Union ceiling 56.8 %.
- **I7 Poetiq rerun-path fixes:**
  - no grid when code fails or crashes on any test input;
  - attempt_2 = attempt_1;
  - a failed task re-queued at the back (refinement starves);
  - verifications still pending at the hard stop are dropped;
  - "first python block" is the one executed.
- **I8 Easy-first ordering.** Free; +1 LB, inside the noise.
- **I9 Temperature 0.6 vs 1.0.** 1.0 costs about 11 % MTP speed; the accuracy effect is unknown. DFlash2 was benchmarked at 1.0.
- **I10 KV saturation and prefix-cache eviction at 86k** with 16 sequences. Also an E8 OOM crash.
- **I11 Clock.** Deadlines are measured from cell 0, not container start; inputs admitted between 11:00 and 11:34 get only minutes.
- **I12 Grid representation** ((R×C) header, CSV) and prompts that stop cell-by-cell hand simulation.
- **I13 Union with an NVARC-style solver.** A public notebook with a different model scores 29–32 LB. Is a split of the 12 h or the GPUs worth it?

## 5. Research questions

- **R1** Who reached about LB 60 with Qwen3.8-27B in ARC Prize 2026? Look for any notebook, discussion, write-up or repository, and its method, budget and scheduling.
- **R2** Fastest serving of the Qwen3.5/3.8 hybrid (Gated DeltaNet) on L4 / sm_89:
  - SGLang vs vLLM;
  - speculative decoding (MTP / EAGLE-3 / DFlash);
  - INT4 Marlin vs FP8;
  - KV and mamba-state memory;
  - concurrency 24–48;
  - known bugs (thinking budget ignored with MTP, prefix cache + MTP correctness, DFlash acceptance collapse).
- **R3** Test-time methods for ARC-AGI-2 with reasoning LLMs, and their token efficiency:
  - program synthesis + verification (Poetiq, Greenblatt, Berman, Confluence Labs, Imbue, SOAR, Product-of-Experts, ARChitects, NVARC);
  - code execution in the reasoning loop;
  - fact-sheet / perception helpers.
- **R4** Adaptive compute under a fixed wall clock and many tasks:
  - early stopping of reasoning (budget forcing, confidence-based early exit, DEER / Dynasor-style probes, ThinkPrune);
  - difficulty prediction;
  - portfolio scheduling and when to abandon a task.
- **R5** Cheap ways to add a correct second attempt (pass@2).
- **R6** Ways to cut thinking length without losing accuracy on grid puzzles: representation, prompting, "think in code", tools.

## 6. Required output format

1. **Table A: idea validation (I1–I13).** Columns: ID | verdict | evidence (file + numbers) | expected LB effect | cost | risk | minimal test.
2. **Table B: new solutions found.** Columns: name | source URL | what it does | evidence of gain | fit to our constraints (4×L4, offline, 12 h, Qwen3.8-27B, ≥ 49k thinking) | implementation sketch on our stack | priority.
3. **Today's 2 × 12 h runs.** Which notebook or config each run should be, what it measures, and the decision rule afterwards. Candidates we see:
   - (a) Poetiq with the I7 fixes + I6 direct fallback on EVAL120;
   - (b) direct 86k with I4 (program at forced close);
   - (c) a prompt A/B for I3 / I12;
   - (d) the temperature A/B.
   - A 12 h run at today's speed covers EVAL120 (120 tasks) once. INT4 + DFlash2 is tested tomorrow in a separate notebook (`E11_03`).
4. **A 2.5-week plan:** weekly 4–5 runs plus about 1 submission per 2 days, ordered by expected LB gain per GPU-hour.
5. **Top risks and how to detect them early.**

## 7. File index

| Path | What |
|---|---|
| `01_analysis/Qwen3.8-27B LB and run deep analysis (2026-10-16).md` | **Start here.** The full cross-run analysis |
| `01_analysis/LB_notebooks_rerun_analysis.md` | Line-cited trace of what each submitted notebook does in the hidden rerun; diffs; bugs |
| `01_analysis/archive_qwen_digest.md` | Earlier phase (09-13 → 10-04) and public reference notebooks; tried vs never-tried ideas |
| `01_analysis/GPU EVAL120 ORDER2 86k analysis (2026-10-14).md` | Direct 86k on all 120 eval tasks: token bands, P(solve \| length) |
| `01_analysis/GPU EVAL120 Poetiq R5 analysis (2026-10-15).md` | Poetiq on all 120 eval tasks |
| `01_analysis/Poetiq R5 with ORDER2 - counterfactual replay (2026-10-15).md` | Poetiq + direct combinations |
| `01_analysis/Where tokens and time go - Poetiq R5 + web research (2026-10-15).md` | Token sinks + earlier web research |
| `01_analysis/Concurrency 16 to 25-30 - math and research (2026-10-15).md` | KV / concurrency math |
| `01_analysis/W4A16 checkpoints - MTP and vLLM 0.19 compatibility (2026-10-15).md` | INT4 options |
| `02_data/runs.csv`, `runs_tables.md` | 19 GPU runs × 55 metrics |
| `02_data/units.csv` | 655 requests: run, unit, mode (natural / forced), think and gen tokens, hit, admit / done times, train pass |
| `02_data/unit_outcomes.csv` | 561 unit × run outcomes |
| `02_data/timeline.csv` | About 2-minute intervals: active sequences, tok/s, KV usage |
| `02_data/lb_submissions_all.json` | All 90 team submissions with scores and notebook versions |
| `02_data/ledger/` | Per-puzzle capability ledger (all runs + the ARC Prize official Qwen3.8 xhigh results), oracle order, solved-by-tokens |
| `03_notebooks/` | E7 (best LB, 49k + ordering), E9 (86k), E10 ORDER2 86k (EVAL120), ORDER2 + LOOPSTOP (built, not run), Poetiq R5 (EVAL120 / LB 21.39), E11_03 (tomorrow's SGLang INT4 + DFlash2 GPU validation) |
| `04_readmes/` | Experiment 10 and Experiment 11 READMEs (Poetiq history; the SGLang / INT4 / DFlash2 plan, the Kaggle wheelhouse, verified flags) |
