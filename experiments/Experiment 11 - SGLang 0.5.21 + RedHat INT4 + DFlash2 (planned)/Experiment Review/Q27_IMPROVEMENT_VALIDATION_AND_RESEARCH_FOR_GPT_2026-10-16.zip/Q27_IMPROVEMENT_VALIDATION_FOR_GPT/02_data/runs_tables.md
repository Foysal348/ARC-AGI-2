| Run | Folder | Notebook version | Account | Date | Profile | Tasks | Units | Think + answer budget | Conc. (max active) |
|---|---|---|---|---|---|---|---|---|---|
| E1 run1 v1.3.2 | Q27X_run1 | v1.3.2 | foysalemonshanto (q27-xhigh ver 355535601) | 2026-10-05 | EVAL12 | 12 | 22 | 49,152 + 16,384 | 0 (–) |
| E1 run2 v1.3.4 | (no artifacts) | v1.3.4 | foysalemonshanto (q27-xhigh) | 2026-10-05 | EVAL12 | 12 | 22 | – | – (–) |
| E1 run3 v1.3.5 | Q27X_run3 | v1.3.5 (direct + code check, 1 request per task) | foysalemonshanto (q27-xhigh v5) | 2026-10-05 | EVAL12 | 12 | 22 | 49,152 + 16,384 | 16 (12) |
| E1 run4 v1.4 | Q27X_run4 | v1.4 (LB 18.75 code) | foysalemonshanto (q27-xhigh v6) | 2026-10-06 | EVAL12 | 12 | 22 | 49,152 + 8,192 | 16 (16) |
| E2 run5 R6 code loop | Q27X_run5_R6 | R6 code loop (v1.4 base; up to 4 turns, train-verify) | foysalemonshanto (q27-xhigh) | 2026-10-06 | EVAL12 | 12 | 22 | 49,152 + 8,192 | 16 (12) |
| E1 run6 v1.4.1 | Q27X_run6_v141 | v1.4.1 (prefix cache) | foysalemonshanto (q27-xhigh) | 2026-10-06 | EVAL12 | 12 | 22 | 49,152 + 8,192 | 16 (16) |
| E1 run7 v1.4.4 | Q27X_run7_v144 | v1.4.4 (LB 26.94 code) | foysalemonshanto (q27-xhigh) | 2026-10-10 | EVAL12 | 12 | 22 | 49,152 + 8,192 | 16 (16) |
| E4 Q27A run1 (esfer) | Q27A_run1_esfer | Q27-AGENT REPL v1.x (effort=high) | esfersami50 | 2026-10-07? | EVAL12 | 12 | 22 | 6,144 + 8,192 | 16 (–) |
| E4 run2 v1.7 (esfer) | run2_v1_7_esfer_crash_base_url | Q27-AGENT v1.7 | esfersami50 | 2026-10-1x | EVAL12 | 12 | 22 | – | – (–) |
| E4 run3 v1.8 (foysal) | run3_v1_8_foysal_readiness_bug | Q27-AGENT v1.8 | foysalemonshanto | 2026-10-1x | EVAL12 | 12 | 22 | – | – (–) |
| E4 run4 v1.8.3 (foysal) | run4_v1_8_3_foysal_EVAL12_complete | Q27-AGENT v1.8.3 REPL agent + DIRECT rescue (recorded run7) | foysalemonshanto | 2026-10-1x | EVAL12 | 12 | 22 | 6,144 + 10,240 | 16 (12) |
| E5 v1.9.1 (foysal v3) | GPU EVAL12 v1.9.1 (foysal v3) | Q27-AGENT v1.9.1 long-think program synthesis (49k think + 8k) | foysalemonshanto | 2026-10-12 | EVAL12 | 12 | 22 | 49,152 + 8,192 | 16 (12) |
| E6 dual v2 | GPU EVAL12 dual v2 | v1.4.4 DUAL_ANSWER v2 (2nd answer from prefix) | foysalemonshanto (q27-xhigh-dual v1) | 2026-10-12 | EVAL12 | 12 | 22 | 49,152 + 8,192 | 16 (16) |
| E7 ordering v2 (LB 27.92) | scratchpad lb_nbs/e7_out | v1.4.4 E7 ORDERING_ONLY v2 | foysalemonshanto (q27-xhigh-e7-ordering) | 2026-10-12 | PROXY48 | 48 | 56 | 49,152 + 8,192 | 16 (–) |
| E8 R5 PROXY48 | GPU PROXY48 E8 R5 | v1.4.4 E7 order + E8 per-unit augmentation scoring R5 | foysalemonshanto (q27-xhigh-e8 v1) | 2026-10-13 | PROXY48 | 48 | 56 | 49,152 + 8,192 | 16 (16) |
| E9 EVAL12 86k | GPU EVAL12 E9 | v1.4.4 E9 86k + tail resample | esfersami50 (q27-xhigh-e9 v1) | 2026-10-13 | EVAL12 | 12 | 22 | 77,824 + 8,192 | 16 (16) |
| E10 Poetiq R4 EVAL12 | GPU EVAL12 Poetiq R4 | v1.4.4 E10 86k Poetiq R4 (1 expert, <=10 it) | foysalemonshanto (q27-xhigh-e10-poetiq-r4 v1) | 2026-10-14 | EVAL12 | 12 | 22 | 77,824 + 8,192 | 16 (12) |
| E10 ORDER2 EVAL120 86k | GPU EVAL120 ORDER2 86k DIRECT | v1.4.4 E10 ORDER2 86k DIRECT | hosen42 (q27-xhigh-e10-order2) | 2026-10-14 | EVAL120 | 120 | 172 | 77,824 + 8,192 | 16 (16) |
| E10 Poetiq R5 EVAL120 | GPU EVAL120 Poetiq R5 | v1.4.4 E10 86k Poetiq R5 EVAL120 (1 expert, <=10 it) | hosen42 (q27-xhigh-e10-poetiq-r5-eval120) | 2026-10-14 | EVAL120 | 120 | 172 | 77,824 + 8,192 | 16 (16) |

| Run | Solved att_1 / pass@2 (units) | Score % | Task-norm % | Total wall min | Model-active min | Admitted / finished / never-admitted / lost | Natural / forced / continue | Gen tokens | Failures / notes |
|---|---|---|---|---|---|---|---|---|---|
| E1 run1 v1.3.2 | 0 / 0 | 0.0 | 0.0 | – | 0 | 0 / – / 12 / – | – / – / – | 0 | engine failed after 792 s (FlashInfer JIT link: cannot find -lcuda -> EngineDeadError); GPU memory not released -> ladder stopped |
| E1 run2 v1.3.4 | – / – | – | – | – | – | – / – / – / – | – / – / – | – | OOM in MTP drafter (fixed in v1.3.5 by max_num_batched_tokens 4096); per E1 README only |
| E1 run3 v1.3.5 | 1 / 1 | 4.55 | 4.17 | 56.4 | 42.1 | 12 / 22 / 0 / 0 | 0 / 12 / 0 | 625,530 | none (prefix cache off: ~30 s re-prefill stall per forced close) |
| E1 run4 v1.4 | 2 / 2 | 9.09 | 12.5 | 83.5 | 69.2 | 22 / 22 / 0 / 0 | 4 / 18 / 0 | 1,032,819 | none; prefix cache off |
| E2 run5 R6 code loop | 2 / 2 | 9.09 | 12.5 | 98.0 | 84.0 | 12 / 22 / 0 / 0 | 1 / 46 / 0 | 1,112,146 | none; 47 turns (35 repair turns) |
| E1 run6 v1.4.1 | 2 / 2 | 9.09 | 12.5 | 73.1 | 60.8 | 22 / 22 / 0 / 0 | 5 / 17 / 0 | 1,041,351 | none |
| E1 run7 v1.4.4 | 3 / 3 | 13.64 | 16.67 | 77.9 | 64.3 | 22 / 22 / 0 / 0 | 3 / 19 / 0 | 1,059,550 | none |
| E4 Q27A run1 (esfer) | 0 / 0 | 0.0 | 0.0 | 12.5 | 0.0 | 24 / 22 / 0 / 0 | – / – / – | 0 | all 24 attempts HTTP 400: reasoning_effort 'high' unsupported -> 0 tokens |
| E4 run2 v1.7 (esfer) | 0 / 0 | 0 | – | 13.5 | – | – / – / – / – | – / – / – | 0 | crash before any request: KeyError 'base_url' in smoke(); identity submission |
| E4 run3 v1.8 (foysal) | 0 / 0 | 0 | – | – | – | – / – / – / – | – / – / – | 0 | server readiness bug: vLLM server never reported up (start_s 1505, failure UNKNOWN); 0 requests |
| E4 run4 v1.8.3 (foysal) | 0 / 0 | 0.0 | 0.0 | 56.3 | 43.2 | 24 / 22 / 0 / 0 | – / – / – | 664,419 | agent 0/22; 5 attempts HTTP 500, 18 token-budget stops; hybrid score = recorded run7 DIRECT |
| E5 v1.9.1 (foysal v3) | 1 / 1 | 4.55 | 8.33 | 55.1 | 42.3 | 12 / 22 / 0 / 0 | 0 / 12 / – | 712,767 | agent 1/22 (136b0064); 12/12 programs reached the 49k think budget; reported 3/22 = recorded run7 DIRECT |
| E6 dual v2 | 1 / 1 | 4.55 | 8.33 | 86.9 | 60.1 | 22 / 22 / 0 / 0 | 4 / 18 / 0 | 1,041,027 | none; 2nd-answer branch 22 req / 24,975 tok / 880 s, 0 marginal hits |
| E7 ordering v2 (LB 27.92) | – / – | – | – | – | – | – / – / – / – | – / – / – | – | kernel log ends at 44 s (pip install); no records/metrics in the download -> no commit-run metrics; LB 27.92 |
| E8 R5 PROXY48 | 10 / 10 | 17.86 | 19.79 | 124.5 | 110.7 | 56 / 41 / 0 / 15 | 15 / 26 / 0 | 2,348,385 | CUDA OOM (790 MiB alloc, all 4 GPUs) -> EngineDeadError at ~124 sched-min; 15/56 units lost; scorer never finished a view |
| E9 EVAL12 86k | 4 / 4 | 18.18 | 19.44 | 148.0 | 136.0 | 22 / 22 / 0 / 0 | 9 / 13 / 0 | 2,501,071 | none; 14 tail resamples (12 changed attempt_2), 0 gain |
| E10 Poetiq R4 EVAL12 | 4 / 4 | 18.18 | 20.83 | 149.7 | 137.5 | 27 requests (12 it1 + 8 it2 + 7 it3); all 12 tasks got it1; 6 tasks still queued for a further iteration at stop / 22 / 0 / 0 | 3 / 24 / 0 | 1,845,550 | none |
| E10 ORDER2 EVAL120 86k | 58 / 58 | 33.72 | 36.94 | 534.4 | 522.4 | 172 / 172 / 0 / 0 | 97 / 74 / 1 | 10,447,055 | none |
| E10 Poetiq R5 EVAL120 | 77 / 78 | 45.35 | 48.61 | 703.7 | 691.1 | 172 requests (120 it1 + 52 it2); all 120 tasks got it1; 49 tasks still queued for a further iteration at stop / 172 / 0 / 0 | 64 / 104 / 4 | 11,648,771 | none (time-bound: 49 tasks still queued for it2/it3 at stop) |

| Run | Think mean / median (all) | Solved mean / median | Unsolved mean / median | Agg tok/s (run) | Median tok/s @16 | Peak 2-min tok/s | Per-request tok/s (median) | Slot util % | KV peak / p50 | Preempt. | MTP acc (tok/step; per-pos) | Prefix hit (vLLM) / cached-prompt frac |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| E1 run1 v1.3.2 | – / – | – / – | – / – | – | – | – | – | – | – / – | – | – (–; –) | – / – |
| E1 run2 v1.3.4 | – / – | – / – | – / – | – | – | – | – | – | – / – | – | – (–; –) | – / – |
| E1 run3 v1.3.5 | 49,175 / 49,175 | 49,175 / 49,175 | 49,175 / 49,175 | 247.8 | – | 350 | 21.5 | 69.8 | 0.58 / 0.45 | 0 | 0.588 (2.763; 0.75/0.57/0.44) | – / 0.0 |
| E1 run4 v1.4 | 46,255 / 49,175 | 30,740 / 30,740 | 47,806 / 49,175 | 248.9 | 367 | 441 | 22.16 | 72.0 | 0.72 / 0.40 | 0 | 0.657 (2.971; 0.81/0.64/0.51) | – / 0.0 |
| E2 run5 R6 code loop | 22,247 / 12,311 | 49,175 / 49,175 | 21,051 / 12,311 | 220.7 | – | 378 | 23.11 | 59.6 | 0.58 / 0.27 | 0 | 0.678 (3.034; 0.82/0.67/0.54) | – / 0.0 |
| E1 run6 v1.4.1 | 46,645 / 49,175 | 31,862 / 31,862 | 48,123 / 49,175 | 285.3 | 363 | 444 | 22.96 | 73.2 | 0.73 / 0.40 | 0 | 0.655 (2.966; 0.81/0.64/0.51) | 0.786 / 0.822 |
| E1 run7 v1.4.4 | 47,432 / 49,175 | 37,293 / 36,770 | 49,033 / 49,175 | 274.6 | 361 | 432 | 23.15 | 73.3 | 0.79 / 0.41 | 0 | 0.661 (2.984; 0.82/0.65/0.52) | 0.572 / 0.608 |
| E4 Q27A run1 (esfer) | – / – | – / – | – / – | 0.0 | – | – | – | – | – / – | – | – (–; –) | – / – |
| E4 run2 v1.7 (esfer) | – / – | – / – | – / – | – | – | – | – | – | – / – | – | – (–; –) | – / – |
| E4 run3 v1.8 (foysal) | – / – | – / – | – / – | – | – | – | – | – | – / – | – | – (–; –) | – / – |
| E4 run4 v1.8.3 (foysal) | – / – | – / – | – / – | 256.5 | – | – | – | – | 0.31 / – | 0 | 0.736 (–; –) | – / – |
| E5 v1.9.1 (foysal v3) | 56,638 / 57,344 | 49,982 / 49,982 | 57,243 / 57,344 | 280.9 | – | – | – | – | 0.68 / – | 0 | 0.634 (–; –) | – / – |
| E6 dual v2 | 46,213 / 49,175 | 25,113 / 25,113 | 47,218 / 49,175 | 288.5 | 374 | 431 | 22.97 | 72.8 | 0.71 / 0.40 | 0 | 0.664 (2.991; 0.82/0.65/0.52) | 0.844 / 0.877 |
| E7 ordering v2 (LB 27.92) | – / – | – / – | – / – | – | – | – | – | – | – / – | – | – (–; –) | – / – |
| E8 R5 PROXY48 | 45,389 / 49,175 | 37,402 / 40,648 | 47,965 / 49,175 | 353.5 | 357 | 418 | 22.15 | 100.0 | 0.73 / 0.58 | 0 | 0.663 (2.99; 0.82/0.65/0.52) | 0.721 / 0.718 |
| E9 EVAL12 86k | 65,981 / 77,847 | 42,602 / 39,978 | 71,177 / 77,847 | 306.6 | 349 | 429 | 21.48 | 87.6 | 0.90 / 0.68 | 0 | 0.655 (2.965; 0.81/0.64/0.51) | 0.814 / 0.837 |
| E10 Poetiq R4 EVAL12 | 65,584 / 77,847 | 57,235 / 64,483 | 66,627 / 77,847 | 223.7 | – | 338 | 25.3 | 57.2 | 0.79 / 0.44 | 0 | 0.560 (2.68; 0.74/0.54/0.40) | 0.79 / 0.844 |
| E10 ORDER2 EVAL120 86k | 59,863 / 68,410 | 43,514 / 41,212 | 68,182 / 77,847 | 333.3 | 348 | 415 | 21.71 | 95.6 | 0.87 / 0.69 | 0 | 0.669 (3.007; 0.82/0.66/0.53) | 0.834 / 0.839 |
| E10 Poetiq R5 EVAL120 | 65,348 / 77,847 | 60,797 / 60,164 | 67,978 / 77,847 | 280.9 | 295 | 378 | 17.85 | 99.9 | 0.99 / 0.77 | 9 | 0.557 (2.671; 0.73/0.54/0.40) | 0.132 / 0.583 |
