# E11-04 audit request: SGLang 0.5.21 + Qwen3.8-27B INT4 + DFlash2 capacity / real-concurrency validation (4× L4)

**What we ask:**
- Audit this notebook before it runs once on Kaggle; about 3 h of GPU, and we can rarely repeat a run.
- Find **bugs, wrong flags, wrong log parsing, wrong measurements, or missing tests** that would make the run waste GPU or give misleading conclusions.
- Do as many web or source searches as you need (SGLang 0.5.21 source, issues, docs).
- Quote file and line for every claim, and label each one **verified** (file or source) or **hypothesis**.
- We verify everything before acting.

## 1. Background (verified in the previous run, E11-03 run 1)

E11-03 run-1 files: `context/E11-03 run1 analysis (2026-10-17).md`. Its §6 is our validation of your earlier two reviews against the SGLang 0.5.21 source.

**Concurrency cap:**
- SGLang capped `max_running_requests` through the mamba (SSM) state cache: 5 slots per request with extra_buffer + overlap (`kv_cache_configurator.py:2232-2330`).
- Config C (DFlash2, fp32 SSM) ran **6** concurrent; D (fp16 SSM) ran 13; B ran 10. `/get_server_info` still said 32.

**D memory per GPU:**

| item | GB |
|---|---|
| target weights | 4.62 |
| drafter weights | 1.49 |
| mamba | 3.26 |
| target KV | 2.94 |
| draft KV | 0.92 |
| prefill graph | 2.60 |
| verify graphs | 0.88 |
| free | 4.39 |

- Auto `mem_fraction_static` was 0.6187. KV was 386,563 tokens; production needs about 920k (12 × 60k).
- D's speed at a real 12 was 404 tok/s, against vLLM FP8 + MTP-3 at about 307 short and 255–300 long context.

## 2. What E11-04 does

Notebook `notebook/E11_04_sglang_capacity_validation_on_KAGGLE.ipynb` (sha256 080d1b9e…), built by `notebook/build_e11_04_capacity_validation.py`.

The builder **exec's** `notebook/build_e11_03_gpu_validation.py` to reuse its cell texts verbatim (install, preflight, tokenizer, server helpers). It then patches them with exact-match `once()` replacements and adds new cells.

**Arms.** All: TP4, INT4 target, DFlash2 drafter (8 draft tokens, `unquant`), `--max-running-requests 12`, `--cuda-graph-max-bs-decode 12`, `--disable-prefill-cuda-graph`, `--mem-fraction-static` 0.83 (a ladder retry at 0.78 if the launch fails).

| arm | mamba strategy | mamba cache | slots per request | SSM dtype | extra |
|---|---|---|---|---|---|
| W1 | `extra_buffer_lazy` | 56 | 4 | float16 | — |
| W2 | `no_buffer` | 48 | 3 | float32 | `--enable-linear-replayssm-spec` |
| W3 | `extra_buffer_lazy` | 56 | 4 | bfloat16 | — |

- W2 uses no_buffer because `attention_hook.py:315-320` says the ReplaySSM ring is not reset on the extra_buffer donation path. That check is for the decode variant; we chose no_buffer for the spec variant out of caution.

**Stages per arm** (cells 4–7):
1. **Startup caps parsed from the server log** (`server_caps`): capped_to, slots per request, KV tokens (TP0 lines; target, then draft), mamba cache size, verify and decode graph bs, prefill graph present, last avail mem, FP8 scale warning.
2. **Capacity gate:** effective running ≥ 12, KV ≥ 900k, verify graph contains bs 12.
3. **Greedy outputs:** 4 prompts × 512 tokens, compared across arms.
4. **Sweep** at 1, 4, 8, 12 concurrent × 4,096 tokens (E10 DIRECT prompts, xhigh, T 0.6). Each level carries a **real-concurrency check**: the decode log must show the requested `#running-req` at least twice.
5. **Sanity solve:** 8 easy puzzles, E10 DIRECT protocol (W1 always, W2 if time allows).
6. **PROD closed loop** (`x_prod`):
   - 12 requests always in flight, refilled on finish, 48 distinct ARC prompts.
   - Up to 60,000 new tokens, stop at `</think>`, T 1.0.
   - Window W1 35 min, W2 25 min, W3 15 min; 10 min if the gate failed.
   - **Throughput = delta of `sglang:generation_tokens_total` / window.**
   - Then `/abort_request {"abort_all": true}`, with at most 10 more minutes of waiting.
   - It records the share of decode lines at 12 running (PASS needs ≥ 0.5), the max `#full token`, the max context, and the count of "retract" log lines.
7. **Marker contamination** (W1):
   - 4 greedy prompts run solo twice (repeatability), then inside a batch with 8 companions.
   - The companions use the same tasks with an instruction to write their own codename (`ZQX-701…708`).
   - A codename in a greedy output, or a companion writing another companion's codename, is contamination.
8. **contcache** (W1, W2): a forced-close continuation must hit the prefix cache, with warm ≥ 1.5× faster than cold.
9. **Report** with a GO / NO-GO table per arm.
10. **Checkpoint probe:** counts `k_scale` / `v_scale` tensors in the INT4 `model.safetensors.index.json` and records `kv_cache_scheme`.

**Local CPU harness:** `harness/run_harness_04.py` + `harness/fake_sglang_server_04.py`.
- The fake models the cap math, queueing beyond the cap, KV sizing, verify graph bs, the FP8 warning, abort, the generation counter, periodic Decode lines, prefix cache and marker companions.
- Scenarios: main, capfail (W3 capped at 8), replayfail (W2 never launches), contam (a leak). **All four PASS** (logs in `harness/logs/`).
- The fake is not the real engine: its timings and caps are synthetic.

## 3. Questions

1. **Flags (SGLang 0.5.21):**
   - Will `--mamba-radix-cache-strategy extra_buffer_lazy` + `--max-mamba-cache-size 56` + `--max-running-requests 12` give 12 real running with DFLASH?
   - Is `extra_buffer_lazy` compatible with DFLASH speculative decoding and the overlap scheduler?
   - Do `--disable-prefill-cuda-graph` and `--cuda-graph-max-bs-decode 12` capture a verify graph at bs 12?
   - Is anything else needed: `--max-total-tokens`, `--mamba-full-memory-ratio`, `--speculative-num-steps`?
2. **ReplaySSM spec with `no_buffer`, DFLASH and GDN (Qwen3.5/3.8 hybrid):**
   - Is the combination supported and correct in 0.5.21?
   - Do `SGLANG_RAGGED_VERIFY_MODE` or `--linear-attn-verify-backend` need setting?
   - Does no_buffer break prefix-cache hits for our continuation pattern?
3. **Memory:** with `--mem-fraction-static 0.83` and no prefill graph, is ≥ 900k KV plausible per arm? Is 0.83 at risk of OOM during prefill (chunked 4096) or decode at 12 × 60k?
4. **Measurement validity:**
   - Is `sglang:generation_tokens_total` the right counter for speculative decoding (does it count accepted tokens)?
   - Is the share-at-12 criterion sound?
   - Does `abort_all` work as used?
   - Does the decode-log regex (`_KV_RE` on "Decode batch" lines) parse 0.5.21's lines (see the E11-03 logs in context)?
5. **Contamination test:** is the marker design sound? What would you add, within a few minutes of GPU?
6. **Anything that wastes GPU time:** stage order, timeouts, the ladder, or the guard values.
7. **Missing tests** that would change the production decision. For example: answer-phase continuation, natural-close parsing via `</think>`, or long-context prefill speed.

## 4. File map

| path | what |
|---|---|
| `notebook/E11_04_sglang_capacity_validation_on_KAGGLE.ipynb` | the notebook to audit |
| `notebook/build_e11_04_capacity_validation.py` | its builder (patches on top of E11-03) |
| `notebook/build_e11_03_gpu_validation.py` | E11-03 builder (its cell texts are reused) |
| `harness/run_harness_04.py`, `harness/fake_sglang_server_04.py` | local CPU harness |
| `harness/logs/log_{main,capfail,replayfail,contam}.txt`, `harness/report_main.md` | harness runs (all PASS) and a sample report |
| `context/E11-03 run1 analysis (2026-10-17).md` | run-1 analysis plus our validation of your previous reviews (§6) |
| `context/E11-03_report.md`, `context/server_D_C_int4_dflash2_ssm_fp16_try0.log`, `context/server_C_int4_dflash2_try0.log` | real E11-03 SGLang logs (log format, caps, memory) |
| `context/Experiment 11 README.md` | E11 history |
