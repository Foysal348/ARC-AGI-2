# E11-04 capacity + real-concurrency validation · run 20261017T160522Z

Driver None (CUDA None) · preflight PASS · checkpoint k/v scale tensors 2 · kv_cache_scheme {"actorder": null, "block_structure": null, "dynamic": false, "group_size": null, "num_bits": 8, "observer": "static_minmax", "observer_kwargs": {}, "scale_dtyp

## Startup caps (from the server log)

| arm | launch | effective running | capped_to | state slots/req | KV tokens | KV GB target+draft | mamba cache | verify graph bs | prefill graph | free GB | FP8 scale warning | gate |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| W1_lazy_fp16 | [('0.83', 'ready in 2s')] | 12 | None | None | 960000 | 7.3+2.28 | 56 | [1, 2, 3, 4, 5, 6, 7, 8, 10, 12] | False | 1.6 | True | PASS |
| W2_replay_fp32 | [('0.83', 'ready in 2s')] | 12 | None | None | 960000 | 7.3+2.28 | 48 | [1, 2, 3, 4, 5, 6, 7, 8, 10, 12] | False | 1.6 | True | PASS |
| W3_lazy_bf16 | [('0.83', 'ready in 2s')] | 12 | None | None | 960000 | 7.3+2.28 | 56 | [1, 2, 3, 4, 5, 6, 7, 8, 10, 12] | False | 1.6 | True | PASS |

## Sweep (short prompts, 4,096 tokens) with real concurrency

| arm | requests | total tok/s | log gen tok/s | accept | real running max | real 12? |
|---|---|---|---|---|---|---|
| W1_lazy_fp16 | 1 | 1262.9 | 35.0 | 4.60 | 1 | PASS |
| W1_lazy_fp16 | 4 | 4582.3 | 140.0 | 4.60 | 4 | PASS |
| W1_lazy_fp16 | 8 | 5869.9 | 280.0 | 4.60 | 8 | PASS |
| W1_lazy_fp16 | 12 | 9617.0 | 420.0 | 4.60 | 12 | PASS |
| W2_replay_fp32 | 1 | 1261.9 | 35.0 | 4.60 | 1 | PASS |
| W2_replay_fp32 | 4 | 5032.1 | 140.0 | 4.60 | 4 | PASS |
| W2_replay_fp32 | 8 | 6291.4 | 280.0 | 4.60 | 8 | PASS |
| W2_replay_fp32 | 12 | 9633.2 | 420.0 | 4.60 | 12 | PASS |
| W3_lazy_bf16 | 1 | 1254.4 | 35.0 | 4.60 | 1 | PASS |
| W3_lazy_bf16 | 4 | 5035.8 | 140.0 | 4.60 | 4 | PASS |
| W3_lazy_bf16 | 8 | 6289.7 | 280.0 | 4.60 | 8 | PASS |
| W3_lazy_bf16 | 12 | 9608.8 | 420.0 | 4.60 | 12 | PASS |

## PROD closed loop (12 in flight, ARC prompts, up to 60000 thinking, T 1.0) · target >= 332 tok/s

| arm | window s | gen tokens | **tok/s** | share of log lines at 12 | accept | KV in use max | context max | retract lines | finished (natural) | meets target |
|---|---|---|---|---|---|---|---|---|---|---|
| W1_lazy_fp16 | 61.0 | 32595.0 | **534.3** | 0.78 | 4.60 | 60000.0 | 9655 | 0 | 169 (169) | True |
| W2_replay_fp32 | 60.1 | 31030.0 | **516.3** | 0.803 | 4.60 | 60000.0 | 9533 | 0 | 168 (168) | True |
| W3_lazy_bf16 | 60.3 | 31026.0 | **514.5** | 0.777 | 4.60 | 60000.0 | 9643 | 0 | 170 (170) | True |

## Correctness

- **W1_lazy_fp16 marker contamination:** contamination False · greedy leaks [] · companion cross [] · companions wrote own code 8/8 · solo repeat identical 4/4 (mean prefix 512.0) · solo vs batch identical 4/4 (mean prefix 512.0)
- **W1_lazy_fp16 contcache:** pass True · min cached ratio 0.997 · warm vs cold 5.27x
- **W2_replay_fp32 contcache:** pass True · min cached ratio 0.997 · warm vs cold 5.95x
- **W2_replay_fp32 greedy vs W1:** 0/4 identical, mean prefix 200.0
- **W3_lazy_bf16 greedy vs W1:** 0/4 identical, mean prefix 200.0

### Sanity W1_lazy_fp16: 4/8 solved · FP8 expectation 6.74

| puzzle | hit | mode | think tokens | FP8 think | accept | sec |
|---|---|---|---|---|---|---|
| 2ba387bc#0 | 1 | natural | 187 | 5355 | 4.60 | 11.0 |
| bf45cf4b#0 | 0 | natural | 112 | 17485 | 4.60 | 9.6 |
| 58f5dbd5#0 | 1 | natural | 150 | 22674 | 4.60 | 9.6 |
| 136b0064#0 | 0 | natural | 194 | 23164 | 4.60 | 9.6 |
| 31f7f899#0 | 1 | natural | 155 | 25425 | 4.60 | 9.6 |
| 1818057f#0 | 0 | natural | 255 | 26891 | 4.60 | 9.6 |
| e8686506#0 | 1 | natural | 73 | 27730 | 4.60 | 9.6 |
| 7491f3cf#0 | 0 | natural | 151 | 31874 | 4.60 | 9.6 |

### Sanity W2_replay_fp32: 4/8 solved · FP8 expectation 6.74

| puzzle | hit | mode | think tokens | FP8 think | accept | sec |
|---|---|---|---|---|---|---|
| 2ba387bc#0 | 1 | natural | 139 | 5355 | 4.60 | 8.3 |
| bf45cf4b#0 | 0 | natural | 83 | 17485 | 4.60 | 7.3 |
| 58f5dbd5#0 | 1 | natural | 117 | 22674 | 4.60 | 7.9 |
| 136b0064#0 | 0 | natural | 283 | 23164 | 4.60 | 8.0 |
| 31f7f899#0 | 1 | natural | 153 | 25425 | 4.60 | 7.6 |
| 1818057f#0 | 0 | natural | 168 | 26891 | 4.60 | 7.8 |
| e8686506#0 | 1 | natural | 218 | 27730 | 4.60 | 7.5 |
| 7491f3cf#0 | 0 | natural | 67 | 31874 | 4.60 | 7.5 |

## GO / NO-GO (production candidate = all PASS)

| arm | capacity gate | real 12 in PROD | PROD >= target | no retraction | no contamination | sanity >= 6/8 | contcache |
|---|---|---|---|---|---|---|---|
| W1_lazy_fp16 | PASS | PASS | PASS | PASS | PASS | **FAIL** | PASS |
| W2_replay_fp32 | PASS | PASS | PASS | PASS | PASS | **FAIL** | PASS |
| W3_lazy_bf16 | PASS | PASS | PASS | PASS | PASS | - | - |

Total time 6 min · best arm: W1_lazy_fp16 · notes: []