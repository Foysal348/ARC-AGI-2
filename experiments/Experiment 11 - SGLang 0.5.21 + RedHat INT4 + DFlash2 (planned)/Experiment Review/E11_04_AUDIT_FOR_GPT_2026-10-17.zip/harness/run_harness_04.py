"""E11-04 CPU harness: fake /kaggle/input, every notebook cell in one namespace against fake_sglang_server_04.py
(which models SGLang's mamba-cache concurrency cap, KV sizing, abort and the generation counter), then checks.
usage: python run_harness_04.py [scenario]
scenarios: main | capfail (W3 bf16 capped below 12) | replayfail (W2 never launches) | contam (greedy output leaks a code)"""
import hashlib, json, os, shutil, sys, time
from pathlib import Path

HERE = Path(__file__).resolve().parent
H3 = HERE.parent / "e11_03_harness"
NB = Path(r"D:/ARC AGI 2/experiments/Experiment 11 - SGLang 0.5.21 + RedHat INT4 + DFlash2 (planned)/Experiment Notebooks/"
          r"E11_04_sglang_capacity_validation_on_KAGGLE.ipynb")
DATA = Path(r"D:/ARC AGI 2/experiments/Experiment 10 - Q27-XHIGH Poetiq Code-Verify attempt_2 (planned)/Experiment Review/"
            r"E10_ORDER2_EVAL120_RESULTS_FOR_GPT/data")
scenario = sys.argv[1] if len(sys.argv) > 1 else "main"
RUN = HERE / f"run_{scenario}"
if RUN.exists():
    shutil.rmtree(RUN)
INP, OUT = RUN / "input", RUN / "out"

wh = INP / "datasets" / "foysalemonshanto" / "sglang-0-5-21-cu13-wheelhouse"
wh.mkdir(parents=True)
(wh / "BUILD_INFO.json").write_text(json.dumps({"sglang": "0.5.21"}))
(wh / "requirements.lock").write_text("sglang==0.5.21\nflashinfer-jit-cache==0.6.18+cu130\n")
_wheels = {"sglang-0.5.21-py3-none-any.whl": b"sglang",
           "flashinfer_jit_cache-0.6.18+cu130-cp39-abi3-manylinux_2_28_x86_64.whl": b"jit"}
_lines = []
for _n, _c in _wheels.items():
    (wh / _n.replace("+", "")).write_bytes(_c)
    _lines.append(f"{hashlib.sha256(_c).hexdigest()}  {_n}")
(wh / "SHA256SUMS").write_text("\n".join(_lines) + "\n")
m4 = INP / "models" / "foysalemonshanto" / "qwen3-8-27b-int4-redhat" / "pytorch" / "w4a16-g128" / "1"
m4.mkdir(parents=True)
for f in (H3 / "tok").iterdir():
    shutil.copy(f, m4 / f.name)
(m4 / "model_mtp.safetensors").write_bytes(b"")
(m4 / "model.safetensors.index.json").write_text(json.dumps({"weight_map": {"model.layers.3.self_attn.k_scale": "a",
                                                                            "model.layers.3.self_attn.v_scale": "a",
                                                                            "model.layers.3.mlp.weight": "a"}}))
df = INP / "models" / "foysalemonshanto" / "qwen3-8-27b-dflash2" / "pytorch" / "bf16" / "1"
df.mkdir(parents=True)
shutil.copy(HERE.parent / "sgl_src" / "dflash2_config.json", df / "config.json")
comp = INP / "competitions" / "arc-prize-2026-arc-agi-2"
comp.mkdir(parents=True)
for f in ("arc-agi_evaluation_challenges.json", "arc-agi_evaluation_solutions.json"):
    shutil.copy(DATA / f, comp / f)
(comp / "arc-agi_test_challenges.json").write_text("{}")

os.environ.update({"E11_HARNESS": "1", "E11_INPUT": str(INP), "E11_OUT": str(OUT), "E11_TIME_BUDGET": "36000",
                   "E11_FAKE_SERVER": str(HERE / "fake_sglang_server_04.py"), "E11_PROD_SEC": "60",
                   "E11_TOKENIZER_PYTHON": str(H3 / "hvenv" / "Scripts" / "python.exe")})
for k in ("FAKE_CAP_FAIL", "FAKE_FAIL_ALWAYS", "FAKE_CONTAM"):
    os.environ.pop(k, None)
if scenario == "capfail":
    os.environ["FAKE_CAP_FAIL"] = "bfloat16"
if scenario == "replayfail":
    os.environ["FAKE_FAIL_ALWAYS"] = "replay"
if scenario == "contam":
    os.environ["FAKE_CONTAM"] = "1"

nb = json.load(open(NB, encoding="utf-8"))
g = {"__name__": "__main__"}
t0 = time.time()
for i, c in enumerate(nb["cells"]):
    if c["cell_type"] != "code":
        continue
    print(f"\n======== executing notebook cell {i}", flush=True)
    exec(compile("".join(c["source"]), f"<cell {i}>", "exec"), g)
print(f"\nnotebook finished in {time.time() - t0:.0f}s")

R = json.load(open(OUT / "results.json", encoding="utf-8"))
C = R["configs"]
fails = []


def check(cond, msg):
    print(("PASS " if cond else "FAIL ") + msg)
    if not cond:
        fails.append(msg)


rep = (OUT / "report.md").read_text(encoding="utf-8")
check(R.get("kv_scale_tensors_in_checkpoint") == 2, f"checkpoint k/v scale tensors counted: {R.get('kv_scale_tensors_in_checkpoint')}")
check(R.get("kv_cache_scheme") is not None, "kv_cache_scheme read from the INT4 config")
check(set(C) == {"W1_lazy_fp16", "W2_replay_fp32", "W3_lazy_bf16"}, f"three arms ran: {sorted(C)}")
w1 = C["W1_lazy_fp16"]
check(w1.get("ok"), "W1 ok")
cmd = w1["attempts"][-1]["cmd"]
for f in ("--mamba-radix-cache-strategy extra_buffer_lazy", "--max-mamba-cache-size 56", "--disable-prefill-cuda-graph",
          "--mamba-ssm-dtype float16", "--max-running-requests 12", "--mem-fraction-static 0.83", "--speculative-algorithm DFLASH",
          "--speculative-draft-model-quantization unquant", "--cuda-graph-max-bs-decode 12"):
    check(f in cmd, f"W1 command has {f}")
check(cmd.count("--mem-fraction-static") == 1, "mem fraction set once")
c1 = w1.get("caps") or {}
check(c1.get("effective_running") == 12 and c1.get("capped_to") is None, f"W1 caps: effective 12, not capped ({c1.get('capped_to')})")
check(c1.get("kv_tokens") == 960000 and c1.get("kv_gb_draft"), f"W1 KV tokens {c1.get('kv_tokens')} target {c1.get('kv_gb_target')} draft {c1.get('kv_gb_draft')}")
check(12 in (c1.get("verify_graph_bs") or []) and c1.get("prefill_graph_captured") is False, "W1 verify graph has bs 12, no prefill graph")
check(c1.get("fp8_kv_scale_warning") is True, "FP8 KV scale warning detected")
check((w1.get("gate") or {}).get("pass"), "W1 capacity gate PASS")
check(all(st["real_concurrency"]["pass"] for st in w1["sweep"].values()), "W1 sweep: real concurrency PASS at every level")
p1 = w1.get("prod") or {}
check(p1.get("tok_s") and p1.get("gen_tokens") and p1["real_concurrency"]["pass"], f"W1 PROD: {p1.get('tok_s')} tok/s, real 12 {p1.get('real_concurrency')}")
check(55 <= p1.get("window_s", 0) <= 100, f"W1 PROD window {p1.get('window_s')} s (60 requested)")
check(p1.get("requests_started", 0) > 12 and p1.get("natural_close_in_window", 0) > 0, f"W1 PROD refilled: {p1.get('requests_started')} started")
_post = [r for r in p1.get("requests", []) if not r.get("in_window")]
check(len(_post) <= 12 and p1.get("requests_started", 0) == len(p1.get("requests", [])),
      f"W1 PROD: no new request after the window ({len(_post)} finished after it), every started request accounted for")
m1 = w1.get("mark") or {}
want_contam = scenario == "contam"
check(m1.get("contamination") is want_contam, f"W1 marker test contamination = {m1.get('contamination')} (expected {want_contam})")
check(m1.get("companions_wrote_own_code") == 8, f"companions wrote their own code {m1.get('companions_wrote_own_code')}/8")
check(m1["solo_repeat"]["identical"] == 4, "solo greedy repeatable (fake is deterministic)")
check((w1.get("contcache") or {}).get("pass"), f"W1 contcache {w1.get('contcache', {}).get('cache_ratio_min')}")
s1 = (R.get("sanity_by_arm") or {}).get("W1_lazy_fp16") or {}
check(s1.get("n") == 8 and s1.get("hits") == 4, f"W1 sanity {s1.get('hits')}/{s1.get('n')}")
w2 = C["W2_replay_fp32"]
if scenario == "replayfail":
    check(not w2.get("ok") and len(w2.get("attempts", [])) == 2, "replayfail: W2 fails both ladder rungs, run continues")
    check(w2["attempts"][1]["cmd"].count("--mem-fraction-static 0.78") == 1, "ladder rung 2 = mem 0.78")
else:
    check(w2.get("ok") and "--enable-linear-replayssm-spec" in w2["attempts"][-1]["cmd"]
          and "--mamba-radix-cache-strategy no_buffer" in w2["attempts"][-1]["cmd"], "W2 runs ReplaySSM with no_buffer")
    check((w2.get("caps") or {}).get("effective_running") == 12, f"W2 effective running {(w2.get('caps') or {}).get('effective_running')}")
    check((w2.get("greedy_vs_W1") or {}).get("mean_prefix") == 200.0, "W2 greedy vs W1 measured (fake drift at 200)")
    check((w2.get("contcache") or {}).get("pass"), "W2 contcache (no_buffer) measured")
w3 = C["W3_lazy_bf16"]
check("--mamba-ssm-dtype bfloat16" in w3["attempts"][-1]["cmd"], "W3 is bfloat16")
if scenario == "capfail":
    c3 = w3.get("caps") or {}
    check(c3.get("capped_to") == 8 and not (w3.get("gate") or {}).get("pass"), f"capfail: W3 capped to {c3.get('capped_to')}, gate FAIL")
    check(not w3["sweep"]["12"]["real_concurrency"]["pass"], "capfail: W3 sweep at 12 = real concurrency FAIL")
    check((w3.get("prod") or {}).get("window_s", 99) <= 45, f"capfail: W3 PROD shortened ({(w3.get('prod') or {}).get('window_s')} s)")
    check(R.get("best_spec") != "W3_lazy_bf16", "capfail: W3 cannot be the best arm")
else:
    check((w3.get("gate") or {}).get("pass"), "W3 gate PASS")
check(R.get("best_spec") in C and (C[R["best_spec"]].get("gate") or {}).get("pass"), f"best arm {R.get('best_spec')} passed its gate")
for sec in ("## Startup caps", "## Sweep", "## PROD closed loop", "## Correctness", "## GO / NO-GO"):
    check(sec in rep, f"report has {sec}")
if want_contam:
    check("| W1_lazy_fp16 | PASS | PASS | " in rep and "**FAIL**" in rep.split("## GO / NO-GO")[1], "contam: GO table shows the contamination FAIL")
print(f"\n{len(fails)} failed checks" if fails else "\nALL CHECKS PASS")
sys.exit(1 if fails else 0)
