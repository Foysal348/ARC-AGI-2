"""Fake `python -m sglang.launch_server` for the E11-04 CPU harness (stdlib only). Unlike the E11-03 fake it models the
caps that E11-03 run 1 hit on Kaggle:
- mamba state cache: K = --max-mamba-cache-size (else 33 fp32 / 68 fp16-bf16), slots per request 5 (extra_buffer),
  4 (extra_buffer_lazy), 3 (no_buffer); effective running = min(--max-running-requests, K // slots); the SGLang warning
  line is printed when capped and requests beyond the cap QUEUE (a semaphore), so Decode lines show the real running count
- KV tokens: 960k with --mem-fraction-static >= 0.80 and --disable-prefill-cuda-graph, else 387k; target + draft lines
  on every TP rank; verify CUDA graph bs list up to the cap; FP8 scale warning
- /abort_request (abort_all), /metrics sglang:generation_tokens_total counter
- contamination companions ("M:" prompts) write their own codename; FAKE_CONTAM=1 leaks one into greedy outputs
- FAKE_FAIL_ALWAYS=replay -> every launch with --enable-linear-replayssm-spec exits; FAKE_CAP_FAIL=<ssm dtype> -> K 33
"""
import hashlib, json, os, sys, threading, time
from array import array
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ARGS = sys.argv[1:]
FLAGS = ["--model-path", "--tp-size", "--kv-cache-dtype", "--attention-backend", "--mem-fraction-static",
         "--max-running-requests", "--chunked-prefill-size", "--context-length", "--mamba-radix-cache-strategy",
         "--mamba-ssm-dtype", "--max-mamba-cache-size", "--speculative-algorithm", "--speculative-draft-model-path",
         "--speculative-draft-model-quantization", "--speculative-num-draft-tokens", "--speculative-num-steps",
         "--speculative-eagle-topk", "--enable-metrics", "--disable-flashinfer-autotune", "--random-seed", "--host", "--port",
         "--log-level", "--cuda-graph-max-bs-decode", "--decode-log-interval", "--disable-prefill-cuda-graph",
         "--enable-linear-replayssm-spec"]
if "--help" in ARGS:
    print("usage: launch_server.py [-h] " + " ".join(f"[{f} X]" for f in FLAGS))
    sys.exit(0)
for a in ARGS:
    if a.startswith("--"):
        assert a in FLAGS, f"unknown flag {a}"
assert "--watchdog-timeout" not in ARGS, "optional-flag filter failed"
assert sum(a == "--mem-fraction-static" for a in ARGS) == 1, "mem fraction must be set exactly once"


def arg(name, default=None):
    return ARGS[ARGS.index(name) + 1] if name in ARGS else default


PORT = int(arg("--port", 30000))
ALGO = arg("--speculative-algorithm")
SSM = arg("--mamba-ssm-dtype", "float32")
MEM = float(arg("--mem-fraction-static", 0.62))
MAXRUN = int(arg("--max-running-requests", 32))
STRAT = arg("--mamba-radix-cache-strategy", "extra_buffer")
REPLAY = "--enable-linear-replayssm-spec" in ARGS
NO_PREFILL = "--disable-prefill-cuda-graph" in ARGS
OUT = Path(os.environ["E11_OUT"])
INPUT = Path(os.environ["E11_INPUT"])

if os.environ.get("FAKE_FAIL_ALWAYS") == "replay" and REPLAY:
    print("ValueError: simulated: --enable-linear-replayssm-spec unsupported here", flush=True)
    sys.exit(3)

K = int(arg("--max-mamba-cache-size", 33 if SSM == "float32" else 68))
if os.environ.get("FAKE_CAP_FAIL") == SSM:
    K = 33
SLOTS = {"extra_buffer_lazy": 4, "no_buffer": 3}.get(STRAT, 5)
CAP = K // SLOTS
RUN_CAP = min(CAP, MAXRUN)
KV = 960000 if (MEM >= 0.80 and NO_PREFILL) else 386563
_bs = [b for b in (1, 2, 3, 4, 5, 6, 7, 8, 10, 12, 14, 16) if b <= RUN_CAP]
if RUN_CAP not in _bs:
    _bs.append(RUN_CAP)
for tp in range(4):
    print(f"[2026-10-17 12:00:00 TP{tp}] Load weight end. elapsed=2.4 s, type=Qwen3_5ForConditionalGeneration, quant=compressed-tensors, avail mem=17.10 GB, mem usage=4.62 GB.", flush=True)
for tp in range(4):
    print(f"[2026-10-17 12:00:01 TP{tp}] Using FP8 KV cache but no scaling factors provided. Defaulting to scaling factors of 1.0.", flush=True)
    print(f"[2026-10-17 12:00:01 TP{tp}] Mamba Cache is allocated. max_mamba_cache_size: {K}, conv_state size: 0.05GB, ssm_state size: 1.21GB intermediate_ssm_state_cache size: {0.0 if REPLAY else 1.82}GB", flush=True)
if CAP < MAXRUN:
    for tp in range(4):
        print(f"[2026-10-17 12:00:01 TP{tp}] max_running_requests is capped to {CAP} by the mamba state cache (max_mamba_cache_size={K}, {SLOTS} state slots per request). To raise it: increase --mamba-full-memory-ratio or --max-mamba-cache-size, or halve the state size with --mamba-ssm-dtype bfloat16.", flush=True)
for tp in range(4):
    print(f"[2026-10-17 12:00:02 TP{tp}] KV Cache is allocated. dtype: torch.float8_e4m3fn, #tokens: {KV}, K size: {KV * 3802 / 1e9:.2f} GB, V size: {KV * 3802 / 1e9:.2f} GB", flush=True)
    if ALGO:
        print(f"[2026-10-17 12:00:02 TP{tp}] KV Cache is allocated. dtype: torch.float8_e4m3fn, #tokens: {KV}, K size: {KV * 1190 / 1e9:.2f} GB, V size: {KV * 1190 / 1e9:.2f} GB", flush=True)
if not NO_PREFILL:
    print("[2026-10-17 12:00:03 TP0] Capture target prefill CUDA graph begin. backend=breakable, num_tokens=[4, 8], avail mem=8.35 GB", flush=True)
    print("[2026-10-17 12:00:04 TP0] Capture target prefill CUDA graph end. elapsed=1.0 s, mem usage=2.60 GB, avail mem=5.75 GB.", flush=True)
if ALGO:
    print(f"[2026-10-17 12:00:05 TP0] Capture target verify CUDA graph begin. backend=full, num_tokens_per_req=8, bs={_bs}, avail mem=5.27 GB", flush=True)
else:
    print(f"[2026-10-17 12:00:05 TP0] Capture target decode CUDA graph begin. backend=full, num_tokens_per_req=1, bs={_bs}, avail mem=5.27 GB", flush=True)
print(f"[2026-10-17 12:00:06 TP0] Capture draft verify CUDA graph end. elapsed=1.0 s, mem usage=0.38 GB, avail mem={1.6 if NO_PREFILL else 4.39} GB.", flush=True)
if REPLAY:
    print("[2026-10-17 12:00:06 TP0] ReplaySSM spec-verify enabled (fake)", flush=True)
time.sleep(1.0)

LOCK = threading.Lock()
SEM = threading.Semaphore(RUN_CAP)
ACTIVE = [0]
GEN_TOTAL = [0]
ABORT_AT = [0.0]
_P = {}


def prompts():
    if not _P:
        p = json.load(open(OUT / "prompts.json", encoding="utf-8"))
        cfg = json.load(open(OUT / "tokenize_cfg.json", encoding="utf-8"))
        sol = json.load(open(next(INPUT.rglob("arc-agi_evaluation_solutions.json")), encoding="utf-8"))
        _P.update(p=p, cfg=cfg, sol=sol, sanity=cfg["units"][-8:])
    return _P


def which_unit(ids):
    for uid, pid in prompts()["p"]["units"].items():
        if ids[:len(pid)] == pid:
            return uid, len(pid)
    return None, 0


def toks(seed_text, n, diverge_at=None):
    h = hashlib.sha256(seed_text.encode()).digest()
    out = [1000 + (h[i % 32] * 7 + i) % 5000 for i in range(n)]
    if diverge_at is not None and diverge_at < n:
        out[diverge_at] += 1
    return out


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, obj, code=200, ctype="application/json"):
        body = (json.dumps(obj) if ctype == "application/json" else obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path == "/health":
            return self._send("ok", ctype="text/plain")
        if self.path == "/get_server_info":          # like the real server: reports the REQUESTED max running
            return self._send({"version": "0.5.21-fake", "max_total_num_tokens": KV, "max_running_requests": MAXRUN,
                               "attention_backend": "flashinfer", "mamba_radix_cache_strategy": STRAT, "page_size": 1,
                               "kv_cache_dtype": "fp8_e4m3", "mamba_ssm_dtype": SSM, "speculative_algorithm": ALGO,
                               "mem_fraction_static": MEM, "disable_prefill_cuda_graph": NO_PREFILL,
                               "enable_linear_replayssm_spec": REPLAY, "internal_states": [{}]})
        if self.path == "/metrics":
            with LOCK:
                g = GEN_TOTAL[0]
            return self._send("# HELP sglang:generation_tokens_total Number of generation tokens processed.\n"
                              "# TYPE sglang:generation_tokens_total counter\n"
                              f'sglang:generation_tokens_total{{engine_type="unified"}} {float(g)}\n'
                              f"sglang:num_running_reqs {ACTIVE[0]}\n", ctype="text/plain")
        self._send({"error": "not found"}, 404)

    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        if self.path == "/abort_request":
            if body.get("abort_all"):
                ABORT_AT[0] = time.time()
            return self._send("", ctype="text/plain")
        if self.path != "/generate":
            return self._send({"error": "not found"}, 404)
        ids, sp = body["input_ids"], body["sampling_params"]
        max_new = int(sp["max_new_tokens"])
        t_req = time.time()
        with SEM:                                     # beyond the cap requests queue, as in SGLang
            return self._generate(ids, sp, max_new, t_req)

    def _generate(self, ids, sp, max_new, t_req):
        # prefill first (uncached part costs time), THEN decode as a running request -- the order SGLang uses
        with LOCK:
            cached = 0
            a = array("I", ids).tobytes()
            for seq in SEEN:                              # common prefix by binary search on bytes (fast, C-level)
                lo, hi = 0, min(len(a), len(seq)) // 4
                while lo < hi:
                    mid = (lo + hi + 1) // 2
                    if a[:mid * 4] == seq[:mid * 4]:
                        lo = mid
                    else:
                        hi = mid - 1
                cached = max(cached, min(lo, len(ids) - 1))
        time.sleep((len(ids) - cached) / 4000.0)          # uncached prefill: ~2.5 s per 10k tokens (L4: seconds)
        with LOCK:
            ACTIVE[0] += 1
        try:
            return self._decode(ids, sp, max_new, t_req, cached)
        finally:
            with LOCK:
                ACTIVE[0] -= 1

    def _decode(self, ids, sp, max_new, t_req, cached):
        time.sleep(0.5 + min(max_new, 4096) / 1500.0)        # decode >> prefill variance, as on the GPU (minutes vs seconds)
        P = prompts()
        uid, plen = which_unit(ids)
        think_close = P["p"]["think_close"][0]
        stop_ids = set(sp.get("stop_token_ids") or [])
        text = ""
        if ABORT_AT[0] and t_req <= ABORT_AT[0]:
            out, fin = toks(str(ids[:30]), 7), {"type": "abort"}
        elif think_close in stop_ids:                 # phase 1 / PROD: natural close after ~60-300 tokens
            n = 60 + (hash(str(ids[-5:]) + str(sp.get("sampling_seed"))) % 240)
            out = toks(str(ids[:50]) + str(sp.get("sampling_seed")), min(n, max_new - 1)) + [think_close]
            fin = {"type": "stop", "matched": think_close}
            time.sleep(len(out) / 300.0)                 # 0.2-1.0 s more: PROD requests overlap and refill
        elif uid and len(ids) > plen and uid in P["sanity"]:      # phase 2 of a sanity puzzle
            tid = uid.split("#")[0]
            grid = P["sol"][tid][0] if P["sanity"].index(uid) % 2 == 0 else [[9, 9], [9, 9]]
            text = "Answer:\n```grid\n" + "\n".join(" ".join(str(v) for v in r) for r in grid) + "\n```"
            out, fin = toks(text, 40), {"type": "stop", "matched": 248046}
        else:
            greedy = float(sp.get("temperature", 1.0)) == 0.0
            div = 200 if (greedy and SSM != "float16") else None    # other SSM dtypes drift from W1 (fp16)
            seed_text = str(ids[-20:]) if greedy else f"{ids[-20:]}{sp.get('sampling_seed')}"
            out = toks(seed_text, max_new, div)
            fin = {"type": "length", "length": max_new}
            if uid and uid.startswith("M:"):
                text = f"Codename {P['cfg']['marks'][uid[2:]]}. Let me look at the examples."
            elif greedy and os.environ.get("FAKE_CONTAM") == "1":
                text = "Codename " + next(iter(P["cfg"]["marks"].values())) + " ... (leaked)"
            else:
                text = "Let me look at the examples."
        with LOCK:
            SEEN.append(array("I", list(ids) + list(out)).tobytes())
            del SEEN[:-200]                          # bounded: the PROD loop sends thousands of requests
            GEN_TOTAL[0] += len(out)
        meta = {"prompt_tokens": len(ids), "completion_tokens": len(out), "cached_tokens": cached, "finish_reason": fin,
                "e2e_latency": 0.1}
        if ALGO:
            meta["spec_accept_length"] = 4.6
        self._send({"text": text, "output_ids": out, "meta_info": meta})


SEEN = []


def ticker():
    """Like SGLang's --decode-log-interval: a Decode line at a fixed cadence with the CURRENT running count."""
    while True:
        time.sleep(0.02)
        with LOCK:
            running = ACTIVE[0]
            if running:
                print(f"[2026-10-17 12:00:10 TP0] Decode batch, #running-req: {running}, #full token: {running * 5000}, "
                      f"full token usage: {min(0.99, running * 0.05):.2f}, mamba num: {running * SLOTS}, mamba usage: "
                      f"{running * SLOTS / K:.2f}, " + ("accept len: 4.60, " if ALGO else "")
                      + f"cuda graph: True, gen throughput (token/s): {35.0 * running:.2f}, #queue-req: 0, ", flush=True)


threading.Thread(target=ticker, daemon=True).start()
ThreadingHTTPServer(("127.0.0.1", PORT), H).serve_forever()
