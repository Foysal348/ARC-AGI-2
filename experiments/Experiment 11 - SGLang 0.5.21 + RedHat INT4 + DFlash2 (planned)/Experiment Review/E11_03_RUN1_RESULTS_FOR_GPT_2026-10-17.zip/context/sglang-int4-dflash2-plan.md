---
name: sglang-int4-dflash2-plan
description: "User-chosen path (2026-10-15) to test SGLang 0.5.21 + RedHat Qwen3.8-27B INT4 + BF16 DFlash2 on 4×L4; facts verified from source, Kaggle build templates, guard rails"
metadata:
  node_type: memory
  type: project
  originSessionId: 1c6db7aa-c78b-4b3a-b97a-5c67187fe52f
  modified: 2026-10-15T10:34:45.557Z
---

**Decision (user, 2026-10-15):** test the newest stack in a SEPARATE validation notebook. E10 FP8 + vLLM 0.19 stays as the fallback.

**Stack (verified on PyPI / GitHub v0.5.21):**
- sglang 0.5.21: torch==2.13.0, torchaudio==2.11.0, flashinfer_python[cu13]==0.6.18, transformers==5.12.1, xgrammar 0.2.7, cuda-python>=13.
- The sglang wheel is manylinux_2_34; Kaggle has glibc 2.35, so it is OK.

**Models:**
- Target: `RedHatAI/Qwen3.8-27B-INT4`.
  - 19.45 GB: `model.safetensors` 18.6 GB + `model_mtp.safetensors` 0.85 GB.
  - BF16 MTP head, ignored via `re:^mtp.*`.
  - W4A16 g128 sym.
  - Card vs BF16: GPQA −1.35, AIME25 −1.25.
- Drafter: `z-lab/Qwen3.8-27B-DFlash2` (`incoai` copy is identical): 3.85 GB BF16, 5 layers, `DFlash2DraftModel`.

**SGLang flags verified in the v0.5.21 source (arg_groups/fields):**
- `--speculative-algorithm DFLASH` (builtins: EAGLE, EAGLE3, NEXTN, STANDALONE, NGRAM, DFLASH, DSPARK, UNO).
- `--speculative-draft-model-path`.
- `--speculative-draft-model-quantization unquant`. **Mandatory:** issue #39087, the drafter otherwise inherits INT4 and acceptance drops to ~1.0.
- `--speculative-num-draft-tokens` (alias `--speculative-dflash-block-size`).
- `--mamba-radix-cache-strategy {auto,no_buffer,extra_buffer,extra_buffer_lazy}`.
- `--mamba-ssm-dtype {float32,bfloat16,float16}`.
- `--mamba-full-memory-ratio` (fallback 0.9), `--mem-fraction-static`, `--max-running-requests`, `--kv-cache-dtype fp8_e4m3`, `--quantization compressed-tensors`, `--disable-flashinfer-autotune`, `--enable-metrics`.

**Guard rails (my validation of GPT's plan):**
- SSM state: test float32 first (the model's native setting), then float16. Avoid bfloat16 unless measured; a bf16 state is a known quality risk on long thinking.
- Use fresh `SGLANG_CACHE_DIR` / `CUDA_CACHE_PATH` (issue #42917: stale kernel cache gave PPL 9.98 vs 6.05).
- Bundle flashinfer-cubin + flashinfer-jit-cache (cu130) with flashinfer 0.6.18 (extra index).
- cuda-compat is only an optional asset. The first GPU cell prints `nvidia-smi` and runs a CUDA GEMM, a FlashInfer kernel and a TP4 all-reduce. Our same Docker image (sha 37c64f7d) already ran torch 2.13 cu130 on Kaggle in ARC-AGI-3 (RTX PRO 6000).
- Test order: A INT4 only → B INT4 + MTP (EAGLE steps 3, topk 1, draft 4) → C INT4 + DFlash2.
- Concurrency 1/4/8/16 first, then 20–32 by measured KV/GDN headroom.
- Correctness checks:
  - greedy equality target vs speculative;
  - EVAL12 paired vs FP8 at Poetiq temperature 1.0;
  - watch for acceptance collapsing to 0 (#43514) and greedy drift with thinking (#38009).

**Kaggle build templates (ARC-AGI-3 project; proven on Kaggle):**
- Model mirror (CPU, internet ON, stream HF → Kaggle resumable upload, no disk staging): `D:\Machine Learning 1 Year Challenge\ARC-AGI-3\experiments\2026-09-26_nvidia-flashnext-nvfp4\01_model-upload\NVIDIA_FlashNext_NVFP4_01_upload_on_kaggle.ipynb`.
- Wheelhouse (pip download binary-only → requirements.lock → offline install test → flag check → `kaggle datasets create`): `...\2026-09-25_occamy-1.0-nvfp4\02_runtime\vLLM_0_29_0_wheelhouse_build_on_KAGGLE.ipynb`. This built torch 2.13 cu130 + flashinfer 0.6.18 (dataset `foysalemonshanto/occamy-1-0-0-vllm`).
- Both need Kaggle Secrets KAGGLE_USERNAME / KAGGLE_KEY attached and must be started from the editor (Save & Run All); API-started runs cannot read secrets.

Related: [[prefer-latest-stack]], [[kaggle-quick-save-push]], [[no-push-without-approval]].

**Stage 1 built and quick-saved, 2026-10-15** (Experiment 11 folder; builder `build_e11_assets.py`):
- `foysalemonshanto/e11-01-model-mirror-int4-dflash2`: HF → Kaggle stream; models `qwen3-8-27b-int4-redhat` and `qwen3-8-27b-dflash2` (private since v2).
- `foysalemonshanto/e11-02-sglang-0-5-21-wheelhouse`: dataset `sglang-0-5-21-cu13-wheelhouse`, 220 wheels, about 5 GB.
- Found while building:
  - sglang 0.5.19–0.5.21 pin `cuda-tile==1.6.0rc5`, which is sdist-only. The uv lock overrides it to 1.6.0, installed with `--no-deps`.
  - flashinfer-cubin 0.6.18 does not exist; use `flashinfer-jit-cache 0.6.18+cu130` from flashinfer.ai/whl/cu130.
- Next: the user runs both from the editor with secrets attached, then I build the Stage-2 GPU validation notebook.

**Rev 2 of E11-02, 2026-10-15** (after an external audit; Kaggle v2, sha f4d184cd; E11-01 unchanged, sha f6ad2a72):
- nvcc / crt / nvvm / nvjitlink pinned 13.0.88. This is torch 2.13's own cuda-toolkit 13.0.3 set; the Kaggle L4 driver supports CUDA 13.0. 13.4.92 came only from humming-kernels' unpinned nvcc. This is a match, not a downgrade: the engine versions are unchanged.
- Install into a venv (`venv --without-pip` + `pip --python`), NOT `--target` + PYTHONPATH.
  - Proof from our own ARC-AGI-3 vLLM 0.29 log: `cuteDSL (CUTLASS Python) not available`. nvidia-cutlass-dsl is only a `.pth`.
  - FlashInfer JIT there never found the wheel nvcc (Occamy PDF, problem #2).
- Stage 2 must set:
  - `CUDA_HOME=<site>/nvidia/cu13`;
  - `PATH=<venv>/bin:$CUDA_HOME/bin`;
  - possibly a libcudart.so symlink (the pip runtime ships only .so.13).
  - BUILD_PROBE.json "toolchain" says which.
- 2026-10-15 user: **models private** -> E11-01 v2 `PUBLIC = False` (sha 40b57adf). Teammate accounts (hosen42 / esfersami50) cannot attach them until shared; the dataset from E11-02 stays public (only public PyPI wheels).
- **Stage 1 results (2026-10-15):**
  - Both private models are created on foysalemonshanto; sizes are verified.
  - E11-02 build passed on Kaggle (220 wheels, 4.68 GiB; venv OK; cutlass .pth OK; nvcc 13.0.88 compiles sm_89; all flags present). Only the publish cell failed: no Secrets attached.
  - Stage 2 needs symlinks under CUDA_HOME: `lib/libcudart.so` and `lib64`.
  - Private quota on foysal is tight; Occamy NVFP4 was made public to make room.
- **Stage 2 built (2026-10-15, local only, not pushed):** `E11_03_sglang_int4_gpu_validation_on_KAGGLE.ipynb`.
  - Builder: `build_e11_03_gpu_validation.py`. Sha 9e920bf3.
  - Cells: venv + shims (`libcudart.so`, `lib64`, `libcuda`) → GPU preflight (fatal: GEMM / `sgl_kernel` / NCCL) → E10 prompts → A / B (NEXTN, draft path = INT4, unquant) / C (DFLASH block 8, unquant), each with smoke, greedy, sweep 1-32×4k and long 16×24k → D (best + SSM fp16) → sanity 8 cheap puzzles (E10 DIRECT) → report.
  - CPU harness (`scratchpad/e11_03_harness`, fake server + real INT4 tokenizer via transformers 5.12.1): scenarios main / ladder / bfail all pass.
  - Push script: `push154/push_e11_03_gpu_validation.py`. QUICK_SAVE, L4, no internet, foysalemonshanto.
- **Kaggle drops '+' from dataset file names.** `flashinfer_jit_cache-0.6.18+cu130` became `0.6.18cu130`, so pip cannot match the lock.
  - Dataset `foysalemonshanto/sglang-0-5-21-cu13-wheelhouse` v1 exists (public, 4.99 GB). The CLI create call returned non-JSON and exit 1, yet the dataset was created: verify by listing files, not by exit code.
  - E11-02 v2 (sha 4fe26019, Kaggle nb v7) adds `install_wheelhouse.py` (restores names from SHA256SUMS, checks sha256), tests it on a '+'-stripped layout, and publishes it with `datasets version`. The user runs it with Secrets.
  - E11-03 restores the names itself.
- **Stage 1 COMPLETE (2026-10-15):** dataset v2 is published (227 files, with the installer). On Kaggle the installer test passed and all nvcc link tests pass. Next: E11-03 quick-save after user go; GPU run after the GPU reset.


- **E11-03 rev 3 (2026-10-17):** sha 4a1538f9.
  - Sweep levels now include 12.
  - New cell 5b on the best config: contcache (forced-close continuation must hit the prefix cache, ratio ≥ 0.9), longctx (about 90k contexts), contam (greedy alone vs in a batch), temp (T 1.0 vs 0.6).
  - Harness main/ladder/bfail PASS (39/40/33); the fake server has a prefix cache.
  - The hvenv python.exe was restored with `python -m venv --upgrade`.
  - Run time about 3–3.5 h.
  - Blocked on an account: the models are private on foysal and foysal's quota is exhausted.
- 2026-10-17 **E11-03 rev 3b committed** (user go). Pushed as `foysalemonshanto/e11-03-sglang-int4-gpu-validation` v1, SAVE_AND_RUN_ALL, notebook sha e47d1660, budget about 5 h. Harness fixed: the best-spec check now uses the argmax over complete configs, and the fake server's prefill is slower. main 39, ladder 40, bfail 33 and badsha all PASS.
- 2026-10-17 **E11-03 run 1 result** (COMPLETE, 203 min, 0 errors). See `Experiment 11/Experiment Results/E11-03 run1 analysis (2026-10-17).md`.
  - **The flat curve was a CAP:** SGLang caps max_running_requests by the mamba cache at 5 slots per request when speculating. Caps: A 22, B 10, C 6, D (fp16 SSM) 13.
  - **D (DFlash2 + fp16 SSM) at a real 12 running = 404 tok/s**, 1.39x INT4 alone and about 1.3x vLLM.
  - **Capacity:** auto mem_fraction_static 0.62 leaves 4.4 GB per GPU free. KV is only 387k with D (vLLM 1.35M; production needs about 920k).
  - Custom allreduce is off on 4 PCIe GPUs (TP2 would allow it). Sanity C 7/8; contam = batch non-determinism, not leakage; contcache PASS (11x).
  - Harness must assert real running == level.
  - Next: E11-04 probe with mem-fraction 0.85, max-running 12, mamba cache 60+, plus a production-like long test (needs the user's go).
