# E11-03 rev 3: pre-run audit of the SGLang 0.5.21 + INT4 + DFlash2 GPU validation notebook (2026-10-17)

**What we ask:**
- Audit `notebook/E11_03_sglang_int4_gpu_validation_on_KAGGLE.ipynb` before we spend about 3–3.5 h of 4×L4 GPU on it.
- It is **not a submission.** It measures whether a faster serving stack works on Kaggle and how fast it is. The result decides the engine of our next production notebook (Experiment 11).
- Find anything that would:
  - crash a stage;
  - make a measurement wrong or misleading;
  - waste the run;
  - fail to answer the questions in §3.
- **Verify against the files.** Mark each claim *verified from files* or *hypothesis*.
- Minimal, targeted fixes only; no redesign.

## 1. Context

**Competition:**
- Kaggle ARC Prize 2026 (ARC-AGI-2): offline, 12 h on 4×L4 (sm89, 24 GB each), Internet OFF.
- Hidden test = 240 tasks; the public LB scores its 120-task part.
- **The binding problem is coverage:** finishing tasks within 12 h.

**Current production** (fallback, proven):
- vLLM 0.19 + Qwen3.8-27B FP8, fp8 KV, MTP-3, TP4.
- About 255–281 tok/s aggregate on long Poetiq program-synthesis requests: 77,824–122,880 thinking tokens each, then a forced close and a ≤ 8,192-token answer.

**Experiment 11 path** (user-chosen):
- SGLang 0.5.21;
- RedHat Qwen3.8-27B-INT4 (W4A16 g128, compressed-tensors, BF16 MTP head);
- z-lab Qwen3.8-27B-DFlash2 drafter (BF16, block 8, `--speculative-draft-model-quantization unquant`, which is mandatory: issue #39087).

**Stage 1 is done and verified on Kaggle** (`stage1_results/`):
- private model mirrors created;
- an offline SGLang wheelhouse dataset (220 wheels, venv install, nvcc 13.0.88 pins, '+'-in-filename restore via SHA256SUMS);
- a CPU probe passed.

**Recent findings (D66/L66 deep runs, FP8 vLLM; `context/D66_L66_findings.md`):**

| Finding | Value |
|---|---|
| Decode speed at 12 vs 16 slots | equal (254 vs 256 tok/s) |
| 16 slots at 77.8k | 66 preemptions, KV 99.9 % |
| 12 slots at a 155k context | 0 preemptions |
| Train-passing programs that are test-correct | only 35–42 % |
| Independent attempts | highly complementary (union 50 vs 28/34 of 103) |
| vLLM T 0.6 vs T 1.0 (DIRECT vs Poetiq, confounded) | MTP acceptance 0.664 vs 0.549, +17 % decode |

## 2. The notebook (built by `build/build_e11_03_gpu_validation.py`; rev 2 → rev 3 diff in `diffs/`)

| Cell | What |
|---|---|
| 1 | venv from the wheelhouse + CUDA shims (`libcudart.so`, `lib64`, `libcuda.so`) + fresh caches |
| 2 | GPU preflight. Fatal: bf16 GEMM on 4 GPUs, `sgl_kernel` import, NCCL TP4 all-reduce. Recorded only: Triton, FlashInfer head_dim 256 bf16/fp8, nvcc JIT, CuTe DSL |
| 3 | E10's exact prompts, tokenized in the venv (32 sweep units, 8 sanity puzzles) |
| 4 | Server helpers (launch, health, `/generate` with `input_ids`, decode-log parsing), E10's grid parser, E10 DIRECT protocol |
| 5 | A = INT4 alone; B = INT4 + MTP (NEXTN, 3 steps, topk 1, 4 draft tokens, unquant); C = INT4 + DFlash2 (DFLASH, block 8, unquant). Each: smoke, greedy 4 × 512, sweep at 1/4/8/**12**/16/24/32 × 4,096 tokens, long 16 × 24,576. A Triton attention retry if a launch fails |
| **5b (new)** | Extra tests on the best of B/C (falls back to A), see §3 |
| 6 | D = best + `--mamba-ssm-dtype float16`: greedy drift vs float32, plus the sweep |
| 7 | Sanity solve, 8 cheap puzzles, E10 DIRECT at T 0.6 (FP8 expectation about 6.6 of 8) |
| 8 | `report.md` |

**Common flags:** `--tp-size 4 --kv-cache-dtype fp8_e4m3 --context-length 106496 --max-running-requests 32 --chunked-prefill-size 4096 --mamba-ssm-dtype float32 --enable-metrics --disable-flashinfer-autotune`, plus optional flags only if `--help` lists them. The mamba radix strategy is `auto` (it resolves to `extra_buffer`).

**Time guard:** no new stage after 5 h; each extra stage needs 15 min left.

## 3. Rev 3 extra tests (cell 5b): please check that each really measures what it claims

1. **contcache.**
   - 4 prompts think 6,144 tokens.
   - The forced-close continuation (prompt + thinking + stop text) is sent again; `cached_tokens / prompt_tokens` is checked (pass ≥ 0.9).
   - Wall time is compared with a cold request of the same length (the 2nd token changed).
   - This matters because our scheduler sends phase 2 as a new request. On a hybrid model (GDN + attention) the radix cache must also hold the SSM state at that point. If it does not, every forced close re-prefills about 80k tokens.
   - Questions: is the warm/cold design valid? Is `cached_tokens` the right meta field? Does a mamba-state checkpoint granularity (`extra_buffer`, page size) make 0.9 the wrong threshold?
2. **longctx.**
   - Up to 12 requests at about 90k-token contexts (built by concatenating real prompts, ending with a real prompt so the chat template ends properly), 1,024 new tokens each.
   - Measures tok/s, accept length and KV usage.
   - Is the sizing from `max_total_num_tokens` right for a hybrid model?
3. **contam.**
   - The same 4 greedy prompts alone, then inside a 16-request batch (12 others at T 1.0).
   - Compares the common prefix.
   - Is this a sensible cross-request isolation check given batch-variant numerics and speculative decoding?
4. **temp.**
   - 12 × 4,096 tokens at T 1.0 (top_p 0.95, top_k 20) vs T 0.6.
   - Measures tok/s and accept length.

## 4. Questions

1. Any crash path in the rerun of the whole notebook on Kaggle, especially in the new code and the `EXTRA_STAGES` hook in `run_config`?
2. Do the measurements answer the deployment question: which config (A/B/C, SSM dtype, slot count, temperature) maximises **correct-ish tokens per hour for long-thinking requests**, and is it safe (greedy parity, contam, sanity)?
3. Is anything important for the production engine missing that this run could measure cheaply?
   - continuation with a different sampling seed;
   - `/abort_request`;
   - preemption / retraction behaviour at high KV;
   - DFlash2 acceptance on code-writing (Poetiq) text vs DIRECT grids.
4. Are the time estimates (about 3–3.5 h) plausible? Is the 5 h guard safe?

## 5. Output format

1. **Verdict:** RUN AS IS / RUN AFTER THESE FIXES / DO NOT RUN.
2. **Findings table:**
   - severity: blocker / major / minor;
   - cell and line;
   - what goes wrong, and when;
   - evidence (verified / hypothesis);
   - minimal fix snippet.
3. **Missing cheap measurements,** ranked.
4. **Checks you ran** that found nothing.

## 6. File map

| Path | What |
|---|---|
| `notebook/E11_03_sglang_int4_gpu_validation_on_KAGGLE.ipynb` | **The notebook to audit** (sha256 `4a1538f9…`) |
| `build/build_e11_03_gpu_validation.py` | Builder (rev 3) |
| `build/build_e11_03_gpu_validation.rev2.py`, `diffs/rev2_to_rev3.diff` | Previous builder and the change |
| `build/sglang_0_5_21_requirements.lock`, `hf_pins.json`, `uv_overrides.txt` | Stack pins |
| `harness/run_harness.py`, `harness/fake_sglang_server.py` | CPU harness: real cells, fake SGLang server with a prefix cache |
| `harness/logs/` | main / ladder / bfail results (39/40/33 checks PASS); `run_main_out/` = the fake run's `results.json` and `report.md` |
| `stage1_results/` | Kaggle Stage-1 runs: wheelhouse build probe, flags, logs |
| `context/` | Experiment 11 README, D66/L66 findings, push script |
