"""Fake `python -m sglang.launch_server` for the E11-03 CPU harness (stdlib only).

- --help prints every flag the notebook may pass (minus --watchdog-timeout, to exercise the optional-flag filter)
- /health, /get_server_info, /metrics, /generate (input_ids + sampling_params) like SGLang 0.5.21
- writes "Decode batch" lines in SGLang's format to stdout
- phase 1 (stop_token_ids = [</think>]) closes thinking naturally; phase 2 returns the solution grid for every other
  sanity puzzle (so hit=1 and hit=0 both occur)
- greedy (temperature 0): B (NEXTN) reproduces A exactly; C (DFLASH) diverges at token 100; SSM float16 at token 200
- FAKE_FAIL_FIRST_LAUNCH=<algo> makes the first launch of that config exit (tests the attention-backend ladder)
"""
import hashlib, json, os, sys, threading, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ARGS = sys.argv[1:]
if "--help" in ARGS:
    flags = ["--model-path", "--tp-size", "--quantization", "--kv-cache-dtype", "--attention-backend", "--mem-fraction-static",
             "--max-running-requests", "--chunked-prefill-size", "--max-prefill-tokens", "--context-length",
             "--mamba-radix-cache-strategy", "--mamba-ssm-dtype", "--mamba-full-memory-ratio", "--speculative-algorithm",
             "--speculative-draft-model-path", "--speculative-draft-model-quantization", "--speculative-num-draft-tokens",
             "--speculative-num-steps", "--speculative-eagle-topk", "--reasoning-parser", "--enable-metrics",
             "--disable-flashinfer-autotune", "--random-seed", "--host", "--port", "--log-level",
             "--cuda-graph-max-bs-decode", "--decode-log-interval"]
    print("usage: launch_server.py [-h] " + " ".join(f"[{f} X]" for f in flags))
    sys.exit(0)


def arg(name, default=None):
    return ARGS[ARGS.index(name) + 1] if name in ARGS else default


PORT = int(arg("--port", 30000))
ALGO = arg("--speculative-algorithm")
SSM = arg("--mamba-ssm-dtype", "float32")
OUT = Path(os.environ["E11_OUT"])
INPUT = Path(os.environ["E11_INPUT"])
assert "--watchdog-timeout" not in ARGS, "optional-flag filter failed"

marker = OUT / f"fake_launch_{ALGO}.count"
n_launch = int(marker.read_text()) + 1 if marker.exists() else 1
marker.write_text(str(n_launch))
if (os.environ.get("FAKE_FAIL_FIRST_LAUNCH") == str(ALGO) and n_launch == 1) or os.environ.get("FAKE_FAIL_ALWAYS") == str(ALGO):
    print("RuntimeError: simulated FlashInfer JIT failure on first launch", flush=True)
    sys.exit(3)

LOCK = threading.Lock()
ACTIVE = [0]
print(f"[2026-10-15 12:00:00] server_args: algo={ALGO} ssm={SSM}", flush=True)
print("[2026-10-15 12:00:01 TP0] Load weight end. type=Qwen3_5ForConditionalGeneration, avail mem=12.1 GB", flush=True)
print("[2026-10-15 12:00:02 TP0] KV Cache is allocated. #tokens: 1200000, K size: 4.6 GB, V size: 4.6 GB", flush=True)
print("[2026-10-15 12:00:02 TP0] Mamba Cache is allocated. max_mamba_cache_size: 96", flush=True)
print("[2026-10-15 12:00:03 TP0] Capture cuda graph end. Time elapsed: 30 s", flush=True)
time.sleep(1.0)

_PROMPTS = None
_SOL = None


def prompts():
    global _PROMPTS, _SOL
    if _PROMPTS is None:
        p = json.load(open(OUT / "prompts.json", encoding="utf-8"))
        _PROMPTS = p
        sol = next(INPUT.rglob("arc-agi_evaluation_solutions.json"))
        _SOL = json.load(open(sol, encoding="utf-8"))
    return _PROMPTS, _SOL


def which_unit(ids):
    p, _ = prompts()
    for uid, pid in p["units"].items():
        if ids[:len(pid)] == pid:
            return uid, len(pid)
    return None, 0


def toks(seed_text, n, diverge_at=None):
    h = hashlib.sha256(seed_text.encode()).digest()
    out = [1000 + (h[i % 32] * 7 + i) % 5000 for i in range(n)]
    if diverge_at is not None and diverge_at < n:
        out[diverge_at] += 1
    return out


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, obj, code=200, ctype="application/json"):
        body = (json.dumps(obj) if ctype == "application/json" else obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path == "/health":
            return self._send("ok", ctype="text/plain")
        if self.path == "/get_server_info":
            info = {"version": "0.5.21-fake", "max_total_num_tokens": 1200000, "max_running_requests": 32,
                    "attention_backend": "triton" if "--attention-backend" in ARGS else "flashinfer",
                    "mamba_radix_cache_strategy": "extra_buffer", "page_size": 1, "kv_cache_dtype": "fp8_e4m3",
                    "mamba_ssm_dtype": SSM, "speculative_algorithm": ALGO,
                    "speculative_num_draft_tokens": arg("--speculative-num-draft-tokens"),
                    "internal_states": [{"avg_spec_accept_length": 2.4 if ALGO else None}]}
            return self._send(info)
        if self.path == "/metrics":
            return self._send("sglang:num_running_reqs 0\n", ctype="text/plain")
        self._send({"error": "not found"}, 404)

    def do_POST(self):
        if self.path != "/generate":
            return self._send({"error": "not found"}, 404)
        req = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        ids, sp = req["input_ids"], req["sampling_params"]
        max_new = int(sp["max_new_tokens"])
        with LOCK:
            ACTIVE[0] += 1
            running = ACTIVE[0]
        try:
            time.sleep(0.05 + max_new / 400000.0)
            p, sol = prompts() if (OUT / "prompts.json").exists() else (None, None)
            uid, plen = which_unit(ids) if p else (None, 0)
            think_close = p["think_close"][0] if p else -1
            stop_ids = set(sp.get("stop_token_ids") or [])
            text = ""
            if think_close in stop_ids:                                   # phase 1: natural close after 60 tokens
                out = toks(str(ids[:50]), min(59, max_new - 1)) + [think_close]
                fin = {"type": "stop", "matched": think_close}
            elif uid and len(ids) > plen and uid in json.load(open(OUT / "tokenize_cfg.json"))["units"][32:]:   # phase 2
                tid = uid.split("#")[0]
                sanity = json.load(open(OUT / "tokenize_cfg.json"))["units"][32:]
                good = sanity.index(uid) % 2 == 0
                grid = sol[tid][0] if good else [[9, 9], [9, 9]]
                text = "Answer:\n```grid\n" + "\n".join(" ".join(str(v) for v in r) for r in grid) + "\n```"
                out = toks(text, 40)
                fin = {"type": "stop", "matched": 248046}
            else:
                greedy = float(sp.get("temperature", 1.0)) == 0.0
                div = None
                if greedy and ALGO == "DFLASH":
                    div = 100
                if greedy and SSM == "float16":
                    div = 200
                seed_text = str(ids[-20:]) if greedy else f"{ids[-20:]}{sp.get('sampling_seed')}"
                out = toks(seed_text, max_new, div)
                fin = {"type": "length", "length": max_new}
            cached = 0
            with LOCK:                                                      # rev 3: radix-style prefix cache
                for seq in SEEN:
                    n = 0
                    for a, b in zip(ids, seq):
                        if a != b: break
                        n += 1
                    cached = max(cached, min(n, len(ids) - 1))
                SEEN.append(list(ids) + list(out))
            meta = {"prompt_tokens": len(ids), "completion_tokens": len(out), "cached_tokens": cached, "finish_reason": fin,
                    "e2e_latency": 0.1}
            if ALGO:
                meta["spec_accept_length"] = 2.4 if ALGO == "NEXTN" else 3.1
                meta["spec_verify_ct"] = max(1, int(len(out) / meta["spec_accept_length"]))
            line = (f"[2026-10-15 12:00:10 TP0] Decode batch, #running-req: {running}, #token: {len(ids) + len(out)}, "
                    f"token usage: {min(0.99, running * 0.02):.2f}, " + (f"accept len: {meta.get('spec_accept_length')}, " if ALGO else "")
                    + f"cuda graph: True, gen throughput (token/s): {100.0 * running * (1.5 if ALGO else 1.0):.2f}, #queue-req: 0, ")
            with LOCK:
                print(line, flush=True)
            self._send({"text": text, "output_ids": out, "meta_info": meta})
        finally:
            with LOCK:
                ACTIVE[0] -= 1


SEEN = []
ThreadingHTTPServer(("127.0.0.1", PORT), H).serve_forever()
