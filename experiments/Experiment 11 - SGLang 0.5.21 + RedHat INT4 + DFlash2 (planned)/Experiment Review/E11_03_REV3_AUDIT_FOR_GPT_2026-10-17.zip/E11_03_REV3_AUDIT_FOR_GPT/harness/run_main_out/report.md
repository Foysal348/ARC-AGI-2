# E11-03 GPU validation · run 20261017T033130Z

Driver None (CUDA None) · shims {"renamed_wheels": ["flashinfer_jit_cache-0.6.18cu130-cp39-abi3-manylinux_2_28_x86_64.whl -> flashinfer_jit_cache-0.6.18+cu130-cp39-abi3-manylinux_2_28_x86_64.whl"]}

## Preflight

| step | ok | detail |
|---|---|---|
| harness (fatal) | OK | null |

## Engines

### A_int4 · OK
- launch: [(0, [], 'ready in 2s')]
- KV tokens 1200000 · max running 32 · attention flashinfer · mamba extra_buffer · SSM float32 · draft attention None
- smoke: {'tokens': 16, 'text': ''}

| requests | total tok/s | log gen tok/s | per-request tok/s | accept len | wall s | ok |
|---|---|---|---|---|---|---|
| 1 | 49318.5 | 100.0 | 60854.0 | - | 0.1 | 1/1 |
| 4 | 211784.7 | 400.0 | 55429.8 | - | 0.1 | 4/4 |
| 8 | 374335.0 | 800.0 | 54053.5 | - | 0.1 | 8/8 |
| 12 | 458715.0 | 1200.0 | 45867.4 | - | 0.1 | 12/12 |
| 16 | 605796.9 | 1600.0 | 45144.8 | - | 0.1 | 16/16 |
| 24 | 601649.3 | 2400.0 | 28976.7 | - | 0.2 | 24/24 |
| 32 | 790065.2 | 3200.0 | 30372.0 | - | 0.2 | 32/32 |
- long 16 x 24576: 1377761.6 tok/s total, accept -, wall 0.3 s, usage max 0.32

### B_int4_mtp · OK
- launch: [(0, [], 'ready in 2s')]
- KV tokens 1200000 · max running 32 · attention flashinfer · mamba extra_buffer · SSM float32 · draft attention None
- smoke: {'tokens': 16, 'text': ''}
- greedy_vs_A: 4/4 identical, mean common prefix 512.0 of 512 tokens

| requests | total tok/s | log gen tok/s | per-request tok/s | accept len | wall s | ok |
|---|---|---|---|---|---|---|
| 1 | 50811.9 | 150.0 | 51316.6 | 2.40 | 0.1 | 1/1 |
| 4 | 206784.0 | 600.0 | 53757.8 | 2.40 | 0.1 | 4/4 |
| 8 | 392183.0 | 1200.0 | 54675.7 | 2.40 | 0.1 | 8/8 |
| 12 | 502007.5 | 1800.0 | 47271.9 | 2.40 | 0.1 | 12/12 |
| 16 | 553893.4 | 2400.0 | 39860.7 | 2.40 | 0.1 | 16/16 |
| 24 | 726538.0 | 3600.0 | 37380.0 | 2.40 | 0.1 | 24/24 |
| 32 | 774897.7 | 4800.0 | 29030.2 | 2.40 | 0.2 | 32/32 |
- long 16 x 24576: 1411275.6 tok/s total, accept 2.40, wall 0.3 s, usage max 0.32

### C_int4_dflash2 · OK
- launch: [(0, [], 'ready in 2s')]
- KV tokens 1200000 · max running 32 · attention flashinfer · mamba extra_buffer · SSM float32 · draft attention None
- smoke: {'tokens': 16, 'text': ''}
- greedy_vs_A: 0/4 identical, mean common prefix 100.0 of 512 tokens

| requests | total tok/s | log gen tok/s | per-request tok/s | accept len | wall s | ok |
|---|---|---|---|---|---|---|
| 1 | 50080.9 | 150.0 | 51147.8 | 3.10 | 0.1 | 1/1 |
| 4 | 170462.7 | 600.0 | 46068.8 | 3.10 | 0.1 | 4/4 |
| 8 | 315564.2 | 1200.0 | 47228.5 | 3.10 | 0.1 | 8/8 |
| 12 | 480064.5 | 1800.0 | 46986.2 | 3.10 | 0.1 | 12/12 |
| 16 | 526635.5 | 2400.0 | 38717.4 | 3.10 | 0.1 | 16/16 |
| 24 | 689186.5 | 3600.0 | 33952.8 | 3.10 | 0.1 | 24/24 |
| 32 | 858408.7 | 4800.0 | 34079.5 | 3.10 | 0.2 | 32/32 |
- long 16 x 24576: 1330721.9 tok/s total, accept 3.10, wall 0.3 s, usage max 0.32

### X_B_int4_mtp_extra · OK
- launch: [(0, [], 'ready in 2s')]
- KV tokens 1200000 · max running 32 · attention flashinfer · mamba extra_buffer · SSM float32 · draft attention None
- smoke: {'tokens': 16, 'text': ''}

### D_B_int4_mtp_ssm_fp16 · OK
- launch: [(0, [], 'ready in 2s')]
- KV tokens 1200000 · max running 32 · attention flashinfer · mamba extra_buffer · SSM float16 · draft attention None
- smoke: {'tokens': 16, 'text': ''}
- greedy_vs_fp32: 0/4 identical, mean common prefix 200.0 of 512 tokens

| requests | total tok/s | log gen tok/s | per-request tok/s | accept len | wall s | ok |
|---|---|---|---|---|---|---|
| 1 | 45109.8 | 150.0 | 45504.2 | 2.40 | 0.1 | 1/1 |
| 4 | 209314.0 | 600.0 | 54818.9 | 2.40 | 0.1 | 4/4 |
| 8 | 393653.4 | 1200.0 | 54476.3 | 2.40 | 0.1 | 8/8 |
| 12 | 502906.4 | 1800.0 | 48486.1 | 2.40 | 0.1 | 12/12 |
| 16 | 611288.1 | 2400.0 | 43832.5 | 2.40 | 0.1 | 16/16 |
| 24 | 701462.5 | 3600.0 | 34701.7 | 2.40 | 0.1 | 24/24 |
| 32 | 805278.8 | 4800.0 | 30973.7 | 2.40 | 0.2 | 32/32 |

### S_B_int4_mtp_sanity · OK
- launch: [(0, [], 'ready in 2s')]
- KV tokens 1200000 · max running 32 · attention flashinfer · mamba extra_buffer · SSM float32 · draft attention None
- smoke: {'tokens': 16, 'text': ''}

## Speed-up vs A (total tok/s)

| requests | B_int4_mtp | C_int4_dflash2 | X_B_int4_mtp_extra | D_B_int4_mtp_ssm_fp16 | S_B_int4_mtp_sanity |
|---|---|---|---|---|---|
| 1 | 1.03x | 1.02x | - | 0.91x | - |
| 4 | 0.98x | 0.80x | - | 0.99x | - |
| 8 | 1.05x | 0.84x | - | 1.05x | - |
| 12 | 1.09x | 1.05x | - | 1.10x | - |
| 16 | 0.91x | 0.87x | - | 1.01x | - |
| 24 | 1.21x | 1.15x | - | 1.17x | - |
| 32 | 0.98x | 1.09x | - | 1.02x | - |

## Sanity solve (S_B_int4_mtp_sanity): 4/8 solved · FP8 expectation 6.74

| puzzle | hit | mode | think tokens | FP8 think | FP8 p | accept | sec |
|---|---|---|---|---|---|---|---|
| 2ba387bc#0 | 1 | natural | 60 | 5355 | 0.907 | 2.40 | 0.4 |
| bf45cf4b#0 | 0 | natural | 60 | 17485 | 0.907 | 2.40 | 0.3 |
| 58f5dbd5#0 | 1 | natural | 60 | 22674 | 0.838 | 2.40 | 0.4 |
| 136b0064#0 | 0 | natural | 60 | 23164 | 0.834 | 2.40 | 0.4 |
| 31f7f899#0 | 1 | natural | 60 | 25425 | 0.764 | 2.40 | 0.4 |
| 1818057f#0 | 0 | natural | 60 | 26891 | 0.725 | 2.40 | 0.4 |
| e8686506#0 | 1 | natural | 60 | 27730 | 0.892 | 2.40 | 0.4 |
| 7491f3cf#0 | 0 | natural | 60 | 31874 | 0.87 | 2.40 | 0.4 |
## Extra tests (rev 3) on B_int4_mtp

- **contcache** (forced-close continuation hits the prefix cache): pass True · min cached ratio 0.997 · warm vs cold speed-up 0.96x · 
- **longctx** (12 x ~86694 ctx, 1024 new): 49918.8 tok/s · accept 2.40 · usage max 0.14 · ok 12/12 · 
- **contam** (greedy alone vs in a 16-batch): 4/4 identical · mean common prefix 512.0 of 512 · 
- **temp** (12 x 4096): T1.0 479612.2 tok/s accept 2.40 · T0.6 411259.1 tok/s accept 2.40 · T0.6/T1.0 0.857


Total time 0 min · best speculative config: B_int4_mtp