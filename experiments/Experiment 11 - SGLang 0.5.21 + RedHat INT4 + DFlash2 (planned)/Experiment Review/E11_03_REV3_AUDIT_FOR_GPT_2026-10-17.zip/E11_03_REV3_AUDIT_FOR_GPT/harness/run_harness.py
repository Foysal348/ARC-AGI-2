"""E11-03 CPU harness: builds a fake /kaggle/input, runs every notebook cell in one namespace against the fake SGLang
server, then checks results.json / report.md. usage: python run_harness.py [scenario]
scenarios: main (default) | ladder (first DFLASH launch fails -> triton retry)"""
import json, os, shutil, sys, time
from pathlib import Path

HERE = Path(__file__).resolve().parent
NB = Path(r"D:/ARC AGI 2/experiments/Experiment 11 - SGLang 0.5.21 + RedHat INT4 + DFlash2 (planned)/Experiment Notebooks/"
          r"E11_03_sglang_int4_gpu_validation_on_KAGGLE.ipynb")
DATA = Path(r"D:/ARC AGI 2/experiments/Experiment 10 - Q27-XHIGH Poetiq Code-Verify attempt_2 (planned)/Experiment Review/"
            r"E10_ORDER2_EVAL120_RESULTS_FOR_GPT/data")
scenario = sys.argv[1] if len(sys.argv) > 1 else "main"
RUN = HERE / f"run_{scenario}"
if RUN.exists():
    shutil.rmtree(RUN)
INP, OUT = RUN / "input", RUN / "out"

# ---- fake /kaggle/input
wh = INP / "datasets" / "foysalemonshanto" / "sglang-0-5-21-cu13-wheelhouse"
wh.mkdir(parents=True)
(wh / "BUILD_INFO.json").write_text(json.dumps({"sglang": "0.5.21"}))
(wh / "requirements.lock").write_text("sglang==0.5.21\nflashinfer-jit-cache==0.6.18+cu130\n")
import hashlib
_wheels = {"sglang-0.5.21-py3-none-any.whl": b"sglang",
           "flashinfer_jit_cache-0.6.18+cu130-cp39-abi3-manylinux_2_28_x86_64.whl": b"jit"}
_lines = []
for _n, _c in _wheels.items():   # stored the way Kaggle stores them: '+' dropped from the file name
    (wh / _n.replace("+", "")).write_bytes(b"corrupt" if (scenario == "badsha" and "+" in _n) else _c)
    _lines.append(f"{hashlib.sha256(_c).hexdigest()}  {_n}")
(wh / "SHA256SUMS").write_text("\n".join(_lines) + "\n")
m4 =INP / "models" / "foysalemonshanto" / "qwen3-8-27b-int4-redhat" / "pytorch" / "w4a16-g128" / "1"
m4.mkdir(parents=True)
for f in (HERE / "tok").iterdir():
    shutil.copy(f, m4 / f.name)
(m4 / "model_mtp.safetensors").write_bytes(b"")
df = INP / "models" / "foysalemonshanto" / "qwen3-8-27b-dflash2" / "pytorch" / "bf16" / "1"
df.mkdir(parents=True)
shutil.copy(HERE.parent / "sgl_src" / "dflash2_config.json", df / "config.json")
comp = INP / "competitions" / "arc-prize-2026-arc-agi-2"
comp.mkdir(parents=True)
for f in ("arc-agi_evaluation_challenges.json", "arc-agi_evaluation_solutions.json"):
    shutil.copy(DATA / f, comp / f)
(comp / "arc-agi_test_challenges.json").write_text("{}")

os.environ.update({"E11_HARNESS": "1", "E11_INPUT": str(INP), "E11_OUT": str(OUT), "E11_TIME_BUDGET": "36000",
                   "E11_FAKE_SERVER": str(HERE / "fake_sglang_server.py"),
                   "E11_TOKENIZER_PYTHON": str(HERE / "hvenv" / "Scripts" / "python.exe")})
if scenario == "ladder":
    os.environ["FAKE_FAIL_FIRST_LAUNCH"] = "DFLASH"
if scenario == "bfail":
    os.environ["FAKE_FAIL_ALWAYS"] = "NEXTN"

nb = json.load(open(NB, encoding="utf-8"))
g = {"__name__": "__main__"}
t0 = time.time()
for i, c in enumerate(nb["cells"]):
    if c["cell_type"] != "code":
        continue
    src = "".join(c["source"])
    print(f"\n======== executing notebook cell {i}", flush=True)
    try:
        exec(compile(src, f"<cell {i}>", "exec"), g)
    except SystemExit as e:
        if scenario == "badsha" and "sha256 mismatch" in str(e):
            print("PASS badsha: a corrupted renamed wheel stops the notebook before install:", e)
            print("\nALL CHECKS PASS")
            sys.exit(0)
        raise
if scenario == "badsha":
    print("FAIL badsha: the corrupted wheel was not detected")
    sys.exit(1)
print(f"\nnotebook finished in {time.time() - t0:.0f}s")

# ---- checks
R = json.load(open(OUT / "results.json", encoding="utf-8"))
C = R["configs"]
fails = []


def check(cond, msg):
    print(("PASS " if cond else "FAIL ") + msg)
    if not cond:
        fails.append(msg)


_fixed = "flashinfer_jit_cache-0.6.18+cu130-cp39-abi3-manylinux_2_28_x86_64.whl"
check((OUT / "harness_wheels" / _fixed).exists()
      and R["env"]["shims"]["renamed_wheels"] == [f"{_fixed.replace('+', '')} -> {_fixed}"],
      "Kaggle-renamed wheel restored under its original name (sha256 checked)")
check(R["prompts"]["first_prompt_tail"].endswith("<|im_start|>assistant\n<think>\n"), "prompt ends with the thinking turn")
check(R["prompts"]["template_sha"] != "", "chat template hashed")
for n in ("A_int4", "B_int4_mtp", "C_int4_dflash2"):
    if scenario == "bfail" and n == "B_int4_mtp":
        check(not C[n]["ok"] and len(C[n]["attempts"]) == 2, "bfail: B fails both launches, run continues")
        continue
    check(C[n]["ok"], f"{n} ok")
    check(set(C[n]["sweep"]) == {"1", "4", "8", "12", "16", "24", "32"}, f"{n} sweep has every level (rev 3: 12 added)")
    check(all(C[n]["sweep"][k]["ok"] == int(k) for k in C[n]["sweep"]), f"{n} every request ok")
    check(C[n]["long"]["ok"] == 16 and C[n]["long"]["completion_tokens"] == 16 * 24576, f"{n} long run 16 x 24576")
    check(C[n]["sweep"]["16"]["decode_log"]["n_lines"] >= 16, f"{n} decode log parsed")
    check("--watchdog-timeout" not in C[n]["attempts"][-1]["cmd"], f"{n} unknown optional flag dropped")
    check("--cuda-graph-max-bs-decode 32" in C[n]["attempts"][-1]["cmd"], f"{n} known optional flag kept")
check(scenario == "bfail" or C["B_int4_mtp"]["greedy_vs_A"]["identical"] == 4, "B greedy identical to A (4/4)")
check(C["C_int4_dflash2"]["greedy_vs_A"]["identical"] == 0 and C["C_int4_dflash2"]["greedy_vs_A"]["mean_prefix"] == 100.0,
      "C greedy diverges at token 100")
check((scenario == "bfail" or C["B_int4_mtp"]["sweep"]["16"]["accept_len_mean"] == 2.4) and C["C_int4_dflash2"]["sweep"]["16"]["accept_len_mean"] == 3.1,
      "accept length from meta_info")
check(R["best_spec"] in (("C_int4_dflash2",) if scenario == "bfail" else ("B_int4_mtp", "C_int4_dflash2")), f"best spec chosen: {R['best_spec']}")
dname = f"D_{R['best_spec']}_ssm_fp16"
check(C[dname]["ok"] and C[dname]["greedy_vs_fp32"]["mean_prefix"] == (100.0 if R["best_spec"] == "C_int4_dflash2" else 200.0),
      "D runs and its greedy drift vs fp32 is measured")
check("--mamba-ssm-dtype float16" in C[dname]["attempts"][-1]["cmd"], "D uses float16 SSM")
S = R["sanity"]
check(S["n"] == 8 and S["hits"] == 4, f"sanity 4/8 (fake answers every other puzzle): {S['hits']}/{S['n']}")
check(all(r["mode"] == "natural" and r["grid_parsed"] for r in S["rows"]), "sanity: natural close + parsed grid")
rep = (OUT / "report.md").read_text(encoding="utf-8")
check("## Speed-up vs A" in rep and "## Sanity solve" in rep and "| 32 |" in rep, "report has speed-up + sanity tables")
if scenario == "ladder":
    att = C["C_int4_dflash2"]["attempts"]
    check(len(att) == 2 and not att[0]["ready"] and att[1]["ready"] and att[1]["extra_flags"] == ["--attention-backend", "triton"],
          "ladder: first DFLASH launch fails, triton retry works")
X = R.get("extra") or {}
xc = X.get("config")
check(xc == R["best_spec"] and C.get(f"X_{xc}_extra", {}).get("ok"), f"extra tests ran on the best config: {xc}")
cc = X.get("contcache") or {}
check(cc.get("pass") is True and all(r.get("cached_cold", 0) < 200 for r in cc.get("rows", [])),
      f"contcache: warm continuation hits the cache, cold does not (min ratio {cc.get('cache_ratio_min')})")
lc = X.get("longctx") or {}
check(lc.get("ok") == lc.get("requests") and (lc.get("context_tokens_mean") or 0) > 80000,
      f"longctx: {lc.get('ok')}/{lc.get('requests')} requests at ~{lc.get('context_tokens_mean')} tokens")
ct = X.get("contam") or {}
check(ct.get("identical") == 4, f"contam: greedy alone == greedy inside a batch on the fake server ({ct.get('identical')}/4)")
tp = X.get("temp") or {}
check((tp.get("T1.0") or {}).get("ok") == 12 and (tp.get("T0.6") or {}).get("ok") == 12 and tp.get("speedup_T06_vs_T10"),
      "temp: both temperatures measured")
check("## Extra tests (rev 3)" in rep, "report has the extra-tests section")
print(f"\n{len(fails)} failed checks" if fails else "\nALL CHECKS PASS")
sys.exit(1 if fails else 0)
