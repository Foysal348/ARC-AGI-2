"""Experiment 11 Stage 2: QUICK_SAVE (no run) the GPU validation notebook E11-03 on foysalemonshanto.
The models are private on foysalemonshanto, so the notebook lives there. L4 x4, Internet OFF, pinned Q27 docker image.
Run it from the editor (Save & Run All) only after the user's go. --check-only: account, inputs and quota only.
Credentials: the default ~/.kaggle/kaggle.json (foysalemonshanto), read by the SDK in-process."""
import hashlib, json, sys

from kaggle.api.kaggle_api_extended import KaggleApi
from kagglesdk import KaggleClient
from kagglesdk.kernels.types.kernels_api_service import ApiSaveKernelRequest
from kagglesdk.kernels.types.kernels_enums import KernelExecutionType

NB = (r"D:/ARC AGI 2/experiments/Experiment 11 - SGLang 0.5.21 + RedHat INT4 + DFlash2 (planned)/Experiment Notebooks/"
      r"E11_03_sglang_int4_gpu_validation_on_KAGGLE.ipynb")
SLUG = "foysalemonshanto/e11-03-sglang-int4-gpu-validation"
MODELS = ["foysalemonshanto/qwen3-8-27b-int4-redhat/PyTorch/w4a16-g128/1", "foysalemonshanto/qwen3-8-27b-dflash2/PyTorch/bf16/1"]
DATASET = "foysalemonshanto/sglang-0-5-21-cu13-wheelhouse"
api = KaggleApi(); api.authenticate()
ok = True
owners = sorted({str(getattr(k, "ref", "")).split("/")[0] for k in api.kernels_list(mine=True, page_size=5)})
print("authenticated kernels owner(s):", owners)
if owners and owners != ["foysalemonshanto"]:
    ok = False; print("WRONG ACCOUNT")
for m in MODELS:
    try:
        api.model_instance_get(m.rsplit("/", 1)[0]); print("model OK", m)
    except Exception as e:
        ok = False; print("model ERR", m, repr(e)[:160])
try:
    files = api.dataset_list_files(DATASET)
    names = [f.name for f in (getattr(files, "files", None) or [])]
    print("dataset OK", DATASET, len(names), "files | BUILD_INFO.json" if "BUILD_INFO.json" in names else "| no BUILD_INFO.json?")
except Exception as e:
    ok = False; print("dataset ERR", DATASET, repr(e)[:160])
try:
    q = api.quota_view().gpu_quota
    print("gpu quota used h", round(q.time_used.total_seconds() / 3600, 2), "of", round(q.total_time_allowed.total_seconds() / 3600, 2))
except Exception as e:
    print("quota ERR", repr(e)[:120])
text = open(NB, encoding="utf-8").read(); json.loads(text)
print("notebook sha256(file)", hashlib.sha256(open(NB, "rb").read()).hexdigest()[:12])
if not ok or "--check-only" in sys.argv:
    sys.exit(0 if ok else 1)
r = ApiSaveKernelRequest()
r.slug = SLUG
r.new_title = "E11 03 SGLang INT4 GPU Validation"
r.text = text; r.language = "python"; r.kernel_type = "notebook"
r.is_private = True; r.enable_gpu = True; r.enable_tpu = False; r.enable_internet = False
r.machine_shape = "NvidiaL4"
r.model_data_sources = MODELS
r.dataset_data_sources = [DATASET]
r.kernel_data_sources = []
r.competition_data_sources = ["arc-prize-2026-arc-agi-2"]
r.docker_image = "gcr.io/kaggle-private-byod/python@sha256:37c64f7dd9c54116ecd1bcc88817c5469b88387388fade02bfa8bf3fc647d461"
r.docker_image_pinning_type = "original"
r.kernel_execution_type = KernelExecutionType.QUICK_SAVE
with KaggleClient() as cl:
    resp = cl.kernels.kernels_api_client.save_kernel(r)
print("saved:", r.slug, "version", getattr(resp, "version_number", None), "url", getattr(resp, "url", None),
      "error", getattr(resp, "error", None))
