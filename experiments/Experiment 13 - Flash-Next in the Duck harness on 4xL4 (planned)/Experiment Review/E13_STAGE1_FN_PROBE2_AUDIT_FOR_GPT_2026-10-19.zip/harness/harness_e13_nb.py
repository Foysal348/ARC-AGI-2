"""CPU harness for the E13 probe notebook: runs the REAL notebook cells against fake inputs and fake_e13_server.py.
usage: <e13_venv python> harness_e13_nb.py <notebook> <scenario>    scenarios: ok | garbage | loadfail | oom | parser
'parser' runs e13_gate.memory_gate on the REAL E3 and E12 server logs (regression for the log patterns)."""
import json
import os
import shutil
import socket
import sys
import time
from pathlib import Path

NB, SCEN = sys.argv[1], sys.argv[2]
HERE = Path(__file__).resolve().parent
sys.stdout.reconfigure(encoding="utf-8")
ROOT = HERE / "runs"; ROOT.mkdir(exist_ok=True)
WORK = ROOT / f"{SCEN}_{time.strftime('%H%M%S')}"; WORK.mkdir()

if SCEN == "parser":
    sys.path.insert(0, str(Path(NB).parent / "Build" / "e13_scripts"))
    import e13_gate
    L3 = Path(r"D:/ARC AGI 2/experiments/Experiment 3 - Flash-Next Feasibility (FN)/Experiment Results/Kaggle Runs/FN_PROBE_v421_run1/fn_smoke/serve.log")
    L12 = Path(r"D:/ARC AGI 2/experiments/Experiment 12 - Duck REPL agent for ARC-AGI-2 (planned)/Experiment Results/Kaggle Runs/E12 SGLang EVAL30 run1 (hosen42, 2026-10-19)/q27x/sglang_server_try0.log")
    g3 = e13_gate.memory_gate(L3.read_text(encoding="utf-8", errors="replace"))
    g12 = e13_gate.memory_gate(L12.read_text(encoding="utf-8", errors="replace"))
    print("E3 :", {k: g3[k] for k in ("post_weight_avail_gb", "weight_gb", "kv_dtype", "kv_tokens", "kv_gb", "mamba_cache_size", "post_graph_avail_gb", "graph_mem_gb", "oom")})
    print("E12:", {k: g12[k] for k in ("post_weight_avail_gb", "weight_gb", "kv_dtype", "kv_tokens", "kv_gb", "mamba_cache_size", "post_graph_avail_gb", "graph_mem_gb", "capped_running")})
    assert g3["post_weight_avail_gb"] == 2.55 and g3["weight_gb"] == 19.06 and g3["kv_tokens"] == 118080 and g3["mamba_cache_size"] == 10
    assert g12["post_weight_avail_gb"] == 17.10 and g12["kv_tokens"] == 866744 and g12["kv_dtype"] == "torch.float8_e4m3fn"
    assert g12["graph_mem_gb"] and g12["post_graph_avail_gb"] is not None
    print("PARSER OK"); sys.exit(0)

# ---- fake Kaggle inputs (names follow the real mounts so the notebook's globs are exercised)
INP = WORK / "input"
wh = INP / "datasets/foysalemonshanto/sglang-0-5-21-cu13-wheelhouse"; wh.mkdir(parents=True)
(wh / "SHA256SUMS").write_text(""); (wh / "requirements.lock").write_text("")
fa = INP / "datasets/hosen42/flash-attn-2-8-3-post1-cu13-torch2-13-cp312"; fa.mkdir(parents=True)
(fa / "SHA256SUMS_AND_SOURCE.txt").write_text("harness")
md = INP / "models/dfranzen/intel-qwen3.8-flash-next-w4a16-autoround/transformers/default/1"; md.mkdir(parents=True)
json.dump({"architectures": ["Qwen4ExpForConditionalGeneration"],
           "quantization_config": {"quant_method": "auto-round", "bits": 4, "group_size": 128, "sym": True},
           "text_config": {"indexer_budget": 2048, "indexer_compress_ratio": 4, "num_key_value_heads": 2,
                           "moe_intermediate_size": 640, "num_experts": 512}}, open(md / "config.json", "w"))
(md / "chat_template.jinja").write_text("{{ messages }}")
(md / "model-ple-00001-of-00022.safetensors").write_bytes(b"\0" * 4096)
(INP / "models/dfranzen/albucino-qwen3-8-flash-next-drafter/transformers/default/1").mkdir(parents=True)
(INP / "datasets/dfranzen/pennyroyal-v253").mkdir(parents=True)
ARC = WORK / "arc"; ARC.mkdir()
FIX = Path(r"D:/ARC AGI 2/_scratch/session_1c6db7aa/e12_harness/fixtures")
src = next(FIX.rglob("arc-agi_evaluation_challenges.json"))
ch = json.load(open(src))
json.dump({t: {"train": ch[t]["train"], "test": [{"input": q["input"]} for q in ch[t]["test"]]} for t in list(ch)[:3]},
          open(ARC / "arc-agi_test_challenges.json", "w"))
with socket.socket() as s:
    s.bind(("127.0.0.1", 0)); PORT = s.getsockname()[1]
os.environ.update(E13_HARNESS="1", E13_FAKE_SERVER=str(HERE / "fake_e13_server.py"), E13_PORT=str(PORT),
                  Q27X_ARC_ROOT=str(ARC), Q27X_WORKING=str(WORK / "working"), E13_INPUT_ROOT=str(INP), FAKE_SCEN=SCEN,
                  E13_HARD_STOP_SEC=str(3 * 3600), PYTHONIOENCODING="utf-8")

nb = json.load(open(NB, encoding="utf-8"))
code = ["".join(c["source"]) for c in nb["cells"] if c["cell_type"] == "code"]
assert len(code) == 6, len(code)
G = {"__name__": "__main__"}
t0 = time.time()
for i, c in enumerate(code):
    if i == 4:                       # harness only: short budgets so the fake run is quick
        G["READY_CAP_SEC"], G["READY_STALL_SEC"] = 120, 60
    exec(compile(c, f"<cell{i}>", "exec"), G)
R = json.load(open(WORK / "working" / "e13" / "e13_probe_report.json"))
st = {k: v["ok"] for k, v in R["stages"].items()}
print("\nSTAGES", st)
print("DECISION", json.dumps(R["decision"], default=str)[:1500])
L = R["launches"]
print("LAUNCHES", [(x["cfg"]["tag"], x.get("ready"), x.get("gate_c", {}).get("pass"), x.get("gate_c", {}).get("signature")) for x in L])
mic = R["decision"].get("micro", {})
topk = json.load(open(WORK / "working" / "e13" / "mp_topk.json"))
dec = json.load(open(WORK / "working" / "e13" / "mp_decode.json"))
print("TOPK selftest: good impl fails", topk["t1"]["summary"]["fail_cases"], "/", topk["t1"]["summary"]["total_cases"],
      "| broken impl fails", topk["t2"]["summary"]["fail_cases"], "/", topk["t2"]["summary"]["total_cases"])
print("DECODE selftest: reference pass", dec["fa2"]["pass"], "| wrong-causal impl pass", dec["p1"]["pass"], "fails", dec["p1"]["fails"])
assert topk["t1"]["summary"]["fail_cases"] == 0 and topk["t2"]["summary"]["fail_cases"] == topk["t2"]["summary"]["total_cases"]
assert dec["fa2"]["pass"] is True and dec["p1"]["pass"] is False
assert st["0_inputs"] and st["1_install"] and st["2_fa2_and_patch3"] and st["3_static_asserts"] and st["4_micro_preflight"]
if SCEN == "ok":
    assert st["5_launch1"] and L[0]["gate_c"]["pass"] and L[0].get("speed_16k"), "ok: launch 1 gate"
    assert R["decision"]["launch2"]["kind"] in ("nextn_on", "chunk_4096", "none")
    fl = L[0]["flags"]; assert fl[fl.index("--chunked-prefill-size") + 1] == "2048" and "--speculative-algorithm" not in fl
    assert fl[fl.index("--max-mamba-cache-size") + 1] == "40" and fl[fl.index("--mem-fraction-static") + 1] == "0.93"
elif SCEN == "garbage":
    assert not st["5_launch1"] and L[0]["gate_c"]["signature"] == "decode_wrong"
    assert R["decision"]["launch2"]["kind"] == "b2_diagnostic" and len(L) == 2
    assert "--disable-cuda-graph" in L[1]["flags"] and L[1]["cfg"]["tilelang_off"] is True
elif SCEN == "loadfail":
    assert L[0]["ready"] is False and R["decision"]["launch2"]["kind"] == "stop" and len(L) == 1
elif SCEN == "oom":
    assert L[0]["gate_c"]["signature"] == "oom_or_cuda_error" and R["decision"]["launch2"]["kind"] == "stop" and len(L) == 1
print(f"\nHARNESS {SCEN}: PASS in {time.time() - t0:.0f}s")
