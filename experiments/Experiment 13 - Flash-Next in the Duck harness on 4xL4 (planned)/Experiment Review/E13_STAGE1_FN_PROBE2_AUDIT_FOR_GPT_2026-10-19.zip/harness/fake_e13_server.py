"""Fake SGLang 0.5.21 Flash-Next server for the E13 probe-notebook harness (CPU, no model; our test code only).

Launched by the REAL CELL 4 with the REAL flags. It refuses to start unless every Franzen-verbatim flag and every E13 delta
(D4 TP4+EP4, D5 triton, fp8 KV, page 64, extra_buffer + track 64, prefetch, parsers, preserve_thinking) is present and no
banned flag (--gdn-mtp-cache-mode, --language-model-only) is. It prints SGLang-format memory lines (TP0) with SIMULATED values
(parser test only), and answers the Gate C requests: counting, logprobs, grid echo, the pass-code marker, the python tool call
and the second turn. FAKE_SCEN: ok | garbage ("!!!!", the E3 symptom) | loadfail | oom | slowready.
"""
import json
import os
import re
import sys
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

argv = sys.argv[1:]
SCEN = os.environ.get("FAKE_SCEN", "ok")
PORT = int(argv[argv.index("--port") + 1])
REQ = [["--tensor-parallel-size", "4"], ["--ep-size", "4"], ["--quantization", "auto-round"], ["--kv-cache-dtype", "fp8_e4m3"],
       ["--page-size", "64"], ["--mamba-radix-cache-strategy", "extra_buffer"], ["--mamba-track-interval", "64"],
       ["--mamba-backend", "triton"], ["--linear-attn-decode-backend", "triton"], ["--linear-attn-prefill-backend", "triton"],
       ["--moe-runner-backend", "auto"], ["--ple-offload-embedding"], ["--reasoning-parser", "qwen3"],
       ["--tool-call-parser", "qwen3_coder"], ["--default-chat-template-kwargs", json.dumps({"preserve_thinking": True})],
       ["--schedule-policy", "lpm"], ["--weight-loader-prefetch-checkpoints"], ["--weight-loader-drop-cache-after-load"],
       ["--dtype", "bfloat16"], ["--context-length", "139264"], ["--mamba-ssm-dtype", "bfloat16"], ["--served-model-name", "flashnext"]]
for r in REQ:
    i = argv.index(r[0]) if r[0] in argv else -1
    if i < 0 or (len(r) == 2 and argv[i + 1] != r[1]):
        print(f"ValueError: E13 harness: missing / wrong flag {r}", flush=True); sys.exit(2)
for bad in ("--gdn-mtp-cache-mode", "--language-model-only"):
    if bad in argv:
        print(f"ValueError: E13 harness: banned flag {bad}", flush=True); sys.exit(2)
env_need = {"PYTORCH_CUDA_ALLOC_CONF": "expandable_segments:True", "TORCH_CUDA_ARCH_LIST": "8.9"}
for k, v in env_need.items():
    if os.environ.get(k) != v:
        print(f"ValueError: E13 harness: env {k} != {v}", flush=True); sys.exit(2)
print("server_args=" + json.dumps({"argv": argv, "decode_env": os.environ.get("E13_SM89_TRITON_DECODE"),
                                   "tilelang_off": os.environ.get("E13_DISABLE_TILELANG")}), flush=True)
if SCEN == "loadfail":
    print("[2026-10-19 TP0] Scheduler hit an exception: RuntimeError: Invalid thread config for marlin", flush=True); sys.exit(1)
running = int(argv[argv.index("--max-running-requests") + 1])
mamba = int(argv[argv.index("--max-mamba-cache-size") + 1])
print("[2026-10-19 TP0] Load weight end. type=Qwen4ExpForConditionalGeneration, dtype=torch.bfloat16, avail mem=2.55 GB, mem usage=19.06 GB.", flush=True)
print(f"[2026-10-19 TP0] Mamba Cache is allocated. max_mamba_cache_size: {mamba}, conv_state size: 0.02GB, ssm_state size: 0.62GB", flush=True)
print("[2026-10-19 TP0] KV Cache is allocated. dtype: torch.float8_e4m3fn, #tokens: 180224, K size: 0.53 GB, V size: 0.53 GB", flush=True)
print("[2026-10-19 TP0] Capture decode CUDA graph end. elapsed=30.10 s, mem usage=0.41 GB, avail mem=1.52 GB.", flush=True)
time.sleep(2 if SCEN != "slowready" else 8)
T_READY = time.time()
START = time.time()


def tok(text):
    return max(1, len(text) // 4)


def reply_text(text, max_new):
    if SCEN == "garbage":
        return "!" * max_new
    m = re.search(r"pass code is (ZK-\d+)\.", text)
    if m and text.rstrip().endswith("The pass code is"):
        return f" {m.group(1)}."
    if text.endswith("Output:\n"):
        blocks = text.split("Input:\n")
        return blocks[-1].split("\nOutput:\n")[0] + "\n\n"
    m = re.search(r"(\d+),$", text.strip())
    if m and text.strip().count(",") >= 5:
        n = int(m.group(1))
        return " " + ", ".join(str(n + i) for i in range(1, 30))
    return " ".join(f"tok{i}" for i in range(max_new))


class H(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):
        pass

    def _send(self, obj, code=200):
        b = json.dumps(obj).encode()
        self.send_response(code); self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(b))); self.send_header("Connection", "close"); self.end_headers()
        self.close_connection = True; self.wfile.write(b)

    def do_GET(self):
        if self.path == "/health":
            return self._send({}, 200 if time.time() >= T_READY else 503)
        return self._send({}, 404)

    def do_POST(self):
        body = json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))) or b"{}")
        if SCEN == "oom" and time.time() - START > 1:
            print("[2026-10-19 TP0] torch.OutOfMemoryError: CUDA out of memory. Tried to allocate 1.2 GiB", flush=True)
            return self._send({"error": "CUDA out of memory"}, 500)
        if self.path == "/generate":
            sp = body.get("sampling_params") or {}
            n = int(sp.get("max_new_tokens", 16)); text = body.get("text", "")
            out = reply_text(text, n)
            ids = [1000 + (i % 50) for i in range(n)]
            meta = {"prompt_tokens": tok(text), "completion_tokens": n if sp.get("ignore_eos") else min(n, tok(out)),
                    "finish_reason": {"type": "length"}}
            if body.get("return_logprob"):
                meta["input_token_logprobs"] = [[None if i == 0 else -0.02, 500 + i, None] for i in range(tok(text))]
                meta["output_token_logprobs"] = [[-0.01, x, None] for x in ids]
            if sp.get("ignore_eos"):
                time.sleep(min(2.0, n / 400))
            return self._send({"text": out, "meta_info": meta})
        if self.path == "/v1/chat/completions":
            if body.get("model") != "flashnext":
                return self._send({"error": "model not found"}, 404)
            msgs = body.get("messages") or []
            if not any(m.get("role") == "tool" for m in msgs):
                msg = {"role": "assistant", "content": None, "reasoning_content": "I should call python.",
                       "tool_calls": [{"id": "call_1", "type": "function",
                                       "function": {"name": "python", "arguments": json.dumps({"code": "print(123456789*987654321)"})}}]}
                fin = "tool_calls"
            else:
                msg = {"role": "assistant", "content": "The result is 121932631112635269.", "reasoning_content": "It printed it."}
                fin = "stop"
            if SCEN == "garbage":
                msg = {"role": "assistant", "content": "!!!!!!!!!!!!", "reasoning_content": ""}; fin = "length"
            return self._send({"choices": [{"index": 0, "message": msg, "finish_reason": fin}],
                               "usage": {"prompt_tokens": 300, "completion_tokens": 40, "prompt_tokens_details": {"cached_tokens": 200}}})
        return self._send({}, 404)


srv = ThreadingHTTPServer(("127.0.0.1", PORT), H)
srv.daemon_threads = True
print(f"[2026-10-19] fake E13 server on {PORT}", flush=True)
srv.serve_forever()
