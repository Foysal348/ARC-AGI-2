# Qwen3.8-Flash-Next on Kaggle 4xL4: find the root cause of the NaN output and the right fix

**Ask:**
1. Find the most likely root cause of the NaN in SGLang 0.5.21, using the evidence and source in this zip.
2. Propose the exact fix. Rank the candidates if there are several, and for each name the file, the function and the code change.
3. Design the cheapest GPU check that proves the cause: one short (~30 min) commit on 4xL4.
4. Say whether vLLM 0.32.0 (its native `qwen4_exp` code, which is separate) is likely to avoid the bug on sm_89, and what to watch for there.

Please base every claim on the files here. Mark guesses as guesses.

## Setup

**Hardware:** Kaggle 4x NVIDIA L4 (Ada, sm_89, 24 GB each, PCIe only, no NVLink, no internet at run time). The image is a pinned Kaggle docker image with Python 3.12.

**Model:** `dfranzen/intel-qwen3.8-flash-next-w4a16-autoround`, a Kaggle copy of HF `Intel/Qwen3.8-Flash-Next-W4A16-AutoRound`.
- 125B-A5B MoE: 48 layers, 512 experts, top-10, hidden 2560.
- Layer types: GDN linear attention, with QSA sparse full attention every 4th layer.
- Hyper-connections: hc_count 4.
- PLE (n-gram embedding) at `ple_layer_ids = [2]`, which is 1-based, i.e. layer index 1. The PLE table is 102.4 GB in bf16.
- Quantization: the routed experts are int4, group 128, sym, `auto_round:auto_gptq`. Everything else (attention, shared experts, gates, hyper-connections, PLE, MTP, indexer) is bf16; see `model_config/quantization_config.json` and `README.md`.

**Engine:** SGLang 0.5.21, offline wheelhouse; `server_args` are in the logs. The settings that matter:
- `--tp 4`, `ep_size 4`, `moe_a2a_backend none`, `moe_runner_backend auto`; the MoE resolves to `GPTQMarlinMoEMethod`.
- `quantization auto-round`, `kv_cache_dtype fp8_e4m3`, `attention_backend flashinfer`, `mamba_backend triton`.
- `ple_offload_embedding True`, `ple_offload_backend pinned`: about 23.84 GiB of host tensor per rank.
- `max_mamba_cache_size 20`, `mamba_radix_cache_strategy extra_buffer`.
- NaN arm only: `--disable-cuda-graph`.
- Note: `mamba_ssm_dtype` is `bfloat16` in SGLang but `float32` in the config.

**Symptom:** every request returns `!!!!...` (token id 0) from the first token on, in every configuration tried:
- KV dtype, FA2 and CUDA graphs on or off;
- an older SGLang 0.5.19 build with an FP8 PLE overlay (E3, 2026-10-10).

Load: the weights fit at 19.10 GB per rank. With the gc fix, the earlier Marlin-repack OOM was a delayed free; see `results/E13_LOADPROBE_GPU_run1_2026-10-27.md`.

## New evidence (NANPROBE rev 2, 2026-10-30; `results/E13_NANPROBE_rev2_GPU_run1_2026-10-30.md`)

**How the probe works:** per-module forward pre and post hooks plus an instance-forward wrapper, for 120 forwards in eager mode. It records:
- the first non-finite module output;
- whether that module's own float inputs were already non-finite (`inputs_bad`);
- the last clean module;
- per decoder layer [min, max];
- logits stats;
- the QSA indexer int outputs.

There were 0 hook errors. The source is `notebook_build/e13_scripts/mp_nanprobe.py`. The raw per-rank traces are in `run_output/e13_memtrace/`.

**Result, identical on all 4 ranks, on prefill (122 tokens) and on every decode step:**
- The first non-finite output is `model.layers.2.mlp.experts`, a `FusedMoE` using `GPTQMarlinMoEMethod`:
  - `inputs_bad = false`, so its float inputs were finite;
  - the previous clean module is `model.layers.2.mlp.topk`;
  - the outputs of `model.layers.2.mlp` and `model.layers.2` are then non-finite.
- `model.layers.0` and `.1` outputs are finite: prefill [-1.24, 1.50], decode [-0.33, 0.32]. Layers 2-47 are non-finite, and the logits are all NaN.
- Layers 0 and 1 run the same `GPTQMarlinMoEMethod` without a NaN.
- There is no constant/zero collapse and no \|x\| > 1e4 before the NaN.
- QSA indexer outputs look plausible: min -1 (padding), max = seq_len - 1.
- The count prompt was re-run after the hook window and gave the same `!!!!`.
- The weight post-processing trace (`pwal` events) shows every `model.layers.N.mlp.experts` repack with the same +324,403,200 bytes. One `gc.collect()` ran.

**What is special about layer 2:** the PLE block sits in decoder layer index 1 (`layer_id + 1 in ple_layer_ids`).
- The PLE output is added to `hidden_states` before layer 1's attention; see `sglang_0_5_21_src/srt/models/qwen4_exp.py` around L1379-1392.
- Its rows are gathered from pinned host memory via UVA on a side stream (`start_prefetch`, L1159-1194). The prefetch for layer i+1 is started before layer i runs (L1756-1761).
- So the side-stream gather for the PLE of layer 1 overlaps layer 0, and its consumer is layer 1.
- Layer 2's MoE is the first MoE after the PLE layer.
- The routed-expert quantization of layer 2 is identical to every other layer (`extra_config` differs between layers 1 and 2 only by `layers.1.ple.key_proj` / `value_proj`).

Open questions (my guesses, UNVERIFIED):
1. Layer-2 expert weights or scales corrupted on the device after loading, for example by buffer reuse across streams, the delayed-free repack, or the PLE reshard. We never scanned the weights.
2. A Marlin MoE workspace / `sorted_token_ids` / `expert_map` problem under EP4 without a2a, for which layer 2 is somehow the first trigger.
3. PLE-related memory aliasing: the `_eager_prefetch_buffer`, `record_stream` only on `lookup_ids`, the output buffer not recorded on the side stream.
4. Something in the hyper-connection mix of layer 2 that the hooks treat as finite input but that the experts read wrongly (layout or stride, e.g. a non-contiguous view into the hc-widened tensor).

## Capacity facts (arm `kv_lean`, mem-fraction 0.95, CUDA graphs on)

- KV: 161,984 fp8 tokens (94,528 at mem 0.93). Free after graphs: 0.62 GB.
- Mamba: 20 slots = 4 running (extra_buffer + overlap = 5 slots per request). The capacity gate is OK.
- 4 concurrent 20k-token prompts ran: no OOM and the server stayed alive.

## vLLM 0.32.0 alternative (source in `vllm_0_32_0_qwen4_exp_src/`)

- It natively registers `Qwen4ExpForConditionalGeneration` / `Qwen4ExpMTP`; checked on the GPU in this run, `run_output/e13_loadprobe.json` → `vllm_registry`.
- Its code path differs from SGLang:
  - INC W4A16 MoE → `AutoGPTQMoEMethod` (Marlin);
  - QSA in Triton + FA2 (no TileLang);
  - the PLE table is pinned host via `--engram-config '{"cpu_offload": true}'`, with its own prefetch;
  - sm_90-only fast paths (cute_dsl `hc_down_silu`, `cooperative_topk`, the low-latency GEMM) fall back on sm_89.
- Official eval config: `tests/evals/qwen4_exp/configs/Qwen3.8-Flash-Next-FP8.yaml`.

## Files

| Path | What it is |
|---|---|
| `notebooks/Q27-XHIGH-E13_FLASHNEXT_NANPROBE.ipynb` | The notebook that produced the new evidence (sha 4c11a70b) |
| `notebooks/Q27-XHIGH-E13_FLASHNEXT_LOADPROBE.ipynb` | Previous load / memory probe (sha 107aa182) |
| `notebook_build/build_e13_duck.py`, `notebook_build/e13_scripts/*.py` | Builder and injected scripts (`mp_memtrace.py` + `mp_nanprobe.py` = the sitecustomize hook) |
| `results/*.md` | Reports: SMOKE1 rev 6b (repack OOM), LOADPROBE (`!!!!` + delayed free), NANPROBE rev 2 (this evidence) |
| `run_output/` | NANPROBE run: kernel log, `e13_loadprobe.json`, both SGLang server logs, one rank's NaN trace and one rank's kv_lean trace |
| `model_config/` | Intel checkpoint `config.json`, `quantization_config.json`, `README.md` (from HF) |
| `sglang_0_5_21_src/srt/` | Relevant SGLang 0.5.21 source: `models/qwen4_exp.py`, `qwen4_exp_ple_table.py`, `layers/quantization/auto_round.py`, `gptq/schemes/gptq_moe.py`, QSA, GDN |
| `vllm_0_32_0_qwen4_exp_src/` | vLLM 0.32.0 `vllm/models/qwen4_exp/**`, INC quantization files, `engram.py`, eval config |
