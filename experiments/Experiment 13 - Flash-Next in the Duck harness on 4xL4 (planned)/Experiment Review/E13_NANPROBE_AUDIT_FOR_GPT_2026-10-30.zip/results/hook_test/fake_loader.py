
class _QM:
    def process_weights_after_loading(self, module):
        module.done = True

def _modules_with_quant_method(model):
    for m in model.modules():
        if hasattr(m, "weight") and m is not model:
            yield m, _QM()

class DefaultModelLoader:
    @staticmethod
    def load_weights_only(model, weights, target_device):
        return model
    @staticmethod
    def postprocess_weights(model, target_device):
        for module, qm in _modules_with_quant_method(model):
            qm.process_weights_after_loading(module)
