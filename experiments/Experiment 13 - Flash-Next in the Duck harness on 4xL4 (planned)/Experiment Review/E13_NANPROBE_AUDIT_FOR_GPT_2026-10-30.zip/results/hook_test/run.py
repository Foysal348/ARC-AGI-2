
import torch, json
from torch import nn
from sglang.srt.model_loader import loader as LD
class Layer(nn.Module):
    def __init__(s, bad=False):
        super().__init__(); s.lin = nn.Linear(8, 8); s.bad = bad
    def forward(s, x):
        y = s.lin(x)
        return y * float("nan") if s.bad else y
class Model(nn.Module):
    def __init__(s):
        super().__init__(); s.embed = nn.Linear(8, 8); s.layers = nn.ModuleList([Layer(), Layer(), Layer(bad=True), Layer()])
    def forward(s, x):
        x = s.embed(x)
        for l in s.layers: x = l(x)
        return x
m = Model()
LD.DefaultModelLoader.load_weights_only(m, None, "cpu")
LD.DefaultModelLoader.postprocess_weights(m, "cpu")
for _ in range(3): m(torch.randn(2, 8))
