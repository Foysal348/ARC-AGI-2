# E13 RC1: audit request (Flash-Next layer-2 MoE NaN root cause + Flash-Next on vLLM 0.32)

This notebook was built from your three root-cause audits of `E13_FLASHNEXT_NAN_ROOTCAUSE_FOR_GPT_2026-10-30.zip`. It has not run yet.

**Please audit `notebooks/Q27-XHIGH-E13_FLASHNEXT_RC1.ipynb` (sha bf28715d) before its one GPU commit** on Kaggle 4xL4 (budget ≤ 120 min):

1. **Blockers.** Find anything that would crash, hang, OOM or waste the GPU run. Check:
   - every timeout clamp and deadline;
   - the GPU-free gate between arms;
   - the vLLM install / launch / kill path;
   - the 400 kB commit-size limit (the notebook is 391 kB, its payloads zlib + base64);
   - the effect of the per-module hooks on runtime (only layers 0-3).
2. **Measurement validity.** Will each test actually answer its question?
   - Weight scans (after the repack / after forward 0): is chunking enough to avoid an OOM when only ~0.6-1 GB is free after KV allocation?
   - MoE input capture: integer top-k ids, strides.
   - Fixtures + the CPU GPTQ reference: auto_gptq v1 packing, the zero convention (auto-detect v1 = stored 7 / v2 = stored 8), SiLU-MLP, the EP local vs full sum.
   - PLE mode switch: flag file read per forward, `/flush_cache` and a new prompt per mode. Does `sync` / `skip` really isolate the side-stream prefetch?
   - Layer-2 non-Marlin switch.
3. **vLLM 0.32.0 flags for Flash-Next on 4xL4** (`e13_vllm_flags` in the probe cell):
   - TP4 + `--enable-expert-parallel`, `--enforce-eager`, `--max-model-len 8192`, `--max-num-seqs 4`, `--max-num-batched-tokens 4096`;
   - `--gpu-memory-utilization 0.93` with 19.1 GB of weights per rank;
   - `--engram-config {"cpu_offload": true}`, `--language-model-only`, bf16 KV, `--no-enable-prefix-caching`.
   - Anything missing, wrong or risky (e.g. memory profiling of PLE / QSA caches, the `--language-model-only` support for `Qwen4ExpForConditionalGeneration`)?
   - Is the gc hook (`mp_vllm_gc.py`) correct for vLLM 0.32's `model_loader.utils.process_weights_after_loading`?
4. **Exact fixes.** Give file / function / change for everything you flag. Rank the items: BLOCKER / HIGH / MED / LOW.

## Design (see `review/RC1_FIX_LIST_2026-10-30.md`, items C1-C8)

There are three arms in order. Each has its own deadline and a GPU-free gate. No Duck; the submission is the fallback.

**Arm 1 `rc1`:** SGLang 0.5.21, Intel W4A16 AutoRound, TP4 + EP4, eager, mem 0.93, mamba 20; hooks on `layers.[0-3]` only.
- Weight scan of the experts of layers 0-3 after the repack and after forward 0:
  - float tensors: non-finite count and the local experts that hold them, finite min / max / mean \|x\|;
  - int tensors: sum + position-weighted sum;
  - the expert maps.
- The runtime `gptq_moe` source: sha256 and the patch-#3 marker.
- Every MoE input: dtype, shape, stride, contiguity, min / max, and the -1 count for ints.
- Fixtures for layers 1-2, forwards 0-1, 6 tokens per rank: hidden input, top-k ids and weights, Marlin output, expert map, meta.
- After the server is killed: a CPU reference from the checkpoint's GPTQ weights, compared with the Marlin output. Layer 1 validates the reference. The checkpoint scales of layers 1-2 are scanned too.
- The count prompt under PLE modes orig / sync / skip in the same server: cache flushed, a different prompt per mode, every forward tagged with its mode.

**Arm 2 `vllm_fn`:** vLLM 0.32.0, native `qwen4_exp`, with the flags in item 3 above.
- Checks: count, the 2+2 chat, 4 x 256-token streams (tok/s), and the PLE / INC / KV log lines.
- The gc hook runs after each MoE repack.

**Arm 3 `l2_wna16`:** only with ≥ 22 min left. Arm 1, with layer 2's experts on `apply_gptq_quant_layer(backend="gptq")` (MoeWNA16).

## Local validation (`results/RC1_local_validation_2026-10-30/`)

- **`unit_rc1.py`: 17/17.** It runs the real decoded sitecustomize on a toy model. The model has FusedMoE-shaped experts with a NamedTuple top-k, a NaN scale in expert row 3, a weight changed during forward 0, the fake `qwen4_exp` PLE layer (orig / sync / skip) and the fake `auto_round` switch (on and off).
- **`unit_vllm_gc.py`: OK.** It covers the wrapper, gc and logging on a fake `vllm.model_executor.model_loader.utils`.
- **Harness scenario `rc1`: 13/13.** It runs the real notebook cells against two fakes:
  - a fake SGLang server that writes simulated rc1 records and fixtures;
  - a fake vLLM server that checks the flags and the hook.

  The CPU reference is checked against a tiny real GPTQ checkpoint packed the auto_gptq v1 way: L1 rel err 0.0016, L2 NaN vs a finite reference.
- **Caveats:**
  - The harness cannot test the real SGLang / vLLM behaviour.
  - The packing convention of the test checkpoint was written from vLLM's `pack_rows` / `pack_cols` logic. On the GPU, layer 1 is the real check of the reference.

## Evidence before RC1

`results/E13_NANPROBE_rev2_GPU_run1_2026-10-30.md`:
- The first NaN is in `model.layers.2.mlp.experts` (`GPTQMarlinMoEMethod`) on all ranks, with finite float inputs.
- Layers 0-1 are finite.
- PLE sits at layer index 1 (`ple_layer_ids = [2]`, 1-based).

## Files

| Path | What |
|---|---|
| `notebooks/Q27-XHIGH-E13_FLASHNEXT_RC1.ipynb` | The notebook to audit (sha bf28715d) |
| `notebook_build/build_e13_duck.py` | Builder (`--rc1`); the probe cell source is the `PROBE_SRC` string + the RC1 functions in it |
| `notebook_build/e13_scripts/mp_memtrace.py`, `mp_nanprobe.py`, `mp_rc1.py` | The SGLang server sitecustomize (concatenated in that order) |
| `notebook_build/e13_scripts/mp_vllm_gc.py` | The vLLM server sitecustomize |
| `notebook_build/tests/` | `unit_rc1.py`, `unit_vllm_gc.py`, `patch_harness_rc1.py` (harness scenario + fake SGLang changes), `fake_e13_vllm_server.py` |
| `results/RC1_local_validation_2026-10-30/` | Unit and harness outputs |
| `results/E13_NANPROBE_rev2_GPU_run1_2026-10-30.md` | The GPU evidence RC1 builds on |
| `review/RC1_FIX_LIST_2026-10-30.md` | The fix list from your three audits, with the source checks |
| `push/kernel-metadata.json` | Kaggle push metadata (account hosen42; datasets / models attached) |
| `sglang_0_5_21_src/srt/` | Relevant SGLang 0.5.21 source (`qwen4_exp.py`, PLE table, `auto_round.py`, `gptq_moe.py`, QSA, GDN) |
| `vllm_0_32_0_qwen4_exp_src/` | vLLM 0.32.0 `qwen4_exp/**`, INC quantization, `engram.py`, `model_loader/utils.py`, eval config |
| `model_config/` | The Intel checkpoint's `config.json`, `quantization_config.json`, `README.md` (HF) |
