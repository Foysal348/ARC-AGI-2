# Our earlier Flash-Next work (ARC-AGI-3) and Franzen's stack: review

Read-only, 2026-10-19.

## Main fact

Our ARC-AGI-3 Flash-Next runs (B0, P1_SPARSE) were served by **vLLM with NVFP4 on an RTX PRO 6000**, not SGLang/Pennyroyal. Pennyroyal was Franzen's stack; we used it only in Experiment 3 (4xL4), which failed.

## Model artifacts

| Artifact | Format / size | Use on L4 |
|---|---|---|
| RadixArk/Qwen3.8-Flash-Next-NVFP4 (our B0/P1) | 135 GB, PLE FP8 | NVFP4: no native sm89 path |
| nvidia/Qwen3.8-Flash-Next-NVFP4 (ModelOpt mixed, uploaded as `foysalemonshanto/qwen3-8-flash-next-nvfp4-nvidia`) | 132.7 GB | NVFP4: no |
| Intel/Qwen3.8-Flash-Next-W4A16-AutoRound (Kaggle `dfranzen/intel-qwen3.8-flash-next-w4a16-autoround`) | INT4 g128, 73.6 GB main + BF16 PLE (~102 GB on disk, ~95 GB pinned); linear-attention / indexer / router / embedding weights 16-bit | **loads on 4xL4** (E3) |
| albucino/Qwen3.8-Flash-Next-W4A16-FP8PLE (our overlay `foysalemonshanto/qwen38-flash-next-fp8ple-overlay`) | FP8 PLE 51.2 GB | used in E3 |
| albucino INT4 g32 MTP drafter (`dfranzen/albucino-qwen3-8-flash-next-drafter`) | compressed-tensors | Franzen's NEXTN |

## Serving setups

**Ours, ARC-AGI-3 (vLLM `0.1.dev20073+g8e685d198`, RTX PRO 6000):**
- Settings: TP1, `modelopt_fp4`, max length 32k, KV 5 GiB (105k tokens), max 8 seqs, MTP 3.
- Throughput: about 220-330 tok/s with only about 3 running (KV-starved).
- MTP acceptance fell from 78 % to 54-64 %.

**Franzen (Pennyroyal v2.5.3 = sglang 0.5.19, RTX PRO 6000):**
- Settings: TP1, auto-round, fp8 KV, mem 0.96, ctx 139,264, page 64, 10 running, chunk 8192.
- Mamba / linear attention: extra_buffer, track 64, FlashInfer for mamba and both linear-attention backends, `--gdn-mtp-cache-mode none`, PLE offload, lpm.
- Speculative: NEXTN (3 steps, topk 1, 4 draft tokens), FR-Spec, accept thresholds 1.0.
- Measured on a demo run: P90 decode 836 tok/s aggregate, about 600 tok/s harness-side, prefix reuse 93 %.

## Architecture (`e3/FN_SMOKE_build_config.json`)

- `qwen4_exp`, 48 layers: 36 linear-attention (GDN) and 12 full-attention/QSA (`full_attention_interval` 4).
- Hidden size 2560. Full attention: 24 query heads, 2 KV heads, head_dim 256.
- GDN: 16 key heads and 48 value heads, dim 128.
- MoE: 512 experts, top-10, intermediate 640, plus a shared expert of 640.
- QSA indexer: 4 heads, dim 128, compress ratio 4, budget 2048.
- PLE n-gram table: 47.68 GiB in FP8, about 95 GB in BF16.
- Vocab 248,320; MTP 1 layer.
- Memory per token / request:
  - KV about 24 KiB/token in bf16, 12 KiB in fp8 (all ranks together);
  - recurrent state about 56 MB per request in bf16.

## Problems hit and fixes (4xL4)

| Problem | Fix |
|---|---|
| FlashInfer GDN needs SM90+ | Triton |
| MoE TP split 160 is not a multiple of group 128 | EP4 |
| AutoRound needs MoE runner `auto` | `--moe-runner-backend auto` |
| FA4 crashes on sm89 | our FA2 shim |
| DP attention would replicate the PLE | not used |
| torch `pin_memory` rounds up to a power of two | Pennyroyal's mmap + cudaHostRegister |
| `--language-model-only` is rejected | not used |
| slow weight load | prefetch |
| QSA page 64 | radix off |
| no custom all-reduce on more than 2 PCIe GPUs | none |
| about 7 min of JIT warm-up | none |
| **final blocker: garbage output + TileLang data-race warning** | unresolved |

## Franzen's write-up

- Qwen3.6-27B → Qwen3.8-27B → Flash-Next: "each switch brought a substantial improvement".
- NVFP4 vs W4A16: "similar quality and throughput"; W4A16 leaves more VRAM for KV.
- Removing preserved thinking causes a large regression.
- He gives no numeric speed comparison against the 27B.
