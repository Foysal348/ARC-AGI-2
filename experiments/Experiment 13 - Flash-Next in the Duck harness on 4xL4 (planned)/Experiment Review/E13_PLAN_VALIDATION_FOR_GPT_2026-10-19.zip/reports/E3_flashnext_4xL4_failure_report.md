# Experiment 3 (Flash-Next on 4xL4): what was run, how each run failed, and what to change

Read-only review, 2026-10-19. Sources are in `e3/` in this zip; the originals are in `experiments/Experiment 3 - Flash-Next Feasibility (FN)/`.

## Stack shared by every run

- **Model:** a symlink merge, `/tmp/fn_model`:
  - 15 main shards from `dfranzen/intel-qwen3.8-flash-next-w4a16-autoround` (auto-round, 4 bit, group 128);
  - 10 FP8 PLE shards plus config/index from `foysalemonshanto/qwen38-flash-next-fp8ple-overlay` (a copy of HF `albucino/Qwen3.8-Flash-Next-W4A16-FP8PLE@c6af9fe`);
  - the MTP tensors left out.
- **Engine:** Pennyroyal `sglang-0.5.19+gd00d88efc8d6` (dataset `dfranzen/pennyroyal-v253`), installed offline with uv into `/tmp/sgl-intel/venv`.
  - torch 2.13.0+cu130, CUDA 13.0, triton 3.7.1, nccl 2.29.7, Python 3.12.13, driver 580.178.04.
- **Env:** `TORCH_CUDA_ARCH_LIST=8.9`; all SM120 env vars 0; `SGLANG_MAMBA_CONV_DTYPE=bfloat16`; `SGLANG_ALLOW_OVERWRITE_LONGER_CONTEXT_LEN=1`; CUDA_HOME = pip `nvidia/cu13`; g++-11.
- **Common flags:**
  - parallelism / model: `--tp 4 --ep-size 4 --quantization auto-round --dtype bfloat16 --kv-cache-dtype auto` (bf16 KV), `--page-size 64`;
  - mamba / PLE / graphs: `--mamba-ssm-dtype bfloat16 --ple-offload-embedding --disable-cuda-graph`;
  - backends: `triton` for mamba and both linear-attention backends;
  - `--reasoning-parser qwen3`, no speculative decoding.

## Run by run

**FN-SMOKE v3:**
- Both launches failed in 15 s: `ValueError: --language-model-only does not support ['Qwen4ExpForConditionalGeneration']`.

**v3.1** (not run):
- Found that QSA forces page 64 while mamba `no_buffer` asserts page 1.
- Added `extra_buffer --mamba-track-interval 64` and a radix-off variant.

**v3.2:**
- Settings: radix off, triton attention, **triton MoE**.
- Died about 70 s into the load: `gptq_kernels.py:360 create_moe_runner: assert get_moe_runner_backend().is_auto()`.

**v3.3 (MoE auto):**
- Weights loaded in 258-402 s; KV about 15-20k tokens.
- Both attempts crashed on the server's warm-up decode inside FA4 CuTe: `qwen_sparse_attn_backend.py:1950 _forward_paged_attention → flash_attn/cute ... FlashAttentionForwardSm80 → MLIRError: unable to compute crd2idx`.
- The TileLang data-race warning was already at serve.log:289.

**FN-PROBE v4:**
- Added a PyTorch "FA2" shim patched into `qwen_sparse_attn_backend`.
- Both launches hit the 1080 s wait while still loading: the input disk was slow (0.29 GB/s).

**v4.1 / v4.2:** harness and review only.

**v4.2.1** (+ `--weight-loader-prefetch-checkpoints`):
- The server came up, but the sanity check produced garbage (details below).

## The v4.2.1 run in detail

- **Load:**
  - weights 344.8 s;
  - 19.06 GB/rank of weights;
  - KV pool 118,080 tokens (K 0.68 + V 0.68 GB per rank, bf16);
  - mamba cache 10 slots.
- **Memory:** 0.97 GB free after the pool; 0.66 GiB free after warm-up. nvidia-smi showed 21891 / 23034 MiB on all 4 GPUs.
- **Warm-up:** the server's own warm-up request took about 7.4 min. /health was ready at 862 s.
- **Kernels:**
  - GDN: `TritonGDNKernel`.
  - MoE: `GPTQMarlinMoEMethod`.
  - QSA prefill: Triton `_sparse_gqa_prefill` / `_qsa_prefill_all_visible_indices_kernel`.
  - QSA decode: the paged fallback calling our PyTorch shim.
  - A TileLang JIT kernel on 4 ranks: ``Data race detected: `Logits(bx, position)` is written by multiple threads in loop (token,)`` (probably the QSA indexer / top-k scorer).
  - CustomAllReduce disabled (more than 2 PCIe GPUs).
- **Garbage:**
  - prompt "Reply with the numbers 1 to 20" at temperature 0, thinking off, max 96;
  - the reply was 96 "!" characters in 17.8 s.
- **Speed:**
  - the log line `Decode batch, #running-req: 1 ... cuda graph: False, gen throughput (token/s): 5.95` (eager, single stream, PyTorch shim);
  - the calibrated concurrency and CUDA-graph stages never ran.

## Root causes and pitfalls, with a rule for next time

1. `--language-model-only` is rejected for Qwen4Exp: never pass it.
2. QSA page 64 needs `extra_buffer` + track 64, or radix off.
3. Mamba slots: the request limit is `max_mamba_cache_size // ratio` (ratio 5 with extra_buffer, 1 with radix off), and a 0 raises only after the load.
4. AutoRound MoE needs runner `auto` (Marlin).
5. EP4, because the TP4 Marlin shards are 160 wide and 160 is not a multiple of group 128.
6. Memlock is only 8 MiB, but a 1 GiB `cudaHostRegister` works: keep the pin probe.
7. FA4 CuTe crashes in the QSA decode fallback on sm89; `--attention-backend triton` does not avoid it (SGLang PR #36968).
8. The input disk is 2-3x slower on some days: always use prefetch, hash headers only, and a progress-based wait.
9. mf 0.96 left 0.66 GiB free, so expect OOM under load.
10. JIT warm-up takes about 7 min.
11. Log token ids, logprobs and NaN checks so a garbage output can be diagnosed.
12. Keep the process-group kill, the port gate, and counting /health only while the launcher is alive.
13. Pennyroyal warns: "TP=4: TP>1 on this consumer-PCIe image is experimental and not yet hardware-qualified".

## Open questions never answered

The cause of the garbage was never isolated. Candidates:
- our shim (its maths was re-checked 2026-10-19 and looks correct);
- the TileLang indexer data race;
- Marlin + EP4 on sm89;
- the FP8 PLE overlay and its `weight_scale`;
- the bf16 SSM state;
- TP4 over PCIe.

Also unknown: whether prefill was correct, and the real throughput with CUDA graphs at 8-16 concurrency.

## Weight sizes

- Intel W4A16 main: 15 shards, 73.58 GB.
- FP8 PLE overlay: 51.22 GB, 47.68 GiB pinned in host RAM.
- The BF16 PLE variant: about 102 GB on disk, about 95 GB pinned.
- GPU-resident: 19.06 GB/rank x 4 = 76.2 GB.
- Host RAM 202.6 GB.
