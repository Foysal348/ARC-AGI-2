# Review request: E13, Qwen3.8-Flash-Next in the Duck REPL harness on Kaggle 4x NVIDIA L4 (plan validation + research)

## Context (short)

- **Competition:** Kaggle ARC Prize 2026, ARC-AGI-2.
  - Hardware: 4x L4 (24 GB each, sm89, PCIe, no NVLink), 202.6 GB host RAM.
  - Rules: 12 h, internet off, offline wheels only.
- **Current main lane:** Qwen3.8-27B (INT4 + DFlash2, SGLang 0.5.21) inside the Duck REPL harness.
  - Duck = Tufa Labs' harness, Daniel Franzen's fork `da-fr/arc-agi-3-solution`, adopted verbatim + a small ARC-2 adapter.
- **New, separate lane (E13):** run **Qwen3.8-Flash-Next** in the same Duck harness.
  - The user's principle: **take everything from Franzen's ARC-AGI-3 milestone-2 notebook and change only what 4xL4 makes unavoidable** (minimal change).
  - Reuse our proven work instead of redoing it.
  - The user does not want a loop of guesses.
- **History:** our earlier attempt (Experiment 3, 2026-10-05..11) used Franzen's engine (Pennyroyal 0.5.19) on 4xL4. It loaded, but output garbage ("!!!!") at about 6 tok/s; the cause was never isolated. See `reports/`.

## Your tasks

### A. Validate PLAN.md rev 3 claim by claim

Use `plan/VALIDATION.md`, which has 23 claims with evidence paths. For each:
- say **agree / disagree / unsure**;
- cite the file and line in this zip (or a public URL).

Especially check:
1. **Pennyroyal 0.5.19 cannot decode QSA on sm89 with a minimal change** (claim 4). Look at `pennyroyal_0_5_19_src/.../qwen_sparse_attn_backend.py` `_forward_paged_attention`, and the scratch dtype with fp8 KV. Is there any other existing path in Pennyroyal that avoids FA2/FA4 on sm89?
2. **P1 for 0.5.21** (`sglang_0_5_21_src/.../qwen_sparse_attn_backend.py` around line 1601): is routing CUDA sm89 to the existing `is_hip()` Triton branch (`sparse_gqa_packed_decode_triton`) correct? Check:
   - CUDA graph capture, the fp8 KV path, GQA under TP4 (6 Q heads, 1 KV head per rank), and the NEXTN draft / target-verify rows;
   - the `relative_indices` construction under graph capture.
3. **Franzen patch #3** (GPTQ-Marlin MoE scales `torch.half` → `params_dtype`) on 0.5.21 `gptq/schemes/gptq_moe.py:239,247`. Is it needed and sufficient? Are other dtype mismatches likely, given `--dtype bfloat16` and AutoRound W4A16?
4. **EP4 + AutoRound Marlin MoE + NEXTN drafter** (compressed-tensors INT4 g32) on 0.5.21 TP4 sm89: any known blocker?
5. **PLE BF16 offload** (`qwen4_exp.py:505-540`, VocabParallel + pinned host): the host RAM estimate (about 95 GB, 128 GB worst case with power-of-two rounding) vs 202.6 GB, the 8 MiB memlock limit, and the `file` backend.
6. **TileLang QSA indexer on sm89** (`qsa/mqa.py`): the earlier "Data race detected: Logits(bx, position)" warning. Real bug or a false positive? Is the torch fallback (`HAS_TILELANG=False`) exact?
7. **KV estimate:** 6 KiB/token/rank fp8, about 170-250k tokens. Is the arithmetic right, and does the NEXTN drafter's KV reduce it much?

### B. Minimal-change check

- Is there any change in PLAN §2 (D1-D7) that is **not** unavoidable? Is anything **missing** that will certainly break on sm89?
- Should anything from Franzen we planned to drop be kept: patch #2 (spec-state memory budgeting), patch #4 (prefix-cache retention), patch #5 (prefetch lookahead), `--gdn-mtp-cache-mode`?

### C. Research (public sources, give URLs)

1. Has anyone served **Qwen3.8-Flash-Next (qwen4_exp / Qwen4-Exp)** on **Ada / L4 / sm89** or another non-Hopper/Blackwell GPU, with SGLang or vLLM? Which kernels did they use for QSA decode, GDN and MoE, and what were the numerics and throughput?
2. SGLang upstream after 0.5.21: any fix for QSA decode on sm80/sm89 (FA2/FA4/Triton), for the Marlin MoE scale dtype, or for TileLang on sm89 (PR #36968 and successors)?
3. Is there a classic **FA2 `flash_attn` wheel** for torch 2.13 + CUDA 13.0 + Python 3.12 that supports sm89? (It would give Pennyroyal / 0.5.21 a validated decode without code changes.)
4. Any public ARC-AGI-2 Kaggle notebook or discussion running Flash-Next on 4xL4, with scores and speeds?
5. The licence: does the Qwen Community License for Flash-Next block ARC Prize 2026 eligibility? Any official ruling (thread 745079 or others)?

### D. Output format

1. A table: claim # → agree / disagree / unsure → evidence.
2. A list of blockers and bugs (file:line), most severe first.
3. A concrete minimal fix for each blocker.
4. Research findings with URLs.
5. Your verdict: is PLAN rev 3 the minimal correct path? If not, give the minimal alternative.

Do not propose re-architecting Duck, fine-tuning, or replacing the competition setup. The goal is the minimal working Flash-Next serving on 4xL4 that we can drop into the existing Duck notebook.

## Zip layout

| Folder | Contents |
|---|---|
| `plan/` | PLAN.md (rev 3), VALIDATION.md |
| `reports/` | Experiment 3 failure report; ARC-3 Flash-Next work report |
| `franzen/` | his notebook v1/v2/v3 (with outputs), versions list, v3 cells split out, the `da-fr` serving README + Pennyroyal bundle builder + patches, WRITEUP, README |
| `e3/` | Experiment 3 README, v4.2.1 run report + serve.log, v3.3 serve.log, v4.2.1 builder, the v3.x patch headers, model config |
| `sglang_0_5_21_src/` | relevant 0.5.21 source files (the wheel version we use) |
| `pennyroyal_0_5_19_src/` | the same files from Franzen's Pennyroyal wheel + requirements.lock |
| `wheelhouse_0_5_21/` | SHA256SUMS + lock of our 0.5.21 wheelhouse (220 wheels) |
| `e12/` | our running Duck notebook (E12 SGLang EVAL30), its engine cell, the Duck settings doc, E12 PLAN.md, SMOKE1 request sizes |
| `misc/` | Kaggle input listings (Franzen model / drafter / Pennyroyal dataset), the flag list used for checks |
