# Experiment 13: Qwen3.8-Flash-Next in the same Duck harness on 4xL4 (plan rev 3, 2026-10-19, after self-validation)

## Goal and principle (user, 2026-10-19)

- Try Flash-Next once in the Duck architecture.
- **Minimal change:** take everything from Franzen's notebook (`dfranzen/arc-agi-3-milestone-2-solution`) and change only what 4xL4 makes unavoidable.
- **Reuse our proven work** instead of redoing it, so we do not loop.

Constraints:
- E12 (27B Duck) stays the main lane.
- Licence: the Qwen Community License may block prize eligibility (thread 745079, no ruling yet). The user decides before any LB use.
- Every GPU step needs the user's go. No push without approval.

Validation log with evidence for each claim: `VALIDATION.md` (same folder).

## What changed from rev 2 (self-validation, details in VALIDATION.md)

1. **Engine A (Franzen's Pennyroyal 0.5.19) cannot get the "one-condition" decode fix.**
   - Its `qwen_sparse_attn_backend.py` has no `is_hip()` branch and no Triton packed-decode kernel. Its decode scratch also takes the **KV dtype**, so with Franzen's fp8 KV the FA fallback would receive fp8 K/V.
   - On sm89, Pennyroyal can only decode through FA2 (not available; and it rejects fp8), FA4 (crashes on sm89) or our own shim (X1, rejected).
   - **So Pennyroyal is not a minimal-change option on L4.**
2. **Engine B (SGLang 0.5.21, our proven wheelhouse) becomes the only engine.**
   - It has the Triton packed-decode kernel. That kernel converts fp8 to Q's dtype, uses no host sync, and has no HIP-specific code.
   - The fix is one condition.
3. **0.5.21 still has the GPTQ-Marlin MoE scale bug** (`dtype=torch.half`, 2 places) that Franzen fixed in his patch #3.
   - Pennyroyal's wheel already contains the fix (sha `47e65140…` = his AFTER_SHA).
   - So B takes **Franzen's patch #3 verbatim**.
4. `--gdn-mtp-cache-mode` (a Pennyroyal flag) does not exist in 0.5.21. Every other Franzen flag exists in both builds (script check).
5. PLE: in 0.5.21 it is a `VocabParallelEmbedding`, sharded over TP ranks.
   - BF16 PLE is about 95 GB in total, about 24 GB pinned per rank; host RAM is 202.6 GB.
   - Risk: pinned rounding to 32 GB per rank gives 128 GB. A `file` backend exists as a fallback.

## 1. Reuse inventory (proven work, taken as is)

Status:
- **K** = worked on Kaggle (evidence);
- **L** = local harness;
- **X** = do not reuse.

| # | Piece | Where | Status | Use |
|---|---|---|---|---|
| R1 | SGLang 0.5.21 wheelhouse `foysalemonshanto/sglang-0-5-21-cu13-wheelhouse` + `install_wheelhouse.py` + flashinfer-jit `+` rename + libcudart/lib64/libcuda shim + venv | E11 Build, E12 CELL 5 | **K** (E11-06, E12 SMOKE1/EVAL30) | engine, unchanged |
| R2 | E11 bring-up: diagnosed relaunch, caps from the log, fail-closed capacity gate | E12 CELL 5 | **K** | unchanged; Flash-Next log patterns added |
| R3 | Preflight that checks every launch flag exists in the build | E3 builder stage 3 | **K** (E3) | ported to the 0.5.21 venv |
| R4 | Pin probe (memlock 8 MiB, cudaHostRegister 1 GiB OK) | E3 stage 3_pinned_memory | **K** | unchanged |
| R5 | `--weight-loader-prefetch-checkpoints` (345 s for 124.8 GB on 4xL4) | E3 stage 4 | **K** | Franzen's flag too |
| R6 | Launcher safety: own process group + killpg, port gate, /health only while the launcher lives, progress-based wait | E3 v4.2.1 + `fnh/fn_harness_v42.py` | **K** + **L** | unchanged |
| R7 | Stage report JSON, input check, model dir assembled by symlink | E3 stages 0/1 | **K** | unchanged |
| R8 | Flash-Next launch rules: MoE runner `auto`; **EP4**; no `--language-model-only`; QSA page 64; mamba slots | E3 crashes | **K** | launch asserts |
| R9 | Duck package (20 files, byte-identical da-fr @ 10882e33) + `arc2_duck.py` + sandbox / memory self-tests | E12 CELL 3 | **K** | unchanged |
| R10 | E12 solver, report, dual-mode CELL 0 fallback, request and thinking logs | E12 CELL 0/6/7 | **K** | unchanged |
| R11 | Duck milestone-2 env, already mapped to ARC-2 | E12 settings doc | **K** | unchanged |
| R12 | Fake-server notebook harness | `e12_harness/harness_e12_nb.py` | **L** | add a Flash-Next flag profile |
| R13 | Push script (account, sha, quick save / commit, `--hamid` / `--esfer`) | `push_e12/push_e12_duck.py` | **K** | add `--e13` |
| R14 | Models: Franzen's public Intel W4A16 AutoRound (BF16 PLE, 22 PLE shards, resharded by him) + albucino NEXTN drafter; FR-Spec map `hot_tokens_64k.pt` (in `dfranzen/pennyroyal-v253`, public) | Kaggle | **K** (Intel attached in E3) | verbatim |
| R15 | Franzen's patch #3 (GPTQ-Marlin MoE scale dtype) | `_scratch/ext/dafr/serving/build_bundle_pennyroyal.sh` | **K** (Franzen; shipped in Pennyroyal) | applied to 0.5.21 |
| X1 | Our PyTorch FA2 shim | E3 | **X** | replaced by P1 |
| X2 | E3 "minimal first boot" (no CUDA graph, no radix cache, bf16 KV, 16k ctx, 8 requests) | E3 | **X** | Franzen's values instead |
| X3 | Our FP8 PLE overlay | E3 | **X** in the first try | Franzen uses BF16 PLE; fallback only if host RAM fails |
| X4 | Pennyroyal 0.5.19 | Franzen | **X** on L4 | see rev-2 change 1 |

## 2. The complete delta from Franzen (everything else is verbatim)

| # | Franzen | E13 | Why |
|---|---|---|---|
| D1 | Pennyroyal 0.5.19 | SGLang 0.5.21 (R1) | Pennyroyal has no sm89 decode path (rev-2 change 1) |
| D2 | patch #3 already in his wheel | the same patch #3 applied to 0.5.21 (2 tokens: `dtype=torch.half` → `dtype=params_dtype`; anchor count asserted) | the bug is still in 0.5.21 |
| D3 | TRT-LLM QSA decode (SM100/SM120 only) | **P1:** `if is_hip():` → `if is_hip() or <sm89 switch>:`, i.e. SGLang's own `sparse_gqa_packed_decode_triton` | FA4 CuTe crashes on sm89 (E3 v3.3) |
| D4 | TP1 | `--tensor-parallel-size 4 --ep-size 4` | weights 73.6 GB vs 24 GB per L4; EP for group 128 (R8) |
| D5 | FlashInfer GDN / mamba backends | `triton` | FlashInfer GDN is validated only on SM90/SM100 (`gdn_backend.py:189`) |
| D6 | `TORCH_CUDA_ARCH_LIST=12.0`, SM120 env | `8.9`; SM120 env removed (the 0.5.21 env does not know them) | different GPU |
| D7 | `--gdn-mtp-cache-mode none` | dropped | the flag does not exist in 0.5.21 |
| — | model + BF16 PLE + NEXTN drafter + FR-Spec; ctx 139,264; 10 running; chunk 8192; prefill 16384; fp8 KV; page 64; extra_buffer + track 64; mamba cache 60; CUDA graphs up to bs 10; NEXTN 3 steps; accept thresholds 1.0; lpm; preserve_thinking; parsers; prefetch; drop cache; mem 0.96; precache thread | **verbatim** | — |

Duck side: E12 unchanged, except 10 streams (Franzen's `MAX_ACTIVE_STREAMS`), reasoning key `reasoning_content`, and the served name.

Not taken from Franzen:
- patch #1 (SM120 GEMM): not applicable;
- patch #4 (prefix-cache retention): a later option, only if the cache % is low;
- patch #5 (prefetch lookahead): load speed only.

Risk of not taking patch #2 (spec-state memory budgeting): KV capacity may be lower. It is measured, not guessed.

## 3. Decision ladder (fixed, at most 2 launches)

The probe runs R1-R8. Gate C runs on every launch:
- prefill logprobs of a known sequence;
- greedy counting test;
- a small grid echo;
- token ids, logprobs and a NaN check logged.

| Launch | Config | Gate C pass | Gate C fail |
|---|---|---|---|
| B | 0.5.21 + D1-D7, verbatim rest | speed stage | B2 |
| B2 | B with TileLang off (`HAS_TILELANG=False` → SGLang's torch indexer) **and** NEXTN off | speed stage; then re-enable NEXTN once | **stop**, report which test failed |

**Speed stage:**
- decode tok/s at 1 / 4 / 8 / 10 streams with ARC-2 Duck context sizes (SMOKE1: 7k-14k on an easy task; up to the 58k drain);
- KV tokens, free GB per GPU, preemptions;
- the real running count checked.

**Pass bar:**
- correct output;
- aggregate decode at least 700 tok/s (27B W1 = 330-380);
- KV enough for the usable concurrency at the context sizes E12 EVAL30 measures.

KV estimate (to be measured): fp8 KV is 6 KiB/token per rank (12 layers x 1 KV head x 256 x 2). About 1-1.5 GB per rank is left after weights, mamba and the drafter, i.e. **about 170-250k tokens**. That makes concurrency, not speed, the main risk.

## 4. Stages

**Stage 0 (offline, no GPU):**
- Build the probe from R1-R8 + D1-D7 + Gate C.
- Check the anchors in the 0.5.21 wheel: P1, patch #3, and TileLang `HAS_TILELANG`.
- Run the local harness, then the audit zip.

**Stage 1: FN-PROBE-2 on Kaggle.**
- About 60-90 min of L4x4. Weight loading is about 175 GB, about 5-10 min.

**Stage 2: Duck SMOKE1.** E12 SMOKE1 with only the engine cell swapped.

**Stage 3: Duck EVAL30.** Same 30 tasks / 48 inputs as E12 EVAL30, compared directly.

**Stage 4: LB.**
- Only if E13 beats the 27B Duck on score x coverage, after the licence decision and the user's go.
- One bundled submission.

## 5. Risks

1. **Concurrency.** KV is about 170-250k tokens fp8, or less with the drafter.
   - E12 EVAL30 measured Duck prompts at **p50 47.9k / p90 97.7k / max 117k**.
   - So Flash-Next would hold only about 2-4 resident contexts.
   - E12 with 870k KV already re-prefilled 35 % of its prompt tokens (`Experiment 12/Experiment Results/E12 SGLang EVAL30 run1 analysis (2026-10-19).md`).
   - The speed stage must report tok/s **at the context sizes E12 measured**.
2. **Garbage persists in B2.** Then the cause is Marlin + EP4, TP4 over PCIe, or the BF16 PLE path; stop with a report.
3. **Pinned host RAM.** 95-128 GB of 202.6 GB.
4. **Startup.** Load + JIT take about 15 min of the 12 h run.
5. **Licence.**

## 6. GPU budget

- Stage 1: about 1.5-2 h of quota.
- Stage 2: about 0.5 h.
- Stage 3: about 4 h.
