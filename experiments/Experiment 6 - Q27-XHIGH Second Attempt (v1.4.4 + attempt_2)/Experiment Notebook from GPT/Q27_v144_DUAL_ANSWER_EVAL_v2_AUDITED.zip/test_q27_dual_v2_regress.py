"""Focused v2 tests; uses CPU fake engine and the notebook's actual functions."""
import json, pathlib, tempfile, traceback, copy
BASE_DIR = pathlib.Path(__file__).resolve().parent
from types import SimpleNamespace
import importlib.util
p = BASE_DIR / 'test_q27_dual_cpu_v2_legacy.py'
spec=importlib.util.spec_from_file_location('old_dual_tests', p)
m=importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

passes=[]
def ok(name, condition):
 assert condition,name
 passes.append(name)
 print('PASS',name)

# 1. F1 actual baseline regression reproduced using GT only in scoring.
ns,td=m.mk(expected_alt=False)
try:
 ns['SECOND_BRANCH_POLICY']='replace_any'
 # baseline = test input, now ground truth -> old fallback correct, new alternative incorrect.
 ns['SOLUTIONS']['task']=[[[1,1],[1,1]]]
 base=copy.deepcopy(ns['FIRST_PASS_SNAPSHOT']['task#0'])
 ok('F1 original fallback is exact correct',ns['score_unit']('task#0',base)['hit']==1)
 r=ns['run_second_answer_stage']()
 ok('F1 replace_any can LOSE hit', r['replaced_attempt2']==1 and ns['score_unit']('task#0',ns['FINAL']['task#0'])['hit']==0)
finally:td.cleanup()

# 2. F1 train-supported fallback protected under new default selection.
ns,td=m.mk()
try:
 ns['SECOND_BRANCH_POLICY']='protect_supported'
 r=ns['run_second_answer_stage']()
 ok('train-supported identity fallback is protected', r['protected_fallback']==1 and r['replaced_attempt2']==0)
 ok('unselected valid alternative persisted',len(ns['SECOND_BRANCH_CANDIDATES'])==1 and
    (ns['OUT']/'second_branch_candidates.json').exists())
 ok('per-unit reason and field exposed', r['records'][0]['reason_not_selected']=='fallback_train_supported')
finally:td.cleanup()

# 3. F1 partial train support means fallback allowed to be replaced.
ns,td=m.mk()
try:
 ns['SECOND_BRANCH_POLICY']='protect_supported'
 ns['CHALLENGES']['task']['train'][0]['output']=[[9]]
 r=ns['run_second_answer_stage']()
 ok('unsupported identity fallback may be replaced',r['replaced_attempt2']==1 and r['protected_fallback']==0)
finally:td.cleanup()

# 4. F2 duplicate previous fallback should not be counted as replacement.
ns,td=m.mk(alt_text='```grid\n1 1\n1 1\n```')
try:
 ns['SECOND_BRANCH_POLICY']='replace_any'
 snap=copy.deepcopy(ns['FIRST_PASS_SNAPSHOT']['task#0'])
 r=ns['run_second_answer_stage']()
 ok('F2 duplicate old attempt2 no replacement',r['duplicate_previous_second']==1 and r['replaced_attempt2']==0)
 ok('F2 final equals exact baseline', ns['FINAL']['task#0']['attempt_2']==snap['attempt_2'])
finally:td.cleanup()

# 5. F3 final records artifact; original log unchanged in production (mock emulates original event log).
ns,td=m.mk()
try:
 ns['SECOND_BRANCH_POLICY']='replace_any'
 original_rec=copy.deepcopy(ns['RECORDS'])
 (ns['OUT']/'records.jsonl').write_text(json.dumps(original_rec[0])+'\n')
 r=ns['run_second_answer_stage']()
 final=json.loads((ns['OUT']/'records_final.json').read_text())
 raw=json.loads((ns['OUT']/'records.jsonl').read_text())
 ok('F3 original records.jsonl remains historical', raw['src']==original_rec[0]['src'])
 ok('F3 final record carries replaced source', final[0]['src'][1]=='model_second_branch' and final[0]['score']==ns['score_unit']('task#0',ns['FINAL']['task#0']))
 ok('F3 final candidate file and output consistent',json.loads((ns['OUT']/'second_branch_candidates.json').read_text())['task#0']['selected']==True)
finally:td.cleanup()

# 6. Wrong grid/no primary success never causes mutation.
ns,td=m.mk(alt_text='garbage')
try:
 ns['SECOND_BRANCH_POLICY']='replace_any'
 snap=copy.deepcopy(ns['FINAL'])
 r=ns['run_second_answer_stage']()
 ok('invalid alternative cannot alter baseline',ns['FINAL']==snap and r['replaced_attempt2']==0)
finally:td.cleanup()

# 7. F4 late start should log no-work without deadline exception.
ns,td=m.mk(past_deadline=True)
try:
 ns['SECOND_BRANCH_POLICY']='replace_any'
 snap=copy.deepcopy(ns['FINAL'])
 r=ns['run_second_answer_stage']()
 ok('late start has explicit skip reason',r['skipped']=='already_past_second_answer_deadline' and ns['FINAL']==snap)
finally:td.cleanup()

# 8. Per-candidate fault isolation: first decode raises, second still selected.
ns,td=m.mk()
try:
 ns['SECOND_BRANCH_POLICY']='replace_any'
 ns['UNITS'].append('task#1');ns['UNIT_TASK']['task#1']='task';ns['UNIT_Q']['task#1']=1
 ns['UNIT_INDEX']['task#1']=1
 ns['CHALLENGES']['task']['test'].append({'input':[[2,2],[2,2]]})
 ns['SOLUTIONS']['task'].append([[4,5],[6,7]])
 ns['FINAL']['task#1']=ns['make_attempts']('task#1',[[9,8],[7,6]])
 ns['STATE']['task#1']=dict(ns['STATE']['task#0'],uid='task#1')
 ns['FIRST_PASS_SNAPSHOT']['task#1']=copy.deepcopy(ns['FINAL']['task#1'])
 ns['RECORDS'].append({'unit':'task#1','src':['model','test_input'],'score':{'hit':0,'pass1':0}})
 count=[0]
 def bad_decode(ids,**kwargs):
  count[0]+=1
  if count[0]==1:raise ValueError('one candidate decode error')
  return '```grid\n4 5\n6 7\n```'
 ns['tokenizer']=SimpleNamespace(decode=bad_decode)
 r=ns['run_second_answer_stage']()
 ok('candidate-local error does not stop other samples',r['candidate_errors']==1 and r['replaced_attempt2']==1 and r['completed']==1)
 ok('candidate-local exception report exists',any(rec['status']=='candidate_error' for rec in r['records']))
finally:td.cleanup()

# 9. Offline counterfactual scoring: inject complete lightweight report dependencies.
ns,td=m.mk(expected_alt=False)
try:
 ns['SECOND_BRANCH_POLICY']='protect_supported'
 # Train does not support fallback, baseline fallback is correct hidden truth.
 ns['CHALLENGES']['task']['train'][0]['output']=[[9]]
 ns['SOLUTIONS']['task']=[[[1,1],[1,1]]]
 ns['run_second_answer_stage']()
 ns.update({'RUN_ID':'test','PROFILE':'EVAL12','RERUN':False,'CONFIG':{},'ENGINE_INFO':{},
 'SCHED':{'started':ns['time'].perf_counter(),'wall_sec':1,'tok_per_sec':100,'max_active':1,'not_admitted':0,'error':None,'aborted_at_hard_stop':0,'drained':0},
 'SKIPPED':[], 'METRICS_SNAPSHOTS':[], 'N_HIDDEN_UNITS':259,
 'NOTEBOOK_T0':ns['time'].perf_counter()-20,'ADMIT_DEADLINE':ns['time'].perf_counter()+100,
 'DRAIN_DEADLINE':ns['time'].perf_counter()+200,'VERIFY_DEADLINE':ns['time'].perf_counter()+400,
 'WORKING':ns['OUT'],'RUN_ID':'test','zipfile':__import__('zipfile'),
 'SUBMISSION_PATH':ns['OUT']/'submission.json','P':{'source':'eval'},'ENGINE_READY':True})
 ns['RECORDS'][0].update({'mode':'natural','think_tokens':10,'p1_tokens':10,'p2_tokens':2,
 'prompt_tokens':11,'has_grid':True,'task_id':'task','query':0,'sec':10,'end_reason':'natural',
 'p1_finish':'stop','p2_finish':None,'answer_chars':50})
 nb=json.loads((BASE_DIR / 'Q27-XHIGH-v1_4_4_DUAL_ANSWER_EVAL_v2.ipynb').read_text())
 cell=''.join(nb['cells'][8]['source'])
 exec(cell,ns)
 rp=json.loads((ns['OUT']/'run_report.json').read_text())
 ok('counterfactual explicitly captures baseline loss with replace_any',
    rp['second_branch_policy_counterfactual']['replace_any']['lost_units']==['task#0'])
 ok('counterfactual preserve baseline guarantees no lost hit in this fixture',
    rp['second_branch_policy_counterfactual']['keep_fallback']['lost_units']==[])
finally:td.cleanup()

# 10. Frozen original v1.4.4 inference, primary scheduler and parser from old baseline.
new=json.loads((BASE_DIR / 'Q27-XHIGH-v1_4_4_DUAL_ANSWER_EVAL_v2.ipynb').read_text())
base=json.loads((BASE_DIR / 'BASE_Q27-XHIGH-v1_4_4.ipynb').read_text())
for i in [1,3,4,5,6]:
 ok(f'original cell {i} frozen',new['cells'][i]['source']==base['cells'][i]['source'])
old_sched=''.join(base['cells'][7]['source']).rstrip()
new_sched=''.join(new['cells'][7]['source']).split('# ==================================================================== SECOND ANSWER EXPERIMENT',1)[0].rstrip()
ok('original scheduler unchanged byte-for-byte',new_sched==old_sched)
print('\nALL',len(passes),'NEW REGRESSION ASSERTIONS PASS')
