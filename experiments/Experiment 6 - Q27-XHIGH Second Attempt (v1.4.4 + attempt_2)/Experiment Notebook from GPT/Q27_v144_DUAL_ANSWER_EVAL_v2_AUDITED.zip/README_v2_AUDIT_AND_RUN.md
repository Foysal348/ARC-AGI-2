# Q27 v1.4.4 Dual-Answer Experiment v2 — audited update

## What is shipped

- `Q27-XHIGH-v1_4_4_DUAL_ANSWER_EVAL_v2.ipynb`: updated Kaggle research notebook.
- `BASE_Q27-XHIGH-v1_4_4.ipynb`: proven original v1.4.4 baseline used to freeze/check the primary code.
- `test_q27_dual_cpu_v2_legacy.py`: old 8-category mock CPU suite adjusted to use portable relative paths. It explicitly selects `replace_any` to exercise the original behavior.
- `test_q27_dual_v2_regress.py`: 23 additional assertions, including F1 score regression reproduction, F1 mitigation, F2 and F3, F4, candidate error isolation, offline policy comparison, primary-source freeze.
- `validation_cpu.log`, `validation_notebook.log`: saved independent local test runs.

## Source freeze / scope

The baseline primary inference source in cells 1, 3, 4, 5, and 6 is exactly unchanged. The original primary scheduler before the `SECOND ANSWER EXPERIMENT` marker in cell 7 is exactly unchanged. Only additive second-branch configuration (cell 2), the second-answer stage (cell 7), and reporting (cell 8) changed.

The notebook preserves all engine/model/prompt/sampling/primary seeds and primary launch scheduling. An additional final-answer continuation from the original full reasoning token-ID prefix is attempted only after original primary inference completes.

## Bug fixes and caveats

**F1 — genuine potential score regression.** A novel alternative can overwrite a *correct* fallback in `attempt_2` even though `attempt_1` remains unchanged. The additional `novel != baseline_attempt_2` check does not alone avoid the regression. The default **`protect_supported`** policy keeps original identity or horizontal-mirror fallback when that transformation fits every available training pair. This is a dataset-blind conservative heuristic; it cannot guarantee zero hidden LB loss and can itself forgo a useful alternative. The alternative is still recorded so evaluation can compare selection policies offline. There is no universal ground-truth-free rule that guarantees one of two alternative candidates is correct.

**F2 — duplicate former fallback.** An alternative identical to original `attempt_2` is never selected or counted as a replacement; `novel` counts alternatives distinct from both baseline attempts.

**F3 — stale records.** Original append-only `records.jsonl` is retained as a *primary event log*. At every completed alternative, the stage atomically checkpoints `records_final.json`, `second_branch_candidates.json`, `eval_generated_dual_submission.json` and (for hidden mode) `submission.json`; final report summarizes current candidate state. If disk writes fail, `checkpoint_errors` records it. Score correctness cannot be guaranteed if the filesystem itself is failing.

**F4 — hidden time/ON issue.** Not a new code bug: hidden default remains OFF, and post-primary alternatives may have no remaining time. We deliberately DO NOT reserve time by modifying the frozen primary scheduler. Real late-stage scheduling/second-slot allocation requires a separate GPU throughput experiment.

**Candidate error containment.** One alternative's decode/parse/select error is recorded as `candidate_error` and does not kill other completed alternatives. Engine-wide `engine.step()` failures still end the optional stage safely.

## Run profile and policy

- For EVAL12 with branch enabled: default `Q27X_PROFILE=EVAL12`, `Q27X_SECOND_BRANCH=1`, `Q27X_SECOND_POLICY=protect_supported`.
- Optional ablation: `Q27X_SECOND_POLICY=replace_any` (may LOSE an original fallback hit; EVAL ONLY).
- Diagnostic no-replacement: `Q27X_SECOND_POLICY=keep_fallback` (generates raw alternatives, never changes `attempt_2`).
- Kaggle competition rerun: `RERUN_ALL` is selected automatically by `KAGGLE_IS_COMPETITION_RERUN`; Second Branch remains OFF unless manually enabled. Do NOT enable hidden branch solely on CPU evidence.
- Optional controls: `Q27X_SECOND_MAX` <= original answer cap, `Q27X_SECOND_ACTIVE` <= MAX_NUM_SEQS, `Q27X_SECOND_MARGIN` seconds before hard stop.

The per-unit report in `second_branch_report.json` contains `baseline_second_source`, `grid_valid`, `distinct_from_primary`, `distinct_from_previous_second`, `novel`, `train_fallback_supported`, `selected` and `reason_not_selected`. `second_branch_candidates.json` keeps the raw alternative grid for offline counterfactual evaluation, whether selected or rejected.

**Candidate selection is ground-truth-blind.** EVAL-only `score_unit` diagnostics can access solutions during reporting/record updates, as the frozen base already does, but their values never feed back into candidate selection or model prompts. The report includes counterfactual counts for `replace_any`, `protect_supported` and `keep_fallback`, plus exact marginal gains and lost baseline hits. This is *not* permission to use GT to pick the hidden policy per task.

## Local testing

```bash
python test_q27_dual_cpu_v2_legacy.py
python test_q27_dual_v2_regress.py
```

All 8 legacy categories and 23 new assertions pass in the included logs. The full notebook passes `nbformat.validate` and AST parse in the supplied local runtime; all saved outputs are cleared. **GPU 4×L4, vLLM, MTP3 and actual candidate quality have not been validated with this update.** Do not claim new LB without an actual controlled GPU evaluation.

## Key artifacts after Kaggle EVAL12

- `q27x/records.jsonl`: original primary history (not authoritative final result)
- `q27x/records_final.json`: current final per-unit summary (authoritative final record)
- `q27x/second_branch_candidates.json`: raw alternatives for policy comparison
- `q27x/second_branch_report.json`: per-unit and global branch diagnostics
- `q27x/eval_generated_dual_submission.json`: generated final candidate pairs for evaluation
- `q27x/run_report.json`: baseline, final, net, and counterfactual policy scores

## Last caution

This is a **CPU-validated EVAL experiment**, not a safe claim of higher leaderboard score. A second answer sampled from the same reasoning prefix can remain highly correlated with the primary wrong rule. In hidden time-tight runs, post-primary branching may be skipped entirely. Evaluate additional exact hits, fallback losses, and GPU wall-time before enabling a hidden submission.
