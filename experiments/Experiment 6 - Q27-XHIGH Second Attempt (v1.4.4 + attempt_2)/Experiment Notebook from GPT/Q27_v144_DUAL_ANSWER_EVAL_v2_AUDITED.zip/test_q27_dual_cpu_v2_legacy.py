import ast, json, pathlib, re, time, tempfile, types
BASE_DIR = pathlib.Path(__file__).resolve().parent
from types import SimpleNamespace
nb=json.load(open(BASE_DIR / 'Q27-XHIGH-v1_4_4_DUAL_ANSWER_EVAL_v2.ipynb'))
source=''.join(nb['cells'][7]['source']); sec=source.split('# ==================================================================== SECOND ANSWER EXPERIMENT',1)[1].split('\ntry:\n    run_second_answer_stage()',1)[0]
section = '# ==================================================================== SECOND ANSWER EXPERIMENT' + sec
parser_code=''.join(nb['cells'][5]['source'])

def mk(mode='natural', alt_text='```grid\n4 5\n6 7\n```', enabled=True, expected_alt=True, empty_second=False, past_deadline=False):
    td=tempfile.TemporaryDirectory(prefix='q27dual-')
    folder=pathlib.Path(td.name)
    expected = [[4,5],[6,7]] if expected_alt else [[1,2],[3,4]]
    ns={'__name__':'__test__','os':__import__('os'),'re':re,'json':json,'time':time,'traceback':__import__('traceback'),
        'tokenizer':SimpleNamespace(decode=lambda ids,**kwargs:alt_text),
        'ENGINE_READY':True,'SCHED_ERROR':None,'SECOND_BRANCH_ENABLED':enabled,
        'SECOND_BRANCH_POLICY':'replace_any','SECOND_BRANCH_CANDIDATES':{},'SECOND_BRANCH_MAX_TOKENS':8192,'SECOND_BRANCH_MAX_ACTIVE':8,'SECOND_BRANCH_MARGIN_SEC':90,
        'HARD_STOP':time.perf_counter()+ (10 if past_deadline else 240),
        'OUT':folder, 'TASK_IDS':['task'], 'UNITS':['task#0'],'UNIT_TASK':{'task#0':'task'},'UNIT_Q':{'task#0':0},
        'UNIT_INDEX':{'task#0':0},'PROMPT_IDS':{'task#0':[11]},'CHALLENGES':{'task':{'train':[{'input':[[0]],'output':[[0]]}], 'test':[{'input':[[1,1],[1,1]]}]}},
        'SOLUTIONS': {'task':[expected]}, 'THINK_CLOSE_ID':99,'STOP_IDS':[98,99,97],
        'MAX_MODEL_LEN':81920, 'SEED':23, 'CONCURRENCY':16, 'RECORDS':[{'unit':'task#0','src':['model','test_input'],'score':{'hit':0,'pass1':0}}],
        'make_params':lambda cap, seed: {'cap':cap,'seed':seed},
        '_req':lambda uid,phase:f'{uid}|{phase}',
        'write_json_atomic':lambda path,payload:pathlib.Path(path).write_text(json.dumps(payload)),
    }
    # Get actual ARC grid parser and make_attempts, not a stub.
    exec(parser_code,ns)
    prim=[[1,2],[3,4]]
    ns['FINAL']={'task#0':ns['make_attempts']('task#0', prim)}
    assert ns['FINAL']['task#0']['attempt_1']==prim
    p1 = [1,2,99,101,15] if mode=='natural' else [1,2,3]
    pre = [] if mode=='natural' else [98,99,97]
    ns['STATE']={'task#0':{'uid':'task#0','phase':'done', 'prompt_ids':[11], 'p1_ids':p1,
                           'p2_prefix':pre,'mode':mode}}
    class FakeEngine:
        def __init__(self):self.pending={};self.admitted=[];self.aborted=[]
        def add_request(self,uid,prompt,params):self.pending[uid]=None;self.admitted.append((uid,prompt['prompt_token_ids'],params))
        def step(self):
            assert self.pending
            outs=[]
            for uid in list(self.pending):
                self.pending.pop(uid)
                toks=[] if empty_second else [101]
                outs.append(SimpleNamespace(request_id=uid,outputs=[SimpleNamespace(token_ids=toks,finish_reason='stop')],finished=True))
            return outs
        def abort_request(self,ids):self.aborted +=ids
    engine=FakeEngine();ns['engine']=engine
    ns['write_submission']=lambda:ns['write_json_atomic'](folder/'submission.json',ns['FINAL'])
    exec(section,ns)
    return ns,td

# Independent source diff: all original code before alternative block unchanged.
orig=json.load(open(BASE_DIR / 'BASE_Q27-XHIGH-v1_4_4.ipynb'))
for i in [1,3,4,5,6]:
    assert ''.join(nb['cells'][i]['source'])==''.join(orig['cells'][i]['source']),i
assert ''.join(nb['cells'][7]['source']).split('# ==================================================================== SECOND ANSWER EXPERIMENT',1)[0].rstrip()==''.join(orig['cells'][7]['source']).rstrip()
print('PASS frozen primary cells, exact scheduler unchanged')
# Fenced grid parser, natural close, state transitions, scoring, output files.
for mode, expected_prefix in [('natural',[11,1,2,99]),('forced_close',[11,1,2,3,98,99,97])]:
 ns,td=mk(mode)
 try:
  assert ns['dual_answer_prefix'](ns['STATE']['task#0']) == expected_prefix
  report=ns['run_second_answer_stage']()
  assert report['error'] is None,report['error']
  assert report['submitted']==1 and report['completed']==1 and report['parsed']==1 and report['distinct']==1
  assert report['replaced_attempt2']==1
  assert ns['FINAL']['task#0']['attempt_1']==[[1,2],[3,4]]
  assert ns['FINAL']['task#0']['attempt_2']==[[4,5],[6,7]]
  assert ns['RECORDS'][0]['score']=={'hit':1,'pass1':0}
  assert ns['engine'].admitted[0][1]==expected_prefix
  assert ns['engine'].admitted[0][2]['seed']==26
  assert (ns['OUT']/'second_branch_report.json').exists()
  assert (ns['OUT']/'eval_generated_dual_submission.json').exists()
  assert (ns['OUT']/'submission.json').exists()
  print('PASS',mode,'candidate and correct-only marginal hit, durable output')
 finally:td.cleanup()
# Duplicate candidate must not change second slot.
ns,td=mk(alt_text='```grid\n1 2\n3 4\n```',expected_alt=False)
try:
 report=ns['run_second_answer_stage']();assert report['replaced_attempt2']==0
 assert ns['FINAL']['task#0']['attempt_2'] != [[1,2],[3,4]]
 assert ns['FINAL']['task#0']['attempt_1']==[[1,2],[3,4]]
 print('PASS duplicate second answer discarded')
finally:td.cleanup()
# Malformed prediction rejected with no primary corruption.
ns,td=mk(alt_text='no valid grid')
try:
 report=ns['run_second_answer_stage']();assert report['parsed']==0 and report['replaced_attempt2']==0
 assert ns['FINAL']['task#0']['attempt_1']==[[1,2],[3,4]]
 print('PASS malformed candidate no corruption')
finally:td.cleanup()
# Timeout and opt-out.
for kw in ({'past_deadline':True},{'enabled':False}):
 ns,td=mk(**kw)
 try:
  r=ns['run_second_answer_stage']();assert r['submitted']==0 and len(ns['engine'].admitted)==0
  print('PASS no new request:',kw)
 finally:td.cleanup()
# No think boundary returns None.
ns,td=mk()
try:
 ns['STATE']['task#0']['p1_ids']=[1,2]
 ns['STATE']['task#0']['p2_prefix']=[]
 r=ns['run_second_answer_stage']();assert r['skipped_no_prefix']==1
 print('PASS missing thinking boundary')
finally:td.cleanup()
# All notebook code AST parseable and outputs cleared.
for i,c in enumerate(nb['cells']):
 if c['cell_type']=='code':
  ast.parse(''.join(c['source'])); assert c['outputs']==[] and c['execution_count'] is None
print('PASS all notebook syntax and cleared old outputs')
print('ALL 8 CATEGORY CHECKS PASS')
