# Q27-XHIGH-v1.4.4 — Dual-answer EVAL experiment

This experiment modifies the **SECOND ATTEMPT ONLY**, with the original v1.4.4 model, tokenizer, prompt, primary scheduler, sampling policy, primary seeds, MTP3, fp8 KV and 49,152 thinking budget untouched.

## Basis and evidence

The supplied `arc-2026d-32-22lb-updated-v2 (24).ipynb` and `arc-2026d-with-codex (24).ipynb` use a Qwen3-4B fine-tuned test-time-training pipeline with constrained DFS decoding and beam/augmentation scoring, NOT the Q27 reasoning pipeline. They already share the exact same `arc_decoder.py` source; in BOTH, `run_dual_selection()` produces Probmul rank 1 and rank 2, because the first three candidates in the concatenated pool come from Probmul ranking. Codex notebook's saved evaluation reports 26.00/120 using top1 and 33.50/120 using top2; this is a **saved local public-evaluation weighted benchmark**, not a new Kaggle LB result. No GT-aware/rank oracle selector is deployed.

## Implemented experiment

1. Runs the complete original v1.4.4 primary inference first, unchanged.
2. Only AFTER the primary scheduler exits, constructs a second answer continuation from the complete original reasoning **token IDs**:
   - Natural close: the original prompt and phase-1 output through the first `</think>` token, discarding already sampled final answer.
   - Forced close: the original prompt + complete phase-1 reasoning + original `STOP_IDS` suffix.
3. Uses original `make_params()` with a distinct deterministic seed (`SEED + 10 * UNIT_INDEX[uid] + 3`) and up to the original answer cap (8,192 tokens).
4. If branch output parses as a valid grid different from `attempt_1`, only `attempt_2` is replaced; `attempt_1` is immutable. An invalid/duplicate second answer retains the original fallback.
5. The optional second stage is deadline-bound, logs candidate results, updates submission atomically and catches errors without sacrificing saved primary answers.
6. The report records first-pass hits, final pair hits, marginal extra hits, and any loss from replacing the original second fallback.

## Default run options

- `Q27X_PROFILE=EVAL12`: second branch enabled **by default** for this research experiment.
- `Q27X_PROFILE=RERUN_ALL`: second branch **disabled by default**. The proven v1.4.4 hidden baseline stays unchanged unless explicitly opted in via `Q27X_SECOND_BRANCH=1`.
- `Q27X_SECOND_MAX=8192`; `Q27X_SECOND_ACTIVE=8`; `Q27X_SECOND_MARGIN=90` (seconds before HARD_STOP).

## Important output artifacts

- `Q27X_BUNDLE.zip` (original bundle)
- `run_report.json`: baseline vs dual score and `primary_unchanged_all` in EVAL mode
- `second_branch_report.json`: per-unit diagnostics and GPU use
- `eval_generated_dual_submission.json`: actual predicted pair for every test unit, unlike the original EVAL `submission.json` identity fallback
- `second_answers/*.txt`: alternative branch text

The new stage runs after the primary scheduler, so it cannot interfere with first-pass compute. This avoids a confounded comparison but may spend time re-prefilling long prefixes. It is NOT validated on real 4xL4 or Qwen vLLM; real-model benefit is unknown. In a time-tight hidden run the stage may have no time left. Do not use hidden mode with second branching before GPU EVAL results.

## CPU tests

`python test_q27_dual_cpu.py` runs source freeze, natural-close and forced-close prefix, distinct-candidate, invalid/duplicate, disabled/deadline, score accounting, durability and notebook syntax tests using a fake engine. This is a CPU-only harness, not a test of actual MTP or vLLM throughput.
