# Q27-AGENT v1.8.3 — pre-GPU review request (2026-10-12)

This continues your two most recent reviews (`previous_audits/3_…`, `4_…`).

- **3:** v1.8.1 audit, verdict NO-GO.
- **4:** review of our v1.8.2 timing proposal: "metrics + MTP3 GO, late admission conditional, dynamic budget fix first, e2e soft limit".

All findings in both were checked in code; the true ones are fixed in v1.8.3. Your point about verifying KV capacity also turned up a wrong assumption of ours (§2.3).

**Next GPU step:** one EVAL12 commit run (~1.5 GPU-h): the agent on 12 evaluation tasks, merged with the recorded DIRECT answers.

**12-hour hidden rerun:** still not ready. The agent/DIRECT split will be set from EVAL12's `net_gain`, as you asked. Nothing has been pushed since GPU run 3.

**We ask for:**
1. GO / NO-GO for the EVAL12 commit run.
2. A check of the new timing code. It runs only in the hidden rerun or with `eval_direct: "live"`.
3. Anything else that could waste the GPU run.

## 1. Files

| Path | What |
|---|---|
| `notebooks/AGENT_Q27-AGENT-v1_8_3.ipynb` | **Under review** (sha256 `cf571ea8…`). |
| `notebooks/AGENT_Q27-AGENT-v1_8_1_previously_audited.ipynb` | The version of your audit 3. |
| `diffs/*.diff` | v1.8.1 → v1.8.3, one diff per file or cell. **Start here.** |
| `notebooks/DIRECT_Q27-XHIGH-v1_4_4_LB26.94.ipynb` | The LB-26.94 DIRECT pipeline. |
| `build/` | Builder + `direct_ref_eval12.json`. `cd build && python make_q27_agent.py out.ipynb` gives a byte-identical notebook (verified). |
| `build/tests/` + `outputs/` | All tests including `check_static.py` (ast + pyflakes gate); fresh outputs. |
| `runs/` | GPU runs 2 and 3 (logs), Kaggle CPU DRYRUN of v1.8 and v1.8.2 (27/27 each), DIRECT run 4 / run 7 records. |
| `previous_audits/` | Your four audits and reviews, verbatim. |

## 2. Changes since v1.8.1

### 2.1 Audit 3 → v1.8.2 (all items were reproduced in code first)

**E2E gate:**
- If no effort completes python → tool result → verified submit:
  - the commit run stops with `AGENT_E2E_NO_GO`;
  - the hidden run sets `agent_disabled`; `run_submit` then calls `run_rescue` on every task with atomic submission updates, and `solve_repl` is never called.
- If the DIRECT probe also failed, the agent runs as the last resort. Returning would leave the identity fallback, which scores 0.

**DIRECT decoupled from the agent:**
- The rescue's thinking flag and its 49,152 budget no longer follow the agent's `thinking` / `thinking_token_budget` fallback.
- While checking this we found the budget was coupled too, not only the flag; both are fixed.

**Rescue probe vs recorded answers:** a rejected rescue probe disables only a LIVE rescue. With `eval_direct: "ref"` the recorded answers are still merged.

**`RETAIN_DOC`:** no longer says kept functions may use "the preloaded names". It now names the tool-only ones as forbidden.

**Rescue logging:**
- The hidden path writes `rescue_attempts.jsonl`, one flushed line per answered test input.
- The DRYRUN check now requires that file to exist and be non-empty. The old check was `>= 0` on a file that was never written.

**Report labels and metric:**
- `direct_source` now says run 7 = Q27-XHIGH v1.4.4 (LB 26.94).
- The new `net_gain` = (hybrid − direct hits) − expected DIRECT hits displaced by the agent's tokens. It uses DIRECT tokens per query and the hit rate from the same reference.

**`test_v18_local` on Linux:** the libc / CRT symbol choice is now platform-explicit; the old test used a `hasattr` probe inside the child. We could not run Linux locally. Please re-run it.

**Our own find:** `check_static.py` caught a `"\n"` escape in our patch that broke `run_submit.py`, before anything was pushed. The static gate is now mandatory before every push.

### 2.2 Your proposal review → v1.8.3

**MTP:**
- Rung 0 = v1.4.4's `{"method": "mtp", "num_speculative_tokens": 3}` (acceptance 0.661 there).
- Rung 1 = the `qwen3_5_mtp ×2` rung that came up in GPU runs 1–3.
- Then the previous fallbacks.

**Metrics:**
- `MetricsSampler` reads `/metrics` every 30 s in a background thread and records:
  - KV usage peak and p95;
  - running and waiting peaks;
  - counter **deltas** (preemptions, MTP accepted/draft, generated tokens). These are restart-safe: a counter that goes down starts a new segment.
- If metrics cannot be read, the report says `metrics_unavailable`; it never shows a made-up 0.
- KV **capacity** is parsed from the startup log ("GPU KV cache size", "Maximum concurrency … x"), as you advised.

**DIRECT timing — your option "late admission with a forecast, and a dynamic budget only with fixes"** (`rescue.time_budget`, `run_rescue`):
- **Per-request budget:** the shared `ChatClient` is copied per request with `thinking_token_budget = budget` and `max_tokens = budget + answer`. A test confirms the HTTP payload carries the per-request budget. (You noted `chat()` has no override; the copy is how we pass it.)
- **Budget formula:**
  - `remaining = finish − now − overhead_s` (120 s for prefill and safety);
  - `think = remaining × rate − answer_reserve_tokens` (4096);
  - `finish = deadline + 480 s`, i.e. 11:43 in the hidden run; v1.4.4's hard stop was 11:44.
  - If `think < 4096` the result is **None**, and no new request starts. 4096 is v1.4.4's own `MIN_THINK_BUDGET`.
  - Otherwise the budget is capped at 49,152.
- **Rate:** the 25th percentile of `tokens / wall` over the last 32 finished requests (prefill included). Until 4 have finished it is 15 tok/s; run 7 measured about 17.
- **KV throttle:** no new request while the sampler's latest KV usage is ≥ 0.95.
- **Per-request record:** `planned_think_budget`, `started`, `finish_target`, `late`, so the forecast error is visible.
- **Budget rejected by the server:** the per-request copy drops it, and the retry stays **bounded** by `max_tokens = budget + answer` (test T2). There is no unlimited-thinking retry.
- **Deadlines are separate:** `deadline_epoch` (11:35: agent stage end and rescue admission) is unchanged, so the process cut stays 11:50 (test T7). The answer deadline is derived inside `run_rescue`.
- **Wording:** this raises the chance of a late answer; it does not guarantee one.

**E2E:**
- Hidden run: 300 s soft limit.
- One bounded extension to 600 s only if a try's python call already worked and less than 120 s remain.
- A deterministic HTTP failure moves to the next effort at once.

### 2.3 Your KV point, measured

- The agent server's startup log (GPU runs 2 and 3) says: **"GPU KV cache size: 342,400 tokens; Maximum concurrency for 81,920 tokens per request: 13.41x"**. That is about 1.1M tokens effective for this hybrid model.
- v1.4.4's offline engine reported 1,353,600 tokens.
- So our "same KV" assumption was wrong: the server has about 19% less. 16 × ~57k ≈ 912k still fits, with less margin.
- `num_gpu_blocks_override=96` in the log is only the CUDA-graph profiling pass.

## 3. Tests (fresh outputs in `build/tests/outputs/`)

**Static and local:**
- `check_static.py`: clean (one known-harmless `pre` leftover from the source notebook is allowed).
- `test_v18_local`: all groups, including your **T1–T8**:
  - per-request budget in the payload;
  - bounded retry when the budget is rejected;
  - an 11:34-like slow stream is rejected;
  - the cap at 49,152;
  - the p25 speed adapts down;
  - the KV throttle waits;
  - the process cut is unchanged;
  - a crashed unit keeps earlier answers.
- Also tested: sampler peak / delta / restart / unavailable; e2e extension (applied / not offered / not needed); `/metrics` parsing.

**Real GPU path (`test_gpu_path_local`, the real `submit_main.main()` with the launcher's cfg; only install, libcuda and the vLLM command are substituted):**
1. commit run;
2. GPU run 3's bug re-inserted fails in 0 s;
3. e2e NO-GO in the commit run → no evaluation;
4. e2e NO-GO in the hidden run → 0 agent calls, DIRECT on every test input, rescue log written;
5. rejected rescue probe with ref eval → comparison still complete;
6. agent thinking fallback → DIRECT keeps thinking with 49,152.

**Other:**
- `run_notebook_dryrun_local` executes every notebook cell in order. Windows lacks libc and `_posixsubprocess`, so those three checks run on Kaggle Linux.
- Older tests: all pass.
- Kaggle CPU DRYRUN of v1.8.2: 27/27; **of v1.8.3: 29/29** (`runs/kaggle_dryrun_v1_8_3/`; `kv_capacity` is empty there because the fake server writes no vLLM startup log).

## 4. Known residuals (stated, not fixed)

- No real-model evidence yet:
  - agent quality;
  - MTP ×3 speed on the server;
  - KV peak;
  - forecast accuracy;
  - valid-grid rate of short-budget DIRECT answers.
- The guard is an audit hook plus native-symbol blocking, not a kernel sandbox (`unshare`: not permitted on Kaggle).
- The server forces `</think>` without v1.4.4's stop sentence. Forced closes were correct 1 time out of 37 in v1.4.
- The hidden-run split (`agent_frac` 0.5, caps 16k/32k) is a placeholder until EVAL12.
