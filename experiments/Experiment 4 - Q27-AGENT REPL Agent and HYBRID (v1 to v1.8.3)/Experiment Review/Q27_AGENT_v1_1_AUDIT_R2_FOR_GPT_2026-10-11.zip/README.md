# Q27-AGENT v1.1 — audit bundle R2 (2026-10-11)

This responds to your audit R1 of v1.0 (NO-GO).
- **Every R1 finding was first reproduced, or checked in the code, before anything was changed.**
- The table below shows how each one was verified, what was changed, and which local test now covers it.
- **Notebook:** `notebook/Q27-AGENT-v1_1.ipynb` (sha256 `44443e4d…`). The previous version is kept as `notebook/Q27-AGENT-v1_previous.ipynb`.
- `build/make_q27_agent.py` rebuilds the notebook byte-identically from `source_notebook/` (checked).

Context, goal and provenance are unchanged from R1 and summarised in §4.

## 1. R1 findings → verification → change → test
| R1 finding | How we verified it | v1.1 change | Local test |
|---|---|---|---|
| BLOCKER-1 libcuda shim missing | True. Our own Q27-XHIGH run 2 on image `…37c64f7d…` failed with `ld: cannot find -lcuda`, and the old code had no shim. | `submit_main.ensure_libcuda()`: symlink `libcuda.so` → the real `libcuda.so.1` in `/tmp/q27a_cuda_link`, put first on `LIBRARY_PATH` for the server, then a C link probe against `cuInit` with `-lcuda`. The result goes into `agent_server_report.json`. | Runs on Windows → SKIP without crashing. Real test only on L4. |
| BLOCKER-2 server-ready ≠ tool-ready | True. Only `/v1/models` was polled. | `submit_main.smoke(cfg)` runs after every ladder rung comes up. It sends real requests: a forced `submit` (tool_choice named, thinking off, temperature 0), an automatic `python` call, and an automatic `python` call with thinking on (budget 1024). Each gets 2 tries. The rung is accepted if the auto or thinking test passes. If the forced test fails, `force_submit_after` is set to 0; if the thinking test fails, the agent runs with `thinking=False`. Otherwise the server is killed and the next rung is tried. | `test_v11_local` uses a fake OpenAI server in 3 modes: all OK, forced broken, none. |
| HIGH-1 token oversubscription; the last request could exceed the cap | True. The code used `supply/n × 1.3` with 2 attempts and a fixed `max_tokens`. | Per-request cap = `min(turn_max, remaining)`, and the attempt stops below 256. The rerun cap is `supply/n × cap_factor (1.0)`. Attempt 2 is queued only after attempt 1 failed (next row). | `test_v11_local`: turn-3 cap = 6000 when 14,000 of a 20,000 budget is used. |
| HIGH-2 macro instead of the official metric | **Reproduced:** 50 % vs 20 %. | `official_score_pct = correct test outputs / all test outputs`; `task_macro_score_pct` is kept beside it. The launcher prints the official number. | `test_v11_local`: official 20.0 %, macro 33.33 %. |
| HIGH-3 two attempts of one task at once | True. The old log shows `136b0064#0` and `#1` both verified. | `solve_repl` queues attempt 0 of every task; attempt k+1 is queued, at the back, only when attempt k ended unverified. One pool, no idle tail. | `test_v11_local`: A gets [0] only; B and C get [0, 1]. |
| HIGH-4 forced submit unreachable under the budget | True arithmetically (8,192 × 7 ≈ 57k of 60k). | Thinking 6,144 / turn max 8,192, 30 turns, nudge every 4, forced submit after 5. **These are hypotheses, not tuned values.** No A/B is possible before the first real run. | — |
| HIGH-5 memory-safe flags missing | True. | `--max-num-batched-tokens 4096` on every rung, and env `VLLM_MEMORY_PROFILER_ESTIMATE_CUDAGRAPHS=1`. **Not added:** an explicit attention backend. We are not sure of the 0.19 server CLI flag, and a wrong flag would break every rung; the resolved backend will be read from the log. MTP stays the source's `qwen3_5_mtp` with 2 tokens, which is what ran on the hidden test. | — |
| MEDIUM markup recovery | **Reproduced:** `arguments: {}`. **Your proposed regex `(?=</function>)` does not fix it:** `TOOL_BLOCK` hands PARAM the body without `</function>`. | `PARAM … (?:</parameter>|\Z)`. Non-dict arguments become `{"_invalid_arguments": …}`. A call without a usable `code` string gets targeted feedback and does not crash. | `test_v11_local`: 5 parser cases, plus invalid-code feedback in a real attempt. |
| HIGH orphan server on timeout | True. `subprocess.run(timeout)` SIGKILLs `submit_main`, so its `finally` never runs, and the server is in its own session. | `submit_main` writes `/kaggle/working/vllm_server.pid` and a SIGTERM handler kills the group. The launcher cell kills that group in `finally`, if its cmdline contains `vllm` or it is already gone. | Linux-only (`killpg`); not testable here. |
| 12.1 ladder can eat the whole eval | True (6 × 1500 s). | Rung timeout = `min(1500, deadline − now − min_agent_s)`. No rung starts with less than 300 s beyond the reserve (eval 30 min, rerun 60 min). | `test_v11_local`: smoke-gated rung 1 chosen; no rung when the reserve is reached. |
| 12.2 no mid-run server recovery | True. | **Not done in v1.1.** A circuit breaker or restart is a larger change. Progress is persisted per attempt, so completed answers survive. | — |
| 12.3 validator limits | **Reproduced:** 31×1 and `True` were accepted. | 1..30 on each side, `type(v) is int`, atomic rewrite. | `test_v11_local`. |
| 12.4 sandbox isolation | True, by design. | **Not changed.** Generated code must run; it keeps the timeout and `RLIMIT_AS`. | — |
| 12.5 partial eval report | True. | `attempts.jsonl` is opened fresh (`"w"`), and `progress.json` is written after every attempt. | `test_v11_local`. |
| Docker image | Your argument accepted. | We will pin **our proven image `…37c64f7d…`**, now with the libcuda shim, not the source's image. | — |

## 2. Current configuration
- **Server:** the source's ladder (MTP `qwen3_5_mtp` 2 + fp8 KV + `--reasoning-config` + `--language-model-only` first, … plain last), plus `--max-num-batched-tokens 4096`, `max_num_seqs 16`, `max_model_len 81920`, prefix caching, tool parser `qwen3_coder`, reasoning parser `qwen3`.
- **Agent:**
  - `attempts 2` (phased), `concurrency 16`;
  - `temperature 0.6`, `reasoning_effort high`;
  - `thinking_token_budget 6144`, `max_tokens = turn_max_tokens 8192`;
  - `max_turns 30`, `context_budget 28000`, `trim_drain 6000`, `keep_recent 6`;
  - `nudge_every 4`, `force_submit_after 5`, `effort_ladder [medium, low]`, `retain_functions`, `degenerate_guard`, `timeout_as_cut`, `in_python`;
  - eval cap 60k; rerun cap = supply/n, clamped to 15k–60k at 300 tok/s.
- **Commit run (planned next):**
  1. server ladder plus tool smoke;
  2. the agent on the 12 EVAL12 tasks (direct baseline 3/22 = 13.64 % official);
  3. a 2.5 h budget;
  4. reports `agent_server_report.json`, `agent_eval/eval_report.json`, `attempts.jsonl` (transcripts), `progress.json`.
- **Rerun:** agent deadline 11 h 35 min, process cut 11 h 50 min, leftover server killed, validator last.

## 3. Local tests (Windows CPU) — all PASS (`tests/outputs/`)
- `tests/test_agent_local.py` — the eval path with a scripted client (verified / wrong / no-tool tasks).
- `tests/test_submit_local.py` — the rerun path; `submission.json` content.
- `tests/test_v11_local.py` — one check per v1.1 fix (see the table).
- Run: `python tests/<test>.py notebook/Q27-AGENT-v1_1.ipynb tests/data`.

**Still not verifiable without a GPU run:**
- the real tool-calling behaviour of Qwen3.8 through vLLM 0.19 with the overlay wheels;
- the libcuda probe result on Kaggle;
- MTP plus tools;
- KV capacity and throughput;
- real agent quality.

The commit run is designed to measure exactly these and to stop early, with a report, if the smoke fails.

## 4. Provenance and context (unchanged from R1)
- **Agent package:** public notebook https://www.kaggle.com/code/madarshbb/arc-qwen-3-8-27b-agent (copy in `source_notebook/`).
  - `provenance/cell_provenance.txt` lists which cells are identical and shows every diff.
  - Changed: cells 7 `client.py`, 8 `repl_agent.py`, 10 `run_submit.py`, 11 `submit_main.py`, 14 validator.
  - New: cells 0, 12 `run_eval.py`, 13 launcher.
- **Evidence** (`evidence/`): leaderboard top 50, and discussions 748082 (source author: "~15" in direct mode), 746149, 742796, 745787, 747515.
- **Inputs:**
  - model `foysalemonshanto/qwen3-8-27b-fp8-repacked-v1`;
  - dataset `mirzamilanfarabi/arc3-vllm-h100-wheelhouse-v3`;
  - dataset `keithtyser/taaf-duck-qwen38-serving-v1` (overlay wheels);
  - competition data.
- **Baseline** (`baseline_q27_xhigh/`): our direct notebook v1.4.4 and its EVAL12 report (3/22).

## 5. Question
Is v1.1 a **GO for the 2.5 h commit run** (server + tool smoke + EVAL12)? We are not asking about the 12 h submission; that waits for the commit-run results. If not, which concrete line would waste the commit run?
