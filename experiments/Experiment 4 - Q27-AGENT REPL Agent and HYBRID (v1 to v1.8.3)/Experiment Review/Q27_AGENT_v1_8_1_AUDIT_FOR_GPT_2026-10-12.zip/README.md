# Q27-AGENT v1.8.1 — pre-GPU audit request (2026-10-12)

Kaggle *ARC Prize 2026 – ARC-AGI-2*.
- Hardware: Qwen3.8-27B-FP8 on vLLM 0.19.0, 4×L4, no internet, 12-hour rerun.
- Our best LB is now **26.94**: the DIRECT pipeline Q27-XHIGH v1.4.4.
- This notebook is the REPL tool agent plus the DIRECT method as a rescue (HYBRID).
- You audited v1.6 and gave NO-GO (`previous_audits/2_…`). Since then: v1.7 (your fixes), two crashed GPU runs, v1.8, v1.8.1.
- **Nothing in this zip has produced a single agent answer on the real model yet.**
- The next step is a ~1.5 GPU-hour EVAL12 commit run on 12 evaluation tasks.

## What we ask

1. **GO / NO-GO for the EVAL12 commit run.** Mark findings Reproduced / Confirmed from code / Plausible.
2. **Bugs in code that runs only on the GPU path** (server ladder, readiness, smoke, e2e probe, agent loop) — the two GPU crashes were of this kind (§2). We now rehearse that path locally (§4); please look for what the rehearsal still cannot reach.
3. **Design review of the rerun split** (§5): EVAL12 data will set it, but is the framework right?

## 1. Files

| Path | What |
|---|---|
| `notebooks/AGENT_Q27-AGENT-v1_8_1.ipynb` | **The notebook under audit** (sha256 `6d478a45…`). |
| `notebooks/AGENT_Q27-AGENT-v1_6_previously_audited.ipynb` | The version you audited. |
| `diffs/*.diff` | v1.6 → v1.8.1, one diff per file or cell. **Start here.** |
| `notebooks/DIRECT_Q27-XHIGH-v1_4_4_LB26.94.ipynb` | The 26.94 DIRECT pipeline. |
| `build/make_q27_agent.py` + `direct_ref_eval12.json` | Builder. `cd build && python make_q27_agent.py out.ipynb` gives a byte-identical notebook (verified). |
| `build/tests/` + `outputs/` | All tests; fresh outputs, all PASS. Also `pyflakes_v1_8_1.txt`. |
| `runs/gpu_run2_v1_7_crash/` | Notebook log + vLLM log (v1.7 crash). |
| `runs/gpu_run3_v1_8_bug/` | `agent_server_report.json` + vLLM log (v1.8 bug). |
| `runs/kaggle_dryrun_v1_8/` | The Kaggle CPU DRYRUN: `dryrun_report.json` 27/27, notebook log, reports. |
| `runs/direct_run7_v1_4_4_LB26.94/`, `runs/direct_run4_v1_4_LB18.75/` | DIRECT EVAL12 records + full answer texts. They are the source of `direct_ref_eval12.json`. |
| `previous_audits/` | Your two previous audits, verbatim. |

## 2. What happened since your v1.6 audit

**v1.7** — every finding of your final audit fixed, then pushed:
- the eval score is the deployed policy;
- verified-but-wrong is counted from the agent alone;
- the guard is fail-closed with a canary, and blocks ctypes symbols, cffi and `fork_exec`;
- `train` is scope-checked with symtable;
- the e2e probe (your Patch B) was added;
- throughput is reported per stage, rescue results are checkpointed, and the breaker uses a sliding window.

**GPU run 2 (v1.7)** crashed after 14 minutes in the smoke with `KeyError: 'base_url'`.
- Cause: the new rescue probe called `rescue.direct_client(cfg)`, but `submit_main`'s cfg gets `base_url` only at dispatch.
- Your v1.6 audit had read this probe ("rescue smoke failure non-fatal") but not this defect. Our tests used a hand-made cfg that contained `base_url`.

**Token check, done after run 2 against our own records:**
- The v1.7 rescue gave 32k thinking per *task* with another prompt.
- In the 26.94 pipeline's EVAL12 records, every correct answer needed **26–37k** thinking tokens: 26.5k, 35.0k, 25.9k, 36.8k, plus one from a forced close at 49k.
- So 32k would have lost 3 of 5 hits.

**v1.8:**
1. **The rescue is the 26.94 method verbatim.**
   - One request per *test input*.
   - v1.4's prompt and grid parser copied exactly.
   - xhigh, thinking capped at 49,152 tokens, up to 8,192 answer tokens, temperature 0.6 / top_p 0.95 / top_k 20.
   - A reply without a grid gets one no-thinking commit call.
   - Difference from v1.4: the server forces `</think>` through `thinking_token_budget`, whereas v1.4 appended Qwen's stop sentence. Forced closes gave 1 correct out of 37 in v1.4.
2. **The eval spends no GPU on DIRECT** (`eval_direct: "ref"`).
   - The agent is merged exactly with the recorded answers of runs 7 and 4 on the same 12 tasks.
   - Those answers were re-parsed with the verbatim parser; the correctness matches the run records 22/22.
   - So the agent keeps the whole eval time (`EVAL_HOURS` 1.5). `"live"` regenerates DIRECT instead.
3. **Merge:** only **one** train-verified grid ranks above the direct answer. In the earlier R6 code-loop experiment, 3 of 4 train-verified programs were wrong on test.
4. **4,096 tokens of action room** after the forced `</think>` (`turn_max_tokens` 10,240 with a 6,144-token budget). In PIV v2.4G, a 768-token room truncated tool calls.
5. **`direct_client` defaults** `base_url` and `model` (the run-2 crash).
6. **DRYRUN:** a commit run without a GPU drives the real path against `fake_vllm.py` and ends with a check cell. **On Kaggle CPU it passed 27/27**, including the guard against the real solutions file, libc via ctypes, `fork_exec`, subprocess, and the fail-closed canary.

**GPU run 3 (v1.8)** — the server came up in about 8 minutes, but readiness was never detected. The ladder spent 25 minutes on each rung; we cancelled after about 40 minutes.
- Cause: the DRYRUN branch inside `start_server` contained `import urllib.request`. That makes `urllib` local to the whole function, so the real readiness poll raised `UnboundLocalError`, and the poll's `except Exception` swallowed it.
- Evidence: the vLLM log shows `Application startup complete` and **zero** `GET /v1/models` requests.
- DRYRUN did not catch it because its branch executes the import. Earlier tests replaced `start_server` with a fake.

**v1.8.1 (this zip):**
- The import is removed.
- The readiness poll re-raises `NameError` / `AttributeError` / `TypeError`, so a code bug now fails at once.
- New `test_gpu_path_local.py` runs **the real `submit_main.main()` with the launcher's own cfg**. Only three things are substituted:
  - `install()`;
  - `ensure_libcuda()`;
  - the vLLM command line, which is redirected to `fake_vllm.py` while the real command is still built.
- With that, it exercises:
  - the real ladder;
  - the real readiness loop;
  - the real smoke, rescue probe and e2e probe;
  - the real `run_eval`.
- Negative control: re-inserting run 3's line makes the test fail in under 1 second.
- pyflakes would also have flagged it (`redefinition of unused 'urllib'`).

## 3. Lessons from earlier experiments on this base, and where each is handled

| Lesson | Handled by |
|---|---|
| Template rejects effort `high` (agent run 1) | xhigh; the smoke and e2e probe send the agent's exact request; `AGENT_PARAMS` stops the ladder |
| xhigh + tools never closes thinking, 0 tool calls (PIV v1.7) | server `thinking_token_budget` 6,144; e2e checks a real xhigh tool call, otherwise falls back to medium/low |
| Short action room truncates tool calls (PIV v2.4G) | 4,096-token room |
| Train-verified ≠ test-correct (R6) | one verified slot above direct; `verified_but_wrong_*` reported |
| MTP drafter OOM at large batch (XHIGH run 2) | `max_num_batched_tokens` 4096 + `VLLM_MEMORY_PROFILER_ESTIMATE_CUDAGRAPHS=1` |
| FlashInfer JIT needs `-lcuda` | libcuda shim; probe PASS in all three GPU runs |
| Kaggle default image moved to Python 3.13 | image pinned (`37c64f…`) |
| Re-prefill of ~50k tokens after forced close | prefix caching (mamba `align`, confirmed in logs) |
| Custom all-reduce on PCIe | vLLM disables it automatically (log), same as the 26.94 base |

## 4. Evidence and EDA

**Tests:**
- `test_v18_local` (11 groups), `test_gpu_path_local` (real GPU path + negative control), `run_notebook_dryrun_local` (executes *every notebook cell in order* with the launcher's cfg; Windows lacks libc and `_posixsubprocess`, so those three checks are verified on Kaggle Linux instead).
- Older tests: `test_agent_local`, `test_submit_local`, `test_v16_regress`, `test_v14_concurrency`.
- **All PASS.** The Kaggle DRYRUN gave 27/27.

**Kaggle facts:**
- `unshare` on the GPU machine: "Operation not permitted", so a namespace sandbox is not available.
- Server load times: 490 s (run 1), 520 s (run 2), ~470 s (run 3).

**EDA:**
- Evaluation tasks are much larger than test or training tasks: median test-input cells 489 vs 169, task JSON 7.7k vs 3.2k characters, colours 7.2 vs 6.0.
- EVAL12 is harder still: 785 cells and 1.83 test inputs per task.
- The commit run's test file holds 240 *training* tasks; it is a placeholder.
- Observed LB/EVAL12 ratio is about 2× (v1.4: 9.1% → 18.75; v1.4.4: 13.6% → 26.94). We therefore use EVAL12 only for comparisons on the same tasks.

## 5. Open design question: the rerun split

- In the DIRECT pipeline, **score is roughly the number of queries finished in 12 h**. v1.4 → v1.4.4 gained +8.19 LB from prefix caching and admission until 11:34 alone.
- The EVAL12-based projection says DIRECT alone needs about 12.9 h for 259 queries. That probably overstates hidden-test token use, since the hidden tasks look easier.
- In HYBRID, every hour given to the agent removes DIRECT coverage. `agent_frac` (rerun default 0.5) and the scout/deep caps (16k/32k) will be set from EVAL12: the agent's verified-correct tasks per GPU-hour versus DIRECT's.

**Questions:**
- Is the comparison metric right?
- Should the agent instead run only *after* DIRECT, in DIRECT's leftover time?
- Should the agent target specific task types?

## 6. Known residuals (not fixed, stated)

- The guard is a PEP 578 audit hook plus native-symbol blocking. It is not a kernel sandbox: namespaces are unavailable, and seccomp is untested on Kaggle. Denials are reported (`isolation_denied_tasks`).
- The DIRECT forced close inserts no stop sentence (see §2, v1.8 item 1).
- The agent turn design (6,144 forced thinking per turn; thinking dropped between turns) is untested on the real model. Run 1 never got an answer. The EVAL12 report shows cuts, turns and verified rate.

## Constraints

- Same model, engine and hardware.
- Notebook must stay dual-mode: a commit run is the EVAL12 measurement; a competition rerun writes `submission.json`.
- Agent stops at 11 h 35 m; the process is cut at 11 h 50 m.
- Only one submission can be pending at a time.
