# Q27-AGENT v1.2 — audit bundle R3 (2026-10-11)

This responds to your audit R2 of v1.1 (NO-GO as-is; "conditional GO after three required fixes").
- **Every R2 finding was first verified in the generated code, or reproduced, before it was changed.**
- **Notebook:** `notebook/Q27-AGENT-v1_2.ipynb`, **SHA-256 `c6e1ab75be356507…`** (LF newlines). `build/make_q27_agent.py` rebuilds it **byte-identically** from `source_notebook/`; this was checked inside this bundle.
- The previous version is in `notebook/Q27-AGENT-v1_1_previous.ipynb`.
- Earlier context, provenance and evidence are unchanged; see `evidence/`, `provenance/cell_provenance.txt` and `source_notebook/`.

## 1. R2 findings → verification → change → test
| R2 finding | Verified how | v1.2 change | Test (`tests/test_v12_local.py`) |
|---|---|---|---|
| **BLOCKER-1** smoke passes invalid code | Code: `check()` only tested for a non-empty string. | A call counts only if its code works on `SMOKE_TASK` (train `[[1,2]]→[[1,2]]`, test `[[3,4]]`). A `submit` must `verify()` with 1/1 and return `[[[3,4]]]`; a `python` call must run via `run_snippet` and print `(1, 2)`, with no traceback and no crash. | Fake server returns "definitely NOT executable python code !!!" → `ok=False`, all three tests False. Correct code → all True. |
| **BLOCKER-2** budget silently dropped | Code: `client.py` sets `thinking_token_budget = None` on a 400 and retries. | `thinking_budget_retained = (client budget still 1024)`; `thinking_ok` requires it. On a rung where thinking is not OK, the agent runs with `thinking=False` **and** `thinking_token_budget=None` (explicit). The report records `thinking_budget_retained`. | Fake server returns a 400 when the budget is present → `thinking_ok=False`, `thinking_budget_retained=False`, `ok=True` (auto). The ladder test checks that the agent config gets `thinking=False` and a `None` budget. |
| **BLOCKER-3** smoke can eat the reserve | Code: 3 cases × 2 tries × 300 s. | `smoke(cfg, smoke_deadline)`: one deadline per rung, `min(180 s, slack − 30 s)`, where slack = deadline − now − `min_agent_s`. Each request gets `min(75 s, remaining)`. The smoke is skipped, and the ladder stops, when slack ≤ 60 s. The report has `install_s`, per-rung `start_s` and `smoke_s`, and `remaining_agent_s`. | A server that hangs for 20 s per request, with a 6 s smoke deadline → returns after 6.0 s with `deadline_hit=True`. In the ladder, every smoke deadline is ≤ 180 s. |
| HIGH CUDA probe FAIL still loads | Code: the result was ignored. | **Kept non-fatal, but logged loudly and in the report.** Only FlashInfer's JIT needs `-lcuda`; vLLM picks the attention backend itself on later rungs, and every rung must still pass the smoke. Aborting would forfeit runs that a non-FlashInfer rung could serve. **If you see a concrete reason that every rung needs `-lcuda`, tell us and we will make it fatal.** | Ladder test with `probe=FAIL`: warning printed, the ladder continues. |
| HIGH validator crash path | Code: `r.get` on a str row. | Cell 14 is rewritten (no longer the source's): a non-dict file, missing or null rows, str rows, ragged or out-of-range grids, bool values, unknown keys and truncated JSON are all handled. **Only a bad ROW is replaced** by the fallback. Atomic write. | 8 cases: valid, missing task, null rows, string row (only that row replaced), ragged, unknown task (dropped), bool, truncated JSON. |
| HIGH rerun budget not fully accounted | Arithmetic agreed. | **No change now, as you advised.** It waits for EVAL12 numbers: first-attempt verify rate, tokens per second attempt, and useful-token share. | — |
| MEDIUM progress not atomic | Code. | `progress.json.tmp` followed by `os.replace`. | Checked. |
| MEDIUM SHA claim / CRLF | **Reproduced:** the on-disk file had 2,476 CRLF, sha `9391cbf3…`; the LF-normalised sha was `44443e4d…`, the printed in-memory hash. | `write_text(..., newline="\n")`, and the printed hash is of the file on disk. | Byte-identical rebuild. |
| MEDIUM solution-file access in eval | True: generated code runs with the real filesystem, and the evaluation solutions exist there. | Not blocked; it is **detected**. `file_access_suspicious_tasks` lists every task whose executed code matches `solution|/kaggle/|open(|listdir|scandir|glob|pathlib|Path(|walk(`. The task is flagged, and the transcripts are in `attempts.jsonl`. | A mock task calling `os.listdir('/kaggle/input')` is flagged; clean tasks are not. |
| 11.1 retained functions using preloaded names | True: a kept function may read `train_inputs` and fail in the `submit` sandbox. | **Not changed.** The model then gets the `NameError` as submit feedback; there is no crash. | — |
| 11.2 verified ≠ correct | Agreed. | The report adds `verified_but_wrong_tasks`, next to `tasks_with_verified_program` and `official_score_pct`. | A mock that fits train but is wrong on test is listed. |

## 2. Local tests (Windows CPU) — all PASS, outputs in `tests/outputs/`
- `test_agent_local.py` — eval path.
- `test_submit_local.py` — rerun path.
- `test_v12_local.py` — every R1 and R2 fix:
  - parser (5 cases);
  - request cap (6,000);
  - phased attempts;
  - invalid-code feedback;
  - official metric (14.29 % vs macro 20 %);
  - contamination flag and verified-but-wrong;
  - atomic progress;
  - validator (8 cases);
  - tool smoke (4 modes, including the hang);
  - server ladder (probe FAIL, smoke deadline, explicit no-thinking fallback, reserve).
- Run: `python tests/<test>.py notebook/Q27-AGENT-v1_2.ipynb tests/data`.

**Not verifiable without a GPU:**
- real Qwen3.8 tool calls through vLLM 0.19 with the overlay wheels;
- the real `-lcuda` probe;
- the effect of the thinking cap per turn;
- MTP plus tools;
- KV and throughput;
- agent quality;
- `killpg` (Linux).

## 3. Question
Is v1.2 a **GO for the 2.5 h EVAL12 commit run**? The 12 h submission is not being asked. If not, which concrete line would waste that run?
