# Q27-AGENT v1.8.3 — real GPU EVAL12 result: analysis + request for solutions (2026-10-12)

You gave v1.8.3 a GO (`previous_audits/5_gpt_GO_v1_8_3.md`). It ran as a commit run on Kaggle, 4×L4, on 2026-10-12.

- **Infrastructure:** everything worked.
- **The agent:** **0 / 22** test outputs correct (DIRECT reference 3/22).
- **What failed:** almost entirely the tool interface and the turn structure. The model's reasoning was never really tested, because its programs never reached verification.

**We ask for:**
1. Your own diagnosis from the raw data. Do you agree with §3?
2. Concrete, minimal fixes, ranked by expected gain, that make the agent produce real, verifiable `transform(grid)` programs on this model.
3. The best design for Qwen3.8-27B (xhigh needs long continuous thinking) with a REPL tool. Use the public ARC agent harnesses and the Kaggle discussions where useful.
4. Whether DIRECT-only improvements (the LB-26.94 method + MTP×3 + late admission) should come first.

## 1. Files

| Path | What |
|---|---|
| `run_eval12_v1_8_3/` | **Raw outputs.** `attempts.jsonl` (24 attempts with full transcripts: reasoning, content, calls, tool outputs per turn), `eval_report.json`, `agent_server_report.json`, `vllm-server.log`, `q27-agent.log`, submissions. |
| `analysis/` | Our extraction: `summary.json`, `per_attempt_table.md`, `submits_with_code.json` (every submitted program and its feedback), `http500_traceback_excerpt.txt`. |
| `notebooks/AGENT_Q27-AGENT-v1_8_3_as_run.ipynb` | The exact notebook that ran (sha256 `cf571ea8…`). |
| `notebooks/DIRECT_Q27-XHIGH-v1_4_4_LB26.94.ipynb` | Our best LB pipeline: 49,152 continuous xhigh thinking + 8,192 answer tokens per test input. |
| `build/`, `source_notebook/` | Builder (byte-identical rebuild) and madarshbb's public agent it is based on. |
| `direct_records/` | DIRECT runs 7 (v1.4.4, LB 26.94) and 4 (v1.4, LB 18.75) on the same 12 tasks: records + full answers. |
| `previous_audits/` | All your earlier audits, verbatim. |

## 2. Measured facts

### Infrastructure (all OK)

- **Server:** up in 510 s on rung 0 (`--speculative-config {"method":"mtp","num_speculative_tokens":3}`, fp8 KV, prefix caching, `--reasoning-config`).
- **Smoke:** all OK. Forced, auto, thinking with a 6,144 budget, roundtrip, the agent's exact request shape and the DIRECT probe all passed.
- **E2E probe at xhigh:** python → tool result → verified submit worked on the first try. The probe task is trivial, so it took only 57 tokens.
- **KV capacity** (startup log): 337,600 "tokens"; max concurrency 12.63× at 81,920 tokens per request.
- **Telemetry over the run:**
  - KV usage peak 31%, p95 30%;
  - preemptions 0;
  - running requests peak 12, waiting peak 3;
  - MTP acceptance 0.736;
  - agent generation 256.5 tok/s.
- **Guard and breaker:** no guard failures, no denials; the circuit breaker did not trip.

### Agent configuration

- xhigh, `thinking_token_budget` 6,144 per turn (forced `</think>`), turn max_tokens 10,240.
- Up to 30 turns; context budget 28k with trimming.
- After a cut turn the effort ladder steps xhigh → medium → low.
- **Forced submit** (`tool_choice={"type":"function","function":{"name":"submit"}}`) once 5 python calls have happened since the last submit.
- Attempt caps: 24k scout, then 36k deep. Two attempts per task.

### Outcome over 24 attempts and 304 turns

| Metric | Value |
|---|---|
| Correct test outputs | **0 / 22** (verified programs 0; `best_ok` = 0 or −1 in every attempt) |
| Attempt endings | token budget 18, **HTTP 500: 5**, turn budget 1 |
| Turn finish | tool_calls 185, stop 82, length 37 |
| Turns with neither content nor a tool call | 35 |
| Turn tokens | p25 245, median 937, p75 2,476; **22 turns cut at the 10,240 cap** |
| Tool calls | python 191, submit 82 |
| **Submit outcomes** | **59 empty `code`** ("no valid 'code' string"); **22 rejected as nonportable** (used `train` / `train_inputs` …, i.e. exploration code); **1** reached the sandbox and reproduced 0 train pairs |
| Forced submit turns | 89 |

## 3. Our diagnosis (each point checked against `attempts.jsonl`)

**1. The model never submitted on its own.**
- In practically every attempt, the number of submit calls equals the number of forced-submit turns. For example, 898e7135#0 had 7 forced turns and 7 submits; 247ef758#1 had 14 and 14; 4c7dc4dd#1 had 13 and 13.
- No attempt has more empty submits than forced turns.
- Within a 24k–36k budget the model keeps exploring with `python` and never chooses `submit` by itself.

**2. Forced submits produce no program.**
- 59 of 89 forced turns returned a `submit` call with **no `code`**. Typical case (2b83f449): reasoning ends with "Let me overlay.", content is empty, the call is `submit` with no arguments. The model was mid-exploration and the named `tool_choice` forced a call it had nothing to put in.
- The other forced submits carried **exploration code**, e.g. `A = np.array(train[0][0]); print(...)`. That is what it would have sent to `python`.
- Our smoke tested a forced submit only with thinking off and on a trivial identity task, so it missed this.

**3. vLLM 0.19.0 HTTP 500**, in 5 of 24 attempts (`analysis/http500_traceback_excerpt.txt`).
- `serving.py: _parse_tool_calls_from_content → assert content is not None` fails when a turn's output is all reasoning, with tools present.
- Our client treats any HTTP error as fatal for the attempt.

**4. Thinking depth.**
- Every xhigh turn is capped at 6,144 thinking tokens, and thinking is dropped between turns (Qwen's template does not resend earlier reasoning).
- In the DIRECT records, every correct answer needed **26–37k continuous thinking**.
- The agent never thinks more than 6k in one go. The user had explicitly forbidden budgets below the base, and this design violated that.

**5. EVAL12 is our hardest subset.**
- Median test-input cells: 785, versus 489 for all evaluation tasks and 169 for the test/training files.
- Our EVAL12 → LB ratio has been about 2× (v1.4: 9.1% → 18.75; v1.4.4: 13.6% → 26.94).

## 4. Constraints (please keep fixes within these)

- **Model and stack:** Qwen3.8-27B-FP8; vLLM 0.19.0 offline wheelhouse plus the transformers overlay; 4×L4 (about 1.0M effective KV tokens); no internet.
  - The chat template supports `reasoning_effort` xhigh, medium or low only.
  - `thinking_token_budget` works server-side.
  - Tools go through the `qwen3_coder` parser.
- **Hidden rerun:** 12 h for 240 tasks / 259 queries. DIRECT alone (49k per query) projected about 12.9 h on EVAL12-sized tasks; the hidden tasks are smaller.
- **Token budgets:** no budget below the LB base (49,152 continuous thinking per test input) without the user's explicit approval. Designs that cut thinking must justify it with data.
- **Notebook shape:** dual mode (commit run = EVAL12 measurement; rerun = hidden test `submission.json`).
- **Submissions:** one pending submission at a time; scoring takes about 1.5–2 days per submission; deadline 2026-11-02.

## 5. Candidate fixes we are considering (please critique, rank, or replace)

**A. No named forced submit while thinking.**
- Replace it with a text instruction ("write the complete transform(grid) now and call submit"), sent as a user message with thinking on.
- If submit comes back with empty or exploration code, return a precise correction once.

**B. HTTP 500 → retry.** Retry the turn once (or treat it as a cut turn) instead of failing the attempt. Possibly lower `max_tokens` for that turn.

**C. A first long turn.**
- Turn 1 at xhigh with the base budget (up to 49k continuous thinking).
- The model must end it with a complete `transform(grid)` submit; the python tool stays available.
- Later turns at low or medium effort repair the program from the verification feedback, with a compact memory of the hypothesis.
- This is the DIRECT strength plus code verification. Note R6 (an earlier code loop): its repair turns restarted from scratch and got 2/22.

**D. One attempt per task with the whole budget** (instead of 24k + 36k), so the turn history stays continuous.

**E. Drop the agent for the next submission.** Submit DIRECT v1.4.4 + MTP×3 (acceptance 0.736 measured) + late admission with the time-aware budget. This could fit more queries into 12 h, which was the source of the v1.4 → v1.4.4 gain of +8.19 LB.
