# Q27-AGENT v1.3 — audit bundle R4 (2026-10-11)

This responds to your audit R3 of v1.2: conditional GO for EVAL12 after four fixes.
- **Every R3 finding was verified in the generated code before it was changed.**
- **Notebook:** `notebook/Q27-AGENT-v1_3.ipynb`, **SHA-256 `73ab263862e8dcd4…`** (LF). `build/make_q27_agent.py` rebuilds it byte-identically; this was checked inside this bundle.
- The previous version is `notebook/Q27-AGENT-v1_2_previous.ipynb`.
- Provenance, evidence and the baseline are unchanged; see `provenance/`, `evidence/`, `source_notebook/` and `baseline_q27_xhigh/`.

## 1. R3 findings → verification → change → test (`tests/test_v13_local.py`)
| R3 finding | Verified | v1.3 change | Test |
|---|---|---|---|
| **HIGH-1** no second-turn check (python → tool result → model) | Yes: the smoke never sent a `role: "tool"` message. | A new **roundtrip** stage runs on the mode the agent will use (thinking if that test passed, otherwise plain). It takes the first `python` call, runs it, sends back the assistant `tool_calls` plus the `role:"tool"` result plus "now submit identity", then makes a second request **without tool_choice**, so the automatic submit is tested too. The submit must `verify()`. `ok = (auto or thinking) and roundtrip`. | Fake server returns 400 whenever a `role:"tool"` message is present → `auto_ok=True`, `thinking_ok=True`, **`roundtrip_ok=False`, `ok=False`**. The normal server → `roundtrip_ok=True` (mode thinking). |
| **HIGH-2** smoke budget 1024 ≠ agent 6144; the runtime drop is silent | Yes. | The thinking test sends the agent's real budget (`cfg["thinking_token_budget"]`, 6144) with `max_tokens ≥ budget + 1024` and effort `low`, to keep the reply short; the server must accept the value. `thinking_budget_retained` compares against the requested budget. `client.py` sets `budget_dropped=True` and prints a warning when it drops the budget at runtime, and `run_eval` reports `thinking_budget_dropped_at_runtime`. | A server that accepts 1024 but rejects > 4096 → `thinking_ok=False`, `thinking_budget_retained=False`, `ok` via auto + roundtrip, `roundtrip_mode="auto"`. |
| **HIGH-3** the client retry re-used a full timeout | Yes. | `ChatClient.chat(..., _deadline=None)`: one absolute monotonic deadline per logical request, forwarded to the budget-rejection retry. `urlopen(timeout=remaining)`; when it is exhausted the client returns `{"error": "request deadline exhausted", "timeout": True}`. The smoke's semantic execution uses `min(8 s, smoke time left)`. | A server answering 400 after 0.25 s, then 200 after 0.25 s, with a 0.40 s timeout → the call returns an error at 0.41 s, and `budget_dropped` is recorded. |
| **HIGH** the `-lcuda` FAIL rationale was weak | Yes: no rung changes the attention backend. | `classify_startup_failure()` reads the server-log tail: `CUDA_LINKER` / `UNSUPPORTED_FLAGS` / `OOM` / `UNKNOWN`, recorded per rung. **A CUDA_LINKER failure stops the ladder** instead of reloading the 27B on every rung. A failed probe before loading is still logged, not fatal: a compiler-probe failure alone does not prove that the engine path needs `-lcuda`. | A log with "cannot find -lcuda" → 1 start, `failure=CUDA_LINKER`, ladder stopped, agent not started. "unrecognized arguments" → `UNSUPPORTED_FLAGS`. |
| HIGH contamination detector bypass | Yes (a builtins read). | **Still detection, not prevention.** The regex is wider: `builtins`, `__import__`, `importlib`, `io`, `os`, `sys`, `subprocess`, `shutil`, `socket`, `eval(`, `exec(`, `compile(`, `getattr(`, `globals(`/`locals(`/`vars(`, plus the earlier terms. Flagged tasks are for manual review in `attempts.jsonl`, and the EVAL score is provisional for them. | A mock task using `getattr(__builtins__, 'op'+'en')` is flagged. |
| MEDIUM the python check accepted a hard-coded `print("(1, 2)")` | Yes. | Each smoke uses a fresh random identity task (shape from {2×3, 3×2, 2×4, 4×3, 3×5, 5×2}, random colours). The expected shape string is computed from it, and the submit must return that task's test grid. | A server whose python code is `print("(1, 2)")` → `auto_ok=False`, `thinking_ok=False`, `ok=False`. |
| rerun 2nd-attempt budget, nvidia-smi poll, log re-reads | Agreed / noted. | Unchanged. The rerun budget waits for the EVAL12 numbers; the `kill()` GPU-drain poll is already bounded at 36 × 5 s. | — |

## 2. Local tests (Windows CPU) — all PASS, outputs in `tests/outputs/`
- `test_agent_local.py` (eval path) and `test_submit_local.py` (rerun path).
- `test_v13_local.py` covers every R1, R2 and R3 fix:
  - parser (5 cases);
  - request cap;
  - phased attempts;
  - invalid-code feedback;
  - official metric;
  - contamination flag (builtins) and verified-but-wrong;
  - atomic progress;
  - validator (8 cases);
  - tool smoke (7 modes, including roundtrip 400 and the hard-coded print);
  - client one-deadline;
  - server ladder;
  - startup classification.
- Run: `python tests/<test>.py notebook/Q27-AGENT-v1_3.ipynb tests/data`.

**Not verifiable without a GPU:**
- real vLLM 0.19 tool calls and multi-turn behaviour;
- the real 6,144 thinking cap;
- MTP plus tools;
- KV and throughput;
- agent quality;
- `killpg` (Linux).

The EVAL12 commit run measures these and writes `agent_server_report.json` (install, start and smoke times, smoke records, chosen rung, budget retained) before any agent work.

## 3. Question
With the four R3 items done, is v1.3 a **GO for the 2.5 h EVAL12 commit run**? The 12 h submission is not being asked.
