# Q27-AGENT v1.6 — final pre-GPU audit request (2026-10-11)

**Competition:** Kaggle *ARC Prize 2026 – ARC-AGI-2*.
- Hardware and limits: 4×L4, 12 h rerun, no internet.
- Model: Qwen3.8-27B-FP8 only, served by vLLM 0.19.0.

**Scores so far:**
- Our DIRECT pipeline (reason up to 49k tokens, then write the grid) scored **LB 18.75**.
- The REPL tool AGENT has never produced a real answer on GPU. Run 1 failed on a config error: `reasoning_effort: "high"` does not exist in Qwen3.8's template.

**What v1.6 is:** the AGENT plus the fixes from your previous deep audit, which is included as `previous_audit/gpt_deep_audit_DIRECT_vs_AGENT.md`.

**What happens next:** the next step is a single ~2.3 GPU-hour EVAL12 commit run (12 evaluation tasks, 22 test outputs). It is the only run we can afford before the quota resets.

## What we need from this audit

1. **Bugs that would waste the GPU run.** Anything that crashes, hangs, mis-scores, or makes the three-way score report misleading.
2. **The isolation design** (§2): is it sufficient for EVAL12 score integrity? What concrete escapes remain?
3. **The HYBRID schedule and budgets** (§3): is the time split sensible for EVAL12 and for the 240-task hidden run? Is anything clearly better within the same code?
4. **The open items in §5:** which, if any, must be done *before* this run, as opposed to after we have measured data?

Please mark each finding **Reproduced / Confirmed from code / Plausible** as before. Give a GO / NO-GO for the EVAL12 run.

## 1. Files

| Path | What |
|---|---|
| `notebooks/AGENT_Q27-AGENT-v1_6.ipynb` | **The notebook under audit** (sha256 `956b6437…`, LF). |
| `notebooks/AGENT_Q27-AGENT-v1_5_previous.ipynb` | The previous version you audited. |
| `diffs/*.diff` | Per-file unified diffs v1.5 → v1.6. Every agent module is a `%%writefile` cell; the launch and validator cells are included. **Start here.** |
| `build/make_q27_agent.py` | Builder. It applies exact single-occurrence patches to `source_notebook/` (madarshbb's public agent). |
| `build/tests/*.py` + `outputs/*.txt` | CPU tests and their fresh outputs. Every test passes. |
| `notebooks/DIRECT_LB18.75_*` | The LB-18.75 DIRECT notebook, for comparison. |
| `runs/agent_run1_v1_4/` | GPU run 1. Infrastructure OK; every agent request was rejected with HTTP 400. |
| `runs/direct_run4_v1_4/`, `runs/direct_run7_v1_4_4/` | DIRECT EVAL12 records (2/22 and 3/22). |
| `previous_audit/` | Your deep audit, verbatim. |
| `evidence/` | Leaderboard snapshot, discussion texts, public-notebook list and the sources PDF. |

**Reproduce:**
- Rebuild: `python build/make_q27_agent.py out.ipynb` gives a byte-identical notebook (sha `956b6437…`).
- Tests: `cd build/tests` and run `python test_v16_local.py ../../notebooks/AGENT_Q27-AGENT-v1_6.ipynb data`.
  - `test_agent_local`, `test_submit_local` and `test_v16_regress` take the same two arguments.
  - `test_v14_concurrency` takes only the notebook.
  - Requires Python ≥ 3.10 with numpy.

## 2. Isolation (your P0-B)

**Mechanism:** every child process (the `submit` sandbox and the `python` tool) installs a **PEP 578 audit hook** first, before job data is read or user code runs. The code is in the `RUNNER` strings of `sandbox.py` and `repl.py`.

**Path events:**
- Covered events: `open`, `os.listdir`, `os.scandir`, `os.chdir`, `os.rename`, `os.remove`, `shutil.copyfile`, `shutil.copytree`, `glob.glob`, `os.walk`, `os.symlink`, `os.link`.
- A call raises `PermissionError` if the path matches a denied pattern. The path is checked both as given and after `os.path.realpath`, which catches relative paths after a `chdir` and symlinks.
- Denied patterns (lower-cased substring): `/kaggle/input` and `solution`. They can be overridden with the env `Q27_DENY_PATHS`.

**Blocked outright:** `subprocess.Popen`, `os.system`, `os.exec*`, `os.spawn*`, `os.posix_spawn`, `os.fork`, `socket.connect`.

**Second layer:** the regex detector (`file_access_suspicious_tasks`) is kept as a report-only signal.

**Tested** (`test_v16_local.py` §1):
- Each of 11 escape routes is denied in the sandbox: `open`, `builtins.open`, `io.open`, `os.open`, `pathlib`, `listdir`, `scandir`, relative path after `chdir`, `symlink`, `subprocess`, `os.system`.
- Two routes are denied in the python tool.
- numpy and reading a non-denied file still work.

**Known residual gaps** (we judge them very unlikely in model-written ARC code, but please assess):
- `ctypes` / `cffi` calling libc directly.
- `/proc/self/...` tricks.
- `mmap` of an already-open fd.
- Paths built from fds.

We did not use namespaces or containers because there is no root and no internet on Kaggle.

**Hidden run:** the hidden test answers do not exist on disk, so this protects only the *evaluation* score's integrity.

## 3. HYBRID and budget (your #1, #2, #10)

### Time split
- The agent runs until `agent_frac` of the remaining time:
  - rerun: 0.5;
  - eval commit run: 0.6, set by env `Q27A_AGENT_FRAC`;
  - EVAL_HOURS defaults to 2.0.
- After that, **every task without a verified program** gets a DIRECT answer:
  - `rescue.py`, which calls `run_direct.answer` from the source notebook;
  - xhigh effort, `thinking_token_budget` 32,768, plus 4,096 answer tokens;
  - one no-thinking commit call if the answer is cut.
- The rescue runs 16 tasks concurrently, cheapest prompts first.
- It does not start a task with less than 300 s left.

### Merge
For each test input the two attempts are chosen in this order: verified grids (voted) → direct grid → unverified grids (most train pairs right) → test input, without duplicates.

### Where it is implemented
- **Rerun** (`run_submit.py`): `submission.json` is rewritten atomically after every agent attempt and every rescue answer, under one lock.
- **Commit run** (`run_eval.py`): `rescue_all=True`, so DIRECT also runs on verified tasks. The report then gives:
  - `agent_only_official_pct`, `direct_only_official_pct`, and `official_score_pct` (the HYBRID policy that is deployed);
  - `complementarity`: agent_only / direct_only / both hits, rescue statuses and tokens.

### Two-tier caps
- `attempt_caps` = [24,000 scout, 36,000 deep]. The deep attempt runs only if the scout did not verify.
- It overrides the old 60k single cap and is the same in eval and rerun, so EVAL12 now uses the hidden-run per-task budget (your §8 normalization point).
- You suggested 12–18k for the scout; we chose 24k because the agent's real tokens per solve are unknown. Please comment.

### Circuit breaker
- If the first 6 finished attempts all have 0 generated tokens and an `HTTP …` note (run 1's exact signature), `ABORT` stops all agent loops.
- The time then goes to the rescue.

### Nonportable names (#10)
`train_inputs`, `train_outputs` and `test_inputs` exist only inside the python tool. Two checks now handle them:
- **In `repl._absorb`:** functions that use these names are never kept (an older copy with the same name is dropped), and the model is told why.
- **In `repl_agent.verify`:** a submit whose full source (after `with_kept`) uses them is rejected with precise feedback before it reaches the sandbox.

The checks were tested both ways: portable kept helpers still work.

### Smoke (#11)
- The v1.5 `agent_params` probe is unchanged. It sends the agent's exact effort, sampling and budget with `max_tokens=32`.
  - We checked vLLM v0.19.0's source: `thinking_token_budget` is never compared with `max_tokens` (see `sampling_params.py` and `ThinkingTokenBudgetLogitsProcessor`).
  - So the probe cannot fail just because budget > max_tokens.
- The new `rescue_params` probe tests the rescue's two request shapes. It is informational and does not fail the smoke.

## 4. Status of every point in your previous audit

| # | Your point | v1.6 status |
|---|---|---|
| P0-A | Agent unmeasured on GPU | **Open:** that is what this run measures. Run 1's cause was fixed in v1.5. The breaker limits the damage from any similar error. |
| P0-B | Filesystem isolation | **Done** with an audit hook (§2). It is not a container; residual gaps are listed. |
| 1 | Budget / coverage | **Partly done:** two-tier caps and the agent/rescue time split. **Not done:** a global token ledger (your Patch C). The deadline-based split bounds time but not tokens. |
| 2 | No DIRECT fallback | **Done:** HYBRID with merge and the three-way report. |
| 3 | Train-fit ≠ test-correct | **Measured only:** `verified_but_wrong_tasks` is in the report. **Not done:** leave-one-out validation and a critic. |
| 4 | DIRECT token budget | The rescue uses 32k instead of 49k. **Not done:** a matched 8k/16k/32k/49k A/B. |
| 5 | DIRECT attempt_2 wasted | **Partly done** in HYBRID: attempt_2 is now an agent candidate when one exists. Not an independent second hypothesis. |
| 6 | Candidate diversity | **Not done.** |
| 7 | DIRECT without verification | **Not done** (HYBRID ranks verified programs above direct answers). |
| 8 | Context trimming | **Not done.** |
| 9 | Per-turn cap / forced submit | **Not done.** `force_submit_after` still counts python calls. |
| 10 | Nonportable retained functions | **Done** (§3) and tested. `train` was not added to the blocked names: it is not a tool global, and blocking it would reject ordinary variables. |
| 11 | Smoke vs actual request | **Partly done:** rescue probe added. **Not done:** your Patch B, a bounded end-to-end xhigh + 8192 tool turn in the smoke. |
| 12 | Grid format | **Not done.** |
| 13 | TTT | **Not done** (deprioritised, as you advised). |
| §8 | Per-attempt record schema / holdout set | Partly done (per-attempt records already contain most fields). No holdout. |

## 5. Questions for you

1. Should Patch B (a real xhigh + 8192 + tools turn in the smoke) be **mandatory before** this run? Or is the breaker plus the 32-token parameter probe enough?
2. Is `agent_frac` 0.6 on EVAL12 (about 70 min agent, about 45 min rescue) enough for the agent to show its real verified rate with 16-way concurrency and 24k/36k caps?
3. For the hidden run, is 0.5 sensible before we have data? Should the rescue be ordered differently, for example tasks that had no agent attempt at all first?
4. Is 32k thinking for the rescue a reasonable middle point? DIRECT at 49k: natural completions 4/7 correct (runs 4 + 7), forced completions 1/37.
5. Anything in `run_submit.py`'s HYBRID path that could leave `submission.json` worse than the agent alone? For example a lock-order issue or a stale merge.

## 6. Constraints, so suggestions stay actionable

- Same model (Qwen3.8-27B-FP8), same engine (vLLM 0.19.0 offline wheelhouse plus the transformers overlay), 4×L4.
- No internet during runs.
- The notebook must stay dual-mode:
  - a commit run evaluates EVAL12 and writes a report;
  - a competition rerun solves the hidden test and writes `submission.json`.
- Agent stop at 11 h 35 min; process cut at 11 h 50 min.
