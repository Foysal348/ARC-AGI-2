# Q27-AGENT v1 — audit bundle (2026-10-11)

**Please audit `notebook/Q27-AGENT-v1.ipynb` before we spend a 2.5 h commit run and a 12 h hidden-test submission on it.**
We want concrete bugs (cell, line, failure scenario) and concrete risks that would waste a run or lose score.
Everything below can be checked against the files in this zip.

## 1. Goal and context
- **Competition:** Kaggle "ARC Prize 2026 – ARC-AGI-2". Kaggle 4× NVIDIA L4 (sm89, 22 GB each), no internet, 12 h per hidden-test rerun. Scoring now takes 1–1.5 days (queue ~33 h), and only one pending submission is allowed.
- **Model (fixed):** Qwen3.8-27B-FP8, Kaggle model `foysalemonshanto/qwen3-8-27b-fp8-repacked-v1/PyTorch/hf-fp8/1`.
- **Our best result with this model is LB 18.75.**
  - Notebook `foysalemonshanto/q27-xhigh` v1.4, a direct answer: think up to 49k tokens, then write the grid. One sample per test input.
  - Its successor v1.4.4 is included in `baseline_q27_xhigh/` and is pending on the LB.
  - On our 12-task evaluation subset (EVAL12) v1.4.4 got 3/22 queries (`baseline_q27_xhigh/run7_v144_eval12_run_report.json`).
- **Target: LB 60+ with this same model.**
  - 7 teams are above 60 (`evidence/leaderboard_top50_2026-10-11.csv`); most of them jumped on Oct 8–9.
  - The Kaggle discussions attribute the jump to **Qwen3.8-27B agents / coding agents** (`evidence/kaggle_discussions_*.txt`).
  - One user reports 80 % on the 120 public evaluation tasks with Qwen3.8-27B locally, and LB 26.81.

## 2. Where the code and ideas come from (provenance)
| What | Source | Link |
|---|---|---|
| Agent package (cells 1–10, verbatim; cell 11 + 4 lines) | Public notebook **madarshbb / "ARC Qwen 3.8 27B agent"**; its own docstrings say the REPL agent is "modelled on the Tufa Labs duck harness", with options from "dfranzen's ARC-AGI-3 fork of the duck harness". | https://www.kaggle.com/code/madarshbb/arc-qwen-3-8-27b-agent (copy in `source_notebook/`) |
| Evidence that this source notebook scored | Discussion 748082 (author post, 2026-10-11): "Scored about 15 with this notebook using qwen 3.8 27b". | https://www.kaggle.com/competitions/arc-prize-2026-arc-agi-2/discussion/748082 |
| What the source's submitted config was | `mode: "direct"` (its cell 0 / cell 12): direct answers, 2 samples, xhigh, thinking budget 40,960. **Its REPL mode is in the code, but we have no evidence it was submitted or measured on L4.** | `source_notebook/` |
| Leaders = LLM agents | Discussions 746149 ("juicing qwen 27b … engineering"), 742796 ("LLM-agent is all you need"), 745787 (Qwen 3.8 token speed) | https://www.kaggle.com/competitions/arc-prize-2026-arc-agi-2/discussion/746149 · …/742796 · …/745787 |
| Queue / "Kaggle Error" | Discussion 747515 (Kaggle staff): queue ~33 h, pending-submission limit | …/discussion/747515 |
| Leaderboard snapshot | Kaggle API, 2026-10-11 | https://www.kaggle.com/competitions/arc-prize-2026-arc-agi-2/leaderboard |
| Public notebooks (none above ~34) | Kaggle API list sorted by score/recent/votes | `evidence/kaggle_public_notebooks_by_score_2026-10-11.txt` |
| Serving wheels (transformers 5.8.0, huggingface_hub 1.5.0) | Kaggle dataset `keithtyser/taaf-duck-qwen38-serving-v1` (public; keithtyser is on team "ARC Raiders", LB 58.75) | https://www.kaggle.com/datasets/keithtyser/taaf-duck-qwen38-serving-v1 |
| vLLM 0.19 wheelhouse | Kaggle dataset `mirzamilanfarabi/arc3-vllm-h100-wheelhouse-v3` (the same one our 18.75 notebook uses) | https://www.kaggle.com/datasets/mirzamilanfarabi/arc3-vllm-h100-wheelhouse-v3 |
| Dual-mode rule, deadlines, fallback | Our own conventions, also used in the 18.75 notebook | `baseline_q27_xhigh/Q27-XHIGH-v1_4_4.ipynb` |

**We found no public link to the Tufa Labs harness itself.** It is named only inside the source notebook's comments.

`provenance/cell_provenance.txt` proves which cells are identical to the source (sha256), and shows the only diff (submit_main.py).

## 3. What the notebook does
- **cell 1** (verbatim): writes a valid fallback `submission.json` (test input in both attempts) and the start epoch.
- **cells 2–10** (verbatim) write the agent package to `/kaggle/working/agent/`:
  - `grids.py` — grid text and diffs;
  - `sandbox.py` — runs `transform` programs in subprocesses with a timeout and memory cap;
  - `backend.py`;
  - `agent.py` — aggregation and scoring;
  - `repl.py` — the `python` tool, with preloaded numpy grids and helpers, plus function retention;
  - `client.py` — an OpenAI-compatible client that also recovers qwen3_coder tool markup;
  - `repl_agent.py` — the agent loop: tools, verify against train examples, cell diff, nudges, forced submit, effort ladder, context trim with hysteresis, degenerate-loop guard;
  - `run_direct.py`;
  - `run_submit.py` — the hidden-test runner; the submission is rewritten as each attempt finishes.
- **cell 11** `submit_main.py` (source plus a dispatch):
  - installs the wheelhouse with `--target`;
  - installs the overlay wheels;
  - starts the vLLM OpenAI server with a ladder of option sets: MTP + fp8 KV + `--reasoning-config` first, then plain;
  - runs `run_eval` (commit run) or `run_submit` (rerun);
  - never raises, and kills the server's process group at the end.
- **cell 12** `run_eval.py` (**new**): the REPL agent on the evaluation tasks.
  - Scores with the source's own `to_submission` and `score`.
  - Writes `/kaggle/working/agent_eval/eval_report.json`, `attempts.jsonl` (with transcripts) and `eval_submission.json`.
  - Never touches `submission.json`.
- **cell 13** (**new**, replaces the source's launch cell): builds the config and calls `submit_main.py` in a subprocess with a timeout.
  - **Rerun:** `deadline_epoch = START + 12 h − 25 min` (the agent stops at 11 h 35 min). The subprocess is cut at deadline + 15 min = 11 h 50 min.
  - **Commit / interactive:** `eval=True`, the 12 EVAL12 task ids (the same as our 3/22 direct baseline), `deadline = START + 2.5 h`. Override with env `Q27A_EVAL_HOURS` / `Q27A_EVAL_TASKS`.
- **cell 14** (verbatim): the last line of defence. Any malformed submission row is replaced by the fallback.

**Agent configuration (our choices; please review them):**
- Attempts and concurrency: `attempts 2`, `concurrency 16`, server `max_num_seqs 16`, `max_model_len 81920`.
- Sampling: `temperature 0.6`, `top_p 0.95`, `top_k 20`.
- Reasoning per turn: `template_kwargs.reasoning_effort "high"`, `thinking_token_budget 8192` (per request), `max_tokens = turn_max_tokens 12288`.
- Turns and context: `max_turns 40`, `context_budget 28000`, `keep_recent 6`, `trim_drain 6000`.
- Harness options: `nudge_every 6`, `in_python True`, `force_submit_after 10`, `effort_ladder ["medium","low"]`, `retain_functions True`, `degenerate_guard True`, `timeout_as_cut True`, `snippet_timeout 30`.
- Token caps:
  - Rerun: `tok_per_s 300`, so the per-attempt cap is `clamp(300 × available_s / n_tasks × 1.3, 15000, 60000)`.
  - Eval: `eval_cap 60000`.

## 4. Local verification (Windows CPU, no GPU, no server)
- Every code cell parses. `%%writefile` cells are checked as Python.
- **`tests/test_agent_local.py`** runs `run_eval.main` with a scripted mock client on 3 real evaluation tasks (`tests/data/`).
  - Task A: a `python` call, then a submit that reproduces every example → verified, score 1.0.
  - Task B: identity submits plus one cut turn (`finish_reason=length`) → 0.
  - Task C: plain text, no tool → hint path, turn budget, 0.
  - An unknown task id is dropped.
  - **PASS** (`tests/outputs/test_agent_local.txt`).
- **`tests/test_submit_local.py`** runs the rerun path (`run_submit.main`, mode repl) with the mock client.
  - `submission.json` has every task and every test input.
  - The verified answer is attempt_1, and a task with no program keeps the fallback.
  - **PASS** (`tests/outputs/test_submit_local.txt`).
- Both tests: `python tests/test_agent_local.py notebook/Q27-AGENT-v1.ipynb tests/data`. The second test imports the first from the same folder.
- **Not testable locally:**
  - the real vLLM server on L4 in tool-calling mode (qwen3_coder parser + overlay wheels);
  - `--reasoning-config` / `thinking_token_budget` behaviour;
  - real model behaviour as an agent;
  - throughput;
  - the docker image.

## 5. Questions for the audit
1. **Server on L4 in tool mode.** The source's server code ran on the hidden test only in direct mode (~15). In REPL mode the requests carry `tools` with `tool_choice auto` (or forced `submit`).
   - Any reason the ladder (`--enable-auto-tool-choice --tool-call-parser qwen3_coder --reasoning-parser qwen3 --reasoning-config … --language-model-only`, MTP `qwen3_5_mtp`) would fail or degrade with tools on vLLM 0.19?
   - Does the client's markup recovery cover the gaps?
2. **Budget sanity.** The token supply on 4×L4 is roughly 275–370 tok/s aggregate with 16 running (our measurement, direct mode); prefix-cache hit rate was 57–79 %.
   - With 240 hidden tasks × up to 2 attempts × cap ≤ 60k, plus attempt-major ordering, is the configuration sensible?
   - Should attempt 2 exist at all, or should it start only for tasks without a verified first attempt (currently both attempts of a task can run at once when workers are free)?
3. **Agent parameters** (§3). Are `reasoning_effort high` with an 8k thinking budget per turn, 40 turns, a 28k context, and the nudge/force settings reasonable for Qwen3.8-27B? What would you change first?
4. **Eval-mode design.** Is 12 tasks × 2 attempts in 2.5 h a meaningful comparison against the direct baseline (3/22 queries on the same tasks)?
5. **Deadlines.**
   - The rerun agent deadline is 11 h 35 min; requests are allowed to run until deadline + 60 s; the subprocess is cut at 11 h 50 min; then cell 14 runs.
   - Is anything able to overrun 12 h, or to leave `submission.json` half-written? It is written atomically with `os.replace`.
6. **Anything in the verbatim source code that is buggy or unsafe for a 12 h rerun:** thread safety of `on_done` / `write_atomic`, sandbox memory caps, `pip install --target` time, the server start timeout of 1500 s per rung × 6 rungs.
7. **Docker image.** We plan to pin the source notebook's image (`kernel-metadata.json`: `…57e612b4…`), not ours (`…37c64f7d…`, used for LB 18.75). Is that right?

## 6. Files
- `notebook/Q27-AGENT-v1.ipynb` — the notebook to audit.
- `build/make_q27_agent.py` — builds it from `source_notebook/`.
- `provenance/cell_provenance.txt` — cell-by-cell identity check and diff.
- `source_notebook/` — madarshbb's notebook and its `kernel-metadata.json` (inputs and docker image).
- `tests/` — the two local tests, their outputs, and `data/` (public evaluation challenges and solutions).
- `evidence/` — leaderboard top 50, discussion texts (748082, 742796, 746149, 747515, 745787), topic list, public notebook list.
- `baseline_q27_xhigh/` — our direct-mode notebook v1.4.4 and its EVAL12 run report (3/22).
