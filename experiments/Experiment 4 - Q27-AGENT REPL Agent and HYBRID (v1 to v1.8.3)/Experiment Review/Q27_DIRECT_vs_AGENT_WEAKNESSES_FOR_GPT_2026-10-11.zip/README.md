# Two Qwen3.8-27B notebooks for ARC-AGI-2 (Kaggle 2026): weaknesses and how to fix them

**What we ask:**
1. Read both notebooks and the evidence.
2. List their **weaknesses**, ranked by expected effect on the Kaggle leaderboard score.
3. For each weakness, propose a **concrete fix backed by sources**: Kaggle discussions, public GitHub code, papers, Hugging Face traces, or vLLM documentation. Give links and quotes, and say what has been *measured* versus *claimed*.

Everything below can be checked against the files in this zip.

## 1. Goal and hard constraints
- **Competition:** Kaggle "ARC Prize 2026 – ARC-AGI-2", https://www.kaggle.com/competitions/arc-prize-2026-arc-agi-2. The deadline is 2026-11-02.
- **Our target is LB ~60 with Qwen3.8-27B.** Seven teams are already above 60 (`evidence/leaderboard_top50_2026-10-11.csv`: Tufa Labs 88.06, rabbithole 80.56, Yi-Chia Chen 77.22, nvbanana 77.08, _hans 69.03, ALbert RUehlman 67.36, Dawid Kopiczko 62.92), and most of them jumped on Oct 8–9. **Please do not tell us 60 is unreachable.** Tell us *how* the gap closes.
- **Fixed constraints:**
  - Model: Qwen3.8-27B-FP8, Kaggle model `foysalemonshanto/qwen3-8-27b-fp8-repacked-v1`.
  - Hardware: Kaggle 4× NVIDIA L4 (sm89, 22 GB each).
  - No internet in the scoring run; 12 h wall time per rerun.
  - Hidden test: 240 tasks with 259 test inputs; public and private are scored from one `submission.json`.
  - Engine: vLLM 0.19.0 from the offline wheelhouse `mirzamilanfarabi/arc3-vllm-h100-wheelhouse-v3`.
  - One submission per day, and one pending submission at a time. The Kaggle queue is currently about 33 h (discussion 747515), so an LB result takes about 1.5 days. **Most experiments must therefore be evaluated in our own commit runs on evaluation tasks.**
- **Metric:** fraction of test outputs where attempt_1 or attempt_2 is exactly right.

## 2. The two notebooks
| | **DIRECT: `notebooks/DIRECT_LB18.75_Q27-XHIGH-v1_4.ipynb` (LB 18.75)** | **AGENT: `notebooks/AGENT_Q27-AGENT-v1_5.ipynb` (not scored yet)** |
|---|---|---|
| Method | Direct answer: one prompt per test input; the model thinks, then writes the grid. | REPL tool agent (python + submit): explore with a `python` tool (numpy grids and helpers preloaded), then `submit` a `transform(grid)` program. It is verified on the train pairs, with a cell diff as feedback. |
| Origin | Our own. | Agent package copied from the public notebook https://www.kaggle.com/code/madarshbb/arc-qwen-3-8-27b-agent (`source_notebook/`). Its docstrings say "modelled on the Tufa Labs duck harness" and mention options "from dfranzen's ARC-AGI-3 fork". The author's ~15 LB came from its **direct** mode, not the agent (discussion 748082). |
| Thinking | xhigh, up to 49,152 thinking tokens in one turn (forced close), then an 8,192-token answer. | xhigh per turn with `thinking_token_budget` 6,144 and max 8,192 tokens per turn, up to 30 turns, 60k tokens per attempt. Effort ladder after a cut turn: medium, then low. |
| Samples / attempts | 1 sample per test input. attempt_1 = the model's grid; attempt_2 = the test input or its mirror (almost never right). | Up to 2 attempts per task; the second is queued only if the first did not verify. Answers: verified programs vote; otherwise the best unverified program (most train pairs right); otherwise the test input. |
| Engine | vLLM offline `LLM` with the step API, TP4, fp8 KV, MTP 3, FlashInfer (libcuda shim), `max_num_batched_tokens` 4096, 16 sequences, GPU 0.90, no prefix caching. | vLLM OpenAI server with the same model and wheelhouse, plus `keithtyser/taaf-duck-qwen38-serving-v1` (transformers 5.8 overlay), tool parser `qwen3_coder`, reasoning parser `qwen3`, fp8 KV, MTP 2, prefix caching, 4096 batched tokens, 16 sequences. Before starting, every server rung must pass a real tool smoke test (forced, auto, thinking, a roundtrip python → tool result → submit, and the agent's exact request parameters). |
| Hidden-run timing | 12 h budget; admit until 10 h 30, drain at 11 h 06, hard stop at 11 h 35. | Agent deadline 11 h 35; process cut at 11 h 50. |
| Commit run | EVAL12: 12 public evaluation tasks, 22 test outputs. | The same EVAL12 tasks. |

`notebooks/DIRECT_successor_Q27-XHIGH-v1_4_4_pendingLB.ipynb` is v1.4 plus prefix caching plus later admission (until 11 h 34). It is still pending on the LB.

## 3. Measured evidence (our own runs, in `runs/`)
**DIRECT, run 4 (v1.4, EVAL12): 2/22.**
- 18 of 22 queries were force-closed at 49k thinking tokens.
- The 4 that finished naturally were 2 exact and 2 one cell off.
- Throughput was about 373 tok/s with 16 running and 248.9 tok/s over the whole run; re-prefill took about 12 % of the time.
- See `runs/direct_run4_v1_4/OUR_ANALYSIS.md`.

**DIRECT, run 7 (v1.4.4): 3/22 = 13.6 %.**
- 19/22 were forced at 49k; mean thinking was 47.4k tokens.
- Throughput was 274.6 tok/s; prefix-cache hit rate 57 %.
- The projection for the hidden test was about 12.9 h, so the hidden run always runs to its deadlines.

**DIRECT on the LB: 18.75.** The direct method generalises better on the hidden test than EVAL12 suggests.

**AGENT, run 1 (v1.4 on Kaggle):**
- **The infrastructure passed:**
  - libcuda link probe PASS;
  - server rung 0 (MTP 2 + fp8 KV + reasoning-config) up in 490 s;
  - every smoke stage OK in 64 s, including the roundtrip and the accepted 6,144 budget.
- **Every agent request then failed with HTTP 400:** the chat template rejects `reasoning_effort: "high"` (only xhigh / medium / low exist).
  - This was our config error, fixed in v1.5.
  - The client's budget-drop heuristic also misfired on that error, and that is fixed too.
- **So no agent-quality or throughput number exists yet.** See `runs/agent_run1_v1_4/`.

**Local CPU tests of the agent (mock LLM): all PASS** (`agent_build/tests/outputs/`). They cover parser cases, request caps, phased attempts, the official metric, the validator, smoke modes, the ladder and concurrency. They prove the plumbing, **not** reasoning quality.

## 4. Weaknesses we already see — please confirm, refute, rank, add to, and solve
**DIRECT notebook:**
1. **The token budget is the binding limit.** About 85 % of queries are cut at 49k thinking tokens, and forced answers are rarely right. ARC Prize reports 42.4 % semi-private for Qwen3.8-27B xhigh at about 175k tokens per task with 2 attempts (discussion 745787); we can afford about 50k per task on 4×L4 in 12 h.
2. **attempt_2 is wasted** (test input or mirror).
3. **There is no verification.** A wrong grid cannot be detected or corrected.
4. Prompt and layout: space-separated digit rows. Is this the best layout for this model?

**AGENT notebook:**
1. **Unmeasured on real hardware.** We do not know its turns per task, tokens per turn, verify rate or throughput.
2. **No answer when no program is found.** The task falls back to the test input, whereas DIRECT always writes a grid. A hybrid (agent first, direct answer for unverified tasks) is not built.
3. **Verification uses train pairs only.** A program can fit train and still be wrong on test (overfitting). Voting happens only among verified programs.
4. **Per-turn thinking cap of 6,144 with xhigh.** It may cut reasoning on hard tasks, and may leave only 8–9 turns per attempt within 60k. Are these numbers sensible?
5. **Budget and coverage.** 240 tasks × up to 2 attempts in about 11 h at an unknown agent throughput; tasks never reached keep the fallback. The rerun cap is supply/n per attempt.
6. **Context trimming** (28k budget, hysteresis) may drop useful history. Retained helper functions that use preloaded names (`train_inputs`) fail inside the submit sandbox (the model sees a `NameError`).
7. **Generated code runs without filesystem isolation.** On evaluation tasks it could read the public solutions file. We only detect this with a regex.
8. **One sample per turn at temperature 0.6, and no diversity mechanism** (no evolution, recombination, or best-of-k across attempts).
9. **No test-time training**, and no use of the 4B NVARC-style models that score about 30 LB on their own. We want to stay on Qwen3.8-27B, but tell us if combining is what top teams do.

## 5. What we want back (format)
For each weakness, in the order of expected LB impact:
- **Evidence:** links with dates and quotes from Kaggle discussions, GitHub repos, papers, HF datasets or docs; mark each **measured** or **claimed**.
- **Fix:** concrete enough to implement in these notebooks (parameters, code changes, prompts, scheduling), with the expected cost in tokens and time on 4×L4 / 12 h.
- **How to validate it** in a ~2.5 h EVAL12 commit run before spending a 1.5-day LB submission.
- Then a **plan to reach ~60**: which changes to make first, in which notebook (direct, agent, or a hybrid), and why.

Please stay within the constraints in §1 and do not propose a different model or engine for the scoring run. Point out anything in the code you think is a bug.

## 6. Sources we know of (verified links unless marked)
**Kaggle:**
- Competition and leaderboard: https://www.kaggle.com/competitions/arc-prize-2026-arc-agi-2/leaderboard
- Discussions:
  - 748082 "Qwen3.8-27B / Flash-Next: ARC-AGI-2 results within Kaggle's compute limits?" — https://www.kaggle.com/competitions/arc-prize-2026-arc-agi-2/discussion/748082 (one user: 27B = 80 % on the 120 public eval tasks locally, LB 26.81; madarshbb's notebook ~15).
  - 746149 "Can we prune strongest open source models…": "juicing qwen 27b … engineering" is what drove the score jump. https://www.kaggle.com/competitions/arc-prize-2026-arc-agi-2/discussion/746149
  - 742796 "LLM-agent is all you need" — https://www.kaggle.com/competitions/arc-prize-2026-arc-agi-2/discussion/742796
  - 745787 "Qwen 3.8 token generation speed": NguyenThanhNhan reports LB 23.33 with pure reasoning in SGLang (EAGLE, radix cache, forced commit at 49k). https://www.kaggle.com/competitions/arc-prize-2026-arc-agi-2/discussion/745787
  - 747515: Kaggle staff on the queue and the pending limit. https://www.kaggle.com/competitions/arc-prize-2026-arc-agi-2/discussion/747515
  - Full texts are in `evidence/`.
- Agent source notebook: https://www.kaggle.com/code/madarshbb/arc-qwen-3-8-27b-agent
- Serving wheels: https://www.kaggle.com/datasets/keithtyser/taaf-duck-qwen38-serving-v1 (keithtyser is on team "ARC Raiders", LB 58.75). The dataset also contains `src/ARC3-Inference/` (an ARC-AGI-3 agent harness) — worth inspecting.

**GitHub / web**, from `evidence/ARC_AGI_2_High_Score_Systems_sources_2026-10-06.pdf`; mostly API-model systems, but their *methods* may transfer:
- Stateful REPL agent; GPT-OSS-120B open weights 26.39 %: https://github.com/gutfeeling/arc-agi-2-submission · traces https://huggingface.co/datasets/arcagi2/arcagi2-agentic-coding-publication · write-up https://pivotools.github.io/pivotools-quarto-blog/posts/agentic_coding_arc_agi/
- REPL program synthesis plus sub-agents: https://github.com/symbolica-ai/arcgentica
- Evolution over program populations (Kimi K2.5 open weights 34 %): https://github.com/imbue-ai/darwinian_evolver
- Reasoner plus validator plus judge: https://github.com/noemon/noemon-arc-agi
- Multi-agent program synthesis with voting: https://github.com/confluence-labs/arc-agi-2
- Verified artifact exchange: https://github.com/dastin359/athanor
- Multi-model judge (ARC Prize verified 72.9 %): https://github.com/beetree/ARC-AGI
- Task data: https://github.com/arcprize/ARC-AGI-2 · verification policy: https://arcprize.org/leaderboard/community
- **Tufa Labs' harness:** named only inside the source notebook's comments. We found no public link — please search.

## 7. Files
- `notebooks/` — DIRECT (LB 18.75) with its kernel metadata; DIRECT successor v1.4.4; AGENT v1.5.
- `agent_build/` — the AGENT builder (rebuilds the AGENT notebook from `source_notebook/`), local tests, their outputs, and the public evaluation data used by the tests.
- `source_notebook/` — madarshbb's public agent notebook.
- `runs/` — DIRECT run 4 and run 7 reports and records; AGENT run 1 server report, eval report and logs.
- `evidence/` — leaderboard top 50, discussion texts, topic list, public notebook list, the sources PDF.
