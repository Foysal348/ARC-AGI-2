"""E33 scripted scheduler tests. No GPU/server; use monkeypatch for Duck agent and external hooks."""
import importlib.util, os, time, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parent
FILE=Path(os.environ.get('E33_POST_FILE',ROOT/'E33_arc2_duck_post.py'))
spec=importlib.util.spec_from_file_location('e33_tested',FILE)
M=importlib.util.module_from_spec(spec);spec.loader.exec_module(M)

class FakeSession:
    script={}
    def __init__(self,agent_cls,*,task_id,task,branch,**kw):
        self.tid=task_id;self.branch=branch;self.record=None;self.status='new'
    def run(self,**kw):
        self.record=dict(self.script.get((self.tid,self.branch),{}))
        self.status='done'
    def write(self):
        r=dict(self.record or {})
        return dict(r,task_id=self.tid,branch=self.branch,status='done',
                    generated_tokens=int(r.get('generated_tokens',50)),submissions=r.get('submissions',[]))

def rec(pass_=False,tokens=50,grid=None):
    sub=[{'accepted':pass_,'train_exact':[pass_], 'test_outputs':[grid or [[1]]]}]
    return {'generated_tokens':tokens,'submissions':sub}

class E33Tests(unittest.TestCase):
    def setUp(self):
        self.env=dict(os.environ)
        os.environ.update(E28_SCHED='1',E33_SCHED='1',E33_POETIQ='1',E33_DIRECT='1',E33_ATTEMPT2='1')
        self.original=(M.BranchSession,M.E33_RUN_POETIQ,M.E33_RUN_DIRECT,M.E33_CAN_START,M.E28_TRY_RESERVE,M.E28_RELEASE)
        M.BranchSession=FakeSession;FakeSession.script={}
        M.E28_TRY_RESERVE=None;M.E28_RELEASE=None
        self.hook_events=[]
        def poi(tid,task,plan,deadline,base_url,model_id,out_dir,iteration,prior):
            self.hook_events.append((tid,plan['attempt'],iteration,prior is not None))
            return {'task_id':tid,'poetiq':{'train_pass':False,'score':.5,'iteration':iteration},**rec(False)}
        def direct(tid,task,plan,deadline,base_url,model_id,out_dir):
            self.hook_events.append((tid,plan['attempt'],'E',False))
            return {'task_id':tid,'e31':{},**rec(False,grid=[[7]])}
        M.E33_RUN_POETIQ=poi;M.E33_RUN_DIRECT=direct;M.E33_CAN_START=lambda stage,dl:True
        self.task={'train':[{'input':[[0]],'output':[[1]]}],'test':[{'input':[[0]]}]}
        self.temp=tempfile.TemporaryDirectory()
    def tearDown(self):
        M.BranchSession,M.E33_RUN_POETIQ,M.E33_RUN_DIRECT,M.E33_CAN_START,M.E28_TRY_RESERVE,M.E28_RELEASE=self.original
        os.environ.clear();os.environ.update(self.env)
        self.temp.cleanup()
    def run_sched(self,tasks=None,order=None,workers=1):
        tasks=tasks or {'t':self.task};order=order or list(tasks)
        return M._e28_solve_all(tasks,order,out_dir=Path(self.temp.name),
                  deadline=time.monotonic()+100,base_url='fake',model_id='fake',
                  workers=workers,min_admit_sec=0,agent_cls=object)
    def test_full_sequential_chain_and_branch_uniqueness(self):
        out=self.run_sched(); seq=M.SCHED_LAST['e28']['e33']['sequence']
        self.assertEqual([s[2] for s in seq[:5]],['A','B1','C','D','E'])
        self.assertEqual([s[1] for s in seq[:5]],[1]*5)
        self.assertEqual([s[2] for s in seq[5:]],['A','B1','C','D','E'])
        self.assertEqual(len({r['branch'] for r in out['t']}),10)
        self.assertEqual(sum(M.SCHED_LAST['e28']['e33']['release_counts'].values()),10)
    def test_train_pass_stops_chain(self):
        FakeSession.script[('t',0)]=rec(True)
        FakeSession.script[('t',1)]=rec(True)
        out=self.run_sched();self.assertEqual(len(out['t']),2)
        self.assertEqual([r['e33']['stage'] for r in out['t']],['A','A'])
    def test_a_cap_b2(self):
        FakeSession.script[('t',0)]={'generated_tokens':120000,'nb5_verdict':'BUDGET_LIMITED'}
        out=self.run_sched(); self.assertIn('B2',[r['e33']['stage'] for r in out['t']])
    def test_no_hook_skip_terminates(self):
        M.E33_RUN_POETIQ=None
        out=self.run_sched(); self.assertTrue(all(r['e33']['stage'] not in ('D','E') for r in out['t']))
        self.assertEqual(sum(1 for r in out['t'] if r['e33']['stage']=='C'),2)
    def test_hook_exception_skip(self):
        def bad(*a):raise RuntimeError('broken')
        M.E33_RUN_POETIQ=bad
        out=self.run_sched();self.assertEqual(sum(r['status']=='skipped' for r in out['t']),2)
    def test_false_admission_skip(self):
        M.E33_CAN_START=lambda stage,dl:False
        out=self.run_sched();self.assertEqual(sum(r['status']=='skipped' for r in out['t']),2)
    def test_attempt2_disabled(self):
        os.environ['E33_ATTEMPT2']='0'
        out=self.run_sched();self.assertTrue(all(r['e33']['attempt']==1 for r in out['t']))
    def test_d_predecessor(self):
        self.run_sched();self.assertTrue(all(p for tid,at,it,p in self.hook_events if it==2))
    def test_answer_distinct_multi_test(self):
        task=dict(self.task,test=[{'input':[[0]]},{'input':[[1]]}]);
        a={'task_id':'t','branch':0,'e33':{'attempt':1,'stage':'A'},
            'submissions':[{'accepted':True,'train_exact':[True], 'test_outputs':[[[2]],[[3]]]}]}
        b={'task_id':'t','branch':1,'e33':{'attempt':2,'stage':'A'},
            'submissions':[{'accepted':True,'train_exact':[True], 'test_outputs':[[[4]],[[5]]]}]}
        out=M.select_attempts_e33(task,[a,b]);
        self.assertEqual(out[0]['attempt_1'],[[2]])
        self.assertEqual(out[1]['attempt_1'],[[3]])
        self.assertEqual(out[0]['attempt_2'],[[4]])
        self.assertEqual(out[1]['attempt_2'],[[5]])
    def test_priority_attempt1_before_attempt2(self):
        tasks={str(i):self.task for i in range(6)}
        self.run_sched(tasks,workers=4)
        seq=M.SCHED_LAST['e28']['e33']['sequence']
        # At each dispatch, attempt 2 only starts if all eligible attempt-1 work is running.
        self.assertEqual(sorted([x[0] for x in seq if x[1]==1 and x[2]=='A']),sorted(tasks))
    def test_attempt2_group_order(self):
        FakeSession.script[('a',0)]=rec(True,tokens=200)
        FakeSession.script[('b',0)]=rec(False,tokens=30)
        FakeSession.script[('c',0)]=rec(True,tokens=20)
        tasks={t:self.task for t in ('a','b','c')}
        self.run_sched(tasks,workers=1)
        second=[x[0] for x in M.SCHED_LAST['e28']['e33']['sequence'] if x[1]==2 and x[2]=='A']
        self.assertEqual(second,['b','c','a'])
    def test_release_contract_four_workers(self):
        hooks=[]
        M.E28_RELEASE=lambda key:hooks.append(key)
        tasks={str(i):self.task for i in range(6)}
        out=self.run_sched(tasks,workers=4)
        got={(tid,r['branch']) for tid,rr in out.items() for r in rr}
        self.assertEqual(set(hooks),got)
        self.assertEqual(len(hooks),len(got))
    def test_supply_after_chain_exhausted(self):
        os.environ['E29_SUPPLY']='1'
        os.environ['E29_SUPPLY_MAX_ATTEMPTS']='12'
        result=self.run_sched()
        sequence=M.SCHED_LAST['e28']['e33']['sequence']
        first_supply=next(i for i,x in enumerate(sequence) if x[1]==0)
        self.assertTrue(all(x[1] in (1,2) for x in sequence[:first_supply]))
        self.assertTrue(all(x[1]==0 for x in sequence[first_supply:]))
        self.assertTrue(any(r['e33']['attempt']==0 for r in result['t']))
        self.assertEqual(len({r['branch'] for r in result['t']}),len(result['t']))
    def test_hooks_none_and_release_one_per_stage(self):
        M.E33_RUN_DIRECT=lambda *args:None
        M.E33_RUN_POETIQ=lambda *args:None
        out=self.run_sched()
        self.assertTrue(all(r['e33']['stage'] in ('A','B1','C') for r in out['t']))
        cnt=M.SCHED_LAST['e28']['e33']['release_counts']
        self.assertTrue(all(v==1 for v in cnt.values()))
    def test_negative_control_base_lacks_E33(self):
        bp=ROOT/'BASE__arc2_duck_E29_post.py'
        raw=bp.read_text()
        self.assertNotIn('def _e33_solve_all(',raw)
        self.assertIn('def _e33_solve_all(',FILE.read_text())
    def test_parallel_no_same_attempt_overlap(self):
        import threading
        in_flight=set();bad=[];lock=threading.Lock()
        def poi(tid,task,plan,deadline,base_url,model_id,out_dir,iteration,prior):
            key=(tid,plan['attempt'])
            with lock:
                if key in in_flight:bad.append(key)
                in_flight.add(key)
            time.sleep(.004)
            with lock:in_flight.remove(key)
            return {'task_id':tid,'poetiq':{'train_pass':False,'score':0.2},**rec(False)}
        M.E33_RUN_POETIQ=poi
        tasks={str(i):self.task for i in range(8)}
        self.run_sched(tasks,workers=4)
        self.assertFalse(bad)
    def test_off_gate(self):
        os.environ['E33_SCHED']='0'
        self.assertFalse(M._e33_on())
        refspec=importlib.util.spec_from_file_location('base_e33_control',ROOT/'BASE__arc2_duck_E29_post.py')
        ref=importlib.util.module_from_spec(refspec);refspec.loader.exec_module(ref)
        for a in ([],[{'task_id':'t','branch':0,'generated_tokens':5,'submissions':[{'accepted':True,'train_exact':[True],'test_outputs':[[[9]]]}]}]):
            self.assertEqual(M.select_attempts_e28(self.task,a),ref.select_attempts_e28(self.task,a))
            self.assertEqual(M.build_submission({'t':self.task},{'t':a}),ref.build_submission({'t':self.task},{'t':a}))

if __name__=='__main__': unittest.main(verbosity=2)
