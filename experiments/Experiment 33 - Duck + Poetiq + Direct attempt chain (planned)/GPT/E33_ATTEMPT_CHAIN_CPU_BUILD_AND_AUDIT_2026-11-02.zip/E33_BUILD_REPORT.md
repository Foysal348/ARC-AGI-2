# E33 Attempt-Chain Scheduler — CPU Build / Independent Test Report

**Date:** 2026-11-02  
**Input:** `E33_SCHEDULER_BUILD_for_GPT_FLAT_2026-11-02(1).zip`  
**Base:** `BASE__arc2_duck_E29_post.py` SHA-256 `d8603109f9530896e9e4a56e52806202fc2cd4c58bd664d9a25222fe6f7592c2`  
**Decision:** **CODE BUILD COMPLETE (conditional); production NO-GO until the original E29 scripted-Duck harness, E33 notebook hooks, and GPU smoke are verified.**

## Deliverables

- `e33_sched_build.py`: deterministic `once` edits and generated opt-in runtime tail, `make_sched(base_text, base_sha) -> (post_text, patch_text, module_text)`.
- `e33_runtime.txt`: the separately maintained new runtime tail consumed by the generator.
- `e33_sched.diff`: strict 3-line-context unified diff from the exact E29 post text.
- `e33_sched_patch.py`: SHA-pinned patch applier with `apply`, `verify`, `revert`, `tree_state`, `cell3`. Uses the supplied E28 applier's `apply_unified` / `reverse_unified` and atomic file writer.
- `E33_arc2_duck_post.py`: regenerated complete post-patch source, for inspection only. The intended deployment uses the diff.
- `e33_sched_tests.py`: 17 CPU synthetic-script tests (stdlib), including off parity with the original E29 selection code.

## Source edits

1. **Selector dispatch**, before the original E29 supply selector: only `E28_SCHED=1` **and** `E33_SCHED=1` execute `select_attempts_e33`.
2. **Scheduler dispatch**, at the start of `_e28_solve_all`: same strict opt-in gate; otherwise the entire original E29 body executes unchanged.
3. **Runtime tail**, containing E33 branch mapping, stage routing, hook admission and execution, answers, report, queue priority, capacity probe and supply logic.

**Switches:** `E33_SCHED`, `E33_POETIQ`, `E33_DIRECT`, `E33_ATTEMPT2` are each enabled only by the literal string `1`. Budget plan fields: `E33_POETIQ_THINK=60000`, `E33_POETIQ_ANSWER=8192`, `E33_DIRECT_THINK=104000`, `E33_DIRECT_ANSWER=8192`. The actual solver hooks enforce their own thinking/answer phases; the scheduler only provides plans.

## Branch ID map

| Attempt | A | B1/B2 | C Poetiq-1 | D Poetiq-2 | E Direct |
|---|---:|---:|---:|---:|---:|
| 1 | 0 | 2 | 20 | 21 | 22 |
| 2 | 1 | 23 | 24 | 25 | 26 |

Supply retains >=3, choosing the next unused branch while skipping IDs allocated to E33. Supply stage uses attempt=0 internally, so it cannot overwrite records from the two main attempt chains. The original E29 supply cap can be slightly conservative because all newly inserted method stages count towards the cap; verify this against the production notebook configuration.

## Scheduling and admission

- The worker queue is held under one condition lock. For a given task/attempt, only one stage may be running. A2 can overlap A1's later stages.
- A1 ends -> enqueue A2 (when enabled), and either B1/B2 or C of attempt 1. Each subsequent stage queues exactly one successor only when the previous stage was not train-pass and not TIME or SKIP.
- Priority: all ready attempt-1 work, then ready attempt-2 work, then supply; within an attempt the previously reservation-blocked B2 gets priority, followed by A/B/C/D/E, with attempt-2 nonpasses first and full-train-pass A2 tasks sorted by A1 generated tokens.
- KV reservation uses `E28_TRY_RESERVE((task,branch),plan)`; a rejected request is backfilled; with nothing running, the head item may be forced as in E28. Hook exceptions **fail closed** (a deliberate safety difference from E28's fail-open exception behavior). `E28_RELEASE((task,branch))` is called once for every started stage.
- `capacity_probe` KV admission threshold and stale-sample logic are implemented; this is *not* a byte-for-byte copy of the E28 instrumentation. Any important difference requires real harness testing.
- C/D/E need a callable solver hook and `E33_CAN_START(stage,deadline)` returning True. No hook, False, None or exception records a skipped stage and terminates that task/attempt chain.

## Record and answer contracts

- C/D call `E33_RUN_POETIQ(tid,task,plan,deadline,base_url,model_id,out_dir,iteration,prior_record)`. D receives the stored C record.
- E calls `E33_RUN_DIRECT(tid,task,plan,deadline,base_url,model_id,out_dir)`.
- C/D train pass requires both `poetiq.train_pass` and an accepted submission with all required test grids present and valid. Direct is always nonpassing and terminal.
- Every published record has `task_id`, `branch`, `e33` with attempt/stage/phase and terminal reason. Hook-supplied `submissions` are preserved.
- Per query, the selector ranks train-pass Duck/Poetiq, then best partial train-match Duck/Poetiq, then Direct, then legacy R5 fallbacks and the query's own input. Attempt 2 prefers its own chain if distinct from attempt 1, then a distinct attempt-1 candidate, then fallback. Only `valid_grid` outputs are eligible; output index `K` maps to test input `K`.
- `SCHED_LAST['e28']['e33']` reports per-stage queued/started/done/skipped/pass, tokens/seconds, stage reach, supply, events, KV samples, releases and errors; `SCHED_LAST['e28']['slots']` contains per-query sources.

## CPU evidence (not GPU measurements)

- Input ZIP SHA manifest: **13/13 verified**.
- `e33_sched_build.py`: generated module and complete source compile.
- Unified diff: forward and reverse verified through the actual reference `e28_sched_patch.py` functions, including **atomic file-mode apply / revert**; final bytes are identical to the pinned pre-source after revert.
- `e33_sched_tests.py`: **17/17 PASS**, covering A->B->C->D->E chain order, A1/A2 separation, A2 grouping, B2 classification, train-pass stop, no-hook/exception/late skips, D's prior record, multi-test answers, supply position and branch uniqueness, four-worker release and one-at-a-time conditions, switch-off selection parity, and an unpatched-base negative control.

## Unresolved HIGH-risk validation gaps

1. **Real Duck harness not shipped.** The supplied ZIP explicitly does not include the Duck payload and original `arc2_duck.py`/vendor tree. The 17 tests are synthetic and do **not** substitute for `REF__e29_sched_tests.py`'s actual scripted-Duck integration. In production, exercise `ST.setUpModule`, `ST._tasks`, `ST.SCRIPTS`, `ST.Env`, `ST.RunLog`, `ST._solve`, `ST._norm_recs`, `ST._norm_e28`. Verify budget/window and S1/S2 counting with the real agent.
2. **Notebook hooks not shipped or tested.** The real E18 Poetiq hook, E31 Direct hook, streamed token-ID retry, trace saving, 60k admission floor and the reworked notebook call site must be implemented and tested. A queue-side `think_cap` does not enforce a solver-side cap or preserve distribution by itself.
3. **KV accounting for new stages unknown.** E28's notebook `E28_TRY_RESERVE` may inspect `plan['phase']` and not understand `C-POETIQ1`, `D-POETIQ2`, `E-DIRECT`. Review its implementation and assign a valid projected block count before GPU use. 131k long-prefix and 24-stream pressure are especially risky on PP1.
4. **Original E28 implementation was not copied verbatim.** The separate E33 worker preserves the intended ordering, reservation, backfill, no-idle and KV threshold *semantics*, but some counters, supply concurrency and failure handling differ. Require explicit parity assertions where the spec says 'stay as they are'.
5. **Deadline stragglers.** The implementation closes publication at the join deadline and reports stragglers, but does not freeze/kill an unfinished `BranchSession` like original E28. Before production, test time-window termination and ensure the notebook's shutdown joins or terminates requests cleanly.

**Recommended next gate:** do NOT deploy this as an accepted E33 production scheduler yet. Integrate with the real payload and the E18/E31 hooks, run the full requested harness and one GPU smoke; resolve the above differences or explicitly accept them with evidence. This is an inspectable first implementation, not a GPU-validated final release.
