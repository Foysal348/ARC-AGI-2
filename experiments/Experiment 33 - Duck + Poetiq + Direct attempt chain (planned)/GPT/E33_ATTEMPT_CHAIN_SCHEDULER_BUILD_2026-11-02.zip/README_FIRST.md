# E33 attempt-chain scheduler — build artifact (2026-11-02)

## Verdict / scope
**GO for scheduler source build and CPU/fake-hook validation.** This is NOT a ready-to-submit Kaggle notebook. The E18 Poetiq runtime, E31 DIRECT runtime, actual Duck payload, complete Kaggle CPU kits, offline wheelhouse and 4x L4 GPU execution are not bundled or certified.

Read `E33_BUILD_REPORT.md` for the exact changes and limitations. Read `00_DESIGN_E33_ATTEMPT_CHAIN.md` for the user-fixed design.

## Deliverables
- `e33_sched_build.py`: once-only pinned generator; creates E33 post source, strict unified diff (`n=3`), SHA-pinned applier.
- `e33_sched.diff`: strict patch against the **E29 post** Duck source only.
- `e33_sched_patch.py`: SHA-pinned `apply`, `verify`, `revert`, `tree_state`, `cell3`.
- `arc2_duck_E33_post.py`: generated full Duck E33 post source; **not** a Kaggle notebook.
- `e33_sched_tests.py`: stdlib tests against scripted E29 Duck harness.
- `stress_e33.py`: 120-task/24-worker deterministic fake-hook stress.
- `E33_SCHED_TAIL_READABLE.py.txt`: human-readable source of the E33 extension.
- `BASE__arc2_duck_E29_post.py`, `e28_sched_patch.py`, `e29_sched_patch.py`, `e29_sched_tests.py`: exact audit/test dependencies.
- `E33_BUILD_FACTS.json`, `MANIFEST_SHA256.json`, execution logs, and this report.

## Reproduction (extract flat ZIP and run from extracted directory)
```bash
python e33_sched_build.py --base BASE__arc2_duck_E29_post.py --out ./generated
python e33_sched_tests.py -v
python stress_e33.py
```
The three generated files should match the included post source/diff/applier byte-for-byte. `git apply --check` / `git apply` / `git apply --reverse` were independently tested with `arc2_duck.py` as the target path.

## Use in notebook
1. Use the original E29 post state (`BASE__arc2_duck_E29_post.py`, SHA below), **not** the E29 DIRECT post.
2. In CELL3, apply and verify the E29 scheduler first, then call `e33_sched_patch.cell3(e12_dir, sched_rec, rec)`. Fail closed on any unexpected pre-state or SHA.
3. In the notebook, implement/test `E33_RUN_POETIQ`, `E33_RUN_DIRECT`, `E33_CAN_START`, and bind those callable globals to the patched Duck module. Configure `E33_CHAIN`, `E33_POETIQ`, `E33_DIRECT`, `E33_ATTEMPT2` as literal flags.
4. For actual evaluation, integrate the original E18 Poetiq prompt/sandbox/feedback logic and E31 Direct token-ID streaming + final-score publisher; verify the hook record schema and that every stage saves all thinking traces.
5. Re-run the complete Kaggle CPU real/e2e/commit/rerun kits on the exact notebook SHA, then GPU smoke. **Do not treat the provided fake-hook tests as GPU or full Poetiq correctness evidence.**

## Fixed identity
Base E29 post SHA256: `d8603109f9530896e9e4a56e52806202fc2cd4c58bd664d9a25222fe6f7592c2`
E33 post SHA256: `13fa1a27f815ddf8a03526ae2933fbbc89bdef7e8d325575a91ec656817e457f`
Unified diff SHA256: `bfb1414e49e44a7582dc230eff4fae34f6ea8bbe09db4d460cb6654de8656b6c`

## Validation
- 41/41 independent stdlib test cases PASS (several inherited tests exercise equivalent scenarios again).
- 120 tasks / 24 workers: 800 starts, 800 completions, 800 E28 releases; no errors, stragglers or leftover queued work.
- Strict SHA-pinned apply/revert and `git apply` forward/reverse PASS.
- Negative-control tests fail on unpatched E29 post as expected.
- No real Kaggle 4x L4 test, actual Poetiq feedback solver test, E31 server integration test or full notebook smoke is claimed.
