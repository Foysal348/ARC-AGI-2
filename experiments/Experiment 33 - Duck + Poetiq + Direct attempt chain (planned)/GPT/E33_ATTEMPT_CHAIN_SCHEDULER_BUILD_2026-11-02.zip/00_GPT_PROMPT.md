# TASK: build the E33 attempt-chain SCHEDULER for our Duck harness (`arc2_duck.py`): Kaggle ARC-AGI-2, 4×L4

**Your job.** Write the scheduler change as a strict unified diff on the base file `BASE__arc2_duck_E29_post.py` (sha256 d8603109f9530896e9e4a56e52806202fc2cd4c58bd664d9a25222fe6f7592c2). Deliver the diff, the generator and the tests described below. The spec is fixed by the user: `00_DESIGN_E33_ATTEMPT_CHAIN.md`, sections 3 and 4. Follow it exactly; do not add rules of your own.

## Deliverables
1. **`e33_sched_build.py`**: a generator in the style of `REF__e29_direct_build.py`.
   - Once-only text edits (`once(text, old, new, label)`) on the base file.
   - A tail block with the new functions.
   - `make_sched(base_text, base_sha) -> (post_text, patch_text, module_text)`.
   - The patch is a strict unified diff with n=3 context. It must apply forward and reverse with `REF__e28_sched_patch.py`'s `apply_unified` / `reverse_unified`.
2. **`e33_sched_patch.py`**: the generated applier module, same API as `REF__e29d_sched_patch.py`: `apply` / `verify` / `revert` / `tree_state` / `cell3`, with pre / post / patch shas and a marker line.
3. **`e33_sched_tests.py`**: stdlib unittest on the scripted-Duck harness `REF__e29_sched_tests.py`. Use it as `REF__e29d_direct_tests.py` does: `ST.setUpModule`, `ST._tasks`, `ST.SCRIPTS`, `ST.Env`, `ST.RunLog`, `ST._solve`, `ST._norm_recs`, `ST._norm_e28`, with stub hooks.
4. **A short report:** every edit and its purpose, the branch-id map, the priority implementation, the hook contracts, the answer-rule implementation, the test list + results, and the risks.

## The spec in brief (the full text is in 00_DESIGN, sections 3-4)
**Chains.**
- Attempt 1: A (Duck 104k) → B (Duck re-run: B1 104k for B1 / FAIL kinds, B2 120k for cap-cut, exactly `e28_b_phase`) → C (Poetiq iteration 1) → D (Poetiq iteration 2, with feedback) → E (Direct).
- STRICTLY SEQUENTIAL per (task, attempt). The next stage is queued only when the previous one ended without a train pass, and the chain stops at the first train pass.
- A non-pass A kind with no B phase goes straight to C. A TIME end (the solve window is over) queues nothing.

**Attempt 2.** The same chain on separate branches, A′ B′ C′ D′ E′.
- Queued for a task when its attempt-1 A ends.
- Group 1: tasks whose attempt-1 A was not a train pass, in task order.
- Group 2: the rest, by ascending attempt-1 A tokens (E28's C2 key).
- It stops at the first attempt-2 train pass.

**Priority.**
- Every attempt-1 item comes before any attempt-2 item.
- Inside an attempt: waiting B2 (E28's rule), then A, B, C, D, E, earlier stage first. Inside a stage: group, then task order.
- Supply (S1 / S2, `_e29_*`) runs only when both attempts' queues are empty, as now.
- The KV reservation hook `E28_TRY_RESERVE`, backfill and force-when-idle stay as they are.

**Branches.**
- Each (attempt, stage) gets its own branch id and reservation key. Supply already uses branches >= 3, so choose ids that never collide, and document them.
- Never two stages of one (task, attempt) at once. Attempt 1 and attempt 2 of a task may run concurrently.

**Hooks** (module globals the notebook sets; follow the pattern of `E29D_RUN` / `E29D_CAN_START` in REF__e29d_sched_patch.py):
- `E33_RUN_POETIQ(tid, task, plan, deadline, base_url, model_id, out_dir, iteration, prior_record) -> record | None`
- `E33_RUN_DIRECT(tid, task, plan, deadline, base_url, model_id, out_dir) -> record | None`
- `E33_CAN_START(stage, deadline) -> bool`: the notebook's 60,000-thinking-floor admission.
- No hook, False, None or an exception means that stage is skipped for that task (recorded) and that chain ends. The worker must never crash.
- **Records** have the shape of `REF__e29_direct.py`'s record: `task_id`, `status`, `generated_tokens`, `submissions = [{"test_outputs": [grid per test], "accepted": bool, "train_exact": [...]}]`, plus a `poetiq` block (`train_pass`, `score`, `iteration`, ...) or an `e31` block. Publish them like `_e29d_item` in the REF DIRECT patch.
- **Train pass:** Duck = kind TRAIN_PASS; Poetiq = `rec["poetiq"]["train_pass"]` (= accepted); Direct = never (E is the last stage).
- Every path: one start, one completion, one `E28_RELEASE((task, branch))`.

**Answers** (user-accepted; spec section 4):
- **attempt_1**, from attempt 1, in this order:
  1. the first train-pass answer;
  2. else the best train match among the attempt-1 Duck / Poetiq records (E28's best-train rule, with Poetiq's train score as the match);
  3. else the attempt-1 Direct grid;
  4. else E28's fallbacks;
  5. else the test input.
- **attempt_2**, from attempt 2 by the same rule when it differs from attempt_1; else the next distinct attempt-1 candidate; else the fallbacks.
- Grid K → test K; valid grids only. Record each query's slot source.

**Switches.** Env flags set by the notebook, like `E29_DIRECT=1` + hook: E33 on, Poetiq on, Direct on, attempt 2 on. **OFF = byte-identical behaviour to the base file.** Test this strictly with the harness normalizers.

**Report block.** `e28["e33"]`:
- per stage and attempt: queued / started / done / skipped (no hook, false or late) / train-pass counts;
- the stage reached per task;
- tokens.

Phase names: A, B1, B2, C-POETIQ1, D-POETIQ2, E-DIRECT, each with the attempt.

## Tests to include
1. The full chain order on 1 worker.
2. The stop at the first pass for each stage.
3. B1 vs B2 vs straight to C.
4. The attempt-2 groups and order.
5. Attempt 2 never ahead of a runnable attempt-1 item.
6. 4 workers, with the invariants: one start / done / release per (task, branch), and never two stages of one (task, attempt) at once.
7. Hooks None / False / raising: the stage is skipped and the chain ends.
8. The window ends mid-chain.
9. The answer-rule cases 1-5 for both slots.
10. Multi-test tasks.
11. Switches off: strict parity with the base.
12. Supply runs only when everything else is empty.
13. A negative control: the tests fail on the unpatched base.

## Facts that matter (E28 K100 6-h EVAL120 on this engine: `REF__E28_K100_run_summary.json`, `REF__E28_K100_attempts.json`)
- **Timeline:**
  - the A queue empties at ~233 min of 360;
  - B2 runs at 233-307 min start;
  - E28's C1 items started at 346-352 min.
- **Counts:** 16 of 120 A attempts did not train-pass; B2 rescued 8 of them.
- **attempt_2 hits:** all 7 came from Duck's second attempt on train-pass tasks, which is attempt 2 here.
- **Per-stream speed:** ~18-30 tok/s at 24 streams. So a Poetiq iteration (68k) takes ~40-60 min, and Direct (112k) takes ~60-100 min.

## Files in this zip
| File | What |
|---|---|
| `00_DESIGN_E33_ATTEMPT_CHAIN.md` | The fixed spec |
| `BASE__arc2_duck_E29_post.py` | The file you patch: the Duck payload + the E28 scheduler + the E29 supply |
| `REF__e28_sched_patch.py` | The E28 scheduler patch + the applier (`apply_unified`, `reverse_unified`, `_write_atomic`, `_py_compile`) |
| `REF__e29_sched_patch.py` | The E29 supply patch (E28 post → E29 post) |
| `REF__e29_direct_build.py` | The generator pattern to copy |
| `REF__e29d_sched_patch.py` | The current DIRECT diff (rev 2g). E33 REPLACES it; reference only |
| `REF__arc2_duck_DIRECT_post.py` | The base with the rev 2g DIRECT diff applied, so you can read it |
| `REF__e29_sched_tests.py` | The scripted-Duck test harness |
| `REF__e29d_direct_tests.py` | How tests use the harness, with stub hooks |
| `REF__e29_direct.py` | The Direct solver, for the record shape |
| `REF__E28_K100_run_summary.json`, `REF__E28_K100_attempts.json` | The run data above |
| `00_MANIFEST_SHA256.json` | The shas of every file |

**Not included:** the Duck payload zip. The harness extracts it from a local path, so the tests need these files next to them: `arc2_duck.py`, `e28_sched_patch.py`, `e29_sched_patch.py`. Use `BASE__arc2_duck_E29_post.py` as the post text, and write the tests so they can run against a given post file (an env path override). We run the final tests here against the real payload.
