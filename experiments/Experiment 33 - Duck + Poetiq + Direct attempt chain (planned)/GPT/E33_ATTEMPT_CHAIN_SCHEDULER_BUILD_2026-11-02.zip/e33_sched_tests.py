"""E33 attempt chains — standalone stdlib adversarial suite.

Run: python e33_sched_tests.py -v
If the original Duck payload is available, set E28_TEST_PAYLOAD / E29_TEST_E28_DIR and
E33_TEST_PAYLOAD_RUN=1 to test with ST.setUpModule and the original session harness.
Without it, tests run on the exact E29 post and E33 post text, using the ST task,
script, solve, normalization and RunLog interfaces with a fake deterministic session.
"""
import copy
import hashlib
import importlib.util
import json
import os
import sys
import tempfile
import threading
import time
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path[:0] = [str(HERE)]
import e33_sched_patch as EP
import e28_sched_patch as E28S
import e29_sched_tests as ST

BASE = Path(os.environ.get('E33_TEST_E29_POST', HERE / 'BASE__arc2_duck_E29_post.py'))
POST = Path(os.environ.get('E33_TEST_POST', HERE / 'arc2_duck_E33_post.py'))
PATCH = HERE / 'e33_sched.diff'
G = {}


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


class DeterministicSession:
    """Scripted Duck session, same public record contract as REF__e29_sched_tests.BranchSession."""
    _lock = threading.Lock()
    starts = []
    ends = []

    def __init__(self, agent_cls, *, task_id, task, branch, view, queue_position, out_dir,
                 deadline, base_url, model_id, save_request_logs, analyzer_timeout,
                 started_at, max_generated_tokens, **kw):
        self.task_id = task_id
        self.task = task
        self.branch = branch
        self.status = 'new'
        self.max_generated_tokens = max_generated_tokens
        self.deadline = deadline
        self._frozen = False
        self.record = {'task_id': task_id, 'branch': branch, 'submissions': [], 'checked': [],
                       'runs': [], 'note': '', 'generated_tokens': 0, 'status': 'new', 't0': time.time()}
        self.agent = None
        self.e28_plan = None
        self._session_mod = G['mod']
        self._script = ST.SCRIPTS.get((task_id, f'b{branch}')) or ST.SCRIPTS.get(
            (task_id, self._session_mod.E28_PLANS.get((task_id, branch), {}).get('phase', ''))) or {'kind': 'pass'}

    def run(self, pause_at_tokens=None, tag=None):
        p = self._session_mod.E28_PLANS.get((self.task_id, self.branch), {})
        self.e28_plan = p
        sc = self._script
        delay = float(sc.get('sleep', 0.002))
        with self._lock:
            self.starts.append((self.task_id, self.branch, p.get('phase'), time.monotonic()))
        time.sleep(delay)
        kind = sc.get('kind', 'pass')
        tok = int(sc.get('tokens', sc.get('at', 1500)))
        value = int(sc.get('value', 1))
        rec = self.record
        rec['generated_tokens'] = tok
        rec['status'] = 'paused' if kind == 'time' else 'done'
        rec['runs'] = [{'tokens': tok, 'sec': delay}]
        if kind == 'pass':
            sub = {'accepted': True, 'train_exact': [True, True], 'test_outputs': [[[value]] for _ in self.task['test']],
                   'branch': self.branch, 't': time.time()}
            rec['accepted'] = True
            rec['submissions'] = [sub]
        elif kind == 'cap':
            rec['nb5_verdict'] = 'BUDGET_LIMITED'
            rec['checked'] = [{'accepted': False, 'train_exact': [True, False],
                               'test_outputs': [[[value]] for _ in self.task['test']]}]
        elif kind == 'self':
            rec['checked'] = [{'accepted': False, 'train_exact': sc.get('exact', [True, False]),
                               'test_outputs': [[[value]] for _ in self.task['test']]}]
        elif kind == 'fail':
            rec['note'] = 'mock analyzer failed'
        with self._lock:
            self.ends.append((self.task_id, self.branch, p.get('phase'), time.monotonic()))
        self.status = rec['status']
        return self.status

    def verified_signatures(self, *a, **kw):
        return set()

    def write(self):
        return copy.deepcopy(self.record)

    def freeze(self):
        self._frozen = True
        return self.write()


def tasks(n, nq=1):
    return ST._tasks(n, nq)


def run(M, items, *, workers=1, deadline=10.0, reserve=None, on_done=None, supply=False, fake_session=True):
    G['mod'] = M
    with ST.Env(e28=True, supply=supply, E33_CHAIN='1', E33_POETIQ='1', E33_DIRECT='1', E33_ATTEMPT2='1'):
        old = M.BranchSession
        if fake_session:
            M.BranchSession = DeterministicSession
        M.E28_TRY_RESERVE = reserve
        M.E28_RELEASE = lambda k: G.setdefault('releases', []).append(k)
        try:
            recs, t, s = ST._solve(M, items, list(items), workers, deadline_sec=deadline,
                                    min_admit=0.05, kv_poll=0.05, on_branch_done=on_done)
        finally:
            M.BranchSession = old
            M.E28_TRY_RESERVE = None
            M.E28_RELEASE = None
    return recs, s


def rec(tid, grid=3, *, train=False, score=0.0, iteration=1, nq=1):
    return {'task_id': tid, 'status': 'done', 'generated_tokens': 1800,
            'accepted': bool(train),
            'submissions': [{'accepted': bool(train), 'train_exact': [train, train],
                             'test_outputs': [[[grid]] for _ in range(nq)]}],
            'poetiq': {'train_pass': bool(train), 'score': score, 'iteration': iteration}}


def hook(calls, *, pass_stage=None, fail_stage=None, none_stage=None, sleep=0.001):
    def _call(tid, task, p, deadline, url, model, outdir, *ext):
        att, st = p['attempt'], p['e33_stage']
        with G['lock']:
            calls.append((tid, att, st, p['start_seq'], ext))
        time.sleep(sleep)
        if st == fail_stage:
            raise RuntimeError('injected hook exception')
        if st == none_stage:
            return None
        if st == 'E':
            result = rec(tid, grid=8, nq=len(task['test']))
            result['e31'] = {'has_grid': True}
            result['accepted'] = False
            result['poetiq'] = {}
            return result
        return rec(tid, grid=4 if st == 'C' else 5,
                   train=st == pass_stage, score=1 if st == pass_stage else 0.5,
                   iteration=1 if st == 'C' else 2, nq=len(task['test']))
    return _call


def setUpModule():
    G['tmp'] = tempfile.TemporaryDirectory(prefix='e33_tests_')
    ST.FIX['tmp'] = Path(G['tmp'].name)
    G['base'] = load(BASE, 'e33_baseline_')
    G['mod'] = load(POST, 'e33_patch_')
    G['patch'] = G['mod']
    G['lock'] = threading.Lock()
    os.environ['E12_ARC2_REV5'] = '1'
    if os.environ.get('E33_TEST_PAYLOAD_RUN') == '1':
        ST.setUpModule()   # Only when the exact hash-pinned Duck payload is available.


def tearDownModule():
    if os.environ.get('E33_TEST_PAYLOAD_RUN') == '1':
        ST.tearDownModule()
    G['tmp'].cleanup()


class PatchTests(unittest.TestCase):
    def test_manifest_base_and_patch_identity(self):
        self.assertEqual(hashlib.sha256(BASE.read_bytes()).hexdigest(), EP.PRE)
        self.assertEqual(hashlib.sha256(POST.read_bytes()).hexdigest(), EP.POST)
        self.assertEqual(hashlib.sha256(PATCH.read_bytes()).hexdigest(), EP.PATCH_SHA)
        self.assertEqual(EP.tree_state(str(BASE)), 'E29_POST')
        self.assertEqual(EP.tree_state(str(POST)), 'E33_PATCHED')

    def test_strict_patch_forward_reverse(self):
        b = BASE.read_text()
        p = EP.apply(b)
        self.assertEqual(p['text'], POST.read_text())
        self.assertTrue(p['ok'])
        self.assertEqual(EP.revert(p['text'])['text'], b)
        with self.assertRaisesRegex(RuntimeError, 'STATE_MISMATCH'):
            EP.apply(b + '# tampered\n')
        with self.assertRaises((ValueError, RuntimeError)):
            E28S.apply_unified(b.replace('if _e28_on():     # E28 SCHED', 'if _e28_on(garbage):     # E28 SCHED'), EP.PATCH)

    def test_file_apply_revert_and_idempotence(self):
        f = Path(G['tmp'].name) / 'arc2_duck.py'
        f.write_bytes(BASE.read_bytes())
        self.assertTrue(EP.apply(f)['ok'])
        self.assertTrue(EP.verify(f)[0])
        self.assertTrue(EP.apply(f)['ok'])
        self.assertEqual(f.read_bytes(), POST.read_bytes())
        self.assertTrue(EP.revert(f)['ok'])
        self.assertEqual(f.read_bytes(), BASE.read_bytes())

    def test_negative_control(self):
        # This assertion MUST fail on the unpatched E29 post: no E33 code there.
        with self.assertRaises(AssertionError):
            self.assertTrue(hasattr(G['base'], '_e33_solve_all'))
        self.assertTrue(hasattr(G['mod'], '_e33_solve_all'))

    def test_flags_invalid_and_off(self):
        with ST.Env(e28=True, supply=False, E33_CHAIN='0'):
            self.assertFalse(G['mod']._e33_on())
        with ST.Env(e28=True, supply=False, E33_CHAIN='1', E33_POETIQ='garbage', E33_DIRECT='1'):
            self.assertFalse(G['mod']._e33_flags()['poetiq'])
            self.assertTrue(G['mod']._e33_flags()['direct'])


class ChainTests(unittest.TestCase):
    def setUp(self):
        G['mod'] = G['patch']
        ST.SCRIPTS.clear()
        G['releases'] = []
        DeterministicSession.starts.clear()
        DeterministicSession.ends.clear()
        M = G['mod']
        M.E33_RUN_POETIQ = M.E33_RUN_DIRECT = None
        M.E33_CAN_START = lambda stage, deadline: True

    def test_full_chain_and_attempt2(self):
        M = G['mod']
        T = tasks(1)
        for branch in (0,2,7,8):
            ST.SCRIPTS[('t000', f'b{branch}')] = {'kind': 'cap' if branch in (0,7) else 'self'}
        calls=[]
        M.E33_RUN_POETIQ = M.E33_RUN_DIRECT = hook(calls)
        r,s=run(M,T)
        self.assertEqual(len(r['t000']), 10)
        self.assertEqual([x['phase'] for x in s['e28']['e33']['start_order']],
                         ['A','B2','C-POETIQ1','D-POETIQ2','E-DIRECT']*2)
        self.assertEqual([x['attempt'] for x in s['e28']['e33']['start_order']],[1]*5+[2]*5)
        self.assertEqual(len(G['releases']),10)

    def test_first_train_pass_A_B_C_D(self):
        M=G['mod']; T=tasks(1)
        for where in ('A','B','C','D'):
            self.setUp()
            for b in (0,7):
                ST.SCRIPTS[('t000',f'b{b}')]= {'kind':'pass' if where=='A' else 'self'}
            for b in (2,8):
                ST.SCRIPTS[('t000',f'b{b}')]= {'kind':'pass' if where=='B' else 'self'}
            calls=[]
            M.E33_RUN_POETIQ=M.E33_RUN_DIRECT=hook(calls,pass_stage=where if where in ('C','D') else None)
            r,s=run(M,T)
            want={'A':['A'],'B':['A','B1'],'C':['A','B1','C-POETIQ1'],
                  'D':['A','B1','C-POETIQ1','D-POETIQ2']}[where]
            self.assertEqual([x['phase'] for x in s['e28']['e33']['start_order'] if x['attempt']==1],want)
            self.assertEqual([x['phase'] for x in s['e28']['e33']['start_order'] if x['attempt']==2],want)

    def test_b1_b2_straight_c(self):
        M=G['mod']; T=tasks(3)
        ST.SCRIPTS[('t000','b0')]={'kind':'self'}
        ST.SCRIPTS[('t001','b0')]={'kind':'cap'}
        ST.SCRIPTS[('t002','b0')]={'kind':'time'}
        # A self -> B1, cap -> B2; TIME -> no B/C chain.
        M.E33_RUN_POETIQ=M.E33_RUN_DIRECT=hook([])
        _, s=run(M,T)
        phases={t:[x['phase'] for x in s['e28']['e33']['start_order'] if x['task']==t and x['attempt']==1] for t in T}
        self.assertIn('B1',phases['t000']);self.assertIn('B2',phases['t001'])
        self.assertEqual(phases['t002'],['A'])

    def test_attempt2_group_order(self):
        M=G['mod']; T=tasks(4)
        ST.SCRIPTS[('t000','b0')]={'kind':'pass','tokens':20000}
        ST.SCRIPTS[('t001','b0')]={'kind':'pass','tokens':10000}
        ST.SCRIPTS[('t002','b0')]={'kind':'self'}
        ST.SCRIPTS[('t003','b0')]={'kind':'self'}
        M.E33_RUN_POETIQ=M.E33_RUN_DIRECT=hook([])
        _,s=run(M,T)
        order=[x['task'] for x in s['e28']['e33']['start_order'] if x['attempt']==2 and x['phase']=='A']
        self.assertEqual(order,['t002','t003','t001','t000'])

    def test_priority_and_no_same_attempt_overlap(self):
        M=G['mod']; T=tasks(6)
        ST.SCRIPTS.update({(t,'b0'):{'kind':'self','sleep':0.01} for t in T})
        M.E33_RUN_POETIQ=M.E33_RUN_DIRECT=hook([],sleep=0.004)
        _,s=run(M,T,workers=4)
        entries=s['e28']['e33']['start_order']
        a2=[i for i,x in enumerate(entries) if x['attempt']==2]
        a1=[i for i,x in enumerate(entries) if x['attempt']==1]
        self.assertGreater(min(a2),0)
        # A still waiting at each pop must win over A' (except KV backfill).
        self.assertGreater(min(a2), max(i for i,x in enumerate(entries) if x['phase']=='A' and x['attempt']==1))
        # No two starts of the SAME task/attempt overlap, even across stages.
        starts=DeterministicSession.starts
        self.assertEqual(len({(t,b) for t,b,_,_ in starts}),len(starts))
        self.assertEqual(len(G['releases']),len(entries))

    def test_hook_none_exception_and_late_end_chain(self):
        M=G['mod']; T=tasks(1)
        ST.SCRIPTS[('t000','b0')]={'kind':'self'}
        ST.SCRIPTS[('t000','b2')]={'kind':'self'}
        for failure in ('none','raise','late'):
            self.setUp()
            ST.SCRIPTS[('t000','b0')]={'kind':'self'}
            ST.SCRIPTS[('t000','b2')]={'kind':'self'}
            calls=[]
            M.E33_RUN_DIRECT=hook(calls)
            M.E33_RUN_POETIQ=hook(calls,none_stage='C' if failure=='none' else None,
                                   fail_stage='C' if failure=='raise' else None)
            M.E33_CAN_START=lambda stage,deadline: failure!='late'
            _,s=run(M,T)
            self.assertEqual([x['phase'] for x in s['e28']['e33']['start_order'] if x['attempt']==1],
                             ['A','B1']+([] if failure=='late' else ['C-POETIQ1']))
            self.assertTrue(s['e28']['e33']['skipped'])

    def test_window_cut_mid_chain(self):
        M=G['mod']; T=tasks(1)
        ST.SCRIPTS[('t000','b0')]={'kind':'time'}
        M.E33_RUN_POETIQ=M.E33_RUN_DIRECT=hook([])
        _,s=run(M,T,deadline=0.3)
        self.assertEqual([x['phase'] for x in s['e28']['e33']['start_order'] if x['attempt']==1],['A'])

    def test_multi_test_and_slot_sources(self):
        M=G['mod']; T=tasks(1,3)
        ST.SCRIPTS[('t000','b0')]={'kind':'self','value':2}
        ST.SCRIPTS[('t000','b2')]={'kind':'self','value':3}
        ST.SCRIPTS[('t000','b7')]={'kind':'pass','value':8}
        M.E33_RUN_POETIQ=M.E33_RUN_DIRECT=hook([])
        rs,s=run(M,T)
        sub=M.build_submission(T,rs)
        self.assertEqual(len(sub['t000']),3)
        self.assertTrue(all('attempt_1' in v and 'attempt_2' in v for v in sub['t000']))
        self.assertEqual(len(s['e28']['e33']['slots']['t000']),3)

    def test_supply_only_after_chain_queues_empty(self):
        M=G['mod']; T=tasks(1)
        ST.SCRIPTS[('t000','b0')]={'kind':'self'}
        ST.SCRIPTS[('t000','b2')]={'kind':'self'}
        ST.SCRIPTS[('t000','b7')]={'kind':'self'}
        ST.SCRIPTS[('t000','b8')]={'kind':'self'}
        M.E33_RUN_POETIQ=M.E33_RUN_DIRECT=hook([])
        _,s=run(M,T,supply=True)
        order=s['e28']['e33']['start_order']
        supplied=[i for i,x in enumerate(order) if x['branch']>=12]
        chain=[i for i,x in enumerate(order) if x['attempt'] in (1,2)]
        self.assertTrue(supplied)
        self.assertGreater(min(supplied),max(chain))
        self.assertGreaterEqual(min(x['branch'] for x in order if x['branch']>=12),12)

    def test_off_base_parity(self):
        M=G['mod']; B=G['base']; T=tasks(2)
        ST.SCRIPTS.clear()
        ST.SCRIPTS[('t000','b0')]={'kind':'pass'}
        ST.SCRIPTS[('t001','b0')]={'kind':'self'}
        matched=[]
        for mod in (M,B):
            G['mod']=mod
            old_session = mod.BranchSession
            try:
                mod.BranchSession=DeterministicSession
                with ST.Env(e28=True,supply=False,E33_CHAIN='0'):
                    records, duration, report=ST._solve(mod,T,list(T),workers=1,deadline_sec=2,min_admit=0.1)
                matched.append((ST._norm_recs(records, False), ST._norm_e28(report['e28'], False)))
            finally:
                mod.BranchSession=old_session
        self.assertEqual(matched[0], matched[1])
        G['mod']=M




class SlotTests(unittest.TestCase):
    def setUp(self):
        G['mod'] = G['patch']
        os.environ['E12_ARC2_REV5'] = '1'
        self.M = G['mod']
        self.task = tasks(1, 3)['t000']

    @staticmethod
    def item(stage, attempt, grids, *, full=False, frac=0.0, score=None):
        branch = G['patch'].E33_BRANCH[(attempt, stage)]
        rec = {'task_id': 't000', 'branch': branch,
               'e33': {'stage': stage, 'attempt': attempt}, 'generated_tokens': 1000,
               'submissions': [{'test_outputs': grids, 'train_exact': [bool(frac >= .5), bool(full)],
                                'accepted': full}], 'accepted': full}
        if stage in ('C','D'):
            rec['poetiq'] = {'train_pass': full, 'score': float(score or 0), 'iteration': 1 if stage == 'C' else 2}
        if stage == 'E':
            rec['accepted'] = False
            rec['submissions'][0]['accepted'] = False
        return rec

    def test_first_train_pass_and_two_slots(self):
        M = self.M
        r1 = self.item('A', 1, [[[1]], [[2]], [[3]]], full=True)
        r2 = self.item('A', 2, [[[4]], [[5]], [[6]]], full=True)
        with ST.Env(supply=False,e28=True,E33_CHAIN='1'):
            slots=[]
            res = M.select_attempts_e33(self.task,[r1,r2],slots)
        self.assertEqual([r['attempt_1'] for r in res],[[[1]],[[2]],[[3]]])
        self.assertEqual([r['attempt_2'] for r in res],[[[4]],[[5]],[[6]]])
        self.assertEqual(slots[0]['attempt_1'],'1:A')
        self.assertEqual(slots[0]['attempt_2'],'2:A')

    def test_best_train_match_poetiq_over_duck(self):
        M=self.M
        a = self.item('A',1,[[[2]]]*3, full=False,frac=0.5)
        c = self.item('C',1,[[[5]]]*3, full=False,score=0.75)
        d = self.item('D',1,[[[6]]]*3, full=True,score=1)
        with ST.Env(supply=False,e28=True,E33_CHAIN='1'):
            self.assertEqual(M.select_attempts_e33(self.task,[a,c])[0]['attempt_1'],[[5]])
            self.assertEqual(M.select_attempts_e33(self.task,[a,c,d])[0]['attempt_1'],[[6]])

    def test_direct_and_input_fallback(self):
        M=self.M
        e = self.item('E',1,[[[9]],[[8]],[[7]]])
        with ST.Env(supply=False,e28=True,E33_CHAIN='1'):
            self.assertEqual(M.select_attempts_e33(self.task,[e])[0]['attempt_1'],[[9]])
            self.assertEqual(M.select_attempts_e33(self.task,[])[0]['attempt_1'],[[9]])

    def test_strict_attempt_separation_and_next_distinct(self):
        M=self.M
        a = self.item('A',1,[[[1]]]*3,full=True)
        b = self.item('B',1,[[[2]]]*3,full=False)
        a2 = self.item('A',2,[[[1]]]*3,full=True)
        with ST.Env(supply=False,e28=True,E33_CHAIN='1'):
            res=M.select_attempts_e33(self.task,[a,b,a2]);self.assertEqual(res[0]['attempt_2'],[[2]])
            # A2 answer must never fill attempt 1 when all attempt-1 stages are absent.
            only_2=M.select_attempts_e33(self.task,[a2]);self.assertEqual(only_2[0]['attempt_1'],[[9]])

    def test_fallback_rules_preserved_but_not_attempt2(self):
        M=self.M
        old = M.select_attempts_r5
        try:
            def stub(task, records, _e28_lists=None):
                if _e28_lists is not None:
                    _e28_lists.extend([[[[7]]] for _ in task['test']])
                return [{'attempt_1': [[7]], 'attempt_2': [[9]]} for _ in task['test']]
            M.select_attempts_r5=stub
            a2=self.item('A',2,[[[8]]]*3,full=True)
            res=M.select_attempts_e33(self.task,[a2])
            self.assertEqual(res[0],{'attempt_1': [[7]], 'attempt_2': [[8]]})
        finally:
            M.select_attempts_r5=old

    def test_bad_grids_never_selected(self):
        M=self.M
        bad=self.item('A',1,[[[10]], [[12]], [[999]]],full=True)
        with ST.Env(supply=False,e28=True,E33_CHAIN='1'):
            res=M.select_attempts_e33(self.task,[bad])
        self.assertEqual(res[0]['attempt_1'],[[9]])


class AdditionalChainTests(ChainTests):
    def test_poetiq_feedback_receives_iteration1_record(self):
        M=G['patch'];T=tasks(1)
        ST.SCRIPTS.update({('t000',f'b{x}'):{'kind':'self'} for x in (0,2,7,8)})
        received=[]
        def poit(tid,task,p,deadline,url,model,out,iteration,prior):
            if iteration==2: received.append(prior)
            return rec(tid,grid=4,iteration=iteration, nq=len(task['test']))
        M.E33_RUN_POETIQ=poit;M.E33_RUN_DIRECT=hook([])
        _,s=run(M,T)
        self.assertEqual(len(received),2)
        self.assertTrue(all(r and (r.get('e33') or {}).get('stage')=='C' for r in received))

    def test_reservation_backfill(self):
        M=G['patch'];T=tasks(3)
        ST.SCRIPTS.update({(t,'b0'):{'kind':'self'} for t in T})
        G['reservation_calls']=[]
        def reserve(key,plan):
            G['reservation_calls'].append(key)
            # The first eligible A0 is held while another A0 is admitted.
            return key[0]!='t000' or plan['phase']!='A'
        M.E33_RUN_POETIQ=M.E33_RUN_DIRECT=hook([])
        _,s=run(M,T,workers=3,reserve=reserve)
        self.assertGreater(s['e28']['fit_fails'],0)
        self.assertTrue(s['e28']['e33']['start_order'])

    def test_hooks_missing_skip_and_stop(self):
        M=G['patch'];T=tasks(1)
        ST.SCRIPTS.update({('t000',f'b{x}'):{'kind':'self'} for x in (0,2,7,8)})
        M.E33_RUN_POETIQ=None;M.E33_RUN_DIRECT=hook([])
        _,s=run(M,T)
        self.assertIn('no_hook',s['e28']['e33']['skip_reasons'])
        self.assertEqual(s['e28']['e33']['start_order'][-1]['phase'],'B1')

    def test_callable_hook_false_ends_chain(self):
        M=G['patch'];T=tasks(1)
        ST.SCRIPTS.update({('t000',f'b{x}'):{'kind':'self'} for x in (0,2,7,8)})
        M.E33_RUN_POETIQ=lambda *args: False
        M.E33_RUN_DIRECT=hook([])
        _,s=run(M,T)
        self.assertGreaterEqual(s['e28']['e33']['skip_reasons'].get('hook_failed_or_none',0),1)
        self.assertFalse(any(x['phase']=='D-POETIQ2' for x in s['e28']['e33']['start_order']))



class RealBranchSessionContractTests(unittest.TestCase):
    """Exercise the actual pinned BranchSession with ST.make_fake, not our simpler session stub."""

    def setUp(self):
        self.M=G['patch']
        G['mod']=self.M
        ST.SCRIPTS.clear()
        G['releases']=[]
        M=self.M
        self.orig_import=M._import_duck
        class TA:
            RUNTIME_STATE_FILENAME='state.json'
            _priority_gate=staticmethod(lambda: None)
        def state_writer(path, **kwargs):
            Path(path).write_text('{}')
        M._import_duck=lambda: (TA,None,None,state_writer)
        M.E33_CAN_START=lambda stage,deadline: True
        M.E33_RUN_POETIQ=M.E33_RUN_DIRECT=hook([])

    def tearDown(self):
        self.M._import_duck=self.orig_import

    def test_actual_branchsession_A_and_B2(self):
        M=self.M;T=tasks(1)
        ST.SCRIPTS[('t000','b0')]={'kind':'cap'}
        ST.SCRIPTS[('t000','b2')]={'kind':'partial','at':2000}
        ST.SCRIPTS[('t000','b7')]={'kind':'pass','at':5000}
        rs,info=run(M,T,workers=2,fake_session=False)
        r0=next(r for r in rs['t000'] if r['branch']==0)
        self.assertEqual(r0['e28']['kind'],'B2')
        self.assertTrue(any(x['phase']=='B2' for x in info['e28']['e33']['start_order']))
        self.assertTrue(any(x['branch']==7 and x['e28']['kind']=='TRAIN_PASS' for x in rs['t000']))
        self.assertGreater(info['tasks_with_request_sent'],0)
        self.assertEqual(len(G['releases']),len(info['e28']['e33']['start_order']))

    def test_real_branchsession_first_pass_stops_chain(self):
        M=self.M;T=tasks(2)
        ST.SCRIPTS[('t000','b0')]={'kind':'pass','at':3000}
        ST.SCRIPTS[('t001','b0')]={'kind':'pass','at':4000}
        rs,info=run(M,T,workers=4,fake_session=False)
        self.assertFalse(any(x['phase'].startswith('B') for x in info['e28']['e33']['start_order']))
        self.assertEqual(len(rs['t000']),2)
        self.assertEqual(len(rs['t001']),2)
        self.assertEqual(info['tasks_with_request_sent'],2)



class HookAndBudgetTests(unittest.TestCase):
    def setUp(self):
        G['mod'] = G['patch']
        self.M = G['mod']
        ST.SCRIPTS.clear()
        G['releases'] = []
        self.M.E33_CAN_START = lambda stage, deadline: True

    def test_method_budgets_include_answer_and_minimum_thinking(self):
        T = tasks(1)
        ST.SCRIPTS.update({('t000',f'b{x}'):{'kind':'self'} for x in (0,2,7,8)})
        seen = []
        def task_hook(tid, task, p, *rest):
            seen.append(dict(p))
            return rec(tid, grid=5, nq=len(task['test']))
        self.M.E33_RUN_POETIQ = self.M.E33_RUN_DIRECT = task_hook
        _, info = run(self.M, T, supply=False)
        vals={(p['e33_stage'], p['budget']) for p in seen}
        self.assertIn(('C', 60000+8192), vals)
        self.assertIn(('D', 60000+8192), vals)
        self.assertIn(('E', 104000+8192), vals)
        self.assertFalse(info['e28']['e33']['invalid_settings'])

    def test_budgets_below_floor_or_unparseable_disable_only_one_method(self):
        with ST.Env(e28=True, supply=False, E33_CHAIN='1', E33_POETIQ='1',
                    E33_DIRECT='1', E33_ATTEMPT2='1', E33_POETIQ_THINK='59000'):
            flags = self.M._e33_flags()
            self.assertFalse(flags['poetiq'])
            self.assertTrue(flags['direct'])
            self.assertTrue(flags['attempt2'])
            self.assertIn('poetiq', flags['invalid'])
        with ST.Env(e28=True, supply=False, E33_CHAIN='1', E33_POETIQ='1',
                    E33_DIRECT='1', E33_DIRECT_THINK='bad'):
            flags = self.M._e33_flags()
            self.assertTrue(flags['poetiq'])
            self.assertFalse(flags['direct'])

    def test_cell3_fails_closed_when_e29_is_not_selected(self):
        old = os.environ.get('E33_CHAIN')
        try:
            r = EP.cell3(HERE, {'applied': True, 'path': 'E28'}, {})
            self.assertEqual(r['error'], 'E33_NEEDS_E29_POST')
            self.assertNotIn('E33_CHAIN', os.environ)
        finally:
            if old is None:
                os.environ.pop('E33_CHAIN', None)
            else:
                os.environ['E33_CHAIN'] = old

    def test_cell3_verified_file_then_revert(self):
        target = Path(G['tmp'].name) / 'cell3'
        target.mkdir(exist_ok=True)
        (target / 'arc2_duck.py').write_bytes(BASE.read_bytes())
        old = os.environ.get('E33_CHAIN')
        try:
            outcome = EP.cell3(target, {'applied': 'applied', 'path': 'E29'}, {})
            self.assertTrue(outcome['ok'])
            self.assertEqual(os.environ.get('E33_CHAIN'), '1')
            self.assertTrue(EP.verify(target)[0])
            self.assertTrue(EP.revert(target)['ok'])
        finally:
            if old is None:
                os.environ.pop('E33_CHAIN', None)
            else:
                os.environ['E33_CHAIN'] = old

if __name__=='__main__':
    unittest.main(verbosity=2)
