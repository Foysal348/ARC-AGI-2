# E33 Attempt-Chain Scheduler — technical build and independent verification

## Decision
**GO for scheduler-source build and CPU harness. Not yet a complete E33 notebook or production GO.** The requested strict diff and generated files are reproducible, while external Poetiq/E31 hooks and Kaggle GPU runs remain unverified.

## Source + changes
Pinned base: `BASE__arc2_duck_E29_post.py` SHA `d8603109f9530896e9e4a56e52806202fc2cd4c58bd664d9a25222fe6f7592c2`.

`e33_sched_build.py::once` performs only two guarded edits to existing E29 function bodies:
1. `solve_all_r6`: if `_e33_on()` dispatch `_e33_solve_all()` before original `_e28_on()` and rev6 paths.
2. `select_attempts`: if `_e33_on()` dispatch `select_attempts_e33()` before original E29/E28 selection.
Then it appends a self-contained E33 extension tail. No existing branch runs differently when `E33_CHAIN != '1'`, backed by strict scripted-Duck normalized parity tests.

`make_sched(base_text, base_sha)` rejects an unpinned base, compiles the resulting post, produces a strict `difflib.unified_diff(n=3)` and a standalone SHA-pinned applier module.

## Branch IDs
| Chain | A | B | C Poetiq-1 | D Poetiq-2 | E DIRECT |
|---|---:|---:|---:|---:|---:|
| Attempt 1 | 0 | 2 | 1 | 5 | 6 |
| Attempt 2 | 7 | 8 | 9 | 10 | 11 |

E29 S1/S2 branches begin at **12** to avoid collision. Attempt 0 labels only supply, not a third E33 chain.

## Scheduling, ordering and safety
- A→B (E28 B1/B2 classifier) → C→D→E; non-B-kind failure from A goes directly to C.
- The next stage queues only after the preceding stage finishes without `TRAIN_PASS` or `TIME`; first pass ends its attempt's chain. A TIME does not queue attempt 2.
- Attempt 2 is queued once the task's attempt-1 A completes, independent of attempt-1 subsequent stages. Its group 1 is A1 nonpass tasks in input order; group 2 is A1 pass tasks by ascending A1 tokens.
- Every ready attempt-1 item outranks attempt-2. Inside attempt: waiting B2, then A, B, C, D, E. A fit failure permits lower-priority runnable backfill; the original E28 force-when-idle rule is preserved.
- `(task,attempt)` stays active while a stage is running, disallowing overlap within a chain; concurrent attempt-1 and attempt-2 for one task are allowed.
- Supply S1/S2 is considered only when no chain queues and no active chain work; keeps original E29 supply policy with branch counter shifted to >=12.
- `E28_TRY_RESERVE((task,branch), plan)` and `E28_RELEASE((task,branch))` are preserved for admitted work. Exception path tries release; worker count has finally-safe accounting in tested paths.

## Hooks and fail-closed behavior
The notebook must bind these module globals before enabling E33:
```python
E33_RUN_POETIQ(tid, task, plan, deadline, base_url, model_id, out_dir, iteration, prior_record) -> record | None
E33_RUN_DIRECT(tid, task, plan, deadline, base_url, model_id, out_dir) -> record | None
E33_CAN_START(stage, deadline) -> bool
```
No hook, hook `None`, invalid budget, `False` admission or raised exception: record a skip and end only that chain; never report `TRAIN_PASS` for failed hooks. Poetiq pass requires `poetiq.train_pass` plus verified accepted evidence. DIRECT is terminal and cannot count as a train pass. C/D each reserve 60,000 thinking + 8,192 answer; E reserves 104,000 thinking + 8,192 answer.

`cell3()` demands the E29 POST recorded state and a SHA-verified E33 apply; leaves `E33_CHAIN` unset on failure. NOTE: this is a source applier; the notebook must separately supply both actual solver integrations and their independent verification.

## Answers
`select_attempts_e33()` selects each query's valid 0–9 grid: first train-pass in attempt 1, else best Duck/Poetiq train score, else DIRECT, else E28 fallback, else test input. Attempt 2 prefers its own distinct candidate, else next distinct attempt-1 candidate, else fallback. Attempt-2 candidate cannot silently populate attempt-1 slot. All query sources stored in `SCHED_LAST['e28']['e33']['slots']`.

## Report / telemetry
`SCHED_LAST['e28']['e33']`: per attempt and stage queued/started/done/skipped/train-pass/tokens, invalid-setting/skips, by-task stage history, start order, slot provenance, branch map, leftover queue, worker errors. Preserves E28 row fields, task exposure, `tasks_with_request_sent` based on actual Duck agent counters, and LIVE callback `on_branch_done`.

## Independent validation
1. 41/41 Python stdlib unit test cases PASS (original E29 scripted-Duck helper and separate mocked transport; some inherited test scenarios repeated).
2. Cases cover A→B→C→D→E, first-train-pass stops, B1/B2/straight-to-C, attempt 2 ordering, priority, per-chain non-overlap, hook None/False/error, timeout, multi-test grids, attempts 1/2 provenance, OFF parity and E29 supply ordering.
3. Additional actual `BranchSession` tests use the supplied harness with mocked Duck transport; not the actual Duck payload.
4. 120 tasks / 24 workers deterministic stress: started=800, done=800, E28_RELEASE=800, error=0, stragglers=0, queue left=0.
5. Builder outputs reproducible byte-identically; `git apply --check`, forward, reverse; strict applier test passes; negative-control run against E29 unpatched fails as expected.

## Remaining operational risks / requirements
- The requested E18 Poetiq client, train-example sandbox evaluation, two-phase token streaming, per-example feedback, voting, solution history and think traces are external. The hooks need a separate real implementation and CPU/fake-server tests.
- The requested E31 DIRECT token-ID streaming and 26-minute drain policy are external. Their request retry/answer preservation must be independently verified under the integrated server.
- Engine, boot, offline wheel staging, PP, DFlash memory and correct Kaggle submission are outside this scheduler source build. No GPU or full Kaggle CPU kit was executed here.
- Since E33 prioritizes attempt-1 sequential chains (including 60k/104k thinking) and uses 6-hour EVAL window, many later stages may not get GPU time. That is a work-supply/score tradeoff dictated by the specification, not a proven performance win.
- Do not enable E33 on the E29 DIRECT post or on a different E29 source SHA. No production notebook was created by this scheduler-only build.
