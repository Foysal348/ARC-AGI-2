"""Standalone 120-task / 24-worker deterministic scheduler stress test."""
import json
import e33_sched_tests as T

def main():
    T.setUpModule()
    try:
        test = T.ChainTests('test_full_chain_and_attempt2')
        test.setUp()
        M = T.G['mod']
        tasks = T.tasks(120)
        for i, tid in enumerate(tasks):
            T.ST.SCRIPTS[(tid, 'b0')] = {'kind': 'self' if i % 3 else 'pass', 'sleep': 0.0004}
            T.ST.SCRIPTS[(tid, 'b2')] = {'kind': 'self', 'sleep': 0.0004}
            T.ST.SCRIPTS[(tid, 'b7')] = {'kind': 'self' if i % 2 else 'pass', 'sleep': 0.0004}
            T.ST.SCRIPTS[(tid, 'b8')] = {'kind': 'self', 'sleep': 0.0004}
        M.E33_RUN_POETIQ = M.E33_RUN_DIRECT = T.hook([], sleep=0.0004)
        records, report = T.run(M, tasks, workers=24, deadline=10)
        starts = len(report['e28']['e33']['start_order'])
        releases = len(T.G['releases'])
        done = sum(report['e28']['e33']['done'].values())
        out = {'tasks': len(records), 'workers': 24, 'started': starts,
               'completed': done, 'released': releases, 'worker_errors': report['worker_errors'],
               'stragglers': report['stragglers'], 'queue_left': report['e28']['e33']['left']}
        assert out['tasks'] == 120
        assert starts == releases == done
        assert not out['worker_errors'] and not out['stragglers'] and not out['queue_left']
        print(json.dumps({'PASS': True, **out}, indent=2))
    finally:
        T.tearDownModule()

if __name__ == '__main__':
    main()
