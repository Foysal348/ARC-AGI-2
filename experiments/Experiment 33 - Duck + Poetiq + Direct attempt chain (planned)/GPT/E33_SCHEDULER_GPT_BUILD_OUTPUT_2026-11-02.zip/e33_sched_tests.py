"""E33 scheduler scripted-Duck contract tests.

Default mode is a local ST.make_fake / ST._solve fixture with minimal vendored Duck stubs (the
supplied ZIP omits Duck's vendor payload). Set E33_TEST_REAL=1 and configure E28_TEST_PAYLOAD
etc. to invoke ST.setUpModule and execute against the real extracted Duck harness instead.
"""
import collections
import copy
import hashlib
import importlib.util
import os
from pathlib import Path
import tempfile
import threading
import time
import types
import unittest

import e29_sched_tests as ST
import e33_sched_build as B
import e33_sched_patch as P
import e28_sched_patch as E

HERE = Path(__file__).resolve().parent
BASE = (HERE / 'BASE__arc2_duck_E29_post.py').read_text()
PATCHED = (HERE / 'E33__arc2_duck_post.py').read_text()
FIX = {}


def _module(path, name):
    spec = importlib.util.spec_from_file_location(name, str(path))
    m = importlib.util.module_from_spec(spec)
    import sys
    sys.modules[name] = m
    spec.loader.exec_module(m)
    return m


def _stub_vendor(m):
    ta = types.SimpleNamespace(RUNTIME_STATE_FILENAME='runtime.json', _priority_gate=lambda: None)
    m._import_duck = lambda: (ta, None, None, lambda path, **kw: Path(path).write_text('{}'))


def setUpModule():
    if os.environ.get('E33_TEST_REAL') == '1':
        ST.setUpModule()
        FIX['real'] = True
        FIX['tmp'] = ST.FIX['tmp']
        FIX['base'] = ST.FIX['e29']
        pp = Path(FIX['tmp']) / 'e33_test_real.py'
        pp.write_text(PATCHED)
        FIX['post'] = _module(pp, 'e33_test_real')
        # The real Duck payload's vendor directory was inserted by ST.setUpModule.
    else:
        FIX['real'] = False
        FIX['tmp_obj'] = tempfile.TemporaryDirectory(prefix='e33_sched_tests_')
        FIX['tmp'] = Path(FIX['tmp_obj'].name)
        ST.FIX['tmp'] = FIX['tmp']
        FIX['base'] = _module(HERE / 'BASE__arc2_duck_E29_post.py', 'e33_test_base')
        FIX['post'] = _module(HERE / 'E33__arc2_duck_post.py', 'e33_test_post')
        for m in (FIX['base'], FIX['post']):
            _stub_vendor(m)


def tearDownModule():
    if FIX.get('real'):
        ST.tearDownModule()
    else:
        FIX['tmp_obj'].cleanup()


def _record(tid, task, value=7, score=0.0, full=False, iteration=None, method='poetiq'):
    n = len(task['test'])
    r = {'task_id': tid, 'status': 'done', 'generated_tokens': 13,
         'submissions': [{'test_outputs': [[[value + i]] for i in range(n)],
                          'accepted': bool(full), 'train_exact': [bool(full), bool(full)], 't': time.time()}]}
    if method == 'poetiq':
        r['poetiq'] = {'iteration': iteration, 'score': score, 'train_pass': bool(full)}
    else:
        r['e31'] = {'mode': 'natural'}
        r['submissions'][0]['accepted'] = False
        r['submissions'][0]['train_exact'] = []
    return r


def _hooks(m, *, c=False, d=False, direct=7, gate=True, errors=None, calls=None):
    errors = errors or {}
    def po(tid, task, plan, deadline, base_url, model_id, out_dir, iteration, prior_record):
        if calls is not None:
            calls.append((tid, plan['attempt'], plan['phase'], prior_record is not None))
        if iteration == 2 and prior_record is None:
            raise AssertionError('feedback prior record missing')
        mode = errors.get(('C' if iteration == 1 else 'D'))
        if mode == 'raise':
            raise ValueError('injected')
        if mode == 'none':
            return None
        if mode == 'false':
            return False
        return _record(tid, task, value=4 if iteration == 1 else 5, score=.5 if iteration == 1 else .75,
                       full=(c if iteration == 1 else d), iteration=iteration)
    def dr(tid, task, plan, deadline, base_url, model_id, out_dir):
        if calls is not None:
            calls.append((tid, plan['attempt'], plan['phase'], None))
        mode = errors.get('E')
        if mode == 'raise':
            raise RuntimeError('injected')
        if mode == 'none':
            return None
        if mode == 'false':
            return False
        return _record(tid, task, value=direct, method='direct')
    m.E33_RUN_POETIQ = po
    m.E33_RUN_DIRECT = dr
    m.E33_CAN_START = gate if callable(gate) else lambda stage, dl: gate


def _run(scripts=None, n=1, workers=1, supply=False, attempt2=False, poet=True, direct=True,
         deadline_sec=10., min_admit=.1, mod=None, **more):
    m = mod or FIX['post']
    tasks = ST._tasks(n)
    ST.SCRIPTS.clear()
    ST.SCRIPTS.update(scripts or {})
    env = dict(E33_SCHED=1, E33_POETIQ=int(poet), E33_DIRECT=int(direct),
               E33_ATTEMPT2=int(attempt2), E29_SUPPLY_MAX_ATTEMPTS=3)
    env.update(more)
    with ST.Env(supply=supply, e28=True, **env):
        records, elapsed, report = ST._solve(m, tasks, list(tasks), workers,
                                            deadline_sec=deadline_sec, min_admit=min_admit)
        submission = m.build_submission(tasks, records)
    return records, report, submission


def _s(t, phase, kind='fail', at=1000, value=2):
    return ((t, phase), {'kind': kind, 'at': at, 'value': value})


def _stages(records, tid, attempt=1):
    return [(r.get('e33') or {}).get('phase') for r in records[tid]
            if (r.get('e33') or {}).get('attempt') == attempt]


class TestPatch(unittest.TestCase):
    def test_manifest_base_and_roundtrip(self):
        self.assertEqual(B.sha(BASE), B.BASE_SHA)
        post, diff, module = B.make_sched(BASE, B.sha(BASE))
        self.assertEqual((post, diff, module), (PATCHED, P.PATCH, (HERE / 'e33_sched_patch.py').read_text()))
        self.assertEqual(E.apply_unified(BASE, diff), post)
        self.assertEqual(E.apply_unified(post, E.reverse_unified(diff)), BASE)
        self.assertEqual((P.tree_state(BASE), P.tree_state(post)), ('E29_POST', 'E33_PATCHED'))
        self.assertEqual(P.revert(post)['text'], BASE)
        self.assertEqual(P.apply(BASE)['text'], post)
        self.assertEqual(post.count(P.MARKER), 1)
        self.assertTrue(all(h.startswith('@@') for h in diff.splitlines() if h.startswith('@@')))
        self.assertNotIn('\r', diff)
    def test_negative_control_on_unpatched_base(self):
        self.assertFalse(hasattr(FIX['base'], '_e33_solve_all'))
        self.assertFalse(hasattr(FIX['base'], 'select_attempts_e33'))
        self.assertEqual(P.tree_state(BASE), 'E29_POST')
        with self.assertRaises(RuntimeError):
            P.apply(BASE.replace('def _e28_on()', 'def  _e28_on()', 1))
    def test_applier_file_mode(self):
        p = FIX['tmp'] / ('test_patch_' + str(time.monotonic_ns()))
        p.mkdir()
        (p / 'arc2_duck.py').write_text(BASE)
        self.assertTrue(P.apply(p)['ok'])
        self.assertTrue(P.verify(p)[0])
        self.assertEqual(P.apply(p)['applied'], 'already')
        self.assertTrue(P.revert(p)['ok'])
        self.assertEqual((p / 'arc2_duck.py').read_text(), BASE)
    def test_cell3_fail_closed(self):
        with ST.Env(supply=False, e28=True):
            with tempfile.TemporaryDirectory() as d:
                p = Path(d) / 'arc2_duck.py'
                p.write_text(BASE)
                r = P.cell3(d, {'applied': True, 'path': 'E29'}, {})
                self.assertTrue(r['ok'])
                self.assertEqual(os.getenv('E33_SCHED'), '1')
                os.environ.pop('E33_SCHED', None)
                r2 = P.cell3(d, {'applied': True, 'path': 'OTHER'}, {})
                self.assertIn('error', r2)
                self.assertIsNone(os.getenv('E33_SCHED'))


class TestChains(unittest.TestCase):
    def setUp(self):
        _hooks(FIX['post'])
    def test_full_chain_order(self):
        scripts = dict([_s('t000', 'A'), _s('t000', 'B1')])
        recs, rpt, _ = _run(scripts)
        self.assertEqual(_stages(recs, 't000'), ['A', 'B1', 'C-POETIQ1', 'D-POETIQ2', 'E-DIRECT'])
        self.assertEqual(len({r['branch'] for r in recs['t000']}), 5)
        self.assertEqual(rpt['worker_errors'], 0)
        self.assertEqual(rpt['e28']['e33']['done']['1:E-DIRECT'], 1)
        self.assertEqual(rpt['e28']['e33']['started']['1:E-DIRECT'], 1)
    def test_stop_at_first_pass_each_stage(self):
        choices = [('A', 'pass', False, False, ['A']),
                   ('B1', 'pass', False, False, ['A', 'B1']),
                   ('C', 'fail', True, False, ['A', 'B1', 'C-POETIQ1']),
                   ('D', 'fail', False, True, ['A', 'B1', 'C-POETIQ1', 'D-POETIQ2'])]
        for stage, what, cp, dp, expected in choices:
            with self.subTest(stage=stage):
                _hooks(FIX['post'], c=cp, d=dp)
                scripts = dict([_s('t000', 'A', 'pass' if stage == 'A' else 'fail'),
                                _s('t000', 'B1', 'pass' if stage == 'B1' else 'fail')])
                recs, _, _ = _run(scripts)
                self.assertEqual(_stages(recs, 't000'), expected)
    def test_b1_b2_and_unknown_direct_to_c(self):
        _hooks(FIX['post'], c=True)
        scripts = dict([_s('t000', 'A', 'fail'), _s('t001', 'A', 'cap'),
                        _s('t002', 'A', 'fail')])
        original = FIX['post'].e28_classify
        def transformed(r, *a, **kw):
            out = original(r, *a, **kw)
            if r.get('task_id') == 't002' and int(r.get('branch')) == 0:
                return dict(out, kind='OTHER')
            return out
        FIX['post'].e28_classify = transformed
        try:
            recs, rpt, _ = _run(scripts, n=3)
        finally:
            FIX['post'].e28_classify = original
        self.assertIn('B1', _stages(recs, 't000'))
        self.assertIn('B2', _stages(recs, 't001'))
        self.assertEqual(_stages(recs, 't002'), ['A', 'C-POETIQ1'])
    def test_attempt2_priority_and_groups(self):
        _hooks(FIX['post'], c=True)
        scripts = dict([_s('t000', 'A', 'pass', 3000), _s('t001', 'A', 'fail'),
                        _s('t002', 'A', 'pass', 1000), _s('t003', 'A', 'fail')])
        recs, rpt, _ = _run(scripts, n=4, attempt2=True)
        rows = sorted(rpt['e28']['attempts'], key=lambda r: r['start_seq'])
        a2 = [r['task'] for r in rows if r['attempt'] == 2 and r['phase'] == 'A']
        self.assertEqual(a2, ['t001', 't003', 't002', 't000'])
        last_a1 = max(r['start_seq'] for r in rows if r['attempt'] == 1)
        first_a2 = min(r['start_seq'] for r in rows if r['attempt'] == 2)
        self.assertLess(last_a1, first_a2)
    def test_hooks_missing_none_false_raise_end_chain(self):
        for mode in ('no_hook', 'none', 'false', 'raise', 'gate_false', 'gate_raise'):
            with self.subTest(mode=mode):
                _hooks(FIX['post'], errors={'C': mode} if mode in ('none', 'false', 'raise') else None)
                if mode == 'no_hook':
                    FIX['post'].E33_RUN_POETIQ = None
                elif mode == 'gate_false':
                    FIX['post'].E33_CAN_START = lambda *a: False
                elif mode == 'gate_raise':
                    FIX['post'].E33_CAN_START = lambda *a: 1 / 0
                recs, rpt, _ = _run(dict([_s('t000', 'A'), _s('t000', 'B1')]))
                self.assertEqual(_stages(recs, 't000'), ['A', 'B1', 'C-POETIQ1'])
                self.assertEqual(rpt['e28']['e33']['skipped']['1:C-POETIQ1'], 1)
                self.assertEqual(rpt['worker_errors'], 0)
    def test_window_ends_midchain(self):
        _hooks(FIX['post'], gate=lambda *a: False)
        recs, rpt, _ = _run(dict([_s('t000', 'A'), _s('t000', 'B1')]))
        self.assertEqual(_stages(recs, 't000'), ['A', 'B1', 'C-POETIQ1'])
        self.assertEqual(rpt['e28']['e33']['skipped']['1:C-POETIQ1'], 1)
    def test_four_workers_release_once_and_no_overlap_same_attempt(self):
        _hooks(FIX['post'])
        m = FIX['post']
        lock = threading.Lock()
        releases, grants = collections.Counter(), collections.Counter()
        running = set()
        original = m.BranchSession.run
        def wrapped(session, *args, **kw):
            p = session.e28_plan or {}
            k = (session.task_id, p.get('attempt'))
            with lock:
                self.assertNotIn(k, running)
                running.add(k)
            try:
                return original(session, *args, **kw)
            finally:
                with lock:
                    running.remove(k)
        def fit(k, p):
            with lock: grants[k] += 1
            return True
        def release(k):
            with lock: releases[k] += 1
        m.E28_TRY_RESERVE, m.E28_RELEASE = fit, release
        m.BranchSession.run = wrapped
        try:
            scripts = dict([_s(f't{i:03d}', 'A', 'fail') for i in range(6)] +
                           [_s(f't{i:03d}', 'B1', 'fail') for i in range(6)])
            recs, rpt, _ = _run(scripts, n=6, workers=4, attempt2=True)
            for tid, rs in recs.items():
                for rec in rs:
                    self.assertEqual(releases[(tid, rec['branch'])], 1)
                    self.assertEqual(sum(r['branch'] == rec['branch'] for r in rs), 1)
            self.assertEqual(rpt['worker_errors'], 0)
        finally:
            m.BranchSession.run = original
            m.E28_TRY_RESERVE = m.E28_RELEASE = None
    def test_attempt_a_time_queues_nothing(self):
        _hooks(FIX['post'])
        recs, rpt, _ = _run(dict([_s('t000', 'A', 'hang')]), attempt2=True,
                             deadline_sec=.14, min_admit=.04)
        self.assertEqual(_stages(recs, 't000'), ['A'])
        self.assertEqual(_stages(recs, 't000', attempt=2), [])
        self.assertEqual(recs['t000'][0]['e33']['kind'], 'TIME')

    def test_bad_budget_disables_only_its_item(self):
        _hooks(FIX['post'])
        scripts = dict([_s('t000', 'A'), _s('t000', 'B1')])
        for bad in ('garbage', '4000', '0', '-3'):
            with self.subTest(budget=bad):
                recs, rpt, _ = _run(scripts, E33_POETIQ_THINK=bad)
                self.assertEqual(_stages(recs, 't000'), ['A', 'B1', 'C-POETIQ1'])
                self.assertEqual(rpt['e28']['e33']['skipped']['1:C-POETIQ1'], 1)
        # Invalid DIRECT thinking affects E only; Poetiq C and D still finish.
        recs, rpt, _ = _run(scripts, E33_DIRECT_THINK='abc')
        self.assertEqual(_stages(recs, 't000')[-1], 'E-DIRECT')
        self.assertEqual(rpt['e28']['e33']['skipped']['1:E-DIRECT'], 1)
        self.assertEqual(rpt['e28']['e33']['skipped']['1:C-POETIQ1'], 0)

    def test_bad_poetiq_train_pass_evidence_fail_closed(self):
        _hooks(FIX['post'])
        def inconsistent(tid, task, plan, dl, url, model, out, iteration, prior):
            r = _record(tid, task, value=4, score=1.0, full=True, iteration=iteration)
            r['submissions'][0]['accepted'] = False
            return r
        FIX['post'].E33_RUN_POETIQ = inconsistent
        recs, rpt, _ = _run(dict([_s('t000', 'A'), _s('t000', 'B1')]))
        self.assertEqual(_stages(recs, 't000'), ['A', 'B1', 'C-POETIQ1'])
        self.assertEqual(rpt['e28']['e33']['skipped_reasons']['t000:1:C-POETIQ1'],
                         'inconsistent_train_pass')

    def test_branch_ids_no_supply_collision(self):
        ids = FIX['post'].E33_BRANCH
        self.assertEqual(len(set(ids.values())), len(ids))
        self.assertTrue(all(b <= 2 for b in ids.values()))
        self.assertEqual((ids[(1,'A')], ids[(1,'B')]), (0,2))
        self.assertTrue(all(b < 0 for (a,s),b in ids.items() if (a,s) not in ((1,'A'),(1,'B'))))

    def test_supply_only_after_attempt_queues_empty(self):
        _hooks(FIX['post'])
        scripts = dict([_s('t000', 'A'), _s('t000', 'B1')])
        recs, rpt, _ = _run(scripts, supply=True, poet=False, attempt2=False,
                            E29_SUPPLY_MAX_ATTEMPTS='3')
        starts = sorted(rpt['e28']['attempts'], key=lambda r: r['start_seq'])
        supply_indices = [i for i, r in enumerate(starts) if r['phase'] in ('S1', 'S2')]
        self.assertTrue(supply_indices, starts)
        self.assertTrue(all(r['phase'] in ('S1', 'S2') for r in starts[supply_indices[0]:]), starts)
        self.assertEqual(rpt['worker_errors'], 0)


class TestAnswers(unittest.TestCase):
    def test_grid_order_multitest_and_distinct_slots(self):
        m = FIX['post']
        task = ST._tasks(1, nq=3)['t000']
        def rec(attempt, stage, v, frac=.3, full=False):
            r = _record('t000', task, v, frac, full, 1 if stage == 'C' else None,
                        'poetiq' if stage in ('C', 'D') else 'direct')
            r['e33'] = {'attempt': attempt, 'stage': stage, 'phase': stage, 'skipped': False}
            if stage in ('A', 'B'):
                r['e28'] = {'phase': 'A' if stage == 'A' else 'B1'}
                r['accepted'] = full
            return r
        cases = [
            ([rec(1, 'C', 4, 1., True), rec(1, 'E', 7)], 4),
            ([rec(1, 'C', 4, .3), rec(1, 'D', 5, .8)], 5),
            ([rec(1, 'E', 7)], 7),
        ]
        for records, expected in cases:
            with self.subTest(expected=expected):
                got = m.select_attempts_e33(task, records)
                self.assertEqual([x['attempt_1'] for x in got], [[[expected + i]] for i in range(3)])
        rows = [rec(1, 'C', 4, 1., True), rec(1, 'E', 7), rec(2, 'C', 4, 1., True)]
        slot = []
        out = m.select_attempts_e33(task, rows, _slots_out=slot)
        self.assertEqual([x['attempt_1'] for x in out], [[[4]], [[5]], [[6]]])
        self.assertEqual([x['attempt_2'] for x in out], [[[7]], [[8]], [[9]]])
        self.assertEqual(slot[0]['attempt_2'], '1E')
    def test_invalid_grids_and_input_fallback(self):
        task = ST._tasks(1, nq=2)['t000']
        r = _record('t000', task, 3, 1., True, 1)
        r['submissions'][0]['test_outputs'] = [[[100]], [[2]]]
        r['e33'] = {'attempt': 1, 'stage': 'C', 'phase': 'C-POETIQ1'}
        out = FIX['post'].select_attempts_e33(task, [r])
        self.assertEqual(out[0]['attempt_1'], [[9]])
        self.assertEqual(out[1]['attempt_1'], [[2]])
    def test_negative_control_unpatched_selector(self):
        self.assertFalse(hasattr(FIX['base'], 'select_attempts_e33'))
    def test_unpatched_base_fails_the_full_chain_requirement(self):
        # Negative control: with the same E33 env the unpatched E29 base still runs its old A/B/C,
        # and cannot produce the required Poetiq1/Poetiq2/E sequence.
        scripts = dict([_s('t000','A'), _s('t000','B1')])
        ST.SCRIPTS.clear(); ST.SCRIPTS.update(scripts)
        with ST.Env(supply=False, e28=True, E33_SCHED=1, E33_POETIQ=1,
                    E33_DIRECT=1, E33_ATTEMPT2=0):
            tasks = ST._tasks(1)
            recs, _, _ = ST._solve(FIX['base'], tasks, list(tasks), 1,
                                   deadline_sec=10., min_admit=.1)
        self.assertFalse(any(r.get('e33') for r in recs['t000']))
        self.assertNotEqual([r.get('e28',{}).get('phase') for r in recs['t000']],
                            ['A','B1','C-POETIQ1','D-POETIQ2','E-DIRECT'])



class TestSwitchOff(unittest.TestCase):
    def test_byte_identical_behavior_e28_and_rev6(self):
        scripts = dict([_s('t000', 'A', 'pass'), _s('t001', 'A', 'fail'), _s('t001', 'B1', 'pass')])
        for enabled in (True, False):
            with self.subTest(e28=enabled):
                ST.SCRIPTS.clear(); ST.SCRIPTS.update(scripts)
                with ST.Env(supply=False, e28=enabled, E33_SCHED=0):
                    tasks = ST._tasks(2)
                    args = dict(out_dir=FIX['tmp'] / ('off_' + str(time.monotonic_ns())),
                                deadline=time.monotonic() + 10, base_url='http://127.0.0.1:9/v1',
                                model_id='fake', workers=1, agent_cls=ST.make_fake(FIX['base']),
                                min_admit_sec=.1, analyzer_timeout=30., capacity_probe=None)
                    a = FIX['base'].solve_all_r6(tasks, list(tasks), **args)
                    ra = copy.deepcopy(FIX['base'].SCHED_LAST)
                    args.update(out_dir=FIX['tmp'] / ('off_' + str(time.monotonic_ns())),
                                deadline=time.monotonic() + 10, agent_cls=ST.make_fake(FIX['post']))
                    b = FIX['post'].solve_all_r6(tasks, list(tasks), **args)
                    rb = copy.deepcopy(FIX['post'].SCHED_LAST)
                    self.assertEqual(ST._norm_recs(a, False), ST._norm_recs(b, False))
                    if enabled:
                        self.assertEqual(ST._norm_e28(ra['e28'], False), ST._norm_e28(rb['e28'], False))
                    self.assertEqual(FIX['base'].build_submission(tasks, a), FIX['post'].build_submission(tasks, b))


if __name__ == '__main__':
    unittest.main(verbosity=2)
