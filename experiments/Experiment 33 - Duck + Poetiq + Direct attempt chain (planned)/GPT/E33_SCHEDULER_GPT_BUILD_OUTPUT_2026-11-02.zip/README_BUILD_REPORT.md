# E33 attempt-chain scheduler — GPT build / CPU validation

**Status:** BUILD COMPLETE; **CPU synthetic scripted-Duck: 21/21 PASS**; real Duck payload / Kaggle GPU / Poetiq-client integration: **UNVERIFIED**. Not a production GO until full vendor-backed harness, CPU kit and GPU smoke pass.

## Inputs / exact identity

- Input bundle: `E33_SCHEDULER_BUILD_for_GPT_FLAT_2026-11-02.zip`.
- Base: `BASE__arc2_duck_E29_post.py` SHA-256 `d8603109f9530896e9e4a56e52806202fc2cd4c58bd664d9a25222fe6f7592c2`.
- Generated post SHA-256 `692c230a861d55d83c93f6e238e7924466025aefb87e21b47778189d0088cb34`.
- Generated strict unified diff SHA-256 `81f997d4ce00a4ec0ad7e3e1a8aa3025033e9865e65a531ac1b1e0d3a20db25b`.
- Generated applier module SHA-256 `f3079d6835c208be9dcb07600f882055437ebe9a5b2ae78925ee8daa1ea0a99a`.
- Original supplied 13/13 file SHA/size manifest PASS.

## Deliverables

- `e33_sched_build.py`: standalone builder using `once(text, old, new, label)` for three edits, followed by the new E33 functions. Exports `make_sched(base_text, base_sha) -> (post_text, patch_text, module_text)`. The diff is created with `difflib.unified_diff(..., n=3)`.
- `e33_sched.diff`: exact strict unified diff from base to post. Validated forward and reverse using the supplied `REF__e28_sched_patch.py`'s `apply_unified` / `reverse_unified`.
- `e33_sched_patch.py`: generated `apply`, `verify`, `revert`, `tree_state`, `cell3` API. SHA checked, exact pre/post, atomic file writes through E28 applier, py_compile, fail-closed notebook startup.
- `E33__arc2_duck_post.py`: convenience full patched text (do **not** apply the diff on this file again).
- `e33_sched_tests.py`: scripted-Duck unit suite, with local stub vendor mode and real vendor-backed mode controlled by `E33_TEST_REAL=1`.

## Exact base edits

1. In `solve_all_r6`, insert `_e33_on()` dispatch to separate `_e33_solve_all(...)` **before** existing `_e28_on()` dispatch. The E28/E29 code is otherwise unchanged when E33 is OFF.
2. In `build_submission`, use `select_attempts_e33` when E33 is ON, otherwise use the original E28 or r5 selector exactly as before.
3. In `e28_slot_table`, dispatch to `select_attempts_e33` when E33 is ON; otherwise preserve `select_attempts_e28`.
4. Append the E33 hooks, branch map, selection function and independent scheduler. E29's existing supply functions are reused.

## Branch IDs (collision-free)

| Attempt | A | B1/B2 (shared branch per attempt) | C Poetiq1 | D Poetiq2 | E Direct |
|---|---:|---:|---:|---:|---:|
| 1 | `0` | `2` | `-1` | `-2` | `-3` |
| 2 | `-10` | `-11` | `-12` | `-13` | `-14` |

E29 supply uses `3, 4, ...`; the negative E33 branch IDs cannot collide with supply. Each stage has its own request/record/reservation key `(task, branch)`. B1 and B2 cannot coexist for the same attempt and share that attempt's B branch.

## Priority and chain implementation

- Each attempt runs independently and **strictly sequentially**: A → optional B1/B2 → C → D → E, stopping on first train pass. A TIME does not queue B, C, or attempt-2 A.
- Attempt-2 A is queued upon attempt-1 A completion and may run concurrently with a different stage of attempt 1.
- `priority()` sorts by (attempt 1 before attempt 2), then already-waiting B2, stage A/B/C/D/E, attempt-2 group (A1 not train-pass first), task order for group 1, ascending A1 tokens for group 2, stable index.
- KV fit uses the existing E28 hook and backfill across priority-sorted candidates. When no session is running, the top item is forced as in E28 to avoid deadlock. E29 supply is considered only when both attempts' pending queues are empty.
- `E33_RUN_POETIQ` receives `iteration=1/2` and the published Poetiq iteration-1 record on iteration 2. No client/model transport was implemented in this scheduler-only deliverable.
- `E33_CAN_START(stage, deadline)` is passed a label such as `C-POETIQ1`, `D-POETIQ2`, `E-DIRECT` and is required to enforce the 60k thinking floor before drain. False, missing/raising hook, malformed stage budget, missing/malformed record all terminate that stage with a recorded SKIP; no next stage is queued.
- Each accepted/admitted item is counted once in `started`, published once in records, counted once in `done`, and releases its E28 reservation once even when publishing fails. NOTE: straggling/daemon workers are frozen at deadline; a live Kaggle stress test remains essential.

## Notebook hook contracts / switches

Enable `E28_SCHED=1`, then apply E29 and E33 diff in CELL 3, and bind after importing patched `arc2_duck`:

```python
import e33_sched_patch as E33S
E33_REC = E33S.cell3(E12_DIR, E28_SCHED_REC, {})
assert E33_REC.get('ok') and E33S.verify(E12_DIR)[0]
# E12A is the imported, patched arc2_duck module.
E12A.E33_RUN_POETIQ = poetiq_runner   # (tid, task, plan, deadline, base_url, model_id, out_dir, iteration, prior_record) -> dict|None
E12A.E33_RUN_DIRECT = direct_runner   # (tid, task, plan, deadline, base_url, model_id, out_dir) -> dict|None
E12A.E33_CAN_START = can_start_e33    # (stage, deadline) -> bool
```

- `E33_SCHED=1` enables scheduler (requires E28); `E33_POETIQ=1`, `E33_DIRECT=1`, `E33_ATTEMPT2=1` independently enable methods/second attempt. These latter switches must be set by the notebook. Malformed or absent method flags mean OFF.
- Poetiq budgets: `E33_POETIQ_THINK=60000`, `E33_POETIQ_ANSWER=8192`. Direct budgets: `E33_DIRECT_THINK=104000`, `E33_DIRECT_ANSWER=8192`. Malformed, nonpositive or under-60k thinking budget turns only the affected stage off. A/B budgets use the E28 configuration.
- The supplied E29 DIRECT *scheduler* diff `e29d_sched_patch.py` must **not** be applied to this E33 post. E33 calls the Direct client through its own `E33_RUN_DIRECT` hook.
- The notebook must provide the Poetiq client and E29 Direct client; no claim of Poetiq core parity with E18 was tested here.

## Answer rule / slot reporting

`select_attempts_e33` performs per-query grid K → test K mapping with `valid_grid` validation. Within each attempt it takes first verified train-pass output, else highest train fraction among Duck and Poetiq, else Direct grid. Attempt-2 gets the best distinct candidate from its own chain, else the next distinct attempt-1 candidate, then E28/r5 fallback candidates and finally input. Sources are saved in `SCHED_LAST['e28']['slots']`, and counts/tokens/seconds/skipped reasons and per-task stage reached appear in `SCHED_LAST['e28']['e33']`.

## Test evidence / limits

Run: `python e33_sched_tests.py -q` in this extracted ZIP. Local tests use `ST.make_fake`, `ST.SCRIPTS`, `ST.Env`, `ST._solve`, `ST._norm_recs`, `ST._norm_e28` with a minimal vendor stub since the Duck payload zip was not supplied. The 21 tests cover strict patch/revert, no-fuzz failure, CELL 3 fail-closed startup, negative control unpatched E29, complete single-worker chain, stop-on-pass, B1/B2/straight-C, attempt-2 groups/priority, missing/false/exception hooks, hard/soft end, bad budgets and train-pass evidence, 4-worker release-once, supply-after-queues, answer rules, 3-test grid indexing and E33-OFF E28/rev6 identity.

**Real vendor-backed testing NOT RUN**. In the user's environment, place `e28_sched_patch.py`, `e29_sched_patch.py`, `e29_sched_tests.py` next to this suite, configure `E28_TEST_PAYLOAD` and any reference data paths as in ST, then run `E33_TEST_REAL=1 python e33_sched_tests.py -q`. This explicitly calls `ST.setUpModule()` to extract the real Duck payload and uses the real `BranchSession` / vendor.

**No Kaggle GPU test performed.** No Poetiq model/client transport tested. No strict GPU-run GO claimed. The E33 opt-in configuration should run CPU-kit and 70-minute smoke validation before production.

## Residual risk / follow-up checks

1. **HIGH / verification required**: negative branch IDs are new to the vendor-backed Duck path. Check seed independence, priority dispatch, budget/window, output filenames, live metrics and actual notebook reservation hook with the real payload.
2. **HIGH / integration required**: bind the Poetiq/Direct client hooks, preserved token-ID streaming and feedback; `E33_CAN_START` must enforce the user floor. If missing, E33 fail-closes each hook stage and marks it skipped.
3. **MEDIUM**: E33 uses a distinct scheduler loop. The same E28 admission semantics are ported (KV gate, backfill, idle-force), but exact vendor-backed capacity/gauges/timeout parity is not yet established.
4. **MEDIUM**: E29 supply cap counts only actual Duck A/B/S stages; Poetiq/Direct are excluded because they are not Duck supply attempts. If a different supply-cap policy is desired, reconcile with the user's fixed E33 design before changing this.
5. **MEDIUM**: asynchronous stragglers and notebook's 12-hour long-run lifecycle require GPU validation. Avoid merging the previously separate E29 DIRECT scheduler diff.
