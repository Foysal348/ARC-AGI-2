"""E33 strict scheduler generator. stdlib only; builds an opt-in E29 post diff.
Pinned base: d8603109f9530896e9e4a56e52806202fc2cd4c58bd664d9a25222fe6f7592c2.
"""
import difflib
import hashlib
from pathlib import Path

BASE_SHA = "d8603109f9530896e9e4a56e52806202fc2cd4c58bd664d9a25222fe6f7592c2"
MARKER = "# E33 ATTEMPT CHAIN: per-attempt A/B/Poetiq1/Poetiq2/Direct; E29 off-path unchanged."


def sha(x):
    return hashlib.sha256((x.encode('utf-8') if isinstance(x, str) else x)).hexdigest()


def once(text, old, new, label):
    found = text.count(old)
    if found != 1:
        raise AssertionError(f'{label}: expected once, found {found}')
    return text.replace(old, new)

TAIL_SRC = r'''

# E33 ATTEMPT CHAIN: separate, opt-in scheduler. The E29 path is untouched when E33_SCHED != "1".
E33_MARKER = '# E33 ATTEMPT CHAIN: per-attempt A/B/Poetiq1/Poetiq2/Direct; E29 off-path unchanged.'
E33_RUN_POETIQ = None
E33_RUN_DIRECT = None
E33_CAN_START = None
E33_BRANCH = {(1, 'A'): 0, (1, 'B'): 2, (1, 'C'): -1, (1, 'D'): -2, (1, 'E'): -3,
              (2, 'A'): -10, (2, 'B'): -11, (2, 'C'): -12, (2, 'D'): -13, (2, 'E'): -14}
E33_STAGES = ('A', 'B1', 'B2', 'C-POETIQ1', 'D-POETIQ2', 'E-DIRECT')
E33_STAGE_NAMES = {'C': 'C-POETIQ1', 'D': 'D-POETIQ2', 'E': 'E-DIRECT'}


def _e33_flag(key):
    """Only the literal '1' enables an item. Malformed values fail closed for that item."""
    return os.environ.get(key, '').strip() == '1'


def _e33_on():
    return _e28_on() and _e33_flag('E33_SCHED')


def _e33_stage(phase):
    return phase[:1]


def _e33_budget_value(name, default):
    """Malformed or nonpositive explicit budgets fail closed, not silently replaced by the default."""
    raw = os.environ.get(name)
    if raw is None:
        return default, True
    try:
        val = int(raw)
    except (ValueError, TypeError):
        return default, False
    return val, 0 < val <= 131072


def _e33_record_candidates(rec, qi):
    """Valid per-query grids from this record, keeping their train-match evidence and source order."""
    e = rec.get('e33') or {}
    stage = e.get('stage') or _e33_stage(str((rec.get('e28') or {}).get('phase') or ''))
    if stage not in ('A', 'B', 'C', 'D', 'E'):
        return []
    meta = rec.get('poetiq') or {}
    poetiq_score = meta.get('score', 0)
    try:
        poetiq_score = max(0.0, min(1.0, float(poetiq_score)))
    except (TypeError, ValueError):
        poetiq_score = 0.0
    full = (bool(meta.get('train_pass')) if stage in ('C', 'D')
            else (e28_train(rec)['full'] if stage in ('A', 'B') else False))
    cand = []
    for typ, entries in (('submissions', rec.get('submissions') or []), ('checked', rec.get('checked') or [])):
        for idx, s in enumerate(entries if isinstance(entries, list) else []):
            if not isinstance(s, dict):
                continue
            outs = s.get('test_outputs') or []
            g = outs[qi] if isinstance(outs, list) and qi < len(outs) else None
            if not valid_grid(g):
                continue
            te = s.get('train_exact') or []
            te = te if isinstance(te, list) else []
            k, n = sum(bool(x) for x in te), len(te)
            frac = (float(k) / n) if n else 0.0
            if stage in ('C', 'D'):
                frac = poetiq_score
            # First stage train pass gets priority even if a hook left accepted unset.
            is_full = bool(full and s.get('accepted'))  # Never promote a different, non-accepted Duck submission.
            cand.append({'grid': g, 'full': is_full, 'frac': 1.0 if is_full else frac,
                         'k': k, 'n': n, 'origin': typ, 'index': idx})
    return cand


def _e33_records_for_attempt(records, attempt):
    rows = [r for r in records if isinstance(r, dict)
            and (r.get('e33') or {}).get('attempt') == attempt]
    return sorted(rows, key=lambda r: (('A', 'B', 'C', 'D', 'E').index((r.get('e33') or {}).get('stage', 'E')),
                                       int(r.get('publish_seq') or 0)))


def _e33_ranked_candidates(records, qi):
    """First full train pass, then best partial match; ties keep earlier stages and older candidates."""
    rows = []
    for ri, r in enumerate(records):
        for ci, c in enumerate(_e33_record_candidates(r, qi)):
            rows.append((r, c, ri, ci))
    return sorted(rows, key=lambda x: (-int(x[1]['full']), -x[1]['frac'], x[2], x[3]))


def select_attempts_e33(task, branch_records, _slots_out=None):
    """User-fixed E33 answer rules, independently for every test input. Supply is fallback, not an E33 chain."""
    a1_recs = _e33_records_for_attempt(branch_records, 1)
    a2_recs = _e33_records_for_attempt(branch_records, 2)
    fallbacks = []
    # E28's candidate tiers on existing Duck / supply records; no unverified hook outputs in fallback pools.
    base_recs = [r for r in branch_records if ((r.get('e33') or {}).get('stage') in ('A', 'B')
                                           or str((r.get('e28') or {}).get('phase') or '').startswith('S'))]
    select_attempts_r5(task, base_recs, _e28_lists=fallbacks)
    outputs = []
    for qi, q in enumerate(task['test']):
        seq1, seq2 = _e33_ranked_candidates(a1_recs, qi), _e33_ranked_candidates(a2_recs, qi)
        fallback = [(g, 'r5') for g in (fallbacks[qi] if qi < len(fallbacks) else []) if valid_grid(g)]
        fallback.append((q['input'], 'input'))
        def pick(rows, exclude=None):
            for r, c, _, _ in rows:
                if exclude is None or c['grid'] != exclude:
                    e = r.get('e33') or {}
                    return c['grid'], f"{e.get('attempt')}{e.get('phase')}"
            return None
        first = pick(seq1)
        if first is None:
            g1, src1 = next(((g, src) for g, src in fallback), (q['input'], 'input'))
        else:
            g1, src1 = first
        second = pick(seq2, g1)
        if second is None:
            second = pick(seq1, g1)
        if second is None:
            second = next(((g, src) for g, src in fallback if g != g1), None)
        g2, src2 = second if second is not None else (q['input'], 'input')
        if not valid_grid(g2):
            g2, src2 = q['input'], 'input'
        outputs.append({'attempt_1': g1, 'attempt_2': g2})
        if _slots_out is not None:
            _slots_out.append({'qi': qi, 'attempt_1': src1, 'attempt_2': src2,
                               'a1_candidates': len(seq1), 'a2_candidates': len(seq2)})
    return outputs


def _e33_solve_all(tasks, order, *, out_dir, deadline, base_url, model_id,
                   save_request_logs=False, on_branch_done=None, workers=10,
                   b1_view='facts', min_admit_sec=240.0, capacity_probe=None,
                   agent_cls=None, analyzer_timeout=None, join_grace_sec=60.0,
                   kv_admit_limit=0.95, kv_poll_sec=5.0, kv_stale_sec=30.0,
                   weak_commit=False, ignored=None):
    """E33 opt-in scheduler, independently sequenced for attempts 1/2 with E28 KV backfill + E29 supply."""
    agent_cls = agent_cls or make_agent_class()
    cfg = e28_config()
    timeout = float(analyzer_timeout or os.environ.get('E12_DUCK_REQUEST_TIMEOUT') or 900.0)
    b2_timeout = float(cfg['b2_request_timeout'] or timeout * max(1, cfg['b2_tokens'] / max(1, cfg['t1'])))
    started = time.monotonic()
    order = [t for t in order if t in tasks]
    idx = {t: i for i, t in enumerate(order)}
    E28_PLANS.clear()
    cond = threading.Condition()
    queues = []
    sessions = {}
    records = {t: [] for t in order}
    active = set()
    meta = {}
    seq = [0]
    state = {'stop': False, 'running': 0, 'publish_seq': 0, 'pop_seq': 0, 'events': [], 'durations': [],
             'kv': None, 'kv_t': None, 'last_free_t': None, 'kv_holds': 0, 'kv_hold_sec': 0.,
             'kv_samples': 0, 'kv_missing': 0, 'kv_stale_checks': 0, 'kv_idle_overrides': 0,
             'kv_superseded': 0, 'fit_errors': 0, 'worker_errors': 0, 'gauges': [], 'closed': False}
    e28 = {'started': {}, 'done': {}, 'queued': {}, 'a_class': {}, 'b_class': {}, 'rows': {},
           'first_start_sec': {}, 'last_start_sec': {}, 'queue_empty_sec': {}, 'setup_failed': [],
           'pop_seq': 0, 'fit_checks': 0, 'fit_fails': 0, 'fit_errors': 0, 'backfill_starts': 0,
           'forced_admits': 0, 'admission_checks': 0, 'backfill_log': [],
           'idle': {'nothing_fits': 0., 'kv_gate': 0., 'no_runnable': 0.}}
    e33 = {'queued': {}, 'started': {}, 'done': {}, 'skipped': {}, 'train_pass': {}, 'tokens': {}, 'seconds': {},
           'per_task': {t: {'1': [], '2': []} for t in order}, 'skipped_reasons': {},
           'branch_map': {f'{a}{p}': b for (a, p), b in E33_BRANCH.items()},
           'switches': {k: _e33_flag('E33_' + k) for k in ('POETIQ', 'DIRECT', 'ATTEMPT2')}}
    for a in (1, 2):
        for ph in E33_STAGES:
            k = f'{a}:{ph}'
            for field in ('queued', 'started', 'done', 'skipped', 'train_pass', 'tokens', 'seconds'):
                e33[field][k] = 0
    sup = _e29_supply_state(e28) if _e29_on() else None
    if sup is not None:
        # No supply branch collides with the E33 negative branch IDs.
        sup['c'].update(order)
    def sec():
        return round(time.monotonic() - started, 3)
    def stagekey(p):
        return f"{p['attempt']}:{p['phase']}"
    def newplan(tid, attempt, phase, **kw):
        s = _e33_stage(phase)
        valid_budget = True
        if s in ('C', 'D', 'E'):
            pre = 'E33_DIRECT' if s == 'E' else 'E33_POETIQ'
            think, ok1 = _e33_budget_value(pre + '_THINK', 104000 if s == 'E' else 60000)
            answer, ok2 = _e33_budget_value(pre + '_ANSWER', 8192)
            budget = think + answer
            valid_budget = ok1 and ok2 and think >= 60000 and budget <= 131072
        else:
            budget = cfg['b2_tokens'] if phase == 'B2' else cfg['t1']
        # A malformed stage-specific budget disables only that Poetiq/Direct item.
        p = {'task': tid, 'attempt': attempt, 'branch': E33_BRANCH[(attempt, s)], 'phase': phase,
             'budget': budget, 'valid_budget': valid_budget,
             'window': cfg['b2_window'] if phase == 'B2' else None,
             'timeout': b2_timeout if phase == 'B2' else timeout}
        p.update(kw)
        return p
    def enqueue(p):
        with cond:
            k = (p['task'], p['branch'])
            if k in active or any((x['task'], x['branch']) == k for x in queues):
                raise AssertionError('E33 duplicate stage: ' + repr(k))
            seq[0] += 1
            p['seq'] = seq[0]
            queues.append(p)
            meta[k] = {'queued_sec': sec(), 'first_tried_sec': None, 'fit_fails': 0,
                       'backfill': 0, 'waiting': False}
            e33['queued'][stagekey(p)] += 1
            cond.notify_all()
    for t in order:
        enqueue(newplan(t, 1, 'A'))
    def priority(p):
        a, ph = p['attempt'], p['phase']
        m = meta.get((p['task'], p['branch']), {})
        waiting_b2 = ph == 'B2' and m.get('waiting')
        s = _e33_stage(ph)
        order_stage = {'A': 0, 'B': 1, 'C': 2, 'D': 3, 'E': 4}[s]
        # Group 1: non-pass A1 in task order; group 2: train-pass A1 by ascending A1 tokens.
        a1 = e28['a_class'].get(p['task'], {})
        group = 0 if a1.get('kind') != 'TRAIN_PASS' else 1
        groupkey = idx[p['task']] if group == 0 else int(a1.get('tokens') or 0)
        return (a, 0 if waiting_b2 else 1, order_stage, group, groupkey, idx[p['task']], p['seq'])
    def can_stage(p):
        s = _e33_stage(p['phase'])
        if s not in ('C', 'D', 'E'):
            return True, 'duck'
        enabled = _e33_flag('E33_DIRECT' if s == 'E' else 'E33_POETIQ')
        hook = E33_RUN_DIRECT if s == 'E' else E33_RUN_POETIQ
        if not enabled or hook is None:
            return False, 'switch_off' if not enabled else 'no_hook'
        if not p['valid_budget']:
            return False, 'invalid_budget'
        gate = E33_CAN_START
        if gate is None:
            return False, 'no_can_start'
        try:
            return (True, 'ready') if gate(E33_STAGE_NAMES[s], deadline) is True else (False, 'late_or_false')
        except Exception as exc:
            return False, 'can_start_' + type(exc).__name__
    def fit(p):
        if E28_TRY_RESERVE is None:
            return True
        e28['fit_checks'] += 1
        try:
            ok = bool(E28_TRY_RESERVE((p['task'], p['branch']), dict(p)))
        except Exception as exc:  # E28's original fail-open reservation-hook policy.
            e28['fit_errors'] += 1
            state['events'].append({'t': sec(), 'kind': 'e28_fit_error', 'error': repr(exc)[:160]})
            return True
        if not ok:
            e28['fit_fails'] += 1
        return ok
    def start(p, wi, qlens, start_seq):
        k = (p['task'], p['branch'])
        active.add(k)
        state['running'] += 1
        label = stagekey(p)
        if p['attempt'] in (1, 2):
            e33['started'][label] += 1
        e28['started'][p['phase']] = e28['started'].get(p['phase'], 0) + 1
        e28['first_start_sec'].setdefault(p['phase'], sec())
        e28['last_start_sec'][p['phase']] = sec()
        m = meta.setdefault(k, {'queued_sec': sec(), 'first_tried_sec': None, 'fit_fails': 0,
                                'backfill': 0, 'waiting': False})
        return {'task': p['task'], 'branch': p['branch'], 'attempt': p['attempt'], 'phase': p['phase'],
                'stage': _e33_stage(p['phase']), 'start_sec': sec(), 'worker_slot': wi,
                'start_seq': start_seq, 'queues_at_start': qlens, 'budget': p['budget'],
                'queued_sec': m['queued_sec'], 'wait_sec': sec() - m['queued_sec']}
    def publish(rec, final=False):
        with cond:
            if state['closed'] and not final:
                return
            rec = copy.deepcopy(rec)
            state['publish_seq'] += 1
            rec['publish_seq'] = state['publish_seq']
            rows = records.setdefault(rec['task_id'], [])
            rows[:] = [r for r in rows if r.get('branch') != rec.get('branch')] + [rec]
        if on_branch_done is not None:
            try:
                on_branch_done(copy.deepcopy(rec))
            except Exception as exc:
                log.warning('E33 publish hook: %s', exc)
    def release(p):
        if E28_RELEASE is not None:
            try:
                E28_RELEASE((p['task'], p['branch']))
            except Exception as exc:
                state['events'].append({'t': sec(), 'kind': 'release_error', 'error': repr(exc)[:160]})
    def route(p, cls):
        s, tid, attempt = _e33_stage(p['phase']), p['task'], p['attempt']
        kind = cls.get('kind')
        if sup is not None:
            _e29_note_end(sup, tid, p['phase'], cls)
        if s == 'A':
            if attempt == 1:
                e28['a_class'][tid] = {k: cls.get(k) for k in ('kind', 'end_reason', 'tokens')}
                if _e33_flag('E33_ATTEMPT2') and kind != 'TIME':
                    enqueue(newplan(tid, 2, 'A', a1_kind=kind, a1_tokens=cls.get('tokens', 0)))
                elif _e33_flag('E33_ATTEMPT2') and kind == 'TIME':
                    # The solve window is over: no attempt-2 new work.
                    pass
            if kind not in ('TRAIN_PASS', 'TIME'):
                bp = e28_b_phase(kind)
                enqueue(newplan(tid, attempt, bp, previous_kind=kind) if bp else
                        newplan(tid, attempt, 'C-POETIQ1'))
        elif s == 'B':
            if attempt == 1:
                e28['b_class'][tid] = {k: cls.get(k) for k in ('kind', 'end_reason', 'tokens')}
            if kind not in ('TRAIN_PASS', 'TIME'):
                enqueue(newplan(tid, attempt, 'C-POETIQ1'))
        elif s == 'C' and kind != 'TRAIN_PASS':
            enqueue(newplan(tid, attempt, 'D-POETIQ2'))
        elif s == 'D' and kind != 'TRAIN_PASS':
            enqueue(newplan(tid, attempt, 'E-DIRECT'))
        elif s == 'S' and sup is not None:
            sup['s_class'].setdefault(tid, []).append({k: cls.get(k) for k in ('kind', 'end_reason', 'tokens')})
    def finish(p, row, rec, cls, started_at, error=None, skipped=False):
        tid, b, lab = p['task'], p['branch'], stagekey(p)
        row.update(end_sec=sec(), tokens=int((rec or {}).get('generated_tokens') or 0),
                   kind=cls['kind'], end_reason=cls.get('end_reason'), status='skipped' if skipped else 'done',
                   error=error, best_train=cls.get('train'))
        m = meta.get((tid, b)) or {}
        row.update(fit_fails=m.get('fit_fails', 0), backfill_starts_while_waiting=m.get('backfill', 0))
        if rec is None:
            rec = {'task_id': tid, 'branch': b, 'status': 'skipped' if skipped else 'done',
                   'generated_tokens': 0, 'submissions': [], 'checked': [], 'accepted': False,
                   'note': error or cls.get('end_reason', '')}
        rec = dict(rec)
        rec['task_id'], rec['branch'] = tid, b
        if p['attempt'] in (1, 2):
            rec['e33'] = {'attempt': p['attempt'], 'stage': _e33_stage(p['phase']),
                          'phase': p['phase'], 'kind': cls['kind'], 'skipped': bool(skipped)}
        rec['e28'] = dict(row)
        rec['submissions'] = [dict(s_, branch=b) for s_ in rec.get('submissions') or [] if isinstance(s_, dict)]
        if (tid, b) in sessions:
            # Preserve provenance in the actual Duck branch_result.json as well as in the scheduler records.
            ses = sessions[(tid, b)]
            ses.record['e28'] = dict(row)
            ses.record['e33'] = dict(rec.get('e33') or {})
            try:
                ses.write()
            except Exception as exc:
                state['events'].append({'t': sec(), 'kind': 'disk_record_error',
                                        'task': tid, 'error': repr(exc)[:200]})
        publish(rec)
        with cond:
            e28['done'][p['phase']] = e28['done'].get(p['phase'], 0) + 1
            if p['attempt'] in (1, 2):
                e33['done'][lab] += 1
                e33['tokens'][lab] += row['tokens']
                e33['seconds'][lab] += round(time.monotonic() - started_at, 3)
                e33['train_pass'][lab] += int(cls['kind'] == 'TRAIN_PASS')
            if skipped:
                if p['attempt'] in (1, 2):
                    e33['skipped'][lab] += 1
                    e33['skipped_reasons'][f'{tid}:{lab}'] = cls.get('end_reason')
            if p['attempt'] in (1, 2):
                e33['per_task'][tid][str(p['attempt'])].append({'phase': p['phase'], 'branch': b,
                    'kind': cls['kind'], 'tokens': row['tokens'], 'skipped': skipped})
            e28['rows'][f'{tid}_b{b}'] = row
            state['running'] -= 1
            state['last_free_t'] = time.monotonic()
            active.discard((tid, b))
            state['durations'].append(round(time.monotonic() - started_at, 3))
            if not skipped:
                route(p, cls)
            cond.notify_all()
    def kv_blocked():
        kv, when = state['kv'], state['kv_t']
        if kv is None or when is None or time.monotonic() - when > kv_stale_sec:
            return False
        if state['last_free_t'] is not None and when < state['last_free_t']:
            state['kv_superseded'] += 1
            return False
        return kv >= kv_admit_limit
    def probe_once():
        if capacity_probe is None:
            return
        try:
            snap = capacity_probe() or {}
        except Exception:
            snap = {}
        with cond:
            state['kv'], state['kv_t'] = _finite01(snap.get('kv_usage')), time.monotonic()
            state['kv_samples'] += 1
            state['kv_missing'] += int(state['kv'] is None)
            SERVER_LAST.clear()
            SERVER_LAST.update({k: snap.get(k) for k in ('kv_usage', 'mamba_usage', 'running', 'queue')}, t=state['kv_t'])
            cond.notify_all()
    def pick(wi):
        e28['admission_checks'] += 1
        candidates = sorted(queues, key=priority)
        bad_budgets, skipped_fit = set(), []
        for p in candidates:
            k = (p['task'], p['branch'])
            m = meta[k]
            if m['first_tried_sec'] is None:
                m['first_tried_sec'] = sec()
            if p['budget'] in bad_budgets or not fit(p):
                bad_budgets.add(p['budget'])
                m['waiting'] = True
                m['fit_fails'] += 1
                skipped_fit.append(k)
                continue
            if skipped_fit:
                e28['backfill_starts'] += 1
                for key in skipped_fit:
                    meta[key]['backfill'] += 1
            queues.remove(p)
            return p, skipped_fit
        if candidates and state['running'] == 0:
            e28['forced_admits'] += 1
            p = candidates[0]
            queues.remove(p)
            return p, skipped_fit
        return None
    def worker(wi):
        while True:
            with cond:
                while True:
                    left = deadline - time.monotonic()
                    if left < min_admit_sec or state['stop']:
                        return
                    has = bool(queues)
                    supply = (not has and sup is not None
                              and bool(_e29_candidates(sup, order, e28['a_class'])))
                    if (has or supply) and kv_blocked() and state['running'] > 0:
                        e28['idle']['kv_gate'] += max(0.01, kv_poll_sec)
                        cond.wait(timeout=min(5.0, max(.1, kv_poll_sec)))
                        continue
                    if has:
                        got = pick(wi)
                    elif supply:
                        c = _e29_candidates(sup, order, e28['a_class'])
                        got = None
                        for ph, tid, why in c:
                            sn = sup['s_n'].get(tid, 0) + 1
                            spp = {'task': tid, 'attempt': 0, 'branch': sup['next_b'].get(tid, 3),
                                   'phase': ph, 'budget': cfg['b2_tokens'] if ph == 'S2' else cfg['t1'],
                                   'window': cfg['b2_window'] if ph == 'S2' else None,
                                   'timeout': b2_timeout if ph == 'S2' else timeout,
                                   's_index': sn, 's_reason': why,
                                   'view': b1_view if sn % 2 else 'facts'}
                            if fit(spp):
                                got = (spp, [])
                                _e29_take(sup, e28, tid, spp)
                                break
                        if got is None and c and state['running'] == 0:
                            ph, tid, why = c[0]
                            sn = sup['s_n'].get(tid, 0) + 1
                            spp = {'task': tid, 'attempt': 0, 'branch': sup['next_b'].get(tid, 3), 'phase': ph,
                                   'budget': cfg['b2_tokens'] if ph == 'S2' else cfg['t1'],
                                   'window': cfg['b2_window'] if ph == 'S2' else None,
                                   'timeout': b2_timeout if ph == 'S2' else timeout,
                                   's_index': sn, 's_reason': why, 'view': b1_view if sn % 2 else 'facts'}
                            _e29_take(sup, e28, tid, spp)
                            e28['forced_admits'] += 1
                            got = (spp, [])
                    else:
                        if state['running'] == 0:
                            state['stop'] = True
                            cond.notify_all()
                            return
                        cond.wait(timeout=.1)
                        continue
                    if got is None:
                        e28['idle']['nothing_fits'] += .1
                        cond.wait(timeout=.1)
                        continue
                    p, skips = got
                    tid, b = p['task'], int(p['branch'])
                    if (tid, b) in active:
                        raise AssertionError('E33 branch concurrent ' + repr((tid, b)))
                    if sup is not None and _e33_stage(p['phase']) in ('A', 'B', 'S'):
                        # E29 supply cap counts Duck attempts, not Poetiq/Direct/skip stages.
                        _e29_note_take(sup, tid, p)
                    state['pop_seq'] += 1
                    qlens = [sum(x['attempt'] == 1 for x in queues), sum(x['attempt'] == 2 for x in queues), 0]
                    row = start(p, wi, qlens, state['pop_seq'])
                    break
            t0 = time.monotonic()
            stage = _e33_stage(p['phase'])
            rec = None
            cls = {'kind': 'FAIL', 'tokens': 0, 'end_reason': 'not_started', 'train': None}
            err = None
            sk = False
            try:
                if stage in ('C', 'D', 'E'):
                    ok, reason = can_stage(p)
                    if not ok:
                        sk = True
                        err = reason
                        cls = {'kind': 'SKIP', 'tokens': 0, 'end_reason': reason, 'train': None}
                    else:
                        hook = E33_RUN_DIRECT if stage == 'E' else E33_RUN_POETIQ
                        with cond:
                            prior = (copy.deepcopy(next((x for x in records.get(tid, [])
                                    if (x.get('e33') or {}).get('attempt') == p['attempt']
                                    and (x.get('e33') or {}).get('stage') == 'C'), None)) if stage == 'D' else None)
                        args = (tid, tasks[tid], dict(p), deadline, base_url, model_id,
                                Path(out_dir) / ('direct' if stage == 'E' else 'poetiq'))
                        rec = (hook(*args) if stage == 'E' else hook(*args, 1 if stage == 'C' else 2, prior))
                        if (not isinstance(rec, dict) or rec.get('task_id') != tid
                                or not isinstance(rec.get('submissions'), list)
                                or (stage in ('C', 'D') and not isinstance(rec.get('poetiq'), dict))
                                or (stage == 'E' and not isinstance(rec.get('e31'), dict))):
                            sk = True
                            rec = None
                            cls = {'kind': 'SKIP', 'tokens': 0, 'end_reason': 'missing_or_bad_record', 'train': None}
                        elif stage in ('C', 'D'):
                            full = bool((rec.get('poetiq') or {}).get('train_pass'))
                            accepted_grids = any(s_.get('accepted') and len(s_.get('test_outputs') or []) == len(tasks[tid]['test'])
                                and all(valid_grid(g) for g in s_.get('test_outputs') or [])
                                for s_ in rec['submissions'] if isinstance(s_, dict))
                            if full and not accepted_grids:
                                sk = True
                                cls = {'kind': 'SKIP', 'tokens': 0, 'end_reason': 'inconsistent_train_pass', 'train': None}
                            else:
                                cls = {'kind': 'TRAIN_PASS' if full else 'B1', 'tokens': int(rec.get('generated_tokens') or 0),
                                       'end_reason': 'poetiq_train' if full else 'poetiq_partial',
                                       'train': {'full': full, 'frac': (rec.get('poetiq') or {}).get('score')}}
                        else:
                            cls = {'kind': 'DIRECT', 'tokens': int(rec.get('generated_tokens') or 0),
                                   'end_reason': 'last_stage', 'train': None}
                else:
                    E28_PLANS[(tid, b)] = dict(p)
                    session = BranchSession(agent_cls, task_id=tid, task=tasks[tid], branch=b,
                        view=p.get('view') or ('facts' if stage == 'A' and p['attempt'] == 1 else b1_view),
                        queue_position=(E29_S_QPOS + sup['seq'] if stage == 'S' and sup is not None
                                        else state['pop_seq']), out_dir=out_dir, deadline=deadline,
                        base_url=base_url, model_id=model_id, save_request_logs=save_request_logs,
                        analyzer_timeout=p['timeout'], started_at=started, max_generated_tokens=p['budget'])
                    session.e28_plan = dict(p)
                    sessions[(tid, b)] = session
                    try:
                        session.run(pause_at_tokens=None, tag={'e28_phase': p['phase'], 'e33_attempt': p['attempt']})
                    finally:
                        rec = session.write()
                    cls = e28_classify(rec, budget=p['budget'], at_deadline=time.monotonic() >= deadline - 5.)
            except Exception as exc:
                err = f'{type(exc).__name__}: {exc}'[:300]
                sk = stage in ('C', 'D', 'E')
                cls = {'kind': 'SKIP' if sk else 'FAIL', 'tokens': 0, 'end_reason': 'hook_error' if sk else 'duck_error',
                       'train': None}
                log.warning('E33 %s %s failure: %s', tid, p['phase'], err)
            # Exactly one publish, one release, and one route decision for this item.
            try:
                finish(p, row, rec, cls, t0, error=err, skipped=sk)
            except Exception as exc:
                with cond:
                    state['worker_errors'] += 1
                    state['events'].append({'t': sec(), 'kind': 'finish_error', 'task': tid, 'error': repr(exc)[:200]})
                    state['running'] -= 1
                    active.discard((tid, b))
                    cond.notify_all()
            finally:
                # A publishing/serialization exception must never leak an E28 reservation.
                release(p)
    probe_once()
    probe = threading.Thread(target=lambda: _e33_probe_loop(), daemon=True)
    def _e33_probe_loop():
        while not state['stop'] and capacity_probe is not None:
            time.sleep(max(0.02, float(kv_poll_sec)))
            if not state['stop']:
                probe_once()
    probe.start()
    threads = [threading.Thread(target=worker, args=(i,), daemon=True)
               for i in range(max(1, int(workers)))]
    for th in threads:
        th.start()
    for th in threads:
        th.join(timeout=max(0., deadline + float(join_grace_sec) - time.monotonic()))
    state['stop'] = True
    with cond:
        state['closed'] = True
        state['stragglers'] = sum(th.is_alive() for th in threads)
    for s in sessions.values():
        if s.agent is not None:
            try:
                snap = s.freeze()
                if (s.task_id, s.branch) in active:
                    # A straggler is terminal: retain its stage identity and prevent late records.
                    pp = s.e28_plan or {}
                    snap['e33'] = {'attempt': pp.get('attempt'), 'stage': _e33_stage(pp.get('phase', 'A')),
                                   'phase': pp.get('phase'), 'kind': 'TIME', 'skipped': False}
                    publish(snap, final=True)
            except Exception as exc:
                state['events'].append({'t': sec(), 'kind': 'freeze_error', 'error': repr(exc)[:120]})
    slots = e28_slot_table(tasks, records)
    rows = sorted(e28['rows'].values(), key=lambda r: (idx.get(r.get('task'), 1 << 30), r.get('start_seq', 1 << 30)))
    SCHED_LAST.clear()
    SCHED_LAST.update(events=state['events'], allowed=max(1, int(workers)), durations=state['durations'][-500:],
                      sessions={f'{t}_b{b}': s.status for (t, b), s in sessions.items()},
                      stragglers=state['stragglers'], worker_errors=state['worker_errors'],
                      stage1_left=sum(p['attempt'] == 1 for p in queues),
                      heap_left=len(queues), workers=max(1, int(workers)),
                      kv_admit_limit=kv_admit_limit, kv_samples=state['kv_samples'], kv_missing=state['kv_missing'],
                      kv_stale_checks=state['kv_stale_checks'], kv_superseded=state['kv_superseded'],
                      e28={'enabled': True, 'config': dict(cfg, workers=workers, tasks=len(order)),
                           'started': e28['started'], 'done': e28['done'], 'queued': e28['queued'],
                           'first_start_sec': e28['first_start_sec'], 'last_start_sec': e28['last_start_sec'],
                           'first_passes': dict(e33['train_pass']), 'attempts': rows, 'slots': slots,
                           'fit_checks': e28['fit_checks'], 'fit_fails': e28['fit_fails'],
                           'fit_errors': e28['fit_errors'], 'backfill_starts': e28['backfill_starts'],
                           'forced_admits': e28['forced_admits'], 'admission_checks': e28['admission_checks'],
                           'a_class': e28['a_class'], 'b_class': e28['b_class'],
                           **({'supply': _e29_report(sup, e28, rows, slots, order)} if sup is not None else {}),
                           'e33': dict(e33, left=[{'task': p['task'], 'attempt': p['attempt'],
                                                    'phase': p['phase']} for p in queues])})
    return records
'''
APPLIER_TEMPLATE = r'''
"""E33 attempt-chain scheduler, strict E29-post -> E33-post applier. Generated by e33_sched_build.py."""
import hashlib
import json
import os
from pathlib import Path
import e28_sched_patch as E28S

DUCK_REL = 'arc2_duck.py'
PRE = __PRE__
POST = __POST__
MARKER = __MARKER__
ENV = 'E33_SCHED'
PATCH = __PATCH__
SHA = {'pre': PRE, 'post': POST, 'patch': hashlib.sha256(PATCH.encode()).hexdigest()}
apply_unified = E28S.apply_unified
reverse_unified = E28S.reverse_unified


def _sha(data):
    return hashlib.sha256(data).hexdigest()


def _is_text(obj):
    return isinstance(obj, str) and '\n' in obj


def _file(obj):
    p = Path(obj)
    return p / DUCK_REL if p.is_dir() else p


def _state_of(data):
    h = _sha(data)
    if h == PRE:
        return 'E29_POST', h
    if h == POST and data.decode('utf-8').count(MARKER) == 1:
        return 'E33_PATCHED', h
    return 'OTHER', h


def tree_state(target):
    if _is_text(target):
        return _state_of(target.encode('utf-8'))[0]
    f = _file(target)
    return _state_of(f.read_bytes())[0] if f.is_file() else 'OTHER'


def verify(target):
    if _is_text(target):
        st, h = _state_of(target.encode('utf-8'))
    else:
        f = _file(target)
        if not f.is_file():
            return False, 'missing ' + str(f)
        st, h = _state_of(f.read_bytes())
    return st == 'E33_PATCHED', f'{st} sha256={h}'


def _move(data, forward):
    out = apply_unified(data.decode('utf-8'), PATCH if forward else reverse_unified(PATCH)).encode('utf-8')
    want = POST if forward else PRE
    if _sha(out) != want:
        raise RuntimeError(f'E33_{"POST" if forward else "REVERT"}_SHA_MISMATCH: {_sha(out)}')
    compile(out.decode('utf-8'), DUCK_REL, 'exec')
    return out


def _do(target, forward):
    key = 'applied' if forward else 'reverted'
    start, done = ('E29_POST', 'E33_PATCHED') if forward else ('E33_PATCHED', 'E29_POST')
    if _is_text(target):
        data = target.encode('utf-8')
        st, h = _state_of(data)
        rec = {'mode': 'text', 'before': st, 'sha_before': h, 'sha': SHA}
        if st == done:
            rec.update({key: 'already' if forward else 'not_applied', 'text': target})
        elif st == start:
            rec.update({key: 'applied' if forward else 'reverted', 'text': _move(data, forward).decode('utf-8')})
        else:
            raise RuntimeError(f'E33_STATE_MISMATCH: {st} {h}')
        rec['after'], rec['sha_after'] = _state_of(rec['text'].encode('utf-8'))
        rec['ok'] = rec['after'] == done
        return rec
    f = _file(target)
    data = f.read_bytes() if f.is_file() else b''
    st, h = _state_of(data)
    rec = {'mode': 'file', 'file': str(f), 'before': st, 'sha_before': h, 'sha': SHA}
    if st == done:
        rec[key] = 'already' if forward else 'not_applied'
    elif st == start:
        E28S._write_atomic(f, _move(data, forward))
        rec[key] = 'applied' if forward else 'reverted'
    else:
        raise RuntimeError(f'E33_STATE_MISMATCH {f}: {st} {h}')
    E28S._drop_pyc(f)
    rec['after'], rec['sha_after'] = _state_of(f.read_bytes())
    rec['py_compile'] = E28S._py_compile(f)
    if rec['after'] != done or rec['py_compile']['rc']:
        raise RuntimeError('E33_VERIFY_FAILED: ' + json.dumps(rec, default=str))
    rec['ok'] = True
    return rec


def apply(target):
    return _do(target, True)


def revert(target):
    return _do(target, False)


def cell3(e12_dir, sched_rec, rec):
    """Fail-closed notebook CELL 3: E33 enabled only after exact SHA + compile verification."""
    rec = dict(rec)
    os.environ.pop(ENV, None)
    if not (sched_rec.get('applied') and sched_rec.get('path') == 'E29'):
        rec['error'] = 'E33 requires E29 scheduler post, got ' + str(sched_rec.get('path'))
        return rec
    try:
        r = apply(e12_dir)
        rec.update({k: v for k, v in r.items() if k != 'text'})
        ok, why = verify(e12_dir)
        if not ok:
            raise RuntimeError('E33 verify: ' + why)
        os.environ[ENV] = '1'
        rec.update(ok=True, verify_why=why)
    except Exception as e:
        os.environ.pop(ENV, None)
        rec['error'] = f'{type(e).__name__}: {e}'[:500]
        try:
            rec['revert'] = {k: v for k, v in revert(e12_dir).items() if k != 'text'}
        except Exception as e2:
            rec['revert_error'] = f'{type(e2).__name__}: {e2}'[:300]
    return rec
'''


def make_sched(base_text, base_sha=BASE_SHA):
    """Return (patched Duck source, strict n=3 unified diff, generated applier module)."""
    if sha(base_text) != base_sha or base_sha != BASE_SHA:
        raise RuntimeError('E33 PRE SHA mismatch: ' + sha(base_text))
    post = base_text
    post = once(post,
        '    if _e28_on():     # E28 SCHED: the A -> B -> C scheduler (Experiment 28); unset = the rev 6 scheduler below\n',
        '    if _e33_on():     # E33: opt-in attempt-chain scheduler; OFF goes to exact E29 code\n'
        '        return _e33_solve_all(tasks, order, out_dir=out_dir, deadline=deadline, base_url=base_url, model_id=model_id,\n'
        '                              save_request_logs=save_request_logs, on_branch_done=on_branch_done, workers=workers,\n'
        '                              b1_view=b1_view, min_admit_sec=min_admit_sec, capacity_probe=capacity_probe,\n'
        '                              agent_cls=agent_cls, analyzer_timeout=analyzer_timeout, join_grace_sec=join_grace_sec,\n'
        '                              kv_admit_limit=kv_admit_limit, kv_poll_sec=kv_poll_sec, kv_stale_sec=kv_stale_sec,\n'
        '                              weak_commit=weak_commit)\n'
        '    if _e28_on():     # E28 SCHED: the A -> B -> C scheduler (Experiment 28); unset = the rev 6 scheduler below\n',
        'dispatch')
    post = once(post,
        '    if _e28_on():\n        select = select_attempts_e28      # E28 SCHED: the A / B / C answer slots (same output format)\n',
        '    if _e33_on():\n        select = select_attempts_e33      # E33: attempt-chain answer slots\n'
        '    elif _e28_on():\n        select = select_attempts_e28      # E28 SCHED: the A / B / C answer slots (same output format)\n',
        'submission')
    post = once(post,
        '            select_attempts_e28(task, records.get(tid) or [], _slots_out=rows)\n',
        '            (select_attempts_e33 if _e33_on() else select_attempts_e28)(task, records.get(tid) or [], _slots_out=rows)\n',
        'slot report')
    post = post + TAIL_SRC
    compile(post, 'arc2_duck.py', 'exec')
    patch = ''.join(difflib.unified_diff(base_text.splitlines(keepends=True), post.splitlines(keepends=True),
                                         fromfile='a/arc2_duck.py', tofile='b/arc2_duck.py', n=3))
    module = (APPLIER_TEMPLATE.replace('__PRE__', repr(base_sha)).replace('__POST__', repr(sha(post)))
              .replace('__MARKER__', repr(MARKER)).replace('__PATCH__', repr(patch)))
    compile(module, 'e33_sched_patch.py', 'exec')
    return post, patch, module


if __name__ == '__main__':
    d = Path(__file__).resolve().parent
    b = (d / 'BASE__arc2_duck_E29_post.py').read_bytes().decode('utf-8')
    post, patch, module = make_sched(b, sha(b))
    for name, value in [('E33__arc2_duck_post.py', post), ('e33_sched.diff', patch), ('e33_sched_patch.py', module)]:
        (d / name).write_text(value, encoding='utf-8', newline='\n')
    print('pre', sha(b), 'post', sha(post), 'patch', sha(patch), 'module', sha(module))
