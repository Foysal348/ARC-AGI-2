# E33 independent audit bundle ? 2026-11-02

Audit the released notebooks against DESIGN_E33_ATTEMPT_CHAIN_2026-11-02.md. Report concrete defects, severity, file/function references, and reproduction steps. Distinguish notebook defects from test harness limitations. Do not assume a successful Kaggle execution status means all tests passed: inspect JSON verdict.ALL_OK.

## Contents
- notebooks/: exact released production and 150-minute smoke notebooks.
- payload/: exact staged E33 runtime files and CPU-only helper sources.
- Build/: build/finalization scripts, source generators and tests. e33_nbx.py is generated notebook glue.
- CPU_kits/: generated CPU notebooks with private Kaggle metadata; GPU disabled.
- CPU_results/: downloaded reports/logs from successful units v3, units-nb v3 and chain v6 runs.
- MANIFEST_SHA256.json: byte-level manifest of every other entry.

## Current status and scope
Production notebook SHA256: 0429b589d45d9fdf780141e08a7e843201474fee04283237cbe9567c952fa85c
Smoke notebook SHA256: 2f04605eb1264bf0b37a50583b44e6b350891a44f25e68847648ad0ebedb184c
units v3: ALL_OK. units-nb v3: ALL_OK. chain v6: ALL_OK, 9/9 tests.
The real environment kit v2 was RUNNING at the last recorded status; its final outcome is NOT certified by this bundle. No GPU smoke or production execution has been performed by this agent.

## Important review points
1. Answer order must explicitly be e28: first train pass, best Duck/Poetiq train match, Direct, fallbacks, input. Both notebooks set E33_CHAIN[a1_order] after check_chain.
2. Confirm all five E33D_FILES hashes against payload files. Smoke and production differ only in the profile line.
3. Preserve the selected ZIP base's fail-closed MTP relaunch checks, including validation exceptions.
4. Review per-attempt sequential routing, attempt-1 priority, B2 waiting priority, reservations, attempt-2 seeds, multi-test mapping and trace persistence.
5. Smoke is 150 minutes with a 95-minute record-only Poetiq C?D / Direct probe, changed from the initial design's ~70-minute smoke. D admission and actual thinking length are time-dependent; CPU tests do not certify GPU throughput or 60k thinking completion.
6. Several E29-specific tests are intentionally incompatible with E33; inspect the explicit expected-failure map and E33 replacement coverage. Kit adapters retarget QSA lookup and smoke assertions without skipping them.
7. Chain fixture programs explicitly convert NumPy scalars to native int for E18 sandbox JSON serialization. Real solver/sandbox contracts were not changed.

## Reproducibility limitations / known remaining concerns
Build scripts refer to sibling experiments and absolute D:/ARC AGI 2 paths. This ZIP is an audit bundle, not a self-contained engine/model distribution. E18/E29 sources, Merlin, model weights and competition data are external prerequisites.
finalize_e33.py reproduces runtime files and notebooks from GPT/E33_CHAIN_SMOKE_AND_PRODUCTION_NOTEBOOKS.original.zip in the original workspace. Its original base notebooks are included under base/. Build facts/readable export were synchronized afterwards for CPU kits; review regeneration consistency. The older build_e33.py is not the release entrypoint and can overwrite final release settings if invoked directly.
The separate merged e33_sched_tests_all.py previously had two failing assertions (idle force/backfill ordering and distinct fallback answer expectations); it was not certified as passing. Do not confuse the passing core scheduler suite with this merged suite.

## Suggested checks
- Parse all notebook code cells and decompressed embedded sources without executing GPU setup.
- Recompute payload pins, compare production/smoke and verify MTP failure paths with stubs.
- Inspect included CPU JSON verdicts and negative-control results.
- In the complete workspace: python -B Build/e33_nbx_tests.py; python -B Build/e33_sched_tests.py; python -B Build/e33_poetiq_tests.py.
- Full Linux sandbox/environment validation belongs on Kaggle CPU. GPU execution requires a separate user go.

No Kaggle credentials are included. Private kernel IDs are metadata, not credentials.

## Real-kit follow-up
Real kit v2 completed: 78/82 checks passed. Four failures traced to stale DFlash donor pins, missing expected e28 answer-order environment, and NumPy scalar-returning fixture programs. CPU harness corrected; real kit v3 submitted and last observed RUNNING. No notebook/runtime payload changed for these harness corrections. Final v3 success is not yet certified.
