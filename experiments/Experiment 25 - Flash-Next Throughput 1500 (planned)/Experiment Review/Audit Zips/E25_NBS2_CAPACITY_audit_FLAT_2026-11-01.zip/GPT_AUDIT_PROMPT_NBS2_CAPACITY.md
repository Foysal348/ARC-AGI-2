# GPT audit prompt: E25 NB-S2 "capacity" GPU notebook (DFlash2 base), 2026-11-01

You are auditing a Kaggle GPU measurement notebook before its first GPU commit. Read every file in this flat zip. `MANIFEST_SHA256.json` holds the sha256 of each file. Report only real defects: a crash path, a wrong measurement, a gate that could stop an arm without a real failure, a cross-arm skip, or a launch argv that is not what the arm claims. For each defect give the file, the line, the evidence and a minimal fix.

## What the notebook is
- **Hardware and model:** Kaggle 4 x L4 (sm_89, PCIe, no P2P); Qwen3.8-Flash-Next klee100 3bpw-MTP on Merlin v3.0.0 (vLLM 0.32 fork, ad42e37); TP2 x PP2 + EP, partition 25 / 23, FP8 QSA KV with static scales.
- **Base arm B:** NBDF-K100's D3s, exactly:
  - DFlash2 K3 with BF16 drafter KV and FLASH_ATTN;
  - `DFLASH_DRAFT_SW_BLOCK=1024` and the dflash_seam apply / verify / revert;
  - the drafter Model gate (pinned shas);
  - Q-defer (nb4_ppack);
  - no DRAFT_HEAD / I8;
  - seqs 24, pin 7,933,526,016, the D pin ladder (DFLASH_DRAFT_EMBED_HOST=1 at the same pin first, then 0.25-GiB rungs).
- **Arms:** one change each vs B, in budget priority B > IDX > S28 > LP > S32 > SPC.
  - **IDX:** `--attention-config {"indexer_kv_dtype":"fp8"}`. This is the JSON form. The dotted `--attention-config.indexer_kv_dtype` is equivalent for vLLM, but the notebook's `--help` flag gate checks literal flag strings and would refuse it.
  - **S28 / S32:** `--max-num-seqs` 28 / 32, with captures 4 .. 112 / 128 (multiples of 1 + K). The windows run at 28 / 32 where residency allows: 8k, 20k and 40k are capped by the boot's resident bound; 90k@8 and 116k@6 stay as the mandatory bands.
  - **LP:** `--max-num-batched-tokens 2048 --long-prefill-token-threshold 1024 --long-prefill-token-threshold-adaptive`.
  - **SPC:** `--enable-mamba-shared-prefix-checkpoint`.
  - **Dropped:** K4 (MTP-only) and PP4 (the seam's aux relay is PP2-specific) as N/A_DFLASH (user decision); DYN (D4 / D3 dynamic K) moved to NB-S1 (coordinator). The DYN helpers stay in nbs2_lib, unused by the arm plan.
- **Windows (every arm except where S28 / S32 raise the level):** 8k@16 x 2, 20k@24, 40k@16, 90k@8, 116k@6.
- **B's A/A:** the greedy oracle twice (prefix-cache reset between), B's own concurrency ladder, teacher-forced logprobs fresh vs repeat at 2k / 8k / 40k, and 8k@16 twice.
- **Levers' correctness:** greedy token ids judged relative to B's A/A (`k100_rel`); the teacher-forced envelope gate vs B's A/A (+0.05 mean |dlogp|, -0.03 rank-1); TF_REQUIRED (no WIN without TF PASS); the long oracle at 90k and 116k.
- **NB-S2 records, all record-only:**
  - the KV ledger per window: KV usage high-water, preemptions, recompute tokens, waiting by reason, a block estimate; reclaimable blocks are NOT_READABLE (Merlin has no metric for them);
  - K_eff per window;
  - the sibling probe (the SPC junction hit; B is the control);
  - the prefill-stall probe (LP's metric: p95 inter-token gap of 8 decoding streams while 2 cold 40k prompts prefill; B is the control);
  - the pool and the residents.

## How it is built (please verify this claim)
`build_e25_nbs2.py` runs the NBDF builder (Exp 27 `build_e27_nbdf.py`, k100 variant) in-process twice, with `--test-out` set to a scratch folder:
- first closed, which must give the NBDF-K100 closed sha 456c47e6;
- then gated with NBDF-K100's real-kit report, which must equal the proven gated NBDF-K100 notebook **c5c43770** byte for byte (asserted).

Its cells are then edited by exact-once text replacements. See `nbs2_body_vs_nbdf_k100.diff` for every body change.
- CELL 0 = E18 R2 cell 1 verbatim (asserted).
- The CELL 7 body and `nbs2_lib.py` live in the NEW payload dataset `foysalemonshanto/q27-e25-nbs2-payload`, sha-pinned in the stub, which keeps the notebook < 400 kB (343,922 B). Everything else is NBDF-K100's.

## Gate rule (user rule; check that nothing violates it)
- **Only real failures stop an arm:**
  - a crash / launch failure / OOM after the pin ladder;
  - garbage, request errors, short output;
  - zero acceptance, NaN;
  - a real fallback:
    - wrong spec method / K / drafter (SPEC_MISMATCH);
    - an EAGER drafter;
    - IDX's indexer K cache not fp8 (IDX_NOT_ENGAGED);
  - missing init (nb4_ppack init lines, the seam's draft_load_check);
  - the klee100 boot gates (method map, static scales);
  - TF outside B's A/A envelope.
- **A failure stops only its own arm. There are no cross-arm skips:**
  - B not usable is recorded and the levers run;
  - a tree check failure skips only that arm.
- **Global setup failures boot no arm:** merge, #60490, k100_setup, the sha gate, the seam apply, the drafter gate. These are not arm-to-arm dependencies.
- **Recorded only:** labels, memory, prefix, parity, ledger, probes.
- **B's own ladder:** a concurrency contamination on B is its A/A and is recorded as BASE_LADDER_NONDET_RECORDED. It is never a stop.
- **The embedded KV gate is NBDF-K100's, and it passed** (per_k_success D3s True). NB-S2 adds no closed gate. If you find any gate that stays closed at run time, it is by design only if it is that NBDF-K100 gate; anything else is a defect.

## Budget
- **Hard stop:** 175 min (150 GPU-min of arms + setup / boot); the deadman fires at 180 min. The planned walk runs B, IDX and S28; LP, S32 and SPC are SKIPPED_BUDGET.
- **One-flag rebuild:** `python build_e25_nbs2.py --budget-min 300` runs all 6 arms (walk: 215 min -> + LP, 255 -> + S32, 300 -> + SPC).
- **Per-arm est_min:** B 50, IDX 38, S28 40, LP 41, S32 40, SPC 42. These are estimates: prefix test only on B / SPC, no profiles, no reruns.

## Specific questions
1. **S28 / S32:** does a larger `--max-num-seqs` at a fixed `--kv-cache-memory-bytes` change the pool? The kit records max concurrency at 21 / 24 / 28 / 32. Is the window level capping (band_level with the arm's seqs) correct for the MIXED 1024 / 4096 block path?
2. **IDX:** the kit simulates the pool with the compressed_key_cache spec at fp8 (B_idxfp8). Is the dtype / page halving right for the QSA indexer on klee100? Is our `idx_readback` (the worker's kv_cache_specs example "compressed_key_cache" with a float8 dtype) a correct engagement test?
3. **LP:** does chunk 2048 with the SW-1024 drafter and QSA prefill workspace risk an OOM at 7,933,526,016? (The pin ladder applies.) Is the stall probe (20 ms polling of the SSE token counts) a sound p95 decode-stall metric?
4. **SPC:** with DFlash2 (use_eagle includes dflash; no flagged eagle group -> all groups flagged), engine block 1024 and prefix-match-unit 64, does the shared-prefix checkpoint activate? Is the sibling probe (P = 6,900 tokens, three siblings; C's hit above the 6,144 block boundary = SPC_JUNCTION_HIT) a correct read-back?
5. **Real kit:** confirm it executes the notebook's own pre-launch functions in nbs2_main's order (the step-coverage table is in the kit's report, NBS2_STEPS), and that the argparser one-change check (serve parser + EngineArgs, diff vs B) has the right expected field sets.
6. Check any place where `is_q` (now `arm["key"] == "B"`) and `is_d` (every arm is a D arm) both being True changes NBDF-K100 behaviour beyond the marked edits.
