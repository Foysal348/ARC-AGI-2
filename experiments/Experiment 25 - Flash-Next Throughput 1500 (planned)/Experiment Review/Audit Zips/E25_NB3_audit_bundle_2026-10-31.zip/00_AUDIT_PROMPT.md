# Audit request: E25 NB3 "Kernel bench" (Qwen3.8-Flash-Next, Kaggle 4×L4, Merlin = vLLM 0.32.0 fork)

You are a senior CUDA / inference-engine reviewer. Read every file fully. Report findings ranked HIGH / MED / LOW, each
with file + line, the concrete failure scenario on the real Kaggle GPU run, and the fix. Finish with GO / NO-GO for a GPU
run (the run itself needs the user's separate approval).

## What NB3 is
A GPU notebook with **no model server**: it installs Merlin offline, merges the Flash-Next checkpoint from Kaggle Models,
verifies sha256, and runs three micro-benchmarks in subprocesses with timeouts, then writes tables, a ranked list of
patch candidates for NB4 and `lever_scorecard.json`:
- **D5 Marlin MoE** with real layer-0 experts (INT4 g128, 512 experts top-10, EP rank 0 = 256 local experts): token
  counts T from RC2's real micro-batch shapes; routing modes uniform / Zipf / per-request / extreme-hot (16 experts);
  correctness vs an fp32 dequantised reference; `MERLIN_MARLIN_MOE_CFG` sweep; **PP2 split-vs-combined** (two half
  micro-batches vs one combined call, same routing ids and weights; equivalence gate = bitwise or ≤ 1-2 bf16 ulps);
  DRAM bytes via `ncu` if present, else DERIVED; replay of real router ids from NB1 if that file is attached.
- **D7 world-2 all-reduce**: NCCL (P2P off, protocol/algo unset — forced LL128 deliberately removed) vs P5 host-staged
  all-reduce (built from embedded sources), pairs (0,1) and (2,3) concurrently, numeric checks.
- **D4 sm_89 GEMM plans + draft heads**: Flash-Next TP2 shapes on cuBLAS vs the SM121 plan entry vs skinny GEMM, an
  (8,9) plan entry patched in, draft head bf16/int8/int4.

## Context files
- `docs/PLAN_1500.md` (v3.6; §1.1 throughput model, §3 levers, §4.1 selection rule), `docs/NB_BUILD_SPEC_2026-10-31.md`,
  `docs/06_GPT_REPORT_3_VERIFICATION_AND_ROOFLINE.md`, `docs/A7_kernels_comms_graphs.md`.
- `rc2_context/E13_RC2_GPU_v1_2026-10-31.md` (the real 4×L4 run NB3 calibrates against) and `rc2_context/build_e13_rc2.py`
  (the Kaggle-proven code NB3 reuses via cut()/once()).
- `build/` the builder, bench scripts, unit tests, `nb3_export/` (embedded files as patched), `nb3_code_export.py`
  (all notebook cells in one file). `tests/nb3_unit_tests_144_PASS.txt` = local results. `notebook/` = the built notebook.

## Questions
1. Will each bench actually run on L4 sm_89 inside the Merlin venv without a VllmConfig (imports, op registration,
   workspace allocation inside CUDA-graph capture, EP expert maps)? Name every call that can fail and how it degrades.
2. Is the MoE correctness reference right for compressed-tensors pack-quantized INT4 g128 (N-first layout, scales,
   transpose)? Is the split-vs-combined equivalence gate sound?
3. Are timing methods valid (CUDA events/graphs, rotated cold weight copies vs L2 48 MB, warm-up, sync)?
4. Is the D7 comparison fair (sizes = hidden 2560 × T × 2 B, concurrency of both pairs, numeric check), and is the P5
   world-2 build/ABI handled safely?
5. Are the scorecard projections honest (MICROBENCH_PROJECTED labels, RC2 fit 24.18 + 0.1759·D(4r) ms, no microbench gain
   counted as an engine gain)?
6. Fail-closed behaviour: sha gate, GPU-empty checks, Xid abort, timeouts, budget 75 min, hard stop, fallback submission.
7. Anything that would waste the GPU session or produce misleading numbers.
