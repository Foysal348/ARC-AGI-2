# Audit request: E25 NB5 "FN-Duck" (Qwen3.8-Flash-Next ARC-AGI-2 solver on Kaggle 4×L4, Merlin = vLLM 0.32.0 fork)

You are a senior reviewer of LLM agent harnesses and inference serving. Read every file fully. Verify every claim against
the code before reporting it. Report findings ranked HIGH / MED / LOW with file + line, the concrete failure scenario on the
real Kaggle run (12-h limit, offline, hidden-test rerun), and the fix. Finish with GO / NO-GO for (a) a SMOKE/EVAL30 GPU run
and (b) EVAL120 / production (both need the user's separate approval).

## What NB5 is (six profile notebooks, identical code; only the default profile differs)
The LB-proven Duck config B harness (E15B/E21 cells, reused verbatim and asserted) ported onto the Merlin Flash-Next server
(the Kaggle-proven RC2 boot path). Thinking ≥ 60k up to 120k (no ARC-AGI-3 caps), max-model-len 131,072, xhigh; dual-mode
(Kaggle rerun = all hidden tasks; commit = eval subset + scoring; full-schema submission.json); 11:45 solve end / 11:50 watchdog.
- **Commit-turn variant C:** the server's own thinking-on render via `/tokenize`, trailing `<think>\n` replaced by a closed
  think block, sent as token ids to `/v1/completions`, parsed with Duck's own markup recovery (CPU test in
  `docs/commit_turn_prefix_test_2026-10-31.json`: 98.3 % prefix reuse vs 0 % for `enable_thinking=False`). Variant A
  switchable; SMOKE splits A/C; switch to A on ≥ 4 commit turns without a tool call, C-only corruption, or ≥ 2 fewer
  exact matches (with ≥ 3 commit attempts per variant).
- **Admission:** projected reservation per attempt (ceil(P/4096) + F blocks; F = 6 from the RC2 log; Merlin retains
  finished sessions so the raw KV gauge is telemetry only); `live` optional; `future` placeholder; preemption gate
  (+1 F margin after any SMOKE preemption).
- **Budget guard on every request:** `min(cap, 131072 − prompt(/tokenize) − 2048)`; below the 60k floor → BUDGET_LIMITED.
- **SMOKE:** functional checks, then task checks with early exit, bounded by a 40-min gate; long SMOKE only in SMOKEDIAG.
- **Reports:** steady decode / mixed / solver window / whole notebook tok/s, productive duty factor, prefix-hit and
  recompute tokens, tool-call rate, Merlin-vs-Duck admission interaction, solve-vs-token bands, GPU-only gates.
- Profiles: EVAL120 (default), EVAL30, EVAL30MTP (second boot without speculation), QUALITY (FP8+K3 at 4 streams vs
  BF16+K3 at 2 streams on 11 fixed tasks; refused unless NB0's FP8 gate = PASS), SMOKEDIAG, BUDGET (60k/80k/100k/112k).
- Values from NB0 (FP8 verdict), NB1 (pool, F, pin, extra args) and NB2 (K, draft head) must be baked into CELL 1 before
  any push (Kaggle commits cannot set env vars). Known access issue: the Duck payload dataset `esfersami50/q27-e15b-payload`
  is not yet readable by the other two accounts.

## Files
`notebook/` (6 profiles; default sha 6aff0155…, 328,321 B), `build/` (builder, `nb5_lib.py`, unit tests, fake server, e2e,
all cells in one file), `tests/` (unit 91/91 and the five e2e modes commit / rerun / mtp / notok / floor), `rc2_context/`,
`merlin/`, `docs/` (PLAN v3.6, spec, PENDING_BATCH_FIXES, the commit-turn CPU test and its script).

## Questions
1. Variant C correctness on the real server: token-id completion semantics, reasoning/tool parser behaviour, prefix-cache
   reuse, MTP state; is the A/C switch rule sound for a 3-task SMOKE?
2. Admission and capacity: is the projected reservation preemption-safe given Merlin's retention and cost-aware admission
   (`VLLM_E2_SCHED_MISS_DEFER_S`); are the interaction counters meaningful; can admission deadlock or starve?
3. Budget guard and the 60k floor: any path that silently shortens thinking, exceeds 131,072, or loses a final answer?
4. Dual-mode and the 12-h limit: hidden-rerun path, submission schema, deadline handling, watchdogs, fallback.
5. Can any failure produce a misleading score, tok/s or PASS?
6. Anything else that would waste GPU hours or LB submissions.
