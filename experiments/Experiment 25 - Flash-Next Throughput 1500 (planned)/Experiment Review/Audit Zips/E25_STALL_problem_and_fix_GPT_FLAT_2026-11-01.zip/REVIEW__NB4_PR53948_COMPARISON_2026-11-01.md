# NB4 Q-defer / Q-pack vs upstream vLLM #53948 / #47686 / #53810 (2026-11-01)

Scope: read-only comparison of `Experiment Notebooks/Build/nb4_ppack.py` (Q-pack `NB4_PPACK=1`, Q-defer `NB4_PPDEFER=1`)
against the upstream work on the same problem, on Merlin v3.0.0 (vLLM 0.32 fork, ad42e37, source
`_scratch/e23/p2/merlin-src/vllm/`). No repo writes other than this file; no Kaggle; no git writes.

## 0. Verdict

**(b): keep our patches, with 3 specific fixes (2 for hangs, 1 hardening) and 1 read-back improvement (section 5).**
Do not port #53948 (option c). For PP2 its receive timing is the same as ours. Porting it costs more and carries more
risk (9 of 28 source hunks are rejected on ad42e37, and Merlin-specific semantics need checking). Worse, its activation
gate turns it **off** whenever `--profiler-config` is set, and every NB4S arm sets it. Ported as-is, it would be a
silent no-op in the QD arm, and it has no counters that could show that.

## 1. Sources and bases

| Item | State | Base | Matches Merlin? |
|---|---|---|---|
| PR #53948 "[MRV2][PP] Defer sampled-result receives" (chengchengpei) | open, not merged; mergify reports conflicts; author paused 2026-10-05 | `main` 5f30fc70 (head 81039f06, 9 commits, 11 files, +700/-64 incl. tests) | **Yes, closely.** Merlin `pp_utils.py` = the PR base + Merlin's `deferred_state` / `attach_deferred_state` / `drop_deferred_states` (diff = only those 3 blocks + `replace` import). `model_runner.py` / `gpu_worker.py` differ a lot (Merlin PLE, RecoverSSM defer-tail, guard telemetry) |
| PR #47686 "[Spec][V2] Pack PP sampled/counts/draft broadcast into one NCCL op per step" (eastwood-c) | closed unmerged 2026-07-27 (was draft) | `main` 21b396ab, stacked on #46994 (MTP+PP support) | **No.** Its base `pp_utils.py` has no draft relay (2 broadcasts, no padding). The PR itself adds `broadcast_draft` / `PendingRecv.draft_tokens`. Merlin has upstream's later, differently named relay (`broadcast_drafts`, `get_prev_sampled_outputs(draft_tokens_to_update)`). 137 differing lines vs Merlin. It cannot be applied; our Q-pack is in effect the port |
| Issue #53810 "Post sampled-result receives closer to T+PP consumption" | open | analysis at d591d1d5 / ac7509e2 | n/a (design + measurements) |

Dry run (scratch copy of the 8 Merlin files, `git apply --reject` of #53948's non-test diff):

| File | Hunks | Clean | Rejected |
|---|---|---|---|
| engine/core.py | 1 | 1 | 0 |
| gpu/model_runner.py | 5 | 3 | 2 (#4 post-model launch: Merlin's `ExecuteModelState(...)` has extra PLE fields; #5 `shutdown`: Merlin body differs) |
| gpu/model_states/interface.py | 1 | 0 | 1 |
| gpu/model_states/mamba_hybrid.py | 1 | 1 | 0 (textually; semantics: see 4c) |
| gpu/pp_utils.py | 13 | 11 | 2 (#2 `PendingRecv` field: Merlin's `deferred_state` sits in the context; #9 return dict: Merlin returns `deferred_state=`) |
| gpu/warmup.py | 2 | 2 | 0 |
| gpu_worker.py | 4 | 0 | 4 (all: compile_or_warm_up_model, flush helper, execute_model, shutdown) |
| worker_base.py | 1 | 1 | 0 |
| **Total** | **28** | **19** | **9** |

## 2. Q-defer vs #53948, point by point

#53948 mechanism: the receiver saves its metadata at `receive()` (event None, `launched=False`). With
`recv_launch_delay = pp_size - 1`, `get_prev_sampled_outputs` → `_advance_receive_queue` picks
`queue[-delay]` as `pending_post_model_receive`. `launch_post_model_receive()` posts it at the end of
`execute_model` (after the forward, before the IntermediateTensors return) or in the zero-token branches. Consume
still happens at T+pp_size, and `_launch_receive` is called there as a fallback (idempotent).

| Point | Ours (Q-defer) | #53948 | Same for PP2? |
|---|---|---|---|
| When posted | `receive(T)` parks; `flush_deferred_receive("exec")` right after `kv_connector.finish_forward()` of step T+1 (= after graph(T+1) launch, before `ExecuteModelState`) | delay pp-1 = 1 step; posted after step T+1's model kernels (after `ExecuteModelState`, before return) | **Identical.** No GPU op lies between the two placements. For PP4 they would differ (ours T+1, theirs T+3); we only run PP2 |
| Stream placement | `broadcast_stream.wait_stream(main)` at post time, buffers allocated at post time | same wait at launch; buffers allocated at `receive()` on the broadcast stream | equivalent |
| FIFO / collective order | at most one parked slot. `receive()` first flushes an older parked slot (`"recv"`). `flush` walks the queue oldest-first. Consume posts a still-parked slot before waiting or early-returning | a missed `pending` is launched before the next one is selected. Consume launches before filtering. `flush_pending_collectives` walks pending + queue | equivalent. Our T5 test checks it |
| Sender | unchanged (immediate) | immediate; but the **draft payload is snapshotted on the main stream** (self-found race, commit c2c41a4c98) | **differs** → fix F3 |
| Slot / generation | mask + `gen_at_receive_np` + rows taken at `receive()` (unchanged); `replace()` keeps `deferred_state`, `nb4_*` | same snapshot at `receive()`. `launched` flag instead of `event is None` (needed only for the CPU stream placeholder) | equivalent on CUDA |
| Invalidated rows | unchanged from Merlin: `idx_mapping=-1`. Merlin's `RecoverSSM.commit_step` already does `torch.where(idx_mapping >= 0, num_sampled, 0)` (recoverssm.py:135) and `_scatter_num_accepted_kernel` skips <0 | adds `num_sampled=where(idx>=0, …, 0)` in `get_prev_sampled_outputs` | not needed in Merlin (already covered). Also not deferral-specific: the consume time does not change |
| Warmup / capture | deferral active from `PPHandler.__init__`, so also during `warmup_kernels` (scheduler-realistic steps). The cleanup step (0 tokens) hits the `"empty"` flush before the final `torch.accelerator.synchronize()`. Dummy runs excluded; `is_current_stream_capturing()` guard | delay 0 (immediate) until `compile_or_warm_up_model` finishes, and only if `enable_jit_warmup` and no runtime-sync features. Also warms PP post-update + Mamba/RecoverSSM kernels per decode shape | differs but **safe for PP2**: each warmup step is run by both ranks in their own process, and stage 0 posts receive(T) at its own forward(T+1), with no wait on stage 1. Every parked slot is flushed before the warmup synchronize and before capture. The extra warmups target first-use JIT syncs on a rank whose posted send has no posted receiver. In PP2 that is only stage 1, whose sends stage 0 posts on its own (see section 3) |
| Empty steps | `"empty"` flush in the `total_num_scheduled_tokens == 0` branch (after `update_pp_decode_requests`) | same branch + `batch_desc.num_tokens == 0` (all-DP-zero) + a worker-level flush in `gpu_worker.execute_model` | the DP-zero branch is unreachable at DP=1 (only dummy runs). Not needed |
| Chunked prefill | unchanged: mask None ⇒ no slot on either side; partial mask ⇒ rows excluded at consume | unchanged (+#58542 upstream: also skips final chunks that finish; already in Merlin's `compute_need_sampled_mask`) | same |
| Aborts | unchanged generation check; a parked slot of a freed request is still posted (sender sent it) | same ("post before filtering") | same |
| Shutdown drain | **none** | `flush_pending_collectives()` in `GPUModelRunner.shutdown`, `Worker.shutdown`, and before `synchronize_device` in `_finish_pause` (pause/sleep) | **missing** → fix F1 |
| Sync RPCs (profiler, pause, sleep, collective_rpc) | **no flush** | profiler / MM-stats configured ⇒ deferral never enabled; pause/sleep flush. A reviewer asked about collective_rpc deadlocks; still unanswered | **missing** → fix F2 (see section 3) |
| Activation / counters | env read at init; `NB4_PPQ init` per worker; `stats` at counts 1, 10, 100, … (park, exec / empty / recv / consume flushes) | automatic, no env, **no counters** (#53810 asked for launch / flush / fallback / unready counters; not in the PR) | ours is better. Read-back can be tightened (R1) |

### Cases #53948 handles that ours does not

1. Shutdown and pause/sleep drain (F1; pause/sleep are not used by NB4S).
2. Device syncs at RPC boundaries while a receive is parked (profiler gate). This matters for NB4S `/stop_profile` (F2).
3. Sender-side snapshot of the persistent draft table on the main stream (F3).
4. DP-zero empty branch and worker-level zero-token flush (not reachable here).
5. JIT/sync-free activation gate + PP post-update / Mamba warmups (needed for PP4 middle ranks and for upstream's
   "any device" generality; not needed for PP2 per the analysis above).
6. Padded `(2, ceil4(n))` counts buffer, so a Triton first-use compile cannot start while a collective is outstanding.
   Not needed: our unpadded `[2, n]` matches baseline Merlin, and a stage-0 compile cannot deadlock (its posted receives
   are always matched by sends already posted).
7. CPU-stream placeholder (`launched` flag). Not needed on CUDA.

### Behavioural differences that could hang, give wrong data or be a silent no-op

- **Hang H1 (shutdown).** `GPUModelRunner.shutdown` (model_runner.py:2891-2894) calls `torch.accelerator.synchronize()`.
  With the last step's receive parked on stage 0, stage 1's send can still be outstanding. If NCCL does not finish the
  send eagerly (see section 3), stage 1 hangs on graceful shutdown. Bounded in NB4S: lab `kill()` sends SIGTERM, waits
  40 s, then SIGKILLs the group, so the cost is up to about 40 s per arm plus noisy shutdown logs.
- **Hang H2 (sync RPC while parked).** Between steps there is always one parked receive (receive(N), matched by the
  already-posted send(N)). A device sync on stage 1 inside an RPC that blocks the engine core can therefore never
  finish, because stage 0 posts receive(N) only at forward(N+1), and step N+1 is not dispatched while the RPC is pending.
  This is exactly why #53948 disables deferral when a profiler is configured. NB4S risk: section 3.
- **Wrong data W1 (sender draft race).** Merlin's `broadcast_drafts(self.req_states.draft_tokens, …)`
  (model_runner.py:2818) passes the persistent table and gathers `draft_tokens[idx_mapping]` **on the broadcast
  stream** (pp_utils.py:209-217). If the sender's broadcast stream backs up behind a send waiting for a deferred
  receiver, a later `propose()` can overwrite those rows before the gather runs. Stage 0 would then embed the wrong
  draft ids: a silent wrong-output bug. In PP2 the margin is about one full micro-batch cycle: rows of micro-batch A are
  rewritten at propose(T+2), while send(T) completes when stage 0 runs receive(T) right after graph(T+1). So it is
  unlikely, but it is real, and #53948's author found it by review. Our Q-pack sender has the same pattern
  (`_nb4_send_packed`, nb4_ppack.py:288-298). Fix F3.
- **Silent no-op (only if #53948 were ported).** `runtime_device_syncs = profiler_config.profiler is not None` keeps the
  receive immediate for the whole server life. All NB4S arms pass `--profiler-config` (build_e25_nb4s.py:238), so a
  ported #53948 would never defer, and it has no counters to reveal that. Ours has no such gate and reports itself.
- No difference in collective order, shapes, dtypes, mask symmetry or consume cadence was found. Our tests T3-T5 cover
  those. Missing test coverage: shutdown drain, sync-at-RPC, draft-table overwrite while the sender stream is backed up.

## 3. Profiler interaction (NB4S profiled window in every arm)

How NB4S profiles (e23_lab `profiled_load` / `profile`): settled 8k@8 decode → `POST /start_profile
{"delay_iterations":20,"max_iterations":40}` → sleep 6 s → `POST /stop_profile` → 20 s → trace parse; the streams keep
decoding the whole time (max_new 8192). Merlin `WorkerProfiler` (profiler/wrapper.py): `start()` with a delay only sets
flags. `step()` is called in `annotate_profile`, at the top of every worker `execute_model` after the PP irecv post
(gpu_worker.py:1652). It starts the torch profiler at iteration 20 and **auto-stops inside the step** after 40 profiled
iterations, through `stop()`. `torch.profiler` stop synchronizes the device and exports the trace on the host. A later
`/stop_profile` on an inactive profiler is a no-op ("not active").

- **Auto-stop inside a step: safe with ours.** Both ranks reach the stop at the same execute_model(N), since every
  worker sees the same message order. Stage 1's sync waits for send(N-1) (and its hidden-state irecv(N)). Stage 0 syncs:
  its posted receives ≤ N-2 are matched. It then exports and runs forward(N), and the `"exec"` flush posts receive(N-1).
  Stage 1's sync then finishes. There is no deadlock; stage 1 just waits for stage 0's export. That is after the
  window, and the parser already drops the first and last replays.
- **`/stop_profile` RPC while still active: possible deadlock with ours (H2).** This happens only if 20 + 40 iterations
  take longer than 6 s (about 150 ms per iteration or more). NB1 R2 measured a tick of about 43-50 ms per step
  (36 steady ticks in the window), so the auto-stop normally comes at about 3 s and the RPC is a no-op. The margin is
  about 2x, not a guarantee: profiler overhead, a slow first iteration or a stall could cross it. If it is crossed, stage
  1 syncs inside the RPC with send(N) outstanding, and stage 0 never gets step N+1. The HTTP call times out at 900 s and
  the rest of the arm (40k@8) is lost.
- **Eager-send caveat.** NCCL broadcast between 2 ranks writes into the peer's connection buffer under credit flow
  control. A sub-2 KiB message (ours: 64·n B packed, or 32n / 8n / 24n B) usually fits in a free slot, so the root
  kernel can finish **before** the receiver posts. If that holds on the 4xL4 SHM/no-P2P path, H1 and H2 never hang.
  It depends on protocol, version and channel, and nobody (us or upstream) has validated it. #53948 states that the
  head send "can" wait. Treat H1/H2 as real until a GPU run shows otherwise; F1/F2 make it moot.
- **Upstream's gate does not apply to our goal.** Upstream turns deferral off under any profiler config. We need it on in
  the profiled window, because the stall is measured there. So we keep deferral on and add the flush at the sync points
  (F2) instead of copying the gate.

## 4. Q-pack vs #47686

| Point | Ours (Q-pack) | #47686 |
|---|---|---|
| Wire format | one int64 tensor of n·(2K+3), **segment-major**: `[sampled n·(K+1) | num_sampled n | num_rejected n | drafts n·K]` | one int64 `[n, 2·msl+1]` = `[n, 2K+3]`, **row-major** per request: `[sampled | ns | nr | draft]` |
| Element count | same: n·(2K+3) on both sides; n = sender `sampled_token_ids.shape[0]` vs receiver `input_batch.num_reqs` (same equality the original relies on); sender checks the shapes | same |
| Padding of short sampled rows | zero pad (`F.pad`, = Merlin original) | -1 fill (`torch.full(-1)`) |
| Sender timing | sampled + counts written at the original #1/#2 point (in `broadcast()`), sent once in `broadcast_drafts()` after `propose()` | same (stage in `broadcast()`, send in `broadcast_draft()`) |
| Sender stream | pack copies **on the broadcast stream** (after `wait_stream(main)`), as in Merlin's original sends; the draft gather on the broadcast stream (W1) | pack built **on the main stream**, drafts filled on the main stream, then one send on the broadcast stream (no persistent-table race) |
| Receiver | ONE broadcast + `record_event`, zero-copy views; int64→int32 count cast on the **main** stream after `wait_event` | one broadcast, then `.contiguous()` + two `.to(int32)` **on the broadcast stream** before `record_event` (3 extra side-stream kernels) |
| Pairing guard | `RuntimeError` on stale stash / drafts without stash / need-mask mismatch | `assert`s |
| No-spec (K=0) | refuses (`RuntimeError`) | sends the 3-column row from `broadcast()` |
| Alignment | sampled at 0, counts at 32n B, drafts at 48n B (always 16 B-aligned for K=3) | strided column views (made contiguous by copies) |

Ours fits the false-dependency goal better: nothing is queued on the side stream behind the receive. The only gap is
the sender-side stream choice (F3). No hang or desync path was found in the wire format or the unpacking.

### 4c. If #53948 were ported anyway (effort / risk)

- Effort: about 300 changed source LOC across 8 files. 9 of 28 hunks need manual merges (table above). On top of that:
  an env gate for the A/B (#53948 has none, so arm B on the same tree would also defer), an override of the profiler
  gate, counters, new pre/post shas, the strict applier, and test rework (our T3-T5 simulator is built on our API).
  Estimate: 1 working day + a CPU kit.
- Risk: medium. (i) `warmup_postprocess_state` calls Merlin's `RecoverSSM.commit_step`, which consumes `self._step` /
  `_step_is_deferred` (recoverssm.py:114-125): it interacts with Merlin's defer-tail commits, which upstream does not
  have. (ii) `drop_deferred_states` / `attach_deferred_state` use `dataclasses.replace`, so the queue object can stop
  being the object held in `pending_post_model_receive`. A replace after selection and before launch would post one
  receive twice (collective desync, which hangs). That is safe in today's call order, but fragile. (iii) The engine-core
  `_finish_pause` and the worker `execute_model` hunks touch code NB4S does not exercise.
- Gain over ours for PP2: none in timing (same post point). It only adds the drain/sync handling, which F1/F2 add more
  cheaply.

## 5. Recommended fixes (all in `nb4_ppack.py`; shas `PP_POST` / `MR_POST` at :56/:58 must be regenerated)

- **F1 — shutdown drain (hang H1).** Add a hunk to `MR_PATCH` (nb4_ppack.py:409-437) at Merlin model_runner.py:2891-2894:
  before `torch.accelerator.synchronize()` in `GPUModelRunner.shutdown`, add
  `if self.pp_handler is not None: self.pp_handler.flush_deferred_receive("shutdown")`.
  Add `"flush_shutdown"` to `_NB4_STAT_KEYS` (:89-99) and log a final `stats` line there, which R1 needs.
- **F2 — flush at sync RPCs (hang H2, NB4S `/stop_profile`).** Add a third `PATCHES` entry (nb4_ppack.py:439, plus pre /
  post sha + marker) for `vllm/v1/worker/gpu_worker.py`. At the top of `Worker.profile()` (Merlin gpu_worker.py:1690,
  before the `is_start` branch), and at the top of `Worker.shutdown()`, add:
  `ph = getattr(getattr(self, "model_runner", None), "pp_handler", None); if ph is not None: ph.flush_deferred_receive("rpc")`.
  An RPC reaches every worker at the same point in its message order, so this is a PP-group-uniform boundary
  (#53948's `_finish_pause` reasoning). Stage 0 posts receive(N) before stage 1 synchronizes. The flush must sit
  **inside** the same RPC as the sync: a separate flush RPC would leave a window in which a new step parks again.
  Cheaper NB4S-only alternative: skip `/stop_profile` when the auto-stop has fired. But the lab function is shared, and
  F2 also covers manual stops.
- **F3 — sender draft snapshot on the main stream (wrong data W1).**
  (a) Q-pack, `_nb4_send_packed` (nb4_ppack.py:288-298): compute `send = draft_tokens[input_batch.idx_mapping]` **before**
  `with torch.cuda.stream(self.broadcast_stream)`, then `send.record_stream(self.broadcast_stream)`, and drop the
  `input_batch.idx_mapping.record_stream` (:298).
  (b) Q-defer (original sender): extend the `broadcast_drafts` hunk (nb4_ppack.py:194-204) with a last-rank branch,
  active when either env is "1": the same main-stream gather, then the original broadcast. That needs a sender flag set
  in `__init__` (:142-149), e.g. `self.nb4_any = "1" in _nb4_env`, because `nb4_ppdefer` is False on the last rank
  (:149). Keep env-off byte-identical (T4).
  Optional: move the `_nb4_stash_packed` pad/stack copies (:250-269) to the main stream as well (#47686 style).
  `sampled_token_ids` / `num_sampled` / `num_rejected` look like fresh per-step tensors (`record_stream` protects them),
  so this is lower priority.
- **R1 — read-back.** `readback_label` (nb4_ppack.py:648-676) labels ENGAGED once `defer_park` and `flush_exec` each
  appear once. Use the last `stats` line per non-last rank and also require
  `flush_exec >= 0.9 * defer_park` and `flush_recv + flush_consume <= 0.05 * defer_park` (the counts will not add up
  exactly because of empty-step flushes). Otherwise label `ENGAGED_FALLBACK`: deferral collapsed to post-at-consume,
  which is a different timing.
- Tests to add to `nb4_ppack_tests.py`: shutdown with a parked slot (F1); a sync-RPC with a parked slot, where the sim
  sender blocks until matched (F2); a sender whose broadcast stream lags while the main stream overwrites the draft
  table (F3).

## 6. What the upstream discussions report

- **#53948 / #53810 gains:**
  - H100 TP8/PP4, Kimi K3, no speculation, 4,000 requests at concurrency 710, 615 in / 130 out, same image: output
    2,431→3,368 tok/s (**+38.5 %**), mean TTFT -41.2 %, mean TPOT -25.7 %, 0 failures. An earlier comment: +39.9 % vs
    main (3,324 vs 2,376), P99 TPOT -41 %.
  - Issue #53810, PP4: delay-3 **+18 %** prefill-heavy, **+4-6 %** decode-heavy. Post-model placement adds **+4.8 %**
    (same configuration, not a same-allocation A/B). With PP partition retuning: +5-11 %.
  - Controlled run on #49274 + #54962: 648.8 → 751.3 (delay 3, +15.8 %) → 803.0 tok/s/node (post-model, +6.9 %;
    cumulative +23.8 %).
  - Author: "10 %-39 % depending on the workload"; deployed internally.
  - RDNA4 PP3 (6x R9700, ROCm, `GPU_MAX_HW_QUEUES=1`): without deferral, step time grows linearly with batch size
    (27/51/77 ms for 1/2/3). With it: 28/33/56/66 ms at 1/4/8/16, aggregate 36→244 tok/s. This is the closest analogue
    to our "false dependency through a hardware queue" stall.
- **#53948 regressions and caveats:**
  - Post-model placement with the old partition: +2.4 % on long generation (inside the 3 % noise band) and **-1.5 %** on
    very long generation, with KV at 100 % and preemptions. The issue says it is "not a universal win" and that stage
    balance should be retuned once the interference is gone.
  - Validated only at about 5.7 KiB payloads, with no draft tokens. Speculative payloads have "no hardware perf
    validation".
  - No PP2 GPU validation is listed (an acceptance criterion is still open).
- **#53948 bugs found in review:**
  - pause/sleep synchronize while receives are still unposted, which could hang (fixed: flush before
    `synchronize_device`);
  - the Mamba fused-align warmup kernel was missed (fixed);
  - the description said opt-in env / `is_cuda_alike`, but the code was automatic, so it was gated to CUDA only;
  - the padded counts views had shape `(8,)` with uninitialized padding at n=5 (fixed: slice to n);
  - self-found: the draft-table race on the backed-up sender stream (fixed, commit c2c41a4c98);
  - added the runtime-sync and profiler gate, and invalidated-row `num_sampled` zeroing.
  - Open items: maintainer `yewentao256` asked to "check runtime collective_rpc, I am not sure if there might be a dead
    lock" (unanswered). `njhill` says it needs substantial simplification (< 300-400 LOC), and notes that merged #58542
    removes the problem in the prefill-only case. A history note in #53810: per-rank delays broke FIFO order, and
    delaying the source too deadlocked. The safe baseline is one common receiver delay, an immediate source and a finite
    drain. Ours follows that.
- **#47686:**
  - GLM-5.2-FP8 TP4/PP2, MTP k=3, 8xH200: about **31 % of stage-0 GPU kernel time** spent spinning in
    `Broadcast_RING_LL` (about 3 kernels per step). With the patch, nsys shows exactly 1.0 broadcast per eligible step
    (17,712 = 8 ranks x 2,214 steps), down from about 2.9.
  - TPOT p50 -9.6 % at concurrency 1; +5.6 % output tok/s and -5.9 % TPOT p50 at concurrency 256; "neutral-to-positive,
    no cell regressed beyond noise"; 6,744 requests with 0 errors, greedy probes identical.
  - `njhill`: wants a "robust/non-negligible performance benefit to warrant the additional complexity". The author kept
    it as a draft; it was closed without review comments.
  - #53810 calls packing (fewer kernels) and deferral (shorter kernel lifetime) **complementary**. That supports
    keeping the `Q-pack+defer` combination available (`server_env` already allows it).

## 7. URLs used

- https://github.com/vllm-project/vllm/pull/53948.diff ; https://api.github.com/repos/vllm-project/vllm/pulls/53948 (+ /comments, /reviews, /commits; issues/53948/comments pages 1-2)
- https://github.com/vllm-project/vllm/pull/47686.diff ; https://api.github.com/repos/vllm-project/vllm/pulls/47686 (+ /comments, /reviews, /commits; issues/47686/comments)
- https://api.github.com/repos/vllm-project/vllm/issues/53810 (+ /comments)
- https://api.github.com/repos/vllm-project/vllm/pulls/58542
- https://raw.githubusercontent.com/vllm-project/vllm/5f30fc7031cae49bf51073fc953d419b08f8887c/vllm/v1/worker/gpu/{pp_utils,model_runner,warmup}.py, …/gpu_worker.py, …/engine/core.py (PR #53948 base)
- https://raw.githubusercontent.com/vllm-project/vllm/21b396abe14bd35d821c346d10961a97de4f2d56/vllm/v1/worker/gpu/pp_utils.py (PR #47686 base)

Local evidence read: nb4_ppack.py (whole), nb4_ppack_tests.py (header/structure), Merlin pp_utils.py (whole),
model_runner.py (:420-432, :1385-1398, :1963-2003, :2177-2275, :2470-2600, :2600-2700, :2790-2830, :2891-2895),
warmup.py (:355-471), gpu_worker.py (:1376-1384, :1490-1510, :1652, :1690-1750, execute_model), profiler/wrapper.py
(:77-200, :380-430), recoverssm.py (:112-150), mamba_hybrid.py (scatter kernel), build_e25_nb4s.py / nb4s_lib.py
(profile flow), e23_lab.py (`profile`, `profiled_load`, `kill`), NB1 R2 results (tick 43-50 ms).
