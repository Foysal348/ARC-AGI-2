# Verification request: the PP2 stage-0 stall, what is wrong, and whether our fix is right (2026-11-01)

All files are flat; read every file before answering. Prefixes:
- `PROBLEM__`: the measured evidence;
- `SRC__`: Merlin v3.0.0 sources, i.e. a vLLM 0.32 fork, named as path with `__`;
- `FIX_REV1__`: the notebook / patch as first built;
- `FIX_REV2__`: the current notebook and patch;
- `REVIEW__`: our upstream comparison.

## Setup
- **Hardware:** Kaggle 4× L4, sm_89, PCIe, P2P off, custom all-reduce off, NCCL over host SHM.
- **Engine:** Merlin v3.0.0, TP2 × PP2 + EP, V2 model runner, async scheduling, MTP K3 (probabilistic), FP8 QSA KV, FULL_AND_PIECEWISE cudagraphs.
- **Model:** Qwen3.8-Flash-Next W4A16.

## 1. What went wrong (measured; `PROBLEM__` files)
**The stall**
- NB1 R2 boot B1 traces, all 4 ranks, one window. Tick 49.66 ms; stage 0 compute 23.54 ms plus an **in-graph stall of 21.75 ms**.
- In 39 / 39 stage-0 decode FULL graphs (1,036 nodes), the graph stops at node #173 (a TP AllReduce).
- It resumes about 7 µs after the OTHER micro-batch's PP sampled-token `Broadcast Int x8` (stream 31, `pp_broadcast` communicator) ends.

**Why we call it a false dependency**
- Step k consumes step k−2's receive, and that receive was complete about 10 ms before step k's graph started.
- `PPHandler.receive` (`SRC__…pp_utils.py`) posts three receives per step on `broadcast_stream` before the next graph launch. Receive #1 spins about 27-29 ms waiting for stage 1.

**Ideal tick:** 34.6 ms; about 40-42 ms when counting stage 1's own wait. That is +19-25 % realistic tok/s.

**Our analysis:** `nb4_timeline.py` + tests, `nb4_b1_v2.json`, and the three internal research notes.

## 2. The planned fix: notebook NB4S (`FIX_REV2__Q27-XHIGH-E25_NB4S_STALL.ipynb`, sha e5dc5967, 95-min hard stop)
**The arms**
- Each arm is base B (NB1 R2 B3 config) plus exactly one change:
  - **S:** `CUDA_DEVICE_MAX_CONNECTIONS=32`;
  - **QP:** "Q-pack" (`NB4_PPACK=1`): one packed int64 [n, 2K+3] broadcast instead of three;
  - **QD:** "Q-defer" (`NB4_PPDEFER=1`): `PPHandler.receive` is parked and posted after the next graph launch.
- **Per arm:** env read-back on all 4 workers, oracle vs B, 8k@8 ×2, a profiled window run through `nb4_timeline`, and 40k@8.
- **Verdicts:** STALL_FIXED_WIN / STALL_FIXED_NO_SPEED / STALL_MOVED / STALL_REDUCED / NO_EFFECT / CORRECTNESS_FAIL / NOT_ENGAGED / ENGAGED_FALLBACK / NOT_INTEGRATED / SKIPPED_BUDGET.

## 3. What was wrong in our first fix (rev 1) and how rev 2 fixes it (`REVIEW__NB4_PR53948_COMPARISON_2026-11-01.md`, `FIX_REV2__rev1_to_rev2_source.diff`)
We compared our patch with vLLM PR #53948 (deferred PP receives, open) and PR #47686 (packed broadcast, closed).

**H1: shutdown hang.**
- **Problem:** `GPUModelRunner.shutdown` synchronizes the device while the last deferred receive is still parked.
- **F1:** flush the parked receive before the sync, and log the final stats.

**H2: hang at a syncing RPC.**
- **Problem:** a `/stop_profile` RPC can arrive while a receive is parked. Stage 1's send can never finish, so the HTTP call times out at 900 s and the arm is lost.
- **F2:** a third patched file, `gpu_worker.py`. `Worker.profile()` and `Worker.shutdown()` flush first, inside the same RPC.

**W1: wrong drafts.**
- **Problem:** `broadcast_drafts` gathers from the persistent `req_states.draft_tokens` on the broadcast stream. If that stream lags, a later `propose()` can overwrite the rows, and stage 0 receives the wrong drafts.
- **F3:** gather on the main stream before entering the broadcast stream, with `record_stream` on the gathered tensor. This applies both to Q-pack and to Q-defer's sender.

**R1: a misleading verdict.**
- **Problem:** ENGAGED was reported after a single park + flush.
- **Fix:** ENGAGED now needs `flush_exec ≥ 0.9·defer_park` and `flush_recv + flush_consume ≤ 0.05·defer_park`; otherwise the label is ENGAGED_FALLBACK, which is never a winner.
- Stats lines are now also logged every 1000 counts.

**Why we did not port #53948:**
- it is disabled whenever `--profiler-config` is set, and every NB4S arm sets it;
- it has no env gate;
- 9 of its 28 hunks are rejected on Merlin;
- it has Merlin-specific conflicts (RecoverSSM warmup, `replace()` slot copies);
- for PP2 it gives no timing benefit.

**Tests (local units):** ppack 243 / 243, nb4s 194 / 194, timeline 20, P5 19. With the env vars off, behaviour is byte-identical (test T4).

## Questions; answer each with evidence (source line, CUDA / NCCL docs, PR)
1. Is the diagnosis right? Is the stall really a false dependency on the other micro-batch's broadcast? Give the exact mechanism: hardware work-queue / connection aliasing, NCCL cross-communicator ordering, or something else. Did we misread the traces anywhere?
2. Will each arm (S, QP, QD) actually remove that dependency? Which one is most likely to win, and what tick do you expect?
3. Are F1, F2 and F3 correct and complete? Check them against `FIX_REV2__nb4_ppack.py` and the Merlin sources. Are any hang paths left: NCCL op ordering across ranks, env mismatch between ranks, warmup, chunked prefill, aborts, empty steps, profiler start / stop, revert after QD?
4. Is the R1 verdict logic sound? Can any verdict mislabel the result?
5. Report ONLY blockers for the GPU run: wrong raw data, a mid-run crash or hang, wasted GPU time, or a misleading verdict. For each, give file:function / line, a concrete scenario and a minimal fix. Start with one line: GO / NO-GO.
