# PLAN 1500: Flash-Next on 4×L4 (living document)

**Revision:** v3.6, 2026-10-31.

**Rebuilt after a full read of every input:**
- the 7 past-work mining reports (`Experiment Review/Past work mining/A1…A7`);
- GPT research report 1 and its verification (`Experiment Review/GPT research inputs/01_…`);
- our own source checks;
- the user's decisions and standing rules.

**Still waiting for:** GPT reports 2 and 3, and the E13 RC2 GPU result.

**Source tags:**

| Tag | Source |
|---|---|
| [A1] | vLLM engine |
| [A2] | SGLang + speculative decoding |
| [A3] | Flash-Next history + Merlin knobs |
| [A4] | run average / workload |
| [A5] | transcript |
| [A6] | platform / boot |
| [A7] | kernels / comms / graphs |
| [G1v] | GPT report 1, verified (`01_VERIFICATION_by_agent.md`) |
| [OWN] | our own check |
| [RC2] | the E13 RC2 GPU run |

**Labels:** (est.) = an estimate, not a measurement. UNVERIFIED = not yet confirmed.

---

## 0. Rules for every Flash-Next speed notebook (from the user and our history)

**Process** [A5, memory]:
- Start with a short speed stage of about 10-15 min.
- Audit with 2 agents, then a Kaggle CPU kit.
- Push only after the user's go.
- Use few arms per notebook, never 20-25.
- Correctness and KV come before any full run.
- Speed is measured in short runs, not 12 h runs.

**Workload:**
- Every slot must be busy; idle slots are waste.
- Mix easy and hard tasks when admitting, so the KV peak stays flat.
- Admission gate at about 0.95 KV, not 0.85.
- The run stops by about 11:50 of the 12 h (budget ~11.5 h).

**Model and accuracy:**
- Reasoning effort xhigh, forced: Merlin's default is medium.
- Thinking ≥ 60k, up to 120k (max-model-len 131072).
- Never import the ARC-AGI-3 caps.
- Save the full thinking traces.
- Always report both the steady peak and the run average.
- Never substitute configured capacity for observed running streams.
- Every speed winner needs a paired ARC accuracy run (same tasks, MTP on vs off) before adoption. The SGLang LB gap (26.9-29.2 vs vLLM 31.5-34.6) is unexplained, and RedHat INT4 lost about 5 task-norm points in Duck. [A1, A2]

**Engine gates kept from RC2:**
- fail-fast after the short checks;
- non-finite logprob gate;
- real running == level;
- boot gate < 150 MiB;
- graceful kill and /dev/shm cleanup;
- every request saved.

---

## 1. Target

**Definition (user, 2026-10-31):** 1500 tok/s = the **whole-run average** (generated tokens ÷ the full runtime).

| Regime | Run ÷ steady | Examples [A4] |
|---|---|---|
| Queue never empties, good prefix reuse | 0.89-0.99 | E10 ORDER2 0.96, R5 0.99, R3K 0.89, E21 0.89-0.95 |
| Small subset with a tail | 0.72-0.86 | EVAL12 runs, E15 EVAL20; Darren 710/980 = 0.72 |
| Controller or cache failure | 0.39-0.74 | E12 EVAL30 thrash 0.39, G4B false step-down 0.64, E18 drain 0.74 |

- So the steady rate needs about **1,580-1,690** with 88-93 % prefix hits, or about 1,900 at vLLM-0.32-level reuse (55-68 %). [A4]
- **Supply vs demand:** 62.1M tokens (1500 × 41,400 s) against 240 × 2 × 120k ≈ 57.6M. A tail will appear unless it is filled with useful work. [A4]
- **Every boot minute ≈ 90k tokens** at 1500 tok/s, about 1.5 attempts at the 60k floor. [A3, A6]

**Arithmetic.** Steady tok/s = C · a / t_cycle.
- C is the real running streams and a the accepted tokens per stream per verify cycle.
- Under PP2, t_cycle = 2 ticks: a request advances once every 2 ticks, and each stage carries about C/2 requests per tick. [A7, OWN]

**Acceptance at xhigh is low; plan with a ≈ 2.3-2.8:**
- Merlin Flash-Next: 2.29 tokens per MTP step at xhigh prose, 2.66 at medium [A3].
- 27B real Poetiq reasoning: 2.69 (per position 0.73 / 0.54 / 0.42), against 3.57 on synthetic grid prompts [A1].
- ARC-AGI-3 Flash-Next track: ≈ 2.8 [A3].

**The MoE step floor (est.)** [A2, A3, A7]:
- Distinct experts touched per layer by T tokens: D(T) = 512·(1 − (1 − 10/512)^T). That is D(16) = 139, D(32) = 240, D(64) = 367.
- One expert is ≈ 2.53 MB (INT4 g128).
- The weight-streaming ceiling on an L4 is ≈ 250 GB/s.
- MoE bytes per verify token: 1.21 GB at T = 1, 0.91 at T = 32, 0.70 at T = 64, 0.45 at T = 128. **More tokens per step means fewer bytes per token.**
- PP2 itself costs about +31 % expert reads at 16 streams, because two half-batches touch more distinct experts than one batch.

**Per-tick cost estimate, TP2×PP2, 8 streams (micro-batch ≈ 4 requests, T = 16)** [A7]:

| Part | ms/tick |
|---|---|
| MoE | 4.7-21 |
| Dense GEMMs incl. replicated HC weights | 6.6-12 |
| Vocab heads (BF16 draft heads; int8 6.4, int4 4.5) | 10.2 |
| TP2 all-reduce | 1.5-3.8 |
| Logits gather | 2-3 |
| PP hand-off | 1-3 |
| QSA | 2-5 |
| GDN + RecoverSSM | 1-3 |
| PLE | < 0.5 |
| Guard reader | 0.3 |

- Stage 1 ≈ 30-62 ms; stage 0 ≈ 17-45 ms, idling 5-15 ms per tick, because stage 1 carries the heads.
- Result: **≈ 150-400 tok/s at 8 streams, ≈ 320-670 at 16**. This agrees with the synthesis projection of 200-320.
- **1500 needs the per-tick cost cut 3-5×, or many more tokens per tick.**

**Ceilings (est.)** [A3]:

| Streams | Serial PP2 | Overlapped PP2 |
|---|---|---|
| 8-16 | 255-490 | — |
| 16-32 | — | 525-1,000 |

- Source shows that PP2 + async interleaves two micro-batches: `max_concurrent_batches` = pp + 1 (`vllm/config/vllm.py:607-617`), `scheduler.py:792-796` [A7].
- The 3090 "serial stages" trace was single-stream. **Whether the overlap holds under MTP at our concurrency is the RC2 question.**

**Combinations that reach 1500 steady at a ≈ 2.5:**

| Streams | t_cycle |
|---|---|
| 20 | 33 ms |
| 24 | 40 ms |
| 32 | 53 ms |

- All need **16-32 resident streams**. Today's pool holds about 5 at 70k.
- So the plan has two thrusts: (1) more resident streams, (2) a cheaper tick at high T.

**Reference points:**

| Source | Hardware | Number | Caveat |
|---|---|---|---|
| Merlin [A3] | 4×3090, P2P on | 1 stream 168-187; 8 agents 638 | 638 = short 512-token follow-ups, thinking off |
| Merlin [A3] | same | six 127k sessions 574.5 (10.78 ms/token per agent), 0 preemptions | |
| Merlin [A3] | same | no-MTP single stream ~82; no-P2P decode −20-25 % | |
| jon-nielsen [G1v] | 4×3090, no P2P, TP2×PP2+EP+MTP4 (our closest analog) | 4 streams ~267, single 105.6 | |
| Franzen [A3] | 1× RTX PRO 6000 | 588-617 job-wallclock with 10 streams, P90 836.6, 93.4 % reuse | |
| chenxin [A2, A5] | 3×4090-48GB Flash-Next NVFP4 | 124 / 387 / 618 / 635 at 1 / 4 / 8 / 16: flattens after 8 | |
| [A5] | 4× RTX PRO 2000 Blackwell (~288 GB/s, the bandwidth analog) | TP4 NVFP4 MTP3: 386.9 at c8, still rising | |
| club-3090 [A5] | 4×3090 | c16 1,811 ÷ bandwidth ratio 3.1 ≈ 584 | "bandwidth parity: more speed needs fewer bytes read" |
| Darren [G1v] | 4×L4, model unnamed | 980 peak, 710 average over 6 h, ~1,100 pure decode, ~250 under heavy prefill | |

### 1.1 Throughput model v3.5 (RC2-calibrated; two external reviews + GPT decision 2026-10-31)

**Targets.** Main scenario a = **2.72** (RC2 natural xhigh long row; the 90-s windows' 3.0-3.25 are early-reasoning
values), steady **1,700** (whole-run 1,500 at ~88 % productive time; 1,579 / 1,667 / 1,875 / 2,083 at 95 / 90 / 80 / 72 %).
Sensitivity: a 2.3-3.2. Report four rates separately: tick, request cycle (= 2 ticks under PP2), completed-micro-batch
rate, wall-clock (steady decode / mixed agent / whole run).

**Step model (FITTED, not measured).** tick_ms = 24.18 + 0.1759·D(4r), r = C/2 requests per micro-batch,
D(T) = 512(1 − (1 − 10/512)^T). Leave-one-out on the 7 RC2 multi-stream windows (C 2-8, 40k-116k): mean abs holdout error
1.5 %, max 4.0 % (linear form 25.6 + 5.79·r: 2.3 % / 5.6 %). **Validated only inside C 2-8; extrapolation to C 16-48 is
UNVERIFIED.** The 24 ms term is FITTED (may contain stage idle and hand-off, not only compute); 173 GB/s is back-calculated
from the slope, not a bandwidth measurement (NB3 measures it).

**Required tick for steady 1,700 at a 2.72:** (C/2)·a / 1700 → C 8: 6.4 ms, C 16: 12.8 ms, C 24: 19.2 ms, C 32: 25.6 ms.

**Three-layer roofline (est.; 250 GB/s per card; uniform routing; serial-additive costs):**

| C | MoE-only PP2 INT4 | + 24 ms floor, PP2 INT4, a 2.72 | + floor, PP2 2-bit (hypothetical), a 2.72 | required KV blocks at 68k / 90k (F = 6) | resident-feasible at 149 / ~220 blocks (68k) |
|---|---|---|---|---|---|
| 8 | 725 | 266 | 336 | 184 / 224 | no / yes |
| 16 | 838 | 410 | 564 | 368 / 448 | no / no — STRUCTURAL_TARGET |
| 24 | 962 | 526 | 759 | 552 / 672 | STRUCTURAL_TARGET |
| 32 | 1,095 | 635 | 940 | 736 / 896 | STRUCTURAL_TARGET |
| 48 | 1,386 | 850 | 1,295 | 1,104 / 1,344 | STRUCTURAL_TARGET |

(F = 6 per request is **ENGINE-DERIVED**: 149/(32+6)·131,072 = 513,940 and 78/38·131,072 = 269,043 match both logged
pools. Which physical pages the 6 blocks are, and how many K changes can reclaim, is still for NB1. The ~215-220-block pool
from the +1.0-1.1 GiB pin is an ESTIMATE until NB1 boots it.)

**Hypotheses to measure, not forecasts:**
- PP2 split-batch expert reads: 2·D(2C) vs D(4C) per cycle, × 1.31 at C 16 under uniform routing; L2 (48 MB) cannot hold
  a layer's touched experts (~300 MB per card), so DRAM re-reads are likely — NB3 split-vs-combined bench + NB1 DRAM bytes.
- Stage imbalance: 1 stream 44.1 ms vs 2 streams 30.3 ms suggests a heavy stage ≈ 30 ms and ~14-16 ms idle on the light
  one (≈ 27 % tick cut if balanced). The 1-vs-2-stream difference does not isolate stage execution: NB1 per-stage CUDA
  timelines first; D2 (int8 head) and D6 (repartition) move up in research priority, **no 25/23 change before that**.
- Low-bit experts (C6) could free ~7-8 GiB per card for KV, but this does not automatically become ~500 blocks: SM89
  kernels, quantized residency, allocator overhead and ARC accuracy first. Research-only branch; NB1-NB3 stay on INT4.
- What a steady 1,700 needs in this model (all simultaneously): fixed floor ~6-12 ms, a ≥ 3.5 (or a deeper drafter),
  more resident streams, fewer weight bytes, and/or a single-batch layout. No single lever reaches it.

**Gates added in v3.6:**
- **Productive duty factor ≥ 88.2 %** (1,500 ÷ 1,700) is an independent gate: steady 1,700 alone does not give a 1,500
  whole-run average.
- **Projected admission does not guarantee zero preemptions** (prefix-cache retention, block allocation and engine-side
  admission interact): every run keeps a preemption counter and gates on it.
- **K7 / a = 5 rows need a deeper speculative method**, not just K 3 → 7: K3's theoretical maximum is 4 tokens per
  iteration, and deeper drafts add draft compute, graph shapes and recurrent-state work that must be measured.
- Block size: 2,479,838,700 B / 150 allocated blocks = **15.77 MiB per card** (149 usable); 7.5 GiB ≈ 487 blocks (est.).

**RC2 vs Merlin's 3090 reference:** consistent after bandwidth scaling (≈ 184 vs 160-190); this does **not** rule out
SM89-specific implementation bottlenecks (P2P, dispatch, scheduling and cache behaviour differ).

---

## 2. Known facts (verified or measured)

### 2.1 Engine and profile
- **Merlin v3.0.0 `fn-quad-24g-sm89`:**
  - TP2×PP2+EP, partition 25/23 (capacity-optimal: 26/22 = 857,585 tokens, 24/24 = 739,100);
  - FP8 E4M3 QSA KV + scales; MTP fixed at K = 3 (probabilistic draft sampling);
  - seqs 8 ("the only concurrency the engine is gated at"); captures 1..32;
  - prefix caching, `--mamba-cache-mode align`, `--prefix-match-unit 64`, `--use-replayssm`, block 4096, chunk 1024;
  - WARM 0 (persisted Triton autotune is sm_86 only); P2P off (`NCCL_P2P_DISABLE=1`, custom AR off);
  - the vision tower is loaded (`--limit-mm-per-prompt image 42`); reasoning default medium; generation config T 1.0.
  - [OWN, A3, G1v]
- **`build()` strips every `MERLIN_*` env.** Changing K or seqs needs trailing `--speculative-config` / `--compilation-config`; extra args come last and win. [A3]
- **Merlin 3.0.0 = vLLM 0.32.0 rebase.** It already contains #59533, #57097, #54513, #54517, #58114, #58957, #58489, #57105, #55557 and #54890. **Missing: #60490**, the QSA indexer prefill workspace (0.4-0.5 GiB/GPU, not reserved during profiling): first-long-prefill OOM risk. [G1v]
- **On the Kaggle image:** `build()` + `host_phase()` pass for BF16 and FP8; the checkpoint (115.3 GiB) matches byte for byte. [E13 CPU kit v1]
- **Model facts:** 125B with 6B active; 48 layers (36 GDN + 12 QSA); 512 experts top-10, intermediate 640; hidden 2560; vocab 248,320; GDN `mamba_ssm_dtype` fp32; hyper-connections hc 4. [A3, A7]

### 2.2 Capacity
- **FP8 pin** 2,479,838,700 B = 150 blocks (149 usable) ≈ 558k tokens. Per request ceil(L/4096) + 7 blocks, so 5 streams at 70k. BF16 ≈ 292k. [OWN]
- **The fixed +7 blocks per request** (≈ 115 MB/card each; GDN/MTP state slots, UNVERIFIED) take **56 of 149 blocks at 8 streams (38 %)**. [A3]
- **MTP costs:** 12.5 % of Merlin's pool on 3090 (1,057,314 → 924,993); 48 % in the todi stack (MTP2 526,909 vs 1,017,569 without speculation); 18-24 % on the 27B. [A1, A3]
- **TP4 duplicates the 2 KV heads.** 3090: TP4 pool 342,912 vs TP2×PP2 806,792 (−57 %); RC1 stock TP4 BF16 = 30,208. [A3]
- **DP 2×TP2 is ruled out** (≈ 33.7 GiB per card needed). **PP4 leaves almost no KV** (binding stage 19.06 GiB + overhead). [A3]
- **27B capacity levers:** `--language-model-only` +10.3 % KV; SSM fp16 +10 % KV (+11 % at 90k, aligned block 1600 → 832), no Duck accuracy loss, Merlin's 27B profile uses it. With fp16 SSM the fused GDN verify falls back to Triton; it was still net positive. [A1]
- `--language-model-only` replaces the Qwen4Exp vision tower with `StageMissingLayer` (`model.py:989-995`). [OWN]
- **Franzen's KV-preemption collapse:** 10 → 14 streams took 600-620 → ~280 tok/s and the score from 47.30 to 29.90 (topic 750885). **Never admit beyond residency.** [A5]

### 2.3 Graphs
- **Capture sizes count tokens = seqs × (1+K)**, uniform-decode graphs in multiples of 4 at K3 (`cudagraph_utils.py:268-347`, `compilation.py:1543-1571`). Captures to 32 cover 1/2/3/4/6/8 requests per forward. Under PP2 each micro-batch has about N/2 requests. [A1, A7]
- **Flash-Next backends declare UNIFORM_BATCH full graphs:** QSA, GDN, GDN-RecoverSSM. So the 27B FlashInfer downgrade (FULL → PIECEWISE under spec decode) should not apply. **But** on the 27B, Merlin's draft ran with `decode:NONE` and the RecoverSSM commit ran staged-eager ("0 captured"). Check all three for Flash-Next in the RC2 log. [A1, A7]
- **PIECEWISE breaks at every QSA layer**, because QSA is a split op. FULL graphs mattered little on the 27B at 16 streams (+3 %); PR 60532's author claims +36-47 % at batch 1. A community recipe claims FULL ≈ 2× PIECEWISE decode for Flash-Next. **Launch overhead is likely a bigger share for Flash-Next.** [A1, A5]
- **#57759 (4×L20, sm_89 PCIe):** one FULL capture failure under heavy host load; workaround PIECEWISE. [G1v]

### 2.4 Communication (all measured at world 4; none at world 2)
- **Plain NCCL over host shared memory (SHM) with P2P off is best:**
  - 343.9 µs per 983 KB all-reduce in a graph; 49.7 µs at 64 KB; 134 µs at 240 KB.
  - P2P is 5.5× slower; PCIe-IPC 0.39-0.68× in engines.
  - CTA 4/8/16/32 is slower; SHM memcpy is slower and hangs in capture; symm-mem and FlashInfer AR are unsupported on sm_89.
  - PCIe gen 3; NCCL SHM uses 2 channels.
  - [A1, A5, A7]
- **The host-staged all-reduce (E23 P5) wins at small messages:** 1.42× at 64 KB, 1.34× at 240 KB, bit-exact and graph-capturable; INT8 variant 1.8-2×. Flash-Next TP2 all-reduces are 80-160 KB (5,120 B per token, 2 per layer; no all-to-all with EP at dp = 1). [A7]
- **On PCIe/SHM:** `NCCL_PROTO=LL128` +6.2 %; no `expandable_segments` +13-37 % multi-stream; fused_moe aux-stream overlap −20 %. These are from the jon-nielsen 4×3090 no-P2P kit [G1v]. Also seen: `NCCL_CUMEM_ENABLE=0` (todi recipe) [A5]; `NCCL_NTHREADS=512` untested [A5].
- **P2P on helps prefill only** (todi: 1.9× prefill, decode barely changed). Merlin's P2P-on mode turns on exactly the paths we measured slower. **Keep P2P off.** [A3, A7]

### 2.5 Kernels on sm_89 [A7, G1v]
- **The low-latency skinny-GEMM plans** exist only for (10,3), (10,0), (9,0), (12,1). On L4 every dense decode GEMM runs cuBLAS:
  - QSA QKV/o;
  - the shared expert;
  - the router;
  - HC up;
  - the LM head.
- **An (8,9) plan table can be seeded from the SM121 (GB10, 273 GB/s) table**, which already lists the TP2 shapes. This is data only, but the CuTe DSL compile on sm_89 is UNVERIFIED. Dense GEMMs are 3.9 of 11 ms per stage on 3090.
- **The fused HC down+SiLU** needs sm_90. The fix is a code port (FMA variant without PDL). The HC weights are replicated, ≈ 27 MB per layer, read on both TP ranks.
- **QSA Triton tables** exist only for sm_90 and sm_120; an sm_89 table can be added as data only.
- **Top-k:** cooperative top-k needs sm_90, so persistent_topk runs. There is no valid kernel time yet.
- **GDN autotune** runs live with WARM = 0. 14-15 "JIT during inference" warnings appear per Merlin boot.
- **Marlin is the right decode kernel at M ≤ 16** (9-11 % faster than CUTLASS W8A8). **Marlin MoE on L4 has never been microbenchmarked.** It is the largest decode cost.

### 2.6 Workload facts [A4, A3]
- **Prefix caching on** raised the whole-run rate +14.6 % (E1 run 4 → 6). It is part of the LB jump 18.75 → 26.94.
- **Align-mode reuse on vLLM 0.32:** Poetiq 7 %; Duck 59.6-68.5 % vs 87.8-88 % on 0.19, which cost 21 % of generated tokens at equal streams.
  - Align mode costs 13-16 % even at zero hits (#60008) [A5].
  - On 0.32, an aborted request lost its cache even with free KV.
- **Merlin targets exactly this:**
  - replayssm, prefix-match-unit 64, Mamba checkpoint retention always on;
  - cost-aware admission `VLLM_E2_SCHED_MISS_DEFER_S` 120 s and coherent yields;
  - follow-up reuse 74.7 % at 8×131K and 82.1 % at 12×80K oversubscription on 3090.
  - This is UNVERIFIED on our Duck load.
- **Duck commit turn (corrected v3.1).** The current harness keeps thinking ON in the commit turn, so it has **no** cache miss.
  - The real problem: about 25 % of commit turns make no tool call (6/24), because the model spends the whole 4,096-token reserve thinking (E15 Notes/11 F2).
  - The tempting fix `enable_thinking: false` removes the reasoning-effort line from the **system block** (`chat_template.jinja:46-60`).
  - **CPU test** (`Experiment Notebooks/Build/commit_turn_prefix_test.py`, result `Experiment Results/commit_turn_prefix_test_2026-10-31.json`, Flash-Next tokenizer and template, a 12.4k-token 4-turn conversation):

    | Variant | Common prefix with the cache | Note |
    |---|---|---|
    | A: thinking on (current) | 12,248 tokens (98.3 %) | |
    | B: `enable_thinking=False` | **3 tokens** (0 %, header changed) | |
    | C: same render with `<think>\n\n</think>\n\n` closed by hand, sent as token ids | 12,248 (98.3 %, header identical) | |

  - **So C is a no-thinking commit that keeps the cache.** Whether C makes the model call the tool reliably, and with correct grids, is a GPU question (FN-Duck smoke).
  - The test also shows block granularity matters: reusable at block-4096 boundaries 65.7 % vs 98.3 % token-exact. Whether Merlin's `--prefix-match-unit 64` matches below the block size must be measured (W2).
- **Drains that abort and resubmit lose work:** D66 lost 14/15, E18 16/18. A deadline clamp instead gave 0.8-1.2 s overrun and 0 stragglers.
- **More streams at long context gave nothing on the 27B** (D66 16 slots 256 tok/s with 66 preemptions; L66 12 slots 254). Flash-Next must be measured.
- **Prefill blocks decode:**
  - 27B prefill ran at ~1,575 tok/s and took 19-27.5 % of the window, 58-66 % of it re-prefill.
  - A 1,796 tok/s prompt burst cut generation to 52 tok/s.
  - Two-term model: sustained = 1 / (1/decode + r·c), reproduced to within 1 %.
- **ARC-AGI-3 Flash-Next track (vLLM NVFP4, PRO 6000):** KV pin 5 GiB gave 3.2 resident streams at 32k, so 20/77 preemptions. Prefix caching off gave a prompt:generated ratio of 14:1. Result ≈ 245 tok/s on a 1.8 TB/s card.

### 2.7 Platform and boot [A6]
- **Models mount as NFS, datasets as gcsfuse.** This explains the user-observed "Models load ~15× faster"; the wheelhouse should be a Model too.
- **Read rates:** range-parallel (64 MiB, 16 workers) 543-870 MB/s; one reader 34-110 MB/s; file-parallel 159-576 MB/s. The 123.8 GB checkpoint takes 145 s at best, 275 s at the CPU-kit sha rate.
- **cgroup** 185.8 GB, counting page cache and /dev/shm. 124 GB of cache + 47.7 GiB of pinned PLE + workers sits at the limit; the second Flash-Next boot in RC1/NANPROBE was only ~20 % faster.
- **Install and compile times:**
  - Merlin extract 24.5 s + install 175 s (GPU VM);
  - FlashInfer JIT ≈ 150-166 s cold, reused within the session;
  - torch.compile 54 s, 0.75 s with the AOT cache;
  - warm 27B boot 135-162 s vs 384 s cold;
  - CUDA graph capture 2-12 s.
- **A cache carried across sessions has never worked:** E14's tar failed with an `IndexError`.
- **One Merlin Flash-Next cold boot:** ≈ 11-16 min (est.); a second boot in the same session ≈ 6-10 min; target with shipped caches ≈ 7-8 min.
- **Quota:** 4×L4 bills 2×. A fixed 30-min launch timeout means LB 0.

---

## 3. Levers (tiers; ranked within each tier)

### Tier C: capacity, from 5 to 16-32 resident streams (the binding constraint)

| # | Lever | Evidence | Setting / how | Stage |
|---|---|---|---|---|
| C1 | **Shrink the fixed +7 blocks per request** (state slots) | 38 % of the pool at 8 streams [A3]; MTP K and SSM dtype set it | K (D1), SSM dtype (C3), `MERLIN_SHARE_DRAFT_WORKSPACE` (MTP draft shares the target workspace) [A3]; measure F from the "Maximum concurrency" line | S1/S2 |
| C2 | **Admit by live blocks, not worst-case length**: a preemption-free projected-peak controller | Live context ≈ half the final length on growing thinking [A3]; the E7 projected-peak controller idea, never run [A4] | client controller, replayed on real metrics (never synthetic) | FN-Duck |
| C3 | **SSM state dtype bf16/fp16** | 27B +10 % KV, block 1600 → 832, no Duck loss [A1]; prefer bf16 if it keeps the fused GDN verify kernel [A2] | `--mamba-ssm-cache-dtype` (check that Merlin accepts it) | S1 |
| C4 | **Text-only** | 27B +10.3 % KV and −23 s warm-up [A1, A6] | `--language-model-only` | S1 |
| C5 | **KV pin** +0.25 … +1.5 GiB per card, while per-rank free VRAM allows | Merlin rule; boot-OOM retry; reserve #60490 headroom | `KV_BYTES` | S1 |
| C6 | **Fewer weight bytes**: smaller checkpoints (Minachist INT4/INT6, klee100 3bpw-MTP, Haberstroh int2, REAP/EXL3; Marlin runs only 4/8-bit) | ~47 GB main weights would give 2-3× KV [A5]; accuracy unknown (INT4 27B lost 5 points) | research branch | branch |
| C7 | ~~TP4+EP~~ (moved down) | TP4 loses 57 % of the pool [A3] | only if PP2 is fundamentally broken | S3 |

### Tier D: a cheaper tick at high T

| # | Lever | Evidence | Setting / how | Stage |
|---|---|---|---|---|
| D1 | **MTP K0/K1/K2/K3 per stream count on real xhigh ARC reasoning** | 3×4090 Flash-Next at 16 streams: K2 644 > K1 636 > K0 559 > K3 541 [A2]; todi n = 2 acceptance 70 % vs n = 3 53 % [A3]; EXL3 static table K3 ≤ 4 streams, K2 at 5-8, needs 17-32-row kernels [G1v]; FN cookbook: without MTP ~70 requests fit vs ~20 with [A2]. K changes capacity (C1) and captures | trailing `--speculative-config` restating `draft_sample_method` / `draft_lm_head_quant`; metric `vllm:spec_decode_num_accepted_tokens_per_pos_total` | S2 |
| D2 | **DRAFT_HEAD int8/int4** | −6.5-7.2 % ms/token at the same acceptance (3090) [A3]; vocab heads ~10 ms of the tick at BF16 (est.) [A7] | `DRAFT_HEAD` env; check that the head is selected | S2 |
| D3 | **Graph coverage**: FULL for target, draft and RecoverSSM commit; capture ≥ seqs × (1+K) in multiples of 4 | [A1, A7]; launch overhead likely larger for Flash-Next | `--compilation-config`; one eager-vs-graph A/B settles it [A1] | S2 |
| D4 | **sm_89 GEMM plans** (8,9) seeded from SM121 TP2 shapes; then the HC down+SiLU FMA port | Dense GEMMs 6.6-12 ms/tick (est.), the second-largest term [A7, G1v] | data patch in the Merlin tree; code port | S3 |
| D5 | **Marlin MoE on L4**: a microbenchmark with real experts at 1-2 tokens per expert, then `MERLIN_MARLIN_MOE_CFG` per-shape tuning (re-export after `build()`) | MoE is the largest term (4.7-29 ms/tick) [A7]; tuner exists, off by default [A3] | bench on one L4 (CPU-free arm) | S3 |
| D6 | **PP2 balance**: retune 25/23 so stage 0 stops idling; per-shard sampling (no full-vocab logits gather) | Stage 0 idles 5-15 ms/tick; gather 2-3 ms (est.) [A7]; 25/23 is the capacity optimum, so this is a trade [A3] | `VLLM_PP_LAYER_PARTITION`; source | S3 |
| D7 | **TP2 all-reduce:** NCCL world-2 benchmark, then P5 host-staged (INT8 behind a logprob gate), `NCCL_PROTO=LL128` | P5 1.34-1.42× at 64-240 KB (world 4) [A7]; LL128 +6.2 % [G1v] | E14 NCCL bench with world = 2; P5 `.so` | S3 |
| D8 | **Merlin runtime switches:** `VLLM_GDN_DECODE_FASTPATH`, `VLLM_GDN_SHARED_ALIGN_INDEX`, `VLLM_TARGET_SEQ_LENS_ASYNC`, `VLLM_E2_GUARD_MODE=off` (−0.3 ms/step), `use_local_argmax_reduction` + greedy draft (+10-20 % on 8×3090, 0 on 4×3090) | [A3] | env / spec config; each needs a bitwise or greedy check | S3 |
| D9 | **Backport vLLM #60490** (QSA indexer workspace profiled) | Missing in Merlin; 28 lines [G1v] | patch `qsa.py`, or keep headroom | S1 (risk) |
| D10 | **sm_89 QSA Triton table**; top-k timing; warm GDN Triton cache / fixed configs | QSA 2-5 ms, GDN 1-3 ms (est.) [A7] | data patch; cache | S3/B |
| D11 | MoE aux-stream and allocator settings | −20 % / +13-37 % in jon-nielsen's kit [G1v] | check what Merlin enables | S3 |
| D12 | Deeper speculation (K4+) | pulse K6: 3.75-3.89 tokens/step, noisy [G1v]; Merlin CMP K4 −24 % at 4 streams [A3] | — | later |
| D13 | BLOCK_SIZE 2048 | ≈ 1.5 % tail waste; 3,392 was 6-12 % slower prefill under RecoverSSM [A3] | `BLOCK_SIZE` | later |

### Tier W: workload and run average (what turns steady into the run average)

| # | Lever | Evidence | Where |
|---|---|---|---|
| W1 | **Workers = resident capacity, one KV gate at 0.95, no step-down logic, assert real running == workers** | E12 EVAL30 thrash 0.39×; Franzen collapse; G4B false step-down −13 % [A4, A5] | `solve_all_r6` (`Experiment 15 …/src/duck_b/arc2_duck.py:3220`); `e21_capacity` (`Experiment 21 …/e21_engine_new.py:202-235`) with Flash-Next's block 4096 and fixed blocks F |
| W2 | **Prefix reuse on every Duck turn**: log `prefix_hit_pct_whole_run`, `recomputed_prompt_tokens` and the reuse classes; target ≥ 88 % (ideally ≥ 93 %) | 0.32 align 59.6-68.5 % vs 88 % [A4]; Merlin retention / defer / yield untested [A3] | FN-Duck smoke |
| W3 | **No-thinking commit turn that keeps the cache**: render with thinking on, close `<think></think>` by hand, send as token ids; never `enable_thinking=False` (it drops the system reasoning line, so 0 % reuse) | CPU test: B 3 common tokens vs C 12,248 (98.3 %) [OWN]; targets the 25 % commit turns without a tool call (E15 Notes/11 F2) | Duck harness (completions with ids); GPU check: tool-call rate + grid correctness in the FN-Duck smoke |
| W4 | **Deadline-clamped `max_tokens`, `min_admit_sec`, never abort mid-solve** | D66 14/15, E18 16/18 lost; E21 clamp 0 stragglers [A4] | Duck R6-S6 |
| W5 | **Fill the tail with independent attempts on unsolved tasks** (stage 3 `extra_attempts`); stage-1-first; ORDER2 + cells | Attempt 3 on unsolved = 0.12-0.16 tasks, 2-3× attempt 2 on accepted; ORDER2 +4-7 under a tight budget [A4] | `solve_all_r6` stage 3 |
| W6 | **Prefill isolation**: chunk 1024 vs 2048, `--long-prefill-token-threshold`; decode tok/s of the other streams during prefill | Chunk 2048 +7-12 % prefill (CMP) [A3]; Merlin warns "max_num_scheduled_tokens set to 4096 … suboptimal" [A1] | `CHUNK`, `LPT` |
| W7 | **No side GPU work during the solve** (probes before the solve) | E8 scorer OOM lost 15 units [A4] | harness |
| W8 | **Replay every controller on recorded real metric series before GPU** | rev 6d probe mistake [A4] | builder rule |
| W9 | **Planning tools:** the two-term model; 240-task time-slice and budget-grid simulators with Flash-Next rates | [A2, A4] | `Exp15/.../scheduling rules (2026-10-25)/` |
| W10 | Coverage lever, not speed: **Swift1.5-Flash-Next** (31-58 % fewer thinking tokens, small accuracy drops on BF16 benchmarks; profile `fn-swift1.5-quad-24g-sm89` exists; licence risk) | [A3, G1v] | needs an ARC accuracy run |

### Tier B: boot time (every speed notebook pays cold boots)

| # | Lever | Gain (est.) | Note |
|---|---|---|---|
| B1 | **Compile/JIT cache Model (`.bin`):** `VLLM_CACHE_ROOT` (AOT), `FLASHINFER_WORKSPACE_BASE`, `TRITON_CACHE_DIR` (incl. our sm_89 autotune); never `nv/`; strictly keyed (Merlin commit, payload sha, profile, KV dtype, layout, max-len, captures, driver); gated on a greedy known-answer check | 3-6 min per boot | E14's tar failed (IndexError): test the tar code in a CPU kit first [A6] |
| B2 | **sha256 = the prefetch:** range-parallel from t = 0, overlapped with the install; boot as soon as the install is done; abort only on a mismatch | up to ~275 s | replaces RC2's serial sha gate [A6] |
| B3 | **Read order for the cgroup:** non-PLE parts first, PLE last; `posix_fadvise(DONTNEED)` after the PLE pin; never /dev/shm | load headroom | [A6] |
| B4 | **Wheelhouse and Merlin env as Models (NFS)**; a pre-built Merlin venv `.bin` | IO; ~2 min (UNVERIFIED) | [A6] |
| B5 | **Progress-based ready watchdog** (log growth, rchar, stage markers) inside a global bound; sampled warm-up inside the boot; log every boot phase | avoids the 30-min = LB 0 failure and the post-ready JIT | [A6] |
| B6 | One boot per notebook in production; for unavoidable second boots: graceful SIGTERM ≥ 75 s, /dev/shm cleanup, GPU release < 150 MiB, same cache roots | | [A6] |

### Never do (measured negatives)

| Never | Why / evidence |
|---|---|
| P2P on, PCIe-IPC all-reduce, NCCL CTA tuning, `NCCL_SHM_USE_CUDA_MEMCPY` | All slower; memcpy hangs in capture [A7] |
| KV offload to host for live streams | A decoding stream needs its KV on the GPU; an sm_89 fork wedged at 0.3-0.9 tok/s [A5] |
| Prefix caching off while MTP is on | E19 state flips; 40k fell to 3 tok/s [A1] |
| `--no-async-scheduling` with PP | Deadlocks [A3] |
| Admitting beyond residency; time-slicing more sessions than KV holds; pause/resume branches | E12 EVAL30; Franzen; B13 [A4, A5] |
| Abort-and-resubmit drains | [A4] |
| Synthetic prompts for acceptance or K decisions | 3.57 vs 2.69 [A1] |
| A microbenchmark gain counted as an engine gain | [A1] |
| `COUNTERS=1` in production | Disables the fused QSA writer [A3] |
| `--enable-hc-sp`, FlashInfer PCIe IPC | PP = 1 only / needs P2P [G1v] |
| FlashInfer sampler without the `-lcuda` shim | RC1 death [A6] |
| SGLang EP4 for Flash-Next; NVFP4 KV on the Flash-Next QSA path (bf16/fp8 only) | [A3, A1] |
| Early-stop of hopeless thinking | AUC 0.63, −18 % train passes [A4] |

### Alternative branches
- **Smaller-checkpoint path** (C6) and **Swift1.5** (W10): both need ARC accuracy runs.
- **ExLlamaV3 + EXL3:** 795 at 8 streams on 2×5090, but with 118-token prompts; long-context only single-stream; SM120. On vLLM via vllm-exl3 it was 0.62×. Prototype only if Merlin tops out. [G1v]
- **Stock vLLM 0.32 + Intel W4A16:** correct, but KV is tiny at TP4. Only the fallback. [A3]

---

## 4. Stages and gates

| Stage | What | Gate to the next stage |
|---|---|---|
| **S0 = E13 RC2** (running) | Correctness BF16/FP8, KV census, ladder 40k@1/2/4/5 + 8k@8, 90k/116k, long rows, MTP accept, graph/scale lines, telemetry | BF16 + FP8 correctness. **Read from the log:** per-rank free VRAM; real pool and F (fixed blocks); graph mode for target / draft / RecoverSSM commit; active SSM dtype; capture list; PP micro-batch sizes and overlap; prefill rate from counters; per-position acceptance; the "max_num_scheduled_tokens" warning; NCCL transport per group; whether the first 40k/116k prefill hits the #60490 OOM |
| **S1 capacity** (one notebook, few boots) | C4 text-only, C3 SSM dtype, C5 pin steps, D9 (#60490), W6 chunk; prefix continuation test (2-turn replay + after an abort); mixed 8k-116k workload; `nvidia-smi dmon` | More resident streams with no correctness change; real running == level |
| **S2 decode** (parallel account) | D1 K0/K1/K2/K3 × 5/8/12/16 streams on xhigh ARC prompts; D2; D3 eager-vs-graph A/B | Steady tok/s up at matched streams; per-request acceptance does not decay (log per 10-min window) |
| **S3 kernels / comm / layout** | D4 GEMM plans + HC port; D5 Marlin MoE bench + tuning; D6 PP balance / sharded sampling; D7 world-2 NCCL vs P5 vs LL128; D8 switches; D10; D11 | End-to-end gain repeated; bitwise or greedy parity; no rank or graph mismatch |
| **FN-Duck EVAL** | The best config; W1-W8; prefix and recompute counters; solve-vs-tokens bands (thinking ≥ 60k); correct solves per GPU-hour | Run ÷ steady ≥ 0.9; accuracy parity with MTP off on the same tasks |
| **B tier** | Applied in every builder; B1 cache Model after the first good production boot | — |

**Decision rubric on RC2's measured steady tok/s** [G1v]:

| RC2 steady tok/s | Next move |
|---|---|
| < 250 | One profiled boot first. Fix the trace classifier: GDN filed as "other" (6.1 % real vs 0.2 %), 0 forward annotations matched; add `execute_context_*` scopes and `gdn_*` / `qsa_*` / `marlin_moe` / `persistent_topk` patterns [A7] |
| 250-450 | Tier C, then D5/D4 |
| 450-700 | D1/D2/D3, W2/W3 |
| 700-1000 | D4-D8 and the W tier |
| ≥ 1000 | The remaining cycle/acceptance gap; the tail |

**Correctness outcomes:**

| RC2 outcome | Next |
|---|---|
| BF16 PASS, FP8 FAIL | BF16 capacity only |
| Merlin load fail | Stock vLLM fallback; EXL3 / smaller-checkpoint branches move up |
| Long reasoning fail | Isolation: MTP off, dtype, state |

### 4.1 Selection rule after NB1-NB3 (strategic correction, user 2026-10-31)

Not every lever in §3 gets a GPU run. NB1 (capacity), NB2 (decode/MTP) and NB3 (kernel bench) are the screening round.
After them, GPU budget goes ONLY to the 2-3 highest-upside changes; everything else is parked with its measured numbers.

1. **Scorecard.** NB1, NB2 and NB3 each write `lever_scorecard.json`, one row per lever measured:
   `lever` (§3 id), `measured` (what changed: tok/s at matched streams, resident streams, ms/tick, KV tokens),
   `projected_run_tok_s_gain` (via the §1 arithmetic: steady = C·a/t_cycle, run ≈ 0.9 × steady),
   `correctness` (PASS / FAIL / UNTESTED), `confidence` (repeats, window noise), `adoption` (`config` = a flag/env already
   measured end-to-end; `patch` = a source change; `research`), `cost_gpu_h` to confirm, `notes`.
2. **Score** = `projected_run_tok_s_gain` × (1 if correctness PASS else 0) × confidence weight ÷ adoption cost class
   (config 1, patch 2, research 4). FAIL or UNTESTED correctness never gets picked.
3. **Pick the top 2-3** with a projected gain ≥ 5 % of the current run average each. Config-only winners already measured
   end-to-end in NB1/NB2 go straight into the base config (no separate GPU run). Patch winners go to NB4, one per bundle
   (NB4-A = the top patch alone, NB4-B = the second, on top of A; rollback on any regression).
4. **Park the rest.** A parked lever is reopened only if (a) a pick fails its gate, or (b) the picks are in and the run
   average is still below 1500. Parked rows keep their numbers in the scorecard; they are not re-run "to be thorough".
5. **Budget order.** The 12-h production run's GPU allocation and the deadline margin are reserved first; screening and
   NB4 use what is left.
6. **RC2 prior (before the screening data):** capacity is the binding term (8k@8 KV usage 0.97, F dominates; steady 190
   at 5 streams, 262 at 8). Expected top candidates, to be confirmed or replaced by the scorecard: C1/C3/C4/C5 + seqs > 8
   (more resident streams), D1/D2 (K and draft head), and the largest NB3 kernel term (D5 MoE or D7 all-reduce).
7. **NB3 promotion and NB4 adoption (GPT audits of NB3, 2026-10-31, N3-2/N3-9/N3-11/N3-22).** A NB3 row is promotable
   only when its bench's verified status is DONE (rc 0, no timeout, GPUs released, file status DONE, every check True)
   and its correctness is exactly PASS (PASS_BOUND_ONLY, PARTIAL_BUDGET, CONCURRENCY_UNVERIFIED rows are diagnostic, score
   0). A GEMM-plan (D4) or P5 (D7) change is adopted only after a full-engine A/B (2 repeats) plus the 40k / 90k
   correctness rows; P5 additionally needs 1000+ graph replays and both-pair contention evidence before integration.
   NB3 saved-ms columns are microbenchmark numbers, not additive under PP2 overlap; `engine_confirmed_saved_ms` is filled
   by NB4 only.

---

## 5. Risks to test early

| Risk | Evidence | Test |
|---|---|---|
| **First long prefill OOM** (#60490 missing; 0.4-0.5 GiB/GPU) | [G1v] | RC2 40k prefill / 116k census; D9 |
| PP2 long-prefill instability | Stock PP4 crashed at 8k (#63505), no Merlin fix found [A1, A7] | RC2 90k/116k + long rows |
| PP + MTP + prefix constant-token loops (12.5 % at ≥ 3 concurrent; #55506; fixed in Merlin, unsoaked) | [A3] | FN-Duck smoke at full concurrency; repetition detector |
| MTP acceptance collapse to 0 for hours (#55357) / token-0 "!" (#37111) / decay over uptime (#37326) | [A2, G1v] | Per-request acceptance per window; abort runaways |
| Marlin + EP top-k weights multiplied inside the kernel → garbage (chenxin patch 02k; upstream status unknown) | [A3] | RC2 greedy oracle vs BF16; long rows |
| FP8 QSA numerics on sm_89 (profile untested) | [G1v] | RC2 A3 parity |
| Prefix + MTP hybrid-state corruption (class warning, #53912) | [A1, G1v] | Shared-prefix siblings (S1) |
| Graph capture failure under host load (#57759) | [G1v] | Capture logs; PIECEWISE fallback ready |
| Aborted request loses its cache on 0.32 | [A4] | S1 continuation test after an abort |
| Speed winner with lower ARC accuracy | [A1, A2] | Paired ARC run before adoption |
| Boot over 30 min | SGLang 1,197 s on 10-21 [A6] | B2/B5 |

---

## 6. Open questions (with who answers them)

**RC2 log / trace:**
1. Graph mode for target / draft / commit.
2. Per-rank free VRAM, the real pool and F.
3. SSM dtype and the fused-kernel path.
4. PP micro-batch sizes and the overlap.
5. Step ms vs T (the MoE floor).
6. Prefill rate at chunk 1024.
7. Per-position acceptance at xhigh.
8. NCCL transport per group, and custom AR off at TP2.

**S1 / S2 / S3 runs:**
9. The best K per stream count.
10. The DRAFT_HEAD effect on L4.
11. The prefix hit at block 4096 per Duck turn and after an abort.
12. World-2 NCCL vs P5.
13. Marlin MoE GB/s and the real distinct-expert count D(T) on ARC reasoning.
14. Does an (8,9) CuTe GEMM plan compile and win?
15. The eager-vs-graph gap.

**Research / source:**
16. Accuracy of the smaller Flash-Next checkpoints and of Swift1.5 on ARC.
17. Do caches stay valid across sessions and on hidden-rerun machines; what mount type do notebook outputs get? [A6]
18. Is seqs > 8 accepted by Merlin, given "the only concurrency the engine is gated at"? [A3]

**Data still to read:** E23 FULL (Merlin 27B TP4 at 16/20/24 streams; FULL graph G1/G2 rows), when it lands.

---

## 7. Change log
- v0-v2.1 (2026-10-31): folder; GPT report 1 + verification; user target definition; mining summaries.
- **v3 (2026-10-31): rebuilt after reading all 7 mining reports and the verification in full.** New since v2.1:
  - **§0 rules:** the user's standing directives (few arms, short speed stage, audits, mixed admission, 0.95 gate, 11:50 stop, paired accuracy runs).
  - **Facts:**
    - PP2 interleaving in source (`max_concurrent_batches` = pp + 1);
    - the fixed +7 blocks = 38 % of the pool at 8 streams;
    - TP4 −57 % pool;
    - partition capacity numbers;
    - Merlin cost-aware admission and retention numbers;
    - the Franzen collapse;
    - QSA as a split op under PIECEWISE;
    - the sm_89 GEMM-plan gap with the SM121 seed;
    - HC replicated weights;
    - mount types;
    - boot-phase times;
    - the ARC-AGI-3 Flash-Next lessons;
    - the commit-turn header cache miss.
  - **Levers:**
    - C1 (fixed blocks) and C2 (live-block admission) added at the top;
    - TP4 demoted;
    - D4 (GEMM plans), D5 (Marlin MoE bench + `MERLIN_MARLIN_MOE_CFG`), D6 (PP balance), D8 (Merlin runtime switches), W3 (system header), W7, W10 (Swift1.5) added;
    - B tier expanded;
    - never-do list extended.
  - **Arithmetic:** the per-tick table, MoE bytes per verify token, the +31 % PP2 expert reads.
  - **Waiting for:** GPT reports 2 and 3, RC2, E23 FULL.
- v3.1 (2026-10-31): the commit-turn item corrected.
  - The current Duck has no cache miss; the problem is 25 % commit turns without a tool call.
  - CPU prefix test added: `enable_thinking=False` → 0 % reuse; hand-closed think → 98.3 %. W3 is rewritten as that fix.
  - Block-4096 granularity (65.7 % vs 98.3 %) added as a W2 question.
- v3.6 (2026-10-31): third GPT review validated and approved by the user: duty-factor gate ≥ 88.2 %, projected admission ≠
  zero preemptions (counter + gate), K7 caveat, 15.77 MiB per block; NB1 separates critical path from summed kernel time
  and saves router top-k ids for NB3 replay; NB5 adds a 2,048-token safety margin, a BUDGET_LIMITED verdict below the 60k
  floor, the Merlin-vs-Duck admission interaction counters, early-exit SMOKE, a correctness-aware C→A switch and an
  optional budget-sensitivity profile (60k/80k/100k/112k, off).
- v3.5 (2026-10-31): §1.1 throughput model after two external roofline reviews, the lead's re-validation and the GPT
  decision (GO for local revisions, no GPU push): a 2.72 / steady 1,700 targets, three-layer roofline with KV feasibility
  and STRUCTURAL_TARGET rows, FITTED/ESTIMATE/ENGINE-DERIVED labels, leave-one-out holdout of the step model (1.5 % mean,
  in-range only), PP2 split-read and stage-imbalance as hypotheses with their tests, the "no single flag missing" wording
  withdrawn. The v3.4 "MoE-only" ceilings are superseded by the combined rows.
- v3.4 (2026-10-31): GPT reports 2 and 3 verified (`Experiment Review/GPT research inputs/05_*`, `06_*`). New:
  - **RC2 ≈ Merlin's own reference after bandwidth normalisation** (3090 six 127k sessions 574.5 ÷ 3.12 ≈ 184 vs RC2
    160-190): no single missing flag; 1500 needs structural change.
  - **MoE roofline (est.)**: PP2 re-reads experts per micro-batch; INT4 MoE-only ceiling at 250 GB/s/card ≈ 838 (C 16),
    1,095 (C 32), 1,386 (C 48); single-batch layout 1,095 / 1,706 / 2,409; 3-bit × 1.33, 2-bit × 2. Measured fit 368 at
    C 16, 550 at C 32. 1500 needs tick 16.3 ms at C 16 / 32.5 ms at C 32 (today 66.3 / 88.7): cut the ~24 ms fixed floor
    AND raise tokens per expert read (streams, acceptance, layout) or lower bytes (C6).
  - **KV pin headroom**: the 4.1e9 sm89 pin is an RTX 4090 number; L4 RC2 kept ≥ 1,607 MiB free per rank → +1.0-1.1 GiB
    ≈ 215-220 blocks (from 149): 120k worst case 4 → 6 streams (C5, config-only).
  - **FP8 byte-decoder arm**: Merlin's sm_86-qualified `_decode_e4m3_to_bf16` path exists in the same tree; sm_89 uses
    the never-run native cast (`ops/qsa.py:28-36`). NB0 boot E forces the byte path.
  - **RecoverSSM commit graph** modes eager/staged/graph (runtime-flippable, bit-identical; PP-deferred commits stay eager).
  - Corrections: #60532 does not apply to Flash-Next; #60234/#62129 low risk (RC2 ran PP2 + PLE + MTP); GPT formulas
    lack the PP2 cycle factor; capture lists must cover (C/2)(1+K) per micro-batch.
- v3.3 (2026-10-31): RC2 result + 3 external audits (`Experiment Review/GPT research inputs/02-04_*`, each verified) +
  our full analysis (`Experiment 13/Experiment Results/E13_RC2_GPU_v1_2026-10-31.md`). Changes: F = 6 (not 7); Merlin
  retains up to 16 finished sessions, so kv_cache_usage_perc is not live demand (gate on running blocks); RecoverSSM
  commit runs eager (candidate lever `VLLM_RECOVERSSM_COMMIT_GRAPH`); MTP layer FP8 KV at default scale 1.0; per-position
  acceptance 0.834/0.660/0.516; step fit 25.6 + 5.79·r ms per tick (cycle = 2 ticks); the natural 116k FP8 answer on
  0934a4d8 is wrong (15/27). New notebook **NB0 FP8 quality isolation** (BF16/FP8 × MTP off/K3, teacher-forced raw
  arrays at 2k-90k, fresh + repeat); NB1 = capacity only; NB2 drops its MTP-off reference; forced LL128 dropped from NB3.
  FP8 is a production candidate only after NB0's gate and a paired ARC accuracy check.
  - Paired ARC accuracy check (user-approved 2026-10-31): FP8+K3 at 4 streams vs BF16+K3 at 2 streams (no-preemption
    ceilings at 120k: 36 blocks/request), same seeds and budget, on 11 tasks: the 10 that the 27B solved on all ≥ 3 of our
    attempts (1ae2feb7, 38007db0, 3e6067c3, 65b59efc, d8e07eb2, 1818057f, 409aa875, 5961cc34, 7491f3cf, b99e7126) +
    0934a4d8. ≈ 3 GPU-h. Runs only after NB0; skipped if NB0 fails FP8 clearly. MTP-off is left to NB0's teacher forcing.
- v3.2 (2026-10-31): §4.1 selection rule (user-approved strategic correction from the GPT 6-notebook audit): NB1-NB3 are
  the screening round; each writes `lever_scorecard.json`; only the top 2-3 levers by projected run gain × correctness ×
  confidence ÷ adoption cost get further GPU; the rest are parked with their numbers. RC2 result (S0 PASS) noted as the prior.
  - The GPT six-notebook audit (conditional GO for NB1-NB3 builders) is noted; its NB fixes go into §4 when the builders start.
