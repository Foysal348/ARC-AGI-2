# File names in this flat zip
Every file sits at the top level. A path like `folder/sub/file` in README.md is stored as `folder__sub__file`.
Left out: binary torch profiler traces (*.gz) and *.npz arrays.
