# E25 NB2: two diagnostic SMOKE notebooks after the failed SMOKE (2026-10-31)

## What failed (folder `failed_smoke_run/`)
`Q27-XHIGH-E25_NB2_DECODE_SMOKE.ipynb` (sha ad8a28a5…) ran on Kaggle 4×L4 (foysalemonshanto, 21.2 min). The boot was
B = Flash-Next on Merlin v3.0.0, K2 MTP + INT8 draft head + max_num_seqs 16 + capture list up to 64.
- Passed: probes, sampled check, short greedy oracle, config read-back (K, head, seqs, captures), 16-stream admission
  (0 preemptions), dev-mode prefix reset, profiler trace.
- Failed: the 90-s 8k@8 window was flagged `FAIL_GARBAGE_UNDER_LOAD`. Stream 0 (trace `output/nb2/traces/requests.jsonl`
  row 37, prompt f4212f34, seed 1234, temp 0.6, top_p 0.95, top_k 20, ignore_eos) fell into a "row? row? row? …" loop after
  about 1,400 of 2,857 tokens, after coherent grid analysis. The other 7 streams (rows 38-44, seeds 1235-1241) are clean.
  → SMOKE_FAIL, so NB2 FULL is blocked by rule.
- Speed: 242.6 tok/s at 8k@8, tick 42.7 ms, acceptance length 2.592 (per position 0.860 / 0.731). The RC2 control
  (K3, BF16 head, seqs 8) gives 261.8 tok/s, tick 48.2 ms, 3.154.
Question: is the loop caused by K2 / the INT8 head / the bigger capture list, or does the target loop by itself on that prompt
at this sampling? (Speculative decoding with probabilistic verification is lossless in principle.)

## The two new notebooks (folder `new_notebooks/`; same code as the FULL notebook except the baked profile)
| notebook | sha256 | what it runs |
|---|---|---|
| `…_SMOKE_SEED2.ipynb` | e9504bbb… | the same boot B and the same 8 prompts; window seeds 4321-4328 instead of 1234-1241 |
| `…_SMOKE_CTRL.ipynb` | b643b304… | the exact RC2 FP8 control (K3, BF16 draft head, seqs 8, RC2 captures; exact diff vs RC2 empty) on the same 8 prompts, same seeds 1234-1241 and sampling |
Both:
- run the same SMOKE flow (install, sha, probes, sampled, oracle, warm-up, one 90-s 8k@8 window);
- never stop the window early on garbage;
- write a per-stream table {stream, seed, prompt_sha, n_tokens, first garbage window, tail verdict} and the loop counts;
- check that the 8 prompts are the same set and order as the failed run (printed and stored);
- give verdict `DIAG_DONE` or `DIAG_INCOMPLETE`;
- have a 35-min hard stop, expected 18-22 min.
How to read the pair:
- SEED2 loops and CTRL does not → suggests the B configuration GROUP (K2, INT8 head, seqs 16, captures, cache reset differ together); no single factor is identified.
- CTRL loops too (same seed) → suggests target / prompt-level repetition; numeric causes are not excluded.
- Neither loops → the original event was not reproduced (rare or non-deterministic), not resolved.
CTRL cannot clear the prefix cache before its window (the exact RC2 config has no dev mode), and seeded sampling is not
bitwise repeatable across batch numerics, so CTRL is a statistical comparison, not an exact replay.

## Evidence (folder `kits_v4/`, Kaggle CPU kits on the pinned image)
- (kit v3, before the audit round) units kit ALL OK: unit tests 122/122, fake e2e 84/84; flows rerun, no-Merlin, smoke (SMOKE_PASS), smoke_seed2
  (DIAG_DONE, 0 loops with seeds 4321+) and smoke_ctrl (DIAG_DONE, the injected loop on seed 1234 found at stream 0;
  exact RC2 diff empty).
- real kit: everything OK (inputs, merge, sha, prompt hashes, RC2 oracle rows, Merlin install, host phase all boots, CTRL
  exact RC2, capture plan, page-cache drop) except `parser_all_boots`. Merlin's CPU parser raises "Failed to infer device type"
  without a GPU. This is a known CPU-container limit seen in every NB0 / NB1 / NB2 real kit, not an argv defect.
- The previously run FULL (e20350a9) and SMOKE (ad8a28a5) notebooks are unchanged; the builder pins and asserts their shas.

## Files
`build/` (builder, kit builder, export, unit tests, fake server, e2e checker), `docs/` (wave-1 results, PLAN, batch list,
earlier NB2 units kit report), `00_AUDIT_PROMPT.md`.

## Audit round (three-bundle audits 1-3, 2026-10-31), applied
- `diag_verdict` now also requires `prompt_identity` (same set + order, all 8 prompt shas match the failed run),
  `stream_integrity` (8 streams, seeds exactly seed..seed+7, none missing, no error, n_tokens > 0), `trace_status == TABLE`
  and `no_duplicate_streams`; else DIAG_INCOMPLETE with `failed_detail`. A genuine loop with complete records stays DIAG_DONE.
- `diag_stream_table`: duplicates → AMBIGUOUS_STREAM_ROWS (no overwrite); rows must also match top_p 0.95, top_k 20, ignore_eos.
- logprobs 5 on the 8k@8 window requests only (sampling unchanged: checked in the Merlin vLLM 0.32 sampler and rejection
  sampler); a looped stream records the onset and the top ids / margins of 64 positions around it.
- Interpretation table with "suggests", never "proves"; a clean CTRL implicates the B configuration GROUP only.
- Failed run row 37 labelled MODEL_REPETITION_OBSERVED / NUMERIC_CAUSE_UNDETERMINED (last 500 ids: 2713 ×250, 30 ×250; no margins).
- Evidence: units 133/133 (Py3.14 + Py3.12). Kaggle kits v4 (`kits_v4/`): units ALL OK (units 133/133, fake e2e 84/84;
  flow smoke_seed2 DIAG_DONE 0 loops, flow smoke_ctrl DIAG_DONE with the injected loop at stream 0, all new checks true);
  real: every check OK except the GPU-dependent `parser_all_boots`.
