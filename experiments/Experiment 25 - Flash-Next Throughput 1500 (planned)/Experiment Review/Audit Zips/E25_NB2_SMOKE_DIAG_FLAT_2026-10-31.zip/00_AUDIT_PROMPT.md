# GO / NO-GO: E25 NB2 diagnostic SMOKEs (SEED2, CTRL)

Read `README.md`, then the two notebooks in `new_notebooks/` (or `build/nb2_code_export.py` + `build/build_e25_nb2.py`), the
failed run in `failed_smoke_run/` (notebook + full output, incl. `output/nb2/traces/requests.jsonl` rows 37-44 and the server log)
and the kit outputs in `kits_v3/`.

Answer:
1. Do the two notebooks answer the question "is the 8k@8 loop caused by K2 / INT8 head / CAPS16 or by the target itself"?
   Is anything confounded (prompts, seeds, sampling, prefix cache, batch composition, captures, server config)?
2. Is there a fatal blocker (crash, wrong raw data, wasted GPU)? file:line, failure scenario, minimal fix, a test.
3. From the failed trace: is the looped stream (row 37) consistent with model-level repetition, or does anything point at
   numeric corruption (token ids, margins, acceptance around the loop start)?
Labels, wording and nice-to-haves go into a separate "after the run" list.
Output: `VERDICT: GO` or `VERDICT: NO-GO`, then the blocker list (may be empty), then the after-the-run list.
