# E25 NB3 — final GO bundle (2026-10-31)

This bundle is the exact NB3 notebook that would be pushed to a Kaggle 4×L4 GPU run, with everything needed to decide
GO / NO-GO. Nothing has been pushed yet; the push needs the user's go.

## What NB3 does
NB3 = kernel bench of PLAN_1500 §3 (no model server is started). It measures, on the real Merlin v3.0.0 install
(vLLM 0.32.0 fork) and the real Flash-Next W4A16 checkpoint:
- **D5 Marlin MoE** (layer-0 local experts, EP2 split, T = 16 / 4 / 8 first, then the rest): baseline vs tuned configs,
  graph and eager times kept apart, DRAM bytes via ncu (split and combined runs), correctness vs an fp32 reference.
- **D5 humming arms (C6, research only, never ranked)**: humming W4 g128 on the SAME INT4 weights (kernel-vs-kernel control) and
  W3 g128 / W2 g128 / W3 g64 on synthetic round-to-nearest requant (speed and bytes only; accuracy not representative).
  Structural gate recorded: W3 ≤ 0.8× and W2 ≤ 0.6× Marlin W4 (net positive up to ~1.3× because of the KV capacity gain).
  `import humming` failing = UNAVAILABLE, the bench continues.
- **D7 world-2 all-reduce** (custom AR vs NCCL, pairs and solo, the PP2×TP2 layout).
- **D4 sm_89 GEMM plans + heads** (dense GEMM plans, draft heads, skinny shapes).
Step order and estimates (min): Merlin install 6 → sha gate 4 → bench env 2 → D5 core 13 → D7 build 3 → D7 pairs 10 →
D7 solo 4 → D4 12 → D5 rest 8. Budget 75 min (`NB3_BUDGET_SEC`); every step is skipped as `SKIPPED_BUDGET` when the time left
is below its estimate + 5 min. Fallback submission is written in CELL 6. On the competition rerun it does nothing but the fallback.

## Status
- Notebook `notebook/Q27-XHIGH-E25_NB3_KERNELS.ipynb`, sha256 `8e37d89d88b6174fe2e5a86c320d9b338c97e10d23d0a27535d2cdb60ec87e95`, 267,128 B.
- All 25 items of the three GPT audits of NB3 (N3-1 … N3-25, `docs/PENDING_BATCH_FIXES.md` NB3 section) were applied before this build.
- Local unit tests on this build: **261/261 PASS** (`tests/nb3_unit_tests_run_2026-10-31.txt`, run today).
- Kaggle CPU kits v2 on the pinned image (Py3.12), all run on this exact notebook sha: **mounts ALL OK, merlin ALL OK, units ALL OK**
  (`kits_v2/`). The kits check: real Model mounts and sha of every file, the real Merlin install, the bench plans, imports,
  the units on Linux.
- The later audits of NB0 / NB1 / NB2 / NB5 (A / B / C items) do not touch NB3.
- Not testable on CPU: real kernel timings, ncu counters (`ERR_NVGPUCTRPERM` is handled as `DRAM_BYTES_UNVERIFIED`), humming JIT on a GPU
  (humming CPU kit: import + sm_89 heuristics + NVRTC compile of 8 W3/W2 kernels PASS).

## Push (prepared, not pushed)
`push/kernel-metadata.json`: `foysalemonshanto/q27-xhigh-e25-nb3-kernels`, GPU on, machine `NvidiaL4` (as RC2), internet off,
pinned docker image, Models = RC2's 7 (merlin p1-p5, fp8ple overlay, e23-merlin-env), competition source.

## Files
- `notebook/` the notebook; `build/` builder, kit builder, exported code, bench modules (`nb3_common`, `nb3_moe_bench`,
  `nb3_gemm_bench`, `nb3_humming`, `nb3_export/`), unit tests.
- `tests/` fresh unit-test output. `kits_v2/` the three CPU-kit outputs (reports + logs).
- `docs/` PLAN_1500 v3.6, build spec, batch list with the N3 audit items and evidence, kit v1 results, RC2 GPU analysis.
- `00_AUDIT_PROMPT.md` the prompt for the final GO / NO-GO.
