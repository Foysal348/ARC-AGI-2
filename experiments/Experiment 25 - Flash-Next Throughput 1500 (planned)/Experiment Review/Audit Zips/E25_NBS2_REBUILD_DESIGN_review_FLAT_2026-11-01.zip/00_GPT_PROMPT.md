# DESIGN review: NB-S2 "capacity" rebuild on the current NBDF-K100 (DFlash2 D3s base, Kaggle 4xL4, klee100 on Merlin v3.0.0)

**Answer GO / NO-GO for the rebuild DESIGN on the first line. Then list ONLY BLOCKERS and SEVERE problems** (an arm that
cannot launch, an arm skipped / stopped by anything but a real failure / the time budget / its switch, a wasted run, wrong
data recorded), each with file:line, why, fix. No style items, no new features; verdict-label quality is out of scope
(deferred by the user, raw numbers read by hand).

Read `DESIGN__NBS2_REBUILD.md` first. `OLD__*.ipynb` is the current (OLD-base) build a0faf93c; `BUILD__*` are the NB-S2
builder / lib / tests / body / export / kit (being retargeted right now: files may be mid-rebuild) and `BUILD__build_e25_nbs1.py`
is the reference port of the same kind already done (NB-S1, on GPU now, with the per-arm switch). `NBDF__*` = the current
NBDF base (nbdf_lib b0147751 hard-only gates, dflash_seam 341d859b with the GRD e2_guards edit, builders, facts) and
`KIT__*` = its real CPU kit ALL OK (closed e2198285). `FIXLIST__*` = audit items S2-1..S2-6 (deferred as record-only).
