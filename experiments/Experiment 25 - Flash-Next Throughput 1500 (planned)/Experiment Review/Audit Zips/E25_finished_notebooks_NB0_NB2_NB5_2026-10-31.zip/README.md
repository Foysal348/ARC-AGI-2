# Experiment 25 — Flash-Next Throughput 1500: finished notebooks (2026-10-31)

Qwen3.8-Flash-Next on Kaggle 4× NVIDIA L4 with the Merlin engine (vLLM 0.32.0 fork), TP2×PP2+EP, MTP K3, FP8 QSA KV
cache. Goal: a whole-run average of ≥ 1,500 generated tok/s for ARC-AGI-2 solving (thinking 60k-120k tokens per request,
max-model-len 131,072). Baseline (E13 RC2, real GPU run): 160-262 tok/s; see `PLAN_1500.md` §1.1 for the model.

**Status of everything in this zip:** built and tested locally only (unit tests + a fake-server end-to-end run).
Nothing here has run on a GPU yet; every GPU run needs the user's explicit go. NB1 and NB3 are still being finished
(NB3: 25 audit fixes + humming arms in progress; NB1: builder still running) and are not included.

| File | sha256 (first 16) | Bytes |
|---|---|---|
| `Q27-XHIGH-E25_NB0_FP8_QUALITY.ipynb` | 074a0f53158a3a28 | 260,295 |
| `Q27-XHIGH-E25_NB2_DECODE.ipynb` | c654f68e176a42a0 | 253,695 |
| `Q27-XHIGH-E25_NB5_FNDUCK.ipynb` (default EVAL120) | 6aff0155c6c47d0e | 328,321 |
| `Q27-XHIGH-E25_NB5_FNDUCK_EVAL30.ipynb` | 69b6f8510283dc7c | 328,319 |
| `Q27-XHIGH-E25_NB5_FNDUCK_EVAL30MTP.ipynb` | 5afba5d7987d5ef4 | 328,325 |
| `Q27-XHIGH-E25_NB5_FNDUCK_QUALITY.ipynb` | 3f1ab77ac53397f0 | 328,321 |
| `Q27-XHIGH-E25_NB5_FNDUCK_SMOKEDIAG.ipynb` | bddf4b450ad3fe62 | 328,325 |
| `Q27-XHIGH-E25_NB5_FNDUCK_BUDGET.ipynb` | aca4ef07aac78fb1 | 328,319 |

Every notebook: exact Kaggle Model input paths (5 checkpoint parts, FP8 PLE overlay, Merlin offline env), checkpoint
merge + full sha256 gate, offline Merlin install, page-cache drop + host-RAM gate + GPU-empty gate before every boot,
30-min boot-ready gate, per-boot watchdog, global hard stop, every request and full thinking text saved, a fallback
`submission.json`, and a `PUSHED` sha guard so a notebook that ran on Kaggle is never overwritten.

---

## NB0 — FP8 quality isolation (`Q27-XHIGH-E25_NB0_FP8_QUALITY.ipynb`, ~57 min of a 100-min budget)

**Why:** RC2 measured FP8-KV vs BF16-KV teacher-forced logprobs at 40k: mean |Δ| 1.88, rank-1 agreement 0.367 (BF16
A/A = 0), and its one long FP8 answer was wrong. FP8 doubles the KV pool (513,940 vs 269,042 tokens), so its quality
decides the capacity plan. **NB0 finds out whether the divergence is real and where it comes from.**

**What it does:** five short boots, teacher-forced measurements only (no speed ladders), order D → C → E → B → A:

| Boot | KV | MTP | Note |
|---|---|---|---|
| D | FP8 | K3 | exactly RC2 FP8 |
| C | BF16 | K3 | exactly RC2 BF16 |
| E | FP8 | K3 | FP8 read through Merlin's sm_86-qualified byte decoder instead of the never-run-on-Ada native cast (env-gated patch, audited, restored after; an on-GPU bit-exact check of all 256 E4M3 codes first) |
| B | FP8 | off | `--speculative-config` removed |
| A | BF16 | off | differs from B only in KV dtype |

Per boot: health checks (probes, sampled, greedy oracle) and a config read-back from the server log; teacher-forced last
256 positions at 2k / 8k / 40k / 90k with RC2's exact prompts (fresh + repeat = A/A); decode-vs-prompt-logprob
self-consistency, cold-vs-cached decode, ±2 position shift and chunk-boundary checks; raw per-position arrays saved
(85 files per run). Comparisons A–B, C–D, A–C, B–D, C–E, D–E per band, with a decision table (divergence from 2k →
quantization/kernel; only long → accumulation/state; native-only → the sm_89 cast; MTP-only → speculative/PP state).
Gates: screening HOLD if rank-1 < 0.90 or mean > 0.15; triage NO_GO if mean > 1.0 or rank-1 < 0.5; never GO by itself.

**Output used by:** the FP8 / BF16 decision for NB1, NB2 and NB5 (and whether the paired accuracy A/B runs).

---

## NB2 — Decode / MTP (`Q27-XHIGH-E25_NB2_DECODE.ipynb`, current build ~4.4 h; to be trimmed to ~3 h + a 35-min SMOKE)

**Why:** the per-step cost and the MTP acceptance decide tok/s at a given stream count; MTP depth K and the draft-head
precision are config-only levers.

**What it does:** boots A (K3 + INT8 draft head), B (K2 + INT8, seqs 16), C (K1 + INT8, seqs 16), optional K0 (no MTP)
and CTRL (= RC2), each measuring: per-K fixed blocks F, per-position acceptance, steady windows at 40k@5/8 and 8k@8/12/16,
tick / cycle / completed-micro-batch / wall-clock rates, accepted tokens per verify token, a frozen-cohort decay replay
and a 20-min long natural window, and a profiler trace window (PP2 stage overlap, per-stage idle, verify rows, graph
modes). Writes `lever_scorecard.json` (D2 / D1 / D3), every row "diagnostic until NB0's FP8 gate passes".
**Decided for the next revision (not yet applied):** long window only in A, K0 and CTRL off, A/B/C all at seqs 16
(same captures), BF16-head fallback if A fails on the INT8 head, and a 35-min SMOKE profile before the full run.

**Output used by:** K and draft-head choice for NB5 and production.

---

## NB5 — FN-Duck (`Q27-XHIGH-E25_NB5_FNDUCK*.ipynb`, six profiles, same code)

**Why:** the first real ARC-AGI-2 measurement of Flash-Next: solve rate (exact grid match) and the whole-run average
tok/s with the Duck agent harness, which is what the leaderboard depends on.

**What it does:** the LB-proven Duck config B harness (E15B/E21 cells, verbatim) ported to the Merlin server (RC2 boot
path). Thinking ≥ 60k up to 120k, no ARC-AGI-3 caps; dual-mode (Kaggle rerun = all hidden tasks; commit = eval subset +
score; full-schema `submission.json`); 11:45 solve end, 11:50 watchdog.
- **Commit-turn variant C:** thinking-on render with the `<think>` block closed by hand, sent as token ids (98.3 % prefix
  reuse on CPU, never `enable_thinking=False`); variant A switchable; SMOKE splits A/C for a paired check; switch to A on
  ≥ 4 commit turns without a tool call, C-only corruption, or ≥ 2 fewer exact matches.
- **Admission:** projected per-attempt reservation (preemption-safe; Merlin retains finished sessions, so the raw KV
  gauge is never used as demand); `live` optional; preemption gate (+1 F margin after any preemption).
- **Budget guard on every request:** `min(cap, 131072 − prompt − 2048)`; below the 60k floor → `BUDGET_LIMITED`.
- **Reports:** steady decode / mixed / solver-window / whole-notebook tok/s and the productive duty factor, prefix-hit and
  recompute tokens, tool-call rate, Merlin-vs-Duck admission interaction, solve-vs-token bands, and a list of GPU-only
  gates (token-id completion, parser, MTP state consistency, real prefix reuse) that the fake server cannot prove.

| Profile file | Use |
|---|---|
| `…_FNDUCK.ipynb` | EVAL120 (default; production-like, needs a SMOKE first) |
| `…_EVAL30.ipynb` | 30-task evaluation |
| `…_EVAL30MTP.ipynb` | 30 tasks, MTP on vs off (second boot without speculation) |
| `…_QUALITY.ipynb` | paired accuracy A/B: FP8+K3 at 4 streams vs BF16+K3 at 2 streams on 11 fixed tasks (10 the 27B always solved + 0934a4d8); refused unless NB0's FP8 gate = PASS |
| `…_SMOKEDIAG.ipynb` | long multi-task diagnostic SMOKE (no early exit, no EVAL) |
| `…_BUDGET.ipynb` | attempt budgets 60k / 80k / 100k / 112k on 30 tasks (off by default) |

**Before any NB5 push:** NB0's verdict, NB1's pool / F / pin and NB2's K / draft head must be baked into CELL 1
(Kaggle commits cannot set env vars), then audit + CPU kit + the user's go.
