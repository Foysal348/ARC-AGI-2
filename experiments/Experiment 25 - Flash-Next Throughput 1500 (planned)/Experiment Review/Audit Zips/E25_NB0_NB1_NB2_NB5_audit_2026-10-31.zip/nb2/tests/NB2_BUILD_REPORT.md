# NB2 builder report (the build agent's own report, 2026-10-31; relayed verbatim in substance)

Local tests: unit 78/78 PASS; fake-server end-to-end 82/82 PASS (boots A, B, C, K0, CTRL all DONE / CLEAN in 17.5 min with
the real Merlin `launch.build()` argv fed to the fake server; F recovered exactly per K: A 7, B 6, C 5, K0 4, CTRL 7 on the
fake, whose F = 4 + K); rerun flow and no-Merlin flow pass. No Kaggle calls, no pushes; RC2 and e23_lab.py untouched.

Flags beyond the agreed design: every non-CTRL boot also gets `--profiler-config` and `VLLM_SERVER_DEV_MODE=1` (recorded
in each boot's diff). B and C run at `--max-num-seqs 16`, A at 8 (to be unified at 16 in the next revision).

Real knob names from Merlin source: `DRAFT_HEAD=int8` → `launch.py:319-322` adds `"draft_lm_head_quant":"int8"` to the
profile's `--speculative-config` (field at `vllm/config/speculative.py:610`; log "Draft lm_head: INT8 weight-only copy").
Flash-Next has no K env knob (`MTP_K=3` fixed in `registry.py:49`; `SPEC_K`/`SEQS` only for the 27B / Ornith families),
so K and seqs change through trailing `--speculative-config` / `--max-num-seqs` / `--compilation-config` (RC2's log shows
"Found duplicate keys" and the later value winning). Capture sizes from `registry.capture_sizes_for`; FULL graphs computed
with the 0.32 dispatcher rule (6 FULL graphs on RC2's list at K3, matching the RC2 log). seqs > 8: no engine cap (buffer
sizing only); the 8 limit is in the profile registry.

| Boot | Changes vs RC2 FP8 | Env added | FULL decode sizes |
|---|---|---|---|
| A | spec → K3 probabilistic + draft_lm_head_quant int8; + `--profiler-config` | DRAFT_HEAD=int8, VLLM_SERVER_DEV_MODE=1 | [4,8,12,16,24,32] |
| B | spec → K2 + int8; seqs 8→16; captures → [1,2,3,4,6,8,12,16,24,32,40,48]; + profiler | same | [3,6,9,12,18,24,33,42,48] |
| C | spec → K1 + int8; seqs 16; + profiler | same | [2,4,6,8,12,16,24,32] |
| K0 (optional) | speculative-config removed; seqs 16; + profiler | DEV_MODE | [1,2,3,4,6,8,12,16] |
| CTRL (optional) | none | none | shipped |

Windows: A 40k@5, 40k@8, 8k@8; B/C/K0 the same + 8k@12, 8k@16; CTRL 8k@8.

Design: RC2 builder text executed up to its notebook writer → RC2's cell strings verbatim, then cut()/once() edits
(NB2_* env renames; `merlin_fn_server(cfg)`: env merged before build(), trailing extras, K0 argv edit, exact diff;
`merlin_boot` + `boot_gate_nb2` + cfg). Reference: RC2 FP8 greedy oracle rows (embedded from requests.jsonl, installed only
if the 4 prompt hashes match); boot A's rows are the in-session reference for B/C/K0/CTRL. Gating: A must be DONE/CLEAN or
B/C are SKIPPED_DEPENDENCY; B failing to launch at seqs 16 without an OOM line → retried at seqs 8; OOM → RC2's KV −0.25 GiB
retry; config read-back mismatch → NO_GO_CONFIG_READBACK; ready gate 30 min; watchdogs A 65 / B,C 55 / K0 40 / CTRL 25 min;
global budget 265 min. Before every boot: GPU < 150 MiB, posix_fadvise DONTNEED on every resolved checkpoint file, host gate
Merlin floor + 4 GiB (if neither cgroup nor meminfo is readable the gate is "ok None" and does not block — a deviation).
12/16 streams only if the read-back max-num-seqs ≥ level and the pre-run capacity plan fits (F = 6 baseline); a level
predicted > 1.05 × pool is skipped. F census: kv_cache_usage deltas over an idle baseline (4 requests at 2 blocks, 4 at 6),
with `/reset_prefix_cache` (dev mode). Per-position acceptance: `L.prom` wrapped at runtime, labelled counter deltas.
Per window: running vs level, prefill finished, tick_ms, cycle_ms = 2 × tick, completed micro-batch rate, wall-clock tok/s,
a = tokens_per_step × 2 / C, a / (1 + K), tokens/step vs (C/2) × MAL, graph size the micro-batch pads into, TTFT, phase
label. Step model reproduces RC2: 25.61 + 5.79 r (R² 0.988). Decay: frozen cohort replay (5 prompts, fixed seeds, 1,536
tokens) at start / after the ladder / after the long window + a 20-min natural series per 10-min sub-window (valid if mean
running ≥ level − 0.5; INCONCLUSIVE on the fake). Warm-up until no new JIT. Trace window last (4 rank traces aligned via
baseTimeNanoseconds; PP2 overlap, per-stage idle, verify rows, graph modes, A7 classifier fix). Scorecard rewritten after
every boot (D2, D1 K2/K1/K0, D3; gain 0.9 × (arm − base) at matched windows; long-trace projection vs a = 2.72; diagnostic
until NB0 passes).

Open questions: 4.4-h notebook; profiler/dev-mode perturbation unproven; K3 at 12/16 not covered; B/C with BF16 head if A
fails?; NB0 prompt alignment (done: NB0 uses RC2 prompt(band, 5)); torch trace layout untested on real Merlin traces;
kv_cache_usage timing and /reset_prefix_cache under retention; draft KV dtype as a candidate lever.
