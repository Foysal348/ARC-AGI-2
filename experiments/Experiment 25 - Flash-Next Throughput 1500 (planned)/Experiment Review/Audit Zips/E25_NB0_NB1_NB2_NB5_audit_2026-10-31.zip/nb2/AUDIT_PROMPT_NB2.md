# Audit request: E25 NB2 "Decode / MTP" (Qwen3.8-Flash-Next, Kaggle 4×L4, Merlin = vLLM 0.32.0 fork)

You are a senior inference-engine reviewer. Read every file fully. Report findings ranked HIGH / MED / LOW, each with
file + line, the concrete failure scenario on the real Kaggle GPU run, and the fix. Verify every claim against the code
before reporting it. Finish with GO / NO-GO for (a) a 35-min GPU SMOKE and (b) the full run (both need the user's go).

## What NB2 is
A GPU notebook that boots the Merlin Flash-Next server several times (TP2×PP2+EP, FP8 KV, block 4096, align mamba cache,
prefix caching, PP partition 25/23) to measure decode speed vs MTP depth and draft-head precision on real xhigh ARC prompts:
- Boot A: MTP K3 + `DRAFT_HEAD=int8`; Boot B: K2 + int8 + `--max-num-seqs 16`; Boot C: K1 + int8 + seqs 16; optional K0
  (no speculation) and CTRL (exact RC2 config). K changes through trailing `--speculative-config` (last argument wins).
- Per boot: probes, sampled check, greedy oracle vs RC2's FP8 rows (embedded, hash-matched), F census (fixed blocks per
  request) from kv_cache_usage deltas, steady windows (40k@5, 40k@8, 8k@8, and 8k@12/16 where seqs allow), per-position
  acceptance from metric deltas, tick / cycle / completed-micro-batch / wall-clock rates, a frozen-cohort decay replay and a
  20-min long natural window, a profiler trace window last (PP2 overlap, per-stage idle, verify rows, graph modes).
- `lever_scorecard.json` rows D2 / D1 (K2, K1, K0) / D3, every row "diagnostic until NB0's FP8 gate passes".
- Decisions already taken (to be applied in the next revision, see `docs/PENDING_BATCH_FIXES.md`): trim to ~3 h (long
  window only in A, K0 and CTRL off by default, A/B/C all at seqs 16 with the same capture list, BF16 head fallback if A
  fails because of the INT8 head) and a 35-min SMOKE profile (boot B only) before the full run.

## Files
- `notebook/Q27-XHIGH-E25_NB2_DECODE.ipynb` (sha c654f68e…, 253,695 B).
- `build/build_e25_nb2.py` (builder; reuses the Kaggle-proven RC2 builder via cut()/once()), `build/nb2_unit_tests.py`,
  `build/nb2_fake_server.py`, `build/nb2_e2e_check.py`, `build/nb2_code_export.py` (all cells in one file).
- `tests/nb2_unit_tests_78_PASS.txt` (fresh local rerun) and `tests/NB2_BUILD_REPORT.md` (the builder's report incl. the
  82/82 fake end-to-end result).
- `rc2_context/E13_RC2_GPU_v1_2026-10-31.md` (the real 4×L4 run), `rc2_context/build_e13_rc2.py`, `rc2_context/e23_lab.py`.
- `merlin/launch.py`, `merlin/flash-next.json`, `merlin/registry.py` (Merlin launcher + profiles).
- `docs/PLAN_1500.md` (v3.6, §1.1 throughput model, §4.1 selection rule), `docs/NB_BUILD_SPEC_2026-10-31.md`,
  `docs/PENDING_BATCH_FIXES.md`.

## Questions
1. Will every boot's argv be accepted by Merlin/vLLM 0.32 (trailing `--speculative-config` K2/K1 with
   `draft_lm_head_quant`, `--max-num-seqs 16`, extended `--compilation-config` capture list, `--profiler-config`,
   `VLLM_SERVER_DEV_MODE=1`, K0 by removing speculation)? Is the config read-back from the server log sound?
2. Are the measurements valid: F census from kv_cache_usage deltas (Merlin retains finished sessions), per-position
   acceptance deltas, tokens_per_step vs (C/2)·MAL under PP2, tick vs cycle, a = tokens_per_step·2/C?
3. Correctness: is the greedy oracle vs RC2 FP8 rows a fair reference at T 0 across K/head changes? Fail-closed gates?
4. Does any path let a failed / partial boot produce a positive scorecard row or a misleading PASS?
5. Host memory and boot hygiene (page-cache drop, Merlin RAM floor, GPU < 150 MiB, watchdogs, 30-min ready gate).
6. Budget: does the plan fit, and is the planned trim + SMOKE the right way to minimise GPU cost?
7. Anything else that would waste the GPU session or produce misleading numbers.
