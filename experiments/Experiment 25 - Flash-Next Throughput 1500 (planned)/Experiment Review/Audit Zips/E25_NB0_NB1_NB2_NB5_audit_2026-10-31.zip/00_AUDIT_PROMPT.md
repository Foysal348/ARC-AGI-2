# Audit request: E25 notebooks NB0, NB1, NB2, NB5 (Qwen3.8-Flash-Next on Kaggle 4×L4, Merlin = vLLM 0.32.0 fork)

Read `README.md` first (what each notebook does), then audit each notebook folder with its own `AUDIT_PROMPT_NBx.md`.
For every notebook: read every file fully, verify each claim against the code before reporting it, rank findings
HIGH / MED / LOW with file + line, the concrete failure on the real Kaggle GPU run, and the fix; finish each notebook with
GO / NO-GO for its GPU run (GPU runs need the user's separate approval). Shared context is in `shared_context/`.
Also check cross-notebook consistency: NB0's FP8 verdict, NB1's pool / F / pin and NB2's K / draft head must flow into
NB5's CELL 1 defaults; prompts must match RC2's prompt builder; every notebook must fail closed.
