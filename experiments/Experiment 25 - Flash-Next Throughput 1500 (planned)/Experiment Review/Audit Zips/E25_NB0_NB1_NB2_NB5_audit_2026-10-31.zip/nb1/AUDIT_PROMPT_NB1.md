# Audit request: E25 NB1 "Capacity" (Qwen3.8-Flash-Next, Kaggle 4×L4, Merlin = vLLM 0.32.0 fork)

You are a senior inference-engine reviewer. Read every file fully. Verify every claim against the code before reporting
it. Report findings ranked HIGH / MED / LOW with file + line, the concrete failure scenario on the real Kaggle GPU run, and
the fix. Finish with GO / NO-GO for the GPU run (it needs the user's separate approval).

## What NB1 is (~240-min budget, 3 cold boots, capacity only)
Goal: more resident streams with no correctness change. The FP8 quality question was moved to NB0; every NB1 FP8 number
says "production use depends on NB0's gate". Boots are cumulative and fail closed (patch → B1 → B2 → B3):
- **#60490 backport** (vLLM PR 60490, QSA indexer workspace in the profiling run) rebased onto Merlin commit ad42e37 and
  applied after the offline install by a strict applier (pre-sha `a23d5f90…`, post-sha `88fe0a8f…`, marker, py_compile);
  files in `build/patches/`. Any miss stops every boot.
- **B1:** RC2 FP8 + `--language-model-only` + the patch + `--profiler-config` + a read-only worker extension
  (`--worker-extension-cls nb1_worker_ext.NB1WorkerExt`), dev mode, NCCL debug (this boot only). Measures C4 (text-only)
  vs D9 (#60490) separately from per-rank weight-load and free-VRAM lines; cold-cache allocation census (reset, then
  1/2/4/8 distinct 8k prompts, 1/2/4 at 40k) → pool P, fixed blocks F, running vs retained blocks; `max_safe_running_by_context`
  at 8k/40k/60k/90k/116k; a fresh 90k×5 admission probe; steady windows (start only after every stream's first token);
  per-window tick / cycle (= 2 ticks) / micro-batch rate / wall-clock tok/s, TTFT, uncached prefill, per-position acceptance;
  a PP2 profiler trace (per-stage critical path vs summed kernel time, overlap, idle, graph vs eager launches, graph memory);
  router top-k ids saved in NB3's schema (`nb1_routing_ids.npz`).
- **B2:** B1 + `--mamba-ssm-cache-dtype bfloat16` + `--max-num-seqs 16` + captures to 64 + `MERLIN_SHARE_DRAFT_WORKSPACE=1`
  + `VLLM_RECOVERSSM_COMMIT_GRAPH=graph` (A/B/C eager/staged/graph flipped at runtime; standard windows run eager).
- **B3:** KV pin ladder (+1.0 / +0.75 / +0.5 GiB, starting at the largest step predicted to keep ≥ 0.5 GiB free per rank,
  stepping down on OOM); on B2's config, or on B1's if B2 was not clean.
- Gate reference: RC2's recorded FP8 greedy oracle rows (embedded; used only if the prompt shas match); B2/B3 vs B1.
- Host hygiene before every boot (leftover processes killed, own psm_/loky unlinked, page-cache drop, Merlin's 73 GiB rule,
  GPU < 150 MiB), per-worker majflt/IO sampling during load, 30-min ready gate, per-boot watchdog, 240-min hard stop.
- `lever_scorecard.json` (10 rows) rewritten after every boot.

## Files
- `notebook/Q27-XHIGH-E25_NB1_CAPACITY.ipynb` (sha 3c913b68…, 330,114 B).
- `build/build_e25_nb1.py`, `build/nb1_unit_tests.py`, `build/nb1_local_e2e.py`, `build/nb1_fake_server.py`,
  `build/nb1_code_export.py` (all cells in one file), `build/patches/` (rebased patch + upstream diff).
- `tests/nb1_unit_tests_88_PASS.txt` (fresh local rerun; the e2e harness gave 42/42 on main/e23fake/patchfail/b1fail/rerun).
- `rc2_context/` (RC2 GPU analysis, RC2 builder, e23_lab.py), `merlin/` (launch.py, flash-next.json, registry.py),
  `docs/` (PLAN_1500 v3.6, spec, PENDING_BATCH_FIXES, the NB3 CPU kit results).

## Questions
1. Is the #60490 rebase correct and safe (same semantics as upstream; nothing else in qsa.py changes)? Does the applier fail
   closed in every bad case?
2. Will every boot's argv be accepted (`--language-model-only` with the image flag, `--worker-extension-cls`, SSM bf16 with
   the fused GDN path, seqs 16 + captures to 64, commit-graph modes via dev-mode `/collective_rpc`)? Read-back sound?
3. Are the capacity measurements valid (P and F from usage deltas given Merlin's session retention; residency table;
   90k×5 probe; C4 vs D9 attribution; pin ladder safety vs #60490's lazy workspace)?
4. Profiler: does the trace analysis separate critical path from summed kernel time correctly; does the profiler window
   contaminate any benchmark window?
5. Can a failed / partial boot produce a positive scorecard row or a misleading PASS?
6. Budget and hygiene: will 3 cold boots + measurements fit 240 min; are the host/GPU gates and watchdogs fail-closed?
7. Anything else that would waste the GPU session or produce misleading numbers.
