# Pending batch of fixes (applied ONCE, after the GPT audits arrive; user 2026-10-31)

## Decisions taken by the lead on the user's "choose the better option" (2026-10-31)
1. **NB2 trim (4.4 h → ~3 h):** the 20-min long natural window only in boot A; K0 and CTRL off by default (RC2 is the
   control); boots A, B and C all at `--max-num-seqs 16` with the same extended capture list, so A/B/C differ only in K
   (this also gives K3 at 8k@12/16 without an extra "A16" boot); if A fails because of the INT8 head, B and C run with
   the BF16 head instead of being skipped.
   **NB2 SMOKE (user-delegated decision, applies to NB2 only):** a `SMOKE` profile, 35-min hard stop: boot B (K2 + seqs 16
   + INT8 head + profiler, the riskiest config) with probes, one 90-s 8k@8 window, one 8k@16 admission check and the trace
   window; the trimmed full NB2 runs only after it passes.
   **User rule (2026-10-31): a GPU smoke only for big runs, ≥ 3-4 h.** So: NB2 (trimmed ≈ 3 h, user asked for it) and
   NB5 EVAL120 (~6 h+) get a smoke; NB0 (~1.5-2 h), NB1 (~2-2.5 h) and NB3 (~1 h) run directly, relying on their fail-fast
   gates. The NB1 smoke proposal below is withdrawn.
2. **PROPOSALS ONLY (not approved by the user; the user's instruction covered NB2 only) — GPU smoke policy:**
   - NB3 and NB0: no separate smoke (short notebooks, fail-fast; the first boot/bench is the smoke).
   - NB1 and NB2: add a `SMOKE` profile with a 35-min hard stop that boots only the riskiest configuration (NB1: boot 1
     with #60490 + text-only; NB2: boot B with K2 + seqs 16 + INT8 head + profiler) and runs probes, one 90-s window and
     the trace window, so new flags, parsers and trace analysis are proven before the long runs.
   - NB5: add a `SMOKE` profile (~60 min, real tasks, early exit) for the GPU-only gates (variant C, /tokenize parity,
     parser, prefix reuse), run before any NB5 EVAL.
3. **PROPOSAL — Wave plan:** wave 1 = NB0 full + NB3 full + NB1-SMOKE + NB2-SMOKE across the 3 accounts; wave 2 = NB1 full + NB2
   full + NB5-SMOKE; wave 3 = NB5 EVAL30 with NB0/NB1/NB2 values baked in.
4. **Structural track (C6 / drafter / layout):** CPU-only feasibility research starts now (no GPU).

## NB3 — GPT audit 1 (deep code audit), items verified against the code by the lead (2026-10-31)
| # | Sev | Claim | Evidence in our code | Verdict | Fix |
|---|---|---|---|---|---|
| N3-1 | HIGH | ncu DRAM bytes split by kernel position (first 2/3 = split) | `nb3_common.py:205-215` `ncu_split_bytes`: `rows[:2*n//3]` vs `rows[2*n//3:]`, only checks `n % 3`; docstring assumes equal kernels per call. `moe_align_block_size` and Marlin paths can launch a different number of kernels at T/2 vs T | CONFIRMED | profile split and combined in separate ncu child runs (`--ncu-mode split|combined`), sum all rows per run; nonzero ncu exit / no rows / `ERR_NVGPUCTRPERM` → `DRAM_BYTES_UNVERIFIED`; regression test with unequal kernel counts (1+2 vs 3) |
| N3-2 | HIGH | NB4 ranking ignores the bench family status | `build_e25_nb3.py:348-351` `nb3_report()` calls `C.rank_candidates(TABLES)` without the status dict `st` (only `scorecard` gets it); `finish()` stores `TABLES[tkey]` for any status (TIMEOUT / BENCH_ERROR / CHECK_FAILED included); `rank_candidates` (`nb3_common.py:726-747`) ranks on per-candidate `correctness` only | CONFIRMED | rank only families with status DONE and zero failed checks; other families' rows → `DIAGNOSTIC_ONLY` / `PARTIAL_DIAGNOSTIC`; regression: one PASS candidate then rc 1 → 0 adoptable winners for that family |
| N3-3 | MED | MoE reference gate permissive; "1-2 bf16 ulp" claim not a ULP check | `nb3_moe_bench.py:45` `REF_GATE = {rel_fro 2e-2, cos 0.999}`; `nb3_common.py:161` `EQUIV_TOL = {rel_fro 8e-3, max_abs_over_ref_max 1.6e-2}` commented "~1-2 bf16 ulps" | CONFIRMED (wording + strength) | add max_abs / p99_abs / finite / bitwise per comparison; baseline-vs-tuned elementwise; an adversarial routing case (few local experts, repeated ids); either a real ULP check or drop the "ulp" wording |
| N3-4 | MED | measured vs derived bytes must not mix | `nb3_moe_bench.py:392` already sets `bytes_source` = ncu or "DERIVED" | PARTLY DONE | make sure every GB/s column derived from DERIVED bytes is named `derived_gbps`, never in a "measured bandwidth" column |
| N3-5 | MED | LL128 must read UNTESTED | `nb3_common.py:846`, `build_e25_nb3.py:12,120,440` say "dropped" | CONFIRMED (wording) | report and scorecard: `LL128: UNTESTED (not run, NCCL docs corruption risk)` |
| N3-6 | MED | engine-confirmed column missing; kernel savings not additive under PP2 overlap | no `engine_confirmed_saved_ms` in `nb3_common.py`; projections labelled MICROBENCH_PROJECTED (`:556, :729, :795`) | CONFIRMED | add `microbench_saved_ms` + `engine_confirmed_saved_ms: null` columns; note "not additive under PP2 overlap" |
| N3-7 | MED | first-call gate before the full T sweep | no T=1 / T=4 first-call gate in `nb3_moe_bench.py` (sweep starts directly) | CONFIRMED | load + prepare + T=1 and T=4 output + reference check first; fail → skip the sweep (saves GPU) |
| N3-8 | LOW-MED | EP rank 1 spot-check | `--ep-rank` exists (`nb3_moe_bench.py:513`, default 0), never run with 1 | CONFIRMED | one small T set at `--ep-rank 1` (layer-0 experts 256-511 are in the same file) |
| N3-9 | — | GEMM plan / P5 adoption only after full-engine A/B (2×) + 40k/90k correctness; P5 1000+ replays + both-pair contention before integration | policy, not code | ACCEPTED as NB4 rule | add to PLAN §4.1 |
| N3-10 | — | tests not reproducible from the bundle (Windows paths) | true for the bundle | NOTED | the Kaggle K3 kit runs them on Linux (`q27-e25-nb3-kit-units`) |

## NB3 — GPT audit 2, items verified against the code by the lead (2026-10-31)
| # | Sev | Claim | Evidence in our code | Verdict | Fix |
|---|---|---|---|---|---|
| N3-11 | HIGH | INT8 P5 `PASS_BOUND_ONLY` is ranked as a winner | `nb3_common.py:677-679` sets `corr = "PASS_BOUND_ONLY"`; `rank_candidates` (`:735-737`) admits `str(correctness).startswith("PASS")` | CONFIRMED | `promotion_ready = correctness == "PASS"` in ranking AND scorecard; PASS_BOUND_ONLY = diagnostic only |
| N3-2 (dup) | HIGH | failed bench still ranked / scored | as N3-2; `scorecard(tables, status)` (`:803-807`) receives status but GPT's fault injection shows positive scores with CHECK_FAILED | CONFIRMED (same fix as N3-2, applied to scorecard too) | gate: bench status DONE, result status DONE, exit 0, every check True → else score 0 and `BLOCKED_BENCH_FAILURE` |
| N3-12 | HIGH | eager latency reported as graph latency when capture fails | `tm.get("graph_us") or tm.get("eager_us")` at `nb3_moe_bench.py:322, 325, 329, 365, 409, 423, 482` and `nb3_gemm_bench.py:147, 186, 269, 287` | CONFIRMED | keep `eager_us` and `graph_us` separate; `graph_status` PASS / INCONCLUSIVE_CAPTURE_FAILED + `graph_error`; no graph winner from eager numbers |
| N3-13 | HIGH | SHA gate guards D5 only | `build_e25_nb3.py:446-447` (D5 only) ; steps at `:630-636` run D7 build / pairs / solo and D4 after a `SHA_GATE_FAILED` | CONFIRMED | one `require_sha()` before every GPU bench (D5, D7 build/pairs/solo, D4); on failure set ABORT and record evidence |
| N3-14 | HIGH | D7 PASS with one pair's evidence missing | `ar_numeric` (`nb3_common.py:422-437`) verdicts only the keys found; `arm_ok` (`:654-658`) iterates whatever pairs exist | CONFIRMED | require both pairs × rank 0/1 × mandatory checks; else `INCONCLUSIVE_MISSING_PAIR` / `_MISSING_RANK` |
| N3-15 | HIGH | dequant crosscheck mismatch does not stop D5 | `nb3_moe_bench.py:253-256` records `checks["dequant_crosscheck"]` and continues to the Marlin conversion and the sweep | CONFIRMED | save + raise `INT4_LAYOUT_OR_SCALE_MISMATCH` before any GPU sweep; also gate the extra outputs of `_process_weights_marlin` |
| N3-16 | MED (budget) | D5 scope may exhaust its 1,080 s before tuning | budget `NB3_D5_SEC` 1080 (`build_e25_nb3.py:238`); 21 T × 4 routing modes + split + replay + ncu + 52-rule sweep | PLAUSIBLE (no L4 timing yet) | priority order: T16 (uniform + replay) incl. oracle + tuning sweep, saved; then T4/T8; then T32/T64 (+Zipf); then hot/request; then the rest; ncu last; `PARTIAL_BUDGET` keeps valid rows |
| N3-3 (dup) | MED | no real ULP gate in split equivalence | as N3-3 (`nb3_common.py:161-183`) | CONFIRMED | elementwise BF16 ULP distance (or nextafter envelope); test: one element 4 ULP off → FAIL |
| N3-17 | MED | pair overlap measured over the whole group, not the timed region | `nb3_common.py:469-475` uses group `t0`/`t1` of `main_ab` | CONFIRMED | per-size timed-region monotonic timestamps per pair; overlap below threshold → `CONCURRENCY_UNVERIFIED` |
| N3-18 | — | new CPU regression tests (9 listed by the audit) | — | ACCEPTED | add all 9: PASS_BOUND_ONLY not ranked; CHECK_FAILED → 0 score; graph error → no graph winner; SHA mismatch/timeout → no GPU subprocess; one pair only → INCONCLUSIVE; corrupted scale → stop before sweep; 4-ULP error → FAIL; truncated D5 budget → T16 persisted; missing SM89 CuTe → D4 diagnostics only |
| N3-19 | — | run order and failure policy | — | ACCEPTED | SHA → D5 minimal (T16/T4/T8) → D7 → D4 → D5 rest; `UNSUPPORTED_SM89` lets other arms run; illegal memory access / Xid / leftover VRAM stops the notebook |

## NB3 — GPT audit 3, new items verified against the code by the lead (2026-10-31)
(Its findings on failed-bench ranking, PASS_BOUND_ONLY, missing rank 1, ncu slicing and graph/eager mislabelling are the
same as N3-2, N3-11, N3-14, N3-1 and N3-12; its regression cases are added to those fixes.)
| # | Sev | Claim | Evidence in our code | Verdict | Fix |
|---|---|---|---|---|---|
| N3-20 | HIGH | missing ncu DRAM metrics count as 0 bytes with ok=True | `nb3_common.py:213-214` `sum(r.get(m, 0.0) ...)` | CONFIRMED (adds to N3-1) | per-arm aggregation; a missing / non-finite / negative metric → ok False `MISSING_OR_BAD_<metric>`; tests 2+2+5, 3+3+4, missing metrics, permission error, separated arms |
| N3-21 | HIGH | D4 plan PASS when the dispatch test is missing | `nb3_common.py:697` `dispatch_ok in (True, None)` | CONFIRMED | `dispatch_ok is True` required; None → `UNTESTED_DISPATCH`, False → `FAIL_DISPATCH`; tests for all three |
| N3-22 | HIGH | tuning-sweep budget stop not propagated; parent marks DONE on rc 0 alone | `nb3_moe_bench.py:469` sets `sw["budget_stop"]` only; `:540` status reads `res["budget_stop"]`; `build_e25_nb3.py` `finish()` sets DONE from `rc == 0` without reading the file's status | CONFIRMED | set `res["budget_stop"]` too; `verified_bench_status()` in `finish()` from rc, timeout, GPU release, file status, exit_code and all checks True; fake-clock test → PARTIAL_BUDGET and candidates blocked |
| N3-23 | HIGH | Merlin plan failure silently falls back to a minimal env | `build_e25_nb3.py:410-417` `except Exception` → "MINIMAL env" and continues | CONFIRMED | GPU run: fail closed (RuntimeError, benches skipped); the minimal env is allowed only in the CPU kit (`NB3_CPU_KIT=1`) and labelled `EXPLORATORY_ENV`; tests: missing scales, failed host_phase, broken paths, good plan |
| N3-24 | MED | private Merlin symbol `_unpack_and_dequant_int4_gptq` (positional signature) | `nb3_moe_bench.py:184` imports it via `need(...)` | CONFIRMED as a risk | dependency preflight: symbol present + `inspect.signature` recorded + tiny known INT4 parity before the sweep (the K2 kit's R3 import check also records it) |
| N3-25 | — | integration fault-injection test | — | ACCEPTED | one fake run injecting D5 BENCH_ERROR, D7 TIMEOUT, D4 CHECK_FAILED, a graph capture error, missing rank 1 and missing dispatch together → nb4_top empty, D5/D7/D4 BLOCKED, PP2 DIAGNOSTIC_ONLY, invalid gains 0, fallback valid; plus the positive all-valid case still ranks winners |

## Items already agreed and waiting for the batch
- NB2 open items from its report: confirm `--profiler-config` / DEV_MODE recorded in diffs (kept).
- The GPT audits of NB3 (bundle `_scratch/E25_NB3_audit_bundle_2026-10-31.zip`) — to be validated item by item.
- NB3 CPU kit results (3 kernels) — fixes from it.
