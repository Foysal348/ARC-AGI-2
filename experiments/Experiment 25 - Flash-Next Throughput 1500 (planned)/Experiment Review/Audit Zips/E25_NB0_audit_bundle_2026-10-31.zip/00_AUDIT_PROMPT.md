# Audit request: E25 NB0 "FP8 quality isolation" (Qwen3.8-Flash-Next, Kaggle 4×L4, Merlin = vLLM 0.32.0 fork)

You are a senior inference-engine / numerics reviewer. Read every file fully. Verify every claim against the code before
reporting it. Report findings ranked HIGH / MED / LOW with file + line, the concrete failure scenario on the real Kaggle GPU
run, and the fix. Finish with GO / NO-GO for the GPU run (it needs the user's separate approval).

## Why NB0 exists
RC2 (real 4×L4 run, `rc2_context/E13_RC2_GPU_v1_2026-10-31.md`) measured teacher-forced last-256-position logprobs at 40k:
FP8 KV vs BF16 KV mean |Δ| 1.876, p99 5.46, rank-1 agreement 0.367, while the BF16 A/A was exactly 0; the one long FP8
answer (task 0934a4d8) was wrong (15/27 cells). FP8 doubles the KV pool, so NB0 must establish whether the divergence is
real and where it comes from before FP8 is used.

## What NB0 does (~57 min of a 100-min budget; five boots, order D → C → E → B → A, prefix caching on everywhere)
| Boot | KV | MTP | Note |
|---|---|---|---|
| D | FP8 | K3 | = RC2 FP8 |
| C | BF16 | K3 | = RC2 BF16 |
| E | FP8 | K3 | FP8 read through Merlin's sm_86-qualified Triton byte decoder `_decode_e4m3_to_bf16` instead of the sm_89 native cast (`ops/qsa.py:28-36` `qsa_e4m3_uses_native_cast`); env-gated source patch of the installed tree with sha/anchor checks, `qsa.py:231` validation patched, restored and re-verified afterwards; an on-GPU bit-exact check of all 256 E4M3 codes first |
| B | FP8 | off | `--speculative-config` removed (Merlin CHANGELOG: "the no-MTP line is the same command without --speculative-config") |
| A | BF16 | off | differs from B only in KV dtype |
Per boot: probes / sampled / 4-row greedy oracle and a server-log config read-back; teacher-forced 2k/8k/40k/90k with RC2's
exact prompts (`PROMPTS[band][5]`, 40k = RC2's TF_P), fresh + repeat; decode-vs-prompt-logprob self-consistency, cold-vs-
cached decode, ±2 shift, chunk-boundary localisation; raw per-position arrays (85 npz per run). Pair comparisons A–B, C–D,
A–C, B–D, C–E, D–E; decision table; screening gate (HOLD if rank-1 < 0.90 or mean > 0.15), triage gate (NO_GO if mean > 1.0
or rank-1 < 0.5, else PENDING_LONG_ARC_ACCURACY), never GO. Host hygiene + load monitor + per-boot watchdog.

## Files
`notebook/` (sha 074a0f53…, 260,295 B), `build/` (builder, unit tests, fake server, local e2e, all cells in one file),
`tests/` (121/121 unit log; e2e logs incl. a fresh rerun of native/kv_long/mtp/path after a fake-server fix, all PASS),
`rc2_context/`, `merlin/`, `docs/`.

## Questions
1. Is the boot-E patch semantically exactly Merlin's sm_86 path on sm_89 (every call site, the validation, the fused
   prepare at `qsa.py:710`, the indexer)? Is the device check meaningful? Is restore safe?
2. Is removing `--speculative-config` a valid MTP-off on Merlin's PP2 V2 runner (RecoverSSM/ReplaySSM off)? Config check?
3. Are the teacher-forced comparisons valid (prompt ids, `prompt_logprobs=5`, prompt_logprobs skipping the prefix cache,
   alignment, the last-256 headline vs full arrays), and does the decision table attribute causes correctly?
4. Can any path produce a misleading PASS / GO, or hide a NaN / missing band?
5. Budget, 90k prompt-logprob response size, hygiene, fail-closed order and skip rules.
6. Anything else that would waste the GPU session or produce misleading numbers.
