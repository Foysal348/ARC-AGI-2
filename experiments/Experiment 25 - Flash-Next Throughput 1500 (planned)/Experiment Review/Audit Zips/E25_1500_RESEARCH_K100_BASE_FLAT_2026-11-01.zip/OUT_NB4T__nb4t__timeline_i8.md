clock: SHARED_CLOCK (measured offsets us: {'0': 0.0, '1': -2.5, '2': -0.5, '3': -2.8})

NB1 reproduction (critical path / GPU-busy union / summed kernels, ms per micro-batch):
  stage0 (rank 0, 16 verify tokens, n=40): 40.746 / 39.5 / 42.115
  stage1 (rank 2, 16 verify tokens, n=40): 24.732 / 23.883 / 26.427

steady ticks 36 of 39; tick ms mean 39.024 median 39.137; graph modes {'FULL': 36}

| category | stage0 ms (mean) | stage1 ms (mean) | stage0 % of tick | stage1 % of tick |
|---|---|---|---|---|
| compute | 23.359 | 31.246 | 59.9 | 80.1 |
| copy | 0.111 | 0.048 | 0.3 | 0.1 |
| in_graph_stall | 0.322 | 0.422 | 0.8 | 1.1 |
| nccl_peer_wait | 8.327 | 0.021 | 21.3 | 0.1 |
| nccl_tp_skew | 0.996 | 0.907 | 2.6 | 2.3 |
| nccl_transfer | 5.412 | 5.788 | 13.9 | 14.8 |
| host_launch_gap | 0.346 | 0.012 | 0.9 | 0.0 |
| host_python_gap | 0.131 | 0.005 | 0.3 | 0.0 |
| idle_no_host | 0.02 | 0.575 | 0.1 | 1.5 |
| (in_graph_stall_peer_computing, side measure) | 0.282 | 0.262 | | |
| (in_graph_stall_pp_nccl_running, side measure) | 0.0 | 0.0 | | |
| (nccl_transfer_pp, side measure) | 2.783 | 0.034 | | |
| (nccl_transfer_tp, side measure) | 2.629 | 5.755 | | |
| (nccl_transfer_peer_in_nccl, side measure) | 2.958 | 3.051 | | |
| (nccl_transfer_peer_host, side measure) | 0.786 | 0.351 | | |
| (nccl_transfer_peer_idle, side measure) | 1.668 | 2.386 | | |
| (gap = tick - compute - copy) | 15.554 | 7.73 | | |

pipeline per tick (ms): {'stage0_only_ms': 3.264, 'other_stage_only_ms': 11.164, 'both_busy_ms': 21.392, 'neither_ms': 3.204}; stage-1 idle 7.73 ms
critical path per tick (ms): {'tick_ms': 39.024, 'forward_kernel_wall_ms': 39.019, 'forward_kernel_union_ms': 38.147, 'forward_kernel_sum_ms': 40.765, 'ideal_overlapped_tick_ms': 31.294, 'serialization_ms': 7.73}
stalls: {'ticks_with_stall_over_1ms': 0, 'steady_ticks': 36, 'in_graph_stall_ms_mean': 0.32, 'released_by': {}, 'release_lag_us_median': None, 'release_lag_us_p90': None}
ideal tick: {'per_stage_busy_ms': {'stage0': 23.47, 'stage1': 31.294}, 'observed_tick_ms': 39.024, 'balanced_parity_ideal_ms': 31.294, 'bound_by': 'stage1 work', 'chain_bound_ms': 27.382, 'chain_bound_with_observed_bubble_ms': 30.586, 'rebalanced_stages_ms': 27.382, 'one_parity_serial_tick_ms': 57.968, 'gain_vs_observed_pct': 24.7, 'note': "rebalanced_stages = equal per-stage work (layer split / where the MTP draft and lm-head run); one_parity_serial = every step's work on both stages back to back (no overlap), with this run's per-step work; with all requests in one parity a step carries more requests, so its work is larger than measured here"}
micro-batch parity: BALANCED_4+4; n per parity: {'stage0': {'0': {'4': 20}, '1': {'4': 20}}, 'stage1': {'0': {'4': 20}, '1': {'4': 20}}}; stage step match {'compared': 40, 'matched': 0, 'meaning': 'the stage-1 step with the same index sends exactly the broadcast Seqs this stage-0 step receives (same micro-batch)'}
dependency: NO_STALL {}; step delta {}; real input ready before graph start (ms, median / min) None / None
graph mode (rev 2 rule): {'0': {'FULL': 40}, '1': {'FULL': 40}, '2': {'FULL': 40}, '3': {'FULL': 40}}; NB1 lab rule: {'0': 'PIECEWISE', '1': 'PIECEWISE', '2': 'PIECEWISE', '3': 'PIECEWISE'}