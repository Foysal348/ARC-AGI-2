# E25 NB4S stall test: GPU run v1 (rev 3, sha fa9f35ca, foysalemonshanto, 2026-11-01)

- **Output:** `_scratch/e25_gpu_out/q27-xhigh-e25-nb4s-stall/nb4s/` (`nb4s_results.json`, `nb4s_verdict.json`, `stall_*.json`, `timeline_*.md`, traces).
- **Config:** Merlin v3.0.0, W4, FP8 KV, MTP K3, pin 3,553,580,524, #60490 applied, 8 streams.
- **Arm status:** all four arms DONE. Every oracle vs B is EXACT; every quality gate PASS; env read-back OK on all 4 workers.

## Notebook verdict
`INCONCLUSIVE_BASE_IMBALANCED` for every arm.

- **Cause:** the base-parity gate added in rev 3 (from a GPT audit) rejected B, because B's profiled window split its micro-batches 7 / 1 instead of 4 / 4.
- **Every arm was imbalanced too:**

  | Arm | Split |
  |---|---|
  | B | 7 / 1 |
  | S | 6 / 2 |
  | QP | 3 / 5 |
  | QD | 7 / 1 (the same as B) |

- **The raw data is complete and comparable,** so it is read directly below. The gate itself was too strict: it refuses a comparison that is like for like.

## Speed (8k@8 steady windows, running == level, 0 preemptions; tok/s)
| arm | 8k@8 #1 | 8k@8 #2 | mean | vs B | tick ms | 40k@8 | vs B | acceptance length |
|---|---|---|---|---|---|---|---|---|
| B (base) | 256.6 | 254.0 | 255.3 | — | 48.2 | 248.0 | — | 3.07-3.12 |
| S (`CUDA_DEVICE_MAX_CONNECTIONS=32`) | 278.9 | 291.0 | 285.0 | **+11.6 %** | 42.9-44.9 | 281.3 | +13.4 % | 3.12-3.13 |
| QP (packed PP broadcast) | 301.9 | 301.5 | 301.7 | **+18.2 %** | 41.4-41.8 | 294.3 | +18.7 % | 3.11-3.15 |
| **QD (deferred PP receive)** | 305.7 | 312.5 | **309.1** | **+21.1 %** | 40.9-41.0 | **297.1** | **+19.8 %** | 3.12-3.20 |

B's own window-to-window spread is 1.0 %.

## Stall (stage-0 FULL decode graphs, profiled window, 76 graphs per arm)
| arm | stall median ms | share of graphs < 1 ms | stall node | released by |
|---|---|---|---|---|
| B | **19.81** | 0 % | #172 | `Broadcast Intx14 pp_broadcast` |
| S | 10.84 | 39.5 % | #664 | `Broadcast Intx12 pp_broadcast` (reduced and moved) |
| QP | **0.037** | **100 %** | — | — (fixed) |
| QD | **0.035** | **100 %** | — | — (fixed) |

**Stage-1 SendRecv wait per tick:** B 8.21 ms, S 0.09, QP 0.07, QD 3.52.

## Q-defer engagement (rev 2 R1 rule)
`ENGAGED` on both non-last ranks:
- defer_park 9,307;
- flush_exec 8,983 (exec share 0.965);
- flush_empty 322;
- flush_recv / flush_consume 0;
- flush_rpc 2 (F2 worked at the profiler RPCs);
- fallback share 0.

QP engaged on all 4 ranks: packed_send 9,236 on each last rank, and packed_recv 9,236 on each non-last rank.

## QD timeline (`timeline_qd.md`)
- **Ticks:** 36 steady, 0 ticks with a stall over 1 ms; tick mean 44.07 ms in the 7 / 1 profiled window.
- **Compute per stage:** stage 0 21.6 ms, stage 1 33.0 ms. **Stage 1 now binds** (ideal 33-35 ms).
- **Stage-0 time:** stage-0 NCCL peer wait 13.9 ms, i.e. waiting for stage 1, not a false dependency.
- **Rebalanced ideal:** 27.4 ms. Rebalancing (moving layers, the MTP draft or the LM head off stage 1) is the next lever.

## Reading
1. **The false dependency is real.** It is removed by QD or QP with exact outputs, giving **+18-21 % at 8k and 40k**.
2. **QD is the winner** (+21.1 % / +19.8 %).
3. **S alone gives +11.6 %** and only halves the stall.
4. **The next bottleneck is stage-1 compute.** Candidates:
   - the PP layer partition;
   - the INT8 draft head;
   - sharded sampling.
5. **Not measured here:** QP + QD combined; S + QD.
6. **Notebook fix needed:** the base-parity gate must compare parity between arms (or record it only), not reject an imbalanced base.
