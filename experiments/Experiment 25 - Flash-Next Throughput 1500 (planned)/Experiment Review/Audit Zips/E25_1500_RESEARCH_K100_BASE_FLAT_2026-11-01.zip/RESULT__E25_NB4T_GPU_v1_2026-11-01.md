# E25 NB4T speed levers: GPU run v1 (sha 675b1b9d, hosen42, 2026-11-01)

- **Output:** `_scratch/e25_gpu_out/q27-xhigh-e25-nb4t-levers/nb4t/` (`nb4t_results.json`, `nb4t_verdict.json`, `timeline_*.md`, traces).
- **Base Q:** W4, FP8 KV, MTP K3, Q-defer ENGAGED, 8 streams, pin 3,553,580,524.
- **Notebook verdict:** `I8:WIN`. P26 REGRESSION; P27 SKIPPED_P26_OOM; C12 CORRECTNESS_FAIL (garbage flag, see below).
- **Limit:** only the 8k and 40k bands were measured. Per the user rule of 2026-11-01, no lever is adopted without 90k / 120k bands.

## Speed (tok/s; steady windows, preemptions 0, running == level)
| arm | pin | 8k #1 | 8k #2 | 8k mean | vs Q | 40k | vs Q | AL | oracle |
|---|---|---|---|---|---|---|---|---|---|
| Q (MTP K3 + Q-defer) | 3.55 GB | 304.6 | 301.1 | 302.9 | — | 287.4 | — | 3.05-3.14 | — |
| I8 (INT8 draft head) | 3.29 GB (OOM at 3.55) | 299.1 | 327.3 | 313.2 | +3.4 % | **320.2** | **+11.4 %** | 3.06-3.11 | EXACT |
| P26 (partition 26/22) | 3.29 GB (OOM at 3.55) | 287.3 | 303.2 | 295.2 | −2.5 % | 301.5 | +4.9 % | 3.11-3.13 | NEAR_TIE |
| P27 | — | — | — | — | skipped (P26 OOM) | — | — | — | — |
| **C12 (12 streams)** | 3.55 GB | 386.1 | 389.6 | **387.9** | **+28 %** | **374.6** | **+30 %** | 3.14-3.17 | EXACT |

- **Q capacity:** 215 blocks, max concurrency 5.63 at 131k. Free memory after ready: 663 / 687 / 175 / 175 MiB. The PP0 pin had 379 MiB unused.
- **I8:**
  - The acceptance did not drop.
  - It needed a lower pin (the INT8 head adds about 310 MiB on each PP1 card), so the KV pool is smaller.
  - The two 8k windows disagree (299 vs 327, with the parity labels differing), so the 8k gain is noisy. The 40k gain is clear.
- **P26:** OOM at the base pin. At the lower pin it gave no 8k gain and +5 % at 40k. **Not useful.**
- **C12:**
  - Large gain at 8k and 40k with 0 preemptions.
  - KV usage max was 0.99 at 40k@12, so 90k+ would preempt.
  - The 40k window was flagged `FAIL_GARBAGE_UNDER_LOAD` (LOW_VARIETY on 1 of 12 streams). The sample tail is coherent ARC reasoning ("…Could correspond to row15 first? … transformation: input is a folding puzzle…").
  - The klee100 lab documents that this stream-level LOW_VARIETY check misreads long healthy reasoning (unique words < 8 %) and fixes it with a windowed check. **This is very likely a false positive, but it is not proven: the full stream text was not saved.**

## Next: NB4U, the long-band confirmation
- **Arms:** Q, I8, C12, and C10 / C11, with combinations (I8 + C12).
- **Bands:** 8k, 40k, **90k, about 120k**.
- **Per arm:** a long-context oracle; residency and preemption at each band.
- **Garbage check:** the windowed one from the klee100 lab, with the full stream text saved.
- **Decide** the worker count and I8 for production only from this run.
