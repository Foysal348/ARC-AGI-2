clock: SHARED_CLOCK (measured offsets us: {'0': 0.0, '1': -0.1, '2': -2.4, '3': -2.1})

NB1 reproduction (critical path / GPU-busy union / summed kernels, ms per micro-batch):
  stage0 (rank 0, 8 verify tokens, n=20): 47.307 / 20.808 / 22.396
  stage1 (rank 2, 8 verify tokens, n=20): 20.844 / 18.321 / 20.473

steady ticks 36 of 39; tick ms mean 45.906 median 46.031; graph modes {'FULL': 36}

| category | stage0 ms (mean) | stage1 ms (mean) | stage0 % of tick | stage1 % of tick |
|---|---|---|---|---|
| compute | 23.242 | 34.226 | 50.6 | 74.6 |
| copy | 0.165 | 0.049 | 0.4 | 0.1 |
| in_graph_stall | 11.699 | 1.678 | 25.5 | 3.7 |
| nccl_peer_wait | 8.216 | 0.022 | 17.9 | 0.0 |
| nccl_tp_skew | 0.004 | 0.703 | 0.0 | 1.5 |
| nccl_transfer | 2.566 | 6.837 | 5.6 | 14.9 |
| host_launch_gap | 0.004 | 0.559 | 0.0 | 1.2 |
| host_python_gap | 0.001 | 0.353 | 0.0 | 0.8 |
| idle_no_host | 0.01 | 1.478 | 0.0 | 3.2 |
| (in_graph_stall_peer_computing, side measure) | 8.855 | 1.004 | | |
| (in_graph_stall_pp_nccl_running, side measure) | 11.685 | 0.0 | | |
| (nccl_transfer_pp, side measure) | 2.56 | 0.067 | | |
| (nccl_transfer_tp, side measure) | 0.006 | 6.77 | | |
| (nccl_transfer_peer_in_nccl, side measure) | 1.631 | 6.833 | | |
| (nccl_transfer_peer_host, side measure) | 0.251 | 0.002 | | |
| (nccl_transfer_peer_idle, side measure) | 0.684 | 0.003 | | |
| (gap = tick - compute - copy) | 22.499 | 11.631 | | |

pipeline per tick (ms): {'stage0_only_ms': 5.146, 'other_stage_only_ms': 16.075, 'both_busy_ms': 19.61, 'neither_ms': 5.075}; stage-1 idle 11.631 ms
critical path per tick (ms): {'tick_ms': 45.906, 'forward_kernel_wall_ms': 40.995, 'forward_kernel_union_ms': 27.533, 'forward_kernel_sum_ms': 29.681, 'ideal_overlapped_tick_ms': 34.475, 'serialization_ms': 11.431}
stalls: {'ticks_with_stall_over_1ms': 22, 'steady_ticks': 36, 'in_graph_stall_ms_mean': 11.736, 'released_by': {'ncclDevKernel_Broadcast_RING_LL broadcast Intx12 group [0, 2]': 18, 'ncclDevKernel_Broadcast_RING_LL broadcast Intx4 group [0, 2]': 4}, 'release_lag_us_median': 9.35, 'release_lag_us_p90': 15.3}
ideal tick: {'per_stage_busy_ms': {'stage0': 23.407, 'stage1': 34.275}, 'observed_tick_ms': 45.906, 'balanced_parity_ideal_ms': 34.275, 'bound_by': 'stage1 work', 'chain_bound_ms': 28.841, 'chain_bound_with_observed_bubble_ms': 33.916, 'rebalanced_stages_ms': 28.841, 'one_parity_serial_tick_ms': 62.757, 'gain_vs_observed_pct': 33.9, 'note': "rebalanced_stages = equal per-stage work (layer split / where the MTP draft and lm-head run); one_parity_serial = every step's work on both stages back to back (no overlap), with this run's per-step work; with all requests in one parity a step carries more requests, so its work is larger than measured here"}
micro-batch parity: UNBALANCED; n per parity: {'stage0': {'0': {'6': 20}, '1': {'2': 20}}, 'stage1': {'0': {'6': 20}, '1': {'2': 20}}}; stage step match {'compared': 40, 'matched': 40, 'meaning': 'the stage-1 step with the same index sends exactly the broadcast Seqs this stage-0 step receives (same micro-batch)'}
dependency: FALSE {'FALSE_NO_REAL_INPUT': 1, 'FALSE': 23}; step delta {'1': 24}; real input ready before graph start (ms, median / min) 2.606 / 2.404
graph mode (rev 2 rule): {'0': {'FULL': 40}, '1': {'FULL': 40}, '2': {'FULL': 40}, '3': {'FULL': 40}}; NB1 lab rule: {'0': 'PIECEWISE', '1': 'PIECEWISE', '2': 'PIECEWISE', '3': 'PIECEWISE'}