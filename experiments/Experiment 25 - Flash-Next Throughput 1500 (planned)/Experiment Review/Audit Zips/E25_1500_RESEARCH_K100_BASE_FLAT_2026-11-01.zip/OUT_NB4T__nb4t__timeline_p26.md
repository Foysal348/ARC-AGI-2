clock: SHARED_CLOCK (measured offsets us: {'0': 0.0, '1': -0.3, '2': 2.8, '3': 3.1})

NB1 reproduction (critical path / GPU-busy union / summed kernels, ms per micro-batch):
  stage0 (rank 0, 4 verify tokens, n=20): 53.785 / 52.907 / 54.777
  stage1 (rank 2, 4 verify tokens, n=20): 14.375 / 13.731 / 15.363

steady ticks 36 of 39; tick ms mean 43.961 median 44.284; graph modes {'FULL': 36}

| category | stage0 ms (mean) | stage1 ms (mean) | stage0 % of tick | stage1 % of tick |
|---|---|---|---|---|
| compute | 22.366 | 32.403 | 50.9 | 73.7 |
| copy | 0.11 | 0.056 | 0.3 | 0.1 |
| in_graph_stall | 0.313 | 0.395 | 0.7 | 0.9 |
| nccl_peer_wait | 13.054 | 3.387 | 29.7 | 7.7 |
| nccl_tp_skew | 0.881 | 0.731 | 2.0 | 1.7 |
| nccl_transfer | 6.68 | 6.52 | 15.2 | 14.8 |
| host_launch_gap | 0.005 | 0.108 | 0.0 | 0.2 |
| host_python_gap | 0.001 | 0.083 | 0.0 | 0.2 |
| idle_no_host | 0.551 | 0.278 | 1.3 | 0.6 |
| (in_graph_stall_peer_computing, side measure) | 0.253 | 0.235 | | |
| (in_graph_stall_pp_nccl_running, side measure) | 0.0 | 0.0 | | |
| (nccl_transfer_pp, side measure) | 3.768 | 0.628 | | |
| (nccl_transfer_tp, side measure) | 2.911 | 5.892 | | |
| (nccl_transfer_peer_in_nccl, side measure) | 4.424 | 4.448 | | |
| (nccl_transfer_peer_host, side measure) | 0.633 | 0.124 | | |
| (nccl_transfer_peer_idle, side measure) | 1.622 | 1.947 | | |
| (gap = tick - compute - copy) | 21.485 | 11.502 | | |

pipeline per tick (ms): {'stage0_only_ms': 5.696, 'other_stage_only_ms': 15.741, 'both_busy_ms': 17.833, 'neither_ms': 4.69}; stage-1 idle 11.501 ms
critical path per tick (ms): {'tick_ms': 43.961, 'forward_kernel_wall_ms': 43.924, 'forward_kernel_union_ms': 43.018, 'forward_kernel_sum_ms': 45.991, 'ideal_overlapped_tick_ms': 35.048, 'serialization_ms': 8.913}
stalls: {'ticks_with_stall_over_1ms': 0, 'steady_ticks': 36, 'in_graph_stall_ms_mean': 0.309, 'released_by': {}, 'release_lag_us_median': None, 'release_lag_us_p90': None}
ideal tick: {'per_stage_busy_ms': {'stage0': 22.476, 'stage1': 32.459}, 'observed_tick_ms': 43.961, 'balanced_parity_ideal_ms': 32.459, 'bound_by': 'stage1 work', 'chain_bound_ms': 27.468, 'chain_bound_with_observed_bubble_ms': 32.157, 'rebalanced_stages_ms': 27.468, 'one_parity_serial_tick_ms': 59.625, 'gain_vs_observed_pct': 35.4, 'note': "rebalanced_stages = equal per-stage work (layer split / where the MTP draft and lm-head run); one_parity_serial = every step's work on both stages back to back (no overlap), with this run's per-step work; with all requests in one parity a step carries more requests, so its work is larger than measured here"}
micro-batch parity: UNBALANCED; n per parity: {'stage0': {'0': {'7': 20}, '1': {'1': 20}}, 'stage1': {'0': {'7': 20}, '1': {'1': 20}}}; stage step match {'compared': 40, 'matched': 0, 'meaning': 'the stage-1 step with the same index sends exactly the broadcast Seqs this stage-0 step receives (same micro-batch)'}
dependency: NO_STALL {}; step delta {}; real input ready before graph start (ms, median / min) None / None
graph mode (rev 2 rule): {'0': {'FULL': 40}, '1': {'FULL': 40}, '2': {'FULL': 40}, '3': {'FULL': 40}}; NB1 lab rule: {'0': 'PIECEWISE', '1': 'PIECEWISE', '2': 'PIECEWISE', '3': 'PIECEWISE'}