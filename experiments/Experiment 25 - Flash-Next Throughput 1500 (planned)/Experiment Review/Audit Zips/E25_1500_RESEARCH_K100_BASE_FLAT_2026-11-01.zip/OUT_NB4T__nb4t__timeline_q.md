clock: SHARED_CLOCK (measured offsets us: {'0': 0.0, '1': -0.6, '2': 7.5, '3': 5.9})

NB1 reproduction (critical path / GPU-busy union / summed kernels, ms per micro-batch):
  stage0 (rank 0, 8 verify tokens, n=20): 48.366 / 46.699 / 48.972
  stage1 (rank 2, 8 verify tokens, n=20): 18.688 / 17.721 / 19.749

steady ticks 36 of 39; tick ms mean 41.675 median 41.12; graph modes {'FULL': 36}

| category | stage0 ms (mean) | stage1 ms (mean) | stage0 % of tick | stage1 % of tick |
|---|---|---|---|---|
| compute | 22.645 | 34.06 | 54.3 | 81.7 |
| copy | 0.11 | 0.048 | 0.3 | 0.1 |
| in_graph_stall | 0.31 | 0.399 | 0.7 | 1.0 |
| nccl_peer_wait | 11.622 | 0.023 | 27.9 | 0.1 |
| nccl_tp_skew | 0.921 | 0.848 | 2.2 | 2.0 |
| nccl_transfer | 5.559 | 5.715 | 13.3 | 13.7 |
| host_launch_gap | 0.186 | 0.079 | 0.4 | 0.2 |
| host_python_gap | 0.084 | 0.085 | 0.2 | 0.2 |
| idle_no_host | 0.239 | 0.419 | 0.6 | 1.0 |
| (in_graph_stall_peer_computing, side measure) | 0.271 | 0.262 | | |
| (in_graph_stall_pp_nccl_running, side measure) | 0.0 | 0.0 | | |
| (nccl_transfer_pp, side measure) | 2.961 | 0.031 | | |
| (nccl_transfer_tp, side measure) | 2.597 | 5.684 | | |
| (nccl_transfer_peer_in_nccl, side measure) | 3.159 | 3.176 | | |
| (nccl_transfer_peer_host, side measure) | 0.776 | 0.348 | | |
| (nccl_transfer_peer_idle, side measure) | 1.623 | 2.192 | | |
| (gap = tick - compute - copy) | 18.92 | 7.567 | | |

pipeline per tick (ms): {'stage0_only_ms': 2.98, 'other_stage_only_ms': 14.425, 'both_busy_ms': 20.872, 'neither_ms': 3.399}; stage-1 idle 7.567 ms
critical path per tick (ms): {'tick_ms': 41.675, 'forward_kernel_wall_ms': 41.669, 'forward_kernel_union_ms': 40.785, 'forward_kernel_sum_ms': 43.721, 'ideal_overlapped_tick_ms': 34.108, 'serialization_ms': 7.567}
stalls: {'ticks_with_stall_over_1ms': 0, 'steady_ticks': 36, 'in_graph_stall_ms_mean': 0.317, 'released_by': {}, 'release_lag_us_median': None, 'release_lag_us_p90': None}
ideal tick: {'per_stage_busy_ms': {'stage0': 22.755, 'stage1': 34.108}, 'observed_tick_ms': 41.675, 'balanced_parity_ideal_ms': 34.108, 'bound_by': 'stage1 work', 'chain_bound_ms': 28.431, 'chain_bound_with_observed_bubble_ms': 31.831, 'rebalanced_stages_ms': 28.431, 'one_parity_serial_tick_ms': 60.262, 'gain_vs_observed_pct': 22.2, 'note': "rebalanced_stages = equal per-stage work (layer split / where the MTP draft and lm-head run); one_parity_serial = every step's work on both stages back to back (no overlap), with this run's per-step work; with all requests in one parity a step carries more requests, so its work is larger than measured here"}
micro-batch parity: UNBALANCED; n per parity: {'stage0': {'0': {'2': 20}, '1': {'6': 20}}, 'stage1': {'0': {'2': 20}, '1': {'6': 20}}}; stage step match {'compared': 40, 'matched': 0, 'meaning': 'the stage-1 step with the same index sends exactly the broadcast Seqs this stage-0 step receives (same micro-batch)'}
dependency: NO_STALL {}; step delta {}; real input ready before graph start (ms, median / min) None / None
graph mode (rev 2 rule): {'0': {'FULL': 40}, '1': {'FULL': 40}, '2': {'FULL': 40}, '3': {'FULL': 40}}; NB1 lab rule: {'0': 'PIECEWISE', '1': 'PIECEWISE', '2': 'PIECEWISE', '3': 'PIECEWISE'}