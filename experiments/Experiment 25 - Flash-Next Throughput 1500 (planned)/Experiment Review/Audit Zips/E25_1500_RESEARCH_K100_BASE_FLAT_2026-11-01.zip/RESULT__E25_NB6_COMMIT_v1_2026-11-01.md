# E25 NB6 SUBMIT: commit run v1 + CPU kits (foysalemonshanto, 2026-11-01)

- **Notebook:** `Q27-XHIGH-E25_NB6_SUBMIT.ipynb`, sha 87afcc84, version 1, profile NB6COMMIT.
- **Output:** `_scratch/e25_gpu_out/q27-xhigh-e25-nb6-submit/`.

## GPU commit (4×L4, 24.0 min wall, 50-min budget)
**Boot and engine**
- Boot `merlin_fp8_mtp_pin100` came up on the first try; the ladder did not fail.
- Engine: FP8 KV, MTP K3, 9 workers.
- GPU KV cache 738,142 tokens, the same as NB5 QUALITY's FP8 boot.

**Score**
- Eval 3 / 3 tasks, 3 / 3 queries, all pass1; task-norm 100 %.
- Tasks: 1818057f, 2ba387bc, 45a5af55.

**E15B attempt policy, as built**
- `E12_B_SKIP_B1_IF_ACCEPTED` 0, `E12_B_B1_ACC_MODE` 0, `E12_B_EXTRA_ATTEMPTS` 0.
- 6 attempts, b1 started 3, 6 accepted. No attempt hit the budget and there was no stage 3.

**Server and solver health**
- 0 worker errors, 0 infra errors, 0 preemptions, 0 OOM lines, 0 tracebacks, 0 watchdog stalls and 0 relaunches.
- Solver window 233 s, 23,892 server generated tokens, 102.5 tok/s.
  - The window is too short to measure steady throughput.
  - With 3 tasks, mean running was 2.12, so E15B printed its "mean running < streams" warning. This is expected for 3 tasks.
- Accept length p50 2.88; prefix cache hit 49 %; KV usage max 71.5 %.

**Preflight and output**
- E12 preflight isolation PASS. `drafter_config_error FileNotFoundError` is the same line NB5 QUALITY printed, so it is benign.
- `submission.json` has 240 task ids: the full test set, with the identity fallback plus the eval answers.
- The output notebook is 415 kB (the output, not the commit source).

## CPU kits (Kaggle, same image)
| kit | result | notes |
|---|---|---|
| units | ALL OK | |
| e2e-rerun | ALL OK | normal + boot retry / no eval file; E18 R2 schema comparison PASS |
| real | 2 checks NOT OK, both kit artifacts | `rerun_plans_equal_commit_plans`: the argv differ only at the port (8100 vs 8105 and similar), by design. `vllm_argparse_fields_all_plans`: torch circular import on CPU, a known CPU-only limit. Every other check is OK. |
| e2e-commit | 29 / 30 | The single fail is a stale kit expectation: it expects a baked 40-min commit budget, but NB6COMMIT is 50 min (3000 s). The submission was written 2,822 s before the hard stop. |

No notebook defect was found.

## Next
Submit this version to the competition. This needs the user's go.
