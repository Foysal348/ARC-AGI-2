clock: SHARED_CLOCK (measured offsets us: {'0': 0.0, '1': -0.1, '2': 1.8, '3': 3.8})

NB1 reproduction (critical path / GPU-busy union / summed kernels, ms per micro-batch):
  stage0 (rank 0, 4 verify tokens, n=20): 118.584 / 116.606 / 118.508
  stage1 (rank 2, 4 verify tokens, n=20): 15.014 / 14.107 / 15.941

steady ticks 19 of 39; tick ms mean 123.808 median 120.718; graph modes {'EAGER': 1, 'FULL': 18}

| category | stage0 ms (mean) | stage1 ms (mean) | stage0 % of tick | stage1 % of tick |
|---|---|---|---|---|
| compute | 15.384 | 47.084 | 12.4 | 38.0 |
| copy | 0.087 | 0.031 | 0.1 | 0.0 |
| in_graph_stall | 0.267 | 0.066 | 0.2 | 0.1 |
| nccl_peer_wait | 53.189 | 0.005 | 43.0 | 0.0 |
| nccl_tp_skew | 1.2 | 9.919 | 1.0 | 8.0 |
| nccl_transfer | 49.681 | 29.944 | 40.1 | 24.2 |
| host_launch_gap | 3.448 | 29.951 | 2.8 | 24.2 |
| host_python_gap | 0.506 | 1.267 | 0.4 | 1.0 |
| idle_no_host | 0.046 | 5.541 | 0.0 | 4.5 |
| (in_graph_stall_peer_computing, side measure) | 0.199 | 0.007 | | |
| (in_graph_stall_pp_nccl_running, side measure) | 0.0 | 0.0 | | |
| (nccl_transfer_pp, side measure) | 46.815 | 0.015 | | |
| (nccl_transfer_tp, side measure) | 2.867 | 29.93 | | |
| (nccl_transfer_peer_in_nccl, side measure) | 27.397 | 27.458 | | |
| (nccl_transfer_peer_host, side measure) | 20.109 | 2.342 | | |
| (nccl_transfer_peer_idle, side measure) | 2.176 | 0.144 | | |
| (gap = tick - compute - copy) | 108.337 | 76.693 | | |

pipeline per tick (ms): {'stage0_only_ms': 6.508, 'other_stage_only_ms': 55.293, 'both_busy_ms': 11.121, 'neither_ms': 50.886}; stage-1 idle 76.694 ms
critical path per tick (ms): {'tick_ms': 123.808, 'forward_kernel_wall_ms': 123.747, 'forward_kernel_union_ms': 121.619, 'forward_kernel_sum_ms': 123.532, 'ideal_overlapped_tick_ms': 47.77, 'serialization_ms': 76.038}
stalls: {'ticks_with_stall_over_1ms': 0, 'steady_ticks': 19, 'in_graph_stall_ms_mean': 0.275, 'released_by': {}, 'release_lag_us_median': None, 'release_lag_us_p90': None}
ideal tick: {'per_stage_busy_ms': {'stage0': 15.471, 'stage1': 47.115}, 'observed_tick_ms': 123.808, 'balanced_parity_ideal_ms': 47.115, 'bound_by': 'stage1 work', 'chain_bound_ms': 31.293, 'chain_bound_with_observed_bubble_ms': 82.179, 'rebalanced_stages_ms': 31.293, 'one_parity_serial_tick_ms': 113.472, 'gain_vs_observed_pct': 162.8, 'note': "rebalanced_stages = equal per-stage work (layer split / where the MTP draft and lm-head run); one_parity_serial = every step's work on both stages back to back (no overlap), with this run's per-step work; with all requests in one parity a step carries more requests, so its work is larger than measured here"}
micro-batch parity: UNBALANCED; n per parity: {'stage0': {'0': {'1': 20}, '1': {'11': 20}}, 'stage1': {'0': {'1': 20}, '1': {'11': 20}}}; stage step match {'compared': 40, 'matched': 0, 'meaning': 'the stage-1 step with the same index sends exactly the broadcast Seqs this stage-0 step receives (same micro-batch)'}
dependency: NO_STALL {}; step delta {}; real input ready before graph start (ms, median / min) None / None
graph mode (rev 2 rule): {'0': {'FULL': 20, 'EAGER': 20}, '1': {'FULL': 20, 'EAGER': 20}, '2': {'FULL': 20, 'EAGER': 20}, '3': {'FULL': 20, 'EAGER': 20}}; NB1 lab rule: {'0': 'MIXED', '1': 'MIXED', '2': 'MIXED', '3': 'MIXED'}