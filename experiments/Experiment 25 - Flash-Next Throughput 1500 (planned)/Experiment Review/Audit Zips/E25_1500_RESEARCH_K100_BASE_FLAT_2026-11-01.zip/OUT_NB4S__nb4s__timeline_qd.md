clock: SHARED_CLOCK (measured offsets us: {'0': 0.0, '1': -0.9, '2': -0.2, '3': -0.9})

NB1 reproduction (critical path / GPU-busy union / summed kernels, ms per micro-batch):
  stage0 (rank 0, 4 verify tokens, n=20): 55.061 / 54.221 / 55.91
  stage1 (rank 2, 4 verify tokens, n=20): 14.6 / 13.968 / 15.647

steady ticks 36 of 39; tick ms mean 44.07 median 44.381; graph modes {'FULL': 36}

| category | stage0 ms (mean) | stage1 ms (mean) | stage0 % of tick | stage1 % of tick |
|---|---|---|---|---|
| compute | 21.611 | 32.972 | 49.0 | 74.8 |
| copy | 0.109 | 0.056 | 0.2 | 0.1 |
| in_graph_stall | 0.302 | 0.392 | 0.7 | 0.9 |
| nccl_peer_wait | 13.932 | 2.875 | 31.6 | 6.5 |
| nccl_tp_skew | 0.843 | 0.781 | 1.9 | 1.8 |
| nccl_transfer | 6.72 | 6.539 | 15.2 | 14.8 |
| host_launch_gap | 0.013 | 0.11 | 0.0 | 0.2 |
| host_python_gap | 0.007 | 0.07 | 0.0 | 0.2 |
| idle_no_host | 0.532 | 0.274 | 1.2 | 0.6 |
| (in_graph_stall_peer_computing, side measure) | 0.245 | 0.232 | | |
| (in_graph_stall_pp_nccl_running, side measure) | 0.0 | 0.0 | | |
| (nccl_transfer_pp, side measure) | 3.855 | 0.553 | | |
| (nccl_transfer_tp, side measure) | 2.865 | 5.986 | | |
| (nccl_transfer_peer_in_nccl, side measure) | 4.455 | 4.482 | | |
| (nccl_transfer_peer_host, side measure) | 0.687 | 0.134 | | |
| (nccl_transfer_peer_idle, side measure) | 1.579 | 1.924 | | |
| (gap = tick - compute - copy) | 22.35 | 11.042 | | |

pipeline per tick (ms): {'stage0_only_ms': 5.177, 'other_stage_only_ms': 16.613, 'both_busy_ms': 17.56, 'neither_ms': 4.719}; stage-1 idle 11.041 ms
critical path per tick (ms): {'tick_ms': 44.07, 'forward_kernel_wall_ms': 44.033, 'forward_kernel_union_ms': 43.139, 'forward_kernel_sum_ms': 45.922, 'ideal_overlapped_tick_ms': 35.142, 'serialization_ms': 8.928}
stalls: {'ticks_with_stall_over_1ms': 0, 'steady_ticks': 36, 'in_graph_stall_ms_mean': 0.304, 'released_by': {}, 'release_lag_us_median': None, 'release_lag_us_p90': None}
ideal tick: {'per_stage_busy_ms': {'stage0': 21.72, 'stage1': 33.028}, 'observed_tick_ms': 44.07, 'balanced_parity_ideal_ms': 33.028, 'bound_by': 'stage1 work', 'chain_bound_ms': 27.374, 'chain_bound_with_observed_bubble_ms': 32.093, 'rebalanced_stages_ms': 27.374, 'one_parity_serial_tick_ms': 59.467, 'gain_vs_observed_pct': 33.4, 'note': "rebalanced_stages = equal per-stage work (layer split / where the MTP draft and lm-head run); one_parity_serial = every step's work on both stages back to back (no overlap), with this run's per-step work; with all requests in one parity a step carries more requests, so its work is larger than measured here"}
micro-batch parity: UNBALANCED; n per parity: {'stage0': {'0': {'7': 20}, '1': {'1': 20}}, 'stage1': {'0': {'7': 20}, '1': {'1': 20}}}; stage step match {'compared': 40, 'matched': 0, 'meaning': 'the stage-1 step with the same index sends exactly the broadcast Seqs this stage-0 step receives (same micro-batch)'}
dependency: NO_STALL {}; step delta {}; real input ready before graph start (ms, median / min) None / None
graph mode (rev 2 rule): {'0': {'FULL': 40}, '1': {'FULL': 40}, '2': {'FULL': 40}, '3': {'FULL': 40}}; NB1 lab rule: {'0': 'PIECEWISE', '1': 'PIECEWISE', '2': 'PIECEWISE', '3': 'PIECEWISE'}