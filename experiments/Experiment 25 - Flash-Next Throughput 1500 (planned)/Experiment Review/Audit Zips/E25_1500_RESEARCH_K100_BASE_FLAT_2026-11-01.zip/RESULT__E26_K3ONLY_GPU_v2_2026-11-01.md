# E26 klee100 LOAD, K3_ONLY: GPU run v2 (rev 3, foysalemonshanto, 2026-11-01)

- **Notebook:** `Q27-XHIGH-E25_KLEE100_LOAD_K3ONLY.ipynb`, sha 7773e63f, Kaggle version 2.
- **Output:** `_scratch/e25_gpu_out_k3_v2/q27-xhigh-e25-klee100-load-k3only/`.

## Verdict
`K3_FP8_LOAD_PASS + LOWBIT_TF_DIVERGENT_SEVERE | BF16_NOT_IN_PROFILE`. The core finished (`@@K3_CORE_DONE`), and correctness was CLEAN (engine faults only).

## Boot and read-back
- **Boot:** first rung, `kv_cache_memory_bytes` 7,933,526,016 (7.39 GiB per GPU). Ready in 519.1 s, with no OOM and no device fault.
- **Model load per rank:** 11.45 / 11.45 / 11.97 / 11.97 GiB, about 184-195 s.
- **Method map:** GPU_METHOD_MAP_PASS, 48 / 48 layers.
  - Bits sources: method.weight_schema 96, method.quant_config 2.
  - MTP experts: AutoGPTQMoEMethod W4 g128.
  - Drafter: found on ranks 2-3 via `get_draft_model()`.
- **Template probe:** MATCH (4,894 tokens). Chat probes 3 / 3; arithmetic 8 / 8.

## Capacity (measured)
| | klee100 K3 (pin 7.39 GiB) | W4 FP8 (NB5 / NB6, pin 3.31 GiB) |
|---|---|---|
| KV tokens | **1,652,197** | 738,142 (NB6 server log) |
| Pool blocks (usable) | **479** | 214 |
| Max concurrency at 131,072 | 12.61 | 5.63 |
| F | 6 | 6 |
| Resident bound 40k / 64k / 90k / 120k | 29 / 21 / 17 / 13 | — |

- **Free memory after ready:** 2,795 / 2,791 / 1,189 / 1,189 MiB on cards 0-3.
- **NB5 worker rule:** `floor(479 / (16 + 6))` = **21 workers**, vs 9 for W4.

## Speed (steady windows, running == level, 0 preemptions)
| window | tok/s | tick ms | acceptance length | KV max |
|---|---|---|---|---|
| 20k@16 | **460.4** | 55.8 | 3.21 | 0.51 |
| 20k@24 | **562.0** | 68.7 | 3.22 | 0.60 |
| 40k@16 | **444.7** | 57.2 | 3.18 | 0.84 |
| 60k@16 (admission window, all resident) | 431.1 | 57.8 | — | 0.70 |

- **Skipped as KV-bound:** 20k@32, 40k@24, 60k@16 (sweep), 100k@16.
- **W4 FP8 reference:** 262 tok/s at 8k × 8 and 190 at 40k × 5 (RC2); 225 steady p50 with 9 workers (NB5). At comparable contexts klee100 is about **2.0-2.5× faster**.

## Quality signals (teacher-forced, vs NB0 W4 BF16 KV, MTP off)
| band | mean abs dlogprob | p99 | rank-1 agreement | yardstick: W4 FP8 KV vs BF16 |
|---|---|---|---|---|
| 2k | 1.695 | 9.93 | **0.513** | 0.352 / rank-1 0.897 |
| 8k | 1.095 | 6.93 | **0.652** | 0.220 / rank-1 0.934 |
| 40k | 1.486 | 7.93 | **0.602** | 0.932 / rank-1 0.749 |

**klee100 self-repeat (fresh vs repeat), last 256 tokens:**

| band | mean abs dlogprob | rank-1 agreement |
|---|---|---|
| 2k | 0.659 | 0.856 |
| 8k | 0.098 | 0.949 |
| 40k | 0.283 | 0.914 |

klee100 is therefore not deterministic run to run, whereas NB0's W4 A / A was 0.0.

**Greedy oracle vs RC2 FP8:** the first difference is at token 2 in all 4 rows (1 NEAR_TIE, 3 FAIL_HIGH_MARGIN). That is expected for different weights.

**Reading:** klee100 is a measurably different token distribution from W4, well beyond the FP8-KV effect. Whether ARC accuracy holds can only be shown by the 15-task Duck run (E26 K100 QUALITY, being built). The speed and capacity gains are real and measured.

## Next
- E26 K100 QUALITY: the same 15 tasks, Duck config B, 2 × 104k, a 4,050 s window, about 21 workers. It is compared with NB5 W4 FP8 (13 / 15).
- The audit comes before any push.
