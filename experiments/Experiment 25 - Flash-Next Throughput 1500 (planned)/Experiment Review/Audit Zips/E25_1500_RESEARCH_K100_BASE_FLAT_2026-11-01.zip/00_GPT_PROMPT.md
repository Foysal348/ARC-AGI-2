# Research request: the next levers toward 1500 tok/s for Qwen3.8-Flash-Next on 4×L4, with NB-K100 as the baseline

Read every file in this zip first (flat; the prefixes say where each file comes from). Start with `REPORT__E25_1500_PROGRESS_REPORT_2026-11-01.md`. It holds the measured baseline, the adopted levers, the measured negatives and the open candidates.

## Baseline: NB-K100
- klee100 3bpw-MTP Flash-Next on Merlin v3.0.0 (a vLLM 0.32 fork), TP2 × PP2 + EP, FP8 QSA KV, MTP K3.
- Q-defer, INT8 draft head, 24 workers.
- The real Duck workload averages **385 tok/s** over the window (414 with all workers busy).
- Notebooks:
  - `NB__Q27-XHIGH-E28_K100_EVAL120_6H.ipynb`: the 6-h run in progress now;
  - `NB__Q27-XHIGH-E26_K100_QUALITY.ipynb` plus its outputs `OUT_K100Q__*`.
- The W4 sibling, for reference: `NB__Q27-XHIGH-E28_W4_EVAL120_6H.ipynb`.

## What we ask
1. **Do hundreds of targeted searches** on GitHub (vLLM, SGLang, Merlin-like forks, issues, PRs, discussions), Hugging Face (model cards, quantized Flash-Next / Qwen3.8 variants, drafters), Kaggle (ARC Prize 2026 discussions and notebooks, L4 / T4 serving notebooks), arXiv and blogs. Look for anything that raises **aggregate decode throughput on 4×L4 (sm_89, PCIe, no P2P)** for this model class: hybrid GDN + sparse QSA attention, large MoE (512 experts top-10), hyper-connections, PLE, long contexts of 30-120k, 16-30 concurrent streams.
2. **For every lever found, give:**
   - what it is;
   - evidence, with exact URLs, plus measured numbers and the hardware they were measured on;
   - why it should apply to OUR setup;
   - the expected gain on NB-K100 (state your assumptions);
   - the exact port: files, flags, env, patches;
   - the risk;
   - the cheapest decisive test (GPU minutes, the read-backs, the pass gate).
3. **Rank** them by expected gain × confidence ÷ cost.
4. **Respect the measured negatives** in section 3 of the report. Do not re-propose them unless you bring new evidence that changes the picture, and say so explicitly.
5. **Cover at least these areas:**
   - stage-1 compute after Q-defer (sharded sampling, the LM head, graphing post-target work, PP rebalancing);
   - speculative decoding (DFlash2 and other drafters, K choice, acceptance at FP8, draft-head quantization);
   - KV capacity (fixed blocks F, Mamba page padding, block size, admission on live blocks);
   - MoE kernels on sm_89 (humming / Marlin / Triton tuning, low-bit expert formats);
   - communication (NCCL world-2 settings, host-staged all-reduce, overlap);
   - the prefill / prefix cache under RecoverSSM + PP (re-prefill of generated tokens);
   - scheduler / CUDA graph coverage at 24-32 streams;
   - boot time;
   - any newer vLLM / SGLang release features that could be backported to Merlin.
6. **State the uncertainty plainly.** We will verify every claim against the Merlin source and on GPU.

**Answer format:** a ranked table first (lever, gain, confidence, cost, URLs), then one section per lever, then a proposed 2-3 notebook test plan on NB-K100.
