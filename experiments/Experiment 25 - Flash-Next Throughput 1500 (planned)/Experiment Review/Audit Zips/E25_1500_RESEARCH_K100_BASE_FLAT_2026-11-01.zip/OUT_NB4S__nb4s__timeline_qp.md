clock: SHARED_CLOCK (measured offsets us: {'0': 0.0, '1': -1.4, '2': 14.9, '3': 8.8})

NB1 reproduction (critical path / GPU-busy union / summed kernels, ms per micro-batch):
  stage0 (rank 0, 12 verify tokens, n=20): 23.779 / 22.122 / 23.812
  stage1 (rank 2, 12 verify tokens, n=20): 20.659 / 19.706 / 21.928

steady ticks 36 of 39; tick ms mean 41.846 median 41.975; graph modes {'FULL': 36}

| category | stage0 ms (mean) | stage1 ms (mean) | stage0 % of tick | stage1 % of tick |
|---|---|---|---|---|
| compute | 22.795 | 33.847 | 54.5 | 80.9 |
| copy | 0.166 | 0.055 | 0.4 | 0.1 |
| in_graph_stall | 0.32 | 0.405 | 0.8 | 1.0 |
| nccl_peer_wait | 15.134 | 0.018 | 36.2 | 0.0 |
| nccl_tp_skew | 0.0 | 0.824 | 0.0 | 2.0 |
| nccl_transfer | 3.426 | 6.083 | 8.2 | 14.5 |
| host_launch_gap | 0.001 | 0.072 | 0.0 | 0.2 |
| host_python_gap | 0.001 | 0.108 | 0.0 | 0.3 |
| idle_no_host | 0.002 | 0.435 | 0.0 | 1.0 |
| (in_graph_stall_peer_computing, side measure) | 0.281 | 0.263 | | |
| (in_graph_stall_pp_nccl_running, side measure) | 0.32 | 0.0 | | |
| (nccl_transfer_pp, side measure) | 3.426 | 0.022 | | |
| (nccl_transfer_tp, side measure) | 0.0 | 6.061 | | |
| (nccl_transfer_peer_in_nccl, side measure) | 3.209 | 6.082 | | |
| (nccl_transfer_peer_host, side measure) | 0.019 | 0.0 | | |
| (nccl_transfer_peer_idle, side measure) | 0.197 | 0.001 | | |
| (gap = tick - compute - copy) | 18.885 | 7.944 | | |

pipeline per tick (ms): {'stage0_only_ms': 3.517, 'other_stage_only_ms': 14.367, 'both_busy_ms': 20.701, 'neither_ms': 3.261}; stage-1 idle 7.945 ms
critical path per tick (ms): {'tick_ms': 41.846, 'forward_kernel_wall_ms': 27.668, 'forward_kernel_union_ms': 26.695, 'forward_kernel_sum_ms': 28.84, 'ideal_overlapped_tick_ms': 33.902, 'serialization_ms': 7.945}
stalls: {'ticks_with_stall_over_1ms': 0, 'steady_ticks': 36, 'in_graph_stall_ms_mean': 0.333, 'released_by': {}, 'release_lag_us_median': None, 'release_lag_us_p90': None}
ideal tick: {'per_stage_busy_ms': {'stage0': 22.961, 'stage1': 33.902}, 'observed_tick_ms': 41.846, 'balanced_parity_ideal_ms': 33.902, 'bound_by': 'stage1 work', 'chain_bound_ms': 28.431, 'chain_bound_with_observed_bubble_ms': 31.692, 'rebalanced_stages_ms': 28.431, 'one_parity_serial_tick_ms': 60.124, 'gain_vs_observed_pct': 23.4, 'note': "rebalanced_stages = equal per-stage work (layer split / where the MTP draft and lm-head run); one_parity_serial = every step's work on both stages back to back (no overlap), with this run's per-step work; with all requests in one parity a step carries more requests, so its work is larger than measured here"}
micro-batch parity: UNBALANCED; n per parity: {'stage0': {'0': {'3': 20}, '1': {'5': 20}}, 'stage1': {'0': {'3': 20}, '1': {'5': 20}}}; stage step match {'compared': 40, 'matched': 40, 'meaning': 'the stage-1 step with the same index sends exactly the broadcast Seqs this stage-0 step receives (same micro-batch)'}
dependency: NO_STALL {}; step delta {}; real input ready before graph start (ms, median / min) None / None
graph mode (rev 2 rule): {'0': {'FULL': 40}, '1': {'FULL': 40}, '2': {'FULL': 40}, '3': {'FULL': 40}}; NB1 lab rule: {'0': 'PIECEWISE', '1': 'PIECEWISE', '2': 'PIECEWISE', '3': 'PIECEWISE'}