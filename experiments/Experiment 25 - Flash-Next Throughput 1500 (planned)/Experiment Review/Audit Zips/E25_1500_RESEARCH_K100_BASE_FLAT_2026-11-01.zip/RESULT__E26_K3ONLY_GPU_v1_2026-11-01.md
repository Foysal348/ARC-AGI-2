# E26 klee100 LOAD, K3_ONLY: GPU run v1 (foysalemonshanto, 2026-11-01)

- **Notebook:** `Q27-XHIGH-E25_KLEE100_LOAD_K3ONLY.ipynb`, profile K3_ONLY.
- **Run:** Kaggle 4×L4, 14 min wall.
- **Output:** `_scratch/e25_gpu_out/q27-xhigh-e25-klee100-load-k3only/`.

## Verdict
The notebook's verdict was `K3_FP8_CONFIG_MISMATCH | BF16_NOT_IN_PROFILE`: `@@K3_CORE_FAILED`, then an early exit by design (V-15 / V-16).

**The mismatch is a read-back probe defect, not a model fault:**
- `method_map`: the class was right on all 48 layers (`HummingMoEMethod`), but bits / group read as null (want 3/128, or 2/64 on layers 12-35).
- The MTP drafter's MoE was not found (`mtp_ok` false, map `{}`).
- Raw per-rank rows were not saved.

## What did work (measured)
**Load and gates**
- The boot loaded on the first pin rung: `kv_cache_memory_bytes` 5,270,142,976 B (vs 3,553,580,524 for W4 FP8). Ready in 468.1 s; no OOM, no device fault.
- All pre-boot gates were OK: INPUTS, OVERLAY_MERGE_K6, REFERENCE_DATASET, PROMPT_IDENTITY_READY, MERLIN_INSTALL, PATCH_60490, DIGESTS_K7_K3. The rc2 oracle identity matched (record-only).

**Kernels and quantization**
- Routed experts: `HummingGroupedExperts` backend (grouped_contiguous gemm). Linears: `MarlinLinearKernel` (AutoGPTQ). quantization=inc.
- FP8 E4M3 QSA KV:
  - static per-layer scales loaded on the main model (e.g. layer 3: k 0.0180315, v 0.0123535);
  - the MTP layer 48 uses the default 1.0, as expected.

**Capacity**
- **GPU KV cache: 1,096,865 tokens = 267.8 blocks of 4096. Maximum concurrency at 131,072 tokens: 8.37×.**
  - This compares with W4 FP8 at pin 3.55 GB: 214 blocks.
  - The earlier estimate (≈463 blocks) is not what was measured at this pin.
- **Free memory after ready** (min of nvidia-smi and the worker), by card:

  | Card | 0 | 1 | 2 | 3 |
  |---|---|---|---|---|
  | Free MiB | 4,583 | 4,579 | 3,257 | 3,257 |

  The pin is NOT the limit: about 3 GiB more KV per card looks available on the PP1 cards. This is untested, and the next run should try a higher rung.

**Graphs, speculation and output**
- Captured FULL 9 and PIECEWISE 13 graphs. Draft decode is FULL_DECODE_ONLY.
- MTP K3: mean acceptance 4.00 on the probe (9 / 9 drafted tokens accepted; a tiny sample).
- Chat probes: 3 / 3 correct ("42", "4", "6"); finish stop; no garbage.

## Not measured (stopped by the false mismatch)
- The oracle, and TF 2k / 8k vs the NB0 W4 BF16 reference.
- The stream sweep 20k / 40k / 60k / 100k at levels 16 → 24 → 32.

## Next
1. Fix the probe:
   - read the real `HummingMoEMethod` bits / group;
   - find the V2 runner's MTP drafter;
   - save the raw rows;
   - label "class matches, bits unreadable" as `METHOD_CLASS_ONLY`, not CONFIG_MISMATCH.
2. Rebuild, run the CPU kits, rerun K3_ONLY.
3. Consider a higher first pin rung, given 3.2-4.5 GiB free per card.
