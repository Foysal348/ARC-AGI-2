clock: SHARED_CLOCK (measured offsets us: {'0': 0.0, '1': -1.0, '2': -0.8, '3': -1.4})

NB1 reproduction (critical path / GPU-busy union / summed kernels, ms per micro-batch):
  stage0 (rank 0, 4 verify tokens, n=20): 50.359 / 16.12 / 17.713
  stage1 (rank 2, 4 verify tokens, n=20): 14.59 / 13.947 / 15.639

steady ticks 36 of 39; tick ms mean 48.493 median 48.571; graph modes {'FULL': 36}

| category | stage0 ms (mean) | stage1 ms (mean) | stage0 % of tick | stage1 % of tick |
|---|---|---|---|---|
| compute | 22.066 | 32.679 | 45.5 | 67.4 |
| copy | 0.163 | 0.055 | 0.3 | 0.1 |
| in_graph_stall | 20.326 | 0.388 | 41.9 | 0.8 |
| nccl_peer_wait | 3.735 | 7.055 | 7.7 | 14.5 |
| nccl_tp_skew | 0.314 | 0.772 | 0.6 | 1.6 |
| nccl_transfer | 1.88 | 7.086 | 3.9 | 14.6 |
| host_launch_gap | 0.0 | 0.126 | 0.0 | 0.3 |
| host_python_gap | 0.0 | 0.06 | 0.0 | 0.1 |
| idle_no_host | 0.009 | 0.272 | 0.0 | 0.6 |
| (in_graph_stall_peer_computing, side measure) | 16.767 | 0.199 | | |
| (in_graph_stall_pp_nccl_running, side measure) | 20.254 | 0.0 | | |
| (nccl_transfer_pp, side measure) | 0.802 | 1.18 | | |
| (nccl_transfer_tp, side measure) | 1.078 | 5.906 | | |
| (nccl_transfer_peer_in_nccl, side measure) | 1.818 | 7.046 | | |
| (nccl_transfer_peer_host, side measure) | 0.017 | 0.006 | | |
| (nccl_transfer_peer_idle, side measure) | 0.044 | 0.033 | | |
| (gap = tick - compute - copy) | 26.264 | 15.759 | | |

pipeline per tick (ms): {'stage0_only_ms': 9.311, 'other_stage_only_ms': 19.821, 'both_busy_ms': 14.064, 'neither_ms': 5.298}; stage-1 idle 15.759 ms
critical path per tick (ms): {'tick_ms': 48.493, 'forward_kernel_wall_ms': 46.666, 'forward_kernel_union_ms': 25.798, 'forward_kernel_sum_ms': 28.289, 'ideal_overlapped_tick_ms': 35.142, 'serialization_ms': 13.352}
stalls: {'ticks_with_stall_over_1ms': 36, 'steady_ticks': 36, 'in_graph_stall_ms_mean': 20.304, 'released_by': {'ncclDevKernel_Broadcast_RING_LL broadcast Intx2 group [0, 2]': 18, 'ncclDevKernel_Broadcast_RING_LL broadcast Intx14 group [0, 2]': 18}, 'release_lag_us_median': 4.8, 'release_lag_us_p90': 6.8}
ideal tick: {'per_stage_busy_ms': {'stage0': 22.229, 'stage1': 32.734}, 'observed_tick_ms': 48.493, 'balanced_parity_ideal_ms': 32.734, 'bound_by': 'stage1 work', 'chain_bound_ms': 27.482, 'chain_bound_with_observed_bubble_ms': 32.779, 'rebalanced_stages_ms': 27.482, 'one_parity_serial_tick_ms': 60.261, 'gain_vs_observed_pct': 48.1, 'note': "rebalanced_stages = equal per-stage work (layer split / where the MTP draft and lm-head run); one_parity_serial = every step's work on both stages back to back (no overlap), with this run's per-step work; with all requests in one parity a step carries more requests, so its work is larger than measured here"}
micro-batch parity: UNBALANCED; n per parity: {'stage0': {'0': {'7': 20}, '1': {'1': 20}}, 'stage1': {'0': {'7': 20}, '1': {'1': 20}}}; stage step match {'compared': 40, 'matched': 40, 'meaning': 'the stage-1 step with the same index sends exactly the broadcast Seqs this stage-0 step receives (same micro-batch)'}
dependency: FALSE {'FALSE_NO_REAL_INPUT': 1, 'FALSE': 38}; step delta {'1': 39}; real input ready before graph start (ms, median / min) 9.514 / 2.658
graph mode (rev 2 rule): {'0': {'FULL': 40}, '1': {'FULL': 40}, '2': {'FULL': 40}, '3': {'FULL': 40}}; NB1 lab rule: {'0': 'PIECEWISE', '1': 'PIECEWISE', '2': 'PIECEWISE', '3': 'PIECEWISE'}