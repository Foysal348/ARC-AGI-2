# E25 NB1 R2 capacity (hosen42, sha 62670fce, 75.8 min of 240) — 2026-10-31

Output: `_scratch/e25_gpu_out/q27-xhigh-e25-nb1-capacity-r2/nb1/` (`nb1_results.json`, `lever_scorecard.json`, 3 server
logs, B1 torch traces, routing ids).
- Errors: [].
- Setup: sha 191 s, Merlin install 170 s, #60490 applied (forward test vs RC2 FP8 EXACT).
- The run ended early because the plan was done: B1 → B2 → B3. B2's load tests were skipped after its oracle gate failed.

## Boots
| boot | config vs RC2 | status | pool (tokens / blocks) | F fit | free MiB per card after ready |
|---|---|---|---|---|---|
| B1 | + text-only, profiler | DONE, CLEAN | 513,940 / 149 | 6.11 (residual max 0.82) | 2587 / 2051 / 1933 / 1933 |
| B2 | + SSM bf16, seqs 16, captures to 64, `MERLIN_SHARE_DRAFT_WORKSPACE=1`, `VLLM_RECOVERSSM_COMMIT_GRAPH=graph` | **NO_GO_ORACLE** | 513,940 / 149 | not measured | 1943 / 1943 / 1817 / 1801 |
| B3 | B1 + pin +1.0 GiB (3,553,580,524 B) | DONE, CLEAN | **738,142 / 214** | 6.3 | 1629 / 1629 / 939 / 925 (worker free 639 / 639 / 205 / 191) |

## Steady windows (90 s, real running == level, 0 preemptions, no garbage)
| window | B1 tok/s | B1 tick ms | B1 accept len | B3 tok/s | B3 tick ms | B3 accept len |
|---|---|---|---|---|---|---|
| 8k@3 | 141.3 | 33.8 | 3.18 | 141.2 | 33.8 | 3.18 |
| 8k@8 | 261.0 | 48.2 | 3.15 | 254.6 | 48.3 | 3.08 |
| 40k@5 | 196.3 | 40.5 | 3.18 | 195.6 | 40.4 | 3.16 |
| 40k@7 / 40k@8 | 227.9 (@7, B1 max) | 46.7 | 3.04 | **249.5 (@8)** | 49.9 | 3.11 |
| 90k@5 admission | NOT_ALL_RESIDENT, 1 preemption, kv 0.97 | | | **ALL_RESIDENT, 0 preemptions, kv 0.68, 187.8 tok/s, tick 41.4** | | |

The step time is the same in both boots, so the pin changes capacity only. B3 is capped at 8 streams by seqs 8 (scorecard: 70k resident streams 6 → 8). Prefill: 40k 4,487 tok/s; uncached 2,030-4,090 tok/s.

## Prefix reuse (B1)
| test | reuse |
|---|---|
| 8k two-turn | 93.0 % of turn 2 |
| 40k two-turn | 98.5 % |
| 8k after an abort (281 tokens) | 95.5 % |

**An aborted request keeps its cache on Merlin.** This was different on stock 0.32.

## B2 failure
- **Oracle vs B1: FAIL_HIGH_MARGIN.**
  - Row 1 diverges at token 31 with margin 0.75.
  - The other three are NEAR_TIE (first diff at tokens 47 / 87 / 19, margins 0.125 / 0.125 / 0.0).
  - Probes and sampled output were fine, and there is no garbage.
- **One combined configuration, so the cause is not isolated.** The most likely cause is SSM bf16, the only change that alters the math.
- **What each B2 lever did:**
  - **SSM bf16 gives no capacity in this layout.** The Mamba state per block shrinks from 1,732,992 to 946,560 B, but it is padded to the same 2 MiB page (pad 121.6 %). The pool stays at 149 blocks.
  - **`MERLIN_SHARE_DRAFT_WORKSPACE`:** "drafter does NOT share the target FlashInfer workspace (0 B)". No effect.
  - **RecoverSSM commit graph:** only n=16 was captured at warmup. Other steps ran staged-eager (eager 7 / staged 5 per worker in the census). Its speed was not measured, because the load tests were skipped.
- **→ Park C3** (SSM bf16: zero capacity plus a numeric change). The commit graph and seqs 16 need a clean A/B without SSM bf16.

## B1 profiler trace (40k-class decode, PP2)
- **Graph verdict:** PIECEWISE; eager kernel share 0.08.
- **Kernel time by category:**

  | category | share |
  |---|---|
  | NCCL | 63.5 % (top kernel `Broadcast_RING_LL` 1.71 s) |
  | Marlin MoE | 16.5 % |
  | other GEMM | 9.0 % |
  | Marlin GEMM | 3.3 % |
  | RecoverSSM commit | 2.4 % |
  | QSA | 0.7 % |

- **Stage timeline per micro-batch (16 verify tokens):**

  | stage | critical path ms | GPU-busy union ms | summed kernels ms |
  |---|---|---|---|
  | stage 0 | **50.6** | **27.2** | 29.5 |
  | stage 1 | 31.6 | 23.3 | 25.8 |

  - The binding stage is stage 0, not stage 1 with the heads.
  - The light stage is idle about 27 ms per tick.
- **Reading:** on the binding stage the GPU is busy only ~54 % of the critical path, so ~23 ms per tick is wait or gap, not compute.
  - The NCCL broadcast kernel time is that wait: the PP / TP metadata broadcast spins.
  - The tick is therefore bound by synchronisation, host scheduling and launch gaps, not by MoE bandwidth.
  - This makes the gap the largest single lever found so far. It needs a host-side timeline to split the CPU scheduler, the broadcast and launch latency.

## Decisions
- **C5 pin +1.0 GiB: ADOPT** (config only).
  - 149 → 214 blocks (+44 %), 90k@5 fully resident, 40k@8 fits.
  - The tightest rank keeps 191 MiB free in the worker; the GPU peak is 22,377 of 23,034 MiB. Do not go higher without a 120k first-prefill check.
- **C4 text-only:** frees 430-451 MiB on PP0 only, so the pin of the binding PP1 cards does not grow from it. Keep it; it is free.
- **D9 #60490:** keep. It is a safety fix with no speed change.
- **C3 SSM bf16:** park.
- **Next:**
  - seqs > 8 on the B3 pin (the pool now holds ~12-16 streams at 40k);
  - the commit graph alone;
  - a host-side timeline of the stage-0 gap.

## Re-analysis of the B1 trace with `nb4_timeline.py` (2026-11-01)
It reproduces NB1's numbers exactly. All 4 ranks share one clock, so no cross-rank correction is needed.

Tick: mean 49.66 ms (36 steady ticks).

| category, ms per tick | stage 0 | stage 1 |
|---|---|---|
| compute | 23.54 | 34.56 |
| NCCL peer wait | **20.96** | 6.97 |
| NCCL transfer | 4.54 | 6.51 |
| host launch + python + idle | 0.11 | 0.69 |

- **The stage-0 gap is not host or scheduler time.**
  - It is one in-graph stall per tick, in 36 of 36 ticks.
  - The PIECEWISE graph (1,036 kernels) stops after kernel 172 (`triton_poi_fused_add_0`).
  - It resumes 7 µs (median) after the PP `Broadcast Int x8` (stream 31, group [0,2]) ends.
  - That broadcast carries the sampled tokens. The last stage sends them in `_pp_broadcast_prev_sampled_token_ids`, and stage 0 posts an async receive in `_pp_receive_prev_sampled_token_ids_to_input_batch` (Merlin `gpu_model_runner.py:4577-4600`).
- **Each micro-batch steps every ~99 ms, but its own chain is ~50 ms** → a likely false dependency (UNVERIFIED).
  - First cheap test: `CUDA_DEVICE_MAX_CONNECTIONS` (NB4 arm S).
- **Pipeline per tick:** stage 0 alone 9.3 ms, stage 1 alone 20.2 ms, both busy 15.7 ms, neither 4.5 ms.
- **Ideal overlapped tick** = max(stage compute) = 34.6 ms, so about 15 ms per tick is serialization. That is up to −30 % tick, +43 % tok/s.
- **Stage 1 is heavier once drafting is counted.** Per tick:

  | stage-1 component | ms |
  |---|---|
  | target | 20.2 |
  | MTP drafts | 6.8 + 3.75 |
  | eager lm-head | 2.6 |
  | commit | 0.9 |
  | AllGather | 2.9 |
  | AllReduce | 3.2 |

  So after the stall is removed, stage 1 binds.
