# E25 NB3 CPU kits v1 (Kaggle, foysalemonshanto, 2026-10-31) — ALL OK on all three

Notebook under test: NB3 sha ce6921fe… (pre-audit-fix version). Image: the pinned RC2 image, Python 3.12.13. Outputs in
`_scratch/e25_nb3_kit_{mounts,merlin,units}_v1/`.

| Kit | Verdict | Minutes | Key facts |
|---|---|---|---|
| mounts | `@@KIT mounts ALL OK@@` | 4.0 | all 7 Model inputs at exact paths; merge 38 files / 27 index files, 0 bad; full sha256 OK in 228 s; 9 embedded files + audit copies identical to the blob; R7: config E 512 / topk 10 / H 2560 / I 640 / 4-bit / group 128 / symmetric; 4,608 layer-0 expert tensor names checked, 0 bad (all in model-00001-of-00017), scales BF16; D4 header shapes recorded (lm_head 248320×2560, q_proj 12288×2560, o_proj 2560×6144, HC 320×10240 / 10240×320, …) |
| merlin | `@@KIT merlin ALL OK@@` | 6.0 | offline install OK (261 s); vLLM 0.32.0 (Merlin tree), torch 2.13.0+cu130, Python 3.13 venv; **every bench import OK** incl. `fused_marlin_moe`, `_process_weights_marlin`, private `_unpack_and_dequant_int4_gptq`, `moe_align_block_size`, `determine_expert_map` (local 0..255), `marlin_moe_cfg` (52 rules parse; compiled small configs [128,128],[64,128],[128,64]; bps 1-4), skinny GEMM `is_available` True, low-latency plan caps (10,3),(10,0),(9,0),(12,1) — no (8,9) —, `QuantizedDraftLMHead`, cutlass/cute, quack; ops: `_moe_C.moe_wna16_marlin_gemm` True, `_moe_C.moe_sum` True, **`_C.gptq_marlin_repack` False** (CPU import); P5 build DONE in 28 s with Merlin GCC 13 / nvcc 13.0 (`built for sm_89`, worlds 2/4/8, cover_check world 2 clean); **`ncu` present** (Nsight Compute 2025.1.1) |
| units | `@@KIT units ALL OK@@` | 1.0 | 144/144 unit tests on Python 3.12 (Linux), fake end-to-end (every step DONE, scorecard rows D5/D7/D4/D2/PP2, routing replay, fallback) and rerun flow PASS |

## Findings that matter for the GPU run and the fix batch
1. **posix_fadvise DONTNEED works on the Model (NFS) mounts:** page cache file 28,412 MiB → 222 MiB, inactive 28,190 → 0
   after the drop. This validates the RC2 873-s-load fix (drop checkpoint cache before every boot).
2. **ncu exists on the image.** Whether the GPU box allows the DRAM counters (`ERR_NVGPUCTRPERM`) is still unknown; the
   N3-1/N3-20 fix must handle both cases.
3. **`_C.gptq_marlin_repack` not registered in the CPU import** (the MoE ops are). The D4 draft-head INT8/INT4 path may
   need it: add a GPU-side preflight for it; if absent, D4 draft heads → UNTESTED, not a failure of D4.
4. **The bench env in this kit is the MINIMAL env**, because K2 has no checkpoint (host_phase: "config.json lacks
   text_config.ple_embedding_dtype"). Expected for the kit; the RC2 kit v1 proved host_phase on the full mounts. After the
   N3-23 fix this path must be allowed only under NB3_CPU_KIT and labelled EXPLORATORY_ENV.
5. The private dequant symbol imports fine (N3-24 risk reduced; the signature preflight still goes in).
6. The SM121 plan table covers 124160×2560, 10240×320, 6656×2560, 2560×3072, 640×2560 among the NB3 shapes, not 336×10240
   or 2560×320.
7. The CPU box has a 30 GiB cgroup, so the Merlin 69 + 4 GiB host gate is false there (expected; GPU boxes have ~173 GiB).
