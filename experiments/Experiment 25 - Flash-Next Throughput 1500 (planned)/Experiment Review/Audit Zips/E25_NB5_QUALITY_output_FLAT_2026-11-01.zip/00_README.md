# E25 NB5 QUALITY: notebook + full output (flat bundle, 2026-11-01)

All files are flat. Output files keep their original path, encoded in the name with `__`. For example, `out__q27x__phase_Q_FP8_K3__duck__1818057f_b0__transcript.txt` is the file `q27x/phase_Q_FP8_K3/duck/1818057f_b0/transcript.txt`.

## What the notebook is
`Q27-XHIGH-E25_NB5_QUALITY.ipynb` (sha 9c71ba89…, profile NB5QUALITY_R2) ran on Kaggle 4×L4 under the account foysalemonshanto. It took 163 min and logged 0 errors.

**Model and engine:**
- Qwen3.8-Flash-Next W4 (Merlin checkpoint), served by Merlin v3.0.0 (vLLM 0.32 fork): TP2×PP2+EP, MTP K3 (probabilistic drafting), prefix caching, align mode, block 4096.
- Text-only, #60490 backport, KV pin +1.0 GiB (3,553,580,524 B).

**Harness:** the Duck ARC-AGI-2 adapter, config B (E15B R3K2). It is built on Tufa Labs' Duck harness (Daniel Franzen's ARC-AGI-3 milestone-2 fork, vendored verbatim).
- Long uninterrupted thinking (xhigh, 60k floor).
- 2 independent attempts per task, 104k tokens each.
- Variant A commit, a fixed seed, no stage 3.

**Design: a paired A/B in one notebook.** Two phases, each with its own boot:
- **Q_FP8_K3:** FP8 E4M3 QSA KV (pool 214 blocks, 9 workers).
- **Q_BF16_K3:** BF16 KV (pool 112 blocks, 5 workers).
- The solve windows were equal (4,050 s), and both phases used the same 15 public-eval tasks in the same order:
  - solid (7): 1818057f, 45a5af55, bf45cf4b, 2ba387bc, 8f215267, 38007db0, 58f5dbd5;
  - sometimes (5): 247ef758, f931b4a8, b5ca7ac4, 65b59efc, 221dfab4;
  - never (3): 2b83f449, 16b78196, 64efde09.

**Why:** an earlier notebook (NB0) found teacher-forced FP8-vs-BF16 KV divergence (verdict NO_GO_FP8_TF_DIVERGENCE). NB5 tests whether that shows up in real ARC solving.

## Results (from `out__q27x__nb5_report.json`, `quality_ab`)
| | FP8 KV | BF16 KV |
|---|---|---|
| tasks solved | 13 / 15 | 13 / 15 |
| test queries | 18 / 20 (pass1 17, pass2 1) | 18 / 20 (pass1 18) |
| task-norm | 86.67 % | 90.00 % |
| window tok/s | 172.0 | 158.0 |
| steady p50 tok/s | 225.0 | 169.2 |

**Paired comparison:**
- Both solved 12 tasks.
- FP8-only: 247ef758. BF16-only: 16b78196. Neither: 2b83f449.
- McNemar p = 1.0 (underpowered).

**Tokens per task (FP8, both attempts):** solid ~14k, sometimes ~50k, never ~107k. Attempt 2 added 1 query (FP8) and 0 (BF16).

The full analysis is in `E25_GPU_NB5_QUALITY_2026-11-01.md`.

## Files
**Notebook and build:**
- `Q27-XHIGH-E25_NB5_QUALITY.ipynb`
- builder `build_e25_nb5.py`
- `nb5_lib.py`
- `nb5_code_export.py`

**Output, top level:**
- the Kaggle log
- `nb5_report.json`

**Output, engine:**
- `nb5_engine.json`
- `telemetry.jsonl`
- server logs for both boots
- the install log
- all requests (`requests.jsonl`)

**Output, per phase:**
- `e12_run_report.json`
- `e12_generated_attempts.json`
- the decode summary

**Output, per task and branch:** transcript, branch result, requests, prompt log and tool state.

**Resources:**
- `arc_eval_15tasks_challenges.json` and `arc_eval_15tasks_solutions.json` (the 15 tasks);
- the results docs (NB5, NB0/NB1, NB1 R2);
- `PLAN_1500.md`;
- the NB build spec;
- the batch-fix list with its NB5 audit items.
