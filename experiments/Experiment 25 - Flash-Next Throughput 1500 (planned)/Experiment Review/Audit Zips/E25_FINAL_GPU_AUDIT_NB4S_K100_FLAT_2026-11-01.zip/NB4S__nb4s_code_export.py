# ==================================================================== CELL 1 — config, inputs, lab module (RC2 verbatim + E25 NB1 / NB4S marked edits)
import os, sys, json, math, time, re, shutil, subprocess, hashlib, tarfile, threading, traceback
from pathlib import Path
T_START = time.time()
MODE = "FULL"
RERUN = os.environ.get("KAGGLE_IS_COMPETITION_RERUN", "").strip().lower() in {"1", "true", "yes"}
FAKE = os.environ.get("E23_FAKE_SERVER")                          # local CPU harness only
BUDGET = int(os.environ.get("RC2_BUDGET_SEC") or 95 * 60)      # E25 NB4S: hard stop 95 min (B > S > QP > QD)
HARD_STOP = T_START + BUDGET
MAX_LEN = 131072                                                  # user 2026-10-29: thinking up to 120k
OUT = Path(os.environ.get("E23_OUT", "/kaggle/working/nb4s"))   # E25 NB4S
OUT.mkdir(parents=True, exist_ok=True)
LOGS = OUT / "logs"
LOGS.mkdir(exist_ok=True)
TRACES = OUT / "traces"                                           # memory rule: the full text of every long generation
TRACES.mkdir(exist_ok=True)
TMP = Path(os.environ.get("E23_TMP", "/tmp"))
INP = Path(os.environ.get("E23_INPUT", "/kaggle/input"))
R = {"what": "E25 NB4S STALL: CUDA_DEVICE_MAX_CONNECTIONS=32 vs the stage-0 in-graph stall (Flash-Next on Merlin)",   # E25 NB4S
      "budget_min": BUDGET // 60, "max_len": MAX_LEN,
     "start_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "setup": {}, "sections": {}, "errors": [], "order": []}
_SAVE_LOCK = threading.Lock()
NB1_EXTRA, NB1_ENV, NB1_KV = {}, {}, {}   # E25 NB1: per-boot trailing vllm flags, env and KV pin (filled by the boot plan)


def save():
    with _SAVE_LOCK:
        tmp = OUT / "nb4s_results.json.tmp"                      # E25 NB4S
        tmp.write_text(json.dumps(R, indent=1, default=str))
        tmp.replace(OUT / "nb4s_results.json")                   # E25 NB4S


def left():
    return HARD_STOP - time.time()


def log(*a):
    print(f"[{(time.time() - T_START) / 60:6.1f} min]", *a, flush=True)


COMP = INP / "competitions" / "arc-prize-2026-arc-agi-2"


def write_fallback_submission():
    tp = COMP / "arc-agi_test_challenges.json"
    if tp.is_file():
        tasks = json.load(open(tp))
        sub = {k: [{"attempt_1": [[0]], "attempt_2": [[0]]} for _ in v["test"]] for k, v in tasks.items()}
        Path(os.environ.get("RC2_SUBMISSION", "/kaggle/working/submission.json")).write_text(json.dumps(sub))


if RERUN:
    write_fallback_submission()
    print("E25 NB4S stall diagnostic: competition rerun -> fallback submission.json only")
else:
    LAB_SRC = "\"\"\"E23 lab, rev 3: port-parameterized server lifecycle and measurement for the six-lever notebook (stdlib only).\n\nBase: the Exp 14 VMS harness (VServer / VGen: token ids from return_token_ids, [DONE] + finish_reason required, socket\nshutdown on stop, top-1/top-2 margins, garbage checks on every window). Adopted from the consolidated v3 notebook:\nsame-weight greedy oracle classified by the oracle's logprob margin at the first differing token, a steady decode window\nthat starts only after prefill settled, a GPU-release gate, fail-closed statuses, checkpoint identity, a runtime\n--help flag check, KV + GPU memory samples.\nrev 3 (validation agents 2026-10-29, measurement + robustness):\n  - port check by connect (a TIME_WAIT socket of the previous server is not \"busy\"), with a 90 s wait;\n  - kill(): SIGKILL the whole session after SIGTERM, even when the leader already exited;\n  - steady(): idle gate at entry, admission cap from the prefill to do (700 tok/s assumed), settle needs no preemption\n    and every running stream gaining tokens; in the window: stalled streams, a changing running/waiting set (KV-bound),\n    preemptions and prefills make it INCONCLUSIVE (numbers kept); garbage under load fails it; steps from the\n    vllm:iteration_tokens_total histogram count; replicas measured in one shared window (barrier);\n  - profiled_load(): settle as steady(), bounded profile (delay / max iterations), with_stack off, frontend ignored;\n  - trace_summary(): categories on the kernel base name (attention before GDN: \"fla\" is inside \"flashinfer\"), per-forward\n    graph / kernel launch counts inside the gpu_model_runner forward ranges (VLLM_CUSTOM_SCOPES_FOR_PROFILING=1) and the\n    CUPTI correlation fallback -> FULL / PIECEWISE / EAGER / UNKNOWN; startup cudagraph lines parsed explicitly;\n  - teacher_forced(): prompt logprobs of the last N positions of a long prompt (NVFP4 vs FP8 KV at 40k / 90k);\n  - logprobs keyed by token id (return_tokens_as_token_ids); stop() race closed; compare() flags garbage only when the\n    oracle itself is clean.\n\"\"\"\nimport gzip\nimport hashlib\nimport json\nimport os\nimport re\nimport signal\nimport socket\nimport statistics\nimport subprocess\nimport threading\nimport time\nimport urllib.request as U\nfrom pathlib import Path\n\nFAIL_MARGIN = 0.5          # first differing token: oracle top-1 minus top-2 logprob at or above this = real divergence\nLIVE = set()               # every running Server, for the hard-stop watchdog\n\n\n# ------------------------------------------------------------------ server lifecycle\ndef port_listening(port):\n    \"\"\"True when something accepts connections on 127.0.0.1:port (TIME_WAIT leftovers do not).\"\"\"\n    s = socket.socket()\n    s.settimeout(1.0)\n    try:\n        s.connect((\"127.0.0.1\", int(port)))\n        return True\n    except OSError:\n        return False\n    finally:\n        s.close()\n\n\nclass Server:\n    def __init__(self, name, argv, env, port, log_dir, gpus=\"0,1,2,3\"):\n        self.name, self.argv, self.env, self.port = name, [str(a) for a in argv], dict(env), int(port)\n        self.gpus = str(gpus)\n        self.log_path = Path(log_dir) / f\"server_{name}.log\"\n        self.proc, self.t0, self.ready_sec = None, None, None\n\n    @property\n    def url(self):\n        return f\"http://127.0.0.1:{self.port}\"\n\n    def start(self):\n        end = time.time() + 90\n        while port_listening(self.port):\n            if time.time() > end:\n                raise RuntimeError(f\"PORT_BUSY {self.port} (a listener is still there)\")\n            time.sleep(3)\n        self.log_path.parent.mkdir(parents=True, exist_ok=True)\n        self._fh = open(self.log_path, \"w\", encoding=\"utf-8\")\n        self.t0 = time.perf_counter()\n        self.proc = subprocess.Popen(self.argv, env=self.env, stdout=self._fh, stderr=subprocess.STDOUT,\n                                     start_new_session=True, cwd=\"/tmp\" if os.path.isdir(\"/tmp\") else None)\n        LIVE.add(self)\n        return self\n\n    def alive(self):\n        return self.proc is not None and self.proc.poll() is None\n\n    def log(self):\n        try:\n            return self.log_path.read_text(encoding=\"utf-8\", errors=\"replace\")\n        except Exception:\n            return \"\"\n\n    def rss_mb(self):\n        \"\"\"Host RAM of the server's whole session (engine + workers), MB; None off Linux.\"\"\"\n        try:\n            r = subprocess.run([\"ps\", \"-o\", \"rss=\", \"--sid\", str(self.proc.pid)], capture_output=True, text=True, timeout=20)\n            return round(sum(int(x) for x in r.stdout.split() if x.isdigit()) / 1024, 1)\n        except Exception:\n            return None\n\n    def wait_ready(self, timeout):\n        while time.perf_counter() - self.t0 < timeout:\n            if not self.alive():\n                return False, f\"exited rc={self.proc.returncode}\"\n            try:\n                U.urlopen(self.url + \"/health\", timeout=10).read()\n                self.ready_sec = round(time.perf_counter() - self.t0, 1)\n                return True, f\"ready in {self.ready_sec}s\"\n            except Exception:\n                time.sleep(3)\n        return False, \"startup timeout\"\n\n    def kill(self):\n        if self.proc is None:\n            return\n        pg = self.proc.pid\n        try:\n            os.killpg(pg, signal.SIGTERM) if hasattr(os, \"killpg\") else self.proc.terminate()\n        except Exception:\n            pass\n        try:\n            self.proc.wait(timeout=40)\n        except Exception:\n            pass\n        # rev 3: the leader may exit while EngineCore / workers of the session still hold GPUs: always SIGKILL the group\n        try:\n            os.killpg(pg, signal.SIGKILL) if hasattr(os, \"killpg\") else self.proc.kill()\n        except Exception:\n            pass\n        try:\n            self.proc.wait(timeout=30)\n        except Exception:\n            pass\n        try:\n            self._fh.close()\n        except Exception:\n            pass\n        LIVE.discard(self)\n\n    def facts(self):\n        \"\"\"What vLLM logged at startup: KV pool, max concurrency, selected kernels, graph mode, backend, KV dtype.\"\"\"\n        t = self.log()\n        kv = [int(x.replace(\",\", \"\")) for x in re.findall(r\"GPU KV cache size: ([\\d,]+) tokens\", t)]\n        mc = re.findall(r\"Maximum concurrency for [\\d,]+ tokens per request: ([\\d.]+)x\", t)\n        kern = sorted(set(re.findall(r\"Selected (\\w+Kernel) for\", t)))\n        errs = [l[:300] for l in t.splitlines() if re.search(r\"Traceback|CUDA error|illegal memory|out of memory|\"\n                                                               r\"RuntimeError|AssertionError\", l)][:12]\n        pick = lambda pat, n=8: [l.strip()[:240] for l in t.splitlines() if re.search(pat, l, re.I)][:n]\n        # rev 3 (measurement H5): the decisive startup evidence for the graph mode actually used with spec decode\n        downgrade = pick(r\"not supported with spec-decode.*setting cudagraph_mode|setting cudagraph_mode\\s*=|\"\n                         r\"[Oo]verriding cudagraph_mode to\", 4)       # rev 3e: + the 0.32 wording\n        capture = sorted(set(re.findall(r\"Capturing CUDA graphs \\(([^)]+)\\)\", t)))\n        configured = sorted(set(re.findall(r\"CUDAGraphMode\\.(\\w+)\", t)))\n        return {\"kv_tokens\": min(kv) if kv else None, \"kv_tokens_all\": kv, \"max_concurrency\": float(mc[-1]) if mc else None,\n                \"kernels\": kern, \"error_lines\": errs, \"ready_sec\": self.ready_sec,\n                \"graph_capture_modes\": capture, \"graph_downgrade_lines\": downgrade, \"cudagraph_modes_logged\": configured,\n                \"backend_lines\": pick(r\"attention backend|Using \\w+ backend|backend=|AttentionBackend\"),\n                \"kv_dtype_lines\": pick(r\"kv_cache_dtype|kv cache dtype|nvfp4\"),\n                \"host_embed_lines\": pick(r\"host[- _]?(resident|embed)|HOST_EMBED|embed.*(cpu|host)\", 6)}\n\n\ndef gpu_pids(gpus=None):\n    \"\"\"Compute PIDs on all GPUs, or only on the GPU indices in `gpus` (a bench on another GPU must not fail the release\n    gate of a server that used GPU 0 only). None when nvidia-smi is unavailable.\"\"\"\n    try:\n        a = subprocess.run([\"nvidia-smi\", \"--query-compute-apps=pid,gpu_uuid\", \"--format=csv,noheader,nounits\"],\n                           capture_output=True, text=True, timeout=30)\n        g = subprocess.run([\"nvidia-smi\", \"--query-gpu=index,uuid\", \"--format=csv,noheader,nounits\"],\n                           capture_output=True, text=True, timeout=30)\n    except Exception:\n        return None\n    if a.returncode or g.returncode:\n        return None\n    idx = {u.strip(): int(i) for i, u in (l.split(\",\", 1) for l in g.stdout.strip().splitlines() if \",\" in l)}\n    want = None if gpus is None else {int(x) for x in str(gpus).split(\",\") if str(x).strip() != \"\"}\n    out = set()\n    for l in a.stdout.strip().splitlines():\n        if \",\" not in l:\n            continue\n        pid, uuid = (x.strip() for x in l.split(\",\", 1))\n        if pid.isdigit() and (want is None or idx.get(uuid) in want):\n            out.add(int(pid))\n    return sorted(out)\n\n\ndef gpu_mem():\n    try:\n        r = subprocess.run([\"nvidia-smi\", \"--query-gpu=index,memory.used,memory.total\", \"--format=csv,noheader,nounits\"],\n                           capture_output=True, text=True, timeout=30)\n        return [[int(v) for v in l.split(\",\")] for l in r.stdout.strip().splitlines() if l.strip()]\n    except Exception:\n        return None\n\n\ndef wait_gpu_release(timeout=180, fake=False, gpus=None, free_mib=1024):\n    \"\"\"True when the GPUs in `gpus` (all when None) hold no compute PID AND use < free_mib MiB each (rev 3: compute-app\n    PIDs are often invisible inside Kaggle containers; memory.used is the proven E18 gate); None without nvidia-smi.\"\"\"\n    if fake:\n        return True\n    want = None if gpus is None else {int(x) for x in str(gpus).split(\",\") if str(x).strip() != \"\"}\n    end = time.time() + timeout\n    while time.time() < end:\n        p, mem = gpu_pids(gpus), gpu_mem()\n        if p is None or mem is None:\n            return None\n        used = [m[1] for m in mem if want is None or m[0] in want]\n        if not p and all(u < free_mib for u in used):\n            return True\n        time.sleep(3)\n    return False\n\n\ndef identity(model_dir):\n    \"\"\"Checkpoint identity: sha256 of config / tokenizer / index files (an oracle is only compared with the same weights).\"\"\"\n    root = Path(model_dir)\n    files = [p for n in (\"config.json\", \"tokenizer.json\", \"tokenizer_config.json\", \"generation_config.json\")\n             for p in [root / n] if p.is_file()] + sorted(root.glob(\"*.safetensors.index.json\"))\n    h = hashlib.sha256()\n    for p in files:\n        h.update(p.name.encode())\n        h.update(hashlib.sha256(p.read_bytes()).digest())\n    return {\"dir\": str(root), \"files\": [p.name for p in files], \"sha256\": h.hexdigest()[:16]}\n\n\n_HELP = {}\n\n\ndef help_check(key, argv_prefix, env, flags, timeout=300):\n    \"\"\"The engine's own `serve --help=all` (run once per engine `key`, cached) must list every flag of THIS launch\n    (rev 3: every launch is checked, not only the first); returns the missing ones.\"\"\"\n    if key not in _HELP:\n        try:\n            r = subprocess.run(list(argv_prefix) + [\"--help=all\"], capture_output=True, text=True, timeout=timeout, env=env)\n            _HELP[key] = r.stdout + r.stderr\n        except Exception as e:\n            _HELP[key] = \"ERROR \" + repr(e)[:200]\n    txt = _HELP[key]\n    if len(txt) < 2000:\n        return {\"ran\": False, \"error\": \"help output too short or failed\", \"tail\": txt[-400:]}\n    want = sorted({f for f in flags if isinstance(f, str) and f.startswith(\"--\")})\n    return {\"ran\": True, \"missing\": [f for f in want if f not in txt]}\n\n\ndef start_watchdog(hard_stop_epoch, on_fire):\n    \"\"\"A real hard stop: at `hard_stop_epoch` every live Server is killed and on_fire() is called.\"\"\"\n    def run():\n        while time.time() < hard_stop_epoch:\n            time.sleep(5)\n        try:\n            on_fire()\n        finally:\n            for s in list(LIVE):\n                try:\n                    s.kill()\n                except Exception:\n                    pass\n    t = threading.Thread(target=run, daemon=True, name=\"e23-watchdog\")\n    t.start()\n    return t\n\n\ndef prefetch(paths, threads=16, chunk=16 << 20):\n    \"\"\"Read files once with many readers (page cache warm-up of a cold /kaggle/input mount); returns bytes and seconds.\"\"\"\n    files = [p for root in paths for p in sorted(Path(root).rglob(\"*\")) if p.is_file()]\n    t0, done, lock = time.time(), [0], threading.Lock()\n\n    def worker(fs):\n        for p in fs:\n            try:\n                with open(p, \"rb\") as f:\n                    while True:\n                        b = f.read(chunk)\n                        if not b:\n                            break\n                        with lock:\n                            done[0] += len(b)\n            except Exception:\n                pass\n    big = sorted(files, key=lambda p: -p.stat().st_size)\n    parts = [big[i::threads] for i in range(threads)]\n    ths = [threading.Thread(target=worker, args=(x,), daemon=True) for x in parts if x]\n    for t in ths:\n        t.start()\n    for t in ths:\n        t.join()\n    dt = time.time() - t0\n    return {\"files\": len(files), \"bytes\": done[0], \"sec\": round(dt, 1), \"MBps\": round(done[0] / 1e6 / max(dt, 1e-3), 1)}\n\n\n# ------------------------------------------------------------------ metrics\ndef prom(port):\n    txt = U.urlopen(f\"http://127.0.0.1:{port}/metrics\", timeout=15).read().decode(\"utf-8\", \"replace\")\n    out = {}\n    for line in txt.splitlines():\n        if not line or line.startswith(\"#\"):\n            continue\n        m = re.match(r\"^([A-Za-z_:][A-Za-z0-9_:]*)(\\{[^}]*\\})?\\s+(\\S+)\", line)\n        if not m:\n            continue\n        try:\n            v = float(m.group(3))\n        except ValueError:\n            continue\n        if v != v:\n            continue\n        out[m.group(1)] = out.get(m.group(1), 0.0) + v\n        out[m.group(1) + \"@max\"] = max(out.get(m.group(1) + \"@max\", v), v)\n    return out\n\n\nGEN, PROMPT, RUN, WAIT = (\"vllm:generation_tokens_total\", \"vllm:prompt_tokens_total\", \"vllm:num_requests_running\",\n                          \"vllm:num_requests_waiting\")\nPREEMPT, KVU, ITER = \"vllm:num_preemptions_total\", \"vllm:kv_cache_usage_perc\", \"vllm:iteration_tokens_total_count\"\nACC, DRF, DTOK = (\"vllm:spec_decode_num_accepted_tokens_total\", \"vllm:spec_decode_num_drafts_total\",\n                  \"vllm:spec_decode_num_draft_tokens_total\")\n\n\n# ------------------------------------------------------------------ one streaming request (Exp 14 VGen, port-aware)\nclass Stream(threading.Thread):\n    def __init__(self, port, ids, max_new, temperature=1.0, seed=None, logprobs=0, ignore_eos=True, model=\"q27\"):\n        super().__init__(daemon=True)\n        self.port = int(port)\n        self.body = {\"model\": model, \"prompt\": list(ids), \"max_tokens\": int(max_new), \"temperature\": temperature,\n                     \"top_p\": 0.95 if temperature else 1.0, \"stream\": True, \"ignore_eos\": ignore_eos, \"return_token_ids\": True}\n        if temperature:\n            self.body[\"top_k\"] = 20\n        if seed is not None:\n            self.body[\"seed\"] = int(seed)\n        if logprobs:\n            self.body[\"logprobs\"] = int(logprobs)\n            self.body[\"return_tokens_as_token_ids\"] = True      # rev 3: logprob keys by id (no string collisions)\n        self.text, self.tokens, self.margins = [], [], []\n        self.err, self.done_seen, self.finish_reason = None, False, None\n        self.t_start = self.t_first = self.t_end = None\n        self._resp, self._halt = None, False\n\n    def run(self):\n        self.t_start = time.perf_counter()\n        try:\n            req = U.Request(f\"http://127.0.0.1:{self.port}/v1/completions\", data=json.dumps(self.body).encode(),\n                            method=\"POST\", headers={\"Content-Type\": \"application/json\"})\n            self._resp = U.urlopen(req, timeout=7200)\n            for raw in self._resp:\n                if self._halt:\n                    break\n                line = raw.strip()\n                if not line.startswith(b\"data:\"):\n                    continue\n                payload = line[5:].strip()\n                if payload == b\"[DONE]\":\n                    self.done_seen = True\n                    break\n                d = json.loads(payload)\n                if \"error\" in d or d.get(\"object\") == \"error\":\n                    self.err = (\"stream error: \" + json.dumps(d.get(\"error\") or d.get(\"message\") or d))[:300]\n                    break\n                for c in d.get(\"choices\") or []:\n                    self.text.append(c.get(\"text\") or \"\")\n                    ids_ = c.get(\"token_ids\")\n                    lp = c.get(\"logprobs\") or {}\n                    if ids_ is None:\n                        if c.get(\"text\") or lp.get(\"tokens\"):\n                            self.err = \"MISSING_STREAM_TOKEN_IDS\"\n                    elif any(not isinstance(v, int) or isinstance(v, bool) for v in ids_):\n                        self.err = \"INVALID_STREAM_TOKEN_IDS\"\n                    else:\n                        if ids_ and self.t_first is None:\n                            self.t_first = time.perf_counter()\n                        self.tokens.extend(ids_)\n                    for top in lp.get(\"top_logprobs\") or []:\n                        vals = sorted((v for v in (top or {}).values() if isinstance(v, (int, float))), reverse=True)\n                        self.margins.append(round(vals[0] - vals[1], 4) if len(vals) >= 2 else None)\n                    if c.get(\"finish_reason\") is not None:\n                        self.finish_reason = c[\"finish_reason\"]\n                if self.err:\n                    break\n        except Exception as e:\n            if not self._halt:\n                self.err = repr(e)[:300]\n        finally:                         # rev 3: a stop() before the response existed still closes the socket here\n            try:\n                if self._resp is not None:\n                    self._resp.close()\n            except Exception:\n                pass\n        self.t_end = time.perf_counter()\n        if not self._halt and not self.err and not (self.done_seen and self.finish_reason):\n            self.err = f\"INCOMPLETE_SSE done={self.done_seen} finish={self.finish_reason}\"\n\n    def stop(self):\n        self._halt = True\n        try:\n            self._resp.fp.raw._sock.shutdown(socket.SHUT_RDWR)\n        except Exception:\n            pass\n        try:\n            if self._resp is not None:\n                self._resp.close()\n        except Exception:\n            pass\n\n    def row(self):\n        return {\"text\": \"\".join(self.text), \"tokens\": list(self.tokens), \"margins\": list(self.margins), \"error\": self.err,\n                \"done\": self.done_seen, \"finish_reason\": self.finish_reason}\n\n\n# ------------------------------------------------------------------ correctness\ndef greedy(port, prompts, n_tok=128, logprobs=2, timeout=900, model=\"q27\"):\n    \"\"\"Greedy rows for the same-weight oracle (one request at a time: batch-size effects stay out of the comparison).\"\"\"\n    rows = []\n    for ids in prompts:\n        g = Stream(port, ids, n_tok, temperature=0.0, logprobs=logprobs, ignore_eos=True, model=model)\n        g.start()\n        g.join(timeout)\n        if g.is_alive():\n            g.stop()\n            g.join(10)\n            r = g.row()\n            r[\"error\"] = r[\"error\"] or \"GREEDY_TIMEOUT\"\n        else:\n            r = g.row()\n        rows.append(r)\n    return rows\n\n\ndef degenerate(text):\n    \"\"\"Objective garbage checks: empty, a run of one char, '!!!!' (the E3 / E13 garbage), very low variety.\"\"\"\n    t = text or \"\"\n    if not t.strip():\n        return \"EMPTY\"\n    if re.search(r\"(\\S)\\1{200,}\", t, re.S):      # rev 3: grid rows / separators are not garbage\n        return \"REPEATED_CHAR\"\n    if t.count(\"!\") > 0.5 * max(1, len(t)):\n        return \"BANG_GARBAGE\"\n    words = re.findall(r\"[A-Za-z]{3,}\", t)            # rev 3c: words only; ARC grid dumps (digits) are not garbage\n    if len(words) > 60 and len(set(words)) < 0.08 * len(words):\n        return \"LOW_VARIETY\"\n    return None\n\n\ndef compare(ref, cand):\n    \"\"\"Same-weight oracle: at the first differing token the ORACLE's top-1 - top-2 logprob margin decides:\n    >= FAIL_MARGIN -> FAIL_HIGH_MARGIN, below -> NEAR_TIE; identical -> EXACT; missing data -> INCONCLUSIVE.\"\"\"\n    if not ref or not cand or len(ref) != len(cand):\n        return {\"status\": \"INCONCLUSIVE_PAIRS_MISSING\"}\n    per, worst = [], \"EXACT\"\n    rank = {\"EXACT\": 0, \"NEAR_TIE\": 1, \"INCONCLUSIVE\": 2, \"FAIL_HIGH_MARGIN\": 3}\n    for a, b in zip(ref, cand):\n        if a.get(\"error\") or b.get(\"error\") or not a.get(\"tokens\") or not b.get(\"tokens\"):\n            st, d, m = \"INCONCLUSIVE\", None, None\n        else:\n            x, y = a[\"tokens\"], b[\"tokens\"]\n            d = next((i for i in range(min(len(x), len(y))) if x[i] != y[i]), None)\n            if d is None:\n                st, m = (\"EXACT\" if len(x) == len(y) else \"INCONCLUSIVE\"), None\n            else:\n                mm = a.get(\"margins\") or []\n                m = mm[d] if d < len(mm) else None\n                st = \"INCONCLUSIVE\" if m is None else (\"FAIL_HIGH_MARGIN\" if m >= FAIL_MARGIN else \"NEAR_TIE\")\n        g = degenerate(b.get(\"text\")) if (b.get(\"tokens\") and not b.get(\"error\")) else None\n        if g and degenerate(a.get(\"text\")) is None:           # rev 3c: a request error is not corruption\n            st = \"FAIL_HIGH_MARGIN\"\n        per.append({\"first_diff\": d, \"oracle_margin\": m, \"status\": st, \"garbage\": g})\n        worst = st if rank[st] > rank[worst] else worst\n    return {\"status\": worst, \"rows\": per}\n\n\ndef chat_probes(port, model=\"q27\", cases=((\"Reply with exactly one number: 7 * 6 =\", \"42\"),\n                                          (\"Reply with exactly one number: 2 + 2 =\", \"4\"),\n                                          (\"Reply with exactly one number: 9 - 3 =\", \"6\")), timeout=300):\n    \"\"\"Arithmetic through /v1/chat/completions with thinking off. vLLM 0.32 returns the answer in message.content and\n    the thinking in message.reasoning (NOT reasoning_content: the consolidated notebook's blocker).\"\"\"\n    out = []\n    for q, want in cases:\n        body = {\"model\": model, \"messages\": [{\"role\": \"user\", \"content\": q}], \"temperature\": 0, \"max_tokens\": 32,\n                \"chat_template_kwargs\": {\"enable_thinking\": False}}\n        try:\n            r = json.loads(U.urlopen(U.Request(f\"http://127.0.0.1:{port}/v1/chat/completions\", data=json.dumps(body).encode(),\n                                               headers={\"Content-Type\": \"application/json\"}), timeout=timeout).read())\n            msg = r[\"choices\"][0][\"message\"]\n            got = (msg.get(\"content\") or \"\").strip()\n            out.append({\"q\": q, \"want\": want, \"content\": got[:80], \"reasoning_chars\": len(msg.get(\"reasoning\") or \"\"),\n                        \"ok\": re.search(r\"(?<!\\d)\" + want + r\"(?!\\d)\", got) is not None})\n        except Exception as e:\n            out.append({\"q\": q, \"want\": want, \"error\": repr(e)[:200], \"ok\": False})\n    return {\"ok\": all(x[\"ok\"] for x in out), \"cases\": out}\n\n\ndef template_probe(port, messages, want_ids, model=\"q27\", timeout=120):\n    \"\"\"rev 3h (three GPT SMOKE audits): what the SERVER's chat path renders for `messages` (its own template and default\n    chat-template kwargs, no per-request kwargs) against the production xhigh render `want_ids`. MATCH / MISMATCH /\n    ERROR; the load requests themselves use pre-rendered ids, so this shows chat-path equivalence only.\"\"\"\n    body = {\"model\": model, \"messages\": messages, \"add_generation_prompt\": True}\n    try:\n        r = json.loads(U.urlopen(U.Request(f\"http://127.0.0.1:{port}/tokenize\", data=json.dumps(body).encode(),\n                                           headers={\"Content-Type\": \"application/json\"}), timeout=timeout).read())\n        got = list(r.get(\"tokens\") or [])\n    except Exception as e:\n        return {\"status\": \"ERROR\", \"error\": repr(e)[:200]}\n    want = list(want_ids)\n    first = next((i for i, (a, b) in enumerate(zip(got, want)) if a != b), None if len(got) == len(want) else min(len(got), len(want)))\n    return {\"status\": \"MATCH\" if got == want else \"MISMATCH\", \"server_tokens\": len(got), \"want_tokens\": len(want),\n            \"first_diff\": first}\n\n\ndef teacher_forced(port, ids, last=256, model=\"q27\", timeout=1800):\n    \"\"\"rev 3 (measurement M3): prompt logprobs of the last `last` positions of a long prompt (one prefill, 1 token out),\n    for a lossy-KV comparison (NVFP4 vs FP8 KV) at the context lengths that matter. Returns per-position\n    [logprob of the actual token, its rank, the engine's own rank-1 token id] or an error. rev 3h (three GPT SMOKE\n    audits): the rank-1 token id is kept, so top-1 agreement compares the two engines' predictions.\"\"\"\n    body = {\"model\": model, \"prompt\": list(ids), \"max_tokens\": 1, \"temperature\": 0, \"prompt_logprobs\": 1,\n            \"return_tokens_as_token_ids\": True}\n    try:\n        r = json.loads(U.urlopen(U.Request(f\"http://127.0.0.1:{port}/v1/completions\", data=json.dumps(body).encode(),\n                                           headers={\"Content-Type\": \"application/json\"}), timeout=timeout).read())\n        pl = r[\"choices\"][0].get(\"prompt_logprobs\") or []\n    except Exception as e:\n        return {\"error\": repr(e)[:300]}\n    out = []\n    for pos in range(max(1, len(ids) - last), len(ids)):\n        d = pl[pos] if pos < len(pl) else None\n        if not isinstance(d, dict):\n            out.append(None)\n            continue\n        e = d.get(str(ids[pos])) or d.get(f\"token_id:{ids[pos]}\")     # rev 3c: no fallback to another token\n        top1 = [_tok_id(k) for k, v in d.items() if isinstance(v, dict) and v.get(\"rank\") == 1]\n        out.append([e.get(\"logprob\"), e.get(\"rank\"), top1[0] if len(top1) == 1 else None] if isinstance(e, dict) else None)\n    return {\"positions\": out, \"n\": len(out)}\n\n\ndef _tok_id(k):\n    \"\"\"A prompt-logprob key ('123' or 'token_id:123') as an int id; anything else stays a tagged string.\"\"\"\n    m = re.fullmatch(r\"(?:token_id:)?(-?\\d+)\", str(k))\n    return int(m.group(1)) if m else \"str:\" + str(k)\n\n\ndef compare_tf(ref, cand):\n    \"\"\"Teacher-forced comparison: mean / max |delta logprob| of the actual tokens and rank-1 agreement. rev 3d (four\n    GPT audits): MEASURED only when EVERY expected position is valid on both sides (1 of 256 used to be MEASURED);\n    MEASURED is a measurement, not a PASS (the caller applies the A/A-derived tolerance).\"\"\"\n    if not ref or not cand or ref.get(\"error\") or cand.get(\"error\"):\n        return {\"status\": \"INCONCLUSIVE\"}\n    a_, b_ = ref.get(\"positions\") or [], cand.get(\"positions\") or []\n    if not a_ or len(a_) != len(b_):\n        return {\"status\": \"INCONCLUSIVE_INCOMPLETE_TF\", \"ref_n\": len(a_), \"cand_n\": len(b_)}\n    if any(not a or not b or a[0] is None or b[0] is None for a, b in zip(a_, b_)):\n        return {\"status\": \"INCONCLUSIVE_INCOMPLETE_TF\", \"valid\": sum(1 for a, b in zip(a_, b_) if a and b and a[0] is not None\n                                                                     and b[0] is not None), \"expected\": len(a_)}\n    pairs = list(zip(a_, b_))\n    if any(len(a) < 3 or len(b) < 3 or a[2] is None or b[2] is None for a, b in pairs):\n        return {\"status\": \"INCONCLUSIVE_TOP1_MISSING\", \"expected\": len(pairs),\n                \"with_top1\": sum(1 for a, b in pairs if len(a) >= 3 and len(b) >= 3 and a[2] is not None and b[2] is not None)}\n    d = sorted(abs(a[0] - b[0]) for a, b in pairs)\n    # rev 3h (three GPT SMOKE audits): top-1 agreement = both engines predict the same rank-1 token id. rev 3d-3g counted\n    # \"the forced token is rank 1 on both sides or on neither\", which reads 1.0 for ranks 2 vs 3.\n    r1 = sum(1 for a, b in pairs if a[2] == b[2]) / len(pairs)\n    both = sum(1 for a, b in pairs if (a[1] == 1) == (b[1] == 1)) / len(pairs)\n    p99 = d[min(len(d) - 1, int(round(0.99 * (len(d) - 1))))]          # rev 3e: robust to one outlier position\n    return {\"status\": \"MEASURED\", \"n\": len(pairs), \"mean_abs_dlogprob\": round(statistics.mean(d), 4),\n            \"p99_abs_dlogprob\": round(p99, 3), \"max_abs_dlogprob\": round(d[-1], 3), \"rank1_agreement\": round(r1, 4),\n            \"forced_token_rank1_both_or_neither\": round(both, 4)}\n\n\ndef tf_complete(rows):\n    \"\"\"rev 3e: a teacher-forced row set counts as a reference only when every position of every band is valid\n    (rev 3h: including the rank-1 token id).\"\"\"\n    return bool(rows) and all(isinstance(r, dict) and not r.get(\"error\") and r.get(\"positions\") and\n                              all(p and p[0] is not None and len(p) >= 3 and p[2] is not None for p in r[\"positions\"])\n                              for r in rows.values())\n\n\n# ------------------------------------------------------------------ steady decode\ndef steady(port, prompts, level, secs=60.0, admit=None, max_new=8192, temperature=1.0, seed=1234, model=\"q27\",\n           sample=2.0, prefill_tok_s=700.0, gpu_sample=True, barrier=None):\n    \"\"\"`level` distinct prompts, then a decode window that starts only once prefill has settled. Status:\n    STEADY / CAPACITY_LIMITED (fewer running than asked: KV) / INCONCLUSIVE_* / FAIL_*; numbers are kept on an\n    INCONCLUSIVE window so a KV census survives; never a made-up number. `barrier` (steady_multi) starts every replica's\n    window at the same moment.\"\"\"\n    plen = len(prompts[0]) if prompts else 0\n    admit = admit or max(420.0, 120.0 + level * plen / prefill_tok_s)\n    r = {\"level\": level, \"status\": \"INCONCLUSIVE_NOT_STARTED\", \"port\": port, \"prompt_tokens\": plen, \"max_new\": max_new,\n         \"admit_limit_sec\": round(admit)}\n    if not wait_idle(port, 60):\n        r[\"status\"] = \"INCONCLUSIVE_NOT_IDLE_AT_START\"\n        if barrier:\n            barrier.abort()\n        return r\n    try:\n        p0 = prom(port)\n    except Exception as e:\n        r.update(status=\"INCONCLUSIVE_METRICS_UNAVAILABLE\", error=repr(e)[:200])\n        if barrier:\n            barrier.abort()\n        return r\n    if GEN not in p0 or PROMPT not in p0:\n        r[\"status\"] = \"INCONCLUSIVE_COUNTERS_MISSING\"\n        if barrier:\n            barrier.abort()\n        return r\n    ss = [Stream(port, prompts[i % len(prompts)], max_new, temperature, seed + i, model=model) for i in range(level)]\n    for g in ss:\n        g.start()\n    try:\n        t_adm, best, settled, prev, samples, flat_since = time.perf_counter(), 0, 0, None, [], None\n        last_tok = [0] * len(ss)\n        while time.perf_counter() - t_adm < admit:\n            time.sleep(sample)\n            if all(not g.is_alive() for g in ss):          # rev 3: checked before the metrics read (a dead server)\n                r.update(status=\"INCONCLUSIVE_STREAMS_ENDED_IN_ADMISSION\", errors=[g.err for g in ss if g.err][:3])\n                if barrier:\n                    barrier.abort()                       # rev 3c: the other replicas must not wait for this one\n                return r\n            try:\n                m = prom(port)\n            except Exception:\n                continue\n            run, wait, pt, pre = int(m.get(RUN, 0)), int(m.get(WAIT, 0)), m.get(PROMPT), m.get(PREEMPT, 0)\n            now_tok = [len(g.tokens) for g in ss]\n            first = sum(g.t_first is not None for g in ss)\n            gaining = sum(1 for a, b in zip(last_tok, now_tok) if b > a)\n            last_tok = now_tok\n            best = max(best, run)\n            samples.append([round(time.perf_counter() - t_adm, 1), run, wait, first, gaining])\n            # rev 3: no preemption in the sample, every running request emitted and is gaining tokens\n            calm = run > 0 and prev is not None and pt == prev[0] and pre == prev[1] and first >= run and gaining >= run\n            if calm and run >= level and wait == 0:\n                settled += 1\n            elif calm and run < level and wait > 0:       # KV-bound: the rest wait; accept a plateau held 30 s\n                flat_since = flat_since or time.perf_counter()\n                settled = settled + 1 if time.perf_counter() - flat_since > 30 else 0\n            else:\n                settled, flat_since = 0, None\n            prev = (pt, pre)\n            if settled >= 3:\n                break\n        r[\"admission\"] = {\"sec\": round(time.perf_counter() - t_adm, 1), \"best_running\": best, \"tail\": samples[-6:],\n                          \"prefill_tok_s\": round((prom(port).get(PROMPT, 0) - p0.get(PROMPT, 0)) /\n                                                 max(1e-3, time.perf_counter() - t_adm), 1)}\n        if settled < 3:\n            r[\"status\"] = \"INCONCLUSIVE_NO_SETTLE\"\n            if barrier:\n                barrier.abort()\n            return r\n        if barrier:\n            try:\n                barrier.wait(timeout=max(60.0, admit))\n            except threading.BrokenBarrierError:\n                r[\"status\"] = \"INCONCLUSIVE_REPLICA_BARRIER\"\n                return r\n        m0, t0 = prom(port), time.perf_counter()\n        runs, waits, kvs, mids, gmem, stalls = [], [], [], [], [], [0] * len(ss)\n        last_tok, track, misses = [len(g.tokens) for g in ss], None, 0\n        while time.perf_counter() - t0 < secs:\n            time.sleep(min(sample, max(0.1, secs - (time.perf_counter() - t0))))\n            try:\n                m = prom(port)\n            except Exception:                              # rev 3c: one failed metrics read is not a crash\n                misses += 1\n                if misses >= 5:\n                    break\n                continue\n            mids.append(m)\n            runs.append(m.get(RUN, 0))\n            waits.append(m.get(WAIT, 0))\n            if KVU in m:\n                kvs.append(m[KVU])\n            now_tok = [len(g.tokens) for g in ss]\n            if track is None:                              # rev 3c: only streams decoding at window start can stall\n                track = {i for i in range(len(ss)) if now_tok[i] > last_tok[i]}\n            for i, g in enumerate(ss):\n                if i in track and g.is_alive():\n                    stalls[i] = stalls[i] + 1 if now_tok[i] <= last_tok[i] else 0\n            last_tok = now_tok\n            if any(x >= 3 for x in stalls):\n                break\n            if gpu_sample and len(mids) % 5 == 1:\n                g_ = gpu_mem()\n                if g_:\n                    gmem.append(g_)\n        m1, t1 = prom(port), time.perf_counter()\n        gen = m1.get(GEN, 0) - m0.get(GEN, 0)\n        dt = t1 - t0\n        acc, drf, dtk, it = (m1.get(k, 0) - m0.get(k, 0) for k in (ACC, DRF, DTOK, ITER))\n        rm = statistics.mean(runs) if runs else 0\n        steps = it if it else ((drf / rm) if (drf and rm) else ((gen / rm) if rm else 0))\n        r.update(tok_s=round(gen / dt, 1) if dt else None, gen_tokens=int(gen), window_sec=round(dt, 1),\n                 running_mean=round(rm, 2), running_min=min(runs or [0]), running_max=max(runs or [0]),\n                 waiting_min=min(waits or [0]), waiting_max=max(waits or [0]),\n                 tok_s_per_stream=round(gen / dt / rm, 2) if rm and dt else None,\n                 accept_per_draft=round(acc / drf, 3) if drf else None,\n                 mean_acceptance_length=round(1 + acc / drf, 3) if drf else None,\n                 accept_rate=round(acc / dtk, 3) if dtk else None,\n                 steps=int(steps), steps_source=\"iteration_histogram\" if it else \"estimate\",\n                 step_ms=round(dt * 1000 / steps, 1) if steps else None,\n                 tokens_per_step=round(gen / steps, 2) if steps else None,\n                 kv_usage_mean=round(statistics.mean(kvs), 3) if kvs else None, kv_usage_max=max(kvs) if kvs else None,\n                 gpu_mem_peak_mib=[max(row[i][1] for row in gmem if len(row) > i) for i in range(max(map(len, gmem)))] if gmem else None,\n                 preemptions=m1.get(PREEMPT, 0) - m0.get(PREEMPT, 0), t0=t0, t1=t1)\n        if misses >= 5:\n            r[\"status\"] = \"INCONCLUSIVE_METRICS_LOST\"\n        elif any(x >= 3 for x in stalls):\n            r[\"status\"] = \"INCONCLUSIVE_STALLED_STREAM\"\n        elif sum(g.is_alive() for g in ss) < min(level, best):\n            r[\"status\"] = \"INCONCLUSIVE_STREAMS_ENDED_IN_WINDOW\"\n        elif any(x.get(PROMPT) != m0.get(PROMPT) for x in mids + [m1]):\n            r[\"status\"] = \"INCONCLUSIVE_PREFILL_IN_WINDOW\"\n        elif r[\"preemptions\"] > 0:\n            r[\"status\"] = \"INCONCLUSIVE_PREEMPTION\"\n        elif gen <= 0:\n            r[\"status\"] = \"FAIL_NO_DECODE\"\n        elif min(runs or [0]) < level and (len(set(runs)) > 1 or len(set(waits)) > 1):\n            r[\"status\"] = \"INCONCLUSIVE_RUNNING_SET_CHANGED\"      # KV-bound window must hold one fixed set\n        elif min(runs or [0]) < 0.8 * max(runs or [1]):\n            r[\"status\"] = \"INCONCLUSIVE_RUNNING_UNSTABLE\"\n        else:\n            r[\"status\"] = (\"STEADY\" if min(runs or [0]) == max(runs or [0]) == level else\n                           \"CAPACITY_LIMITED\" if max(runs or [0]) < level else \"INCONCLUSIVE_RUNNING_ABOVE_LEVEL\")\n        return r\n    finally:\n        errs = sorted({g.err for g in ss if g.err})[:3]           # rev 3: snapshot before stop() sets _halt\n        for g in ss:\n            g.stop()\n        for g in ss:\n            g.join(10)\n        r[\"client_leak\"] = any(g.is_alive() for g in ss)\n        r[\"stream_errors\"] = errs\n        gb = [degenerate(\"\".join(g.text)[-4000:]) if g.tokens else None for g in ss]\n        r[\"garbage\"] = {\"streams\": len(ss), \"with_output\": sum(1 for g in ss if g.tokens),\n                        \"garbage\": [x for x in gb if x], \"sample_tail\": \"\".join(ss[0].text)[-200:] if ss and ss[0].tokens else \"\"}\n        if r[\"garbage\"][\"garbage\"] and r.get(\"status\") in (\"STEADY\", \"CAPACITY_LIMITED\"):\n            r[\"status\"] = \"FAIL_GARBAGE_UNDER_LOAD\"\n        r[\"idle_after\"] = wait_idle(port)\n\n\ndef steady_multi(jobs, secs=60.0, **kw):\n    \"\"\"Several servers at once (TP1 replicas): jobs = [(port, prompts, level)]; one shared window (barrier). The aggregate\n    counts only when every window is STEADY / CAPACITY_LIMITED and the windows overlap >= 80 % of the shortest.\"\"\"\n    out = [None] * len(jobs)\n    bar = threading.Barrier(len(jobs))\n\n    def one(i, j):\n        try:\n            out[i] = steady(j[0], j[1], j[2], secs=secs, barrier=bar, **kw)\n        except Exception as e:          # rev 3: a dead replica is recorded, not printed to stderr only\n            out[i] = {\"status\": \"ERROR_REPLICA\", \"error\": f\"{type(e).__name__}: {e}\"[:300], \"port\": j[0]}\n            try:\n                bar.abort()\n            except Exception:\n                pass\n    th = [threading.Thread(target=one, args=(i, j), daemon=True) for i, j in enumerate(jobs)]\n    for t in th:\n        t.start()\n    for t in th:\n        t.join()\n    good = all(o and o.get(\"status\") in (\"STEADY\", \"CAPACITY_LIMITED\") for o in out)\n    ov = (min(o[\"t1\"] for o in out) - max(o[\"t0\"] for o in out)) if good else 0\n    aligned = good and ov > 0.8 * min(o[\"window_sec\"] for o in out)\n    return {\"replicas\": out, \"aligned\": aligned, \"overlap_sec\": round(ov, 1),\n            \"tok_s\": round(sum(o[\"tok_s\"] for o in out), 1) if aligned else None,\n            \"running_mean\": round(sum(o[\"running_mean\"] for o in out), 2) if aligned else None,\n            \"status\": \"AGGREGATE_STEADY\" if aligned else \"INCONCLUSIVE_REPLICA_WINDOWS\"}\n\n\ndef wait_idle(port, wait=90.0):\n    end, hits = time.perf_counter() + wait, 0\n    while time.perf_counter() < end:\n        try:\n            m = prom(port)\n            hits = hits + 1 if m.get(RUN, 0) == 0 and m.get(WAIT, 0) == 0 else 0\n        except Exception:\n            hits = 0\n        if hits >= 3:\n            return True\n        time.sleep(2)\n    return False\n\n\n# ------------------------------------------------------------------ profiler (FULL-graph proof + per-category time)\n# rev 3: matched on the kernel BASE name, attention before GDN (\"fla\" is a substring of \"flashinfer\"), real 0.32 GDN names\nCATS = [(\"nccl\", (\"nccl\", \"allreduce\", \"all_reduce\", \"allgather\", \"all_gather\")),\n        (\"attention\", (\"flashinfer\", \"flash_fwd\", \"unified_attention\", \"paged\", \"attn\", \"attention\", \"batchdecode\", \"batchprefill\",\n                   \"reshape_and_cache\")),\n        (\"gdn_linear_attn\", (\"gdn\", \"delta_rule\", \"chunk_\", \"recurrent\", \"causal_conv\", \"l2norm\", \"solve_tril\", \"merge_16x16\",\n                             \"recompute_w_u\", \"kkt\", \"cumsum\", \"post_conv\", \"layer_norm_gated\", \"gated_delta\")),\n        (\"gemm_marlin\", (\"marlin\",)),\n        (\"gemm_other\", (\"gemm\", \"cutlass\", \"xmma\", \"cublas\", \"sm89_\", \"ampere_\", \"sm80_\")),\n        (\"sampling\", (\"sampl\", \"topk\", \"top_k\", \"argmax\", \"softmax\", \"rejection\"))]\n\n\ndef _cat(name):\n    # rev 3h: \"void (anonymous namespace)::gdn_decode_post_conv_mtp_kernel<...>(...)\" used to reduce to \"void \" -> other\n    s = re.sub(r\"\\(anonymous namespace\\)::\", \"\", str(name))\n    s = re.sub(r\"^\\s*void\\s+\", \"\", s)\n    base = s.split(\"<\")[0].split(\"(\")[0].lower()\n    return next((k for k, pats in CATS if any(p in base for p in pats)), \"other\")\n\n\nCOMPUTE_CATS = (\"nccl\", \"attention\", \"gdn_linear_attn\", \"gemm_marlin\", \"gemm_other\")\n# rev 3h: vLLM 0.32 marks each model execution as execute_context_N(N)_generation_N(N) (no gpu_model_runner range)\nSCOPE_RE = re.compile(r\"^execute_context_\\d+\\(\\d+\\)_generation_\\d+\\(\\d+\\)$\")\n\n\ndef _is_scope(e):\n    n = str(e.get(\"name\", \"\"))\n    return SCOPE_RE.match(n) is not None or (\"forward\" in n.lower() and \"gpu_model_runner\" in n.lower())\n\n\ndef _scope_kind(g, compute_eager, unresolved):\n    \"\"\"FULL = graph-launched with no eager model compute (attention / GDN / GEMM / NCCL) inside the execution scope;\n    eager input-preparation kernels are counted apart and allowed. Unresolved eager launches never read FULL.\"\"\"\n    if g == 0:\n        return \"EAGER\"\n    if compute_eager:\n        return \"PIECEWISE\"\n    if unresolved:\n        return \"PIECEWISE\" if g > 1 else \"MIXED\"\n    return \"FULL\"\n\n\ndef trace_summary(pdir):\n    files = sorted(Path(pdir).rglob(\"*.pt.trace.json*\"), key=lambda p: p.stat().st_mtime)\n    if not files:\n        return {\"error\": \"NO_TRACE_FILE\", \"listing\": [str(p) for p in Path(pdir).rglob(\"*\")][:20]}\n    f = next((p for p in files if re.search(r\"rank0\\.|rank[-_]?0[._]|tp0_\", p.name)), files[0])\n    with (gzip.open if f.name.endswith(\".gz\") else open)(f, \"rt\", encoding=\"utf-8\") as fh:\n        tr = json.load(fh)\n    ev = tr.get(\"traceEvents\", [])\n    kern = [e for e in ev if e.get(\"ph\") == \"X\" and str(e.get(\"cat\", \"\")).lower() in (\"kernel\", \"gpu_kernel\")]\n    rt = [e for e in ev if e.get(\"ph\") == \"X\" and str(e.get(\"cat\", \"\")).lower() in (\"cuda_runtime\", \"cuda_driver\")]\n    is_graph = lambda e: \"GraphLaunch\" in str(e.get(\"name\", \"\"))\n    is_kl = lambda e: re.search(r\"LaunchKernel|cuLaunchKernel\", str(e.get(\"name\", \"\"))) is not None\n    # per-scope counts inside the execution annotations (rev 3h: execute_context_*_generation_*; the older\n    # gpu_model_runner forward ranges still count). rev 3c: user_annotation only, not the gpu_user_annotation copies.\n    fw = sorted([e for e in ev if e.get(\"ph\") == \"X\" and str(e.get(\"cat\", \"\")) == \"user_annotation\" and _is_scope(e)],\n                key=lambda e: e.get(\"ts\", 0))\n    kname = {(e.get(\"args\") or {}).get(\"correlation\"): str(e.get(\"name\", \"\")) for e in kern\n             if (e.get(\"args\") or {}).get(\"correlation\") is not None}\n    per_fw, aux = [], {}\n    for a in fw[:400]:\n        lo, hi, tid = a.get(\"ts\", 0), a.get(\"ts\", 0) + a.get(\"dur\", 0), a.get(\"tid\")\n        inside = [e for e in rt if e.get(\"tid\") == tid and lo <= e.get(\"ts\", -1) <= hi]\n        kls = [e for e in inside if is_kl(e)]\n        ce = un = 0\n        for e in kls:\n            kn = kname.get((e.get(\"args\") or {}).get(\"correlation\"))\n            if kn is None:\n                un += 1\n            elif _cat(kn) in COMPUTE_CATS:\n                ce += 1\n            else:\n                b = re.sub(r\"^\\s*void\\s+\", \"\", re.sub(r\"\\(anonymous namespace\\)::\", \"\", kn)).split(\"<\")[0].split(\"(\")[0][:60]\n                aux[b] = aux.get(b, 0) + 1\n        per_fw.append([sum(1 for e in inside if is_graph(e)), len(kls), ce, un])\n    corr = {(e.get(\"args\") or {}).get(\"correlation\"): str(e.get(\"name\", \"\")) for e in rt\n            if (e.get(\"args\") or {}).get(\"correlation\") is not None}\n    per, tot, names = {k: 0.0 for k, _ in CATS + [(\"other\", ())]}, 0.0, {}\n    src = {k: {\"graph\": 0, \"eager\": 0, \"unknown\": 0} for k in per}\n    for e in kern:\n        d = float(e.get(\"dur\", 0.0))\n        tot += d\n        names[e.get(\"name\", \"\")] = names.get(e.get(\"name\", \"\"), 0.0) + d\n        k = _cat(e.get(\"name\", \"\"))\n        per[k] += d\n        launcher = corr.get((e.get(\"args\") or {}).get(\"correlation\"))\n        src[k][\"graph\" if launcher and \"GraphLaunch\" in launcher else (\"eager\" if launcher else \"unknown\")] += 1\n    tot_k = sum(v[\"graph\"] + v[\"eager\"] for v in src.values())\n    eager_share = round(sum(v[\"eager\"] for v in src.values()) / tot_k, 3) if tot_k else None\n    fw_g = statistics.median([x[0] for x in per_fw]) if per_fw else None\n    fw_k = statistics.median([x[1] for x in per_fw]) if per_fw else None\n    kinds_l = [_scope_kind(g, ce, un) for g, k, ce, un in per_fw]\n    if per_fw:                   # rev 3f (GPT rev 3e audit: 2 FULL + 1 EAGER forwards read FULL by the median)\n        kinds = set(kinds_l)\n        verdict = kinds.pop() if len(kinds) == 1 else \"MIXED\"       # every scope must agree\n        basis = \"per_scope_annotation (all scopes; eager input-prep kernels allowed, eager model compute is not)\"\n    elif tot_k:                  # rev 3d (GPT-2 reproduced FULL with 0 forwards): CUPTI alone never proves FULL\n        att = src[\"attention\"]\n        hint = (\"FULL\" if att[\"eager\"] == 0 and (eager_share or 0) < 0.05 else\n                \"PIECEWISE\" if att[\"eager\"] > 0 and any(v[\"graph\"] for v in src.values()) else\n                \"EAGER\" if not any(v[\"graph\"] for v in src.values()) else \"MIXED\")\n        verdict, basis = \"UNPROVEN\", f\"no forward annotations (cupti hint: {hint})\"\n    else:\n        verdict, basis = \"UNKNOWN\", \"none\"\n    return {\"file\": f.name, \"files\": len(files), \"kernels\": len(kern), \"kernel_us_sum\": round(tot),\n            \"graph_launches\": sum(1 for e in rt if is_graph(e)), \"kernel_launches\": sum(1 for e in rt if is_kl(e)),\n            \"forwards\": len(per_fw), \"forward_kinds\": {k_: kinds_l.count(k_) for k_ in (\"FULL\", \"PIECEWISE\", \"EAGER\", \"MIXED\")},\n            \"per_forward_median_graph_launches\": fw_g, \"per_forward_median_kernel_launches\": fw_k,\n            \"per_forward_median_compute_eager\": statistics.median([x[2] for x in per_fw]) if per_fw else None,\n            \"per_forward_unresolved_eager\": sum(x[3] for x in per_fw),\n            \"scope_names\": sorted({str(a.get(\"name\", \"\")) for a in fw})[:5],\n            \"aux_eager_kernels_in_scopes\": dict(sorted(aux.items(), key=lambda x: -x[1])[:20]),\n            \"launch_source\": src, \"eager_kernel_share\": eager_share, \"graph_verdict\": verdict, \"verdict_basis\": basis,\n            \"by_category_pct\": {k: round(100 * v / tot, 1) for k, v in per.items()} if tot else {},\n            \"top_kernels_us\": dict(sorted(((k, round(v)) for k, v in names.items()), key=lambda x: -x[1])[:25]),\n            \"note\": \"kernel time sums overlapping streams; NCCL time includes rank-skew waiting\"}\n\n\ndef profile(port, pdir, secs=6.0, delay_iters=20, max_iters=40):\n    \"\"\"POST /start_profile (bounded by iterations; falls back to a bare POST), decode, POST /stop_profile, summary.\"\"\"\n    rec = {}\n    try:\n        U.urlopen(U.Request(f\"http://127.0.0.1:{port}/start_profile\", method=\"POST\",\n                            data=json.dumps({\"delay_iterations\": delay_iters, \"max_iterations\": max_iters}).encode(),\n                            headers={\"Content-Type\": \"application/json\"}), timeout=900).read()\n        rec[\"start_profile\"] = \"ok_bounded\"\n    except Exception as e:\n        rec[\"start_profile_bounded_error\"] = repr(e)[:200]\n        try:\n            U.urlopen(U.Request(f\"http://127.0.0.1:{port}/start_profile\", data=b\"\", method=\"POST\"), timeout=900).read()\n            rec[\"start_profile\"] = \"ok\"\n        except Exception as e2:\n            rec[\"start_profile\"] = repr(e2)[:200]\n    time.sleep(secs)\n    try:\n        U.urlopen(U.Request(f\"http://127.0.0.1:{port}/stop_profile\", data=b\"\", method=\"POST\"), timeout=900).read()\n        rec[\"stop_profile\"] = \"ok\"\n    except Exception as e:\n        rec[\"stop_profile\"] = repr(e)[:200]\n    time.sleep(20)\n    try:\n        rec[\"trace\"] = trace_summary(pdir)\n    except Exception as e:\n        rec[\"trace\"] = {\"error\": f\"TRACE_PARSE {type(e).__name__}: {e}\"[:300]}\n    return rec\n\n\ndef profiled_load(port, prompts, level, pdir, secs=6.0, max_new=8192, model=\"q27\", prefill_tok_s=700.0, spec=False):\n    \"\"\"`level` decoding streams (own window: the profiler slows decode), profile() only after prefill settled exactly\n    as in steady() (prompt counter + preemptions flat, every running request emitted and gaining tokens). rev 3d: no\n    profile when unsettled; the profile window must be decode-only (prompt counter flat) and, with `spec`, show\n    speculative drafts (else the trace cannot speak for multi-token verification).\"\"\"\n    plen = len(prompts[0]) if prompts else 0\n    settle = max(300.0, 120.0 + level * plen / prefill_tok_s)\n    ss = [Stream(port, prompts[i % len(prompts)], max_new, 1.0, 4321 + i, model=model) for i in range(level)]\n    for g in ss:\n        g.start()\n    rec, t0, flat, ok, prev, last_tok = {\"level\": level}, time.perf_counter(), None, 0, None, [0] * level\n    try:\n        while time.perf_counter() - t0 < settle:\n            time.sleep(2)\n            try:\n                m = prom(port)\n            except Exception:\n                continue\n            run, wait, pt, pre = int(m.get(RUN, 0)), int(m.get(WAIT, 0)), m.get(PROMPT), m.get(PREEMPT, 0)\n            now_tok = [len(g.tokens) for g in ss]\n            gaining = sum(1 for a, b in zip(last_tok, now_tok) if b > a)\n            last_tok = now_tok\n            first = sum(g.t_first is not None for g in ss)\n            calm = run > 0 and prev is not None and (pt, pre) == prev and first >= run and gaining >= run\n            if calm and run >= level and wait == 0:\n                ok += 1\n            elif calm and wait > 0:\n                flat = flat or time.perf_counter()\n                ok = ok + 1 if time.perf_counter() - flat > 30 else 0\n            else:\n                ok, flat = 0, None\n            prev = (pt, pre)\n            if ok >= 3:\n                break\n        rec[\"settled\"] = ok >= 3\n        if not rec[\"settled\"]:\n            rec[\"status\"] = \"INCONCLUSIVE_PREFILL_NOT_SETTLED\"\n            return rec\n        try:\n            m0 = prom(port)\n            rec[\"running_at_start\"] = m0.get(RUN)\n        except Exception:\n            m0 = {}\n        rec.update(profile(port, pdir, secs))\n        try:\n            m1 = prom(port)\n        except Exception:\n            m1 = {}\n        rec[\"window_deltas\"] = {\"prompt_tokens\": m1.get(PROMPT, 0) - m0.get(PROMPT, 0), \"drafts\": m1.get(DRF, 0) - m0.get(DRF, 0),\n                                \"accepted\": m1.get(ACC, 0) - m0.get(ACC, 0), \"generated\": m1.get(GEN, 0) - m0.get(GEN, 0)}\n        if not m0 or not m1:\n            rec[\"status\"] = \"INCONCLUSIVE_METRICS_UNAVAILABLE\"\n        elif rec[\"window_deltas\"][\"prompt_tokens\"]:\n            rec[\"status\"] = \"INCONCLUSIVE_PREFILL_IN_PROFILE\"\n        elif spec and not (rec[\"window_deltas\"][\"drafts\"] and rec[\"window_deltas\"][\"accepted\"]):\n            rec[\"status\"] = \"INCONCLUSIVE_NO_SPEC_DECODE\"            # rev 3e: drafts AND accepted tokens in the window\n        return rec\n    finally:\n        for g in ss:\n            g.stop()\n        for g in ss:\n            g.join(10)\n        rec[\"idle_after\"] = wait_idle(port)\n"
    (TMP / "e23_lab.py").write_text(LAB_SRC)
    sys.path.insert(0, str(TMP))
    import e23_lab as L
    REQ_LOG = TRACES / "requests.jsonl"                           # memory rule: the full text of EVERY request
    _stream_run = L.Stream.run

    def _traced_run(self):
        try:
            _stream_run(self)
        finally:
            if not self.err and any(m is not None and not (isinstance(m, (int, float)) and math.isfinite(m))
                                    for m in self.margins):
                self.err = "NONFINITE_LOGPROB"           # final audit H2: NaN / Inf logprobs are never data
            try:
                r = self.row()
                pr = self.body.get("prompt") or []
                r.update(port=self.port, sampling={k: v for k, v in self.body.items() if k != "prompt"}, prompt_len=len(pr),
                         prompt_sha=hashlib.sha256(json.dumps(pr).encode()).hexdigest()[:16],
                         ttft=round(self.t_first - self.t_start, 2) if self.t_first and self.t_start else None,
                         sec=round(self.t_end - self.t_start, 2) if self.t_end and self.t_start else None, t=time.time())
                with _SAVE_LOCK, open(REQ_LOG, "a") as fh:
                    fh.write(json.dumps(r) + "\n")
            except Exception:
                pass
    L.Stream.run = _traced_run
    PLE_EXPECTED = json.loads(r"""{"model-plefp8-00000.safetensors": [5200027199, "dc2e845b7edd35bda92834fba3626bf7d199e28d6aceac99fee654aade390cfd"], "model-plefp8-00001.safetensors": [5200027202, "899eaa0716e28594468a1389ee58cb065c23907f1270de3831f5ecb0a4f82d56"], "model-plefp8-00002.safetensors": [5200027198, "06fd8a11abf0419a669f89397b8d70dd6ff42d401e6b2a037c65e49704faaf71"], "model-plefp8-00003.safetensors": [5200027189, "c6aaa1fc08e84eced3c8151ac8679ed943888eba0fcef2556963693430f95bd9"], "model-plefp8-00004.safetensors": [5200027190, "d94e97c96d3ea09208614da016960f3f4b429f47a044c898a51b493f42f74ba2"], "model-plefp8-00005.safetensors": [5200027190, "03d5d4792e14a4ab55bae50bb459624b01786f818bbcfcaed1a5d0235af484c6"], "model-plefp8-00006.safetensors": [5200027190, "586cccbc12383021bc9bc02f206d9b19fbd1672373ed9a5d91e3b0ce34c2418f"], "model-plefp8-00007.safetensors": [5200027190, "c4a23bcc10f3cde6b633e82c282a9a518e3a64d433628283e1bc592c94cf3d6c"], "model-plefp8-00008.safetensors": [5200027190, "2dc8098c0d020bff277c9cf499a6b908e17836b70a5f949dfa24793371c9a87e"], "model-plefp8-00009.safetensors": [4400023163, "61de98b89bb79f386795787d7a76827a26f1e292c26edbb0a1b613da455f5a9c"]}""")                     # 10 FP8 PLE shards: [size, sha256]
    # exact Kaggle mount paths (foysalemonshanto Models, checked through the API 2026-10-31; no recursive search)
    MD = INP / "models" / "foysalemonshanto"
    PART_DIRS = {1: MD / "qwen3-8-flash-next-w4a16-merlin-p1/transformers/default/1",
                 2: MD / "qwen3-8-flash-next-w4a16-merlin-p2/transformers/default/1",
                 3: MD / "qwen3-8-flash-next-w4a16-merlin-p3/transformers/default/1",
                 4: MD / "qwen3-8-flash-next-w4a16-merlin-p4/transformers/default/1",
                 5: MD / "qwen3-8-flash-next-w4a16-merlin-p5/transformers/default/1"}
    PARTS = {}
    for k, d in PART_DIRS.items():                                  # the five checkpoint parts (Models from the kernel outputs)
        mf = d / f"q27_fn_merlin_part{k}_manifest.json"
        PARTS[k] = (d, json.loads(mf.read_text())) if mf.is_file() else None
    PLE_DIR = MD / "qwen38-flash-next-fp8ple-overlay/pytorch/albucino-fp8ple/1"      # our FP8 PLE overlay = albucino's shards
    PLE_DIR = PLE_DIR if (PLE_DIR / "model-plefp8-00000.safetensors").is_file() else None
    MERLIN_PAY = MD / "e23-merlin-env/other/v1/1/merlin_offline_tar.bin"
    MERLIN_PAY = MERLIN_PAY if MERLIN_PAY.is_file() else None
    INTEL = INP / "models/dfranzen/intel-qwen3.8-flash-next-w4a16-autoround/transformers/default/1"
    INTEL = INTEL if (INTEL / "config.json").is_file() else None
    WHEELHOUSE = INP / "datasets/foysalemonshanto/vllm-0-32-0-cu13-wheelhouse/install_wheelhouse.py"
    WHEELHOUSE = WHEELHOUSE if WHEELHOUSE.is_file() else None
    ARC = COMP / "arc-agi_evaluation_challenges.json"
    if not ARC.is_file():
        raise FileNotFoundError(f"{ARC}: attach the competition data")
    MERLIN_OK = all(PARTS.values()) and PLE_DIR is not None and MERLIN_PAY is not None
    R["inputs"] = {"parts": {k: (str(v[0]) if v else None) for k, v in PARTS.items()}, "ple_dir": str(PLE_DIR),
                   "merlin_pay": str(MERLIN_PAY), "intel": str(INTEL), "wheelhouse": str(WHEELHOUSE), "arc": str(ARC),
                   "merlin_inputs_ok": MERLIN_OK}
    ABORT = {"why": None}
    NVSMI_OK = bool(L.gpu_mem()) and not FAKE
    R["setup"]["gpus_at_start"] = L.gpu_mem()
    if not FAKE and not os.environ.get("RC2_CPU_KIT") and len(R["setup"]["gpus_at_start"] or []) != 4:   # CPU kit: no GPUs
        R["errors"].append(f"expected 4 GPUs, nvidia-smi shows {R['setup']['gpus_at_start']}")
        save()
        raise RuntimeError("GPU_PREFLIGHT_FAILED: " + repr(R["setup"]["gpus_at_start"]))
    L.start_watchdog(HARD_STOP, lambda: ABORT.update(why="HARD_STOP reached: watchdog killed live servers"))
    log("RC2 | budget", BUDGET // 60, "min |", json.dumps(R["inputs"])[:900])
    save()


if not RERUN:
    # ==================================================================== CELL 2 — host facts, checkpoint merge, engines
    def run(name, cmd, timeout=3600, env=None):
        t = time.time()
        try:
            with open(LOGS / f"{name}.log", "w") as f:
                r = subprocess.run(["bash", "-c", "set -o pipefail; " + cmd], stdout=f, stderr=subprocess.STDOUT, timeout=timeout,
                                   env={**os.environ, **(env or {})})
            rc = r.returncode
        except subprocess.TimeoutExpired:
            rc = -9
        txt = (LOGS / f"{name}.log").read_text(errors="replace")
        R["setup"][name] = {"rc": rc, "sec": round(time.time() - t, 1), "tail": txt[-1500:]}
        log(name, "rc", rc, f"{time.time() - t:.0f}s")
        save()
        return rc, txt


    SHIM = TMP / "e23_libcuda"          # FlashInfer JIT links -lcuda; Kaggle has only libcuda.so.1
    SHIM.mkdir(exist_ok=True)
    for d in ("/usr/local/nvidia/lib64", "/usr/lib/x86_64-linux-gnu", "/usr/local/cuda/compat", "/usr/lib64"):
        c = sorted(Path(d).glob("libcuda.so.1")) if Path(d).is_dir() else []
        if c and not (SHIM / "libcuda.so").exists():
            (SHIM / "libcuda.so").symlink_to(c[0])


    def host_facts():
        """A0: what the Kaggle box gives us (glibc, driver, GPUs, PCIe, peer access, cgroup memory, /dev/shm, disk)."""
        f = {}
        for k, cmd in (("glibc", "ldd --version | head -1"), ("uname", "uname -a"),
                       ("nvidia_smi", "nvidia-smi --query-gpu=name,compute_cap,driver_version,memory.total,pcie.link.gen.max,pcie.link.width.max --format=csv,noheader"),
                       ("cuda_version", "nvidia-smi | grep -o 'CUDA Version: [0-9.]*'"), ("shm", "df -h /dev/shm | tail -1"),
                       ("tmp_disk", f"df -h {TMP} | tail -1"), ("nproc", "nproc"),
                       ("cgroup_max", "cat /sys/fs/cgroup/memory.max 2>/dev/null || cat /sys/fs/cgroup/memory/memory.limit_in_bytes"),
                       ("cgroup_cur", "cat /sys/fs/cgroup/memory.current 2>/dev/null || cat /sys/fs/cgroup/memory/memory.usage_in_bytes"),
                       ("meminfo", "grep -E 'MemTotal|MemAvailable' /proc/meminfo"), ("ulimit_l", "ulimit -l"),
                       ("omp", "echo OMP_NUM_THREADS=$OMP_NUM_THREADS"), ("topo", "nvidia-smi topo -m; nvidia-smi topo -p2p r"),
                       ("pcie_now", "nvidia-smi --query-gpu=index,pcie.link.gen.current,pcie.link.width.current,power.limit --format=csv,noheader")):
            try:
                f[k] = subprocess.run(["bash", "-c", cmd], capture_output=True, text=True, timeout=60).stdout.strip()[:600]
            except Exception as e:
                f[k] = repr(e)[:200]
        try:
            import torch
            n = torch.cuda.device_count()
            f["peer_access"] = [[torch.cuda.can_device_access_peer(i, j) if i != j else None for j in range(n)] for i in range(n)]
        except Exception as e:
            f["peer_access"] = repr(e)[:200]
        return f


    def host_mem():
        """MiB. avail_mib = max - (current - inactive_file), Merlin's own rule (RC1's guard counted page cache as used and
        skipped arm 3 with MemAvailable 55 GB); /dev/shm counts against the cgroup."""
        out = {}
        try:
            cur = int(Path("/sys/fs/cgroup/memory.current").read_text())
            mx = Path("/sys/fs/cgroup/memory.max").read_text().strip()
            st = dict(l.split() for l in Path("/sys/fs/cgroup/memory.stat").read_text().splitlines() if len(l.split()) == 2)
            out.update(cgroup_cur_mib=cur >> 20, cgroup_max_mib=None if mx == "max" else int(mx) >> 20,
                       **{k + "_mib": int(st[k]) >> 20 for k in ("anon", "file", "shmem", "inactive_file") if k in st})
            if mx != "max":
                out["avail_mib"] = (int(mx) - (cur - int(st.get("inactive_file", 0)))) >> 20
        except Exception:
            pass
        try:
            for l in open("/proc/meminfo"):
                if l.startswith(("MemAvailable", "MemTotal")):
                    out[l.split(":")[0] + "_mib"] = int(l.split()[1]) >> 10
        except Exception:
            pass
        try:
            out["dev_shm_used_mib"] = shutil.disk_usage("/dev/shm").used >> 20
        except Exception:
            pass
        return out


    TELEMETRY = OUT / "telemetry.jsonl"


    def _telemetry():
        """Host RAM + GPU memory every 10 s for the whole run (Merlin's floor ~69 GiB inside a ~173 GiB cgroup)."""
        while True:
            try:
                with open(TELEMETRY, "a") as fh:
                    fh.write(json.dumps({"t": round(time.time() - T_START, 1), "host": host_mem(), "gpu": L.gpu_mem()}) + "\n")
            except Exception:
                pass
            time.sleep(10)


    threading.Thread(target=_telemetry, daemon=True).start()


    SHM = Path(os.environ.get("RC2_SHM", "/dev/shm"))


    def shm_names():
        try:
            return {p.name for p in SHM.iterdir()}
        except Exception:
            return set()


    def shm_cleanup(before):
        """After a boot's server is dead: only /dev/shm entries that appeared during THIS boot (absent from `before`) and
        match the engine's prefixes are unlinked; everything else is recorded, never touched."""
        out = {"host_before": host_mem(), "removed": [], "kept": []}
        try:
            for p in sorted(SHM.iterdir()):
                try:
                    sz = p.stat().st_size >> 20
                except Exception:
                    sz = None
                if p.name not in before and re.match(r"(torch_|psm_|vllm|ple|nccl|sem\.mp-|cuda\.shm)", p.name, re.I):
                    try:
                        p.unlink() if not p.is_dir() else shutil.rmtree(p)
                        out["removed"].append([p.name, sz])
                    except Exception as e:
                        out["kept"].append([p.name, sz, repr(e)[:80]])
                else:
                    out["kept"].append([p.name, sz])
        except Exception as e:
            out["error"] = repr(e)[:200]
        out["host_after"] = host_mem()
        out["removed"], out["kept"] = out["removed"][:60], out["kept"][:60]
        return out


    class MServer(L.Server):
        """Merlin passes --shutdown-timeout 60 and the PLE transport unlinks its /dev/shm storages only on a graceful
        teardown: SIGTERM, wait 75 s, then E23's kill (SIGTERM + 40 s + SIGKILL of the whole session)."""
        def kill(self):
            if self.proc is not None and self.proc.poll() is None:
                try:
                    os.killpg(self.proc.pid, 15) if hasattr(os, "killpg") else self.proc.terminate()
                except Exception:
                    pass
                try:
                    self.proc.wait(timeout=75)
                except Exception:
                    pass
            super().kill()


    def boot_gate():
        """Merlin's pin leaves ~0.9 GiB free per card: every boot needs near-empty GPUs (< 150 MiB, not E23's 1024)."""
        g = L.wait_gpu_release(300, fake=bool(FAKE), gpus="0,1,2,3", free_mib=150)
        return {"ok": g, "gpus": L.gpu_mem(), "host": host_mem()}       # callers launch only on ok is True


    CKPT = TMP / "fn_merlin"
    SHA = {"thread": None, "ok": None, "bad": [], "sec": None}


    def merge_ckpt():
        """Symlink the 5 parts + 10 PLE shards into one directory; names and sizes now, sha256 in a background thread."""
        SHA.update(thread=None, ok=None, bad=[], sec=None)        # a stale result never gates a new merge
        shutil.rmtree(CKPT, ignore_errors=True)
        CKPT.mkdir(parents=True)
        expected = {}
        for k, (d, man) in PARTS.items():
            for n, (size, sha) in man["files"].items():
                expected[n] = (d / man.get("model_subdir", ".") / n, size, sha)
        for n, (size, sha) in PLE_EXPECTED.items():
            expected[n] = (PLE_DIR / n, size, sha)
        bad = []
        for n, (src, size, sha) in sorted(expected.items()):
            if not src.is_file():
                bad.append(f"missing {n}")
                continue
            if not FAKE and src.stat().st_size != size:
                bad.append(f"{n}: {src.stat().st_size} bytes, expected {size}")
            try:
                (CKPT / n).symlink_to(src)
            except OSError:
                if not FAKE:
                    raise
                shutil.copyfile(src, CKPT / n)               # local Windows harness only (no symlink privilege)
        idx = json.loads((CKPT / "model.safetensors.index.json").read_text())
        need = set(idx["weight_map"].values())
        bad += [f"index needs {n}, not merged" for n in sorted(need - set(expected))]
        cfg = json.loads((CKPT / "config.json").read_text())
        if (cfg.get("text_config") or {}).get("ple_embedding_dtype") != "float8_e4m3fn":
            bad.append("config.json: text_config.ple_embedding_dtype is not float8_e4m3fn")
        rec = {"files": len(expected), "index_files": len(need), "bad": bad[:20], "ok": not bad}

        def hash_all():
            t = time.time()
            import concurrent.futures as CF

            def one(item):
                n, (src, size, sha) = item
                if FAKE:
                    return n, True
                with open(src, "rb") as fh:
                    return n, hashlib.file_digest(fh, "sha256").hexdigest() == sha
            with CF.ThreadPoolExecutor(6) as ex:
                res = list(ex.map(one, sorted(expected.items())))
            SHA.update(ok=all(ok for _, ok in res), bad=[n for n, ok in res if not ok], sec=round(time.time() - t, 1))
            R["setup"]["sha256"] = {k: SHA[k] for k in ("ok", "bad", "sec")}
            save()
        if rec["ok"]:
            SHA["thread"] = threading.Thread(target=hash_all, daemon=True)
            SHA["thread"].start()
        return rec


    def sha_gate(timeout):
        """The first launch waits for the full sha256 check (Merlin itself never hashes shards)."""
        th = SHA["thread"]
        if th is not None:
            th.join(max(1, timeout))
        if th is None or th.is_alive():
            return False, "sha256 check not finished"
        return bool(SHA["ok"]), ("ok" if SHA["ok"] else f"sha256 mismatch: {SHA['bad'][:5]}")


    def prefetch_bg(paths, tag):
        """rev 3: warm the page cache of a cold 17-30 GB /kaggle/input checkpoint in the background (many readers)."""
        def go():
            R["setup"]["prefetch_" + tag] = L.prefetch([p for p in paths if p]) if not FAKE else {"fake": True}
            save()
        th = threading.Thread(target=go, daemon=True)
        th.start()
        return th


    MERLIN_ENG = None


    def merlin_install():
        """P2 payload (.bin = a tar Kaggle does not unpack) -> install_merlin_offline.sh (UV_OFFLINE); payload deleted after;
        a failure is cached so later Merlin steps fail fast (rev 3)."""
        global MERLIN_ENG
        if MERLIN_ENG is not None:
            if MERLIN_ENG.get("failed"):
                raise RuntimeError("Merlin install failed earlier: " + MERLIN_ENG["failed"])
            return MERLIN_ENG
        if not MERLIN_OK or MERLIN_PAY is None:
            MERLIN_ENG = {"failed": "Merlin checkpoint / env not attached or incomplete"}
            raise RuntimeError(MERLIN_ENG["failed"])
        if FAKE:
            MERLIN_ENG = {"fake": True}
            return MERLIN_ENG
        try:
            pay_root = TMP / "merlin_pay"
            shutil.rmtree(pay_root, ignore_errors=True)
            pay_root.mkdir()
            t = time.time()
            with tarfile.open(MERLIN_PAY) as tf:
                tf.extractall(pay_root, filter="data")
            R["setup"]["merlin_extract_sec"] = round(time.time() - t, 1)
            pay = pay_root / "merlin_offline"
            shutil.rmtree(TMP / "merlin_off", ignore_errors=True)
            rc, txt = run("install_merlin", f"bash {pay}/install_merlin_offline.sh {pay} {TMP}/merlin_off", timeout=5400)
            kv = dict(re.findall(r"^(MERLIN_[A-Z]+)=(.*)$", txt, re.M))
            shutil.rmtree(pay_root, ignore_errors=True)
            if rc or "INSTALL OK" not in txt:
                raise RuntimeError("Merlin offline install failed (logs/install_merlin.log)")
            sys.path.insert(0, kv["MERLIN_TREE"] + "/tools/merlin")
            import launch as ML
            site = subprocess.run([kv["MERLIN_VENV"] + "/bin/python", "-c", "import sysconfig;print(sysconfig.get_paths()['purelib'])"],
                                  capture_output=True, text=True).stdout.strip()
            MERLIN_ENG = {"kv": kv, "ML": ML, "cuda_home": site + "/nvidia/cu13"}
            return MERLIN_ENG
        except Exception as e:
            MERLIN_ENG = {"failed": f"{type(e).__name__}: {e}"[:300]}
            raise


    MERLIN_CC = {"mode": "gcc13"}       # rev 3c: Merlin README:229 / install-env.sh: FlashInfer JIT at first start needs GCC >= 13



    KV_FP8, KV_BF16 = 2479838700, 2464415744      # Merlin's own L4 pins (23,034 MiB cards; preflight.kv_bytes_for_vram, 150 / 79 blocks)
    PROFILE = "fn-quad-24g-sm89"
    XHIGH = json.dumps({"enable_thinking": True, "reasoning_effort": "xhigh"})
    HOST_PHASE = {}


    def merlin_fn_server(name, kv, port, kv_bytes):
        """Merlin's launch.build() for Flash-Next on the L4 profile: KV pin lowered for 22.49 GiB cards, the checkpoint's own
        chat template at xhigh (Merlin passes medium otherwise), Merlin's host_phase checks recorded, E23's env overrides."""
        eng = merlin_install()
        extra = ["--served-model-name", "q27", "--max-model-len", str(MAX_LEN), "--port", str(port),
                 "--default-chat-template-kwargs", XHIGH] + list(NB1_EXTRA.get(name) or [])   # E25 NB1: per-boot flags (last wins)
        if FAKE:
            return MServer(name, [sys.executable, FAKE, str(CKPT) + "-w4a16", "--tensor-parallel-size", "2", "--max-num-seqs",
                                  "8" if kv == "fp8" else "3", "--port", str(port), "--max-model-len", str(MAX_LEN),
                                  "--kv-cache-memory-bytes", str(kv_bytes)] + list(NB1_EXTRA.get(name) or []),   # E25 NB1 (fake only)
                           {**os.environ, **(NB1_ENV.get(name) or {})}, port, LOGS)
        kvv = eng["kv"]
        gcc_bin = str(Path(kvv["MERLIN_CC"]).parent) if kvv.get("MERLIN_CC") else ""
        base = {k: v for k, v in os.environ.items() if k not in ("PYTHONPATH", "CUDA_PATH", "CUDA_HOME", "LD_PRELOAD", "CC", "CXX")}
        base.update(GPUS="0,1,2,3", PORT=str(port), KV_BYTES=str(kv_bytes), P2P="off",
                    VENV=kvv["MERLIN_VENV"], TREE=kvv["MERLIN_TREE"], CHAT_TEMPLATE="", WARM="0", CACHE_ROOT=f"{TMP}/merlin-cache",
                    PATH=f"{kvv['MERLIN_VENV']}/bin:{gcc_bin}:{eng['cuda_home']}/bin:{os.environ.get('PATH', '')}",
                    CUDA_HOME=eng["cuda_home"])
        if kv == "fp8":
            base["SCALES"] = str(CKPT / "qsa_kv_scales_262k.json")
        plan = eng["ML"].build("flash-next", PROFILE, str(CKPT), base, extra=extra, kv=kv, checkpoint="flash-next", status="untested")
        try:                                               # audits: tree products, venv, checkpoint marker, PLE dtype, toolchain,
            eng["ML"].host_phase(plan)                     # scales file: a failure stops this boot before any server starts
            HOST_PHASE[name] = "ok"
        except BaseException as e:
            HOST_PHASE[name] = f"{type(e).__name__}: {e}"[:600]
            R["setup"].setdefault("host_phase_error", {})[name] = HOST_PHASE[name]
            save()
            raise RuntimeError("MERLIN_HOST_PHASE_FAILED: " + HOST_PHASE[name])
        env = dict(plan.env)
        env.update(LD_PRELOAD=kvv["MERLIN_SHIM"], CUDA_HOME=eng["cuda_home"], VLLM_USE_RUST_FRONTEND="0", HF_HUB_OFFLINE="1",
                   TRANSFORMERS_OFFLINE="1", LIBRARY_PATH=f"{SHIM}:{os.environ.get('LIBRARY_PATH', '')}",
                   PATH=base["PATH"], VLLM_CACHE_ROOT=f"{TMP}/merlin-cache", TRITON_CACHE_DIR=f"{TMP}/merlin-triton",
                   FLASHINFER_WORKSPACE_BASE=f"{TMP}/merlin-fi", CUDA_DEVICE_ORDER="PCI_BUS_ID", VLLM_PLE_OFFLOAD_READY_TIMEOUT="3600")
        for k in ("CC", "CXX", "CUDAHOSTCXX"):
            env.pop(k, None)
        if MERLIN_CC["mode"] == "gcc13" and kvv.get("MERLIN_CC") and kvv.get("MERLIN_CXX"):
            env.update(CC=kvv["MERLIN_CC"], CXX=kvv["MERLIN_CXX"], CUDAHOSTCXX=kvv["MERLIN_CXX"])
            lib13 = Path(kvv["MERLIN_CC"]).parents[1] / "lib"
            if (lib13 / "libstdc++.so.6").exists():
                env["LD_LIBRARY_PATH"] = f"{lib13}:{env.get('LD_LIBRARY_PATH', '')}"
        try:                                               # Merlin's own scheme: PORT 8000..8355 -> 29500+d / 30000+100d
            mp, vp = eng["ML"].distributed_ports(str(port))
            env.update(MASTER_PORT=str(mp), VLLM_PORT=str(vp))
        except Exception:
            env.update(MASTER_PORT=str(29500 + port - 8000), VLLM_PORT=str(30000 + 100 * (port - 8000)))
        env.update(NB1_ENV.get(name) or {})              # E25 NB1: after build(), which strips every MERLIN_* variable
        argv = plan.argv()
        HELP[name] = L.help_check("merlin", argv[:argv.index("serve") + 1], env, argv)
        R["setup"].setdefault("merlin_plans", {})[name] = {"argv_tail": argv[-60:], "status": plan.status, "host_phase": HOST_PHASE[name],
                                                           "env_keys": {k: env[k] for k in sorted(env) if k.startswith(("VLLM_", "NCCL_", "KV_", "P2P", "SCALES", "CUDA_DEVICE_MAX_CONNECTIONS"))}}   # E25 NB4S
        save()
        return MServer(name, argv, env, port, LOGS)


    STOCK = None


    def stock_install():
        """Fallback only: stock vLLM 0.32 venv (E18 / E23 installer) with the -lcuda shim on LIBRARY_PATH (RC1's sampler crash)."""
        global STOCK
        if STOCK is not None:
            return STOCK
        if FAKE:
            STOCK = {"vllm": [sys.executable, FAKE], "env": dict(os.environ)}
            return STOCK
        rc, txt = run("install_stock", f"{sys.executable} {WHEELHOUSE} {TMP}/vllm-venv", timeout=2400)
        kv = dict(l.split("=", 1) for l in txt.splitlines() if l.startswith(("VENV_PYTHON=", "CUDA_HOME=")))
        if rc or "CUDA_HOME" not in kv:
            raise RuntimeError("stock vLLM 0.32 install failed (logs/install_stock.log)")
        env = {k: v for k, v in os.environ.items() if k not in ("PYTHONPATH", "CUDA_PATH", "LD_PRELOAD")}
        env.update(CUDA_HOME=kv["CUDA_HOME"], PATH=f"{TMP}/vllm-venv/bin:{kv['CUDA_HOME']}/bin:{env.get('PATH', '')}",
                   LIBRARY_PATH=f"{SHIM}:{env.get('LIBRARY_PATH', '')}", HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1",
                   VLLM_NO_USAGE_STATS="1", VLLM_CACHE_ROOT=f"{TMP}/vllm-cache", CUDA_DEVICE_ORDER="PCI_BUS_ID",
                   PYTORCH_CUDA_ALLOC_CONF="expandable_segments:True")
        STOCK = {"vllm": [f"{TMP}/vllm-venv/bin/vllm", "serve"], "env": env}
        return STOCK


    def stock_fn_server(name, port):
        eng = stock_install()
        flags = [str(INTEL), "--served-model-name", "q27", "--host", "127.0.0.1", "--port", str(port),
                 "--tensor-parallel-size", "4", "--enable-expert-parallel", "--max-model-len", "32768", "--max-num-seqs", "4",
                 "--max-num-batched-tokens", "4096", "--gpu-memory-utilization", "0.88", "--disable-custom-all-reduce",
                 "--language-model-only", "--engram-config", json.dumps({"cpu_offload": True}), "--load-format", "safetensors",
                 "--dtype", "bfloat16", "--kv-cache-dtype", "fp8_e4m3", "--default-chat-template-kwargs", XHIGH]
        # diagnostic only: RC1 had a 30,208-token BF16 pool at TP4; no MTP here, so prefix caching (default ON) is unaffected
        if FAKE:
            flags = [str(INTEL) + "-w4a16", "--tensor-parallel-size", "4", "--max-num-seqs", "4", "--port", str(port), "--max-model-len", "32768"]
        return L.Server(name, list(eng["vllm"]) + flags, eng["env"], port, LOGS)
    save()


if not RERUN:
    # ==================================================================== CELL 3 — prompts (Flash-Next tokenizer + its own template at xhigh)
    R["sections"]["A0"] = {}
    _t = time.time()
    R["sections"]["A0"]["host"] = host_facts()
    R["sections"]["A0"]["merge"] = merge_ckpt() if MERLIN_OK else {"ok": False, "why": "Merlin inputs missing", "inputs": R["inputs"]}
    R["sections"]["A0"]["host_mem"] = host_mem()
    log("A0 host", json.dumps(R["sections"]["A0"]["host"])[:1200])
    log("A0 merge", json.dumps(R["sections"]["A0"]["merge"])[:800])
    save()
    TOKDIR = TMP / "fn_tok"
    shutil.rmtree(TOKDIR, ignore_errors=True)
    TOKDIR.mkdir()
    # the Merlin checkpoint's tokenizer when the merge is OK; otherwise the Intel (stock fallback) checkpoint's own
    MERLIN_PROMPTS = bool(R["sections"]["A0"]["merge"].get("ok")) and (CKPT / "tokenizer.json").exists()
    _src = CKPT if MERLIN_PROMPTS else INTEL
    if _src is None or not (_src / "tokenizer.json").exists():
        raise FileNotFoundError("no tokenizer: the Merlin merge failed and the Intel fallback checkpoint is not attached")
    for _n in ("tokenizer.json", "tokenizer_config.json", "chat_template.jinja"):
        if (_src / _n).exists():
            shutil.copyfile(_src / _n, TOKDIR / _n)
    from tokenizers import Tokenizer
    from transformers import AutoTokenizer
    TOK = Tokenizer.from_file(str(TOKDIR / "tokenizer.json"))
    _HF = AutoTokenizer.from_pretrained(str(TOKDIR))
    _tpl = ((TOKDIR / "chat_template.jinja").read_text() if (TOKDIR / "chat_template.jinja").exists()
            else json.loads((TOKDIR / "tokenizer_config.json").read_text())["chat_template"])
    _tasks = json.load(open(ARC))
    _ids = sorted(_tasks)


    def _grid(g):
        return "\n".join("".join(str(v) for v in row) for row in g)


    def _task_text(k):
        t = _tasks[k]
        parts = [f"## Task {k}"]
        for i, ex in enumerate(t["train"]):
            parts.append(f"Example {i + 1} input:\n{_grid(ex['input'])}\nExample {i + 1} output:\n{_grid(ex['output'])}")
        for ex in t["test"]:
            parts.append(f"Test input:\n{_grid(ex['input'])}")
        return "\n\n".join(parts)


    _INTRO = "Find the transformation rule of each ARC task below and solve the test inputs.\n\n"
    _PH = "E13_BODY"


    def _render(effort):
        return _HF.apply_chat_template([{"role": "user", "content": _INTRO + _PH}], tokenize=False, add_generation_prompt=True,
                                       enable_thinking=True, reasoning_effort=effort, chat_template=_tpl)


    _RX, _RM = _render("xhigh"), _render("medium")
    assert _RX.count(_PH) == 1
    _head_txt, _tail_txt = _RX.split(_PH)
    _HEAD = TOK.encode(_head_txt, add_special_tokens=False).ids
    _TAIL = TOK.encode(_tail_txt, add_special_tokens=False).ids
    TPL_MSG = [{"role": "user", "content": _INTRO + _task_text(_ids[0])}]
    TPL_IDS = TOK.encode(_HF.apply_chat_template(TPL_MSG, tokenize=False, add_generation_prompt=True, enable_thinking=True,
                                                 reasoning_effort="xhigh", chat_template=_tpl), add_special_tokens=False).ids
    R["prompt_render"] = {"head_text": _head_txt[-600:], "tail_text": _tail_txt, "head_tokens": len(_HEAD), "tail_tokens": len(_TAIL),
                          "xhigh_differs_from_medium": _RX != _RM, "xhigh_sentence": "xhigh" in _head_txt,
                          "template_sha256": hashlib.sha256(_tpl.encode()).hexdigest(),
                          "tokenizer_json_sha256": hashlib.sha256((TOKDIR / "tokenizer.json").read_bytes()).hexdigest()}
    _TASK_IDS = {k: TOK.encode(_task_text(k) + "\n\n", add_special_tokens=False).ids for k in _ids}


    def prompt(band, variant):
        body, i = [], (variant * 7) % len(_ids)
        need = band - len(_HEAD) - len(_TAIL)
        while len(body) < need:
            body += _TASK_IDS[_ids[i % len(_ids)]]
            i += 1
        return _HEAD + body[:need] + _TAIL


    TOK_SHA = "0997f410c57a1f4e53b09e4be8f4a172d90edd9564368fb0847030937229b9f3"   # = the 27B Merlin tokenizer.json
    TPL_SHA = "c3cf9e34abf4f9e36c2d72165aa9c132d3e2a725b6c2586aaa3a8af9d7a81041"   # = the 27B FP8 chat_template.jinja
    R["prompt_render"]["source"] = "merlin" if MERLIN_PROMPTS else "intel_fallback"
    R["prompt_render"]["hashes_ok"] = (R["prompt_render"]["tokenizer_json_sha256"] == TOK_SHA and
                                       R["prompt_render"]["template_sha256"] == TPL_SHA)
    if MERLIN_PROMPTS:                    # the pinned hashes belong to the Merlin checkpoint only (Intel's are recorded)
        assert R["prompt_render"]["hashes_ok"], "Flash-Next tokenizer / template differ from the pinned Merlin checkpoint"
    assert R["prompt_render"]["xhigh_sentence"] and R["prompt_render"]["xhigh_differs_from_medium"], "xhigh render missing"
    BANDS = {"2k": 2048, "8k": 8192, "40k": 40000, "90k": 90000, "116k": 116000}
    NSTREAM = 8
    PROMPTS = {b: [prompt(n, v) for v in range(NSTREAM)] for b, n in BANDS.items()}
    MAX_NEW = {b: MAX_LEN - n - 512 for b, n in BANDS.items()}
    ORACLE_P = [PROMPTS["2k"][0], PROMPTS["2k"][1], PROMPTS["8k"][2]]
    LONG_P = [PROMPTS["40k"][3]]
    TF_P = {"40k": PROMPTS["40k"][5]}
    R["prompts"] = {b: {"n": len(p), "len": len(p[0])} for b, p in PROMPTS.items()}
    log("prompts", json.dumps(R["prompts"]), "| render", json.dumps({k: v for k, v in R["prompt_render"].items() if "text" not in k}))
    save()


if not RERUN:
    # ==================================================================== CELL 4 — the step runner (E23, verbatim)
    HELP = HELP if "HELP" in globals() else {}
    WIN = float(os.environ.get("E23_WIN_SEC") or 90.0)   # 120 s FULL windows
    EST_SCALE = float(os.environ.get("E23_EST_SCALE") or 1.0) if FAKE else 1.0   # local harness only: walk the whole order
    SM_TF = MODE == "SMOKE"                                            # SMOKE teacher-forced: the 40k row only
    ROWS = {}            # oracle greedy rows by key (same weights)
    TF = {}              # teacher-forced rows by key
    NTOK = 128 if MODE == "FULL" else 64
    LIVE = {"rec": None}                 # rev 3c: windows land in the step record before every save (a hard kill keeps them)
    COMPILE_ERR = re.compile(r"ninja: build stopped|Error building extension|error: command '.*(nvcc|g\+\+|gcc|c\+\+)' failed|"
                             r"GLIBCXX_[0-9.]+' not found|unsupported GNU version|fatal error: ")
    OOM_ERR = re.compile(r"OutOfMemoryError|CUDA out of memory|out of memory")
    XID = re.compile(r"NVRM: Xid|\bXid \d+|CUDA error: an illegal memory access|illegal memory access was encountered|"
                     r"unspecified launch failure|CUDA error: misaligned address")       # rev 3e: device faults, not any CUDA error


    def keep_after_error(rec, e):
        """E25 NB1 R2: an exception after the measurements (post-processing) keeps the whole record + postprocess_error /
        postprocess_tb. A clean boot (status None / NOT_RUN / DONE / TF_OOM, correctness CLEAN, quality PASS) keeps its status
        (None / NOT_RUN -> DONE), so its dependent boots still run; any other record -> POSTPROCESS_ERROR (status_before kept).
        R2 audit N1-3: postprocess_ok False; whether the dependents run is decided by core_measurements_complete (core_check)."""
        rec["postprocess_ok"] = False
        rec["postprocess_error"] = f"{type(e).__name__}: {e}"[:800]
        rec["postprocess_tb"] = traceback.format_exc()[-2500:]
        if (rec.get("status") in (None, "NOT_RUN", "DONE", "TF_OOM") and rec.get("correctness") == "CLEAN"
                and rec.get("quality_gate") == "PASS"):
            if rec.get("status") in (None, "NOT_RUN"):
                rec["status"] = "DONE"
        else:
            rec["status_before_postprocess"] = rec.get("status")
            rec["status"] = "POSTPROCESS_ERROR"
        return rec


    def step(sec, name, est_min, fn):
        """One measured step: skipped when the budget cannot hold it, recorded on any exception, never PASS by default."""
        rec = R["sections"].setdefault(sec, {}).setdefault(name, {"status": "NOT_RUN"})
        R["order"].append(f"{sec}/{name}")
        if ABORT["why"]:
            rec.update(status="SKIPPED_ABORT", why=ABORT["why"])
            log("---", sec, name, "SKIPPED_ABORT")
            save()
            return rec
        if left() < est_min * EST_SCALE * 60 + 300:
            rec.update(status="SKIPPED_BUDGET", left_min=round(left() / 60, 1), est_min=est_min)
            log("---", sec, name, "SKIPPED_BUDGET", f"(est {est_min} min, left {left() / 60:.0f} min)")
            save()
            return rec
        LIVE["rec"] = rec
        LIVE["out"] = None                       # E25 NB1 R2: the body's record once it returned (set by watched() / run_boot())
        t = time.time()
        log(">>>", sec, name, f"(est {est_min} min, left {left() / 60:.0f} min)")
        out = None                               # E25 NB1 R2
        try:
            out = fn() or {}
            rec.update(out)
            if rec.get("status") in (None, "NOT_RUN"):
                rec["status"] = "DONE"
        except Exception as e:
            part = out if isinstance(out, dict) and out else LIVE.get("out")   # E25 NB1 R2: never discard what the body produced
            if isinstance(part, dict) and part:                               # E25 NB1 R2
                rec.update(part)                                              # E25 NB1 R2
                keep_after_error(rec, e)                                      # E25 NB1 R2: clean -> DONE + postprocess_error
            else:                                                             # E25 NB1 R2
                rec.update(status="ERROR", error=f"{type(e).__name__}: {e}"[:800], tb=traceback.format_exc()[-2500:])
        rec["sec"] = round(time.time() - t, 1)
        LIVE["rec"] = None
        LIVE["out"] = None                       # E25 NB1 R2
        if ABORT["why"] and rec["status"] in ("DONE", "SERVER_DIED", "LAUNCH_FAILED", "BODY_ERROR"):
            rec["status"] = "PARTIAL_HARD_STOP"
        log("<<<", sec, name, rec.get("status"), f"{rec['sec']:.0f}s")
        save()
        return rec


    def with_servers(servers, timeout, body):
        """Start, wait ready, record facts + memory, run body(servers), always kill; then the GPU-release gate on these
        servers' GPUs only; abort the lab if they stay held."""
        out = {"servers": {}}
        timeout = max(60, min(timeout, left() - 120))
        try:
            for s in servers:
                s.start()
            for s in servers:
                ok, why = s.wait_ready(timeout)
                out["servers"][s.name] = {"ready": ok, "why": why, **s.facts(), "argv_tail": s.argv[-44:], "gpus": s.gpus,
                                          "help_check": HELP.get(s.name)}
                if not ok:
                    out["status"] = "LAUNCH_FAILED"
                    out["servers"][s.name]["log_tail"] = s.log()[-4000:]
                    _xl = [l for l in (s.log() or "").splitlines() if XID.search(l)][:8]   # rev 3e/3f: start-up / capture faults
                    out["servers"][s.name].update(xid=bool(_xl), xid_lines=_xl)
                    return out
            mem0 = L.gpu_mem()
            for s in servers:
                out["servers"][s.name].update(gpu_mem_after_ready=mem0, host_rss_mb=s.rss_mb())
            try:                             # rev 3: an exception in the body keeps everything measured so far
                out.update(body(servers) or {})
            except Exception as e:
                out.update(status="BODY_ERROR", body_error=f"{type(e).__name__}: {e}"[:800], body_tb=traceback.format_exc()[-2000:])
            for s in servers:
                out["servers"][s.name].update(s.facts(), gpu_mem_end=L.gpu_mem(), host_rss_mb_end=s.rss_mb(),
                                              alive_after_body=s.alive(), rc=None if s.alive() else s.proc.returncode,
                                              xid_lines=[l for l in (s.log() or "").splitlines() if XID.search(l)][:8])
                out["servers"][s.name]["xid"] = bool(out["servers"][s.name]["xid_lines"])
                if not s.alive():
                    out["status"] = "SERVER_DIED"
                    out["servers"][s.name]["log_tail"] = s.log()[-4000:]
            return out
        finally:
            for s in servers:
                s.kill()
            gpus = ",".join(sorted({g for s in servers for g in s.gpus.split(",")}))
            rel = L.wait_gpu_release(180, fake=bool(FAKE), gpus=gpus)
            if rel is False:                 # rev 3c: one more kill + 300 s before the lab aborts
                for s in servers:
                    s.kill()
                rel = L.wait_gpu_release(300, fake=bool(FAKE), gpus=gpus)
            if rel is None and NVSMI_OK:     # nvidia-smi worked at start: a failure now is not "released"
                rel = False
            out["gpu_released"] = rel
            if rel is False:
                ABORT["why"] = f"GPUs {gpus} still held after {[s.name for s in servers]}"
                out["status"] = "FAIL_GPU_RELEASE"


    def oracle(port, key=None, refs=()):
        """Greedy rows (2k, 2k, 8k) + one 40k row; saved under `key` (a target-only oracle) or compared with ROWS[ref]."""
        rows = L.greedy(port, ORACLE_P + LONG_P, n_tok=NTOK, timeout=max(120, min(900, left() / 6)))
        clean = all(not r.get("error") and r.get("tokens") and not L.degenerate(r.get("text")) for r in rows)
        if key and clean:            # rev 3d: an errored / empty / garbage reference is never stored (consumers: NO_ORACLE)
            ROWS[key] = rows
        elif key:
            R["errors"].append(f"oracle {key}: reference not stored (error / empty / garbage row)")
        res = {"garbage": [L.degenerate(r["text"]) for r in rows], "errors": [r["error"] for r in rows],
               "text_head": [r["text"][:120] for r in rows]}
        if not FAKE:                 # rev 3h: chat-path render vs the production xhigh render (recorded per arm)
            res["template_probe"] = L.template_probe(port, TPL_MSG, TPL_IDS)
        for ref in refs:
            res["vs_" + ref] = L.compare(ROWS.get(ref), rows) if ROWS.get(ref) else {"status": "INCONCLUSIVE_NO_ORACLE"}
        return res


    def tforced(port, key=None, ref=None):
        """Teacher-forced 40k / 90k prompt logprobs (last 256 positions); saved under `key` or compared with TF[ref].
        rev 3c: on stock vLLM only on its own short launch (prompt logprobs = chunk x 248k-vocab logits: OOM at 0.90)."""
        rows = {b: L.teacher_forced(port, ids) for b, ids in TF_P.items() if not (SM_TF and b != "40k")}
        if key and L.tf_complete(rows):                                 # rev 3e: complete references only
            TF[key] = rows
        elif key:
            R["errors"].append(f"teacher-forced {key}: reference not stored (incomplete band)")
        if ref:
            return {b: L.compare_tf((TF.get(ref) or {}).get(b), rows[b]) for b in rows}
        return {b: {"n": (rows[b] or {}).get("n"), "error": (rows[b] or {}).get("error")} for b in rows}


    def levels(port, band, lv, server=None, **kw):
        """rev 3c: the guard includes admission (prefill) time; a band stops once KV-bound (the fit is recorded); a dead
        server stops the band; every window is written into the live step record before save()."""
        out, fit = {}, None
        for n in lv:
            k = f"{band}@{n}"
            need = WIN + 90 + min(3600, n * BANDS[band] / 1500)
            if ABORT["why"] or left() < need + 120:
                out[k] = {"status": "SKIPPED_BUDGET", "need_sec": round(need)}
            elif fit is not None:
                out[k] = {"status": "SKIPPED_KV_BOUND", "streams_fit": fit}
            elif server is not None and not server.alive():
                out[k] = {"status": "SKIPPED_SERVER_DEAD"}
            else:
                try:                         # rev 3: one failing level never loses the others
                    out[k] = L.steady(port, PROMPTS[band], n, secs=WIN, max_new=MAX_NEW[band], **kw)
                except Exception as e:
                    out[k] = {"status": "ERROR", "error": f"{type(e).__name__}: {e}"[:300]}
                rm = out[k].get("running_max")
                if out[k].get("status") == "CAPACITY_LIMITED" or (rm is not None and 0 < rm < n and
                                                                  str(out[k].get("status")).startswith("INCONCLUSIVE")):
                    fit = rm
            if LIVE["rec"] is not None:
                LIVE["rec"].setdefault("live_windows", {})[k] = out[k]
            save()
        return out
    save()


if not RERUN:
    # ==================================================================== CELL 5 — the arms
    LADDER = [1, 2, 4, 5]                    # 40k: 8 streams would need 8 x (10 + 7) blocks of 4096 > 149 FP8 blocks (preempts)
    TEMP = 0.6                               # production sampling (Merlin's --override-generation-config is T 1.0)
    E23_TF_SCALE = {"tp4_vs_tp1_layout": 0.0772, "nvfp4_vs_bf16_kv": 0.3787}   # E23 SMOKE rev3g mean |d logprob|, for scale
    PREFILL = {"tok_s": 700.0, "measured": False}
    OOM_STEP = 268435456                     # Merlin's note: lower KV_BYTES in 0.25 GiB steps if the boot OOMs
    # Pre-run capacity (Merlin's rule: blocks per request = ceil(L / 4096) + 7; FP8 149 usable blocks, BF16 ~78)
    R["capacity_plan"] = {
        "fp8": {"pool_blocks": 149, "40k@5": 5 * (math.ceil(130560 / 4096) + 7), "8k@8": 8 * (math.ceil(32000 / 4096) + 7),
                "90k@4": 4 * (math.ceil(131072 / 4096) + 7), "116k@3": 3 * (math.ceil(131072 / 4096) + 7),
                "116k@4": 4 * (math.ceil(131072 / 4096) + 7),
                "note": "blocks if every stream grew to max length; the ladder windows are 90 s, so real use is far lower; "
                        "90k@4 and 116k@4 are capacity-limit probes"},
        "bf16": {"pool_blocks": 78, "40k@3": 3 * (math.ceil(130560 / 4096) + 7)},
        "long_rows": "1 natural xhigh ARC row (max 120,000 new) + 1 forced 60,000-token row, temperature 0.6, run CONCURRENTLY "
                     "(concurrency 2): not a single-stream latency number",
    }
    R["correctness_meaning"] = ("Both Merlin boots run MTP K3: CLEAN = BF16_MTP3 vs FP8_MTP3 parity plus probes / sampled / greedy "
                                "evidence; it is NOT target-only (MTP off) correctness. A production GO needs an MTP-off oracle and "
                                "a forced-rejection test.")
    CLEAN = ("EXACT", "NEAR_TIE")


    def _windows(o):
        """Every steady window of a step record (levels dicts + steady_multi replicas)."""
        out = []
        for v in (o.get("steady") or {}).values():
            if isinstance(v, dict):
                out.append(v)
        for k in ("40k", "90k"):
            for r in ((o.get(k) or {}).get("replicas") or []) if isinstance(o.get(k), dict) else []:
                if isinstance(r, dict):
                    out.append(r)
        return out


    def oracle_gate(o, need=(), extra=()):
        """None when clean; otherwise the NO_GO / INCONCLUSIVE status. `need` = refs that must compare clean; `extra` =
        further comparison dicts (replica greedy, 90k greedy) that must compare clean too. rev 3e (audits B-O1, C-F2):
        garbage under load in any window and failed arithmetic probes (real servers; the fake has no chat) are NO_GO too."""
        orc = o.get("oracle") or {}
        if any(orc.get("errors") or []):
            return "NO_GO_ORACLE_REQUEST_ERROR"
        if any(orc.get("garbage") or []):
            return "NO_GO_ORACLE_GARBAGE"
        if any(w.get("status") == "FAIL_GARBAGE_UNDER_LOAD" for w in _windows(o)):
            return "NO_GO_GARBAGE_UNDER_LOAD"
        if not FAKE and isinstance(o.get("probes"), dict) and o["probes"].get("ok") is False:
            return "NO_GO_SHORT_PROBE"
        sts = [(orc.get("vs_" + k) or {}).get("status") for k in need] + [(x or {}).get("status") for x in extra]
        if any(s == "FAIL_HIGH_MARGIN" for s in sts):
            return "NO_GO_ORACLE"
        if any(s not in CLEAN for s in sts):
            return "INCONCLUSIVE_NO_ORACLE" if any(s in (None, "INCONCLUSIVE_NO_ORACLE") for s in sts) else "INCONCLUSIVE_ORACLE"
        return None


    def gated(o, need=(), extra=()):
        g = oracle_gate(o, need, extra)
        o["correctness"] = g or "CLEAN"
        if g and o.get("status") in (None, "DONE"):
            o["status"] = g
        return o




    def _finite(x):
        return isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x)


    _compare_e23, _compare_tf_e23 = L.compare, L.compare_tf


    def _compare_rc2(ref, cand):
        """Final audit H2: a non-finite margin on either side makes the comparison INCONCLUSIVE before any token logic
        (E23's compare read a NaN reference margin as NEAR_TIE)."""
        for rows in (ref or [], cand or []):
            for r in rows:
                if any(m is not None and not _finite(m) for m in (r.get("margins") or [])):
                    return {"status": "INCONCLUSIVE_NONFINITE"}
        return _compare_e23(ref, cand)


    def _compare_tf_rc2(ref, cand):
        """Final audit H2: a non-finite teacher-forced logprob is never MEASURED."""
        for side in (ref, cand):
            for p in ((side or {}).get("positions") or []):
                if p and p[0] is not None and not _finite(p[0]):
                    return {"status": "INCONCLUSIVE_NONFINITE"}
        return _compare_tf_e23(ref, cand)


    L.compare, L.compare_tf = _compare_rc2, _compare_tf_rc2


    def short_gate_failed(o):
        """Final audit H1: a failed probe (real servers; the fake has no chat) or a failed / garbage sampled request stops
        the boot's body at once; gated() then gives the NO_GO verdict."""
        p, s = o.get("probes") or {}, o.get("sampled") or {}
        return (p.get("ok") is not True and not FAKE) or s.get("ok") is not True or bool(s.get("garbage"))


    def oracle_ok(orc):
        return bool(orc) and orc.get("complete") is True and not any(orc.get("errors") or []) and not any(orc.get("garbage") or [])


    def _windows(o):
        """Every load window of a record: the ladder AND the long census (audit: census_long was not gated)."""
        out = []
        for key in ("steady", "census_long"):
            for v in (o.get(key) or {}).values():
                if isinstance(v, dict):
                    out.append(v)
        return out


    def evidence_gate(o, expected_rows, require_sampled=True):
        """Fail-closed evidence (three pre-GPU audits): probes, the sampled path and a COMPLETE oracle are mandatory;
        a missing piece is never CLEAN. expected_rows None = no oracle in this arm (diagnostic arms)."""
        pr = o.get("probes")
        if not isinstance(pr, dict):
            return "INCONCLUSIVE_PROBES_MISSING"
        if pr.get("ok") is not True and not FAKE:          # the fake server has no chat endpoint (E23 rule)
            return "NO_GO_SHORT_PROBE"
        if require_sampled:
            sm = o.get("sampled")
            if not isinstance(sm, dict):
                return "INCONCLUSIVE_NO_SAMPLED_TEST"
            if sm.get("ok") is not True or sm.get("garbage"):
                return "NO_GO_SAMPLED_PATH"
        if expected_rows is None:
            return None
        orc = o.get("oracle")
        if not isinstance(orc, dict):
            return "INCONCLUSIVE_NO_ORACLE"
        if any(orc.get("errors") or []):
            return "NO_GO_ORACLE_REQUEST_ERROR"
        if any(orc.get("garbage") or []):
            return "NO_GO_ORACLE_GARBAGE"
        if orc.get("row_count") != expected_rows or orc.get("complete") is not True:
            return "INCONCLUSIVE_ORACLE_INCOMPLETE"
        return None


    _gated_e23 = gated


    def gated(o, need=(), extra=(), expected_rows=4, require_sampled=True):
        g = evidence_gate(o, expected_rows, require_sampled)
        if g:
            o["correctness"] = g
            if o.get("status") in (None, "DONE"):
                o["status"] = g
            return o
        return _gated_e23(o, need, extra)


    def oracle(port, key=None, refs=(), prompts=None):
        """E23's oracle plus completeness: every expected row present, no error, exactly NTOK tokens (greedy rows run with
        ignore_eos, so a short row is a defect); a reference is stored only when complete and garbage-free."""
        prompts = list(prompts) if prompts is not None else ORACLE_P + LONG_P
        rows = L.greedy(port, prompts, n_tok=NTOK, timeout=max(120, min(900, left() / 6)))
        garbage = [L.degenerate(r.get("text")) for r in rows]
        complete = len(rows) == len(prompts) and all(not r.get("error") and len(r.get("tokens") or []) == NTOK for r in rows)
        if key and complete and not any(garbage):
            ROWS[key] = rows
        elif key:
            R["errors"].append(f"oracle {key}: reference not stored (incomplete / error / garbage)")
        res = {"garbage": garbage, "errors": [r.get("error") for r in rows], "text_head": [(r.get("text") or "")[:120] for r in rows],
               "row_count": len(rows), "expected_rows": len(prompts), "tokens": [len(r.get("tokens") or []) for r in rows],
               "complete": complete}
        if not FAKE:
            res["template_probe"] = L.template_probe(port, TPL_MSG, TPL_IDS)
        for ref in refs:
            res["vs_" + ref] = L.compare(ROWS.get(ref), rows) if ROWS.get(ref) else {"status": "INCONCLUSIVE_NO_ORACLE"}
        return res


    def kv_census(s):
        log_t = s.log() or ""
        lines = log_t.splitlines()
        kv = re.findall(r"GPU KV cache size: ([\d,]+) tokens", log_t)
        conc = re.findall(r"Maximum concurrency for ([\d,]+) tokens per request: ([\d.]+)x", log_t)
        pick = lambda rx, n=24: [l[:240] for l in lines if re.search(rx, l, re.I)][:n]
        return {"kv_tokens": [int(x.replace(",", "")) for x in kv][:2], "max_concurrency": conc[:2],
                "scale_lines": pick(r"K/V scale|kv scale|scaling factor|DEFAULT 1\.0|static K/V"),
                "engine_lines": pick(r"WNA16 MoE backend|MarlinExperts|PLE offload|engram|cudagraph_mode|CUDAGraphMode|PIECEWISE"),
                "startup_lines": pick(r"Loading weights took|Model loading took|torch\.compile takes|torch\.compile took|"
                                      r"Graph capturing finished|init engine|PLE.*ready|Available KV cache memory"),
                "oom_lines": [l[:240] for l in lines if OOM_ERR.search(l)][:6], "host_mem": host_mem()}


    def sampled_check(s):
        """RC1 died at its first sampled request (FlashInfer sampling JIT: ld cannot find -lcuda): one short sampled request
        right after ready, then the engine must still be alive."""
        g = L.Stream(s.port, PROMPTS["2k"][1], 64, temperature=TEMP, seed=5)
        g.start()
        g.join(900)
        if g.is_alive():
            g.stop()
            g.join(10)
        r = g.row()
        return {"tokens": len(r["tokens"]), "error": r["error"], "finish": r["finish_reason"], "alive_after": s.alive(),
                "garbage": L.degenerate(r["text"]), "ok": len(r["tokens"]) == 64 and not r["error"] and s.alive()}


    def prefill_probe(port):
        """Time to first token of one cold 40k prompt (1 new token): the measured prefill rate the ladder admission uses."""
        ids = PROMPTS["40k"][7]
        g = L.Stream(port, ids, 1, temperature=0.0)
        g.start()
        g.join(1800)
        if g.is_alive():
            g.stop()
            g.join(10)
        sec = (g.t_first or g.t_end or time.perf_counter()) - (g.t_start or time.perf_counter())
        ok = not g.err and g.t_first is not None
        if ok:
            PREFILL.update(tok_s=round(len(ids) / max(1e-3, sec), 1), measured=True)
        return {"prompt": len(ids), "ttft_sec": round(sec, 1), "tok_s": round(len(ids) / max(1e-3, sec), 1), "error": g.err, "ok": ok}


    def window_garbage(ids, win=2000, min_len=200):
        """Final audit H3: the first garbage 2,000-token window of a row (None if every window is clean). A whole-text check
        would read 100k tokens of healthy reasoning as LOW_VARIETY (unique words < 8 %), so windows are checked one by one."""
        for i in range(0, len(ids), win):
            seg = ids[i:i + win]
            if len(seg) < min_len:
                break
            v = L.degenerate(TOK.decode(seg))
            if v:
                return {"start_token": i, "verdict": v}
        return None


    def long_quality(name, r):
        if not isinstance(r, dict):
            return "MISSING_LONG"
        if r.get("error"):
            return "FAIL_LONG_REQUEST"
        if r.get("window_garbage"):
            return "FAIL_LONG_GARBAGE"
        if name == "forced60k" and not r.get("reached_60k"):
            return "INCOMPLETE_LONG"
        if name == "natural" and r.get("cut_by_cap"):
            return "INCOMPLETE_LONG"
        return "PASS_LONG"


    def long_gate(o):
        """None when the record has no long rows or both rows PASS_LONG; otherwise the verdict for the top-level status.
        Priority: request error > natural garbage > forced garbage (synthetic past its first EOS) > incomplete."""
        lo = o.get("long")
        if not isinstance(lo, dict):
            return None
        q = {n: long_quality(n, lo.get(n)) for n in ("natural", "forced60k")}
        lo["long_quality"] = q
        if "MISSING_LONG" in q.values():
            return "INCONCLUSIVE_LONG_MISSING"
        if "FAIL_LONG_REQUEST" in q.values():
            return "NO_GO_LONG_REQUEST_ERROR"
        if q["natural"] == "FAIL_LONG_GARBAGE":
            return "NO_GO_LONG_GARBAGE"
        if q["forced60k"] == "FAIL_LONG_GARBAGE":
            return "NO_GO_FORCED60K_GARBAGE"
        if "INCOMPLETE_LONG" in q.values():
            return "INCONCLUSIVE_LONG_INCOMPLETE"
        return None


    def long_rows(port, secs_cap=3000):
        """One natural xhigh ARC request (its own stop, up to 120,000 new tokens) and one forced 60,000-token row
        (ignore_eos: 'synthetic' past its first EOS), CONCURRENTLY (concurrency 2). Full text in traces/ + requests.jsonl.
        A row cut by the time cap is incomplete, not a correctness failure."""
        cap = max(60, min(secs_cap, left() - 900))
        jobs = {"natural": L.Stream(port, TPL_IDS, min(120000, MAX_LEN - len(TPL_IDS) - 512), temperature=TEMP, seed=11,
                                    ignore_eos=False),
                "forced60k": L.Stream(port, PROMPTS["8k"][0], 60000, temperature=TEMP, seed=12, ignore_eos=True)}
        t = time.time()
        for g in jobs.values():
            g.start()
        for g in jobs.values():
            g.join(max(1, cap - (time.time() - t)))
        for g in jobs.values():
            if g.is_alive():
                g.stop()
                g.join(10)
        out = {"concurrency": 2, "cap_sec": round(cap)}
        for name, g in jobs.items():
            row = g.row()
            (TRACES / f"long_{port}_{name}.txt").write_text(row["text"])
            ids = row["tokens"]
            n_tok = len(ids)
            sec = (g.t_end or time.perf_counter()) - (g.t_start or time.perf_counter())
            sl = {}
            for k, end in (("to_8k", 8000), ("to_32k", 32000), ("to_60k", 60000), ("to_100k", 100000)):
                sl[k] = L.degenerate(TOK.decode(ids[end - 2000:end])) if n_tok >= end else "NOT_REACHED"
            out[name] = {"tokens": n_tok, "sec": round(sec, 1), "tok_s": round(n_tok / max(1e-6, sec), 1), "error": row["error"],
                         "finish": row["finish_reason"], "garbage": sl, "window_garbage": window_garbage(ids),
                         "think_closed": "</think>" in row["text"], "cut_by_cap": row["finish_reason"] is None,
                         "tail": row["text"][-400:]}
        out["forced60k"]["reached_60k"] = out["forced60k"]["tokens"] >= 60000
        out["forced60k"]["label"] = "synthetic past the first EOS (ignore_eos)"
        try:
            m = {k: v for k, v in L.prom(port).items() if k.startswith(("vllm:spec_decode", "vllm:num_preemptions", "vllm:kv_cache_usage"))}
        except Exception as e:
            m = {"error": repr(e)[:200]}
        acc, drf = m.get(L.ACC), m.get(L.DRF)
        out["metrics_end"] = m
        out["mtp_accept_per_draft"] = round(acc / drf, 3) if acc and drf else None
        return out


    def tf_last(s, key=None, ref=None, aa=False):
        """Teacher-forced 40k LAST in a boot (chunk x 248k-vocab prompt logits can OOM the last PP rank); free memory first.
        How a server death here is classified is decided from its log in merlin_boot (TF_OOM vs TF_SERVER_DIED)."""
        o = {"gpu_before": L.gpu_mem()}
        if key:
            o["ref"] = tforced(s.port, key=key)
            if aa and s.alive():
                o["aa"] = tforced(s.port, ref=key)              # A/A: the same boot, the same prompt (the noise floor)
                TF["aa"] = o["aa"]
        if ref:
            o["vs_" + ref] = tforced(s.port, ref=ref)
            o["aa_" + ref] = TF.get("aa")
            o["e23_scale"] = E23_TF_SCALE
        o["alive_after"] = s.alive()
        return o


    def merlin_boot(name, kv, port, timeout, body, need=(), expected_rows=4, require_sampled=True):
        """Boot gate (ok must be True), one Merlin boot, cleanup of the /dev/shm entries this boot created; a boot OOM
        retries once 0.25 GiB lower. A server death during TF is TF_OOM only with an OOM line and no device fault."""
        kvb = NB1_KV.get(name) or (KV_FP8 if kv == "fp8" else KV_BF16)   # E25 NB1: the B3 pin step
        tries = []
        while True:
            gate = boot_gate()
            if gate["ok"] is not True:
                return {"status": "GPU_NOT_EMPTY", "boot_gate": gate, "tries": tries}
            shm0 = shm_names()
            o = with_servers([merlin_fn_server(name, kv, port, kvb)], timeout, body)
            o.update(kv_bytes=kvb, boot_gate=gate, shm_cleanup=shm_cleanup(shm0))
            srv = (o.get("servers") or {}).get(name) or {}
            oom = o.get("status") == "LAUNCH_FAILED" and bool(OOM_ERR.search(srv.get("log_tail") or ""))
            tries.append({"kv_bytes": kvb, "status": o.get("status"), "oom": oom})
            if not oom or len(tries) > 1 or left() < timeout + 900:
                break
            kvb -= OOM_STEP
            log("boot OOM:", name, "retry with KV_BYTES", kvb)
        o["tries"] = tries
        if o.get("tf_died") and o.get("status") == "SERVER_DIED":
            srv = (o.get("servers") or {}).get(name) or {}
            if OOM_ERR.search(srv.get("log_tail") or "") and not srv.get("xid"):
                o["status"] = "TF_OOM"
                o["status_note"] = "the server died of OOM in the teacher-forced call (run last); everything before it is valid"
            else:
                o["status"] = "TF_SERVER_DIED"
                o["status_note"] = "the server died in the teacher-forced call without an OOM line (or with a device fault)"
        g = gated(o, need=need, expected_rows=expected_rows, require_sampled=require_sampled)
        if g.get("status") == "TF_OOM" and g.get("correctness") != "CLEAN":
            g["status"] = g["correctness"]
        lg = long_gate(g)                                  # final audit H3: the long rows have their own verdict
        g["long_verdict"] = lg or ("PASS_LONG" if isinstance(g.get("long"), dict) else None)
        if lg and g.get("status") in ("DONE", "TF_OOM"):
            g["status"] = lg
        return g


    def arm_bf16():
        def body(ss):
            s = ss[0]
            p = s.port
            o = {"census": kv_census(s), "probes": L.chat_probes(p), "sampled": sampled_check(s)}
            if short_gate_failed(o):
                o.update(early_stop="SHORT_CORRECTNESS_GATE_FAILED", census_end=kv_census(s))
                return o
            o["prefill"] = prefill_probe(p)
            o["oracle"] = oracle(p, key="bf16")
            o["census_end"] = kv_census(s)
            if not oracle_ok(o["oracle"]):
                o["early_stop"] = "ORACLE_INCOMPLETE"          # no reference: the TF A/A would measure nothing usable
                return o
            o["tf"] = tf_last(s, key="bf16", aa=True)
            o["tf_died"] = not o["tf"]["alive_after"]
            return o
        ok, why = sha_gate(min(1500, left() - 900))
        R["setup"]["sha_gate"] = {"ok": ok, "why": why}
        if not ok:
            return {"status": "SKIPPED_SHA_GATE", "why": why}
        return merlin_boot("merlin_bf16", "bf16", 8000, 45 * 60, body)


    def fp8_gate(o):
        vs = (o["oracle"].get("vs_bf16") or {}).get("status")
        if (o.get("sampled") or {}).get("ok") is not True:
            return "FAIL_SAMPLED"
        if (o.get("probes") or {}).get("ok") is not True and not FAKE:
            return "FAIL_PROBES"
        if any(o["oracle"].get("errors") or []) or any(o["oracle"].get("garbage") or []) or vs == "FAIL_HIGH_MARGIN":
            return "FAIL"
        if o["oracle"].get("complete") is True and vs in CLEAN:
            return "PASS"
        return "INCONCLUSIVE"


    def arm_fp8():
        def body(ss):
            s = ss[0]
            p = s.port
            o = {"census": kv_census(s), "probes": L.chat_probes(p), "sampled": sampled_check(s)}
            if short_gate_failed(o):
                o.update(early_stop="SHORT_CORRECTNESS_GATE_FAILED", census_end=kv_census(s),
                         fp8_gate="FAIL_SAMPLED" if (o["sampled"] or {}).get("ok") is not True else "FAIL_PROBES")
                return o
            if not PREFILL["measured"]:
                o["prefill"] = prefill_probe(p)
            o["oracle"] = oracle(p, refs=("bf16",))
            o["fp8_gate"] = fp8_gate(o)
            if o["fp8_gate"] == "PASS":                      # load tests only on a PASS (audits: INCONCLUSIVE never runs them)
                kw = {"server": s, "temperature": TEMP, "prefill_tok_s": PREFILL["tok_s"]}
                o["steady"] = levels(p, "40k", LADDER, **kw)
                o["steady"].update(levels(p, "8k", [8], **kw))
                o["census_long"] = {**levels(p, "90k", [3, 4], **kw), **levels(p, "116k", [3, 4], **kw)}
                o["long"] = long_rows(p)
            else:
                o["load_tests_skipped"] = f"FP8 comparison gate: {o['fp8_gate']}"
                o["status"] = "NO_GO_FP8_KV" if o["fp8_gate"].startswith("FAIL") else "INCONCLUSIVE_FP8_KV"
            o["census_end"] = kv_census(s)
            if o["fp8_gate"] == "PASS" or os.environ.get("RC2_TF_ON_FP8_FAIL") == "1":   # default: fail fast
                o["tf"] = tf_last(s, ref="bf16")
                o["tf_died"] = not o["tf"]["alive_after"]
            return o
        return merlin_boot("merlin_fp8", "fp8", 8001, 40 * 60, body, need=("bf16",))


    def arm_bf16_load():
        """Only when FP8 fails: the ladder, the census and the long rows on BF16 KV (seqs 3). DIAGNOSTIC_ONLY: this arm
        has no oracle of its own (the A1 boot is the BF16 reference)."""
        def body(ss):
            s = ss[0]
            p = s.port
            o = {"census": kv_census(s), "probes": L.chat_probes(p), "sampled": sampled_check(s)}
            if short_gate_failed(o):
                o["early_stop"] = "SHORT_CORRECTNESS_GATE_FAILED"
            else:
                kw = {"server": s, "temperature": TEMP, "prefill_tok_s": PREFILL["tok_s"]}
                o["steady"] = levels(p, "40k", [1, 2, 3], **kw)
                o["census_long"] = levels(p, "116k", [1, 2], **kw)
                o["long"] = long_rows(p)
            o["census_end"] = kv_census(s)
            o["certification"] = "DIAGNOSTIC_ONLY"
            return o
        return merlin_boot("merlin_bf16_load", "bf16", 8002, 30 * 60, body, expected_rows=None)


    def arm_stock():
        """Fallback when Merlin cannot serve: stock vLLM 0.32 + Intel W4A16 (RC1's correct engine), -lcuda shim, FP8 KV."""
        if INTEL is None or WHEELHOUSE is None:
            return {"status": "FALLBACK_UNAVAILABLE", "why": f"intel={INTEL} wheelhouse={WHEELHOUSE}"}

        def body(ss):
            s = ss[0]
            p = s.port
            o = {"census": kv_census(s), "probes": L.chat_probes(p), "sampled": sampled_check(s)}
            if short_gate_failed(o):
                o["early_stop"] = "SHORT_CORRECTNESS_GATE_FAILED"
                return o
            o["oracle"] = oracle(p, key="stock", prompts=ORACLE_P)          # 2k / 2k / 8k (32k max length: no 40k row)
            if oracle_ok(o["oracle"]):
                o["steady"] = levels(p, "8k", [1, 2, 3], server=s, temperature=TEMP)
            return o
        gate = boot_gate()
        if gate["ok"] is not True:
            return {"status": "GPU_NOT_EMPTY", "boot_gate": gate}
        shm0 = shm_names()
        o = gated(with_servers([stock_fn_server("stock_fn", 8003)], 40 * 60, body), expected_rows=len(ORACLE_P))
        o.update(boot_gate=gate, shm_cleanup=shm_cleanup(shm0))
        return o


    save()


if not RERUN:
    # ==================================================================== CELL 6 — E25 NB1: measurement tools (NB1 R2 verbatim; E25 NB4S dropped the unused capacity / prefix / routing / PP2-trace functions: commit_mode, commit_ab, commit_counter_delta, pool_blocks_from_usage, reset_cache, _hits, alloc_sequence, reset_succeeded, fit_alloc, kv_accounting, n_fit, admission_test, residency_bound, residency_capacity, _f_valid, resolve_F, f_from_log, residency_probes, block_layout, nb1_complete, nb1_tf_req, lp_compare, fp8_self_check, nb1_ladder, _prefix_counts, _reuse, prefix_tests, _merge, _clip, _inter, microbatch_costs, pp2_trace, merge_routing, pp2_profile)
    import gzip
    import statistics
    from collections import Counter
    NB1 = R.setdefault("nb1", {})
    SCORECARD = OUT / "lever_scorecard.json"
    TF_RAW = OUT / "tf_raw"
    TF_RAW.mkdir(exist_ok=True)
    HOSTMEM = OUT / "hostmem"
    HOSTMEM.mkdir(exist_ok=True)
    BLOCK = 4096
    PIN_STEPS_GIB = (1.0, 0.75, 0.5)             # B3 pin ladder (addendum 5): the largest step predicted safe first, then down
    PIN_FREE_MIN_MIB = 512                       # a step must leave >= 0.5 GiB free per rank after warm-up + a 90k prefill
    KV_STEP = 512 << 20                          # the smallest step (+0.5 GiB per card)
    RAM_NEED_MIB = (69 + 4) * 1024               # Merlin's ~69 GiB resident floor + 4 GiB margin, on its own rule
    BOOT_READY_SEC = 30 * 60                     # readiness gate per boot
    SEQS_HI = 16
    CAPTURE_HI = [1, 2, 3, 4, 6, 8, 12, 16, 24, 32, 40, 48, 64]   # Merlin registry.capture_sizes_for(16, K=3): seqs x (1 + K)
    COMPILE_HI = json.dumps({"cudagraph_mode": "FULL_AND_PIECEWISE", "cudagraph_capture_sizes": CAPTURE_HI})
    PROF_DIR = TMP / "nb1_profile"
    PROFILER_CFG = json.dumps({"profiler": "torch", "torch_profiler_dir": str(PROF_DIR), "torch_profiler_with_stack": False,
                               "ignore_frontend": True})      # idle unless /start_profile (annotations only while running)
    EXT_FLAG = ["--worker-extension-cls", "nb1_worker_ext.NB1WorkerExt"]
    DIAG_ENV = {"VLLM_SERVER_DEV_MODE": "1"}     # /collective_rpc (read-only extension) + /reset_prefix_cache; 127.0.0.1 only
    NCCL_DIAG = {"NCCL_DEBUG": "INFO", "NCCL_DEBUG_SUBSYS": "INIT,NET"}   # B1 only: the real NCCL transport per group
    COMMIT_GRAPH_ENV = {"VLLM_RECOVERSSM_COMMIT_GRAPH": "graph"}         # B2 boot: commit graphs captured; flipped to eager at once
    RC2_FP8 = json.loads(r"""{"argv_tail": ["127.0.0.1", "--port", "8001", "--tensor-parallel-size", "2", "--pipeline-parallel-size", "2", "--enable-expert-parallel", "--disable-custom-all-reduce", "--speculative-config", "{\"method\":\"mtp\",\"num_speculative_tokens\":3,\"draft_sample_method\":\"probabilistic\"}", "--max-model-len", "262144", "--max-num-seqs", "8", "--max-num-batched-tokens", "1024", "--gpu-memory-utilization", "0.96", "--kv-cache-memory-bytes", "2479838700", "--kv-cache-dtype", "fp8_e4m3", "--limit-mm-per-prompt", "{\"image\":42,\"video\":0}", "--mm-processor-cache-gb", "0", "--mm-processor-kwargs", "{\"size\":{\"longest_edge\":8388608,\"shortest_edge\":65536}}", "--compilation-config", "{\"cudagraph_mode\":\"FULL_AND_PIECEWISE\",\"cudagraph_capture_sizes\":[1,2,3,4,6,8,12,16,24,32]}", "--enable-prefix-caching", "--mamba-cache-mode", "align", "--enable-prompt-tokens-details", "--no-enable-flashinfer-autotune", "--enable-auto-tool-choice", "--tool-call-parser", "qwen3_coder", "--reasoning-parser", "qwen3", "--override-generation-config", "{\"temperature\":1.0,\"top_p\":0.95,\"top_k\":20,\"min_p\":0.0,\"presence_penalty\":0.0,\"repetition_penalty\":1.0}", "--default-chat-template-kwargs", "{\"enable_thinking\": true, \"reasoning_effort\": \"medium\"}", "--shutdown-timeout", "60", "--block-size", "4096", "--use-replayssm", "--prefix-match-unit", "64", "--served-model-name", "q27", "--max-model-len", "131072", "--port", "8001", "--default-chat-template-kwargs", "{\"enable_thinking\": true, \"reasoning_effort\": \"xhigh\"}"], "env": {"KV_BYTES": "2479838700", "NCCL_P2P_DISABLE": "1", "NCCL_VERSION": "2.25.1-1", "P2P": "off", "SCALES": "/tmp/fn_merlin/qsa_kv_scales_262k.json", "VLLM_CACHE_ROOT": "/tmp/merlin-cache", "VLLM_E2_GUARD_MODE": "warn", "VLLM_E2_PLE_EARLY_REQUEST": "1", "VLLM_E2_PLE_FAST_IDS": "1", "VLLM_E2_QSA_LOGITS_GRANULE_MB": "256", "VLLM_HOST_EMBED_TABLE": "1", "VLLM_MEMORY_PROFILER_ESTIMATE_CUDAGRAPHS": "0", "VLLM_PLE_OFFLOAD_HOME_DEVICE": "0", "VLLM_PLE_OFFLOAD_READY_TIMEOUT": "3600", "VLLM_PORT": "30100", "VLLM_PP_LAYER_PARTITION": "25,23", "VLLM_QSA_KV_SCALES": "/tmp/fn_merlin/qsa_kv_scales_262k.json", "VLLM_SKIP_P2P_CHECK": "1", "VLLM_SPARSE_INDEXER_MAX_LOGITS_MB": "256", "VLLM_USE_BREAKABLE_CUDAGRAPH": "0", "VLLM_USE_RUST_FRONTEND": "0", "VLLM_USE_V2_MODEL_RUNNER": "1"}, "kv_bytes": 2479838700, "kv_tokens": 513940, "max_concurrency": 3.92, "pool_blocks": 149, "F_rule": 6, "F_engine": 6, "seqs": 8, "gpu_mem_after_ready": [[0, 20903, 23034], [1, 20903, 23034], [2, 20863, 23034], [3, 21389, 23034]], "gpu_mem_end": [[0, 21427, 23034], [1, 21427, 23034], [2, 21387, 23034], [3, 21401, 23034]], "windows": {"40k@1": {"status": "STEADY", "tok_s": 70.0, "mal": 3.086, "step_ms": 44.1, "running": [1.0, 1.0]}, "40k@2": {"status": "STEADY", "tok_s": 107.4, "mal": 3.251, "step_ms": 30.3, "running": [2.0, 2.0]}, "40k@4": {"status": "STEADY", "tok_s": 161.0, "mal": 3.017, "step_ms": 37.5, "running": [4.0, 4.0]}, "40k@5": {"status": "STEADY", "tok_s": 190.5, "mal": 3.073, "step_ms": 40.3, "running": [5.0, 5.0]}, "8k@8": {"status": "STEADY", "tok_s": 261.8, "mal": 3.154, "step_ms": 48.2, "running": [8.0, 8.0]}, "90k@3": {"status": "INCONCLUSIVE_PREFILL_IN_WINDOW", "tok_s": 48.7, "mal": 2.93, "step_ms": 60.1, "running": [1.0, 3.0]}, "90k@4": {"status": "STEADY", "tok_s": 159.8, "mal": 3.022, "step_ms": 37.8, "running": [4.0, 4.0]}, "116k@3": {"status": "STEADY", "tok_s": 140.5, "mal": 3.223, "step_ms": 34.4, "running": [3.0, 3.0]}, "116k@4": {"status": "STEADY", "tok_s": 160.3, "mal": 3.016, "step_ms": 37.6, "running": [4.0, 4.0]}}, "tf_40k_vs_bf16": {"status": "MEASURED", "n": 256, "mean_abs_dlogprob": 1.8764, "p99_abs_dlogprob": 5.464, "max_abs_dlogprob": 7.15, "rank1_agreement": 0.3672, "forced_token_rank1_both_or_neither": 0.457}, "ready_sec": 999.1, "bf16": {"kv_tokens": 269042, "max_concurrency": 2.05, "pool_blocks": 78, "seqs": 3, "gpu_mem_after_ready": [[0, 20905, 23034], [1, 20905, 23034], [2, 20693, 23034], [3, 20693, 23034]], "gpu_mem_end": [[0, 21425, 23034], [1, 21425, 23034], [2, 21215, 23034], [3, 21215, 23034]], "ready_sec": 411.1}, "rank_load_gib": {"2": 16.87, "1": 17.33, "0": 17.33, "3": 16.87}, "rank_graph_gib": {"0": 0.33, "1": 0.33, "2": 0.43, "3": 0.43}}""")      # RC2's real boots: argv tail, env keys, pool, memory, windows (rc2_results.json)
    RC2_ORACLE = json.loads(r"""{"bf16": [{"text": "We need solve ARC task. Need infer transformation from examples. User gives Task 0934a4d8 with Example 1 input/output, Example 2 input/output, Example 3 input only? Need solve test inputs? They provided Example 3 input: 194499276 maybe incomplete? Need output? Need find transformation rule and solve test inputs. We need analyze.\n\nWe have ARC tasks represented as strings of digits? Example 1 input is 31 rows? Let's count. Example 1 input lines:\n1 3533665414", "tokens": [1596, 1144, 11290, 67964, 3274, 13, 14235, 22846, 17454, 494, 9989, 13, 2570, 6486, 5261, 220, 15, 24, 18, 19, 64, 19, 67, 23, 440, 12996, 220, 16, 1879, 45447, 11, 12996, 220, 17, 1879, 45447, 11, 12996, 220, 18, 1879, 1132, 30, 14235, 11290, 1228, 10804, 30, 2302, 3766, 12996, 220, 18, 1879, 25, 220, 16, 24, 19, 19, 24, 24, 17, 22, 21, 6970, 31084, 30, 14235, 2468, 30, 14235, 1423, 17454, 5728, 321, 11290, 1228, 10804, 13, 1165, 1144, 22903, 13, 271, 1596, 599, 67964, 8806, 14807, 430, 8796, 314, 17955, 30, 12996, 220, 16, 1879, 369, 220, 18, 16, 6761, 30, 6558, 579, 1698, 13, 12996, 220, 16, 1879, 4965, 25, 198, 16, 220, 18, 20, 18, 18, 21, 21, 20, 19, 16, 19], "margins": [11.375, 10.75, 0.25, 3.5, 0.125, 1.75, 2.375, 0.625, 4.375, 0.125, 4.125, 1.375, 0.125, 1.0, 1.25, 4.875, 8.6875, 10.375, 10.375, 9.6875, 8.25, 10.1875, 14.0, 10.4375, 0.125, 0.875, 1.25, 8.375, 3.875, 1.0, 3.75, 7.375, 3.75, 12.0, 2.625, 8.375, 6.75, 2.5, 8.75, 10.5, 6.625, 0.125, 0.375, 0.5, 0.75, 8.25, 4.125, 1.0, 1.0, 0.125, 0.25, 4.625, 6.375, 9.25, 2.875, 0.375, 4.125, 4.25, 10.9375, 11.5625, 10.625, 10.5625, 9.5625, 11.5, 10.6875, 0.5, 2.25, 4.875, 2.125, 1.25, 0.125, 0.5, 0.625, 0.625, 4.25, 1.125, 2.875, 3.125, 3.125, 4.125, 0.75, 1.375, 1.75, 0.75, 1.0, 4.25, 1.5, 0.5, 1.125, 0.625, 4.625, 1.625, 0.25, 4.5, 1.0, 0.0, 1.25, 8.5, 5.0, 1.125, 2.75, 3.375, 0.625, 0.125, 1.125, 1.875, 7.25, 1.875, 2.125, 0.25, 0.875, 6.25, 1.875, 1.625, 2.625, 2.875, 2.125, 2.375, 8.125, 10.9375, 10.0625, 9.0625, 9.875, 9.375, 11.25, 11.375, 11.875, 12.9375], "error": null, "prompt_sha": "8df9ed2c640ef5bd", "prompt_len": 2048, "finish_reason": "length"}, {"text": "We need solve ARC tasks. Need infer transformation rules from examples and apply to test inputs. We have two tasks: 1818057f and 195c6913. Need output transformed test grids. Need analyze carefully.\n\nWe need produce final answer likely grids. Need infer rules.\n\nTask 1818057f:\nExamples: inputs/outputs with colors 2,4,8. Output changes some 4s to 8? Let's inspect.\n\nExample1 input 10x12? rows:\n1 22224", "tokens": [1596, 1144, 11290, 67964, 8806, 13, 14235, 22846, 17454, 5426, 494, 9989, 321, 3668, 310, 1228, 10804, 13, 1165, 599, 1330, 8806, 25, 220, 16, 23, 16, 23, 15, 20, 22, 69, 321, 220, 16, 24, 20, 66, 21, 24, 16, 18, 13, 14235, 2468, 22773, 1228, 54455, 13, 14235, 22903, 15060, 13, 271, 1596, 1144, 7936, 1534, 4087, 4222, 54455, 13, 14235, 22846, 5426, 13, 271, 6065, 220, 16, 23, 16, 23, 15, 20, 22, 69, 25, 198, 39044, 25, 10804, 14, 39652, 440, 7736, 220, 17, 11, 19, 11, 23, 13, 8984, 4203, 1010, 220, 19, 82, 310, 220, 23, 30, 6558, 579, 23331, 13, 271, 12929, 16, 1879, 220, 16, 15, 87, 16, 17, 30, 6761, 25, 198, 16, 220, 17, 17, 17, 17, 19], "margins": [11.875, 11.375, 0.75, 3.375, 2.625, 3.0, 3.25, 0.5, 3.125, 0.25, 0.625, 4.75, 1.125, 3.25, 2.0, 5.5, 0.875, 3.75, 0.375, 0.5, 1.375, 6.5, 1.125, 2.25, 12.625, 12.0625, 11.3125, 12.9375, 12.4375, 8.875, 10.8125, 10.75, 1.75, 7.375, 13.5625, 13.875, 11.6875, 11.25, 10.75, 12.375, 12.375, 10.75, 2.25, 2.25, 1.625, 0.875, 1.0, 0.375, 0.875, 1.375, 0.125, 1.875, 6.5, 1.5, 1.0, 1.375, 1.0, 4.75, 4.625, 1.75, 1.0, 1.625, 0.875, 0.625, 0.25, 3.5, 1.0, 1.25, 4.625, 11.625, 5.75, 11.125, 12.3125, 10.8125, 10.9375, 11.0, 11.8125, 0.125, 0.0, 2.625, 0.375, 0.25, 0.875, 7.875, 0.75, 0.875, 1.875, 8.125, 0.75, 7.375, 2.875, 3.875, 2.125, 0.25, 2.0, 3.25, 2.625, 0.625, 2.625, 2.125, 10.75, 10.625, 0.75, 1.75, 7.5, 2.75, 6.375, 0.25, 1.75, 1.375, 0.75, 3.25, 8.375, 4.625, 3.75, 4.375, 2.625, 1.5, 0.25, 0.5, 5.375, 1.375, 0.5, 9.75, 4.625, 12.625, 11.4375, 8.375], "error": null, "prompt_sha": "8750743e9dcadca9", "prompt_len": 2048, "finish_reason": "length"}, {"text": "We need solve ARC tasks. Need find transformation rule for each task and solve test inputs. We have multiple tasks: 247ef758, 269e22fb, 271d71e2, 28a6681f, 291dc1e1. Need output transformed grids for test inputs. Need infer rules from examples. Need be careful. We need produce final answer likely grids. Need analyze each task.\n\nWe need parse tasks. There are two test inputs for 247ef758? It says Test input: ...", "tokens": [1596, 1144, 11290, 67964, 8806, 13, 14235, 1423, 17454, 5728, 364, 1754, 3274, 321, 11290, 1228, 10804, 13, 1165, 599, 5081, 8806, 25, 220, 17, 19, 22, 797, 22, 20, 23, 11, 220, 17, 21, 24, 68, 17, 17, 10481, 11, 220, 17, 22, 16, 67, 22, 16, 68, 17, 11, 220, 17, 23, 64, 21, 21, 23, 16, 69, 11, 220, 17, 24, 16, 7385, 16, 68, 16, 13, 14235, 2468, 22773, 54455, 364, 1228, 10804, 13, 14235, 22846, 5426, 494, 9989, 13, 14235, 381, 16097, 13, 1165, 1144, 7936, 1534, 4087, 4222, 54455, 13, 14235, 22903, 1754, 3274, 13, 271, 1596, 1144, 4563, 8806, 13, 2532, 513, 1330, 1228, 10804, 364, 220, 17, 19, 22, 797, 22, 20, 23, 30, 1049, 2640, 3284, 1879, 25, 2423], "margins": [11.75, 9.875, 1.125, 1.25, 3.875, 2.0, 2.875, 0.375, 5.25, 0.875, 1.5, 5.625, 0.875, 3.0, 2.875, 3.125, 7.75, 6.75, 0.5, 0.5, 1.5, 5.625, 1.375, 3.0, 11.75, 13.375, 12.625, 11.3125, 12.0, 13.5, 12.625, 0.625, 8.4375, 11.625, 11.0, 12.5625, 10.5625, 11.0, 10.375, 8.375, 7.375, 9.75, 11.5625, 9.125, 10.0, 9.75, 9.4375, 10.3125, 10.4375, 9.0, 8.1875, 9.4375, 12.625, 9.75, 11.0, 11.3125, 10.9375, 9.625, 9.5625, 10.0, 8.1875, 7.625, 12.375, 11.125, 11.375, 10.625, 10.25, 10.375, 10.0, 2.5, 3.0, 2.125, 0.125, 0.125, 1.875, 0.125, 4.125, 3.125, 2.0, 0.75, 3.0, 0.75, 8.75, 4.125, 0.125, 1.25, 3.875, 2.75, 0.125, 0.25, 0.625, 3.875, 1.625, 1.875, 0.75, 1.0, 0.375, 2.375, 2.125, 0.5, 0.5, 2.5, 1.875, 0.125, 0.75, 0.375, 3.625, 0.125, 1.375, 0.0, 4.125, 7.375, 2.5, 0.375, 12.75, 6.75, 12.375, 4.625, 8.75, 12.1875, 10.25, 2.0, 0.625, 0.25, 1.125, 7.625, 1.75, 2.125], "error": null, "prompt_sha": "fc63e297d382cd8f", "prompt_len": 8192, "finish_reason": "length"}, {"text": "We need solve ARC tasks. Need find transformation rule for each task and solve test inputs. We need output likely transformed grids. Need analyze many tasks. Need be careful. We have multiple tasks with examples and test inputs. Need infer rules.\n\nWe need produce final answer with transformed test inputs for each task. There are tasks: 2c181942, 2d0172a1 (two test inputs?), 31f7f899, 332f06d7, 35ab12c3, 36a08778", "tokens": [1596, 1144, 11290, 67964, 8806, 13, 14235, 1423, 17454, 5728, 364, 1754, 3274, 321, 11290, 1228, 10804, 13, 1165, 1144, 2468, 4222, 22773, 54455, 13, 14235, 22903, 1599, 8806, 13, 14235, 381, 16097, 13, 1165, 599, 5081, 8806, 440, 9989, 321, 1228, 10804, 13, 14235, 22846, 5426, 13, 271, 1596, 1144, 7936, 1534, 4087, 440, 22773, 1228, 10804, 364, 1754, 3274, 13, 2532, 513, 8806, 25, 220, 17, 66, 16, 23, 16, 24, 19, 17, 11, 220, 17, 67, 15, 16, 22, 17, 64, 16, 318, 19186, 1228, 10804, 66926, 220, 18, 16, 69, 22, 69, 23, 24, 24, 11, 220, 18, 18, 17, 69, 15, 21, 67, 22, 11, 220, 18, 20, 365, 16, 17, 66, 18, 11, 220, 18, 21, 64, 15, 23, 22, 22, 23], "margins": [10.125, 11.5, 1.125, 0.25, 3.5, 2.125, 2.625, 0.5, 5.25, 1.0, 1.75, 5.75, 0.375, 2.375, 3.625, 4.25, 6.625, 7.375, 0.25, 0.125, 1.25, 0.5, 0.25, 2.0, 0.5, 1.625, 1.0, 1.0, 4.375, 2.875, 0.75, 2.125, 4.125, 4.0, 0.375, 0.5, 1.625, 3.875, 0.375, 2.125, 2.125, 2.125, 2.875, 1.625, 2.875, 1.125, 0.75, 1.375, 0.125, 1.625, 2.25, 1.0, 2.875, 2.5, 3.0, 0.125, 1.125, 0.75, 1.25, 2.375, 1.75, 1.625, 0.625, 3.0, 0.125, 4.5, 0.5, 11.625, 10.625, 12.0625, 13.0625, 9.5625, 10.9375, 10.375, 10.875, 1.0, 6.5, 9.8125, 10.25, 11.9375, 13.5, 12.3125, 11.625, 11.25, 11.25, 0.375, 2.5, 4.125, 7.25, 0.625, 5.375, 9.75, 9.625, 12.4375, 11.25, 10.4375, 9.0, 11.4375, 10.8125, 3.25, 8.375, 11.875, 7.375, 11.5, 11.0, 10.5625, 8.8125, 10.875, 10.375, 5.625, 10.125, 13.125, 8.625, 7.375, 11.1875, 10.5, 10.25, 10.9375, 5.25, 9.75, 10.1875, 7.25, 11.4375, 12.0, 8.9375, 11.0625, 9.5, 10.3125], "error": null, "prompt_sha": "49b3958bb234d4fd", "prompt_len": 40000, "finish_reason": "length"}], "fp8": [{"text": "We need solve ARC task. Need infer transformation from examples. User gives Task 0934a4d8. Example 1 input 30x30? output 9x4? Example 2 input 30x30? output 4x5? Example 3 input: \"194499276\" only one row? Maybe truncated? Need find transformation rule and solve test inputs. But only one test input? It says Example 3 input: 194499276. Maybe that's the test input? Need output. Need infer from", "tokens": [1596, 1144, 11290, 67964, 3274, 13, 14235, 22846, 17454, 494, 9989, 13, 2570, 6486, 5261, 220, 15, 24, 18, 19, 64, 19, 67, 23, 13, 12996, 220, 16, 1879, 220, 18, 15, 87, 18, 15, 30, 2468, 220, 24, 87, 19, 30, 12996, 220, 17, 1879, 220, 18, 15, 87, 18, 15, 30, 2468, 220, 19, 87, 20, 30, 12996, 220, 18, 1879, 25, 328, 16, 24, 19, 19, 24, 24, 17, 22, 21, 1, 1132, 799, 2713, 30, 10380, 57739, 30, 14235, 1423, 17454, 5728, 321, 11290, 1228, 10804, 13, 1921, 1132, 799, 1228, 1879, 30, 1049, 2640, 12996, 220, 18, 1879, 25, 220, 16, 24, 19, 19, 24, 24, 17, 22, 21, 13, 10380, 421, 579, 279, 1228, 1879, 30, 14235, 2468, 13, 14235, 22846, 494], "margins": [11.5, 11.25, 0.25, 3.625, 0.375, 2.25, 2.25, 0.875, 4.125, 0.25, 4.25, 1.25, 0.125, 1.0, 1.75, 4.625, 9.0, 9.9375, 10.375, 9.5, 8.875, 10.6875, 14.0, 10.625, 0.125, 0.75, 0.875, 7.5, 4.5, 1.25, 3.5, 0.75, 0.0, 1.75, 4.0, 2.625, 1.25, 9.375, 5.5, 4.25, 2.0, 0.25, 2.625, 0.875, 8.875, 3.75, 4.375, 5.75, 5.5, 4.25, 3.5, 5.5, 0.0, 8.0, 7.25, 7.375, 4.625, 5.875, 1.5, 3.75, 4.875, 9.125, 6.75, 0.25, 0.625, 8.25, 8.25, 12.3125, 11.5, 10.3125, 11.0, 10.1875, 11.625, 9.875, 4.375, 2.25, 0.375, 1.0, 4.875, 0.0, 0.25, 5.75, 2.125, 0.0, 0.25, 2.375, 2.875, 6.75, 9.125, 5.125, 1.875, 0.75, 2.375, 0.0, 0.875, 1.875, 2.125, 0.75, 2.25, 1.625, 9.1875, 7.125, 9.125, 5.625, 1.125, 7.9375, 7.0625, 10.375, 11.375, 10.8125, 10.5625, 11.1875, 11.5, 11.625, 1.0, 1.625, 1.375, 2.625, 0.5, 2.375, 1.75, 2.625, 2.0, 2.625, 0.125, 1.5, 0.25, 1.5], "error": null, "prompt_sha": "8df9ed2c640ef5bd", "prompt_len": 2048, "finish_reason": "length"}, {"text": "We need solve ARC tasks. Need infer transformation rules from examples and apply to test inputs. We have two tasks: 1818057f and 195c6913. Need output transformed test grids. Need analyze carefully.\n\nWe need produce final answer likely grids. Need infer rules.\n\nTask 1818057f examples:\nInput/output grids with colors 2,4,8. Output changes some 4s to 8? Let's inspect.\n\nExample1 10x12? Input rows:\n1 222244", "tokens": [1596, 1144, 11290, 67964, 8806, 13, 14235, 22846, 17454, 5426, 494, 9989, 321, 3668, 310, 1228, 10804, 13, 1165, 599, 1330, 8806, 25, 220, 16, 23, 16, 23, 15, 20, 22, 69, 321, 220, 16, 24, 20, 66, 21, 24, 16, 18, 13, 14235, 2468, 22773, 1228, 54455, 13, 14235, 22903, 15060, 13, 271, 1596, 1144, 7936, 1534, 4087, 4222, 54455, 13, 14235, 22846, 5426, 13, 271, 6065, 220, 16, 23, 16, 23, 15, 20, 22, 69, 9989, 25, 198, 2425, 45447, 54455, 440, 7736, 220, 17, 11, 19, 11, 23, 13, 8984, 4203, 1010, 220, 19, 82, 310, 220, 23, 30, 6558, 579, 23331, 13, 271, 12929, 16, 220, 16, 15, 87, 16, 17, 30, 5396, 6761, 25, 198, 16, 220, 17, 17, 17, 17, 19, 19], "margins": [11.875, 11.75, 0.5, 3.125, 2.625, 3.0, 3.125, 0.5, 3.0, 0.5, 0.625, 4.875, 1.0, 3.25, 2.0, 5.625, 0.625, 3.875, 0.375, 0.75, 1.375, 6.75, 1.375, 2.125, 12.8125, 11.9375, 11.6875, 13.1875, 12.0625, 8.4375, 10.3125, 10.5, 1.625, 7.25, 13.5625, 12.625, 10.5625, 9.375, 12.0, 12.6875, 11.3125, 11.0625, 2.0, 2.375, 1.625, 0.875, 1.0, 0.125, 0.5, 1.25, 0.125, 1.875, 6.625, 1.625, 1.5, 1.5, 1.0, 4.75, 4.625, 2.0, 0.875, 1.5, 1.0, 0.625, 0.5, 3.375, 1.0, 1.125, 4.5, 12.375, 5.625, 11.125, 12.625, 10.0625, 9.875, 10.125, 11.625, 0.125, 1.375, 0.5, 1.0, 0.75, 0.375, 1.25, 1.0, 1.75, 7.75, 0.75, 7.75, 2.375, 3.625, 1.625, 0.25, 2.0, 3.5, 2.75, 1.125, 2.25, 2.375, 10.8125, 10.75, 0.75, 1.875, 7.5, 2.75, 5.25, 0.25, 2.125, 1.25, 0.0, 7.125, 3.625, 5.5, 4.5, 2.0, 1.5, 0.75, 0.875, 0.0, 6.375, 1.0, 0.75, 10.0, 4.75, 12.625, 11.5625, 8.375, 11.4375], "error": null, "prompt_sha": "8750743e9dcadca9", "prompt_len": 2048, "finish_reason": "length"}, {"text": "We need solve ARC tasks. Need find transformation rule for each task and solve test inputs. We have multiple tasks: 247ef758, 269e22fb, 271d71e2, 28a6681f, 291dc1e1. Need output transformed test inputs. Need infer rules from examples. Need be careful. We can analyze each.\n\nWe need produce final answer likely grids for each test input. Need determine exact transformations.\n\nLet's parse tasks.\n\nTask 247ef758: examples show", "tokens": [1596, 1144, 11290, 67964, 8806, 13, 14235, 1423, 17454, 5728, 364, 1754, 3274, 321, 11290, 1228, 10804, 13, 1165, 599, 5081, 8806, 25, 220, 17, 19, 22, 797, 22, 20, 23, 11, 220, 17, 21, 24, 68, 17, 17, 10481, 11, 220, 17, 22, 16, 67, 22, 16, 68, 17, 11, 220, 17, 23, 64, 21, 21, 23, 16, 69, 11, 220, 17, 24, 16, 7385, 16, 68, 16, 13, 14235, 2468, 22773, 1228, 10804, 13, 14235, 22846, 5426, 494, 9989, 13, 14235, 381, 16097, 13, 1165, 628, 22903, 1754, 13, 271, 1596, 1144, 7936, 1534, 4087, 4222, 54455, 364, 1754, 1228, 1879, 13, 14235, 7995, 4581, 51192, 13, 271, 9764, 579, 4563, 8806, 13, 271, 6065, 220, 17, 19, 22, 797, 22, 20, 23, 25, 9989, 1420], "margins": [11.875, 9.75, 1.25, 1.5, 3.625, 2.125, 3.0, 0.125, 5.25, 0.875, 1.625, 5.5, 0.875, 3.125, 2.875, 2.875, 8.5, 7.125, 0.375, 0.375, 1.875, 5.375, 1.625, 3.0, 12.125, 13.3125, 12.9375, 11.8125, 11.8125, 13.5, 12.5, 0.375, 8.875, 11.6875, 10.9375, 12.25, 11.0625, 10.6875, 10.375, 8.3125, 7.375, 10.4375, 11.1875, 9.0, 9.8125, 10.125, 10.25, 10.8125, 10.125, 9.3125, 8.0625, 9.5, 12.4375, 10.4375, 11.0, 11.1875, 11.1875, 9.6875, 10.375, 9.0, 7.75, 7.625, 12.875, 10.8125, 11.375, 9.625, 10.625, 11.0625, 9.875, 2.375, 2.875, 2.125, 0.125, 0.0, 0.875, 0.75, 2.0, 0.625, 3.125, 0.875, 8.375, 3.875, 0.125, 1.25, 4.125, 2.875, 0.375, 0.125, 0.5, 0.125, 0.875, 1.375, 2.5, 2.25, 0.75, 4.0, 1.75, 2.0, 0.875, 0.625, 1.125, 3.375, 4.25, 3.75, 0.875, 0.125, 0.5, 0.875, 6.25, 1.5, 3.125, 10.25, 2.625, 2.25, 3.25, 3.625, 3.625, 6.75, 10.375, 7.625, 12.5, 11.75, 11.25, 11.875, 13.4375, 1.5, 0.0, 0.25], "error": null, "prompt_sha": "fc63e297d382cd8f", "prompt_len": 8192, "finish_reason": "length"}, {"text": "We need solve ARC tasks. Need find transformation rule for each task and solve test inputs. We have multiple tasks with examples and test inputs. Need output transformed grids likely. Need infer rules. This is complex. Need analyze each task carefully. Need produce final answer with outputs for each test input. Need be accurate.\n\nWe have tasks:\n2c181942 (one test input)\n2d0172a1 (two test inputs? It lists Test input twice)\n31f7f899 (one test)\n332f06d7 (one test)", "tokens": [1596, 1144, 11290, 67964, 8806, 13, 14235, 1423, 17454, 5728, 364, 1754, 3274, 321, 11290, 1228, 10804, 13, 1165, 599, 5081, 8806, 440, 9989, 321, 1228, 10804, 13, 14235, 2468, 22773, 54455, 4222, 13, 14235, 22846, 5426, 13, 1061, 369, 6150, 13, 14235, 22903, 1754, 3274, 15060, 13, 14235, 7936, 1534, 4087, 440, 15796, 364, 1754, 1228, 1879, 13, 14235, 381, 12995, 13, 271, 1596, 599, 8806, 25, 198, 17, 66, 16, 23, 16, 24, 19, 17, 318, 588, 1228, 1879, 8, 198, 17, 67, 15, 16, 22, 17, 64, 16, 318, 19186, 1228, 10804, 30, 1049, 11140, 3284, 1879, 10598, 8, 198, 18, 16, 69, 22, 69, 23, 24, 24, 318, 588, 1228, 8, 198, 18, 18, 17, 69, 15, 21, 67, 22, 318, 588, 1228, 8], "margins": [10.0, 11.25, 1.0, 0.625, 3.375, 2.5, 2.875, 0.375, 5.125, 0.875, 1.75, 5.875, 0.375, 2.875, 3.625, 4.125, 6.375, 7.5, 0.25, 0.0, 0.25, 6.25, 0.25, 3.75, 2.0, 2.625, 3.125, 2.875, 4.125, 2.75, 0.5, 1.375, 0.625, 0.5, 1.875, 0.125, 1.375, 0.25, 0.0, 9.625, 0.125, 1.375, 1.0, 0.625, 3.125, 4.125, 0.25, 1.875, 0.125, 0.875, 3.875, 1.5, 2.75, 0.0, 2.5, 0.875, 3.0, 4.75, 1.25, 1.0, 0.125, 1.75, 10.625, 1.875, 2.625, 0.125, 3.0, 3.5, 1.125, 0.25, 10.5, 13.375, 13.3125, 12.0625, 10.375, 9.625, 11.0, 0.125, 1.625, 7.5, 1.0, 3.5, 7.75, 7.0, 10.375, 13.0625, 13.1875, 12.0, 11.1875, 11.875, 11.1875, 7.125, 5.75, 5.25, 8.5, 0.625, 0.75, 0.75, 1.375, 7.375, 0.75, 0.0, 4.375, 8.9375, 9.875, 12.8125, 11.8125, 10.6875, 10.1875, 10.5625, 12.125, 4.625, 5.25, 1.125, 0.0, 10.875, 11.6875, 6.875, 13.0, 11.125, 12.0, 10.0625, 11.375, 10.5, 9.25, 9.0, 2.625, 5.25], "error": null, "prompt_sha": "49b3958bb234d4fd", "prompt_len": 40000, "finish_reason": "length"}]}""")   # RC2's recorded greedy oracle rows (traces/requests.jsonl), BF16 + FP8
    GEN_RATE = 45.0                              # tok/s per stream used only to project window growth (RC2: 33 at 8, 70 at 1)
    PP = 2                                       # pipeline stages of the profile: one engine step = one micro-batch (C/2 requests)
    TF_BANDS = ("2k", "8k")                      # FP8 self-consistency only (< 2 min); the BF16 / FP8 isolation is NB0's
    TF_P = {b: PROMPTS[b][5] for b in TF_BANDS}  # RC2's TF prompt (variant 5)
    RETENTION_KNOBS = {   # Merlin source (ad42e37), recorded, not changed
        "MAX_GRACE_PINS": "16 finished turns keep their cached prefix referenced (kv_cache_manager.py:735, class constant)",
        "MAX_PINNED_WAITERS": "16 waiting requests' hits pinned until admission (kv_cache_manager.py:940, class constant)",
        "enable_grace_pins": "enable_caching and partial hash hits (prefix-match-unit 64), kv_cache_manager.py:234",
        "VLLM_E2_SCHED_MISS_DEFER_S": "120 s default (merlin/envs.py:40): a cold miss may wait for protected waiters",
        "VLLM_E2_SCHED_COHERENT_YIELD": "on by default (merlin/envs.py:41): need-sized, session-coherent yields",
        "reset": "/reset_prefix_cache (VLLM_SERVER_DEV_MODE=1) drops grace and waiter pins when they alone block the reset "
                 "(kv_cache_manager.py:1107-1113); it fails while requests run"}
    for _b, _n in (("8k", 34), ("40k", 16)):     # distinct prompts (RC2 has 8 per band)
        PROMPTS[_b] += [prompt(BANDS[_b], v) for v in range(len(PROMPTS[_b]), _n)]
    BANDS["60k"] = 60000                         # residency probe band (addendum 7); RC2's PROMPTS bands are unchanged
    PROMPTS["60k"] = [prompt(BANDS["60k"], v) for v in range(8)]
    MAX_NEW["60k"] = MAX_LEN - BANDS["60k"] - 512
    RESIDENCY_BANDS = ("8k", "40k", "60k", "90k", "116k")
    V_CENSUS = {"8k": list(range(24, 32)), "40k": list(range(9, 13))}   # never used by a steady window in the same boot
    V_PREFIX = {"8k": 32, "40k": 8}
    V_ABORT = 33
    SUFFIX_TXT = ("\n</think>\n\nI have a first rule.<|im_end|>\n<|im_start|>user\nCheck the rule on every training pair, "
                  "then give the final test grid." + _tail_txt)
    SUFFIX_IDS = TOK.encode(SUFFIX_TXT, add_special_tokens=False).ids
    R["prompts"] = {b: {"n": len(p), "len": len(p[0])} for b, p in PROMPTS.items()}


    def psha(ids):
        return hashlib.sha256(json.dumps(list(ids)).encode()).hexdigest()


    R["nb1_prompt_sha256"] = {b: psha(TF_P[b]) for b in TF_BANDS}
    _osha = [psha(p)[:16] for p in ORACLE_P + LONG_P]          # RC2's own prompt_sha formula (16 hex)
    NB1["rc2_oracle_prompts_match"] = {k: [r["prompt_sha"] for r in v] == _osha for k, v in RC2_ORACLE.items()}
    for _k, _v in RC2_ORACLE.items():                          # RC2's recorded rows become references only for identical prompts
        if NB1["rc2_oracle_prompts_match"][_k] and not FAKE:    # (the fake server's text differs: it builds its own reference)
            ROWS["rc2_" + _k] = [{"text": r["text"], "tokens": r["tokens"], "margins": r["margins"], "error": r["error"]} for r in _v]
    NB1["retention_knobs"] = RETENTION_KNOBS
    NB1["sampling"] = ("every request passes its own sampling (greedy: temperature 0; load: T 0.6, top_p 0.95, top_k 20; "
                       "Merlin's --override-generation-config is T 1.0)")
    R["capacity_plan"] = {
        "rule": "blocks per running request = ceil(L / 4096) + F, F = 6 (3 mamba groups x 2; RC2 analysis: 149 / 3.92 = 38 = 32 + 6, "
                "live transitions 6.0 / 6.1); a finished session keeps floor(L / 4096) + 3 blocks (up to 16) until re-admitted or yielded",
        "rc2_pool_blocks": {"fp8": 149, "bf16": 78},
        "worst_case_F6": {"8k@8": 8 * (math.ceil((8192 + 8000) / 4096) + 6), "40k@5": 5 * (math.ceil((40000 + 8000) / 4096) + 6),
                          "8k x 8 hold (cold sequence)": 8 * (math.ceil(9000 / 4096) + 6), "40k x 4 hold": 4 * (math.ceil(41000 / 4096) + 6),
                          "90k x 5 admission (max_new 3000)": 5 * (math.ceil(93000 / 4096) + 6), "pool": 149},
        "retention": "every capacity test starts from /reset_prefix_cache (retained sessions released); windows record the idle "
                     "(retained) blocks before them, so running = used - retained",
        "highest_levels": "computed at run time from the measured pool and F, never above max_num_seqs read from the server log",
        "tf": "B1 only: 2k + 8k FP8 self-consistency (teacher-forced A/A + greedy cached-repeat), < 2 min",
        "c3_note": "at BLOCK_SIZE 4096 the attention page is larger than the mamba page (RC2 log: 'Padding mamba page size by "
                   "21.01%'), so bf16 SSM state cannot change the pool's block count; B2 records the smaller minimum block it allows"}

    # ---- trace classifier fix (A7): QSA / Marlin MoE / top-k before the generic patterns; GDN '(anonymous namespace)' is
    # already handled by the lab's rev 3h _cat
    L.CATS = [("nccl_sendrecv", ("sendrecv", "send_recv", "nccldevkernel_send", "nccldevkernel_recv")), L.CATS[0],
              ("recoverssm_commit", ("recoverssm", "commit_", "boundary_fold", "final_fold", "conv_compaction")),
              ("qsa", ("qsa",)), ("moe_marlin", ("marlin_moe", "fused_marlin_moe", "moe_wna16")),
              ("topk", ("persistent_topk", "cooperative_topk"))] + list(L.CATS[1:])
    L.COMPUTE_CATS = tuple(L.COMPUTE_CATS) + ("nccl_sendrecv", "recoverssm_commit", "qsa", "moe_marlin", "topk")

    # ---- RC2 long-row gate, stricter (audit 2): a natural row needs finish == stop and a closed think; forced rows
    # (ignore_eos) are stability tests only. NB1 runs no long rows; the reused gate is fixed for any later reuse.
    _long_quality_rc2, _long_gate_rc2 = long_quality, long_gate


    def long_quality(name, r):
        q = _long_quality_rc2(name, r)
        if q == "PASS_LONG" and name == "natural":
            if r.get("finish") != "stop":
                return "INCOMPLETE_NATURAL_FINISH"
            if r.get("think_closed") is not True:
                return "INCOMPLETE_THINKING"
        return q


    def long_gate(o):
        g = _long_gate_rc2(o)
        lo = o.get("long") if isinstance(o.get("long"), dict) else None
        if lo and isinstance(lo.get("forced60k"), dict):
            lo["forced60k"]["counts_as"] = "stability test only (ignore_eos)"
        if g is None and lo and any(v in ("INCOMPLETE_NATURAL_FINISH", "INCOMPLETE_THINKING") for v in (lo.get("long_quality") or {}).values()):
            return "INCONCLUSIVE_LONG_INCOMPLETE"
        return g


    # ---- the #60490 backport + the worker extension (written before B1)
    P60490 = "# vLLM PR #60490 (issue #60489) rebased onto Merlin v3.0.0 (commit ad42e37feb7611c4ffd24017bf20a7e2dc94c6e5,\n# tree 07c16a79d077f1e06c19d0eea84efd64f0b63540 = the tree the Kaggle payload installs, install_merlin.log).\n# Same code as upstream; only the import context differs (Merlin's import block). One marker comment added.\n# pre-patch sha256  a23d5f90507ad5185f8b8e8d6ba13ae0cb53b2506264fdfbbf6a60b1171dc653\n# post-patch sha256 88fe0a8f4dd2ef90fc6aefb5771b5b48e40c0b1d575039283c52aeca19b8bd6b\n--- a/vllm/models/qwen4_exp/nvidia/qsa.py\n+++ b/vllm/models/qwen4_exp/nvidia/qsa.py\n@@ -18,8 +18,9 @@\n from torch import nn\n from transformers import Qwen4ExpTextConfig\n \n+import vllm.envs as envs\n from vllm.compilation.breakable_cudagraph import eager_break_during_capture\n-from vllm.config import VllmConfig\n+from vllm.config import VllmConfig, get_current_vllm_config_or_none\n from vllm.config.cache import CacheConfig, CacheDType\n from vllm.distributed import get_tensor_model_parallel_world_size\n from vllm.forward_context import get_forward_context\n@@ -45,6 +46,7 @@\n )\n from vllm.platforms import current_platform\n from vllm.platforms.interface import DeviceCapability\n+from vllm.utils.math_utils import cdiv\n from vllm.utils.torch_utils import (\n     LayerNameType,\n     _encode_layer_name,\n@@ -75,6 +77,7 @@\n from . import model\n from .indexer_qsa import QSAIndexer\n from .ops.qsa import qsa_e4m3_uses_native_cast\n+from .ops.qsa_indexer import _TOPK_WORKSPACE_BYTES\n \n logger = init_logger(__name__)\n \n@@ -782,6 +785,31 @@\n         if isinstance(metadata, list):\n             metadata = metadata[0]\n         if not isinstance(metadata, dict):\n+            # E25 NB1: backport of vLLM PR #60490 (issue #60489).\n+            # Profiling/dummy run: the indexer allocates its selection scratch\n+            # on demand, so touch its peak here for the memory profiler (as\n+            # sparse_attn_indexer does): the prefill logits budget or the\n+            # worst-case decode logits [decode tokens, compressed columns],\n+            # plus the top-k workspace.\n+            logits_bytes = envs.VLLM_SPARSE_INDEXER_MAX_LOGITS_MB * 1024 * 1024\n+            cfg = get_current_vllm_config_or_none()\n+            if cfg is not None:\n+                spec = cfg.speculative_config\n+                num_spec = spec.num_speculative_tokens if spec is not None else 0\n+                decode_tokens = min(\n+                    cfg.scheduler_config.max_num_seqs * (num_spec + 1),\n+                    cfg.scheduler_config.max_num_batched_tokens,\n+                )\n+                block_size = cfg.cache_config.block_size\n+                columns = cdiv(cfg.model_config.max_model_len, block_size) * cdiv(\n+                    block_size, self.indexer.compress_ratio\n+                )\n+                logits_bytes = max(logits_bytes, decode_tokens * columns * 4)\n+            _ = torch.empty(\n+                logits_bytes + _TOPK_WORKSPACE_BYTES,\n+                dtype=torch.uint8,\n+                device=output.device,\n+            )\n             output.zero_()\n             return\n         main_metadata = cast(FlashAttentionMetadata, metadata[self.layer_name])\n"
    P60490_REL = "vllm/models/qwen4_exp/nvidia/qsa.py"
    P60490_PRE, P60490_POST = "a23d5f90507ad5185f8b8e8d6ba13ae0cb53b2506264fdfbbf6a60b1171dc653", "88fe0a8f4dd2ef90fc6aefb5771b5b48e40c0b1d575039283c52aeca19b8bd6b"
    P60490_MARKER = "# E25 NB1: backport of vLLM PR #60490 (issue #60489)."
    NB1_EXT_SRC = "\"\"\"E25 NB1 worker extension (read-only): reached through POST /collective_rpc {\"method\": \"nb1_cache_info\"} with\nVLLM_SERVER_DEV_MODE=1 and --worker-extension-cls nb1_worker_ext.NB1WorkerExt. Reports the ACTUAL cache tensors bound\nto every attention / Mamba layer (dtype, shape, bytes), the KV cache specs (padded vs unpadded Mamba page bytes), the\nphysical block count and this rank's free memory. It never raises: every part returns its error text instead.\"\"\"\nimport json\nimport math\n\n\ndef _t(x):\n    try:\n        import torch\n        if isinstance(x, torch.Tensor):\n            return {\"dtype\": str(x.dtype).replace(\"torch.\", \"\"), \"shape\": list(x.shape), \"bytes\": int(x.numel() * x.element_size())}\n    except Exception:\n        pass\n    return None\n\n\ndef _flat(kc):\n    if _t(kc):\n        return [kc]\n    if isinstance(kc, (list, tuple)):\n        if kc and isinstance(kc[0], (list, tuple)) and not _t(kc[0]):\n            kc = kc[0]                              # one entry per virtual engine\n        return [x for x in kc if _t(x)]\n    return []\n\n\n_RT = {\"on\": False, \"installed\": False, \"rows\": [], \"passes\": 0, \"calls\": 0, \"max_steps\": 200, \"bytes\": 0, \"errors\": [],\n       \"first\": None, \"skipped_capturing\": 0, \"skipped_prefill\": 0}\n_RT_MAX_BYTES = 16 << 20\n_RT_DECODE_MAX_ROWS = 128          # a decode / verify micro-batch: requests x (1 + K) tokens; prefill chunks are larger\n\n\ndef _rt_layer(name):\n    import re as _r\n    m = _r.search(r\"layers\\.(\\d+)\", str(name))\n    return int(m.group(1)) if m else -1\n\n\ndef _rt_wrap(orig):\n    def select_experts(self, hidden_states, router_logits, *a, **k):\n        out = orig(self, hidden_states, router_logits, *a, **k)\n        if _RT[\"on\"] and _RT[\"passes\"] < 2 * _RT[\"max_steps\"] and _RT[\"bytes\"] < _RT_MAX_BYTES:\n            try:\n                import torch\n                if torch.cuda.is_current_stream_capturing():\n                    _RT[\"skipped_capturing\"] += 1\n                else:\n                    ids = out[1]\n                    lay = _rt_layer(getattr(self, \"nb1_layer\", None))\n                    if _RT[\"first\"] is None:\n                        _RT[\"first\"] = lay\n                    n = int(ids.shape[0])\n                    if n > _RT_DECODE_MAX_ROWS:\n                        _RT[\"skipped_prefill\"] += 1\n                    else:\n                        if lay == _RT[\"first\"]:\n                            _RT[\"passes\"] += 1     # one pass of a micro-batch through this stage's first MoE layer\n                        keep = ids.to(torch.int16).cpu().numpy().reshape(n, -1)\n                        _RT[\"rows\"].append((lay, max(0, _RT[\"passes\"] - 1), n, keep))\n                        _RT[\"bytes\"] += keep.nbytes\n                        _RT[\"calls\"] += 1\n            except Exception as e:\n                if len(_RT[\"errors\"]) < 5:\n                    _RT[\"errors\"].append(repr(e)[:160])\n        return out\n    return select_experts\n\n\nclass NB1WorkerExt:\n    def nb1_routing(self, action, arg=\"\"):\n        \"\"\"Router top-k expert ids, ONLY between 'start' and 'stop' (the profiling window): FusedMoERouter.select_experts is\n        wrapped once at class level; every decode / verify-sized call (<= 128 token rows) that runs in Python (not during\n        a CUDA-graph capture) keeps its ids (int16) with the layer index and the pass index (counted at this stage's first\n        MoE layer; NB1 maps pass -> step = pass // 2, mb_index = pass % 2 under PP2); <= max_steps steps, <= 16 MiB per\n        rank. FULL-graph replays run no Python, so graph-replayed decode steps are NOT recorded (vLLM's\n        --enable-return-routed-experts writes the ids from inside the graph; it changes the forward graph and memory, so it\n        is not used on a measured boot). 'stop' writes the rank's part file <arg>_rank<r>.npz.\"\"\"\n        out = {\"action\": action}\n        try:\n            import torch.distributed as dist\n            rank = dist.get_rank() if dist.is_initialized() else 0\n            out[\"rank\"] = rank\n            if action == \"start\":\n                from vllm.model_executor.layers.fused_moe.router.fused_moe_router import FusedMoERouter\n                if not _RT[\"installed\"]:\n                    FusedMoERouter.select_experts = _rt_wrap(FusedMoERouter.select_experts)\n                    _RT[\"installed\"] = True\n                    model = getattr(getattr(self, \"model_runner\", None), \"model\", None)\n                    named = 0\n                    if model is not None:\n                        for name, mod in model.named_modules():\n                            for attr in (\"router\", \"_router\"):\n                                r = getattr(mod, attr, None)\n                                if isinstance(r, FusedMoERouter):\n                                    r.nb1_layer = name\n                                    named += 1\n                    out[\"routers_named\"] = named\n                _RT.update(on=True, rows=[], passes=0, calls=0, bytes=0, errors=[], first=None, skipped_capturing=0,\n                           skipped_prefill=0, max_steps=int(arg or 200))\n                return out\n            _RT[\"on\"] = False\n            out.update(passes=_RT[\"passes\"], calls=_RT[\"calls\"], bytes=_RT[\"bytes\"], errors=_RT[\"errors\"],\n                       skipped_capturing=_RT[\"skipped_capturing\"], skipped_prefill=_RT[\"skipped_prefill\"])\n            if action == \"stop\" and arg and _RT[\"rows\"]:\n                import numpy as np\n                rows = _RT[\"rows\"]\n                offs, o_ = [], 0\n                for r in rows:\n                    offs.append(o_)\n                    o_ += r[2]\n                path = f\"{arg}_rank{rank}.npz\"\n                np.savez_compressed(path, ids=np.concatenate([r[3] for r in rows], axis=0), layer=np.array([r[0] for r in rows]),\n                                    pass_index=np.array([r[1] for r in rows]), mb_size=np.array([r[2] for r in rows]),\n                                    offset=np.array(offs), rank=np.array([rank]))\n                out[\"path\"] = path\n            _RT[\"rows\"] = []\n        except Exception as e:\n            out[\"error\"] = repr(e)[:300]\n        return out\n\n    def nb1_cache_info(self):\n        out = {}\n        try:\n            import torch.distributed as dist\n            out[\"rank\"] = dist.get_rank() if dist.is_initialized() else None\n        except Exception as e:\n            out[\"rank_error\"] = repr(e)[:120]\n        try:\n            ctx = self.vllm_config.compilation_config.static_forward_context\n            sig = {}\n            for name, mod in ctx.items():\n                ts = [_t(x) for x in _flat(getattr(mod, \"kv_cache\", None))]\n                if not ts:\n                    continue\n                key = type(mod).__name__ + \"|\" + json.dumps([(x[\"dtype\"], x[\"shape\"]) for x in ts])\n                g = sig.setdefault(key, {\"module\": type(mod).__name__, \"tensors\": ts, \"layers\": 0, \"example\": name})\n                g[\"layers\"] += 1\n            out[\"cache_tensors\"] = list(sig.values())[:40]\n        except Exception as e:\n            out[\"cache_tensors_error\"] = repr(e)[:300]\n        try:\n            agg = {}\n            for name, sp in self.get_kv_cache_spec().items():\n                d = {\"type\": type(sp).__name__}\n                for k in (\"block_size\", \"page_size_bytes\", \"page_size_padded\", \"dtype\", \"num_kv_heads\", \"head_size\", \"mamba_type\"):\n                    try:\n                        v = getattr(sp, k, None)\n                        d[k] = v if isinstance(v, (int, float, str, bool, type(None))) else str(v)\n                    except Exception as e:\n                        d[k] = \"ERR \" + repr(e)[:60]\n                shapes, dtypes = getattr(sp, \"shapes\", None), getattr(sp, \"dtypes\", None)\n                if shapes and dtypes:\n                    try:\n                        d[\"state_dtypes\"] = [str(x).replace(\"torch.\", \"\") for x in dtypes]\n                        d[\"state_shapes\"] = [list(s) for s in shapes]\n                        d[\"unpadded_page_bytes\"] = int(sum(math.prod(s) * x.itemsize for s, x in zip(shapes, dtypes)))\n                    except Exception as e:\n                        d[\"unpadded_error\"] = repr(e)[:80]\n                key = json.dumps(d, sort_keys=True, default=str)\n                a = agg.setdefault(key, dict(d, layers=0, example=name))\n                a[\"layers\"] += 1\n            out[\"kv_cache_specs\"] = list(agg.values())[:40]\n        except Exception as e:\n            out[\"kv_cache_specs_error\"] = repr(e)[:300]\n        try:\n            out[\"num_gpu_blocks\"] = getattr(self.cache_config, \"num_gpu_blocks\", None)\n            out[\"mamba_page_size_padded\"] = getattr(self.cache_config, \"mamba_page_size_padded\", None)\n            out[\"mamba_ssm_cache_dtype\"] = str(getattr(self.cache_config, \"mamba_ssm_cache_dtype\", None))\n            out[\"cache_block_size\"] = getattr(self.cache_config, \"block_size\", None)\n        except Exception as e:\n            out[\"cache_config_error\"] = repr(e)[:200]\n        try:\n            for obj in (getattr(self, \"model_runner\", None), self):\n                cfg = getattr(obj, \"kv_cache_config\", None)\n                if cfg is not None:\n                    out[\"kv_cache_config\"] = {\n                        \"num_blocks\": getattr(cfg, \"num_blocks\", None),\n                        \"groups\": [{\"spec\": type(g.kv_cache_spec).__name__, \"layers\": len(g.layer_names),\n                                    \"block_size\": getattr(g.kv_cache_spec, \"block_size\", None),\n                                    \"page_size_bytes\": getattr(g.kv_cache_spec, \"page_size_bytes\", None)}\n                                   for g in getattr(cfg, \"kv_cache_groups\", [])][:16],\n                        \"tensors\": [{\"size\": getattr(t, \"size\", None), \"shared_by\": len(getattr(t, \"shared_by\", None) or [])}\n                                    for t in getattr(cfg, \"kv_cache_tensors\", [])][:24]}\n                    break\n        except Exception as e:\n            out[\"kv_cache_config_error\"] = repr(e)[:300]\n        try:\n            import torch\n            fr, tot = torch.cuda.mem_get_info()\n            out[\"mem\"] = {\"free_mib\": fr >> 20, \"total_mib\": tot >> 20, \"allocated_mib\": torch.cuda.memory_allocated() >> 20,\n                          \"reserved_mib\": torch.cuda.memory_reserved() >> 20, \"max_allocated_mib\": torch.cuda.max_memory_allocated() >> 20}\n        except Exception as e:\n            out[\"mem_error\"] = repr(e)[:200]\n        return out\n\n\n    def nb4s_env(self, keys=\"\"):\n        \"\"\"E25 NB4S (read-only): this worker's os.environ for the comma-separated `keys` (default CUDA_DEVICE_MAX_CONNECTIONS),\n        all NCCL_* / CUDA_* variables, pid, rank and device. CUDA reads CUDA_DEVICE_MAX_CONNECTIONS at context creation, so\n        the process env (inherited at spawn, before CUDA init) is what is in effect. Never raises.\"\"\"\n        import os as _os\n        out = {\"pid\": _os.getpid()}\n        try:\n            ks = [k for k in str(keys or \"CUDA_DEVICE_MAX_CONNECTIONS\").split(\",\") if k]\n            out[\"env\"] = {k: _os.environ[k] for k in ks if k in _os.environ}\n            out[\"nccl_cuda_env\"] = {k: v for k, v in sorted(_os.environ.items()) if k.startswith((\"NCCL_\", \"CUDA_\"))}\n        except Exception as e:\n            out[\"error\"] = repr(e)[:200]\n        try:\n            import torch.distributed as dist\n            out[\"rank\"] = dist.get_rank() if dist.is_initialized() else None\n        except Exception as e:\n            out[\"rank_error\"] = repr(e)[:120]\n        try:\n            import torch\n            out[\"device\"] = torch.cuda.current_device() if torch.cuda.is_available() else None\n        except Exception as e:\n            out[\"device_error\"] = repr(e)[:120]\n        return out\n"

    def apply_unified(text, patch):
        """Strict unified-diff applier (no fuzz, no offset): every context / removed line must match at its stated line,
        else ValueError. Lines before the first hunk (comments, ---/+++ headers) are ignored."""
        src = text.splitlines(True)
        hunks, cur = [], None
        for ln in patch.splitlines(True):
            if ln.startswith("@@"):
                m = re.match(r"@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@", ln)
                if not m:
                    raise ValueError("bad hunk header: " + ln[:80])
                cur = [int(m.group(1)), int(m.group(2) or 1), []]
                hunks.append(cur)
            elif cur is not None and ln[:1] in (" ", "-", "+"):
                cur[2].append(ln)
            elif cur is not None and ln.startswith("\\"):
                raise ValueError("'No newline at end of file' hunks are not supported")
        if not hunks:
            raise ValueError("patch has no hunks")
        out, pos = [], 0
        for start, n_old, body in hunks:
            i = start - 1
            if i < pos:
                raise ValueError(f"overlapping hunk at line {start}")
            out += src[pos:i]
            old_seen = 0
            for ln in body:
                tag, s = ln[0], ln[1:]
                if tag in " -":
                    if i >= len(src) or src[i] != s:
                        raise ValueError(f"context mismatch at line {i + 1}: {s[:60]!r}")
                    i += 1
                    old_seen += 1
                if tag in " +":
                    out.append(s)
            if old_seen != n_old:
                raise ValueError(f"hunk at line {start}: {old_seen} old lines, header says {n_old}")
            pos = i
        return "".join(out + src[pos:])


    def apply_60490():
        """After merlin_install, before B1: patch the installed tree's qsa.py (pre-sha must be Merlin ad42e37's), verify the
        post-sha, the marker, a py_compile with the Merlin venv and that `vllm` resolves to the tree; write the read-only
        worker extension next to the tree's vllm/ (on the server's PYTHONPATH). Any miss raises: no boot is started."""
        if FAKE:
            tree = os.environ.get("NB1_FAKE_TREE")
            if not tree:
                raise RuntimeError("PATCH_60490_NO_TREE: NB1_FAKE_TREE is not set (local harness)")
            tree, py = Path(tree), sys.executable
        else:
            eng = merlin_install()
            tree, py = Path(eng["kv"]["MERLIN_TREE"]), eng["kv"]["MERLIN_VENV"] + "/bin/python"
        f = tree / P60490_REL
        raw = f.read_bytes()
        h0 = hashlib.sha256(raw).hexdigest()
        rec = {"file": str(f), "sha_before": h0, "pre_expected": P60490_PRE, "post_expected": P60490_POST}
        if h0 == P60490_POST:
            rec["applied"] = "already_applied"
        elif h0 != P60490_PRE:
            raise RuntimeError(f"PATCH_60490_PRE_SHA_MISMATCH: {h0} (expected Merlin ad42e37 {P60490_PRE})")
        else:
            new = apply_unified(raw.decode("utf-8"), P60490).encode("utf-8")
            if hashlib.sha256(new).hexdigest() != P60490_POST:
                raise RuntimeError("PATCH_60490_POST_SHA_MISMATCH: " + hashlib.sha256(new).hexdigest())
            tmp = f.with_name(f.name + ".nb1tmp")
            tmp.write_bytes(new)
            os.replace(tmp, f)
            rec["applied"] = "applied"
        for pyc in (f.parent / "__pycache__").glob("qsa.*.pyc"):
            pyc.unlink()
        data = f.read_bytes()
        rec.update(sha_after=hashlib.sha256(data).hexdigest(), marker=P60490_MARKER.encode() in data)
        ext = tree / "nb1_worker_ext.py"
        ext.write_text(NB1_EXT_SRC)
        rec["worker_ext"] = {"file": str(ext), "sha256": hashlib.sha256(ext.read_bytes()).hexdigest()}
        cp = subprocess.run([py, "-c", "import py_compile, sys\nfor f in sys.argv[1:]: py_compile.compile(f, doraise=True)", str(f), str(ext)],
                            capture_output=True, text=True, timeout=300)
        rec["py_compile"] = {"rc": cp.returncode, "err": cp.stderr[-400:]}
        origin_ok = True
        if not FAKE:
            envp = {k: v for k, v in os.environ.items() if k != "PYTHONPATH"}
            envp["PYTHONPATH"] = str(tree)            # what Merlin's build() exports for the server
            cp2 = subprocess.run([py, "-c", "import importlib.util as u; print(u.find_spec('vllm').origin); print(u.find_spec('nb1_worker_ext').origin)"],
                                 capture_output=True, text=True, timeout=300, env=envp)
            rec["vllm_origin"] = cp2.stdout.strip()[-400:]
            origin_ok = all(l.startswith(str(tree)) for l in cp2.stdout.strip().splitlines()[-2:]) and len(cp2.stdout.strip().splitlines()) >= 2
        if rec["sha_after"] != P60490_POST or not rec["marker"] or cp.returncode or not origin_ok:
            raise RuntimeError("PATCH_60490_VERIFY_FAILED: " + json.dumps({k: rec.get(k) for k in ("sha_after", "marker", "py_compile", "vllm_origin")})[:600])
        rec["ok"] = True
        rec["forward_test"] = "B1's greedy oracle vs RC2's recorded FP8 rows (unpatched RC2 FP8; B1 adds text-only): B1 oracle.vs_rc2_fp8"
        return rec


    # ---- host memory: previous engine gone, our leaked shm removed, page cache dropped (measured), Merlin's rule
    def cgroup_snapshot(tag):
        """memory.current / stat / events / pressure (first 12 kB each) to hostmem/<tag>.txt; key numbers returned."""
        rec, txt = {"tag": tag}, []
        for n in ("memory.current", "memory.stat", "memory.events", "memory.pressure"):
            try:
                s = (Path("/sys/fs/cgroup") / n).read_text()[:12000]
            except Exception:
                continue
            txt.append(f"--- {n} ---\n{s}")
            if n == "memory.current":
                rec["current_mib"] = int(s.strip()) >> 20
            elif n == "memory.events":
                rec["events"] = {a: int(b) for a, b in (l.split() for l in s.splitlines() if len(l.split()) == 2)}
            elif n == "memory.pressure":
                rec["pressure"] = s.strip().splitlines()[:2]
        try:
            (HOSTMEM / f"{tag}.txt").write_text("\n".join(txt))
        except Exception:
            pass
        rec["host_mem"] = host_mem()
        return rec


    ENGINE_RX = re.compile(r"vllm|PleOffload|ple_offload|EngineCore|merlin_off/venv", re.I)


    def engine_procs():
        """Processes of an engine (vLLM server, workers, PLE offload) other than this notebook; None off Linux."""
        if not Path("/proc/self/stat").exists():
            return None
        me, out = os.getpid(), []
        for d in Path("/proc").glob("[0-9]*"):
            try:
                pid = int(d.name)
                if pid == me:
                    continue
                cmd = (d / "cmdline").read_bytes().replace(b"\0", b" ").decode(errors="replace")
                if ENGINE_RX.search(cmd) and "py_compile" not in cmd:
                    out.append([pid, cmd[:160]])
            except Exception:
                pass
        return out


    def clear_engine_procs():
        left0 = engine_procs()
        rec = {"found": left0}
        if left0:
            for pid, _ in left0:
                try:
                    os.kill(pid, 9)
                except Exception:
                    pass
            time.sleep(10)
            rec["after_kill"] = engine_procs()
        rec["ok"] = not (rec.get("after_kill") if left0 else left0)
        return rec


    def drop_page_cache():
        """posix_fadvise(DONTNEED) on every checkpoint file (merged dir symlinks resolved + the Model mounts); only after the
        previous server is dead (never on the pinned PLE pages of a live server). A measured attempt, not an assumed fix."""
        if not hasattr(os, "posix_fadvise"):
            return {"available": False}
        t, seen, n, b, err = time.time(), set(), 0, 0, 0
        roots = [CKPT] + [v[0] for v in PARTS.values() if v] + ([PLE_DIR] if PLE_DIR else [])
        for root in roots:
            for dp, _, fns in os.walk(str(root)):
                for x in fns:
                    p = os.path.realpath(os.path.join(dp, x))
                    if p in seen:
                        continue
                    seen.add(p)
                    try:
                        fd = os.open(p, os.O_RDONLY)
                        try:
                            os.posix_fadvise(fd, 0, 0, os.POSIX_FADV_DONTNEED)
                            b += os.fstat(fd).st_size
                            n += 1
                        finally:
                            os.close(fd)
                    except OSError:
                        err += 1
        return {"available": True, "files": n, "gib": round(b / 2 ** 30, 1), "errors": err, "sec": round(time.time() - t, 1)}


    def host_ram_gate(tag):
        before = cgroup_snapshot(tag + "_before_drop")
        drops, tries = [drop_page_cache()], 0
        after = host_mem()
        while True:
            av = after.get("avail_mib", after.get("MemAvailable_mib"))
            if av is None:
                ok = bool(FAKE)               # local harness only; on Kaggle an unreadable host is never "enough"
                why = "no cgroup / meminfo reading" + (" (local harness: skipped)" if FAKE else ": HOST_RAM_GATE fails closed")
                break
            if av >= RAM_NEED_MIB:
                ok, why = True, f"avail {av} MiB >= {RAM_NEED_MIB}"
                break
            if FAKE:                          # local / CPU-kit harness only (a 30 GiB CPU box): recorded, never enforced
                ok, why = True, f"avail {av} MiB < {RAM_NEED_MIB} MiB (local harness: recorded, not enforced)"
                break
            tries += 1
            if tries > 3:
                ok, why = False, f"HOST_RAM_GATE: avail {av} MiB < {RAM_NEED_MIB} MiB after {tries} page-cache drops"
                break
            time.sleep(20)
            drops.append(drop_page_cache())
            after = host_mem()
        return {"ok": ok, "why": why, "need_mib": RAM_NEED_MIB, "before": before, "after_drop": cgroup_snapshot(tag + "_after_drop"),
                "drops": drops}


    _boot_gate_rc2, _shm_cleanup_rc2 = boot_gate, shm_cleanup
    BOOT = {"deadline": None, "fired": None, "tag": "boot"}


    def boot_gate():
        """RC2's GPU release gate (< 150 MiB per card), the previous engine's processes gone, then the host-RAM gate."""
        g = _boot_gate_rc2()
        if g.get("ok") is not True:
            return g
        g["engine_procs"] = clear_engine_procs()
        if not g["engine_procs"]["ok"]:
            g["ok"], g["why"] = False, "ENGINE_PROCS_LEFT: " + json.dumps(g["engine_procs"].get("after_kill"))[:300]
            return g
        h = host_ram_gate(BOOT["tag"])
        g["host_ram"] = h
        if not h["ok"]:
            g["ok"], g["why"] = False, h["why"]
        return g


    def shm_cleanup(before):
        """RC2's /dev/shm cleanup (this boot's torch_/psm_/vllm/ple/nccl/sem.mp-/cuda.shm entries) + the loky semaphores the
        RC2 log reported leaked at shutdown (sem.loky-*), only when created during this boot."""
        out = _shm_cleanup_rc2(before)
        out["removed_loky"] = []
        try:
            for p in sorted(SHM.iterdir()):
                if p.name not in before and re.match(r"sem\.loky-", p.name):
                    try:
                        p.unlink()
                        out["removed_loky"].append(p.name)
                    except Exception:
                        pass
        except Exception:
            pass
        return out


    class LoadMonitor(threading.Thread):
        """Every 10 s from launch until ready: per process of the server's session, major faults and /proc/<pid>/io
        (rchar, read_bytes) + the cgroup current; a slow worker (RC2: 873 s vs 125 s) becomes diagnosable."""
        def __init__(self, name):
            super().__init__(daemon=True)
            self.sname, self.stop_ev, self.path, self.last = name, threading.Event(), OUT / f"load_monitor_{name}.jsonl", None

        def sample(self, sid):
            rows = []
            for d in Path("/proc").glob("[0-9]*"):
                try:
                    st = (d / "stat").read_text()
                    rp = st.rindex(")")
                    f = st[rp + 2:].split()
                    if int(f[3]) != sid:
                        continue
                    io = dict(l.split(": ", 1) for l in (d / "io").read_text().splitlines() if ": " in l)
                    rows.append([int(d.name), st[st.index("(") + 1:rp][:24], int(f[9]), int(io.get("rchar", 0)) >> 20,
                                 int(io.get("read_bytes", 0)) >> 20])
                except Exception:
                    pass
            return rows

        def run(self):
            while not self.stop_ev.is_set():
                srv = next((x for x in list(L.LIVE) if x.name == self.sname), None)
                if srv is not None and srv.proc is not None and Path("/proc/self/stat").exists():
                    rec = {"t": round(time.time() - T_START, 1), "procs[pid,comm,majflt,rchar_mib,read_mib]": self.sample(srv.proc.pid),
                           "cgroup_mib": (host_mem() or {}).get("cgroup_cur_mib")}
                    self.last = rec
                    try:
                        with open(self.path, "a") as fh:
                            fh.write(json.dumps(rec) + "\n")
                    except Exception:
                        pass
                    if srv.ready_sec is not None:
                        break
                self.stop_ev.wait(10)


    # ---- per-boot watchdog
    def boot_left():
        d = BOOT["deadline"]
        return min(left(), (d - time.time()) if d else float("inf"))


    def due(sec):
        return boot_left() > sec and not ABORT["why"]


    def watched(body, cap_sec, name):
        """The boot body gets `cap_sec`; every step checks due(); at cap + 300 s the server is killed (hard backstop)."""
        def b(ss):
            BOOT.update(deadline=time.time() + cap_sec, fired=None)

            def fire():
                BOOT["fired"] = name
                for x in ss:
                    try:
                        x.kill()
                    except Exception:
                        pass
            tm = threading.Timer(cap_sec + 300, fire)
            tm.daemon = True
            tm.start()
            try:
                o = body(ss)
                LIVE["out"] = o if isinstance(o, dict) else None   # R2: step() keeps it if anything after the body raises
            finally:
                tm.cancel()
                BOOT["deadline"] = None
            if BOOT["fired"]:
                o["boot_watchdog"] = f"FIRED after {cap_sec + 300:.0f} s: server killed"
            return o
        return b


    # ---- server facts read from the log and from the workers
    def _pick(t, rx, n=6):
        return [l.strip()[:300] for l in t.splitlines() if re.search(rx, l)][:n]


    def server_caps(t, argv=()):
        na = next((l for l in t.splitlines() if "non-default args:" in l), "")
        caps = {"source": "log" if na else "argv"}
        for k in ("max_num_seqs", "max_num_batched_tokens", "block_size", "max_model_len", "kv_cache_memory_bytes", "num_speculative_tokens"):
            m = re.search(rf"'{k}': (\d+)", na)
            caps[k] = int(m.group(1)) if m else None
        for k in ("kv_cache_dtype", "mamba_ssm_cache_dtype", "mamba_cache_mode", "worker_extension_cls"):
            m = re.search(rf"'{k}': '([^']+)'", na)
            caps[k] = m.group(1) if m else None
        m = re.search(r"'language_model_only': (True|False)", na)
        caps["language_model_only"] = m.group(1) == "True" if m else False
        m = re.search(r"'cudagraph_capture_sizes': \[([\d, ]+)\]", na)
        caps["capture_sizes"] = [int(x) for x in m.group(1).split(",")] if m else None
        m = re.findall(r"Setting attention block size to (\d+) tokens", t)
        if m:
            caps["block_size"] = int(m[-1])
        if not na:                                     # fallback (the E23 fake has no args line): the argv, last wins
            a = [str(x) for x in argv]
            for flag, key in (("--max-num-seqs", "max_num_seqs"), ("--block-size", "block_size")):
                idx = [i for i, x in enumerate(a) if x == flag]
                if idx and idx[-1] + 1 < len(a):
                    caps[key] = int(a[idx[-1] + 1])
        caps["block_size"] = caps.get("block_size") or BLOCK
        sizes = caps.get("capture_sizes") or []
        k = caps.get("num_speculative_tokens") or 3
        caps["captures_cover_seqs_x_1pk"] = bool(sizes) and caps.get("max_num_seqs") is not None and max(sizes) >= caps["max_num_seqs"] * (1 + k)
        return caps


    def pool_facts(t):
        f = {}
        m = re.findall(r"GPU KV cache size: ([\d,]+) tokens", t)
        f["kv_tokens"] = int(m[-1].replace(",", "")) if m else None
        m = re.findall(r"Maximum concurrency for ([\d,]+) tokens per request: ([\d.]+)x", t)
        f["max_concurrency"] = float(m[-1][1]) if m else None
        f["max_concurrency_tokens"] = int(m[-1][0].replace(",", "")) if m else None     # R2: M of the line (F_log)
        m = re.findall(r"Padding mamba page size by ([\d.]+)%", t)
        f["mamba_pad_pct"] = float(m[-1]) if m else None
        f["min_block_for_mamba"] = math.ceil(BLOCK / (1 + f["mamba_pad_pct"] / 100)) if m else None
        f["kv_group_sizes"] = (re.findall(r"kv cache group sizes \(([^)]*)\)", t) or [None])[-1]
        f["side_cache_layout"] = _pick(t, r"Side-cache layout", 2)
        f["initial_free_reserved_gib"] = [[float(a), float(b)] for a, b in re.findall(r"Initial free memory ([\d.]+) GiB, reserved ([\d.]+) GiB", t)][:4]
        f["model_load_gib_sec"] = [[float(a), float(b)] for a, b in re.findall(r"Model loading took ([\d.]+) GiB memory and ([\d.]+) seconds", t)][:4]
        f["graph_capture_sec_gib"] = [[int(a), float(b)] for a, b in re.findall(r"Graph capturing finished in (\d+) secs, took ([\d.]+) GiB", t)][:4]
        f["rank_load_gib"] = {int(p) * 2 + int(q): float(g) for p, q, g in re.findall(
            r"\(Worker_PP(\d)_TP(\d)\S*(?: pid=\d+)?\) INFO [^\n]*?Model loading took ([\d.]+) GiB memory", t)}
        f["rank_load_sec"] = {int(p) * 2 + int(q): float(g) for p, q, g in re.findall(
            r"\(Worker_PP(\d)_TP(\d)\S*(?: pid=\d+)?\) INFO [^\n]*?Model loading took [\d.]+ GiB memory and ([\d.]+) seconds", t)}
        f["rank_graph_gib"] = {int(p) * 2 + int(q): float(g) for p, q, g in re.findall(
            r"\(Worker_PP(\d)_TP(\d)\S*(?: pid=\d+)?\) INFO [^\n]*?Graph capturing finished in \d+ secs, took ([\d.]+) GiB", t)}
        f["ssm_dtype_lines"] = _pick(t, r"mamba_ssm_dtype|mamba-ssm-cache-dtype")
        f["gdn_fallback_lines"] = _pick(t, r"Falling back to the Triton GDN spec decode path")
        f["share_workspace_lines"] = _pick(t, r"MERLIN_SHARE_DRAFT_WORKSPACE")
        f["mm_warmup_lines"] = _pick(t, r"Multi-modal warmup completed")
        f["host_ram_lines"] = _pick(t, r"host memory available now|Cgroup memory preflight|Skipping auto-prefetch", 6)
        f["sched_warn_lines"] = _pick(t, r"max_num_scheduled_tokens", 2)
        f["oom_lines"] = _pick(t, r"OutOfMemoryError|CUDA out of memory", 4)
        f["static_scale_lines"] = _pick(t, r"applied static K/V scales", 8)
        f["default_scale_lines"] = _pick(t, r"DEFAULT 1\.0|no static calibration", 4)    # audit 2: the MTP layer's QSA FP8 KV
        f["ext_lines"] = _pick(t, r"Injected .*NB1WorkerExt|nb1_worker_ext", 2)
        f["shm_leak_lines"] = _pick(t, r"leaked (semaphore|shared_memory) objects", 4)
        return f


    def graph_facts(t):
        caps = sorted({(a, int(c)) for a, b, c in re.findall(r"Capturing CUDA graphs \((\w+)\):\s*100%\|[^|]*\|\s*(\d+)/(\d+)", t)})
        return {"captured": caps, "resolved_modes": _pick(t, r"resolved cudagraph modes before capture", 8),
                "draft_identity": _pick(t, r"e2-identity\[.*role=draft", 4), "recoverssm_commit": _pick(t, r"\[recoverssm-commit\]"),
                "recoverssm_path": _pick(t, r"RecoverSSM path taken", 4), "jit": jit_kernels(t)}


    def jit_kernels(t):
        return re.findall(r"JIT compilation during inference: (\w+)", t)


    def nccl_transport(t):
        via = Counter(re.findall(r"NCCL INFO Channel \d+/\d+ ?: ?\d+\[\d+\] -> \d+\[\d+\] (?:\[\w+\] )?via (\S+)", t))
        return {"channel_via": dict(via), "net": sorted(set(re.findall(r"NCCL INFO (Using network \w+|NET/\w+ : Using [^\n]{0,60})", t)))[:6],
                "comm_inits": len(re.findall(r"NCCL INFO comm 0x[0-9a-f]+ rank \d+ nranks \d+", t)),
                "pynccl_groups": _pick(t, r"all-reduce backends .* for group", 6),
                "debug_on": "NCCL INFO" in t}


    def rpc_cache_info(port):
        """The read-only worker extension over /collective_rpc (dev mode): actual cache tensor dtypes, specs, free memory."""
        body = {"method": "nb1_cache_info", "timeout": 120}
        try:
            r = json.loads(L.U.urlopen(L.U.Request(f"http://127.0.0.1:{port}/collective_rpc", data=json.dumps(body).encode(),
                                                   headers={"Content-Type": "application/json"}), timeout=180).read())
            res = r.get("results") or []
        except Exception as e:
            return {"error": repr(e)[:300]}
        out = {"ranks": res}
        dts = sorted({x["dtype"] for w in res if isinstance(w, dict) for g in (w.get("cache_tensors") or [])
                      if "mamba" in g.get("module", "").lower() or "gdn" in g.get("module", "").lower() or "linear" in g.get("module", "").lower()
                      for x in g.get("tensors") or []})
        out["recurrent_tensor_dtypes"] = dts
        out["num_gpu_blocks"] = sorted({w.get("num_gpu_blocks") for w in res if isinstance(w, dict)} - {None})
        out["free_mib_per_rank"] = [((w or {}).get("mem") or {}).get("free_mib") for w in res if isinstance(w, dict)]
        pads = []
        for w in res:
            for s in ((w or {}).get("kv_cache_specs") or []) if isinstance(w, dict) else []:
                if s.get("unpadded_page_bytes") and s.get("page_size_bytes"):
                    pads.append({"rank": w.get("rank"), "type": s.get("type"), "layers": s.get("layers"), "state_dtypes": s.get("state_dtypes"),
                                 "padded": s["page_size_bytes"], "unpadded": s["unpadded_page_bytes"],
                                 "pad_pct": round(100 * (s["page_size_bytes"] - s["unpadded_page_bytes"]) / s["unpadded_page_bytes"], 2)})
        out["mamba_padding"] = pads[:16]
        return out


    def rpc(port, method, *args, timeout=120):
        """POST /collective_rpc (dev mode): a worker method by name with string args; the per-rank results or the error."""
        body = {"method": method, "args": [str(a) for a in args], "timeout": timeout}
        try:
            r = json.loads(L.U.urlopen(L.U.Request(f"http://127.0.0.1:{port}/collective_rpc", data=json.dumps(body).encode(),
                                                   headers={"Content-Type": "application/json"}), timeout=timeout + 60).read())
            return {"results": r.get("results")}
        except Exception as e:
            return {"error": repr(e)[:300]}








    def scales_dump():
        """The static QSA K/V scales file (all values) + which layers it covers; the MTP layer is not in it (default 1.0)."""
        p = CKPT / "qsa_kv_scales_262k.json"
        try:
            d = json.loads(p.read_text())
        except Exception as e:
            return {"error": repr(e)[:200]}
        lay = sorted(int(m.group(1)) for k in d for m in [re.search(r"layers\.(\d+)\.", k)] if m)
        ks = [v.get("k_scale") for v in d.values() if isinstance(v, dict)]
        vs = [v.get("v_scale") for v in d.values() if isinstance(v, dict)]
        return {"file": str(p), "sha256": hashlib.sha256(p.read_bytes()).hexdigest(), "values": d, "layers": lay, "n": len(d),
                "k_scale_min_max": [min(ks), max(ks)] if ks else None, "v_scale_min_max": [min(vs), max(vs)] if vs else None,
                "mtp_layer_in_file": any("mtp" in k for k in d)}


    def free_per_card(rec, name):
        """MiB free per card = total - the highest used reading of this boot (after ready, end, every window peak)."""
        srv = ((rec or {}).get("servers") or {}).get(name) or {}
        rows = [r for r in (srv.get("gpu_mem_after_ready"), srv.get("gpu_mem_end")) if r]
        if not rows:
            return None
        tot = {i: t for row in rows for i, _, t in row}
        used = {i: max(u for row in rows for j, u, _ in row if j == i) for i in tot}
        st = (rec or {}).get("steady")             # R2: nb1_ladder's steady holds "_plan" (list), "_fit" (dict), "_seqs_cap" (int)
        ws = list(st.values()) if isinstance(st, dict) else []
        for w in ws + [(rec or {}).get("profile")]:
            if not isinstance(w, dict):            # R2: only window dicts carry gpu_mem_peak_mib
                continue
            pk = w.get("gpu_mem_peak_mib")
            for i, u in enumerate(pk if isinstance(pk, list) else []):
                if i in used and isinstance(u, (int, float)):
                    used[i] = max(used[i], u)
        return [tot[i] - used[i] for i in sorted(tot)]


    def free_after_ready(rec, name):
        srv = ((rec or {}).get("servers") or {}).get(name) or {}
        row = srv.get("gpu_mem_after_ready")
        return [t - u for _, u, t in row] if row else None


    # ---- KV accounting: pool blocks from usage denominators; cold-cache cumulative admission (physical snapshots)
    def kvu(port):
        return L.prom(port).get(L.KVU)
























    F_MAX_BLOCKS = 40                                # R2: a per-request fixed-block F above 40 blocks is not physical here
    FIT_MIN_SAMPLES = 3                              # R2 audit N1-6: a fit is trusted only with >= 3 all-resident snapshots,
    FIT_MAX_RESID_BLOCKS = 2.0                       # a max |residual| <= 2 blocks
    FIT_LOG_TOL_BLOCKS = 1                           # and |ceil(fit F) - log F| <= 1 block
    F_LOG_SOURCE = "server max-concurrency line (this boot)"












    def profiler_tools():
        """ncu / nsys availability (DRAM bytes per stage need a server LAUNCHED under one of them: a separate boot)."""
        out = {}
        cands = ["ncu", "nsys", "/usr/local/cuda/bin/ncu", "/usr/local/cuda/bin/nsys"]
        try:
            eng = MERLIN_ENG if isinstance(MERLIN_ENG, dict) else {}
            if eng.get("cuda_home"):
                cands += [eng["cuda_home"] + "/bin/ncu", eng["cuda_home"] + "/bin/nsys"]
        except Exception:
            pass
        for c in cands:
            path = shutil.which(c) if "/" not in c else (c if os.path.exists(c) else None)
            if path:
                try:
                    v = subprocess.run([path, "--version"], capture_output=True, text=True, timeout=60).stdout.strip()[:200]
                except Exception as e:
                    v = repr(e)[:100]
                out[c] = {"path": path, "version": v}
        return {"found": out, "dram_bytes": "not measured in NB1: ncu / nsys cannot attach to a running vLLM server; DRAM bytes per "
                "stage need a boot launched under ncu (dram__bytes_read.sum on the Marlin MoE + dense kernels) or nsys: NB3 / NB4 item",
                "torch_profiler_window": "the PP2 trace window runs after the ladder, on its own streams; no benchmark window overlaps it"}


    # ---- requests with usage (cached tokens), greedy logprobs and teacher-forced rows with the cache counters








    # ---- JIT warm-up (excluded from every metric) and per-position acceptance
    def warmup(port, n, secs=None):
        """Multi-stream 2k decode, ramped 1 -> n streams, excluded from every metric: compiles the kernels RC2 saw compiled
        during inference (_fill_num_accepted_kernel, _causal_conv1d_update_kernel, _gdn_recoverssm_verify_kernel,
        _ple_conv_kernel, _ple_conv_writeback_kernel) before any measured window."""
        secs = secs or (45.0 if not FAKE else 4.0)
        srv = next((x for x in list(L.LIVE) if x.port == port), None)
        j0 = jit_kernels(srv.log()) if srv else []
        ss, t0 = [], time.time()
        try:
            for i in range(n):
                g = L.Stream(port, PROMPTS["2k"][i % len(PROMPTS["2k"])], 4096, temperature=TEMP, seed=900 + i, ignore_eos=True)
                g.start()
                ss.append(g)
                time.sleep(min(3.0, secs / max(1, 2 * n)))
            while time.time() - t0 < secs:
                time.sleep(1)
        finally:
            for g in ss:
                g.stop()
            for g in ss:
                g.join(10)
        L.wait_idle(port, 60)
        j1 = jit_kernels(srv.log()) if srv else []
        return {"streams": n, "sec": round(time.time() - t0, 1), "jit_before": j0, "jit_compiled_in_warmup": j1[len(j0):],
                "errors": sorted({g.err for g in ss if g.err})[:3]}


    def accept_pos(port):
        try:
            txt = L.U.urlopen(f"http://127.0.0.1:{port}/metrics", timeout=15).read().decode("utf-8", "replace")
        except Exception:
            return None
        pos = {}
        for m in re.finditer(r"^vllm:spec_decode_num_accepted_tokens_per_pos_total\{([^}]*)\}\s+(\S+)", txt, re.M):
            p = re.search(r'position="(\d+)"', m.group(1))
            if p:
                pos[int(p.group(1))] = pos.get(int(p.group(1)), 0.0) + float(m.group(2))
        return {"pos": pos, "drafts": L.prom(port).get(L.DRF, 0.0)}


    def _prefill_done(r, n):
        tail = ((r.get("admission") or {}).get("tail") or [])
        t = tail[-1] if tail else None
        return bool(t) and t[1] == n and t[2] == 0 and t[3] >= n


    def _req_lines():
        try:
            with open(REQ_LOG) as fh:
                return sum(1 for _ in fh)
        except Exception:
            return 0


    def _ttfts(port, start_line):
        out = []
        try:
            with open(REQ_LOG) as fh:
                for i, l in enumerate(fh):
                    if i >= start_line:
                        r = json.loads(l)
                        if r.get("port") == port and r.get("ttft") is not None:
                            out.append(r["ttft"])
        except Exception:
            pass
        return out


    def _counters(port):
        try:
            m = L.prom(port)
            return m.get(L.PROMPT, 0.0), m.get("vllm:prefix_cache_hits_total", 0.0)
        except Exception:
            return None, None


    def window(port, s, band, n, max_new=None, secs=None):
        """One steady window, timed only after every stream finished admission + prefill (the lab's settle needs all running
        streams to have emitted and be gaining, then an explicit check of the last admission sample; Merlin's cost-aware
        admission may hold a cold miss up to 120 s, inside the lab's >= 420 s admission limit); a window with prefill inside is
        retried once. Recorded: tick_ms (one engine step = one micro-batch of C/2 requests under PP2) AND cycle_ms (= PP x
        tick, the per-request advance time), per-request TTFT, uncached prefill tok/s (prompt minus prefix-hit tokens),
        retained (idle) blocks before the window, per-position acceptance."""
        retained_before = None
        if L.wait_idle(port, 60):
            retained_before = kvu(port)
        def run():
            if max_new is None:                 # RC2 / E23 levels(): MAX_NEW[band], WIN, the budget / KV-bound guards
                return levels(port, band, [n], server=s, temperature=TEMP, prefill_tok_s=PREFILL["tok_s"]).get(f"{band}@{n}") or {}
            return L.steady(port, PROMPTS[band], n, secs=secs or WIN, max_new=max_new, temperature=TEMP, prefill_tok_s=PREFILL["tok_s"])
        a0, c0, l0 = accept_pos(port), _counters(port), _req_lines()
        r = run()
        if r.get("status") == "INCONCLUSIVE_PREFILL_IN_WINDOW" and due(WIN + 120 + n * BANDS[band] / max(500.0, PREFILL["tok_s"])):
            c0, l0 = _counters(port), _req_lines()
            r = dict(run(), retried_after="INCONCLUSIVE_PREFILL_IN_WINDOW")
        a1, c1 = accept_pos(port), _counters(port)
        r["prefill_done_before_window"] = _prefill_done(r, n)
        r["running_eq_level"] = r.get("running_min") == r.get("running_max") == n
        if r.get("status") == "STEADY" and not (r["running_eq_level"] and r["prefill_done_before_window"]):
            r["status"] = "INCONCLUSIVE_RUNNING_NE_LEVEL" if not r["running_eq_level"] else "INCONCLUSIVE_PREFILL_NOT_DONE"
        if r.get("step_ms"):
            r["tick_ms"] = r["step_ms"]
            r["cycle_ms"] = round(PP * r["step_ms"], 1)
            r["requests_per_tick"] = round(n / PP, 2)
            r["microbatches_per_s"] = round(1000.0 / r["step_ms"], 2)
            r["wall_clock_tok_s"] = r.get("tok_s")
            r["tick_note"] = ("tick_ms = step_ms = one PP tick (one completed micro-batch of C/2 requests); cycle_ms = 2 ticks = the "
                              "per-request advance time; microbatches_per_s = completed micro-batches per second; wall_clock_tok_s = "
                              "generated tokens / window seconds")
        adm = (r.get("admission") or {}).get("sec")
        if None not in (c0[0], c1[0]) and adm:
            unc = (c1[0] - c0[0]) - (c1[1] - c0[1])
            r["prefill_uncached_tokens"] = int(unc)
            r["prefill_tok_s_uncached"] = round(unc / adm, 1)
            r["prefill_note"] = "admission.prefill_tok_s counts cached prompt tokens; prefill_tok_s_uncached does not (incl. a retry)"
        r["ttft_per_request"] = _ttfts(port, l0)
        if retained_before is not None:
            r["retained_usage_before"] = retained_before
        if a0 and a1 and a1["drafts"] > a0["drafts"]:
            r["accept_rate_per_position_incl_admission"] = {p: round((a1["pos"].get(p, 0) - a0["pos"].get(p, 0)) / (a1["drafts"] - a0["drafts"]), 3)
                                                            for p in sorted(a1["pos"])}
        return r




    # ---- prefix continuation (2-turn replay) and after an abort






    # ---- PP2 trace window: every rank's trace, stage overlap, idle, verify rows per micro-batch
    SCOPE_ROWS = re.compile(r"^execute_context_(\d+)\((\d+)\)_generation_(\d+)\((\d+)\)$")












    CAPTURE_SIZES = None
    ROUTING_FILE = OUT / "nb1_routing_ids.npz"   # NB3 reads it (dataset foysalemonshanto/e25-nb1-routing-ids after a run)






    def quality_gate(o, ref):
        """RC2's fp8_gate with the reference as a parameter (B1 vs RC2's recorded FP8 rows, B2 / B3 vs B1)."""
        vs = ((o.get("oracle") or {}).get("vs_" + ref) or {}).get("status")
        if (o.get("sampled") or {}).get("ok") is not True:
            return "FAIL_SAMPLED"
        if (o.get("probes") or {}).get("ok") is not True and not FAKE:
            return "FAIL_PROBES"
        orc = o.get("oracle") or {}
        if any(orc.get("errors") or []) or any(orc.get("garbage") or []) or vs == "FAIL_HIGH_MARGIN":
            return "FAIL"
        if orc.get("complete") is True and vs in CLEAN:
            return "PASS"
        return "INCONCLUSIVE"


    def flag_map(argv):
        m, a, i = {}, [str(x) for x in argv], 0
        while i < len(a):
            if a[i].startswith("--"):
                k, v = a[i], True
                if i + 1 < len(a) and not a[i + 1].startswith("--"):
                    v = a[i + 1]
                    i += 1
                m[k] = v
            i += 1
        return m


    def config_diff(argv, env, kv_bytes):
        """Effective flags (last occurrence wins) and env vs RC2's real FP8 boot."""
        ref, new = flag_map(RC2_FP8["argv_tail"]), flag_map(argv)
        skip = {"--port", "--served-model-name", "--host"}
        flags = {k: [ref.get(k), new.get(k)] for k in sorted(set(ref) | set(new)) if k not in skip and ref.get(k) != new.get(k)}
        keys = set(RC2_FP8["env"]) | {k for k in env if k.startswith(("VLLM_", "NCCL_", "KV_", "P2P", "SCALES", "MERLIN_"))}
        envd = {k: [RC2_FP8["env"].get(k), env.get(k)] for k in sorted(keys)
                if k not in ("VLLM_PORT", "MASTER_PORT") and RC2_FP8["env"].get(k) != env.get(k)}
        return {"flags": flags, "env": envd, "kv_bytes": [RC2_FP8["kv_bytes"], kv_bytes]}


    def boot_facts(s, o, name):
        t = s.log() or ""
        o["caps"] = server_caps(t, s.argv)
        o["pool"] = pool_facts(t)
        o["graphs"] = graph_facts(t)
        o["nccl"] = nccl_transport(t)
        o["workers"] = rpc_cache_info(s.port)
        o["host_after_ready"] = cgroup_snapshot(name + "_after_ready")
        env = dict((R["setup"].get("merlin_plans") or {}).get(name, {}).get("env_keys") or {})
        env.update(NB1_ENV.get(name) or {})
        o["config_diff"] = config_diff(s.argv, env, NB1_KV.get(name))
        return o
    save()


if not RERUN:
    # ==================================================================== CELL 7 — E25 NB4S: the arms B / S / QP / QD, the plan (NEW code)
    import importlib, base64, zlib
    NB4S_LIB_SRC = "\"\"\"E25 NB4S library (2026-11-01): which change removes the ~21 ms in-graph stall on stage 0 and speeds up decode?\n\nArms (each = B + exactly one change, run in this priority order): B (NB1 R2 B3 + profiler), S (CUDA_DEVICE_MAX_CONNECTIONS\n=32), QP (Q-pack: NB4_PPACK=1 on the nb4_ppack-patched tree), QD (Q-defer: NB4_PPDEFER=1 on the same patched tree).\n\nPure logic, stdlib only (embedded verbatim in the notebook and unit-tested locally / on the Py3.12 CPU kit):\n  - the arm plan and the never-do gate (env + argv), the launch check on the final env / argv;\n  - the worker env read-back (POST /collective_rpc nb4s_env) parser;\n  - the nb4_ppack patch sequencing (apply before the first Q arm, keep between QP and QD, revert at the end; a failed\n    apply makes every Q arm NOT_INTEGRATED without a boot);\n  - /metrics parsing with the iteration-token histogram buckets -> the micro-batch split of a steady window;\n  - a per-graph stall parser of the torch-profiler traces (largest in-graph gap of every FULL graph per stage: node index,\n    stream, the NCCL kernel that released it, the offset to the nearest pp_broadcast kernel end; stage-1 SendRecv time and\n    pp_broadcast send-side kernel durations; per-step request counts per parity from the scope names);\n  - a compact summary of nb4_timeline.analyze() (agent C's module, embedded verbatim, sha-checked);\n  - the speed comparison, the budget rule, the per-arm verdicts and the best arm.\nDefinitions used by the verdicts (all from the profiled 8k@8 window of each arm):\n  stall of a graph = the largest gap inside one FULL graph replay (>= FULL_MIN_NODES kernels) during which none of the\n  graph's own kernels runs; steady graphs = every replay except the first and the last of each rank (profiler edges).\n\"\"\"\nimport gzip\nimport json\nimport math\nimport re\nimport statistics\nfrom collections import Counter, defaultdict\nfrom pathlib import Path\n\nLIB_VERSION = \"nb4s_lib 2.0 (2026-11-01, arms B / S / QP / QD)\"\nFLAG = \"CUDA_DEVICE_MAX_CONNECTIONS\"\nENV_PACK, ENV_DEFER = \"NB4_PPACK\", \"NB4_PPDEFER\"           # = nb4_ppack.ENV_PACK / ENV_DEFER\nWATCHED = (FLAG, ENV_PACK, ENV_DEFER)                      # read back on every arm (expected value or absent)\nORDER = (\"B\", \"S\", \"QP\", \"QD\")                             # run order = priority when time is short\nQ_ARMS = (\"QP\", \"QD\")\nQ_LABEL = {\"QP\": \"Q-pack\", \"QD\": \"Q-defer\"}                # nb4_ppack.server_env / readback_label arm names\nSTALL_LT_MS = 1.0\nFIXED_SHARE = 0.95\nBASE_STALLED_SHARE_MAX = 0.5\nBASE_STALL_MIN_MS = 5.0\nREDUCED_FRACTION = 0.5\nSPEED_MIN = 0.02\nFULL_MIN_NODES = 500\nRELEASE_WINDOW_US = 200.0\nSTART_RESERVE_SEC = 300                                    # step(): an arm starts only with est_min x 60 + 300 s left\nBODY_RESERVE_SEC = 300                                     # body cap clipped to left - 300 s (teardown + analysis + verdict)\nHARD_STOP_MIN = 95\nCLEAN = (\"EXACT\", \"NEAR_TIE\")\nWINDOWS = (\"8k@8#1\", \"8k@8#2\", \"profile_8k@8\", \"40k@8\")    # the same windows in the same order in every arm\n\n# ------------------------------------------------------------------ never-do list (NB4_RESEARCH_folders \u00a72 item 9 + lead)\nNEVER_DO_ENV = {\n    \"NCCL_GRAPH_MIXING_SUPPORT\": lambda v: str(v).strip() == \"0\",          # unsafe: tp comm mixes eager prefill + graphs\n    \"NCCL_GRAPH_REGISTER\": lambda v: str(v).strip() == \"1\",                # deadlock risk (SGLang keeps 0)\n    \"NCCL_PROTO\": lambda v: \"ll128\" in str(v).lower(),                     # forced LL128: corruption risk\n    \"NCCL_P2P_DISABLE\": lambda v: str(v).strip() == \"0\",                   # P2P on\n    \"NCCL_P2P_LEVEL\": lambda v: True,                                      # P2P on\n    \"P2P\": lambda v: str(v).strip().lower() not in (\"off\", \"0\", \"false\", \"\"),\n    \"NCCL_SHM_USE_CUDA_MEMCPY\": lambda v: str(v).strip() == \"1\",           # slower; memcpy hangs in capture\n    \"NCCL_LAUNCH_ORDER_IMPLICIT\": lambda v: True,                          # not a fix (graphs research); never added\n    \"NCCL_MIN_CTAS\": lambda v: True, \"NCCL_MAX_CTAS\": lambda v: True,      # NCCL CTA tuning: measured negative\n    \"NCCL_MIN_NCHANNELS\": lambda v: True, \"NCCL_MAX_NCHANNELS\": lambda v: True, \"NCCL_NTHREADS\": lambda v: True,\n    \"COUNTERS\": lambda v: str(v).strip() == \"1\",                           # disables the fused QSA writer\n}\nNEVER_DO_ARGS = (\"--no-async-scheduling\", \"--no-enable-prefix-caching\", \"--enable-hc-sp\")\nNEVER_DO_ARG_VALUES = {\"--mamba-ssm-cache-dtype\": (\"bfloat16\",)}         # C3 SSM bf16: parked (0 capacity + B2 FAIL)\n\n\ndef never_do_violations(env, argv=()):\n    \"\"\"Every never-do item set in `env` (a dict) or `argv` (a list; the last occurrence of a flag wins).\"\"\"\n    bad = []\n    for k, pred in NEVER_DO_ENV.items():\n        if k in (env or {}) and env[k] is not None:\n            try:\n                hit = pred(env[k])\n            except Exception:\n                hit = True\n            if hit:\n                bad.append(f\"env {k}={env[k]}\")\n    for k in (env or {}):\n        if k.endswith(\"_COUNTERS\") and str(env[k]).strip() == \"1\":\n            bad.append(f\"env {k}={env[k]}\")\n    a = [str(x) for x in (argv or ())]\n    for f in NEVER_DO_ARGS:\n        if f in a:\n            bad.append(f\"argv {f}\")\n    for f, vals in NEVER_DO_ARG_VALUES.items():\n        idx = [i for i, x in enumerate(a) if x == f]\n        if idx and idx[-1] + 1 < len(a) and a[idx[-1] + 1] in vals:\n            bad.append(f\"argv {f} {a[idx[-1] + 1]}\")\n    return bad\n\n\n# ------------------------------------------------------------------ arm plan\ndef arm_plan(base_extra, base_env, kv_bytes, q_env=None, ports=(8011, 8021, 8031, 8041)):\n    \"\"\"B = NB1 B3 (base_extra / base_env / the B3 pin); S = B + CUDA_DEVICE_MAX_CONNECTIONS=32; QP / QD = B + the\n    nb4_ppack patch + NB4_PPACK=1 / NB4_PPDEFER=1 (q_env = {\"QP\": nb4_ppack.server_env(\"Q-pack\"), \"QD\": ...}).\n    Every arm: the same flags (profiler included), the same pin, the same windows in the same order.\"\"\"\n    q_env = q_env or {\"QP\": {ENV_PACK: \"1\"}, \"QD\": {ENV_DEFER: \"1\"}}\n    change = {\"B\": {}, \"S\": {FLAG: \"32\"}, \"QP\": dict(q_env[\"QP\"]), \"QD\": dict(q_env[\"QD\"])}\n    title = {\"B\": \"NB1 B3 config (FP8 KV, pin 3,553,580,524 B, text-only, #60490, MTP K3, seqs 8) + profiler\",\n             \"S\": \"B + CUDA_DEVICE_MAX_CONNECTIONS=32 (32 hardware work queues per device)\",\n             \"QP\": \"B + Q-pack (nb4_ppack patch, NB4_PPACK=1: one packed broadcast per step, sent after the drafts)\",\n             \"QD\": \"B + Q-defer (nb4_ppack patch, NB4_PPDEFER=1: the receive posted after the next forward launch)\"}\n    est = {\"B\": 22, \"S\": 18, \"QP\": 18, \"QD\": 18}            # the full minimum: launch + gates + body core + teardown\n    arms = {}\n    for i, k in enumerate(ORDER):\n        env = dict(base_env, **change[k])\n        arms[k] = {\"key\": k, \"name\": f\"nb4s_{k.lower()}\", \"port\": ports[i], \"extra\": list(base_extra), \"env\": env,\n                   \"change\": change[k], \"expect\": {w: env.get(w) for w in WATCHED}, \"kv_bytes\": int(kv_bytes),\n                   \"needs_patch\": k in Q_ARMS, \"q_label\": Q_LABEL.get(k), \"est_min\": est[k], \"cap_min\": 14 if k != \"B\" else 16,\n                   \"title\": title[k], \"flag_value\": env.get(FLAG)}\n    return arms\n\n\ndef check_arm_plan(arms):\n    \"\"\"Fail closed (raises ValueError): every arm free of never-do items; each non-B arm differs from B by exactly ONE\n    env key (its change) and nothing else (flags, pin); B sets none of the watched keys; QP / QD never carry the S env;\n    ports distinct; the order is B > S > QP > QD.\"\"\"\n    errs = []\n    b = arms[\"B\"]\n    if tuple(arms) != ORDER:\n        errs.append(f\"order {tuple(arms)} != {ORDER}\")\n    for k, a in arms.items():\n        v = never_do_violations(a[\"env\"], a[\"extra\"])\n        if v:\n            errs.append(f\"{k}: never-do {v}\")\n        if a[\"extra\"] != b[\"extra\"]:\n            errs.append(f\"{k}: flags differ from B\")\n        if a[\"kv_bytes\"] != b[\"kv_bytes\"]:\n            errs.append(f\"{k}: pin differs from B\")\n        diff = {x for x in set(a[\"env\"]) | set(b[\"env\"]) if a[\"env\"].get(x) != b[\"env\"].get(x)}\n        if k == \"B\":\n            if any(w in a[\"env\"] for w in WATCHED):\n                errs.append(\"B sets a watched key\")\n        elif len(diff) != 1 or diff != set(a[\"change\"]) or any(a[\"env\"].get(x) != v for x, v in a[\"change\"].items()):\n            errs.append(f\"{k}: env diff vs B is {sorted(diff)} (must be exactly {a['change']})\")\n        if k in Q_ARMS and FLAG in a[\"env\"]:\n            errs.append(f\"{k} carries the S env\")\n        if a[\"needs_patch\"] != (k in Q_ARMS):\n            errs.append(f\"{k}: needs_patch {a['needs_patch']}\")\n    if len({a[\"port\"] for a in arms.values()}) != len(arms):\n        errs.append(\"ports not distinct\")\n    if errs:\n        raise ValueError(\"ARM_PLAN_INVALID: \" + \"; \".join(errs))\n    return True\n\n\ndef launch_check(arm, env, argv):\n    \"\"\"At launch, on the FULL final env / argv of the server process: never-do items + every watched key equal to the\n    arm's expected value (absent when expected None). Fail closed.\"\"\"\n    bad = never_do_violations(env, argv)\n    for w, want in arm[\"expect\"].items():\n        have = env.get(w)\n        if have != want:\n            bad.append(f\"{arm['key']} launch env {w}={have!r}, expected {want!r}\")\n    return bad\n\n\n# ------------------------------------------------------------------ worker env read-back\ndef parse_env_readback(rpc, expect, n_workers=4):\n    \"\"\"rpc = {\"results\": [per-rank dict from nb4s_env]} or {\"error\": ...}; expect = {key: value or None (absent)}.\n    OK only when every one of n_workers distinct ranks answered and each reports exactly the expected values.\"\"\"\n    out = {\"expected\": dict(expect), \"ok\": False, \"definitive\": False}\n    if not isinstance(rpc, dict) or rpc.get(\"error\"):\n        out[\"why\"] = \"rpc error: \" + str((rpc or {}).get(\"error\") if isinstance(rpc, dict) else rpc)[:200]\n        return out\n    res = rpc.get(\"results\")\n    if not isinstance(res, list):\n        out[\"why\"] = \"no results list\"\n        return out\n    rows = []\n    for w in res:\n        w = w if isinstance(w, dict) else {}\n        envd = w.get(\"env\") if isinstance(w.get(\"env\"), dict) else {}\n        rows.append({\"rank\": w.get(\"rank\"), \"pid\": w.get(\"pid\"), \"values\": {k: envd.get(k) for k in expect},\n                     \"error\": w.get(\"error\")})\n    out[\"workers\"] = rows\n    ranks = [r[\"rank\"] for r in rows]\n    if len(rows) != n_workers:\n        out[\"why\"] = f\"{len(rows)} workers answered, expected {n_workers}\"\n    elif any(r[\"error\"] for r in rows):\n        out[\"why\"] = \"worker error: \" + str([r[\"error\"] for r in rows if r[\"error\"]])[:200]\n    elif len(set(ranks)) != n_workers or None in ranks:\n        out[\"why\"] = f\"ranks {ranks} not {n_workers} distinct\"\n    elif any(r[\"values\"] != dict(expect) for r in rows):\n        out[\"why\"] = f\"values {[r['values'] for r in rows]} != {dict(expect)}\"\n        out[\"definitive\"] = True                      # the workers answered: the env is really not as planned\n    else:\n        out[\"ok\"] = True\n        out[\"why\"] = f\"all {n_workers} workers: {dict(expect)}\"\n    return out\n\n\ndef parse_proc_environ(blobs, expect):\n    \"\"\"Side record: {pid: raw /proc/<pid>/environ bytes or None} of the engine processes -> each process's values.\"\"\"\n    vals = {}\n    for pid, raw in (blobs or {}).items():\n        if raw is None:\n            vals[str(pid)] = \"UNREADABLE\"\n            continue\n        d = {}\n        for item in (raw.decode(\"utf-8\", \"replace\") if isinstance(raw, bytes) else str(raw)).split(\"\\0\"):\n            if \"=\" in item:\n                k, v = item.split(\"=\", 1)\n                d[k] = v\n        vals[str(pid)] = {k: d.get(k) for k in expect}\n    readable = [v for v in vals.values() if v != \"UNREADABLE\"]\n    return {\"values\": vals, \"all_expected\": bool(readable) and all(v == dict(expect) for v in readable), \"readable\": len(readable)}\n\n\n# ------------------------------------------------------------------ nb4_ppack patch sequencing\nclass PatchSeq:\n    \"\"\"The nb4_ppack patch on the installed tree: applied right before the first Q arm, kept between QP and QD (only the\n    env changes), reverted (pre-shas verified by revert_fn) after the last Q arm or in finish(); a non-Q arm never runs on\n    the patched tree. A failed apply -> every Q arm NOT_INTEGRATED (no boot). apply_fn / revert_fn raise on any miss.\"\"\"\n\n    def __init__(self, apply_fn, revert_fn):\n        self.apply_fn, self.revert_fn = apply_fn, revert_fn\n        self.state, self.log, self.apply_rec, self.revert_rec, self.error = \"pristine\", [], None, None, None\n\n    def before_arm(self, arm):\n        \"\"\"(ok, why). Q arm: the tree must be patched (applies once). Non-Q arm: the tree must be pristine.\"\"\"\n        if arm.get(\"needs_patch\"):\n            if self.state == \"applied\":\n                return True, \"already applied\"\n            if self.state in (\"failed\", \"revert_failed\"):\n                return False, f\"NOT_INTEGRATED: patch {self.state}: {self.error}\"\n            try:\n                self.apply_rec = self.apply_fn()\n                self.state = \"applied\"\n                self.log.append((\"apply\", arm[\"key\"]))\n                return True, \"applied\"\n            except Exception as e:\n                self.state, self.error = \"failed\", f\"{type(e).__name__}: {e}\"[:500]\n                self.log.append((\"apply_failed\", arm[\"key\"]))\n                return False, \"NOT_INTEGRATED: \" + self.error\n        if self.state == \"applied\":\n            ok = self._revert(arm[\"key\"])\n            if not ok:\n                return False, \"tree not restored before a non-Q arm: \" + str(self.error)\n        return True, \"pristine\"\n\n    def _revert(self, tag):\n        try:\n            self.revert_rec = self.revert_fn()\n            self.state = \"reverted\"\n            self.log.append((\"revert\", tag))\n            return True\n        except Exception as e:\n            self.state, self.error = \"revert_failed\", f\"{type(e).__name__}: {e}\"[:500]\n            self.log.append((\"revert_failed\", tag))\n            return False\n\n    def finish(self):\n        if self.state == \"applied\":\n            self._revert(\"finish\")\n        return {\"state\": self.state, \"log\": self.log, \"error\": self.error}\n\n\n# ------------------------------------------------------------------ /metrics: the lab's aggregation + histogram buckets\n_PROM_RX = re.compile(r\"^([A-Za-z_:][A-Za-z0-9_:]*)(\\{[^}]*\\})?\\s+(\\S+)\")\nITER_BUCKET = \"vllm:iteration_tokens_total_bucket\"\n\n\ndef prom_parse(txt):\n    \"\"\"(agg, buckets): agg = exactly e23_lab.prom's dict (sum over labels + '@max'); buckets = {le (float): cumulative\n    count} of the iteration-token histogram (summed over label sets).\"\"\"\n    out, buckets = {}, {}\n    for line in txt.splitlines():\n        if not line or line.startswith(\"#\"):\n            continue\n        m = _PROM_RX.match(line)\n        if not m:\n            continue\n        try:\n            v = float(m.group(3))\n        except ValueError:\n            continue\n        if v != v:\n            continue\n        out[m.group(1)] = out.get(m.group(1), 0.0) + v\n        out[m.group(1) + \"@max\"] = max(out.get(m.group(1) + \"@max\", v), v)\n        if m.group(1) == ITER_BUCKET and m.group(2):\n            le = re.search(r'le=\"([^\"]+)\"', m.group(2))\n            if le:\n                try:\n                    k = float(le.group(1))\n                except ValueError:\n                    continue\n                buckets[k] = buckets.get(k, 0.0) + v\n    return out, buckets\n\n\ndef hist_delta(h0, h1):\n    \"\"\"Per-bucket (non-cumulative) step counts between two cumulative snapshots: [[lo, hi, count], ...].\"\"\"\n    if not h0 or not h1:\n        return None\n    les = sorted(set(h0) | set(h1))\n    cum = [(le, h1.get(le, 0.0) - h0.get(le, 0.0)) for le in les]\n    out, prev_le, prev_c = [], 0.0, 0.0\n    for le, c in cum:\n        out.append([prev_le, le, round(c - prev_c, 1)])\n        prev_le, prev_c = le, c\n    return out\n\n\ndef parity_from_hist(delta, n, pp=2, k=3):\n    \"\"\"Micro-batch split of a decode window from its iteration-token histogram: balanced = every step schedules\n    ceil(n / pp) x (1 + k) tokens (4 x 4 = 16 at 8 streams). BALANCED when >= 90 % of the steps fall in the bucket that\n    holds that count; IMBALANCED otherwise; UNRESOLVED when that bucket also holds the 2x count or there is no data.\"\"\"\n    if not delta:\n        return {\"label\": \"UNRESOLVED\", \"why\": \"no histogram\"}\n    t_bal = math.ceil(n / pp) * (1 + k)\n    tot = sum(c for _, _, c in delta if c > 0)\n    if tot <= 0:\n        return {\"label\": \"UNRESOLVED\", \"why\": \"no steps\", \"balanced_tokens\": t_bal}\n    hb = next(((lo, hi, c) for lo, hi, c in delta if lo < t_bal <= hi), None)\n    if hb is None:\n        return {\"label\": \"UNRESOLVED\", \"why\": f\"no bucket holds {t_bal}\", \"balanced_tokens\": t_bal}\n    if hb[0] < 2 * t_bal <= hb[1]:\n        return {\"label\": \"UNRESOLVED\", \"why\": f\"bucket ({hb[0]}, {hb[1]}] cannot separate {t_bal} from {2 * t_bal}\",\n                \"balanced_tokens\": t_bal}\n    share = hb[2] / tot\n    return {\"label\": \"BALANCED\" if share >= 0.9 else \"IMBALANCED\", \"share_at_balanced_bucket\": round(share, 3),\n            \"balanced_tokens\": t_bal, \"bucket\": [hb[0], hb[1]], \"steps\": int(tot),\n            \"dist\": [[lo, hi, c] for lo, hi, c in delta if c > 0][:12]}\n\n\n# ------------------------------------------------------------------ per-graph stall parser (torch-profiler traces)\ndef _open(p):\n    with (gzip.open if str(p).endswith(\".gz\") else open)(p, \"rt\", encoding=\"utf-8\") as fh:\n        return json.load(fh)\n\n\ndef _rank_of(name, tr, k):\n    m_pp, m_tp, m_r = re.search(r\"pp(\\d+)\", name), re.search(r\"_tp(\\d+)\", name), re.search(r\"rank[-_]?(\\d+)\", name)\n    di = tr.get(\"distributedInfo\") if isinstance(tr.get(\"distributedInfo\"), dict) else {}\n    rank = di.get(\"rank\") if isinstance(di.get(\"rank\"), int) else (int(m_r.group(1)) if m_r else k)\n    return rank, (int(m_pp.group(1)) if m_pp else rank // 2), (int(m_tp.group(1)) if m_tp else rank % 2)\n\n\ndef _a(e):\n    a = e.get(\"args\")\n    return a if isinstance(a, dict) else {}\n\n\nSCOPE_RX = re.compile(r\"^execute_context_(\\d+)\\((\\d+)\\)_generation_(\\d+)\\((\\d+)\\)\")\n\n\ndef rank_graphs(tr):\n    \"\"\"One rank: graph replays (kernels grouped by the cudaGraphLaunch correlation), NCCL kernels, decode scopes.\"\"\"\n    ev = [e for e in (tr.get(\"traceEvents\") or []) if e.get(\"ph\") == \"X\" and \"ts\" in e]\n    launches = {}\n    for e in ev:\n        if str(e.get(\"cat\", \"\")).lower() in (\"cuda_runtime\", \"cuda_driver\") and \"GraphLaunch\" in str(e.get(\"name\", \"\")):\n            c = _a(e).get(\"correlation\")\n            if c is not None:\n                launches[c] = e\n    groups, nccl = defaultdict(list), []\n    for e in ev:\n        if str(e.get(\"cat\", \"\")).lower() not in (\"kernel\", \"gpu_kernel\"):\n            continue\n        a = _a(e)\n        c = a.get(\"correlation\")\n        if c in launches:\n            groups[c].append(e)\n        if \"nccl\" in str(e.get(\"name\", \"\")).lower():\n            nccl.append({\"a\": float(e[\"ts\"]), \"b\": float(e[\"ts\"]) + float(e.get(\"dur\", 0.0)), \"name\": str(e.get(\"name\", \"\")).split(\"(\")[0],\n                         \"coll\": a.get(\"Collective name\"), \"dtype\": a.get(\"dtype\"), \"nelems\": a.get(\"In msg nelems\"),\n                         \"pg\": a.get(\"Process Group Description\"), \"group\": a.get(\"Process Group Ranks\"),\n                         \"stream\": a.get(\"stream\", e.get(\"tid\")), \"in_graph\": bool(a.get(\"graph id\"))})\n    nccl.sort(key=lambda d: d[\"b\"])\n    graphs = []\n    for c, ks in groups.items():\n        ks.sort(key=lambda e: float(e[\"ts\"]))\n        graphs.append({\"corr\": c, \"ks\": ks, \"n\": len(ks), \"start\": float(ks[0][\"ts\"]),\n                       \"end\": max(float(k[\"ts\"]) + float(k.get(\"dur\", 0.0)) for k in ks)})\n    graphs.sort(key=lambda g: g[\"start\"])\n    scopes = sorted((e for e in ev if e.get(\"cat\") == \"user_annotation\" and SCOPE_RX.match(str(e.get(\"name\", \"\")))),\n                    key=lambda e: float(e[\"ts\"]))\n    return graphs, nccl, scopes\n\n\ndef largest_gap(g, nccl):\n    \"\"\"The largest gap inside one graph replay (none of its own kernels running): node index (0-based, by start), the\n    stream / kernel after the gap, the releasing NCCL kernel (latest end within RELEASE_WINDOW_US before the gap end) and\n    the offset of the gap end to the nearest preceding pp_broadcast kernel end.\"\"\"\n    ks = g[\"ks\"]\n    cur = float(ks[0][\"ts\"]) + float(ks[0].get(\"dur\", 0.0))\n    best = (0.0, None, None, None)\n    for i in range(1, len(ks)):\n        t = float(ks[i][\"ts\"])\n        if t - cur > best[0]:\n            best = (t - cur, i, cur, t)\n        cur = max(cur, t + float(ks[i].get(\"dur\", 0.0)))\n    gap, idx, a, b = best\n    out = {\"nodes\": len(ks), \"gap_ms\": round(gap / 1000.0, 3), \"node_index\": idx}\n    if idx is None:\n        return out\n    k = ks[idx]\n    out.update(stream=_a(k).get(\"stream\", k.get(\"tid\")), kernel=str(k.get(\"name\", \"\")).split(\"(\")[0].replace(\"void \", \"\")[:60],\n               gap_start_ms_in_graph=round((a - g[\"start\"]) / 1000.0, 3))\n    if gap * 1e-3 >= STALL_LT_MS:\n        cand = [x for x in nccl if b - RELEASE_WINDOW_US <= x[\"b\"] <= b + 5.0]\n        if cand:\n            r = max(cand, key=lambda x: x[\"b\"])\n            out[\"released_by\"] = f\"{r['name']} {r['coll']} {r['dtype']}x{r['nelems']} {r['pg']}\"\n            out[\"release_lag_us\"] = round(b - r[\"b\"], 1)\n    ppb = [x[\"b\"] for x in nccl if x[\"pg\"] == \"pp_broadcast\" and x[\"b\"] <= b + 5.0]\n    if ppb:\n        out[\"offset_to_pp_broadcast_end_us\"] = round(b - max(ppb), 1)\n    return out\n\n\ndef _share_below(vals, lim):\n    return round(sum(1 for v in vals if v < lim) / len(vals), 3) if vals else None\n\n\ndef _med(xs):\n    xs = [x for x in xs if x is not None]\n    return round(statistics.median(xs), 3) if xs else None\n\n\ndef _stage_stall(rows_by_rank):\n    \"\"\"Aggregate per-graph rows (steady graphs only) of one stage's ranks.\"\"\"\n    gaps, nodes, rel, offs = [], Counter(), Counter(), []\n    for rows in rows_by_rank:\n        steady = rows[1:-1] if len(rows) > 2 else rows\n        for x in steady:\n            gaps.append(x[\"gap_ms\"])\n            if x[\"gap_ms\"] >= STALL_LT_MS:\n                nodes[x[\"node_index\"]] += 1\n                rel[x.get(\"released_by\")] += 1\n                if x.get(\"offset_to_pp_broadcast_end_us\") is not None:\n                    offs.append(x[\"offset_to_pp_broadcast_end_us\"])\n    return {\"graphs\": len(gaps), \"stall_ms_median\": _med(gaps),\n            \"stall_ms_mean\": round(statistics.mean(gaps), 3) if gaps else None,\n            \"share_below_1ms\": _share_below(gaps, STALL_LT_MS),\n            \"node_index_mode\": nodes.most_common(1)[0][0] if nodes else None, \"node_index_hist\": dict(nodes.most_common(5)),\n            \"released_by_mode\": rel.most_common(1)[0][0] if rel else None,\n            \"offset_to_pp_broadcast_end_us_median\": _med(offs)}\n\n\ndef graph_stalls(src, full_min=FULL_MIN_NODES):\n    \"\"\"Per-boot stall facts from the traces of the profiled window (a directory or a list of files): the stage-0 stall\n    (the question), the stage-1 stall (where Q-defer could move it), stage-1 SendRecv and pp_broadcast send kernels.\"\"\"\n    p = Path(src) if not isinstance(src, (list, tuple)) else None\n    files = sorted(p.rglob(\"*.pt.trace.json*\")) if p is not None and p.is_dir() else ([p] if p is not None else [Path(x) for x in src])\n    if not files:\n        return {\"error\": \"NO_TRACE_FILE\"}\n    ranks = {}\n    for k, f in enumerate(files):\n        tr = _open(f)\n        rank, pp, tp = _rank_of(f.name, tr, k)\n        graphs, nccl, scopes = rank_graphs(tr)\n        ranks[rank] = {\"pp\": pp, \"tp\": tp, \"graphs\": graphs, \"nccl\": nccl, \"scopes\": scopes, \"file\": f.name}\n    stage0 = min(r[\"pp\"] for r in ranks.values())\n    out = {\"files\": [r[\"file\"] for r in ranks.values()], \"by_rank\": {}}\n    rows_stage = defaultdict(list)\n    for rk in sorted(ranks):\n        r = ranks[rk]\n        tg = [g for g in r[\"graphs\"] if g[\"n\"] >= full_min]\n        rows = [largest_gap(g, r[\"nccl\"]) for g in tg]\n        rows_stage[r[\"pp\"]].append(rows)\n        steady = rows[1:-1] if len(rows) > 2 else rows\n        gv = [x[\"gap_ms\"] for x in steady]\n        rec = {\"stage\": r[\"pp\"], \"target_graphs\": len(tg), \"graph_nodes\": dict(Counter(g[\"n\"] for g in tg).most_common(3)),\n               \"small_graphs\": len(r[\"graphs\"]) - len(tg), \"stall_ms_median\": _med(gv), \"share_below_1ms\": _share_below(gv, STALL_LT_MS),\n               \"steady_graphs\": len(steady), \"first_graph_gap_ms\": rows[0][\"gap_ms\"] if rows else None,\n               \"node_index_mode\": Counter(x[\"node_index\"] for x in steady if x[\"gap_ms\"] >= STALL_LT_MS).most_common(3),\n               \"stream_mode\": Counter(str(x.get(\"stream\")) for x in steady if x[\"gap_ms\"] >= STALL_LT_MS).most_common(3),\n               \"kernel_after_gap\": Counter(x.get(\"kernel\") for x in steady if x[\"gap_ms\"] >= STALL_LT_MS).most_common(2),\n               \"released_by\": Counter(x.get(\"released_by\") for x in steady if x[\"gap_ms\"] >= STALL_LT_MS).most_common(3),\n               \"rows\": rows[:60]}\n        if len(tg) >= 2:\n            rec[\"graph_period_ms_median\"] = round(statistics.median([tg[i + 1][\"start\"] - tg[i][\"start\"] for i in range(len(tg) - 1)]) / 1000.0, 3)\n            lo, hi, nt = tg[0][\"start\"], tg[-1][\"start\"], len(tg) - 1\n            inwin = [x for x in r[\"nccl\"] if x[\"b\"] > lo and x[\"a\"] < hi]\n            sr = sum(min(x[\"b\"], hi) - max(x[\"a\"], lo) for x in inwin if \"SendRecv\" in x[\"name\"])\n            rec[\"sendrecv_ms_per_tick\"] = round(sr / 1000.0 / nt, 3)\n            pb = [x[\"b\"] - x[\"a\"] for x in inwin if x[\"pg\"] == \"pp_broadcast\"]\n            rec[\"pp_broadcast_kernels\"] = {\"per_tick\": round(len(pb) / nt, 2), \"ms_per_tick\": round(sum(pb) / 1000.0 / nt, 3),\n                                           \"median_us\": round(statistics.median(pb), 1) if pb else None,\n                                           \"max_ms\": round(max(pb) / 1000.0, 3) if pb else None}\n        gen = [int(SCOPE_RX.match(str(e.get(\"name\", \"\"))).group(3)) for e in r[\"scopes\"]]\n        rec[\"requests_by_parity\"] = {str(q): dict(Counter(gen[q::2])) for q in (0, 1)}\n        out[\"by_rank\"][rk] = rec\n    out[\"stage0\"] = _stage_stall(rows_stage[stage0])\n    s1 = [v for v in out[\"by_rank\"].values() if v[\"stage\"] != stage0]\n    out[\"stage1\"] = dict(_stage_stall([rr for st, lst in rows_stage.items() if st != stage0 for rr in lst]),\n                         sendrecv_ms_per_tick_mean=_med([v.get(\"sendrecv_ms_per_tick\") for v in s1]),\n                         pp_broadcast_send_ms_per_tick=_med([(v.get(\"pp_broadcast_kernels\") or {}).get(\"ms_per_tick\") for v in s1]),\n                         pp_broadcast_send_max_ms=max([(v.get(\"pp_broadcast_kernels\") or {}).get(\"max_ms\") or 0 for v in s1] or [0]))\n    ref = out[\"by_rank\"].get(min(rk for rk in ranks if ranks[rk][\"pp\"] == stage0), {})\n    out[\"parity\"] = parity_from_scopes(ref.get(\"requests_by_parity\"))\n    return out\n\n\ndef parity_from_scopes(par):\n    \"\"\"{\"0\": {n_requests: steps}, \"1\": {...}} -> BALANCED when both parities have requests and their modal counts differ\n    by <= 1 (8 streams: 4 + 4); IMBALANCED otherwise (e.g. 8 + 0, NB2 SEED2).\"\"\"\n    if not par:\n        return {\"label\": \"UNRESOLVED\", \"why\": \"no scopes\"}\n    mode = {}\n    for q in (\"0\", \"1\"):\n        c = {int(k): v for k, v in (par.get(q) or {}).items()}\n        mode[q] = max(c, key=lambda x: c[x]) if c else 0\n    lab = \"BALANCED\" if mode[\"0\"] > 0 and mode[\"1\"] > 0 and abs(mode[\"0\"] - mode[\"1\"]) <= 1 else \"IMBALANCED\"\n    return {\"label\": lab, \"modal_requests\": mode, \"by_parity\": par}\n\n\n# ------------------------------------------------------------------ nb4_timeline.analyze() -> the per-boot report fields\ndef _g(d, *ks):\n    for k in ks:\n        d = d.get(k) if isinstance(d, dict) else None\n    return d\n\n\ndef summarize_timeline(rep):\n    \"\"\"Compact per-boot fields from agent C's analyze() output; every field is read defensively (None when missing).\"\"\"\n    if not isinstance(rep, dict) or rep.get(\"error\"):\n        return {\"error\": (rep or {}).get(\"error\") if isinstance(rep, dict) else \"no report\"}\n    s = rep.get(\"summary\") or {}\n    out = {\"tick_ms_mean\": s.get(\"tick_ms_mean\"), \"tick_ms_median\": s.get(\"tick_ms_median\"),\n           \"steady_ticks\": s.get(\"steady_ticks\"), \"graph_modes_steady\": s.get(\"graph_modes\"),\n           \"graph_modes_by_rank\": rep.get(\"graph_modes\"), \"clock\": _g(rep, \"clock\", \"method\"), \"stages\": {}}\n    for st in (\"stage0\", \"stage1\"):\n        if isinstance(s.get(st), dict):\n            out[\"stages\"][st] = {c: _g(s, st, c, \"mean_ms\") for c in (\"compute\", \"copy\", \"in_graph_stall\", \"nccl_peer_wait\",\n                                                                       \"nccl_tp_skew\", \"nccl_transfer\", \"host_launch_gap\",\n                                                                       \"host_python_gap\", \"idle_no_host\")}\n            hs = [out[\"stages\"][st].get(c) for c in (\"host_launch_gap\", \"host_python_gap\", \"idle_no_host\")]\n            out[\"stages\"][st][\"host_total\"] = round(sum(x for x in hs if x is not None), 3) if any(x is not None for x in hs) else None\n    ticks = [t for t in (rep.get(\"ticks\") or []) if isinstance(t, dict)]\n    st_t = ticks[1:-1] if len(ticks) > 2 else ticks\n    sv = [_g(t, \"stall\", \"in_graph_stall_ms_ref_rank\") for t in st_t]\n    sv = [x for x in sv if isinstance(x, (int, float))]\n    out[\"tick_stall_ms_median\"] = round(statistics.median(sv), 3) if sv else None\n    out[\"tick_share_stall_below_1ms\"] = _share_below(sv, STALL_LT_MS)\n    by_rank = defaultdict(lambda: defaultdict(list))\n    for t in st_t:\n        for r, row in (t.get(\"by_rank\") or {}).items():\n            for c in (\"compute\", \"copy\", \"in_graph_stall\", \"nccl_peer_wait\", \"nccl_transfer\"):\n                if isinstance(row.get(c), (int, float)):\n                    by_rank[str(r)][c].append(row[c])\n            by_rank[str(r)][\"tick\"].append(t.get(\"tick_ms\"))\n    out[\"per_rank\"] = {}\n    for r, d in sorted(by_rank.items()):\n        m = {c: round(statistics.mean([x for x in v if x is not None]), 3) for c, v in d.items() if [x for x in v if x is not None]}\n        if \"tick\" in m and \"compute\" in m:\n            m[\"busy\"] = round(m[\"compute\"] + m.get(\"copy\", 0.0), 3)\n            m[\"idle\"] = round(m[\"tick\"] - m[\"busy\"], 3)\n        out[\"per_rank\"][r] = m\n    out[\"stalls\"] = rep.get(\"stalls\")\n    par = rep.get(\"parity\") or {}\n    out[\"parity_verdict\"] = par.get(\"verdict\") if isinstance(par, dict) else None\n    out[\"parity_requests\"] = {k: _g(v, \"n_hist_by_parity\") for k, v in ((par.get(\"stages\") or {}) if isinstance(par, dict) else {}).items()}\n    dep = rep.get(\"dependency\") or {}\n    out[\"dependency_verdict\"] = dep.get(\"verdict\") if isinstance(dep, dict) else None\n    out[\"ideal_tick\"] = s.get(\"ideal_tick\")\n    out[\"pipeline\"] = s.get(\"pipeline\")\n    out[\"stage1_idle_ms_mean\"] = s.get(\"stage1_idle_ms_mean\")\n    return out\n\n\n# ------------------------------------------------------------------ speed\ndef window_ok(w):\n    \"\"\"A window counts for speed only when STEADY, running == level, prefill done, 0 preemptions, a tok/s value, and its\n    micro-batch split BALANCED (an IMBALANCED / UNRESOLVED split is labelled and never compared).\"\"\"\n    if not isinstance(w, dict):\n        return False, \"missing\"\n    if w.get(\"status\") != \"STEADY\":\n        return False, f\"status {w.get('status')}\"\n    if w.get(\"running_eq_level\") is not True:\n        return False, \"running != level\"\n    if (w.get(\"preemptions\") or 0) != 0:\n        return False, \"preemptions\"\n    if not isinstance(w.get(\"tok_s\"), (int, float)) or w[\"tok_s\"] <= 0:\n        return False, \"no tok/s\"\n    lab = (w.get(\"parity\") or {}).get(\"label\")\n    if lab != \"BALANCED\":\n        return False, f\"parity {lab}\"\n    return True, \"ok\"\n\n\ndef speed_compare(b, s, keys=(\"8k@8#1\", \"8k@8#2\")):\n    \"\"\"b / s: {window key: window record}. Gain = mean(X) / mean(B) - 1 over the valid windows; B's spread = |w1 - w2| /\n    mean (needs both B windows valid). PASS when gain > max(spread, SPEED_MIN).\"\"\"\n    bv = {k: b.get(k) for k in keys if window_ok(b.get(k))[0]}\n    sv = {k: s.get(k) for k in keys if window_ok(s.get(k))[0]}\n    out = {\"b_valid\": sorted(bv), \"x_valid\": sorted(sv),\n           \"why_invalid\": {f\"{arm}:{k}\": window_ok(d.get(k))[1] for arm, d in ((\"B\", b), (\"X\", s)) for k in keys if not window_ok(d.get(k))[0]}}\n    if len(bv) < 2:\n        out.update(status=\"INCONCLUSIVE_B_SPREAD_UNKNOWN\", why=\"B needs both 8k@8 windows valid for its own spread\")\n        return out\n    if not sv:\n        out.update(status=\"INCONCLUSIVE_NO_X_WINDOW\")\n        return out\n    bt = [w[\"tok_s\"] for w in bv.values()]\n    st = [w[\"tok_s\"] for w in sv.values()]\n    bm, sm = statistics.mean(bt), statistics.mean(st)\n    spread = abs(bt[0] - bt[1]) / bm\n    gain = sm / bm - 1.0\n    thr = max(spread, SPEED_MIN)\n    out.update(b_tok_s=[round(x, 1) for x in bt], x_tok_s=[round(x, 1) for x in st], b_mean=round(bm, 1), x_mean=round(sm, 1),\n               b_spread=round(spread, 4), gain=round(gain, 4), threshold=round(thr, 4),\n               status=\"PASS\" if gain > thr else \"FAIL\",\n               b_tick_ms=[w.get(\"tick_ms\") for w in bv.values()], x_tick_ms=[w.get(\"tick_ms\") for w in sv.values()])\n    return out\n\n\ndef side_window(b, s, key=\"40k@8\"):\n    \"\"\"The 40k@8 window: reported (gain + validity), not gating.\"\"\"\n    ob, os_ = window_ok(b.get(key)), window_ok(s.get(key))\n    out = {\"b_ok\": ob[0], \"x_ok\": os_[0], \"why\": [ob[1], os_[1]]}\n    if ob[0] and os_[0]:\n        out[\"gain\"] = round(s[key][\"tok_s\"] / b[key][\"tok_s\"] - 1.0, 4)\n        out[\"tok_s\"] = [b[key][\"tok_s\"], s[key][\"tok_s\"]]\n        out[\"tick_ms\"] = [b[key].get(\"tick_ms\"), s[key].get(\"tick_ms\")]\n    return out\n\n\n# ------------------------------------------------------------------ budget\ndef arm_fits(left_sec, arm):\n    \"\"\"step()'s own rule: an arm starts only with its full minimum left: est_min x 60 + START_RESERVE_SEC.\"\"\"\n    return left_sec >= arm[\"est_min\"] * 60 + START_RESERVE_SEC\n\n\ndef body_cap_sec(cap_min, left_sec):\n    \"\"\"The body cap at body start: the arm's cap, clipped so teardown + analysis + verdict keep BODY_RESERVE_SEC.\"\"\"\n    return max(60.0, min(cap_min * 60.0, left_sec - BODY_RESERVE_SEC))\n\n\n# ------------------------------------------------------------------ verdicts\ndef stall_class(b_st, x_st, b_s1=None, x_s1=None):\n    \"\"\"STALL_FIXED / STALL_MOVED / STALL_REDUCED / NO_EFFECT from the per-graph stall facts (stage0 dicts; stage1 dicts\n    for the move-to-stage-1 check). A stage-0 fix with a NEW stage-1 stall (median >= BASE_STALL_MIN_MS where B had\n    none) is STALL_MOVED (the main Q-defer risk).\"\"\"\n    sh = x_st.get(\"share_below_1ms\")\n    if sh is None:\n        return \"INCONCLUSIVE_NO_TRACE\", \"no stage-0 graphs\"\n    b_s1, x_s1 = b_s1 or {}, x_s1 or {}\n    s1_new = ((x_s1.get(\"stall_ms_median\") or 0.0) >= BASE_STALL_MIN_MS and (b_s1.get(\"stall_ms_median\") or 0.0) < STALL_LT_MS)\n    if sh >= FIXED_SHARE:\n        if s1_new:\n            return \"STALL_MOVED\", f\"stage 0 fixed ({sh:.0%} < {STALL_LT_MS} ms) but stage 1 now stalls {x_s1.get('stall_ms_median')} ms (B {b_s1.get('stall_ms_median')})\"\n        return \"STALL_FIXED\", f\"{sh:.0%} of stage-0 graphs stall < {STALL_LT_MS} ms\"\n    moved_node = x_st.get(\"node_index_mode\") is not None and x_st.get(\"node_index_mode\") != b_st.get(\"node_index_mode\")\n    moved_rel = (x_st.get(\"released_by_mode\") or \"\").split(\" \")[:4] != (b_st.get(\"released_by_mode\") or \"\").split(\" \")[:4]\n    if moved_node or moved_rel or s1_new:\n        return \"STALL_MOVED\", (f\"stall at node {x_st.get('node_index_mode')} released by {x_st.get('released_by_mode')} vs B node \"\n                               f\"{b_st.get('node_index_mode')} released by {b_st.get('released_by_mode')}; stage-1 stall \"\n                               f\"{x_s1.get('stall_ms_median')} ms (B {b_s1.get('stall_ms_median')})\")\n    bm, sm = b_st.get(\"stall_ms_median\") or 0.0, x_st.get(\"stall_ms_median\") or 0.0\n    if bm and sm <= REDUCED_FRACTION * bm:\n        return \"STALL_REDUCED\", f\"same node; median stall {sm} ms vs B {bm} ms\"\n    return \"NO_EFFECT\", f\"same node {x_st.get('node_index_mode')}; median stall {sm} ms vs B {bm} ms\"\n\n\ndef _win(rec):\n    \"\"\"The arm's windows: rec[\"steady\"] in the notebook (so RC2's garbage-under-load gate sees them), rec[\"windows\"] accepted.\"\"\"\n    w = (rec or {}).get(\"steady\")\n    return w if isinstance(w, dict) else ((rec or {}).get(\"windows\") or {})\n\n\ndef base_check(B):\n    \"\"\"(ok, label, why): B must be clean (gate PASS, env as planned) and reproduce the stall with a balanced profile.\"\"\"\n    if not B or str(B.get(\"status\", \"\")).startswith(\"SKIPPED\") or B.get(\"status\") is None:\n        return False, \"INCONCLUSIVE_NOT_RUN\", f\"B {B.get('status') if B else None}\"\n    if B.get(\"quality_gate\") != \"PASS\":\n        return False, \"INCONCLUSIVE_BASE_GATE\", f\"B gate {B.get('quality_gate')} / status {B.get('status')}\"\n    if not (B.get(\"env_readback\") or {}).get(\"ok\"):\n        return False, \"INCONCLUSIVE_BASE_ENV\", str((B.get(\"env_readback\") or {}).get(\"why\"))\n    bst = (B.get(\"stall\") or {}).get(\"stage0\") or {}\n    if not bst.get(\"graphs\"):\n        return False, \"INCONCLUSIVE_NO_TRACE\", \"B has no stage-0 graphs\"\n    if not ((bst.get(\"share_below_1ms\") or 0) <= BASE_STALLED_SHARE_MAX and (bst.get(\"stall_ms_median\") or 0) >= BASE_STALL_MIN_MS):\n        return False, \"INCONCLUSIVE_BASE_NO_STALL\", (\"B did not reproduce the stall (profile parity \"\n                                                     f\"{((B.get('stall') or {}).get('parity') or {}).get('label')})\")\n    return True, \"OK\", \"B clean and stalled\"\n\n\ndef arm_verdict(B, X, key, base=None):\n    \"\"\"One change arm vs B. Order: not run / not integrated / not engaged -> correctness -> evidence -> stall -> speed.\"\"\"\n    base = base or base_check(B)\n    out = {\"arm\": key}\n    st = str((X or {}).get(\"status\") or \"\")\n    if not X or st.startswith(\"SKIPPED\") or not st:\n        out.update(verdict=\"SKIPPED_BUDGET\" if \"BUDGET\" in st else (\"NOT_INTEGRATED\" if (X or {}).get(\"not_integrated\") else\n                                                                    \"SKIPPED_DEPENDENCY\" if X else \"SKIPPED_BUDGET\"),\n                   why=(X or {}).get(\"why\") or \"not run\")\n        return out\n    if X.get(\"not_integrated\") or st == \"NOT_INTEGRATED\":\n        out.update(verdict=\"NOT_INTEGRATED\", why=X.get(\"why\") or (X.get(\"q_readback\") or {}).get(\"label\"))\n        return out\n    so = X.get(\"oracle_vs\")\n    if so == \"FAIL_HIGH_MARGIN\" or str(X.get(\"correctness\", \"\")).startswith(\"NO_GO\") or str(X.get(\"quality_gate\", \"\")).startswith(\"FAIL\"):\n        out.update(verdict=\"CORRECTNESS_FAIL\", why=f\"oracle vs B {so}, correctness {X.get('correctness')}, gate {X.get('quality_gate')}\")\n        return out\n    qr = X.get(\"q_readback\")\n    if key in Q_ARMS and (not isinstance(qr, dict) or qr.get(\"label\") != \"ENGAGED\"):\n        lab = (qr or {}).get(\"label\")\n        out.update(verdict=\"NOT_INTEGRATED\" if lab == \"NOT_INTEGRATED\" else \"NOT_ENGAGED\", why=f\"ppack read-back {lab}: {(qr or {}).get('detail')}\")\n        return out\n    if not (X.get(\"env_readback\") or {}).get(\"ok\"):\n        out.update(verdict=\"NOT_ENGAGED\", why=str((X.get(\"env_readback\") or {}).get(\"why\")))\n        return out\n    if so not in CLEAN:\n        out.update(verdict=\"INCONCLUSIVE_ORACLE\", why=f\"oracle vs B {so} (status {X.get('status')})\")\n        return out\n    if not base[0]:\n        out.update(verdict=base[1], why=base[2])\n        return out\n    if B.get(\"pin\") != X.get(\"pin\"):\n        out.update(verdict=\"INCONCLUSIVE_PIN_MISMATCH\", why=f\"pin B {B.get('pin')} vs {key} {X.get('pin')}\")\n        return out\n    bst, xst = (B.get(\"stall\") or {}).get(\"stage0\") or {}, (X.get(\"stall\") or {}).get(\"stage0\") or {}\n    if not xst.get(\"graphs\"):\n        out.update(verdict=\"INCONCLUSIVE_NO_TRACE\", why=f\"{key} has no stage-0 graphs\")\n        return out\n    xp = ((X.get(\"stall\") or {}).get(\"parity\") or {}).get(\"label\")\n    if xp != \"BALANCED\":\n        out.update(verdict=\"INCONCLUSIVE_IMBALANCED\", why=f\"{key} profiled window split {xp}: not comparable with B\")\n        return out\n    out[\"b_stall\"] = {k: bst.get(k) for k in (\"stall_ms_median\", \"share_below_1ms\", \"node_index_mode\", \"released_by_mode\")}\n    out[\"x_stall\"] = {k: xst.get(k) for k in (\"stall_ms_median\", \"share_below_1ms\", \"node_index_mode\", \"released_by_mode\")}\n    b1, x1 = (B.get(\"stall\") or {}).get(\"stage1\") or {}, (X.get(\"stall\") or {}).get(\"stage1\") or {}\n    out[\"stage1\"] = {\"b\": {k: b1.get(k) for k in (\"stall_ms_median\", \"sendrecv_ms_per_tick_mean\", \"pp_broadcast_send_ms_per_tick\")},\n                     \"x\": {k: x1.get(k) for k in (\"stall_ms_median\", \"sendrecv_ms_per_tick_mean\", \"pp_broadcast_send_ms_per_tick\")}}\n    cls, why = stall_class(bst, xst, b1, x1)\n    spd = speed_compare(_win(B), _win(X))\n    out[\"speed\"] = spd\n    out[\"side_40k\"] = side_window(_win(B), _win(X))\n    if cls == \"STALL_FIXED\":\n        out.update(verdict=\"STALL_FIXED_WIN\" if spd.get(\"status\") == \"PASS\" else \"STALL_FIXED_NO_SPEED\",\n                   why=why + f\"; speed {spd.get('status')} (gain {spd.get('gain')}, threshold {spd.get('threshold')})\")\n    else:\n        out.update(verdict=cls, why=why + f\"; speed {spd.get('status')} (gain {spd.get('gain')})\")\n    return out\n\n\nRANK = {\"STALL_FIXED_WIN\": 0, \"STALL_FIXED_NO_SPEED\": 1, \"STALL_REDUCED\": 2, \"STALL_MOVED\": 3}\n\n\ndef verdict(arms):\n    \"\"\"arms: {\"B\": rec, \"S\": rec, \"QP\": rec, \"QD\": rec} (missing = not run). Per-arm verdicts + the best arm: the best\n    verdict class (STALL_FIXED_WIN > STALL_FIXED_NO_SPEED > STALL_REDUCED > STALL_MOVED), then the highest 8k@8 gain.\"\"\"\n    B = arms.get(\"B\") or {}\n    base = base_check(B)\n    out = {\"lib\": LIB_VERSION, \"base\": {\"ok\": base[0], \"label\": base[1], \"why\": base[2]},\n           \"criteria\": {\"fixed\": f\">= {FIXED_SHARE:.0%} of the arm's steady stage-0 graphs stall < {STALL_LT_MS} ms (no new stage-1 stall)\",\n                        \"speed\": f\"8k@8 gain > max(B window-to-window spread, {SPEED_MIN:.0%})\", \"oracle\": \"vs B EXACT or NEAR_TIE\"},\n           \"arms\": {}}\n    for k in ORDER[1:]:\n        out[\"arms\"][k] = arm_verdict(B, arms.get(k), k, base)\n    cands = [(RANK[v[\"verdict\"]], -((v.get(\"speed\") or {}).get(\"gain\") or -9.0), k) for k, v in out[\"arms\"].items() if v[\"verdict\"] in RANK]\n    if cands:\n        best = min(cands)\n        out[\"best_arm\"] = best[2]\n        out[\"best_verdict\"] = out[\"arms\"][best[2]][\"verdict\"]\n    else:\n        out[\"best_arm\"], out[\"best_verdict\"] = None, (\"NO_ARM_FIXED\" if base[0] else base[1])\n    out[\"verdict\"] = f\"{out['best_arm']}:{out['best_verdict']}\" if out[\"best_arm\"] else out[\"best_verdict\"]\n    out[\"why\"] = \"; \".join(f\"{k} {v['verdict']}\" for k, v in out[\"arms\"].items())\n    return out\n"
    NB4S_LIB_SHA = "b7ab8ac65c496a2314310d805285d72a6ff5aa1697aee1993fddfc56c7fba9ff"
    TL_SHA = "43a0848def257e70565285b6e172566a0480dc523c76eab100ed536a5a575f5e"                        # agent C's nb4_timeline.py and agent B's nb4_ppack.py: verbatim, zlib + base64
    TL_SRC = zlib.decompress(base64.b64decode("eNq1fW1320ay5nf9Cixn5xiIKUbyTGbnytHc43E0iXcc22s7M3MPw4sFSUhi+BoCkqXY+u/7PFX9CoCUPMn6nEQE0F3dXV1dVV1dVd3r9V799Y9JPVuWi9mqTIpVsbitZlWSnj35qp88OXryp8Pj48Oj4+wk+XBZbstkui6rpL4sk6ouLsrDI6mbrM+TInnz5gmeJvPkYv2fBwcvVpur+kSK1uvt5PJws12fzxblNnl+uV2jTr0tJoCFqixz/fLl98mH9XZebtH6Gn35YrCpB1Jo8FO1Xg0HF7+Mkg3qb4vV/GnyHq3dSJunyR/lXZUNDt7V08VsnKxXi9skZbXky+Til9kGf9D5L5PxrConNX6g+/WsQnerrJ9U62RWJ9urVZXMVtVsWkqXVuu6HK/X8wR9WpWL5MOsvlxf1Ul5g14lm2IyBwaqwcHBN+X5bDWrZ2vUT4vFQnBCUMlyNtmu0eJ6NbWg+3i5WMz8S2lrW27W2zo7OThMni/Wk/kgObsut7cJMZZgPoBLDCohXib8DsRWyeMkHRdV+R6tvSpWtp1c6hwmXZ+25XmGwR8fHR0NkvfSLvp0VSwOEkzEeVXWybisP5TlSjHKptG9VfL92bN3P7w9+yY5x9wlk/ViATTOroUWihovlptFWXOqL0pU2LKzpYxgWS7HeE7fv0meLRZvy+nVpDQYRaMlcXC+3mI6gdFtvcL09zGryV+362I6KSrO1TuUeltOru1ESKWCmK2UDKtMCW25npaWoFDoUGhzOjs/B+WuQGx9jBdTVU7R8viWxWZbdHA6K1aD5JMi4FPy9Wny/OXr53/P379+mf/wLjn8S/Luu2cYfC6vk3S1xoC3W2JgvcqeJmuO+AOmVBo2eATmis1mMZPG0uev3749e/4eMP76X/nz1y9f4uHFP87eZVhyU0MBOhNJtdmWxZT1lSjK6QBU8Xcd+mRRVBVXzQoLjlP0qEq+ffPDiczAFSbg1KB9tV4dvnr+/KXB2VMU2Nzi68XmKseUTPDwpX1Ad58mq8lkkW82KBJUq9D3D5cgHyw8TKJSg4432cw2yjRkCpK0c8b0J/7wqZ9gogsQBspv3apS8Ns15qdKLrbrqw1QUKzYtJlc07manfPth91MUk9bX5LOvi2kDNvly3eToq45AL+6BXZG1L6fcb29c/wMHGyOlobAK0tta5IUaPRDsZ0m837S/f7xccZZ0ak0BCczlKSKoKM+ifwoGyTPMDRb71TWdHlTTjB7OVZpDfaSfwE0gf0UJDBL0CTuBZnUisuJtYS7HI6LenIJHM3qKuiaYup8tsV8GEx/iWaFChbF1WpyWU7BPm6T5z+8ef9C6Xkh7WW6xgs2JQtoQpbmMIfVHvZtJe3Wl6RZIvPsZrK4qsAZEmB8Oxtf2SEoWQJMXaxqFRiCascoFFeb7Wy9ndW3IJVpue3LKDB55QXegu6rqyV4jEoV1AbDTJLEEb/7V7hXZuzk7U9NWWAg/CeyokjcotAFEdSYrfKLbbG5zNF1YCKxuCiAu2+eHco3rtVFcfvITAHot0/5cTlbXdj5M+UoZJSDSAf72iHhgAdJ1z/PbA2XE0BoidIy+VCAzyyI/VsgZ7ycgc6nCdDOxTqmqOA8f8C0EcsJ1gpIf4MRYJzF6sMlZEW/u91ycDEQqZ6M7cp+qiuHg0ft6mrLGQGPqyk+QUtsRooIt1Cyp8KQKSKVxeBT/qFABYN6WcdES59QyDbZps5b37FHXfMKEmUUe8RuSlj8QSli2w4brDd5NS8/+LnuaPB93GARiKNGa0KlhBc1gbcV1ny7CQG3Wo/XmB40xr6qvIuhCj1bIChSLs6po2CelNODR9aHWJ7R6Pgy17WcXxSbREZP8gPs2XRRGtxRkKigeI5vulLRL6hDlo7RCBUkUrPhDZQNAVkLCwga3dxCE1p1NkqyJzgRXxMu4mlfyJHlVL+ToiEjLjchS0nfCHSniKw3Zh22/gmqQYPrxXUxxnipoMn/uFIn89P326vS4Ipdy1frnN2Xut24CrsIVc+g59b2cYrOnCRNgluBY2sJYZx4tWNBrS4oLoEUSMuKDPhqITLqxZvnGTmAXa4zTjkm61DaB5ksk/RisV5n0vQA0M8KzNFsZXiP8iVoKe+fvXyZf//iFbUWjGBJyQB4hmEGAtNIXYpmsH0sZbZaJylJDAjie+JxtkJbb89eQvk7y//54tU3r/9J0OPynGMwUnQhChm0aEG/UQctywLVvSt/dtgVLEmRDSZCGqXQ+FaGYbW3wgnHdFteJ0+wJi9KyIxvAKxaX20noiyVBTYV4Ihn3795/18Qd0VydFiv5yAYaSRFlXIrFJUfpUeZ0KURrxiUlKRmcfbs27O3qM6vV9NCevJS14BRzRv0+TT52w8vX1LPuikmNQiQkljnwawdwcNfTqWczMar19+cvUOjBvcrjLN6mrx5cfb87J8v3p0BVkXmDN0vhMMy777njH779tmb74ymYNoYl4v1h0YL2DMEihWX+PpqRe3TS58UatgaTb17973Q1awGD+RGDQpYuVFpC+ZbcULBuSnCksllsboonQoiMuBW+McE8DmJqZFluSh2GQmUe4tFMQYPxNpKyyd/yOUJ0/mHyySvIPPKfD5bTU9kealCKArOoRXcZqBQvh2iMhL1vNzUuvKVh6Cx1fg4dzpXmnE79+qvx6AWjHQ6m9RGl96uqQqKlvK915zI56lvpBvIidkv1KBXV7JlASm63YUQwVyZsQqhSwheU3We/D4xtQe6kf3HE7T+5s13oHsscdG7VlBd7Na54G5pasgVbLKkviTNSStFbX89tnClexAWi2oAbWEL9qPbVi33iOMD+UzLDWYOWAByKjPxFrxZcONbC/vQwn6qY8I6drwApTgvVuiWm0dVsKhVZp4X1CV8k8Qr0G6wRyUnnJZMKIYiQaZX+YuZpvWHFaBj8W+gtUMpvZotpnn55KscEAai5MpMQTuuZNdbK3E9kiHSQJADt8tiextqigH8Z/9L902z8xmnlYqlYs9R8nTG3Rxoit0rtpQmg4Ner3cwW3ILZswG9okGBfubNgb7e1vaX9664N7cVgfR3pnGAvPtuawjKLvT8ry4WtSkWS1MhNCeYQq+wePBQbQ5PU3+cDQ4Mu/enT17+/w7ff0V9/hHB5FMONWd/9FBm6efwtjDLzFLUTgHEJT582fv+Zj2lL30+kmP28f4SZXo4AmadC87+PvZ21dnL+8BkR28/eHV+xffn/ly5Mi52YawtDxPtyDBLYp/9/rd+6AsIK03LGW0k3PwD6LZVdwJ6HfRVqeyAgoL4kuRuPjz8xW2KKp+iwqBFUDeSK5ZbEXJ3xqOxQfVzC/FduMUnaV2+NXr9/nLZz+8ek6Ovi0HpDgUTLe9d7eovl2vsCQ//R+29+ldjWW9fFE9Lzb1FZv59G1Z60P5YnW+/oTdlnBnLWi+fI+l9KnXrYPYf9vem/WMRAeAz8xGrawI/pvyejYp+eslNP6z7Xa9/fSmLOfP/DNQpiPI3541B6GyU60VnyZX4SOqvXv++s1ZR63/bm6A0x+nj7MfU/2T5YEwj78A5ps3uaGvNlxnk/hkLRKfqLBjjNqlnK8br1iqR0vR4AU6/OKbMyGveBOouxinwJOkmgU2uWwNuF83JZTO86uVIcpo64AK7Xd1xztpGY3xbc9v3bpKkVJ3AYBcAu6wes6+ff32xZlZQ8qcZYWsdR3Hw3LQ3C7Ow9dtVqs9vmjsVHrNHWevsauQhgONHT3FIj3EP8PR54E1TLl6GugXwhMee+a/odXvJpOtNuxxhvM7QaWqjOX7IO2/Wq4yTHuK5sT96AELW7EpmYc8eroQu5P9ZJ6yLB5w2qM1amWYU9o7xzDANwyy5Ck//zDlA4gFw5vmYYXeBvqHfMXblfnrv4qsnJYUqL3+Pi6gJQU5OrPQqi8LKGbQWvIJdhhlR88vpqucVr9im5vW5R2rQ3uryWUXSkCXV6t5rmAnV7AurYRWJsVVVSy4zrnIeosnq/V2yV/cxZWgmtlif69N35fl9qLMj/90c/wn04bRQT/kV7LY5trc1RK6gSCNJOaaLW5Bv2yac0RkPqBJKZnLKLsQUy6XOZQQIEeQYn/uKLk2dKKP2tWa5MyfN9Bm9NUYrwQ7yz//hyATqiMUqty8O8o7eiLqpfIc88DS9XozN39z+VFsL5bFjaL+vDY/t+VPqpwA7ugAK8gJWLMWcu4NtsoiAd0/yO/cPrDotLw2LI+f2m+lLLqf2BU3PBo15iGViYWUrqplrhsWade/VV7FD4KTMbc80ATz8/VCmoS5H+Rmnzj/wrYLO8hWgz9XhTQhf9k7TOW6bM9sjrfSwBUU5jx+xwofVgVIs6MBMxFpDxOJozau3NxOzmSNjREFHZcC32EWwMkcgo5PRpnOyuvv3/zwPlCVHHsKWUF7sTbINKbF5gR3ronOGTFYizGlIwXrPoBea1h2zlOpdFUsS2O6rVRkw3QJcf1jirOq1e1yfQX1CmVgR52UP2YnJ4SG/6p6q3Wzdt3//rH64no9m/5YPbaltdS2hFIEq8BALJVp7+teBkKzT6k8mT5yx4ItRNg/9hfNtHo/wP673KZREzQEpelcDEM4J4DyLud7bhXNzrmrSjd8KXBZUJ5YlLTW06kgzlTe/bp/iah419gZFouLcoxTy7SSEyVsNWbVT9QAk2EB+9wowYkkuiBYENaazq4NBnjkCVE4kgf2mBXYaQXlC4qd7RzfcIBWnBzENmzQ5OqqDMsRrhpbUR4Pw8Pj0fB4FFcUeH/Z+dn0z3xDN8fuMy3dcWEUHOBIDuSd6qCjycNXQwU1LD0LPyxLP1fLdIxNcxHhAKVMrclitkmX/WSx7ieXs74ew1Snr2C0MYCwn1wqcqdPDVS1B2zMWdLS7haGCmQ0SP6vgvm/nAHXci5HyyN9tEfaUnDAPavBG/cnS+5LLmfE8GLtsWGGZOZ0RrwJkIH+ybezi8s61aY5ogzjPiZMfWV3P6/k6IpWgCMHCHIkxeiPsjbtmA1R8nWyKFfpUo8+l8PZCAsQLy9nvoOC3lP5eNAghXAczVll44V0mKfsq3RMLGZmnrWHj7EH7p52WSvpTT+5NfPF4fyE/47uG8qNDuUn83gbrAedSIOXGx0rWhj+xB+ml/L62L4+Drt7zsr7x2xIJapkIKI/BmRjUXksdK+Un/agidw2QBII7oajAMeGDW0M/mVIPHO0GGHOIzRcRje+feiKtOa6Z0W1x62g2gyLdI3yOzvPfzzK/akBbd6ENjc0OG5xH/vtL+2GmjOBAn1bPpgPPyjSgC903CiDxlgMhuNxu50x9vfz6O08Hqap3RpCq4M72Z7sS9MvVBBErE8FwpBf0utMJo6sSmWGPF4rRyIvlD1Z8uK6cvTxzFCEl0asqAY6w7zIPHHYdSE0I/XYozynW02epzwP6yeRoOGrwZJItdIq/mQ4VYttar2Rb0T4tjagSylr8UlXZBDyd9/KbyauF7BWAAsyHTBmgUJpADQdEuPoqdgA9bVyImIxpUVywAqkA34cUEkZ0FGGBdIenKd6mfJqFssEAvV9am+wz67Z7mnvqj4//DMKwrZ9ftnCA22dA/YxPb+0Yk9UonxVpfXW9LOGoaxZEzOPAgP4BqW9Dr+knhx/GZlR3kxo4k/f325KMTf1k38Uiyv93Z6cI9MRnnHCrEHlt74VHQ3HGag7P4XjRb05feIZFotCPduoJZ9f0cFpeXMixntzsg6bgjhSEVKSTjdHsNAcw8pxlA8Gg5wgnmTqX9FXFyloVMaONqVtzrG/JSqC0av7CtVVObmCxrrZiBELEyAaZT/6iOLRVwNq24DBfgwP89F/tgtPKXYs0hudU4R/vLO6wqxSxwwcn0xFdwkRLYBMWTn+PsUrBctHwGpCCD/ygKk2pJeSDjCIgbj5pMeZVOWo5PNcOy5OSFpys2kWxUcpKx358kvMnRLdZuYq1a1KdVjp97aOISBLDaSDmSEmEnmuDopptZ00CQivcHBlTg3WOHdItzifHTddFr/A4KkikY7U90k5H92G8KqCXdm4bhyyQZ7Usm5C+381kMbeGjXxI3t5knzscX5lo07k0qwhxjI1FJqlKC8IqHd35xXCGsZ4L4bjGZMhpuwbRnqFs6ksmH6zm7kh9yxhM+P+VKpkLWEZgLzpyzCytiiTnliZlN4oreRmXOfa84/zO1LOTRaLyLam0gYo/PEmGygHUC4KOIa3RAA2lp1yMH68MjWndnuzGcjcpr3m5PaUujaDWZWDElJD48NNoLJapKfnUX/OM5WiVDq1vVGgKZmlZvDuWFkWT4DADtlhSMbkErv4IQv40XL3xKLcPBnqOkm0tNLYiYFMSjsR+KS2E7YSkNxJJAgcAaLY9q6tbvwmwhKGkkNZ0NZ7WeURzFpVardcBc/plcL4vhepPkWDZAtDsjqPmAUj4YSZCMev0sIAvqCOqoDfGNfFb8V18S2LmXZi8BdNvhoJSgvUydgqvfCzZGSil4NxRTMg7sfCAV60e8A1bgYopXWIeuLKEcLjYtJXuZivoRLBLn1e51fVKc4GPf97vSqtT5FzHTe+jzQJrVfqpAy/Jh7XWhh+RwAzPcXYZGjIZKSYlAf4Pa9qoxEYZvUvLiG1lpSyCK45MDOvm0uUPT1Nev/qiTLfQ2UppHUr6kznQCj2s7YfiqM6H9/m9Hvsm9/1bCqrLzqHFa6YuQUp7f8rsnfQKGX6AtuR2J4yZx5i8fBYs2EWQXuWYA0E74fZa28Pwo13mw/6EQ0nXM7ljhIY59B0GD972cjyztKPUxR6V3xwTcKr0oB4rwfkj+m8vD1dFMvxtEjKk6QcEvsjh2BRwD8iCmBovngcXutvCJxGU8LX0ky5Bo6HPSdOAxL414Mwb8+twZD2dJT2YHXDhPo0IYfDwbH8H9ZQ8QTG3jz+T02DimyqQ/vpBaNomTYsQrg8+tET/qf0aoY2vaJtluvPEwSGS7zsG78rKwpsVNjqEL0Q4gNJcT8Zevpr0JStin4DIekeZ4Gm4XBz22W0U2EOiGr4JlDZ8ZjBN/hqEQwu/rKlDhBx+Iuite5YKjR5kc3QfPDR8klB2FZl+lZmfLu5y2AzOG6vUhwMk6bom9jQbdot7az9N/rePEA1MsXDI3K7d5CNQthYfIrEhSDqDSGIvOCiyHbNhXOFndsSH3sFxH9BHQF/x16ByKlMGEWjZVaXMxCcRp5g0pQMn3u3I6mU7T/TlKkMqndKZx5W1theBuX0+R7g6CuoNKj1AlaP6iIx7zM5Bfs5+A7fx/tgbi529vabsppsZxtdgXfZHoMdWVjX1PwuduO1vumVMlf5Gdv2IfzncmhhVrJlx4FFk6LbSRrp9iRa44vWWukFXpWyVMmLFi1e1Fi00jtv2oWhdB4IkTnhIOTLMFCa1uaOiSr/nLf4Z7umw5N49fBU8FqcAUNXaeO/r0YB+ALCIVlZgHoois9QX92BQKv0/4HrNnx5nL801Cg6PKLQRjzYTpuSpEuz+BwWbzgrtSDjBiUdDNm96kjqkp3T1UFP70DMEdZ3ckqeXe1YkDJ0cnVOOHoobiEdGz8ZvGcPNRdSLAbt2t+59P26/YxlG63cexbug9etW7r3r9y+50r7mNJdl6R0Pm6tvbYpEPnMcdIbTmaW3XeL/45Zah3VWSp2S/HfUl2actvSK07PcTjtvKuVcK2b2EA82B/Wd11iDbXDvLxPVYWzTYMPCg/U2s3DHOyfZaNQKYS+/eEGX7UGjzKBvu03gFVuuGmt3/GZPCEgBNguZ8et87lFeY7CqG3OurpO7/QzzNkH4fZyzgYn1AevVu4kRj6KV3pf2a7jUF5rvbrBS+OoGnCeeZWD/fU5nZavhcqwICSLTEnbWN0Phz2cHZ3MmodVq6Vhg9vdymuswG7v3UvN2ddIgsVoN0usJbdWy/Z6uYjPYdxr2TjMQ4ljtyzzfVuWwFV21AYqk2RpnCroxbyBBic6B3BGkOU6j5brvGu5tiVlIGQv5llbUXX+n06dXHbwElBbJ3LmpDD1lggQEszsr0Eb1oMcurfthOdsGMpJt2rNf1gUnR2WMVvvkPkqc24dgRtON0SstR0Qqx19wFIbhnoxmhue/AlHim1AuvrsTM+reMwBDk+6kPE5SN0xOKz6oUNLaxalx7sozLOQGa1Bw19Np4oMv2jm898Q7MGvwp7v1HLujiznwbpaLvVcR+WdFX/q8FS1JZ9nqBBcXqMym6qwgmyooBKKslU1lC2855hPdsutbg2oN6lv4L0Hn/hK4Mqxy9IfuvS1hMZYNb8/ke9w6N4J4Q+7G2a1brB/VLDiqixckrsqlWm7YKlbM1glisr+Ij4pFi6a6dZiLF9y462gX0ZiGhBx6eypO9sCquWsGE2xpUZTWAKZE5zqMmSsInScPJEuNPrQVWVH44aZfKBH8hXxki7n1mPqEBQJdwU6o8hRmdnrY/YbDutaU12jlvP72oKzlFag1xS5hLMgZgHcSnaRBZEi2gILZvuny4bGcXY9pODtfKEOoT4eDS8npbhSa6govDXt+6vVrtYYi8Y2pFE+pFZBahIzVlOTELN9UBkIp07SJ4mPg6Ntnr28IsX1IAJcHwUzeGH3B7+Lsm/4qK6SIaEM1TrRvayGspiI1Fllo7iCQFtNFGCCQyWIFVT0SG0DZpt6PrTcYxQcWIHpeE3ZvQpODIfibc1KkVK9yQO3QSkR2WURDDg1WnlgYN/pnMbtdG7K0z8t3D3N6EZzFAst9pF+UbZvlm9u8uhU6KM79uL5hPweWeOVvMKvkT0E0zMMfWG4r7yS3w1nZhddcULvGImZzGyghX21uc1chMXGvKUlLvNRFu4trHGNBtQAp9GfpC5FtL7twPS4N/I8U6wtBraaXprQJRBDC/Cn7JlJv+bdcBiLl6pL0lY7JG2w3Ro12zXBwOwcp9C48vNRSSgubfh5CuZJvhb2iFy0bOzVym4bkTXbq5FIWCOPIhyft2eDIX/woqdvwotxnH0FnguG33ADlbBmiY218ctpGLzMFD0al8xEEQKYr3zAcNodL8xCEpycBpHC63NpFevBdiaKQ3YypBFMTFhh9HHaCj624PyxnmugGftM/LmPRgFXZNq39rxUEUfLwFHL06cnqIr8WwOkdxQnCl1x2S354g3rvK3jcNwLeUKPw+npUYCDIF6BAVZlPL0AZz3rMRlz+VA2keFbqeTJY1/wNOyPJv5cunJoc7lIfHsQR+0SoASZFjTITlg/uxQ6C1/sQnmEw6jv9yJvdh6Mbl9p7QDmw+Dw+xf/OvumYwJ+K88BOZzWs30vS6lqVXr8zakys/GZJ9UbMdp+tMIhiER0+Yk+uexEn6LcRKKqC9MPT2vuhuzMKHJEV7b+OZysvO5QSHYfod97rhpsbToAi8nfHct1G+8cNBYG1u4xU1pvw00x2+aaYCstoT2XYzpisiZ9FBpB0LRKbU7/dBQ4LkhuNZuha02H8msJZY+Tmkn+C83h1p3d7MTnqkCQcJBgzGfNSJLHh65ncIwGJr5KrqrMpSAzCchM+jF7yNCGBThPWDNMA9V08y8L0qD8GrcWmjvbK8UbphieAC0jyxLLgpwQb3TtlYXxHQSKYuVN/b+CuI59tknOyw2UMoeBHUZKLfc4KBd4HaIL1rRxC1g30o1b6cbYmAqzEAtSY/fwL+l6522YkhwjZWqyr7BYBLZkXhEoxt2Sk3wqFQdLDR+kcwu2uLplSr5gXU0DhAF4T4VpA5ycnowrvD8UoBkd15+w3bD/hLG7+78Th6dCSjFHi6cUq8JbwlLyPunKKqdeZufnYlK1KQoGSoIpIVtV+N7J3zfvj9lE7FowxJTNRzKLh9IBZ19JZ1TeQUqiZR0RM9Y9vxxnUfjHpOn15Gwf3FNPVMUFnjM3CrX8N/R7xY/uT5UK8AbJLsmATcocfGEHBCMStLqazqbMjWM+YNU09E6L6HxzfBSCxvsha2xFPWPqxRGb4nCI5R2WgwDcV3vBPflMaP/RgvYfoOKHdNCqvMVidrHKRYRWkg1L1N2F57+amMLz3Hd0uwILxOI2mRWYQ9OnfOtMmsd8I5oH8x2zlRyfdKWzDLmlustK4ScnNjvZ1NO/TnrVzl+ZBpknT4IUlVQHnsZZJk98YjL5bGgAiWUQkc3gYJcAKqF4wyKVAYLR//VvyM7z2nTB8HVFmkmLookeJVEWWYHJHOlDaJizxPMXzXZqqJqLWb4zjtGGLObi7EZdBMJKyw+32A5Zf00uRfO2PA/fu/SgR/60RqCrQ5ak3oxcVH0JvzpZCs2xIJyWhzU4gu8UP4jrFyu2FTDTVSzm0AqbGhdnKEjGNYyqQINL4WiuiJ1kNddL7Ms8dh0eIhAKpNU4cKLCBbhsUBaBdKgY6cafapK+Gds3qrPiZ/P4SAGdyjfRczwomgyS/xGC4pvdh7E7TqB/R4JkKgYlI5NbqGT2OgloQC61NyalJv3w4NAjmRjVUgSKvosPDDZrFItULM4j+is6aF+ndWweW6dlm3XHkT8nyTJpsWRtcIZanNJF5XSsmvapqNvmvNZRbXl+Qi3W0NmWeJAVIPQaxODZT77t1U0QbuYCzcRK1SrrLFMahIvOtscg8g8xW9A0L1ZCi+lmCOcmIGQjRpR+cswwcftgPx4edx2v2wg9Ekah0WfWf0IGf7LT6UAXzy1Xlf4sxLCBPn3BNr1UG+0EAdTYybgNDhE8dleSHC1Rtmm4hzSmHm66sehkDIZj0S0aIc5Udq6pWBom511KCdgbgzV2g0bliGHFzOKQeeBQjb+pSJmWrKG6uz9LKOrrqYTG78q922tB64V5fns0/vzYjN7vWcVZuifbJj4pozFQGGW9LE0GZZs1unDp+DzL05EaqmdOs6zX0FV0GDwCkB+SocGIvNzZKc8l1h6JxujlbQ31xHtDDfDO+kRyl1BoYNI6+FvP6V44NQ3gVuTmkXrFeaNBW7EcAgpmXVKaYO3RpMe/TbPmWoymhsLl/Ey2TB0ZnsneHpacmhs3TU0NKd+dLMn2WrPNfWCMVzFG6gOT09zgu3f3W5klgoS5qmnZvExpvfBxh0HmobJvNZfgBT9z832aZuaJ1lo8eY3M5+jV5K1Amg0jtknGSRyDqC3oBY3GTmxcpy1hdqhhqtYvzY5DPkQ5vm3SWgn91CSVPuzdjYKt2jGc2PSEkl1WyPdRnAWa7JQllSM5Zz7TBPDBXB06nTZ5pxjHHBribK5pnM9WUt+7rLne7PlBLJ5D23tlv9z01IuhM/qPBhJFakJMtQilMsOptRyOAeJCsF9owfFVdSseOwzQxTZnYuJ36o1txZ4NdLSyiQttOgtp+r9TEwPPPmFQfdMim2fQ0ISHdwQUnhjEwBTaamNHxv/Qgb4MIetrO6ZQHRYSNAQFV3LmERYnMVgcrMRJ34Yx+YzCdgDyPSReM0qmAXZl6OLfoGiDVjv/2j22bFHhmuprDuDMJZc1hVto09o6EC19aaZDzlM65sIY2W0/NanupdvS1qYlfa+FDR5uXSWW07nSI5rOWeI6V1hafHMbJm34GJxX6bHvJDiuMm/kYKqRIsx+1DG3E4bZ7+5N1kwh5iAQxZEwaKQWswXti6wj15gtYzDVbycbcx26bTQWpSCzpYg2swVh7FzPjHqkJhXjKSJf9qeMYwWTaUQXXS2OdBHVZruBNdLL7YLGReuBRBnofBXHWGSp1q7O7/ZxR9kMw3r6vp2r27DoR7JvrkvPMxkArBy7Xq8lZy8tamh+IifSptHx1ZjZnJkCmukkdO/91NoJ5HD71HFlNGITMjJ5Ma4KKGcif3wRm+M5QEQr9V4Tf/abcqKdNeuwpqNCmri6W1H+knvxZhesb68j2YJozq7OyJu34DhqRYirH0DPwuYM3jx/yOt7GmON0e6xR4kIAyw0299VVflfs54cLe9vkqkLfT0dCnG+A047g0mtafsk163oVvKmkmwstGOFOVOZ1no1XX/g+1bWVK9S/Y1HLWZfLbclmEwXOCBUoCetFNxCzyY5e5CP29yxYTJxG1uR64PqAx35tzWHPFm66Lwuky/f2rzielrMOIYgFFMNOnSTG4ehFU5hsP4Eo9E92aAEh41MUEyX9LXFwD0ZoXY4erCDaCKMfRP7zLDdQySFkS79JDtN5kVNeebPcwr05M+ZNTKzXw6jNDiLYeMnSSczHkWZYyRlCxrc4T6hjviraRBR65zFx1zd0SvahGIsaKHz3sf58BHPux6N7nq81ue8l/AVtzJ4Jb8l0gEPN1JW4hb4Sa07fCe/BADbGWoshTVP9aKIb+8yaEW2Bg3RpaN2bmIyfbLjVFqCtxbN3+OFJFC8ML5kLDX32Jjf5wxnweXOC4xQDPkJqKIDlI3PMB6XfHhgcxKkYarhd7PW3Q4mkSPq6SZOg6M28xtnIO0nf3BZUCji0hsbj38jS+rGH53cVGr0CSKjRm3Q0ZGMwmMbUrVqBW3n5tjmN23VQtzTrtwR9kvp82LIkaZYI051rrBoct7OUp0SUUf3nA/Q24FOFIneRIbzWXsL2SCRRBtVWYYJOeCKsjVnpcgcFH7QYTH1lMubUST/+93rV4dyPQTLm/tiyBC5j7rK7S6xL00DOG8Y48+TMJn4xm5o+4aJ8hQPAJD+HbrLItFsOnol2rG5B8Pov7rzMPnJgWxJ9yHD5BxXcuEMsV5lXg5FmdMdq1Z70imRwqlJmwk8NHmBHOCjhKTWWyzCUtdhGePQILHYXvCjprfOZYH5S6igIy1KdIIpPWwdYX7slZI1GiacV6/z92+fPT/L//bi5Vnvzk8GlcGdB0tujyrBtsZG6M1Xor750BK+V8j1orIGxSDBgTtg8FkOpNFh20o1QrmsE7Qqpf5E5iPa6ugM3hoGUx3pBuFCHIcs0uzCaUcluC+iQKTbCKZ4SoUNwgpZHYUHQvLVgDCy+oM4dHqfTXweeuc6Ma3ihfdUHrX5xvmHVigVzPRxLTdZW+dCGsIMXEaNNizLLlIp5oH8xthpXz3/kOkxseMtWVeWPW0WJ81995NHPF6mc2dFr2ODWtKGRWS3pSaeS59jTGiHVQilOrHZ04ZhA/aka++0GQKrjA4F+vCtgO24nt7FUVTc3Ruw7RhdaxVxBpMvhr7Dw2rUbFHiGXgeRZ2KPVMBLGZuvQHDe2cN4+MFe0vSaTcGfta2fg4w8LMcfOlmEcj4OUCGbz5uQw5+fm5BiqoHvY9g1wFs/m50fxX0XP/ait3msn4SfW/Z3DLfy822OY7LoDELpsMMtA+EoQg9Xd1tIXamLfyARWpz6cFs1x/URw2riKoRDw+OcgmOpdKzWNNvRxePpKiUgv77JXVpiTq0zEMcc5nRsNPt2fvuG596U1ae9pa1RMTzijtVTS/EAwNPrWpBWazpjxPtbIAu5KRQxE6I2CDx/eOESf7v/Eq1DuqmbnYXL71g3TT8UYSNPYBTxySI+RjasY2G5/rzY3Une1w7kKZqGA8sEFFVRzzg7n978PHAPip3p60zVxbjjUvstzMFeuaTdcSD1osGLs+fNKSVReJDBZZG6K+5pWsUYqbZjhnooLuRrjKKMKXWQHo9iTyTGpyyEVOvGV9CJFg9YNR/GINm4u8GJxDbWGy0YkON6Zeh2Zs6laJ08o5yHoP4Za1wCkpZQna5qM2sdhUe+8L3kVyPxZRKHBDbjDHY+Q+OxTibjuJIh5fFlFkdywbaEKRBFjbBO8j3WMxHbIu4MF5Q/GqZnDjGRNReHYfKwa7PPL2RDWF00D/lrUxqRdi3hDz0x8n+cmymSRz7EoPYHuyAehQ3fxAhzO5ucu5uDO14WRBjzUuDPAw3c3NqmH4jFG10P+W04Go02g7ALlTt34HMoLUdcE0824OgCspzpshf0MwyzUOckd6kAGnlAcCQHWGGjdEvevdNAKRFtA7qXbCHWNhTCWfuFG8BLz3sFsGfY2QHzVVjTjc+Ns8glnKftBW7sbj1cBunQ/tQqI1Vgrv8eGmdLdH1fZVi89TwZhi9GXlzCF6PQtPV0Bh0hvaVePJo/mz36jOE6YP/tdKny6+on34SZbNjDXaYkswZFMT0T7sCLoxKpVg/4ggdGrwYB64YqyhWNDFG6HYqTNjCEkNDx6Ilcvr9Y8rvcVNupy87aUZcqoWlF5pYjG4WvnK78aylfqmP413Lk7Xt/ZKbBJVOP9QfniVFdGp2kw24Xvpb9xjxVrPO4h0aQFshydqDQKHWEOIYZdFWJZYckT3XNumn2GJs45KRlV0Ia458BtFfSaIdA4m83f+Y3T1oXEpGJ4mhxJ6xeWkQ8NKals38LBb2zj6l3OZ86M2KEi3trv/Td2zbEZ/cOmQvIGSwrHvI4WoFUpXCnkaC9dAKngxtbsyBGl0qae1RG9n/NetO6Xk/kzv9yAnz6XqS5/aGkW+Cjxl0kwEzMW9SSepwdDS6c6dSfjEanDgT6TfwMA7u89bkU/hhrKVTY0SxN9YeDb46PB58dRPGl0hR3K69ZrrZrYn9RZ4q3NGSlFMiJAwqIZ60DxKp0DLpyYGhFlBvO82I07Ik16GMck6/QUV7E0Xd+AqFFxHqEhEw+AoOjmwAPYng4fnYfhy52wm6GaK5bEZTarUQHdowq7rDgBlxSjim3kWOEo2vSmSZuQMsfGtI3W2p5dhAZCf3dMNubPEQNvZL8LWJZK0v6H4whJjdRayuDrdCMRSre+/cBcMuGGrjgRbOw1x8tVtaOjYWTouzg3f6KUvabW33CJqXgXH4DpzDxX6AdweftyXmwVz3brcfwKopl+XsOprkUQsV6N4lvLZhgFYNcTOp3ZZfNROcnoC6XfkJrSYGbSOs3Xpp9RW02T6A/Hc2/3cdvYSLjB+F2zShycOgkNtChF2MC3DrEnx1m6V922fBY7xx8x2xhGOVmWh7l8VzHUOMN8TzkAb9J8YrRTC8bbqqJbbclw38gTp2TVEDje/3t9KocLfPqSGWqQ9gerpFsGv/JuyKV0hrtw1o6NbWYe0iOHncW9tq1fvPJXWbWeX2KvfFItwSMKXIcdQUV0DQSHMX0coosJNftzc4LQbtWtmzGdrLuBr7FeG9eBWpXH+SNCn2oFyR1ub2xPsO4LYO4r3cjtGoblLLRX3Jkwv7Um4i89mK+9ql//tzXGoYcv9e5eOgXCAWgxfl4mn1C5Ybcu294WCsZA/+lPXwSLSAviFbPSnNBia6acHDzKlRB/PQxlKZsCtzVMs2l8FN37grF1MCj+INdG25OAWOqkGBUoJskZWI8ZK8dJuq1WqtMq9x23XfXQQ+YfSu7vaR8L/STCphs9JSwzHaXDLSl4gv7v6CCnojtp6NSo+VNyI2Epeh689j/hzby239ewRDQP9aLDTLqzi5mxOeNb3jiWC59qTcVE7dE2fdgAOHLscfA1nu6Ii7wx32q5D7P046S+4SAztM7Hc2RER3u+JV24gf4awbAlCfWx5PSjkIBuPr6pwCU7/9dezbXIZi0gYG9ki9lsaE+OpciMVVaOigaeFjk0N2BoOSwo298cZZU70hVDvcW49h6LmObEW6CY91iFY8R8dSeIClSW/JVP4D3yN2+U7IUVyH/DDovaajViei1lrqNTPc8GWu0INuyOuOboTFhdc7NKgLaAsGaMrMTge0benwoaTzkC5g6VnsqamtZa3jdO9r9oJjuK5836nHxRpc2jWXoCElnkMJH1PWq292hfHaQJjWSBnXL1xLuaxnsHLPrXHg/ZIhLMZt8Ht47U63xbnZSy4PL8FneQt6tjMYpoUpNipRvCazlLQYO+2CWUMmILJD/jKZjWGUWd9yRTpAXq1QfUezTm4Q/FOtRbZmk8dJsNJK7lBkrEchvQFP3orfznIt0bVatM+Ln8mhpaeznU0ukEWUTkC4Wd3LL6Ku564EwTVQgR3Cuok99PyPdSKFRzw84mRYDNu1FTXB1Fbvm9m2PbL220icgH4jwgfYWa+CGFAGQB+Ja0t24rG6onCWq9hB/P72dV/AhPQ07m3XwBuXYizzmZDM/JxqD34vF8kE/uJOllXGrRWFTG6zVDwfoS7S55EZV+De9R3MDGuoX8vK5jdaqXCTViibQWdUrXwjqljUa7M+pAWJyFPPWS9Mkfu5ssIdzlyqtBg3WeNjq264Ntz2UGNtreYiFZAyppQINIpmhuQGvDPbL3qtVQEu/lRC7KU7wem3cUFCP8u6EY3duS2n3AtINkwf6T2Y2mbAiB7Vz8cmg/MgLuXSqHH1S1/VisZtGGZnkfV3vA28Scx4ePrZCt+FV8N5HNkNE24jT3AiJ71RakrJjjOMk0223Fdo2xaCjI9XJWsFMtb5xHVBWjuGO+fOxZYx3o5+Gg1UM6Zd7iW9Aa/bhWPvR1QMnHn55Lx5e0Fr40msFxHRQ3R3NFx1ZILFBOhHtgcYPYap9DoKeizbMwXo6r9giUL14ZDoWTuKumEHq1+CPVvjqFm1ysCzuGRozawfGHPxgwe+YebPlcSumoyeZv7MczB79s2+EzObs9HZ6vvBrIhGNbu4yzpMC11uFy4JoKw8DGzXycG+nPM554zeBA4BH/HLJrvUnb6gZBKY1iXbjPHoyu4e3JgbqTCN6nNbBf38G42KOTq3+JG/sGqP3LWC4G+ROcd6QlgaDNwgGu9g/A2S5qp1Acvs1kXjs++49FKdAtScIMH0o44Jlh7mwuzN7MoV8FuX52UZp37hPmP5sHmWjQwDsKCWeSljpIbb+IkEMFJCJEl5gxOwhSaAakie3mce5/RMds8u4ZO2RI/xuTXSsTPpfUN4XFpz5g6fhBaVR44xoICvw/ODsHHLK3rvXrz69uVZjrCbb88amdpbYSJyYYkSdFV20PNlfIFUYGBc8TADHbqnM+9fv87/dvZP9Obszbte49YC5ja4JiF+PLrzTtOrIL2t+l1LscPdpe7pw+tXZ/mbZ29fINthswPw6OZgriXzwPGePsgFRZJjfUbT3nWWdRa+M4B+POhK43Zkc1OsuEzv6fVfn7189uo50icwhKX32Eg8nm36bgAOxVSWuXkLmBBmKNvnzNJq8YdXts1eEDNmislSt1WYrcsamkE29nVmRm+yP5AA3+XfvHj37Nu3Z2cnMo6+GYerEgSnrWs1IeOuU5Vo2MBpKhaDNskUQH/5E1JyJekXr0ujKXGTcsvrYnA5K5uorXadaKYiKBfrD8aW1skVegWvmaH6XJFzXcndM0gt7ToDnWXBICortU0xKNUFt61KKPgmSY4O5cTUJ6brbtIEnGI4UOHsLsAcK05NVBXydZhSp2K0kdhR2fqFW7XJ7QQxmb0d8Tf3neTShmc3Nm/Pnr1kKOrfnr1EclRf03bPMsfZ6lCjN9RCPEgYtRdxznm0G9I4PGwG1aTIfMo2Uynmx4CCoa3fiu2LY/Bks5WyDjg8dwRui6P5sHSfY3JV2OQVmdu6GATxamheGuMGJbvuLQ0GsxXMbyexNAlzQ5uxHZIdp7zjOPnHE5DNd2iAh8EkzStmO5Ry700KaCNF4GScvMdCAMIRVkNMn/qRGVIxAKY0xdVM3eVG8dRMSlwHKbyMKZRjMJfwueyLGircgptcFlOfNcLk9Ji2gyHH5UWxeppIElFJR7OnLbW/tpvy4CVZBJJqkppdGz4kZ1+whXVkieMs7t1VwfZLQ9OYdpafzYWUwQ7vnq1Q13aldXdQpzqvqTh37WraeYmkn0PZNCCubtT3UDPxF2qEcxALcbhmFCsaB/btuV8QJYZpEM8ndzr4ZucHxnWt0ty6huj0apqjh2LR+ALoxX7hTQHZPVGsRsM9D5NkBBqRy94w1IBL5/8r6GlEoIhq20/MJ58eJHzfCEIwLrL3ewBWdVio6ApVnSm/aCdS13AdnQpBUCcNZCEpfhgqNJ99vTsh7U7yc8TZIttRR9+CGEi9P+am4fDtjfY3Pu75xl4MR3KsOk7UQw+91ppq+R3uvGgmIMvOq2E6b+BiugRZcYrxG4vwG4fvqDgyQNdM9yrZNdcypHW332G8h0ewpnhU37iTzuY4FfLOwTFfMvSyt2fvXr/8h83iHKmwpmunLVXcVaeU6aioom5vwyJskHM8J4j8xStcztMLaPlrKLSq6u3toTT0NUPq9jXTe8D9m1I6SGcduNZ2m0rsYbJxqMVcHDKyrxWF3aS2PZtVdyasEdSWYEwefamfmx6sjbUjlzkSfzr83QfbOdM+xJe2mwD3dx0nMqLd5CL3c5X2/uQdF4k5ZBX0zUcFk7u0WPx27Rnvirg9hHT+6gbtXgW+n8Y2dT0JkxTn4XZGDhaEoZJ+mqeLsbnY6jM59Rk3n9aSTP8Io+5bJ2tCbPlJSEGTwS6PA/fl+hRLg303EudPdj3pcLswlCUmg6bjGccaEF9ruA/wowhBtZ3AA1gNB9fOgXd72GkvzSJtwu3w9XgI/babaVHMUIf0oNXwm/VqtjLXFbW6k/6K7hx0Cf7PghfaoPfegdTb5Toj6HRs6R50+TUKou5OBM4RcK+uwgXyR1LI9FqIRxkNnYGd9M/O9Tf2iC8nfmf7T5uATowIyHS04H20QSIk+vueECGFPB/CWc8c94K5VzOmPQAEyQUlhqmau6sJLwTGtQySatBngvm8qw7MjY92yXXeGRDeQNB934BN+1ps5BSbhjPczcoM0d/MMNeSIthcR7sDGFvLwqtvXQC6ZBWQy6e0Vc34dY40YHIlZJ/eMn+BRsAkNmz3uXGXmcx/TbtyiU03YoIbDYYnfzwa3Y+e8Bpf32DzztTM3TSc2zuLffu28Q2vHu1bYHIR6QPmZ58x+kFXRbgLbJuBIoq0k2CCzCvOC5WTxnSd3DOVTd+Sq2nB7GhMEBq3En4wbcm76RYGgW27rHnf0UZzHsKqzW+mJSc7fUnzqgP+ZQEpHQfQdGLLUvGeQbJIA7r1rpR4HfnbdxdE64Lke/nRwi1O35e5kjpvNcbqmQ80ZpxQ1UtarqGRBHVIFtcL/Vql3j3IzLlYnDJh7vENee+fM5fLzxC90WTCV9lvlpwVt32qX14CiwGzxqr3Ii7SHs/AbpE6kZycQSOBN8aEe920vPYMXRORlE++ylF00Cza15MiGoM1mammiEmnmJVpeSi2KMNgJNuTWtNAnbPzW+Np4Z0LtnVfzJF9uTy7eTDPCI7Gqbx5FdiaDGuI7CL/7p0x4UXVJztu7i3vvbmX+bZ2m4d02MOQx7ljbts7iDFdi5OOSHnBFAMFTnfcWxOfxvwG9+f8/0QFZx+DcRiwN7W2h9XfeYlQ44tijx+yhrxrXmX/K8imU8jFw4svTN32/rvhiJSnP04fZz+m+ifLvQtT48v/7PV3THUL28uO25/jW8fTst9x2WnrctP2hZE2ke22gUjmj61x3I2N1s/MeLsOGKjEj4123U7epPb4Gfb8eKobmsFBeMMv+nu9aLAPvdi73/TTYeGJXvAd3ezdspZpZoZasu9dzrqT7kMeMe+e+viRloOruvfcRzwXr5dpd+b964W7xn4u108C+uMkvM1gOXM39KJ0Fubi8Rab6HpbnaL4blpOFd590Ox6SGMUXLg6Cy9cnfkLV7u9ETXCyF29Oss0tLLzblVjQhjfdjH7+DKfTXgNgpppIteb05bZd3zL2OrQG8dxlhsFXlxcxN5oioWbKnQ0uXV+JoFfyMXFkGXVOcNLRXffjmSkiyNhAjtMM23eUPE+CjPh7blT2EZ0NTILdIC1uU0eBJdOv6VLLrAPLKezATSK8gF6zE7RcHCmpbulo7HXLTaS+3Ud3nCV9Z3v+m8tzHcKMLKeXaIkKihu1c1likEMdwupYF3bbcQ8drS+ZlTcuhbTYxhJzbUb6o6IaJa7JmtdfB/vAvR2xPwyxSHO+BqXeKpG6D2ua0ky6M6P45tW+kZLM7d8atZO5x/EvsWBKFnfnfwqAR3aaU8kalAjVfwlSil6468RkldHjyo94NeO6nG1sWX4pu09k9JU467JJPdXVz4Fu8FYYVBTpTO4+TTTjqh3ORHqdVDryxpmcnLeYeIe3TTnf36Wv8/I9Nedy098OXQ8Bj3+juZRx2VHQQx8EPo6M4l0jfthCGJPzoAg26xkEwTJC6SGn+Ku3plLlkITFZJFbNab1CVw44FW4OOihxGZvZ+ocuchf3/1+p+vev3P8j7zGVQIqmmF1YFk3djT9A7BlVFifXKz/SATlJc5u/ZdMRYbeZ1MJqRek8okqcDEJILSZesFO9qTC+E8Dza5Apps+WHDdhdMbYNUdQ3Bq0NsjWC4s5etMztA6NgdmBNQGVHgk3AjgxzeMEorlMSj9naJfbLegG4YjzaShZgY1rvLAYwJGaM+noI1S8bYbYf/z2+yYVdmKGwdk4B9Qq5vYGANXIe+L7bzKXf1wr29c43N1+puAKGv13gN/XsDV5C6cmEFYMXQsmQXRieSzSzMpPDSq/OV7Fc2xsvBpMYwgWdqT52HJTSPSvj9pfPX1o9McqduEI/0bqBHkGqpi1ex990x83jDigcfdOWtIjmvnbTcGmmZerjNK30euVA562WZ3FkXrtU4HECcTqNzIL0fV0Zqbde4ck/iS9IopS7E+bdvfjiUYETRvZixQtQqe+ULEoJqdt7QyfWkl8XOJ2bxBW4B6CyV3shopdwg1EuvhbUM535BBbOQQP2407v1ko/Xw0dybeGIzjp4iIidebojIw22cqcsFa4vFMpOupzuMF0o2tR9CfNLaaqlv/pPTRWU69KsN6ajhUFAJ8uylSgQ0k1lI+eOmIhc6P42YFYRchQvFsijGAhp1brK8QYnKBROv/k9k+Icaa2QqaKO6XzQzo8rEyKsGVA+qv3zURjhzbawrO0nl5MD759qWpSlXuvjioSBeqzdWj8mp0q7PF8LXJ8l2ncqSLrhx1LVF5J+PyBWdYfqoEzjrumzPgtflZTOLqMw4HVMCPD0yWP4UyKerfzrolJAykAD+ccq64U5CC4yWzZ53CbOFpDfCwtl0qguIIFlwfftE9j1J+mR/kDA5BMTns6ajXyRjYwVsVwLKOMT+ONde6jc2hBvcTaN7OEjbozawevK5uFyju5GgxsSM4yctA183JVF17acPMxfKMJEClT09TIXw9OzX4WZfYjphVPXNdtJykPKU116h+7ysEPJAbCvX3Emkod3rLNTQK4PABcgnXzsx5UtlNjE8Fgk0OCwqqHpmG/gq0+j7O8BI2rlLiFHYWx5S6pHkq/VmmGIoRjo5IjmHo6A9eobX5hcQjl7kOIt6xy+xiNrOnwO2FfwokRD6Jy0MFEgocSnY194tXXQQBhSrjU1XEl7brY1wlHDAM9dclIMApB7zZiUR6PIHJC6BjSmpUuredrdRCt49GMMKwg18giHR3qIoSBjWQNL+NKJJV8D2JnaefXYab9U6Sb9VH87X6LhhiMFO8fqXcsTdbo2rtbOhx4ZxECdfZti7Ev6imQ7pmbqFYHPcInh2L78rSDOVn5KaOQ4TdL96moWuv+2Nt8+e1Ex7pw1rwOwoevkiRhasnBpxirBU5pqnEVmN5Fvhcjt9I8i5R21AyqOoyvAzQxPfZm5tEHIRZdjT3NNH+hoayRJ59xFRjQhVwzhr/VGDfqaTTNLEj9VcCSZXi03gWe8NCkfeG1ElboyFdvxfjtm27k+sUGlBwdAai4HwHkuAjDHikKWhdwIPxvIc4uDl+3FdRaHmMkGjQfwWI7weBNXAWjxf8ypaZJbD5Bq5mt1qJnOtpxqBq9Ug8HgL8nw8JD9lEty+GPEN7ip8MkokNlsuLxBbr8nxu69lQRItj9M1mwNSzmB0IaYGw9r3K3u5I+2JdKHIE6iu5D4ZiAxg6ktGJkzBLIppxdZ+10KVrd5f8IvT0ZBk3Kt9f0N1pugOe0+0Rq0lt3THC4IyW3/fPQVH0ODFJ8NwUgjwe0yudhe0baRMzKvrb187gW6xYof1xtIydS+zgYfIAzKnOeDITW21kAuR3Tgt/UpU3OAJawRe3Nx2ruqzw//DGv0qvxAQjrlgsoO/h8//T1f")).decode("utf-8")      # (the notebook stays < 400 kB); sha-checked below
    PPACK_SHA = "6114f505322564170ce134eec91a5e51f16a328f64be45ba08a7faca0eec5127"
    PPACK_SRC = zlib.decompress(base64.b64decode("eNrdfXt348ax5//8FH05e46AEYkhqSfpy8RjW3a88/BEUrx7j6yDgCAoIaJABiAlK4q++/6qqhtoPEhpPM7d7I4TkWz0o7q6qrqqurrQbrdPBgfq4zf7KkhvM/Xn7jIIb9QbfJlGsygdqdV1pLJVcBV1eypOuldpsLymgvlcTaLrOJlyjU+fVBbcLufRtLta3ESJmqSLYBoG2aqjVvcLFSV33atgFU3VLP41ylrLYBVe41ecrBbqQ5TO40Td7Xk9r7eTKefu/fsPquftDdRskd646ueBul1Mo7lK10kSpcr5GRX8v5yd+D8P/A8/fXfy3j/9y8ePJ6fjvuu1WmeLdRpGytH9BtP9QbR3BEDSKFK9o7B/GBwN1ZgB5zL68i64uppHahk8zAE5AOM5Zl8pdBGpZH07idJMLdOoy7C7o5ZSd/P57Zu7/pt7QBmlb66W6zfLpb9exfPMWz4o/vfp05+CZDonVKZRGMV3kRoN+sPu4OigU2AJZUdH3b1+zyrzp2kwW2V41Bt0B/2jTku96N9VtPIB552vV8RfrFfLNXXUHwy7fRo3jZMr5QDWLP5HpKZRtHTV6PigO8T4V+livVSj4VG33+s1T5IXw5fF4IlGv0bhehX5skqY39GRctbLKVbcxyjTKMQDP43+vo4ynlF/eKi6f8DIM0C1h5H7e8Nj96UzjG6XqwcQYQQ4B4MelhZ0ch+kUzUP1kl4jdL9IXB2sL+PR3ESZ9e+qTEaHBwMXjqQYNBnkiawD4bHyimW8XD/qLyGh0fDxgU87h+7rdY50ds1EVxeJVOrxTR4UI5gHbgquhurLJ7MaaUWM8Nk0+guBmlzbSxjkNxk6qLXGVwqEJm66Hf2Lr9CsynxbBoFt62c/LwCLHmkFomK7qL0gbv5SiUYMF8hsA2NeBuH6aI7IYLvqHeosMd0/6pPjHu4ry4SFO/2Lw3zK40p5x8R2i2D6ZTLqI5L6IySKTFCDorj0kglLBNxXl2vFDAHTpdHjkuDDmhQyISLQUcll+jOAVcaIu8Qi4LC/haFkDKuvYb1QctjvOpT73v2lKh3Xrx8QsAM8AZ6zlS6uM/czd3rVcfUpPtlulguMpmDJh1IMBapCuyWLJLuHM3cXD40IMU5B8zSXYnVUK5JHnhm0YySERN3dbm9+yA2353bIE5cYsBX/Q4Q26Hp4xcAWKRTH1SRrEBG88VKnWPRQRPr6KLbv/TQc7hIsvUtzbgCidpVWqBwz5u5Hw83iqjlYpnpgYVHCdLSDBg4h6p4/BWIkZWiZZFJmJXy+EFOVyDoBAMAIwIbzUbjDLCDQKn/DGwxfyB5YubfVf2RilfqOsjUx58UWgZgwyUtexI+EBeZdTt3PUU8/vGbvsL/ZJN0EkweeD7a66hBX91mNC80ztR+d6jWmV7WvI8uAHk1AAlkBHAaAZJIBWoWzLPIHte5hjSDRItkebBlY+kiEuwuERWIW0ClSWFP1Bu7g53e//Tp7bfvxlh5YX+IFZIAIMAFdjrhgtsoy4hAIXkS9Vo5g3dA0Z6ronl0C6RnoIoLw/PJa4f5+5/K4kc0+ycmajMlFSktEpPX7y4FWcI/6j6NibdY29A9LIN0hVHDxZoGDFb8cAHOjZNgDoy+gUTQomy5ANgYzrGY3GWRmDGqqeX99QL7ez6xJIwMS9FTDZdTZ2O9qDnrEgVl6qePJy2LyQCnzTy06qtrEt0RLdtCpKkll43uFK8EzBtswRnx1iq+Wi9AFXdxdA/lg5rJioCyWfwxCwIjiofFHpyZ7olVTPcysYJhlBP9GoQrpmvUBUx3wRzsqCdnmFoFczSfPnBLUtZQ/dUeUWy2kCmAJ6ChSaVVfBsRnZL8CZKraOq1tNpo6Oy7k+9JKSuknN6yiMdkcnr5uZfVYk2CrGMGu49B3QDhFmtvD2OLSoC2Cm5AOULL11gccEkYZzGwAo6dCANB4mU30G0iaCzBip5lSbDMrhfQT0WeT9YroribLJ8ncMao+wi20HiiCtG0EOQEFtEDUDWB0JivoWgwAlLItEKc27sN9f7x5H+fV1UWx1aqRlIZA5W1lw4TC23cuQaUgd1jL/L0yndZCgAeGc2Wb576HgJpAjGQMb0JPy1FbnDHKMCQJPIGTAH2lsSTA56DRC3m1EBwIZiaxWmGHWOLWCeeCQBjPJ937ZayPhgVEtbIX+WQ9L2JMTcUe+oHtjnCYLlaYymTqOBCZ7q+vX0gpGE3CufrKVFPnPnhGiuQmO3Ol6bEjqCvEGPDSvgGDAqWeQAEIELa6AH9NZEuCUqApyVFxyzwHFsGcMjtwHXRSmwjY8nM4jnpBuukLKZo66M611kLLLhKIZChR0N8QqRH95BqqzQG6UUCGTg+WaiP3377HvJcs/IbtcL2BYxgqUBurFN1YA/dYVCUGp6AjP9f1ywkUYmAAS/MIfocAgfSKJosFjegm0mEQrSLb5eLlDS9FSsMn96ef/unkzP1mEbzEXCQRn52Hcjk5dstrVrawdzjWYyxp/Fs5j4pAjMmyRLPNTKI+fvq1WFvf9gD9GRbfjpAtYd5ROwaLJfzB+gFwLIv9d8orGg8qxamtNAruxCSIUpR6MOc7BABZpE/X1x1WB4RYfvzYBLNW+8XV2y2ZaRnTUGEtI+JgBArBhKkLRLqz+rxb9kieWpD2mBhhePBcytegGCVea12u90SbJEOcD2PJ+YntTTfF5n5BnLW37L1BNpfCELKSx6y1ixd3DJJoCe9DOoTfrZaH05O3//40f/2pw8ffiTFq61N11k0OTrs98P92Ww62O/1jyazQS84igbTcLgfHkYHbdP0/PTkhBoaK3faOzqa9aPeYdjH9ygKjvej2fRwf9abHO4d7PfaMBD805P31Ga7NYshTrfUrJiE3O+nU4blcBIN9/rTKJgdT6LoEDAfHPXDvfB4f3oUDQfhcDY4DA/7x2FvOA0nB8fB8WTveH8ym+0fHwWHhwPp66czxsjR7CjYO9zbm+yHw97ecDILw+PZ0SDqH+/PwqPpdDY8CqfDMBzMZscHx/1h/6h/FE2OD472YZsdD2Y8DQ1Y7yA6Ph4Gs0lwMJ0eAiPD4cHk6DgIgv7scNg7gBXbCya9AVB1fHjc6w2PojCczPajg+EAOAylLw1YfxL1osN+L5gN+weHswjdHA0O9mbR7PiwPwmn0/29vYM+gOoNgsNeeHi4Hw0PBuFBGEbhQX8w4Vl+eHv67uSUunuljF+GtTVQo95NR1t8LdjU0zggbcnJHS6ux2A296x7JCYXYQaei0n9oJ0F+7yW1Ga3yx0+cdZunXz82WfQxoaX8EOKuduinH+2W++o/O1f3hO69lq8qCR0yOzc2dkpwKr6oLAjVJ1EygkXt7dg0pcySKf1quz+eY4xXugegth9Zbt4Cj+X3kWwWMXy2Nq36H1GWchRXFac3K8wEoQglFesM+86NGDuhVKQzIODQ6W+lMeoUxBBudcv5bVWt9tVwZvtcqW1u7urJs9V+vpr1YUL71Dt4m+/r77+Wjw4r9QHEjxdNvjE4BGHpZAvpqQFMNQG3vig9peMDDEOTWdBmvIinEKXx3ZxdvZBO0C1smg8Mbr/fPWEGokauKNcBWSwYFdNyAKC9UOqJCiLPlq7MuQGNrc4+Cs1EZ1jnWEopgSCAc9FKwZRYGDdXc7TbA4D3CAnrdW16NHC1GIkat3mIcq1XVQQhVd6TCb7vhhxf89GZIEA/G6/GA1AjywrhX0zuvqlMd3IlumIvQJGFicOQNFGB5sR1mjCOL60Rd+LNLz2zkUFKmNQ0X/kQgT6l+SJoDXOdU/S+J04wQOfHVgj9SP9+Ia9t2ROJUsvmWLFoQNKvyMms4NDIrPDfmf/MCezNIL+mKha/yqe1Qu9IHlwXLH8cjh3f0eB3tr1SUqcnb8999+d/NcZ8OEI/toaeaC77LrdqRTC1KqWgTbu8jImW5/Io1oEKsmLxMoh50+1iGySSlmpfynSy06lrp7J+59+8N/StuDAVCQfODzP/Ef/NR/5Zw8t6T9afEMzPpvMGhEzaOtl2inoksm4o274E0AQLazWQP9Fuf7mX5cjPaN2WxZzHjxoLZOV/0Y3ih6dvSk3ZW+K7q7iRL0wTQArGXCXZQ9L2eNZ4bx/So8lH6bdH5wvb+GcEm80OZGqrgcC+a+Exb96pP9ybwFWyJ4GQ+XKswmbNLswHF/ndeSJ5h29MGZxLkbBpUcjOZVZup1KxWA00TWtGdZqTUb17kwli1h8ohaYDCLsRmS8dNTr1zf3TAUiBLiNreHbBYus9JNkF/UtEw2BhMc2d90eiS3RAavFU/xaZB4MTHwn93ObnsOHn0wdln70h8r33Ke8L0+8lA5gk7IlLNiVk9stbWCLwPNgAy8zOpUgxwkMppvoIRufp2uYrphysJ6vxpgmemf+4yeCERXCJZNZ6osIO6z3KbmVtp/rvSHWJmM9KPm1xHWTb4M0unkUZ8nOSol2BG+JuKwgjMkuX0bQ80JoVJ46o2Odc3YyhbTDsVAeDkko93Ges3eUS+X8wItOQ+B3ycJx2z5BaRfV3JblsJ/PvGD9q38dw5ROZI8GyYCHGXUjLQyYNDzPuyS55JpF3rppj2Sn/p59tetkTnqHtVW3++2vxAtNKLK6a/AWsCfBcqxZtS0lUjnkYtYO3Ex7cLXmKRKo2EqWdJwC3JIRTXKv6LDqBe2weguTWgQaRETD+FpDJU+n7dpzRRuw/WNiQ5C2q7UN8W1ZPbKLAt4Ro1dVXWPNjjXXgirnTvL5MZMToxbPuYiWYWwLovwJmBMP4xTcBCZ1LHsGvNpr29LmmTZi69RaucVXpj/etNjMGeewXfRAamRJthsriy1kVe+b6oxb0ua4NtxftBw+LUdTR7RVsn6wVbeqN2RvyAhun3AlvAECI96gAo98GsQ8Tlkz6aieNXMoSwQtrDgzh1EDXkk6l4tZKJFPpt2pP0AvgsmxhceN9RiJYwuFDTWlt/IyNVaTzqpL1FDVXpJxbZEaGtyMeaNf4oANmxto3WdXb0NN8mqCM5ar63HxtaGeHBzTRuDI1ypNl9epQqRMYE0Qqf8cq15lFdMghvjDFkK72kmaLlKLoSAxxBKzulJ8QsghCe/UH0AybZd0Zr2FQKbRhu7H01/9GWTR1CHgOkqXsRZn7d5lOW8awvHvJ8sL/fNS7Y5VnzcWxB3QzjLoH9hmZd6ez9Y8uCyhOztsFxUVCE3kwtYW06i8KWm1p8xMuolXMrUq6GvyzxQiVLzf4oyHCz0me5a85rQaX4kjJ15VO0wW9zjZ0keJyYOKghRnnALhyD6GoTPOjEFb2dKV0UFTHQtWmH9oLD6HdSsV8xpswjkVtT9fWgHtDG7+Iuzg/jqGvJ/GIs6IUHKlWI4SCAdv+AwLR+rmtMruT85LsGPKeU1x2osjjzRBcAqfK/Ccu30IBTivcVAspHCwz6SwB1IY1JQMoqJbEAKRKVTd7CEJfXHM+9eDqWM9BqF1cn4jZGiGsyfO5c+fbdcpp2YhExURsp6hJLbTyyeJDeeG9omoHByXOtxsfYw3QOetFo7sMjyk662TCVyIDQJ+Gt+OextFkkWBabScB2HEaOrYII03gjcuxYbUOLgUJ2DjU1x01kN8GHIqob08E7u3cX2Eptpl6uImVhGT56An5Dnsd/q9nDybJB8U+G9ytU9MQAlCgV5KCnrlMDYMEjkXomOUuViLIPeMDb+8U1gK5IjcomLUto3nyNHYyuUDN3W1wMENmdMU/uBtEi4ksTStOeU4D8vnU6EgkXil9X+R68jdKuOLMj5CEnIP19PA09E2DHQ1HscVb9NgcMxezf6wMyzJHIhG43Rkz3yUdpkBrCNsZjHS6hcwwuh4EhsD2fPk9YOUX8zs3uTU/1Qk7ZmOZJJfwBiUuIhJfxqtwCXBBL7umovOijBM/GBl9HDIO7MxVLZbC4VeWUBebtM26PS3olRtJ6XCAvOaFtyiGnOebUHWqXvwOvUZlqR37gQZ28Tm5X6PLyIIxGASQRzvG4WkTK/6ZBsycEWhEcSLvy7XjlshzdoGQxvWNYwVxGc57hcwbe4K59BdOQFn9p2sZ2SgsK4BZOYRiJXuOFSHrDT7mNxlo3TKQQCMstwW3cz/ZMIYAWAWj0UAKDDrbN6rNsiE37xodbRvDb2rLowrZxu9486e2t1HLGv/aFhTPtzyT47iEasNW/fnzX5UD32VrjwdwLR1usamfqW6dLjzksML0VjRmsMk+PhiksdQuNyPdlYa/5zojaLlw6hkL13VP0f/7ozYyc3TC1S/3FAK32KJ7O/YEC3cz5ts0Tb30WZQxvh/R+ICxmT3OuWB3Bw/+VxKZFq2qi0DrLaCFd91UdNa2K11zHo3VmpCJjb790Yn6Bhmv7+uht3ZobscW9fh0L0VqQwQCEV/dcmg1c3CI2Vi1VbmRC4qxfMVjueaoMp9GFu0361m6Kh83F3RQO6DTJMtGUNtS2Lc5MTVZA1Xl4B3iNraejheXUbwUhTVP1Pk7H6pyCl1QP5zOu7m4fkQp0E9Lx1f4I+cYMDOWT0so3Gu4h/uN5k+W9V6o7aJwdBRPp0ylM90CMLC90+e/SoKkmmhcAswSeLN4D0kRSmYewhFb5hUXXDW6zi9jtlMf9Wc589B7d2NC4tA6S3OFfoHpRNWEJtNAixoObxxtsSzd8Q+qvTDPJFPXYZX/zFWpd8UI6bHK2po64x/jxq8SnXeqVdiqWFxlHR+G2fs1Vft5haz9iP7150a5Agm04/K8KI8GT+a1X9q6LeRorxwsXzw7WFqq8A4kGpmyCpvfNFOu/tFO+0W1y0Ih3iiUsd2upQOghu2Jct6quxKJfu1eoa64Tz9M7cVxDDaQdcmTjs3CLUcLm8AWkw1YOM5VJV9cOxVGn+G4Wf2l9JexL2AkVg22bXc57ehOl3MbD7SWOHrTTQMaB9/nzhCmac0fqwOWmWKsoJvajdtkqL9fsn+Rr1TddwBcdWbN/b28G+ywfkd+p9G62/aXOiYw+KKTYbtZaN4LqSuNmm+WOrWyUULX0u05rIT4z4nim243BcIWF2/ELDVfakZPZ8p90SUE8lM40yHSU+LBk1sxEuZpaEoH8UJixwRjysjcuFGxtkoUimMpi5RjWdho46/QXR2ypKpJIpGVoySVa/mnGiox7IYId/zsiz+aLv+7PB+ZlAx40gc022i3KfCrnS6WdGlk/6iP3PPInvB9QqKMaGLGgk7CPKLGWURrz28n4BhkAuC8O4qi0wSrMPeLGid8GdfJejjIkivulRw+W9ZeQMzdF5Ui84SKj74mrOq/LxGHJ0G2CtdWjF+4yaHVvNBdtl11Oyme2fumZRutppLJ6PabRITNyDXO/haSZMHaMNNmzaHmzWdR+VXGLV3/ZkjKysSzuqNIvpGz3W+9XxM+yOJL52GuME5ttC6ZJGOWDWj7kY2fzCbW7/L3P7JxHUbBIEROSTUvoGzySx3KmEafH9CLrXxhKdN987gip4FqcQ2i7Tn00k+zSrzum0hm6OjcuDY5+gj5SOxqsr3f1X7eM7D+mIT/Hc2wxv29c/fcX+fXXcDKHJKPt6wBPZ9S8dtxmmTxrF5pWougaxTJqxO9WyvMfa0GT+WgvmiyW87ay0BReEulZJ+ZQtqEFwins9t116hDEwW0wfvOdx8Fr02+lB+T7KtuVS2QTWwl6MCw97gv5F1qtT2L2CizwfKoPJfAk6FgcpyuiYyG0OO/lCLONrQ+fOEUCLRzVU2A7OlUZ22t9StEdyGym5z8ecvchVdX77Y/xIhvk0K5l5CHVPS5CGtM9nnbwn5OJ/dEnS8KbTkBRT88vE2maqsDjccsPPVFPtuR11FNVE29RCcCmXy0o0l1r1SuYT3cUXWbYwsKoXx1Gs1xvR0GvwTZtwSldcNn9LOOS5v9yWzp9DKN1gfWkWP6cYXlojuP/ItmQ1u0Ybbl2UbyIFOeEvPyKtIZjPubOCjC+tJYsuL7soh2RyUXwry+ap0a34qd+Gv7Gv1tcO2PJ54s3lXdR6ilaVkb7mG77jP9ERu97ijwysRnUTuxZQuQxT2VrULKxqzFL71bLxlxYyLL18U5bgl0pEuZhAVuC1ca23xHeEN91x/v+ut5cutfCv1h09/4buRp3Inu5StZyQ0XFiCdIVAk10RAVgJw6+nnsAoTpFgqpktOGdBiWzL1Oo2X2j90rvZjRdav/SO9uYLrZXr75svtVYrSgxYj+8c8mc9+KMhAISIncIp1sC7TrKBSEvcSGYT2jwqNHUO0lZ1/f/jQg4yQIAmcwUD6G3WyeDIuZYFf8F2tumueVCTdSUCsW60NvJcAcNGT5BcRnRbzbnjNM4Mp9/cUXhygq0Eh3PJwmRbcao4buiuFGEGIXUV+VFY9OZbvTXnnKuO0SlBKPRxcMAxYfjcs2M/c+JoWNum6IdP709wAgn087UsSuAV+sztdPspCrKoXb0mVUJMORVNUxBZM23k11PyZC0viHj//IwE1T6N9GrwUjlbxdHub6I33ukrwXqlYFl0wk73ViNb4W63X7uUptPnjGQjMSlacMdQknaMSPpSMgs6WOVEFPxFUj1IGTWBe0hSd6C+JL/gAqmfp4aQMq7/1Gq9/fTp/Y8np/7Z6bd632qR5iO5W3QGGGeFK1sdVaTDZLXmTNLB6DpdyhLDzWJKrYPkNrP1P/5Bd8/hiJwRn490Yha6gEpXwCjviyS34cSbt2sQggQU0CEmn4vyDUJ6KiniWJv9mdJZMZ176j2nftH3HXgjIz+yul4nN7KzRuzLgTB/Q3L6GncIkNtTzijEl4/rA86Y87hR/pqDPIuN55qYaFhLZGECYi/D5FacbsaRu5X0nAajoJY16YEX8NDITXCt28wpWkowV2teEAhoY55QbAjy9JAL02l//XW7wuy3HBHvMYactE3iwvlluus6fxx1+Iv7R/XLbq0IHXXQeVmgaa3vti5ORJoUOHbaE9wOZIQK9kZ8HXWeXIyOe5flXjUK6O7qrce2o9N3Xb4+lhcg3x2wgru/QNVlqTXj0VzAQVdF39FcwmFrooaggC+e4jXaiq7idenPbhVzaHoxuDRd27jY0nNpNX75pdpnHU87vMXeMy2DgOksGR54Spa0I3NjqmNle72kO4zRVEthvRpcqRilPoJoOHRzB0zFtXUHC9pMIEg1AfZy6uM5gAd9HL102NlHyKoMFNPmSBUpAaJNkrH6T+r1mYnP2pRAY66vNDClYPqMhkfu9snabCjYHzeywFMX1HNckAAgxIFrRLlJey3bOhAOItjLgCCtJuwGVAcVkGMUH/3RZZXMUYuat1W3XSd2nuMf0EOUOACJSZNAg2WAs/Rs1LiPNyDASLQ8IipHQEzBqE8jYOJidNi7/I/0qUFTieWSWrU4x0jtqT2v3YZ5AcuG2jPXXtG8S0yPieLZtW1aT0zHdPREXUoGro4WEPAGPGTqkbu3Zyv0GbcsXard9v6G+E+HqSInCkiVFu9BnBYMu6XZhSr7j+Rq5CoiYEe2nML2cU84mCqnG3QmajfsTMk879LnLkoggnZ2d5jbd7o7OouYbpNfiFmw6nghZMWzZ4cU3/v+F8j4YgRq/BLxT6KeJP0fXS38rYKvv3a81y6Lf7pE6Z39d2wCFu3NGMrHQvQ/qd3HYmd4AoD5T+RDaFfkskGGJenpFnSV4K0BIf8FrP7o8mWddbd0ttvcWRZtbGK2ljp5i4eAVEfHUrhcubL592Ckzvq9AeQvyJ7psKR+mQx5BSvwhamOakr4lwdYk0TSjCRGsT95gE3gTDTNaSB1ojtP6uCpdx39Oo2vIgr8LrenHp1VuXmpa7hfEkps4LTXq1n3uO1SB6xp+md/ekvqLOcctLtbXuxdusxFeIRNjDhJq78ePCu3SMv6pKHwEYNEsXzYUZ3lQ0fyMGpoQr6YlCfh82B6OBdUqd0NSSfQWQOKHjqUoO+XhAaecRLmB+ge6dUdrfbIqueZESlccsGMIXk12pcbM4vvKro278xkXtw9w3rZMT44re/r3B2ECPMVNhyejfco8Y2F5sd2GiKRSLj0pICwjGnBNJFSJD/E94vuYa83uswRNsVdQGAtBCiCJpIsMHIC8tWBqto+PaXrGr7fNqrIlOyYaZzaF41oHqhJM5l6V/PFxJlhyOgWU217r+HdCKuSDEXw1kMQ3uRUJKaOw+uMu1iUwks3WqY6+WaRe5JiwzUd4C73/NJAd01sK54FcLLUNlTH2bSpW0uJ0pwodsm0Xe4mjeo1wU9+qbZ5QDYGbIa2nk09kaVDnrliezqFpOxS+tuR2tEd7uBuNl2IkQyi7LUCLwCJMg/akazhTW1ymaEanrL9s6MB2cEC7tziHQvTnXy7Yt/gmHNMCjSyR/Fw4L6nfMsCSi1OK7DAedUQ68odkdiZux7dvNYMXshBirYt8T4vZ0EwNCQvHCfKQU3QKRadr9hE+N5EDE9ml10JuHcXuvolw3yXM5InKY0du4UosZQLHJnFiRRmotZxmUvL3Rf8OflKcpqK4kdihpZDE0Ztu8KFBnz+xHQYHPzmz5zvOMU1YrMWyKrPgqMg9dXtknmQNAA/gZwGJ9EHcxIczHiux8Q3TzqqInhBB0ZyaINKEISGw2oJV3kdwVoPYx2wbE4kWEu132Cxq6qvetAprnT+Q3IdUnoYyYorFMUW+4StnfILOHYyQ7SU4FeS1FMzk3NaE7ihaKQ+h1NEdw0TigWimEuTdTwXVkdnXZ3TVxUJDiRKCdabvppkZd3ROiezWEc7hojLJD9NLuCVwzFDf10+/FVqGf885ZBZYoBFIv4CZviYHAZvceUWqn4melL2DPcBlWP6Q7YFNhnxztO125a52bZJlLTsXFNUwoSXykMQn6ABhXeUe4ra+cJo+Zb7ZOSdxUqk9hgBZ4u/8CIvvuSMtLJYZWHIupTVGYUc2xKzar5W3JIMF8eeknOKIPQ//Hj2gYpH1TRXd+7FaNgz6mVZ7yIiyeWZJdM6nM+4upcsdYB/TbOoWj/3LxJ9hV1QdpKhvSdvQMj1HzN2VS8q9L7vj/GqgK7iTMGWZlhV1EuilvRJwjzNcpPyXkL8rIx5uANLqGe1jI3U6ihVaxV4N0Idj+vYJ7TElD3xvhnFZclYYJpbutuI0SbCbRtYofNY69gqOiUnOHf5HNNdtAsZwQ2q6udFMUADRJe5a8cet8w4ZlKKW1dGvCCN7/Ll/PTzyemP3/+X//3bH9+ffFdjptIqPEo8OCezuhEl9UacaAImSZMCEvepxIgM6OKGUZIbqXkoQWib7quXbEXfUJiCvl8uby7QAlj2GKdk4ZOXwd4IRIlDrvZT3kIy4+i3tCwS3RrRPKRj9gT29pS2JRMf928g0DcJ7g2yltZEUG4YpqbGNknul0nt0xPQ1rkms98ssslP9P+GyG52Oz0jw18msNPohfK6hPPTkzPk0v4N4ho4f4m4RrUvF9dl8st//X8lsG2m+s1Cu7S026U2+v8Nsrd4c4KDN/0VkvYECm3+ni5JBZZyijF64wQdWqT8prAV3dkQ3X+Ck2JKpwcLVlK173ToG5+J7hACdPGulEjemHPTEDeL+DUb/LpBE3RgXqLBa8GadxLFXI0TIFM2GnpHhyNvr1GGjri+mwtmwMQWYlvGh8R8NEnqR5R58AnCVMNpnunj5vxhAXetdUdVGuTSmFCUmEilu22HNbM2vKWI5Eq4zSP+wPdP7+ZZSlAjIRxYfsz4IIiyaGTYaMvmJuedoCe4cHTLXnH/5Gef32iQFo6pNM8T6/zy6L3+5cn9JXv9P9rGJszfncGHuBY18FnsTvndGOIGl5sjmjrQktzm8zjjrMcEE708Cf7g/3n200ftNqdNVoAmFyu8/zuosDPip09usze98JxXz1YtKUReb5m0lyGXHXjePr5r9mBzguPEcp+v0oeNLlvmNkr0n9lnlpa/99cQeRatld3Y0yM5yUFL8Bgjgxe54UqLSQLY6Eb2K0wcINiX83Wscse8WW2M4PSV+VpxKlFjzq4rC/VnajgqXvElMUi0cFecHNZOtZPTH64qXGUd8y4gUPNVcMXp7TnRlCQ2ksN5Z4cznugTEta1aEIgAoafYuhXQTzHCwz4N3jnh7c/nHxHJ+k/nfvlXz9+PD/54fTt+cl3OU3cBzpouCS0hMvv+AaEoV+DKC2ok1heTsbRaypinrwjkogkS6skZ2bPj6QUFbJLfMmFNjaYxt0ajWhxkfJsWLjwELSi8CPxd9LRBIMo1R3lsqGoJadr/LTuXyyjoW3Qx/Xm8jJIe0oyzWJWdkK2tqs5iYMeNrQjBtnSVkY3Gajp8Zgmwu8p5Jd55UU8iuaMBd3WyusRijUK5Xwlr01PDMK7JTTrjLi0+gycEcCuSYybv12hWovlcqkaQ7OQ3KV0s44v3ek5s7qAgwg2FWjMMobcF3Qgm4R0IRDlfehZmrAneh1AtVlRmXFlH/gvbj6PPJgPX0rykstIFpny9RJF62r4acPFNYWMdcYE7MBODqlcZCvlVPgncUfpXQPl1wzkPKFjieuN7RcQlF408GRRpShfnKqbVR69V94UFitPDOPclESt09ZSp53nb0DyWq4rrl1LMJHCr1HcaqG2z05Z32cc+j5H4fvaQNKHSDgmYqHEZQG5c02J9za9WlPM0Sf6lWocBksPapcf6Gc4pRT7tcsW4MY60O4pF1XAiW3GQAVMQ38Frc80YWvGE/mIhlmxZIHHA/g0QIF9ySpvm2t1jdpuyZE7U4r577tW1wQX6X5M8C8b6LEt0WvkmtRhbG0dx6aLOEKtLTFrKDLBa20dvaaLqNaW9/m2c79nyQdamsb/Ads32kk=")).decode("utf-8")
    for _src, _sha, _n in ((NB4S_LIB_SRC, NB4S_LIB_SHA, "nb4s_lib"), (TL_SRC, TL_SHA, "nb4_timeline"), (PPACK_SRC, PPACK_SHA, "nb4_ppack")):
        if hashlib.sha256(_src.encode("utf-8")).hexdigest() != _sha:
            raise RuntimeError(f"EMBED_SHA_MISMATCH: {_n}")
        (TMP / f"{_n}.py").write_text(_src, encoding="utf-8")
    if str(TMP) not in sys.path:
        sys.path.insert(0, str(TMP))
    N = importlib.import_module("nb4s_lib")
    TL = importlib.import_module("nb4_timeline")
    P = importlib.import_module("nb4_ppack")
    NB4S = R.setdefault("nb4s", {})
    NB4S.update(question="which change removes the ~21 ms stage-0 in-graph stall and speeds up decode: CUDA_DEVICE_MAX_CONNECTIONS=32 "
                         "(S), Q-pack (QP) or Q-defer (QD)?",
                lib=N.LIB_VERSION, lib_sha256=NB4S_LIB_SHA, timeline_sha256=TL_SHA, ppack_sha256=PPACK_SHA,
                ppack_file_shas={"pp_pre": P.PP_PRE, "pp_post": P.PP_POST, "mr_pre": P.MR_PRE, "mr_post": P.MR_POST},
                cell6_dropped=json.loads(r"""{"names": ["commit_mode", "commit_ab", "commit_counter_delta", "pool_blocks_from_usage", "reset_cache", "_hits", "alloc_sequence", "reset_succeeded", "fit_alloc", "kv_accounting", "n_fit", "admission_test", "residency_bound", "residency_capacity", "_f_valid", "resolve_F", "f_from_log", "residency_probes", "block_layout", "nb1_complete", "nb1_tf_req", "lp_compare", "fp8_self_check", "nb1_ladder", "_prefix_counts", "_reuse", "prefix_tests", "_merge", "_clip", "_inter", "microbatch_costs", "pp2_trace", "merge_routing", "pp2_profile"], "nb1_cell6_sha256": "d22ae75cf2d9641369cf26397b7ed95920c3a0c455d883a476ba93a524cd3390", "bytes_before": 97385, "bytes_after": 43809}"""), nb1_r2_notebook_sha256="62670fce0e5ee950e1d32027522c5b4feffa55c43b061e4c7394668142b2bd3a")
    B3_PIN = KV_FP8 + (1 << 30)                 # NB1 R2 B3: 3,553,580,524 B (FP8 KV, 214 blocks), the tightest worker kept 191 MiB
    if B3_PIN != 3553580524:
        raise RuntimeError(f"B3_PIN {B3_PIN} != 3553580524")
    B_EXTRA = EXT_FLAG + ["--language-model-only", "--profiler-config", PROFILER_CFG]   # = NB1 R2 B3 (FP8_EXTRA)
    B_ENV = dict(DIAG_ENV)                                                           # = NB1 R2 B3 (no NCCL debug)
    ARMS = N.arm_plan(B_EXTRA, B_ENV, B3_PIN, q_env={"QP": P.server_env("Q-pack"), "QD": P.server_env("Q-defer")})
    N.check_arm_plan(ARMS)                      # never-do list + "each arm = B + exactly one env key" (raises: no boot)
    NB4S["arms"] = {k: {x: a[x] for x in ("name", "port", "env", "change", "expect", "extra", "kv_bytes", "needs_patch", "est_min",
                                          "cap_min", "title")} for k, a in ARMS.items()}
    NB4S["order"] = list(N.ORDER)
    NB4S["windows_order"] = list(N.WINDOWS)
    NB4S["oom_policy"] = ("one policy for every arm: a launch OOM (OOM line anywhere in the launch's full log, no device fault) -> one "
                          "retry 0.25 GiB lower on a fresh port and launch name; every later arm starts at B's final pin; a pin mismatch "
                          "vs B makes that arm INCONCLUSIVE_PIN_MISMATCH; an OOM during the body never retries (BODY_OOM_<item>)")
    NB4S["never_do"] = {"env": sorted(N.NEVER_DO_ENV), "argv": list(N.NEVER_DO_ARGS), "argv_values": N.NEVER_DO_ARG_VALUES}
    NB4S["budget"] = {"hard_stop_min": BUDGET / 60, "start_reserve_sec": N.START_RESERVE_SEC, "body_reserve_sec": N.BODY_RESERVE_SEC,
                      "priority": "B > S > QP > QD (an arm starts only with est_min x 60 + 300 s left)"}
    ARM_OF = {}                                 # launch name (retries included) -> arm
    PIN = {"kv_bytes": B3_PIN, "source": "NB1 R2 B3"}
    NB4S_READY_SEC = 18 * 60                    # readiness gate per boot (NB1 R2 B3 was ready in 297 s)
    CUR = {"item": None}
    _HIST = {}


    def _tree_py():
        eng = merlin_install()
        return Path(eng["kv"]["MERLIN_TREE"]), eng["kv"]["MERLIN_VENV"] + "/bin/python"


    def _ppack_apply():
        tree, py = _tree_py()
        return P.apply_ppack_patch(tree, py)


    def _ppack_revert():
        tree, py = _tree_py()
        rec = P.revert_ppack_patch(tree, py)
        v = P.verify_ppack_patch(tree)              # the pre-shas, verified again after the revert
        if v["state"] != "not_applied":
            raise RuntimeError("REVERT_NOT_PRISTINE: " + json.dumps(v)[:400])
        rec["verify_after"] = v
        return rec


    PSEQ = N.PatchSeq(_ppack_apply, _ppack_revert)


    def _prom_nb4s(port):
        """e23_lab.prom (same dict, one HTTP read) + the iteration-token histogram buckets with their read time, so a steady
        window's micro-batch split comes from the exact snapshots steady() took at t0 / t1."""
        txt = L.U.urlopen(f"http://127.0.0.1:{port}/metrics", timeout=15).read().decode("utf-8", "replace")
        agg, buckets = N.prom_parse(txt)
        h = _HIST.setdefault(port, [])
        h.append((time.perf_counter(), buckets))
        del h[:-600]
        return agg


    L.prom = _prom_nb4s


    def _hist_at(port, t):
        """The latest histogram snapshot read at or before perf_counter time t (steady() reads m0 then sets t0)."""
        best = None
        for ts, b in _HIST.get(port, []):
            if ts <= t + 0.01:
                best = (ts, b)
        return best if best and t - best[0] < 1.0 else None


    _merlin_fn_server_nb1 = merlin_fn_server       # RC2 CELL 2 + NB1's per-boot hooks (env re-exported after build())


    def merlin_fn_server(name, kv, port, kv_bytes):
        """E25 NB4S: NB1's Merlin plan, then the never-do gate + every watched key (CUDA_DEVICE_MAX_CONNECTIONS, NB4_PPACK,
        NB4_PPDEFER) at the arm's value on the FULL final env / argv of THIS launch (fail closed: no server is started)."""
        s = _merlin_fn_server_nb1(name, kv, port, kv_bytes)
        arm = ARM_OF.get(name)
        popped = {}
        for w, want in ((arm or {}).get("expect") or {}).items():
            if want is None and w in s.env:              # inherited from the image env, not planned: removed (recorded)
                popped[w] = s.env.pop(w)
        bad = N.launch_check(arm, s.env, s.argv) if arm else [f"launch {name} has no arm"]
        NB4S.setdefault("launch", {})[name] = {"arm": (arm or {}).get("key"), "port": port, "kv_bytes": kv_bytes, "never_do": bad,
                                               "env": {k: s.env[k] for k in sorted(s.env) if k.startswith(("CUDA_", "NCCL_", "NB4_", "VLLM_SERVER_DEV",
                                                                                                            "VLLM_USE_V2", "P2P"))},
                                               "argv_tail": s.argv[-12:], "help": HELP.get(name), "popped_unplanned_env": popped}
        save()
        if bad:
            raise RuntimeError("NEVER_DO_AT_LAUNCH: " + "; ".join(bad))
        return s


    def free_min(port):
        """Free MiB per card = min(nvidia-smi, the worker's own torch free memory of the same rank); both recorded."""
        smi = L.gpu_mem() or []
        w = rpc_cache_info(port)
        wf = w.get("free_mib_per_rank") if isinstance(w, dict) else None
        sf = [t_ - u for _, u, t_ in smi] if smi else None
        mins = None
        if sf and wf and len(sf) == len(wf):
            mins = [min(a, b) if isinstance(b, (int, float)) else a for a, b in zip(sf, wf)]
        return {"nvidia_smi": sf, "worker": wf, "min": mins or sf or wf}


    def proc_environ():
        """Side record: the watched keys in /proc/<pid>/environ of every engine process (server, workers, PLE)."""
        blobs = {}
        for pid, _ in (engine_procs() or [])[:24]:
            try:
                blobs[pid] = Path(f"/proc/{pid}/environ").read_bytes()
            except Exception:
                blobs[pid] = None
        return blobs


    def _live(o, key, val):
        """Every item lands in the record and in the live step record before save() (a hard kill keeps it)."""
        o[key] = val
        rec = LIVE.get("rec")
        if rec is not None:
            rec.setdefault("live", {})[key] = val
        save()
        return val


    def q_readback(s, arm):
        """Q arms: the 4 'NB4_PPQ init' lines (every rank must agree: a mismatch hangs NCCL) + moved counters, via
        nb4_ppack.readback_label on the launch's whole log. Other arms: None."""
        if not arm["q_label"]:
            return None
        try:
            lab, det = P.readback_label(s.log() or "", arm["q_label"])
        except Exception as e:
            lab, det = "NOT_INTEGRATED", {"error": f"{type(e).__name__}: {e}"[:300]}
        return {"label": lab, "detail": det}


    def hist_window(port, s, band, n):
        """NB1's window() (RC2 levels / lab steady; running == level, prefill done, per-position acceptance, tick / cycle) + the
        window's micro-batch split from the iteration-token histogram at steady()'s own t0 / t1."""
        r = window(port, s, band, n)
        h0, h1 = (_hist_at(port, r["t0"]) if r.get("t0") else None), (_hist_at(port, r["t1"]) if r.get("t1") else None)
        d = N.hist_delta(h0[1], h1[1]) if h0 and h1 else None
        r["parity"] = N.parity_from_hist(d, n, PP, 3)
        return r


    def profile_window(port, arm):
        """One profiled 8k@8 window: lab profiled_load (settled decode, then the bounded POST /start_profile
        {"delay_iterations": 20, "max_iterations": 40}, 6 s, /stop_profile); the traces are kept per arm."""
        shutil.rmtree(PROF_DIR, ignore_errors=True)
        PROF_DIR.mkdir(parents=True, exist_ok=True)
        rec = L.profiled_load(port, PROMPTS["8k"], 8, PROF_DIR, secs=6.0, max_new=MAX_NEW["8k"], spec=True, prefill_tok_s=PREFILL["tok_s"])
        rec["profile_request"] = {"delay_iterations": 20, "max_iterations": 40, "secs": 6.0, "level": 8, "band": "8k"}
        if "trace" in rec:
            rec["lab_trace_summary"] = rec.pop("trace")
            rec["lab_trace_note"] = "e23_lab rule: its PIECEWISE verdict is a parser artefact here (graphs research §0.1); nb4_timeline decides"
        g = L.gpu_mem()
        if g:
            rec["gpu_mem_peak_mib"] = [x[1] for x in g]
        kept = TRACES / f"profile_{arm['key'].lower()}"
        shutil.rmtree(kept, ignore_errors=True)
        kept.mkdir(parents=True, exist_ok=True)
        rec["trace_files"] = []
        for f in sorted(PROF_DIR.rglob("*.pt.trace.json*")):
            if f.stat().st_size < 120e6:
                shutil.copy2(f, kept / f.name)
                rec["trace_files"].append([f.name, f.stat().st_size])
        rec["trace_dir"] = str(kept)
        shutil.rmtree(PROF_DIR, ignore_errors=True)
        return rec


    WIN_NEED = {"8k@8#1": lambda: WIN + 120 + 8 * BANDS["8k"] / max(500.0, PREFILL["tok_s"]),
                "8k@8#2": lambda: WIN + 120 + 8 * BANDS["8k"] / max(500.0, PREFILL["tok_s"]),
                "profile_8k@8": lambda: 360,
                "40k@8": lambda: WIN + 120 + 8 * BANDS["40k"] / max(500.0, PREFILL["tok_s"])}
    RPC_KEYS = ",".join(N.WATCHED) + ",NCCL_P2P_DISABLE,P2P"


    def arm_body(arm, ref, store):
        """Every arm, the same items in the same order; every item gated by due() on the boot's own deadline."""
        def body(ss):
            s = ss[0]
            p = s.port
            o = {"arm": arm["key"], "items_skipped": []}
            CUR["item"] = "facts"
            o = boot_facts(s, dict(o, census=kv_census(s), probes=L.chat_probes(p), sampled=sampled_check(s)), s.name)
            LIVE["out"] = o
            CUR["item"] = "env_readback"
            _live(o, "env_readback_raw", rpc(p, "nb4s_env", RPC_KEYS))
            _live(o, "env_readback", N.parse_env_readback(o["env_readback_raw"], arm["expect"]))
            _live(o, "proc_environ", N.parse_proc_environ(proc_environ(), arm["expect"]))
            _live(o, "q_readback", q_readback(s, arm))
            _live(o, "free_after_ready_min", free_min(p))
            if short_gate_failed(o):
                o.update(early_stop="SHORT_CORRECTNESS_GATE_FAILED", census_end=kv_census(s),
                         quality_gate="FAIL_SAMPLED" if (o["sampled"] or {}).get("ok") is not True else "FAIL_PROBES")
                return o
            if o["env_readback"].get("definitive"):
                o.update(status="NOT_ENGAGED", early_stop="the workers do not hold the planned env: " + str(o["env_readback"].get("why")))
                return o                          # definitive: the arm's change is not in effect, nothing to measure
            if (o["q_readback"] or {}).get("label") == "NOT_INTEGRATED":
                o.update(status="NOT_INTEGRATED", not_integrated=True, early_stop="nb4_ppack init lines: " + json.dumps(o["q_readback"])[:300])
                return o
            if due(300):                          # every arm (the 40k probe prompt is variant 7 of the 40k@8 window: same cache state)
                CUR["item"] = "prefill_probe"
                _live(o, "prefill", prefill_probe(p))
            if not due(240):
                o["items_skipped"].append("oracle")
                o["status"] = "SKIPPED_BOOT_BUDGET_ORACLE"
                return o
            CUR["item"] = "oracle"
            _live(o, "oracle", oracle(p, key=store, refs=(ref,)))
            o["oracle_vs"] = (o["oracle"].get("vs_" + ref) or {}).get("status")
            o["quality_gate"] = quality_gate(o, ref)
            if o["quality_gate"] != "PASS":
                o["load_tests_skipped"] = f"oracle gate vs {ref}: {o['quality_gate']}"
                o["status"] = "NO_GO_QUALITY" if o["quality_gate"].startswith("FAIL") else "INCONCLUSIVE_QUALITY"
                o["census_end"] = kv_census(s)
                return o
            if arm["q_label"]:
                _live(o, "q_readback", q_readback(s, arm))         # the counters moved by now (probes + sampled + oracle decode)
                if (o["q_readback"] or {}).get("label") != "ENGAGED":
                    o.update(status=o["q_readback"]["label"], not_integrated=o["q_readback"]["label"] == "NOT_INTEGRATED",
                             early_stop="nb4_ppack read-back: " + json.dumps(o["q_readback"])[:300])
                    return o
            if due(150):
                CUR["item"] = "warmup"
                _live(o, "warmup", warmup(p, 8))
            else:
                o["items_skipped"].append("warmup")
            o["steady"] = {}                      # RC2's _windows() gate reads "steady": garbage under load is NO_GO here too
            for wk in N.WINDOWS:
                need = WIN_NEED[wk]()
                if not due(need):
                    o["steady"][wk] = {"status": "SKIPPED_BOOT_BUDGET", "need_sec": round(need), "boot_left_sec": round(boot_left())}
                    o["items_skipped"].append(wk)
                    continue
                if not s.alive():
                    o["steady"][wk] = {"status": "SKIPPED_SERVER_DEAD"}
                    continue
                CUR["item"] = wk
                try:
                    r = profile_window(p, arm) if wk.startswith("profile") else hist_window(p, s, wk.split("@")[0], 8)
                except Exception as e:
                    r = {"status": "ERROR", "error": f"{type(e).__name__}: {e}"[:400], "tb": traceback.format_exc()[-1200:]}
                o["steady"][wk] = r
                _live(o, "steady", o["steady"])
            CUR["item"] = "end"
            o["census_end"] = kv_census(s)
            o["workers_end"] = rpc_cache_info(p)
            o["free_end_min"] = free_min(p)
            o["q_readback_end"] = q_readback(s, arm)
            o["ppq_stats_last"] = [e for e in P.parse_log(s.log() or "") if e.get("event") == "stats"][-8:] if arm["q_label"] else None
            o["jit_after_warmup"] = jit_kernels(s.log())[-12:]
            return o
        return body


    def arm_watched(body, cap_min, name):
        """NB1's watched() with the cap fixed at body START (after the launch): min(cap, left - BODY_RESERVE_SEC); every item
        checks due(); at cap + 300 s the server is killed (hard backstop)."""
        def b(ss):
            cap = N.body_cap_sec(cap_min, left())
            BOOT.update(deadline=time.time() + cap, fired=None)

            def fire():
                BOOT["fired"] = name
                for x in ss:
                    try:
                        x.kill()
                    except Exception:
                        pass
            tm = threading.Timer(cap + 300, fire)
            tm.daemon = True
            tm.start()
            try:
                o = body(ss)
                LIVE["out"] = o if isinstance(o, dict) else None
            finally:
                tm.cancel()
                BOOT["deadline"] = None
            o["body_cap_sec"] = round(cap)
            if BOOT["fired"]:
                o["boot_watchdog"] = f"FIRED after {cap + 300:.0f} s: server killed"
            return o
        return b


    def arm_boot(arm, body):
        """One arm: the boot gate, one Merlin launch, the /dev/shm cleanup; the ONE OOM policy (launch OOM in the launch's
        full log, no device fault -> one retry 0.25 GiB lower on a fresh port and launch name); death labels by item."""
        kvb, port, tries, o = PIN["kv_bytes"], arm["port"], [], {}
        ref = "rc2_fp8" if arm["key"] == "B" else "b"
        while True:
            lname = arm["name"] if not tries else f"{arm['name']}_t{len(tries)}"
            NB1_EXTRA[lname], NB1_ENV[lname], NB1_KV[lname] = list(arm["extra"]), dict(arm["env"]), kvb
            ARM_OF[lname] = arm
            BOOT["tag"] = lname
            gate = boot_gate()
            if gate["ok"] is not True:
                return {"status": "GPU_NOT_EMPTY", "boot_gate": gate, "tries": tries, "launch_name": lname, "pin": kvb}
            shm0 = shm_names()
            mon = LoadMonitor(lname)
            mon.start()
            srv, CUR["item"] = None, "launch"
            try:
                srv = merlin_fn_server(lname, "fp8", port, kvb)
                o = with_servers([srv], NB4S_READY_SEC, arm_watched(body, arm["cap_min"], lname))
            finally:
                mon.stop_ev.set()
            try:
                full = srv.log() or ""
            except Exception:
                full = ""
            lines = full.splitlines()
            o.update(kv_bytes=kvb, pin=kvb, launch_name=lname, port=port, boot_gate=gate, shm_cleanup=shm_cleanup(shm0),
                     ready_sec=getattr(srv, "ready_sec", None), load_monitor_last=mon.last, oom_in_log=bool(OOM_ERR.search(full)),
                     xid_in_log=bool(XID.search(full)), oom_lines=[l[:240] for l in lines if OOM_ERR.search(l)][:6],
                     xid_lines=[l[:240] for l in lines if XID.search(l)][:6], died_in=CUR["item"])
            if arm["q_label"] and o.get("q_readback") is None:
                o["q_readback"] = q_readback(srv, arm)        # a launch that failed: the init lines (if any) are still in the log
            oom = o.get("status") == "LAUNCH_FAILED" and o["oom_in_log"]
            tries.append({"launch_name": lname, "port": port, "kv_bytes": kvb, "status": o.get("status"), "oom": oom,
                          "device_fault": o["xid_in_log"], "ready_sec": o["ready_sec"]})
            if not oom or o["xid_in_log"] or len(tries) > 1 or left() < NB4S_READY_SEC + arm["cap_min"] * 60:
                break
            kvb -= OOM_STEP
            port += 1
            log("boot OOM:", lname, "-> one retry with KV_BYTES", kvb, "port", port)
        o["tries"] = tries
        if o.get("status") == "SERVER_DIED":
            o["death"] = ("BOOT_CAP_KILL" if o.get("boot_watchdog") else
                          f"BODY_OOM_{o.get('died_in')}" if o["oom_in_log"] and not o["xid_in_log"] else
                          f"DEVICE_FAULT_{o.get('died_in')}" if o["xid_in_log"] else f"SERVER_DIED_IN_{o.get('died_in')}")
            o["status"] = o["death"]
        return gated(o, need=(ref,), expected_rows=4)


    def analyze_arm(o, key):
        """After the boot (GPUs idle): nb4s_lib.graph_stalls + nb4_timeline.analyze on the arm's traces; full JSON files kept."""
        d = ((o.get("steady") or {}).get("profile_8k@8") or {}).get("trace_dir")
        if not d or not list(Path(d).glob("*.pt.trace.json*")):
            o["stall"] = {"error": "NO_TRACE_FILE"}
            o["timeline"] = {"error": "NO_TRACE_FILE"}
            return o
        t = time.time()
        try:
            st = N.graph_stalls(d)
            (OUT / f"stall_{key.lower()}.json").write_text(json.dumps(st, indent=1, default=str))
            o["stall"] = {k: v for k, v in st.items() if k != "by_rank"}
            o["stall"]["by_rank"] = {r: {x: y for x, y in v.items() if x != "rows"} for r, v in (st.get("by_rank") or {}).items()}
        except Exception as e:
            o["stall"] = {"error": f"{type(e).__name__}: {e}"[:400], "tb": traceback.format_exc()[-1200:]}
        try:
            rep = TL.strip_private(TL.analyze(d))
            (OUT / f"timeline_{key.lower()}.json").write_text(json.dumps(rep, indent=1, default=str))
            o["timeline"] = N.summarize_timeline(rep)
            try:
                (OUT / f"timeline_{key.lower()}.md").write_text(TL.format_report(rep))
            except Exception as e:
                o["timeline"]["format_report_error"] = repr(e)[:200]
        except Exception as e:
            o["timeline"] = {"error": f"{type(e).__name__}: {e}"[:400], "tb": traceback.format_exc()[-1200:]}
        o["analysis_sec"] = round(time.time() - t, 1)
        return o


    def run_arm(key):
        arm = ARMS[key]
        o = arm_boot(arm, arm_body(arm, "rc2_fp8" if key == "B" else "b", "b" if key == "B" else None))
        LIVE["out"] = o
        try:
            o["arm"], o["planned"] = key, NB4S["arms"][key]
            o["free_mib_per_card"] = free_per_card(o, o.get("launch_name"))
            if left() > 120:
                analyze_arm(o, key)
        except Exception as e:
            keep_after_error(o, e)
        return o


    def _arm_rec(key):
        r = (R["sections"].get(key) or {}).get(ARMS[key]["name"])
        return r if isinstance(r, dict) else None


    def arm_clean(o):
        return isinstance(o, dict) and o.get("status") == "DONE" and o.get("correctness") == "CLEAN" and o.get("quality_gate") == "PASS"


    def skip_arm(key, why, status="SKIPPED_DEPENDENCY", **kw):
        R["sections"].setdefault(key, {})[ARMS[key]["name"]] = dict({"status": status, "why": why}, **kw)
        save()


    def finalize():
        """Always (finally): analysis of any arm that has traces but no analysis yet, then the verdict + nb4s_verdict.json."""
        try:
            recs = {}
            for k in ARMS:
                r = _arm_rec(k)
                if r is not None and "stall" not in r and ((r.get("steady") or {}).get("profile_8k@8") or {}).get("trace_dir"):
                    try:
                        analyze_arm(r, k)
                    except Exception as e:
                        r["stall"] = {"error": repr(e)[:300]}
                recs[k] = r
            v = N.verdict({k: r for k, r in recs.items() if r is not None})
        except Exception as e:
            v = {"verdict": "ERROR_IN_VERDICT", "why": f"{type(e).__name__}: {e}"[:400], "tb": traceback.format_exc()[-1500:]}
        v["arms_status"] = {k: (_arm_rec(k) or {}).get("status") for k in ARMS}
        v["patch"] = NB4S.get("patch")
        v["minutes"] = round((time.time() - T_START) / 60, 1)
        NB4S["verdict"] = v
        try:
            (OUT / "nb4s_verdict.json").write_text(json.dumps(v, indent=1, default=str))
        except Exception:
            pass
        save()
        log("NB4S VERDICT", v.get("verdict"), "|", str(v.get("why"))[:400])
        return v


    def nb4s_main(runner=None, pseq=None):
        """install -> #60490 + extension -> sha gate -> B -> S -> QP -> QD (priority order; each needs B clean and its full
        minimum of time). The nb4_ppack patch is applied right before the first Q arm that starts, kept for QD, reverted at
        the end (pre-shas verified); the verdict is written in the finally block whatever happens."""
        runner = runner or run_arm
        pseq = pseq or PSEQ
        try:
            m = R["sections"]["A0"]["merge"]
            if not m.get("ok"):
                NB4S["stop"] = "MERGE_FAILED: no boot started"
                for k in ARMS:
                    skip_arm(k, NB4S["stop"])
                return
            step("A0", "merlin_install", 10, lambda: {"install": (lambda e: {"ok": True, "tree": e["kv"].get("MERLIN_TREE")} if not FAKE else {"fake": True})(merlin_install())})
            pt = step("A0", "patch_60490", 3, apply_60490)
            if pt.get("status") != "DONE" or not pt.get("ok"):
                for k in ARMS:
                    skip_arm(k, f"#60490 patch / worker extension not verified: {pt.get('error') or pt.get('status')}")
                return
            if "rc2_fp8" not in ROWS and not FAKE:
                for k in ARMS:
                    skip_arm(k, "RC2's recorded FP8 oracle rows do not match this notebook's prompts (no gate reference)")
                return
            ok, why = sha_gate(min(1500, left() - 900))
            R["setup"]["sha_gate"] = {"ok": ok, "why": why}
            if not ok:
                for k in ARMS:
                    skip_arm(k, "sha gate: " + why, "SKIPPED_SHA_GATE")
                return
            b = step("B", ARMS["B"]["name"], ARMS["B"]["est_min"], lambda: runner("B"))
            if not arm_clean(b):
                for k in N.ORDER[1:]:
                    skip_arm(k, f"B not clean (status {b.get('status')}, correctness {b.get('correctness')}, gate {b.get('quality_gate')})")
                return
            PIN.update(kv_bytes=b.get("pin") or PIN["kv_bytes"], source="B's final pin")
            for k in N.ORDER[1:]:
                a = ARMS[k]
                if not N.arm_fits(left(), a):
                    skip_arm(k, f"left {left() / 60:.1f} min < its full minimum {a['est_min']} + {N.START_RESERVE_SEC // 60} min "
                                "(priority B > S > QP > QD)", "SKIPPED_BUDGET")
                    continue
                ok_p, why_p = pseq.before_arm(a)
                NB4S["patch"] = {"state": pseq.state, "log": pseq.log, "error": pseq.error, "apply": pseq.apply_rec, "revert": pseq.revert_rec}
                if not ok_p:
                    skip_arm(k, why_p, "NOT_INTEGRATED" if a["needs_patch"] else "SKIPPED_DEPENDENCY", not_integrated=bool(a["needs_patch"]))
                    continue
                step(k, a["name"], a["est_min"], lambda k=k: runner(k))
        finally:
            try:
                pseq.finish()
            except Exception as e:
                pseq.error = f"finish: {type(e).__name__}: {e}"[:300]
            NB4S["patch"] = {"state": pseq.state, "log": pseq.log, "error": pseq.error, "apply": pseq.apply_rec, "revert": pseq.revert_rec}
            finalize()


    def _gpu_util():
        while not _gpu_util_stop.is_set():
            try:
                r = subprocess.run(["nvidia-smi", "--query-gpu=index,utilization.gpu,memory.used,power.draw", "--format=csv,noheader,nounits"],
                                   capture_output=True, text=True, timeout=20)
                if r.returncode == 0:
                    with open(OUT / "nb4s_gpu_util.jsonl", "a") as fh:
                        fh.write(json.dumps({"t": round(time.time() - T_START, 1), "gpus": r.stdout.strip().splitlines()}) + "\n")
            except Exception:
                pass
            _gpu_util_stop.wait(5)


    _gpu_util_stop = threading.Event()
    if not RERUN and not os.environ.get("RC2_UNIT"):
        if NVSMI_OK:
            threading.Thread(target=_gpu_util, daemon=True).start()
        nb4s_main()
        _gpu_util_stop.set()
        R["host_phase"] = HOST_PHASE
        R["prefill"] = PREFILL
        R["minutes"] = round((time.time() - T_START) / 60, 1)
        save()
    save()


if not RERUN:
    # ==================================================================== CELL 8 — report + fallback submission
    if not RERUN and not os.environ.get("RC2_UNIT"):
        write_fallback_submission()
        def _arm_brief(k):
            r = _arm_rec(k) or {}
            w = r.get("steady") or {}
            return {"status": r.get("status"), "correctness": r.get("correctness"), "quality_gate": r.get("quality_gate"),
                    "oracle_vs": r.get("oracle_vs"), "pin": r.get("pin"), "tries": r.get("tries"), "ready_sec": r.get("ready_sec"),
                    "env_readback": (r.get("env_readback") or {}).get("why"), "proc_environ": (r.get("proc_environ") or {}).get("values"),
                    "q_readback": r.get("q_readback"), "free_after_ready_min": (r.get("free_after_ready_min") or {}).get("min"),
                    "free_end_min": (r.get("free_end_min") or {}).get("min"),
                    "windows": {k2: dict({x: v.get(x) for x in ("status", "tok_s", "tick_ms", "cycle_ms", "mean_acceptance_length",
                                                               "accept_rate_per_position_incl_admission", "running_min", "running_max",
                                                               "preemptions", "running_eq_level")}, parity=(v.get("parity") or {}).get("label"))
                                for k2, v in w.items() if isinstance(v, dict)},
                    "stall_stage0": (r.get("stall") or {}).get("stage0"), "stall_stage1": (r.get("stall") or {}).get("stage1"),
                    "profile_parity": (r.get("stall") or {}).get("parity"),
                    "timeline": {x: (r.get("timeline") or {}).get(x) for x in ("tick_ms_mean", "stages", "tick_stall_ms_median",
                                                                              "tick_share_stall_below_1ms", "graph_modes_steady",
                                                                              "parity_verdict", "dependency_verdict", "per_rank", "error")},
                    "why": r.get("why"), "error": r.get("error")}
        R["summary"] = {k: _arm_brief(k) for k in ARMS}
        save()
        _v = NB4S.get("verdict") or {}
        print("BEST ARM:", _v.get("best_arm"), _v.get("best_verdict"), "|", _v.get("why"))
        print(json.dumps(_v, default=str)[:5000])
        print(json.dumps(R["summary"], default=str)[:12000])
