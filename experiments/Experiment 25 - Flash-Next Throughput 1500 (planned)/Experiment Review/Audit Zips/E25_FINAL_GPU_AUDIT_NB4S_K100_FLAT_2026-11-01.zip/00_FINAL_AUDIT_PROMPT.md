# Final pre-GPU audit: two notebooks (NB4S stall test, klee100 load K3_ONLY), 2026-11-01

All files are flat. A prefix tells you which notebook each file belongs to:
- `NB4S__…` for the stall test;
- `K100__…` for the klee100 load test;
- `CTX__…` for context.

This is the LAST audit before the GPU runs, and time is short (the competition deadline is 2026-11-02).

**Report ONLY blockers.** A blocker is something that would:
(a) give wrong raw data;
(b) crash the run mid-way or hang it;
(c) waste GPU time;
(d) produce a misleading verdict.

For each blocker, give: file:function / line, a concrete scenario, and a minimal fix. Do not request new features or new measurements. Start with one line per notebook: GO / NO-GO.

## Notebook 1: NB4S — the stage-0 stall test (`NB4S__Q27-XHIGH-E25_NB4S_STALL.ipynb`, sha e9733a67, 95-min hard stop)

**Platform:** Kaggle 4×L4. Merlin v3.0.0 (vLLM 0.32 fork), V2 model runner, TP2×PP2+EP. Flash-Next W4, FP8 KV, MTP K3, 8 streams.

**The measured problem** (`CTX__E25_GPU_NB1_R2_2026-10-31.md`, `CTX__nb4_b1_v2.json`, `NB4S__NB4_RESEARCH_graphs_2026-11-01.md`):
- Stage 0's FULL decode graph stalls at node #173 for about 21.7 ms in 39 of 39 ticks.
- It is released by the OTHER micro-batch's PP sampled-token `Broadcast Int x8` on stream 31. That makes it a false dependency.
- Tick 49.7 ms; the ideal is 34.6-42 ms.

**Arms** (each = base B + exactly one change):
- **B:** NB1 R2 B3 config (pin 3,553,580,524 B, `--language-model-only`, #60490).
- **S:** `CUDA_DEVICE_MAX_CONNECTIONS=32`.
- **QP:** Q-pack patch, `NB4_PPACK=1`: one packed PP broadcast instead of three.
- **QD:** Q-defer patch, `NB4_PPDEFER=1`: the receive is posted after the next graph launch.

**Per arm:** env read-back from all 4 workers, oracle vs B, 8k@8 ×2, a profiled window analysed by `nb4_timeline`, 40k@8.

**Verdicts:** STALL_FIXED_WIN / STALL_FIXED_NO_SPEED / STALL_MOVED / STALL_REDUCED / NO_EFFECT / CORRECTNESS_FAIL / NOT_ENGAGED / NOT_INTEGRATED / SKIPPED_BUDGET.

**CPU kits:**
- units: ALL OK.
- real: everything OK except two known CPU-only limits:
  - `patch_60490_applied_verified`: the patch sha is OK, but the import probe raises a circular-import error on CPU. The same result appeared in the NB1 kit, and NB1 R2 then ran on GPU with that patch;
  - `argparse_fields_ok`: "Failed to infer device type" on CPU; this kit did not set `VLLM_TARGET_DEVICE=cpu`.

**Questions:**
- Can the Q-pack / Q-defer patches hang NCCL? For example, an env mismatch between ranks, or op ordering across the `pp_broadcast` and hidden-state SendRecv communicators.
- Is the env really reaching the workers?
- Is the revert after QD guaranteed?
- Can the verdict logic mislabel the result?

## Notebook 2: klee100 load test, profile K3_ONLY (`K100__Q27-XHIGH-E25_KLEE100_LOAD_K3ONLY.ipynb`, sha 5bd76bc5, 100-min hard stop; `K100__…_LOAD.ipynb` is the same code with profile ALL, 190 min)

**Goal:** load the low-bit checkpoint klee100 (W3 g128 / W2 g64 routed experts, W4 MTP, W8 projections) on Merlin with FP8 QSA KV and MTP K3 at seqs 32, then measure:
- whether it loads (`@@K3_CORE_DONE` / `@@K3_CORE_FAILED`, with early exit in K3_ONLY);
- the method map (4 ranks, per-PP-stage layers);
- the per-rank static FP8 scales (the W4 sidecar reused);
- the oracle, and TF 2k / 8k vs NB0's W4 BF16 reference;
- the KV pool and F;
- a stream sweep at contexts 20k / 40k / 60k / 100k, levels 16 → 24 → 32, gated by the measured residency.

**Pin ladder:** 5,270,142,976 → 3,553,580,524 → 2,479,838,700 B, with one controlled body-OOM retry. After any device fault, a GPU health gate.

**History:** three earlier GPT audit rounds plus two internal reviews. All 58 items are listed in `K100__KLEE100_LOAD_AUDIT_FIXES_2026-10-31.md` (rounds 1-4, V-1..V-15). Units 373/373, real-data tests 90/90. The rev 3 CPU kits are running on Kaggle now; their reports will follow.

**Known open notes** (judge whether they are blockers):
- `help_check` treats a failed `--help` with output longer than 2,000 characters as "ran", which would raise FAIL_CLI_FLAGS. On GPU, `--help` worked in NB0 and NB1 R2 (missing []).
- The CLI_FLAGS gate is checked only on K0; K3 now boots first.

**Context files:**
- `CTX__E25_GPU_NB5_QUALITY_2026-11-01.md`: W4 FP8 Duck solved 13/15 ARC tasks.
- `CTX__PLAN_1500.md`.
- the klee100 model card / author README.
