# GPU audit: NB-S1 with per-arm ON/OFF switches (DFlash2 D3s base + 5 lever arms), Kaggle 4xL4, klee100 on Merlin v3.0.0

**Answer GO or NO-GO on the first line. Then list ONLY BLOCKERS and SEVERE bugs** (crash, an arm that cannot launch, a wasted
run, wrong data recorded, an arm skipped by anything but a real failure / the time budget / its own switch). Each with
file:line, why, fix. No style items, no new features. Verdict-label / ranking quality is out of scope (deferred by the user;
raw numbers are read by hand).

The notebook in this zip is `NB__PUSH_q27-xhigh-e25-nbs1.ipynb` (sha 40c1fdcdb8bcfc31a650ab9f087405fbd59c96be96a28ed2499a6be052b5e216) = the CLOSED build (KV gate closed, gpu_ready false). The real +
units CPU kits for this exact sha are running now; on ALL OK the gated rebuild (`build_e25_nbs1.py --kv-gate-report`) only
embeds the kit gate, then `nbdf_gate_verify.py` checks embedded == facts + notebook sha. The previous gated build (6 arms, no
switch) had a real kit ALL OK: `KIT__PREVIOUS_nbs1_real_report_ALL_OK_6arms_pre_switch.json` (reference only).

## What changed (the only change since the previous audit): per-arm switches
- CELL 1 now starts with a plain editable line (outside the lzma/sha-locked CELL 7 body), edited in the Kaggle editor before
  the commit, no rebuild / no new kit:
  `NBS1_ON = {'Q': True, 'F8': True, 'G1': False, 'G2': False, 'EH': False, 'DYN': False}` (Q = B; default B + F8, ~2 h;
  B only = F8 False, ~1 h 15-20 min).
- `BUILD__build_e25_nbs1.py`: `SWITCH_BLOCK` + `edit_cells` wrapper (CELL 1), the S1 block reads
  `globals().get("NBS1_ON")` -> `NBS1_SWITCH` (absent -> every arm on; a missing key -> off) and records it in
  `NBDF["nbs1"]["switch"]`; B switched off -> `b_gate = ("SKIPPED_SWITCH_OFF", ...)` (the levers still run); in nbdf_main's
  D loop an off arm -> `skip_arm(k, ..., "SKIPPED_SWITCH_OFF"); continue` before any other check.
- The lib (`nbs1_lib.py` 9668adca), the arm plan (all 6 arms built + check_arms + kit-checked) and every NBDF file are unchanged.
- Units: `TEST__nbs1_unit_tests_output.txt` (63/63; 7 new switch tests: B + F8 -> only Q, F8 launch; B only; B off -> levers
  run; F8 dies -> no off arm started by the rerun path; CELL 1 switch line; body reads it; verdict with off arms).

## Background
- Arms: B = NBDF-K100 D3s (DFlash2 K3, SW-1024, BF16 drafter KV, seam, seqs 24, pin 7,933,526,016), G1
  (VLLM_GDN_DECODE_FASTPATH=1), G2 (VLLM_GDN_SHARED_ALIGN_INDEX=1), EH (DFLASH_DRAFT_EMBED_HOST=1), F8 (fp8 drafter KV,
  TRITON_ATTN, SW 2048), DYN (num_speculative_tokens_per_batch_size [[1,8,4],[9,24,3]]).
- Earlier NBDF-K100 GPU run: every DFlash arm died at capture (Merlin `v1/e2_guards.py` lacked the DFlash speculator's
  `query_cudagraph_manager`) -> fixed by the seam edit GRD (`BUILD__dflash_seam.py`), checked on the real installed tree in the
  real kit (`e2_guard_dflash_ok`). Q lost items to a LOW_VARIETY heuristic on ARC digit grids -> now only hard breakage
  (EMPTY / REPEATED_CHAR / BANG / request errors / NaN / zero accept / launch failure) stops an arm; heuristics record only.

Questions: (1) can the switch ever start an OFF arm, stop an ON arm, or change an ON arm's env / argv / budget? (2) with
B + F8 (and with B only), is anything (time budget, base pin, PIN / SW_PIN update, pending reruns, finalize / report /
CELL 8 submission) broken by the skipped arms? (3) anything else that would make DFlash2 fail at boot / capture / first
decode on GPU that the CPU kit cannot see? List each with file:line.
