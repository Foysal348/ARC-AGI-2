# Research request: a 21 ms false-dependency stall in PP2 decode (Merlin / vLLM 0.32, Flash-Next, 4×L4)

All files in this zip are flat. Read every file before answering. We want deep technical research, not a summary.

## Setup
- **Hardware:** Kaggle 4× NVIDIA L4 (24 GB, sm_89, PCIe gen 3, P2P off: `NCCL_P2P_DISABLE=1`, custom all-reduce off). NCCL 2.29.7 over host SHM.
- **Engine:** Merlin v3.0.0, a vLLM 0.32.0 fork (git ad42e37, source files included).
  - **Parallelism:** TP2 × PP2 + expert parallel, layer partition 25/23.
  - **Runner:** V2 model runner (`VLLM_USE_V2_MODEL_RUNNER=1`), async scheduling on.
  - **Speculation:** MTP K3 speculative decoding with probabilistic drafting.
  - **Cache:** FP8 E4M3 QSA KV, prefix caching, mamba cache mode align, block 4096.
  - **Graphs:** FULL_AND_PIECEWISE cudagraphs, captures [1,2,3,4,6,8,12,16,24,32].
- **Model:** Qwen3.8-Flash-Next W4A16, 125B total / 6B active. 48 layers (36 GDN linear-attention + 12 QSA sparse attention), 512 experts top-10, hyper-connections, a PLE table pinned in host RAM.
- **Workload:** decode, 8 streams (micro-batches of 4 + 4), 8k prompts, xhigh reasoning text.

## What we measured (torch-profiler traces of all 4 ranks are included; the clocks are shared)
One profiled window: 40 forwards per rank, 36 steady ticks.
- **Tick:** 49.66 ms on average (one PP tick = one completed micro-batch; a request advances every 2 ticks).
- **Stage 0, PP rank 0 (GPUs 0-1)**, per tick:
  - compute 23.54 ms;
  - **in-graph stall 21.75 ms**;
  - NCCL peer wait 2.58 ms;
  - transfer 1.26 ms;
  - host launch / python / idle ≈ 0.
- **Stage 1** (GPUs 2-3) compute 34.56 ms per tick:
  - target graph 20.2 ms;
  - MTP draft graphs 6.8 + 3.75 ms;
  - eager lm-head GEMM 2.6 ms;
  - RecoverSSM commit 0.9 ms;
  - AllGather 2.9 ms;
  - AllReduce 3.2 ms.
- **The stall:** in 39/39 stage-0 decode graphs, the FULL graph (one cudaGraphLaunch, 1,036 nodes) runs ~4.7-4.9 ms and then stops at the same node: #173, a TP AllReduce on a forked graph stream.
  - The stop lasts a median 21.5-21.7 ms.
  - It resumes 7 µs (median; p90 8.8 µs) after the PP sampled-token `Broadcast Int x8` (stream 31, communicator `pp_broadcast`, ranks [0,2]) ends.
- **The broadcasts:**
  - **Who posts them:** `PPHandler.receive` in `v1/worker/gpu/pp_utils.py` posts three receives per step on `broadcast_stream` after `broadcast_stream.wait_stream(main)`:
    1. Long×16: sampled tokens [n, K+1];
    2. Int×8: num_sampled / num_rejected [2, n];
    3. Long×12: drafts [n, K].
  - **What the step consumes:** step k consumes slot k−pp = k−2 through `main_stream.wait_event(slot.event)` (`update_pp_decode_requests` → `get_prev_sampled_outputs`).
- **Dependency analysis (all 39 stalls): FALSE.**
  - Step k's stall is released by the Int×8 receive posted by step k−1 (the OTHER micro-batch).
  - Step k's real input (the step k−2 receives) had completed a median 10.1 ms before step k's graph even started.
  - The host is far ahead: cudaGraphLaunch is issued about 62 ms before the GPU start.
  - In the k−1 receive chain, #1 Long×16 spins about 27-29 ms waiting for stage 1 to sample, and #2 / #3 queue behind it on stream 31.
- **Parity:** balanced 4 + 4 in every step; stage-1 step j sends exactly what stage-0 step j receives.
- **A related observation:** an earlier NB2 window ran all 8 requests in one parity (empty steps in the other). It showed no stall but also no overlap.
- **Ideal tick with the false dependency removed:** 34.6 ms, bound by stage-1 work, which is +43.5 % tok/s.
  - Another estimate, which counts stage 1's own receive wait, gives ~40-42 ms (+19-25 %).
  - With stages rebalanced, ~29 ms.

## Our hypothesis (UNVERIFIED)
A CUDA hardware work-queue (connection) false dependency.
- `CUDA_DEVICE_MAX_CONNECTIONS` is unset (default 8). The FULL graph forks ~90+ streams, and stream 31 shares a hardware queue with a graph branch.
- The broadcast at the head of stream 31 cannot complete until the peer stage arrives, so the graph branch behind it in the same queue cannot be dispatched.

## Our planned tests
1. `CUDA_DEVICE_MAX_CONNECTIONS=32` (env only); maybe also `=1` as a negative control.
2. A "Q-pack" patch: send one packed int64 [n, 2K+3] broadcast instead of three.
3. A "Q-defer" patch: post `PPHandler.receive` after the next `run_fullgraph` launch instead of before it.

Never-do, already measured or unsafe: `NCCL_GRAPH_MIXING_SUPPORT=0`, `NCCL_GRAPH_REGISTER=1`, forced LL128, P2P on, `--no-async-scheduling` with PP (deadlocks), CTA tuning, `NCCL_SHM_USE_CUDA_MEMCPY`.

## Questions (answer each with evidence: source lines, CUDA / NCCL docs, issues, PRs)
1. **Is the work-queue false-dependency explanation correct?** Explain exactly how CUDA maps streams, including graph-forked streams inside a cudaGraphLaunch, to hardware connections on sm_89 / Ada with driver 580 and CUDA 13.0. How does `CUDA_DEVICE_MAX_CONNECTIONS` interact with graphs? Can a kernel blocked at the head of one stream stall an unrelated graph branch? What other mechanisms fit the data: NCCL proxy / ordering across communicators, the NCCL graph-capture-mixing locks, `cudaStreamWaitEvent` inside the graph, PLE host-pull WaitValue32, or the `pp_broadcast` communicator sharing resources with the TP communicator in the graph?
2. **Will `CUDA_DEVICE_MAX_CONNECTIONS=32` fix it?** The graph uses more streams than 32. Which value is best? What side effects can it have on NCCL, on graph capture and on memory? Do NCCL, PyTorch or vLLM override or read it? Must it be set before CUDA init in every worker process (vLLM spawns workers)?
3. **Which code-level fix is cleanest and safe in vLLM 0.32 V2 PP?** The candidates:
   - packing the 3 broadcasts;
   - deferring the receive post;
   - a dedicated high-priority stream;
   - `torch.cuda.Stream(priority=...)`;
   - posting the receive only after the peer's data is ready (e.g. event-driven from the host);
   - replacing the broadcast with send/recv;
   - using a separate NCCL communicator per micro-batch parity.

   Check against the included `pp_utils.py` / `model_runner.py` / `async_scheduler.py` / `core.py`. Has upstream vLLM (later than 0.32) or SGLang changed this PP sampled-token relay? Cite PRs.
4. **Once the stall is gone, stage 1 binds.** It runs the target 20.2 ms + MTP drafts ~10.5 ms + lm-head 2.6 ms + commit 0.9 ms + collectives. What are the best options?
   - Move layers to stage 0 with `VLLM_PP_LAYER_PARTITION` (memory-limited).
   - Move the draft or sampler.
   - An INT8 draft lm-head.
   - Overlap the drafting with stage 0.
   - Change K.

   What tick is realistic?
5. **Is there anything in the traces that we misread?** For example, are the NCCL kernel durations measuring a spin wait, or are the graph-node ids stable?
6. **A concrete experiment plan:** at most 3 arms, each with the exact env / patch, what to log to prove the mechanism, and the expected effect.

## Files
**Measurements, analysis and plan:**
- `E25_GPU_NB1_R2_2026-10-31.md`: the NB1 R2 measurements plus the stall re-analysis.
- `nb4_b1_v2.json`: the full analysis output of the B1 traces.
- `NB4_RESEARCH_graphs_2026-11-01.md`, `NB4_RESEARCH_folders_2026-11-01.md`, `NB4_RESEARCH_conversations_2026-11-01.md`: our three internal research notes, with file:line evidence.
- `NB4_TICK_SPEC_2026-11-01.md`: the planned NB4 notebook.
- `PLAN_1500.md`: the throughput plan.

**Analysis code:** `nb4_timeline.py` + `nb4_timeline_tests.py` (stdlib). It parses torch-profiler Chrome traces into tick categories, in-graph stalls, parity and dependency.

**Raw traces and logs:**
- `trace_rank0..3_*.pt.trace.json.gz`: the raw torch-profiler traces of NB1 R2 boot B1, ranks 0-3.
- `server_nb1_b1_fp8.log`: the server log of that boot (flags, graph capture, NCCL init).

**Source files** (Merlin v3.0.0), named as path with `__`:
- `merlin_vllm__v1__worker__gpu__pp_utils.py`
- `…__model_runner.py`
- `…__cudagraph_utils.py`
- `…__async_scheduler.py`
- `…__scheduler.py`
- `…__core.py`
- `…__config__vllm.py`
- `…__parallel_state.py`
- `…__cuda_communicator.py`
