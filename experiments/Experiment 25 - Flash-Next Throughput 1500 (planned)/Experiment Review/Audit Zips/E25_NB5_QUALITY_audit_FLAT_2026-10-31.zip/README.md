# E25 NB5 QUALITY R2: paired FP8-KV vs BF16-KV ARC accuracy (Flash-Next on Merlin, Duck harness) — audit bundle

Flat zip: every file is at the top level, and a name prefix stands for the folder (`build__`, `docs__`, `notebook__`).

## Why
E25 NB0 measured teacher-forced FP8 QSA KV vs BF16 KV on Flash-Next. On the full prompt, rank-1 agreement is 0.90 (2k),
0.93 (8k), 0.75 (40k) and 0.66 (90k). The verdict is NO_GO_FP8_TF_DIVERGENCE (`docs__E25_GPU_wave1_NB0_NB1_2026-10-31.md`). MTP and
the sm_89 native cast are not the cause. Only a paired ARC accuracy run on the same tasks can still accept FP8. BF16 KV halves
the pool (269k vs 514k tokens), so the answer decides the production KV dtype.

## Design (notebook `notebook__Q27-XHIGH-E25_NB5_QUALITY.ipynb`, sha 6754a746…, 385 kB, profile NB5QUALITY_R2)
- One notebook, 4×L4, 180-min hard budget: phase Q_FP8_K3 (FP8 KV, MTP K3), then phase Q_BF16_K3 (BF16 KV, MTP K3), with
  separate boots.
- Equal solve windows, fixed when the first phase starts. A slow first boot shortens both. Unfinished attempts are recorded
  as INCOMPLETE_WINDOW / NOT_STARTED.
- The same 15 public-eval tasks in a fixed order, the same seeds (20261005), budget 104k per attempt, 2 attempts per task, no extra
  attempts, commit variant A, no SMOKE.
- Tasks (from `docs__tokens_to_solve.csv`, our Qwen3.8-27B Duck + Poetiq history):
  - solid: 1818057f, 45a5af55, bf45cf4b, 2ba387bc, 8f215267, 38007db0, 58f5dbd5;
  - sometimes: 247ef758, f931b4a8, b5ca7ac4, 65b59efc, 221dfab4;
  - never: 2b83f449, 16b78196, 64efde09.
- NB0's verdict is recorded and is not a gate. The FP8 phase is labelled UNVALIDATED_FP8_UNDER_TEST.
- Capacity levers, the same in both phases:
  - KV pin ladder: RC2 pin + 1.0 / 0.75 / 0.5 / 0 GiB per card. It steps down on a launch failure or OOM; the BF16 boot starts at
    the FP8 boot's working step.
  - The vLLM #60490 backport (NB1's strict applier, pre / post sha) reserves the QSA workspace at profile time.
  - `MERLIN_SHARE_DRAFT_WORKSPACE=1`, numerics-neutral, to reduce the fixed blocks F. It is dropped if it fails. F is taken from
    the server's own max-concurrency line.
  - Simple concurrency: workers = min(floor(pool / (16 + F)), launch max_num_seqs), with a seqs table of FP8 9 / 8 / 8 / 6 and
    BF16 5 / 4 / 4 / 3. The engine schedules; preemptions are allowed and counted (they flag speed only).
- Config read-back right after ready (C-11): KV dtype, max_num_seqs, pin bytes, speculative config. A mismatch gives
  INCONCLUSIVE_CONFIG_MISMATCH.
- Fixes in common code:
  - NB5-FATAL-1: missing `import tarfile`.
  - NB5-2: `E11Server` raises explicitly; pyflakes check in the builder.
  - A-12: phase failure propagates.
  - A-13: no room → no request.
  - A-14: `/tokenize` 2 retries, then a verified local tokenizer only.
  - C-7: need > pool is denied.
  - C-8: 0 workers → NO_GO_INSUFFICIENT_KV.
  - C-9: requests are clamped to the attempt's projected peak.
  - KIT-5 / KIT-6: kit fixes.
- Report: per phase, the windows, pool, pin, F, ladder tries, read-back, running, preemptions and tok/s. Per task and
  attempt, the outcome, tokens, time, exact match and pass@2. The paired summary covers all tasks and the tasks finished in both:
  solved FP8 / BF16, discordant tasks and the exact McNemar p.

## Evidence
- Local unit tests 126/126 (Py3.14 and Py3.12); kit mode 115/115 with 11 build-time checks skipped.
- The six earlier NB5 notebooks are unchanged and pinned.
- Kaggle CPU kits v2 (files `kits__*`, pinned image, Py3.12): **all 8 ALL OK** — units, real (incl. the lever env now in the server env, pin +1 GiB bytes, seqs 9 / 5, CAPS16 captures, #60490 applied + verified, host phase ×3, commit-turn A/C on the real checkpoint, budget guard, submissions), e2e quality / commit / rerun / mtp / notok / floor.
- Bug found by kit v1 and fixed: the lever `MERLIN_SHARE_DRAFT_WORKSPACE=1` was added before Merlin's `build()`, which drops every `MERLIN_*` variable; it is now applied to the server env after `build()`.

## Time estimate (builder agent, from RC2 / NB1 rates)
About 6.5 min for setup and about 14.5 min per boot, so each window is about 64 min.
- FP8 at about 9 workers runs about 250 tok/s aggregate, about 22 tok/s per stream.
- BF16 at about 5 workers runs about 190 tok/s, about 30 tok/s per stream.
- A full 104k attempt therefore needs 58-79 min, which is more than a window.
- Expected: all 7 solid attempt-1s finish in both phases. Of the sometimes tasks, 1-2 of 5 finish. The never tasks finish 0.
  So the comparison rests mainly on the solid tasks.
- Options not applied:
  - drop the 3 never tasks;
  - use the same lower budget in both phases (≥ 60k);
  - use longer windows (about 2 × 110 min ≈ 4.5 h).

## Questions for the audit (`00_AUDIT_PROMPT.md`)
