# E25 GPU wave 1: NB0 FP8 quality + NB1 capacity (2026-10-31)

Outputs: `_scratch/e25_gpu_out/q27-xhigh-e25-nb0-fp8-quality/`, `_scratch/e25_gpu_out/q27-xhigh-e25-nb1-capacity/`.

## NB0 (esfersami50, sha 37a427a2, 64.1 min): all 5 boots DONE, no abort
Teacher-forced prompt logprobs, last 256 positions ("last256") and the whole prompt ("full"); mean |Δlogprob| / rank-1 agreement.

| check | 2k | 8k | 40k | 90k |
|---|---|---|---|---|
| A/A every boot (same request twice) | 0 / 1.0 | 0 / 1.0 | 0 / 1.0 | 0 / 1.0 |
| self-consistency decode vs TF, every boot | 0.013-0.024 / 0.98 | 0.018-0.022 / 0.96-0.97 | 0.009-0.011 / 0.98-1.0 | — |
| same prefix in a longer prompt (BF16 and FP8 alike) | 2k~8k 0.177-0.190 | 8k~40k 0.010-0.012 | 40k~90k 0.0001-0.0004 | |
| AC / BD (MTP on vs off, same KV) | 0 | 0 | 0 | last256 0.61 / 0.45, full 0.006 / 0.004 |
| AB / CD FP8 vs BF16, last256 | 0.389 / 0.871 | 0.098 / 0.969 | **1.876 / 0.367** | 2.007-2.250 / 0.887-0.914 |
| AB / CD FP8 vs BF16, full | 0.352 / 0.897 | 0.220 / 0.934 | **0.932 / 0.749** | **1.337 / 0.661** |
| CE byte-decoder FP8 vs BF16, full | 0.335 / 0.904 | 0.231 / 0.929 | 0.959 / 0.740 | 1.293 / 0.667 |
| DE native FP8 vs byte-decoder FP8, full | 0.363 / 0.902 | 0.235 / 0.928 | 0.369 / 0.897 | 0.462 / 0.883 |

Verdict file: `fp8_native_production` and `fp8_byte_decoder` = **NO_GO_FP8_TF_DIVERGENCE** (40k / 90k), 8k SCREENING_PASS, 2k HOLD.
Findings: KV_DIVERGENCE_FROM_2K (AB, CD, CE), FP8_DIVERGENCE_NOT_THE_NATIVE_CAST, READ_PATH_CHANGES_LOGITS (DE 2k / 90k),
MTP_CHANGES_TARGET_LOGITS only at 90k last256, CROSS_REQUEST_NONDETERMINISM in every boot (= the 2k prefix scores ~0.18 apart
when it is part of a longer request; BF16 and FP8 alike), RC2 anchor reproduced exactly (40k last256 1.8764 / 0.3672).
Reading:
- The measurement is sound: A/A 0, self-consistency ~0.01-0.02, the RC2 number reproduces bit for bit.
- MTP does not cause it (AC / BD = 0 to 40k), and the sm_89 native cast does not cause it (CE ≈ CD; DE ≪ CD at 40k).
- FP8 QSA KV itself (static scales `qsa_kv_scales_262k.json` / e4m3 quantisation) diverges from BF16 and grows with context:
  full-prompt rank-1 0.90 (2k) → 0.93 (8k) → 0.75 (40k) → 0.66 (90k). On the 27B (E23 FULL) FP8 KV vs BF16 is rank-1 0.98 / mean
  0.06 at 40k, so this is Flash-Next QSA specific.
- Short-prompt noise floor: the 2k prefix moves 0.18 between request shapes in BF16 too, so the 2k FP8 number (0.35) is ~2× noise;
  at 40k / 90k the noise floor is 0.01 / 0.0004 and FP8 is 0.93 / 1.34 → real.
- Decision input: FP8 KV is not certified by TF; only a paired ARC accuracy run could still accept it. BF16 KV = 269,042 tokens
  (78 blocks) vs FP8 513,940 (149) → capacity, not just speed, becomes the bottleneck (low-bit experts, fixed blocks F).

## NB1 (hosen42, sha 47c8e3ae, 30.5 min) = B1 ERROR after its measurements, B2 / B3 SKIPPED_DEPENDENCY
- A0 Merlin install DONE; #60490 patch applied and verified (sha_after 88fe0a8f).
- B1 (FP8, text-only, #60490, profiler) booted and ran 26.6 min; post-processing crashed:
  `free_per_card()` (`nb1_code_export.py:1880-1881`) iterates `steady.values()` and one value is a list →
  `AttributeError: 'list' object has no attribute 'get'`; `step()` then kept only status / live_windows / error, so the B1 record
  (kv census, F fit, residency probes, scorecard inputs) was lost and B2 / B3 were skipped.
- Surviving B1 data: model loading **16.89-16.91 GiB per card** (RC2 17.33 / 16.87: PP0 −0.42 GiB from text-only), load 239-254 s
  per worker (RC2 worst 873 s: the page-cache drop works), KV pool 513,940 tokens = RC2 (pinned bytes), API start → KV ready ≈ 6.3 min.
- Live windows (FP8, steady, 0 preemptions): 8k@3 141.1 (a 3.18, step 33.8); **8k@8 280.0** (RC2 261.8, +7 %; a 3.157, step 90.2);
  40k@5 195.3 (RC2 190.5, +2.5 %); **40k@8 248.6** (kv max 1.0, 0 preemptions; RC2 never ran 40k@8).
- Fix (NB1-BUG-1): `isinstance(w, dict)` in free_per_card; `step()` keeps the partial record on a post-processing exception
  (status `POSTPROCESS_ERROR`, dependents still allowed when the boot itself was clean). NB1-BUG-2: a unit test with a list-valued
  steady entry; the local fake e2e did not produce one.
