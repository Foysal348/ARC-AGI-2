# GO / NO-GO: E25 NB5 QUALITY R2 (paired FP8 vs BF16 KV accuracy)

Read `README.md`, the notebook (or `build__nb5_code_export.py`, `build__nb5_lib.py`, `build__build_e25_nb5.py`) and the docs.

Answer:
1. Is the A/B fair? Check that only the KV dtype differs between the phases (same tasks, order, seeds, budgets, prompts, Duck
   config, MTP, pin step, F lever, captures), that the read-back proves it, and that the equal-window rule holds.
2. Can the result be trusted when many attempts end INCOMPLETE_WINDOW? Is the paired summary (finished-in-both, McNemar)
   computed correctly, and what is the smallest change (task set, budget ≥ 60k, window) that makes the test informative within 3 h?
3. Any fatal blocker: crash, wrong raw data, wasted GPU, pin-ladder OOM handling, #60490 patch, phase failure handling,
   the A-13 / A-14 / C-7 / C-8 / C-9 / C-11 fixes. For each: file:line, scenario, minimal fix, a test.
Labels and nice-to-haves go into a separate "after the run" list.
Output: `VERDICT: GO` or `VERDICT: NO-GO`, then the blocker list (may be empty), then the after-the-run list.
