# E25 NB1 R2 (capacity) — audit bundle (2026-10-31)

## What NB1 measures
Flash-Next on Merlin v3.0.0, 4×L4, TP2×PP2 + EP, MTP K3, FP8 KV. Three cold boots, 240-min budget:
- B1: RC2 FP8 config + text-only (`--language-model-only`) + the vLLM #60490 backport (QSA indexer workspace reserved at
  profile time; pre / post sha verified) + profiler. KV census, F fit (fixed blocks per request), residency probes
  (max safe running streams per context 8k / 40k / 90k), ladder windows.
- B2: B1 + the F / state-slot levers.
- B3: B2 + a KV pin ladder (+1.0 / +0.75 / +0.5 GiB per card, descending).
B2 / B3 run only after a clean B1.

## What happened in R1 (folder `failed_r1_run/`, Kaggle hosen42, sha 47c8e3ae, 30.5 min)
- B1 booted and measured for 26.6 min. Live windows FP8, steady, 0 preemptions: 8k@3 141.1, 8k@8 280.0 (RC2 261.8),
  40k@5 195.3 (RC2 190.5), 40k@8 248.6. Model loading 16.89-16.91 GiB per card (RC2 17.33 / 16.87). Load 239-254 s per worker
  (RC2 worst 873 s: the page-cache drop works).
- Then `free_per_card()` crashed: `steady` carries bookkeeping keys `_plan` (list), `_fit` (dict) and `_seqs_cap` (int) next to the
  windows → `AttributeError: 'list' object has no attribute 'get'`. `step()` kept only status / live_windows / error, so the B1 record
  was lost and B2 / B3 were SKIPPED_DEPENDENCY.
- Also found: B1's F fit was −5.32 (invalid). The idle KV reading right after a successful `/reset_prefix_cache` was stale
  (`kv_cache_usage_perc` refreshes only on engine steps, so 45.6 % / 26.8 % from the last step was used), so ~68 / ~40 phantom
  idle blocks were subtracted. A successful reset proves 0 blocks in use.

## R2 changes (notebook `notebook/Q27-XHIGH-E25_NB1_CAPACITY_R2.ipynb`, sha 5bb24675…, 340 kB)
1. `free_per_card` and `_conf` read only dict windows; type checks on every reading.
2. Post-processing never discards measurements. `keep_after_error()`: a clean boot stays DONE with `postprocess_error` / tb,
   so B2 / B3 still run. A not-clean boot → `POSTPROCESS_ERROR` with `status_before_postprocess`. `step()` keeps the body record
   on an exception after the body returned. `watched()` publishes the body record as soon as it returns.
3. `fit_alloc`: idle = 0 when the reset reply says success; the gauge reading is kept as `idle_gauge_blocks`.
4. F validation: a fitted F is valid only if finite and 0 ≤ F ≤ 40.
   - Invalid → F from THIS boot's own server log line ("GPU KV cache size: N tokens, Maximum concurrency for M tokens per
     request: X x"): F_log = P / X − ceil(M / B), F = ceil(F_log − 0.05). B1 → 5.999 → 6.
   - Neither valid → INCONCLUSIVE_CAPACITY_UNKNOWN (no probes).
   - `nb1_ladder` uses the same validated F (B1: the extra level becomes 40k@7 instead of 40k@8 from F −5.32).
Unchanged: budget 240 min, boots B1 / B2 / B3, the pin ladder, C-6 (probes from the boot's own pool and F).

## Evidence
- Local unit tests: Py3.14 **117/117 PASS** (`tests/r2b_unit314.log`). Py3.12 116/117 (`tests/r2b_unit312.log`); the one
  failure is "worker ext: routing stop", because the local venv has no torch (the Kaggle image has it). It is not an R2 check.
- New fixture `build/nb1_fixture_b1_gpu_2026-10-31.json`: the real B1 crash record, live windows, argv tail and verbatim server-log
  lines (max-concurrency line, both alloc sequences), with shas. The R2 tests replay it.
- Kaggle CPU kits for R2 (folder `kits/`, pinned image, Py3.12):
  - units kit (hosen42) **ALL OK**: units 117/117, fake e2e all pass.
  - real kit (foysalemonshanto): every check OK (inputs, merge, sha256, prompt hashes, RC2 oracle prompts, Merlin install,
    #60490 applied + verified, tree restored, host phase, worker extension, no engine procs, page-cache drop) except
    `argparse_fields_ok`. Merlin's CPU parser raises "Failed to infer device type" without a GPU; this is a known
    CPU-container limit seen in every real kit, not an argv defect.
- The R1 notebook (47c8e3ae) is unchanged and pinned in the builder.

## Files
`notebook/`, `build/` (builder, kit builder, export, units, fake server, local e2e, fixture, `patches/` with the #60490 patch),
`tests/`, `failed_r1_run/` (R1 notebook + full GPU output incl. server log), `docs/` (wave-1 NB0 / NB1 results, RC2 analysis,
PLAN, batch list), `00_AUDIT_PROMPT.md`.
