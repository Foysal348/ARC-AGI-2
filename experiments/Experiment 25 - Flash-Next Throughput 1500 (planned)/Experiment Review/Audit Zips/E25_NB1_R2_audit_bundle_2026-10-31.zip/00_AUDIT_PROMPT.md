# GO / NO-GO: E25 NB1 R2 capacity notebook

Read `README.md`, then `notebook/` (or `build/nb1_code_export.py` + `build/build_e25_nb1.py`), the R1 GPU output in
`failed_r1_run/output/` (results JSON, server log) and the fixture in `build/`.

Answer:
1. Are the two R1 defects really fixed? The free_per_card crash and lost record; the stale idle reading → negative F. Can any
   other post-processing path still lose a boot's measurements or skip B2 / B3 wrongly?
2. Is the F fallback correct? Check the server max-concurrency line formula, the rounding, the 0-40 validity range, and that probes
   and ladder use the same F.
3. Is there any other fatal blocker: crash, wrong raw data, wasted GPU, a wrong pin-ladder step, OOM risk not handled?
   For each: file:line, failure scenario, minimal fix, a test.
Labels, wording and nice-to-haves go into a separate "after the run" list.
Output: `VERDICT: GO` or `VERDICT: NO-GO`, then the blocker list (may be empty), then the after-the-run list.
