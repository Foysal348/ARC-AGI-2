# E25 NB6Q SUBMIT: blocker audit (2026-11-01)

**Answer format.**
- **Line 1:** exactly `GO` or `NO-GO`.
- **Then blockers only.** A blocker is something that can lose the hidden-rerun submission, score, or time; corrupt the Merlin tree; hang the engine; or make the patch run while unverified.
- **For each blocker, give:**
  - the file and line (or the function name);
  - the concrete failure scenario;
  - the minimal fix.
- **Leave out:** style points, nits, refactors, new levers and "nice to have" items.
- **If there is no blocker:** answer `GO` and nothing else.

## What NB6Q is
NB6Q is the proven NB6 SUBMIT notebook (`Q27-XHIGH-E25_NB6_SUBMIT.ipynb`, sha 87afcc84, GPU-committed) plus exactly ONE change: the Q-defer patch.

**The Q-defer patch.** It is the deferred PP receive in `nb4_ppack.py` rev 2. It is env-gated by `NB4_PPDEFER=1` and touches three Merlin v3.0.0 (vLLM 0.32 fork) files:
- `vllm/v1/worker/gpu/pp_utils.py`
- `vllm/v1/worker/gpu/model_runner.py`
- `vllm/v1/worker/gpu_worker.py`

**The evidence** is in `E25_NB4S_GPU_v1_2026-11-01.md`, from NB4S notebook fa9f35ca:
- +21.1 % at 8k@8 and +19.8 % at 40k@8;
- the oracle was EXACT;
- the stage-0 stall went from 19.81 ms to 0.035 ms;
- the read-back was ENGAGED (exec share 0.965, fallback share 0).

## The NB6Q edits
Every NB6Q edit is marked "NB6Q" in the notebook. `NB6_to_NB6Q_cells.diff` shows the diff of every cell. Only the markdown cell and the engine cell differ.

1. **Q1, at the end of the engine cell.** This is a short loader plus one packed literal (json, then lzma, then base85). It holds two files verbatim, each sha256-checked:
   - `nb4_ppack.py`, sha 8dadf076, which is the module NB4S ran;
   - `nb6q_lib.py`, sha 366ed68f, the NB6Q functions. This file is exec'd into the notebook namespace.

   The packing is needed because the notebook must stay under 400 kB (it is 398,924 B). NB6 is 377,053 B; inlining the code made it 402,533 B. This is the same pattern NB5 uses for `nb5_lib`.

   A load failure leaves NB6 behaviour unchanged and defines a stub `nb6q_readback`.

   **The `nb6q_lib.py` functions:**
   - **`merlin_install` wrapper.** It calls NB6's install, then `nb6q_apply`, once.
     - CELL 8's step A0 is the first call. That is before the sha gate, #60490 and any boot.
     - It happens in both commit and rerun.
   - **`nb6q_apply`.** It takes a snapshot of the three files, then runs `apply_ppack_patch`: strict pre-sha, post-sha, marker, and `py_compile` with the Merlin venv python. Then `verify_ppack_patch` and the post shas are checked again.
     - **On ANY exception:** the files are restored byte for byte from the snapshot, in the REVERSE dependency order (`gpu_worker.py`, then `model_runner.py`, then `pp_utils.py`), stopping at the first failed write. The pyc files of all three are then dropped. A loud log line is written to stdout and stderr, the state is set to `FAILED_*`, and no env is set.
     - **Why that order (rev 2, after a GPT audit):** patched `model_runner.py` calls `pp_handler.flush_deferred_receive` unconditionally, and only patched `pp_utils.py` defines it. Restoring in the old order could leave an original `pp_utils.py` under a patched `model_runner.py`, which raises AttributeError on every decode step. With the reverse order and the stop, any partial restore leaves the patched files as a prefix of pp_utils → model_runner → gpu_worker. That state is consistent: with `NB4_PPDEFER` unset, patched files behave as the originals. `NB6Q["consistent"]` records it.
     - **It never raises.**
   - **`merlin_fn_server` wrapper.**
     - It removes `NB4_PPDEFER` and `NB4_PPACK` from the launch env.
     - It sets `NB4_PPDEFER=1` only when the patch is verified applied.
     - NB6's watchdog relaunch (`e21_relaunch`, unchanged) calls `merlin_fn_server`, so a relaunched server gets the same env. This is a known NB6 behaviour.
   - **`nb6q_readback`.** It runs `readback_label` over the `NB4_PPQ` lines of the launch log, streamed. Its result is recorded only:
     - in the boot try (`trec["nb6q_readback"]`);
     - in `NB6Q["readbacks"]`;
     - in `nb5_report.json` under `nb6q_ppdefer`;
     - in the log.

     It never raises and never stops a run, in commit or rerun. NB6's other read-backs behave the same way.
2. **Q2:** one inserted line in `nb5_boot_try`, `nb6q_readback(trec, s, "after_warmup")`.
3. **Q3:** one inserted line after the boot's `with_servers` returns, `nb6q_readback(trec, srv, "final")`.
4. **Q4:** the markdown header.

**Unchanged (NB6 bytes):**
- CELL 0 (E18 R2 = E15B);
- CELL 1: profiles RERUN_PROD 717 min and NB6COMMIT 50 min with 3 tasks, and all levers;
- the Duck path;
- ORDER2;
- the E15B writer;
- E18's server ladder, readiness, retry and fast kill;
- no sha gate in the rerun;
- CELL 6/7, CELL 8 and CELL 9.

**FAKE-mode hook.** `NB6Q_FAKE_TREE` is read only when `FAKE` is set (`E11_HARNESS=1`). It exists for the CPU kits' fake server.

## Tests run locally (Windows, Python 3.14)
- **`nb6q_unit_tests.py`:** 53 / 53 PASS. One case is skipped: the POSIX-only venv-python path, which the Kaggle real kit runs.
  - S1 static: 20.
  - S2 functional: 30, on copies of the real Merlin ad42e37 source. It covers the applied path, env only when applied, a foreign tree, a failure after the write (byte-for-byte restore), the restore failing, a failure on the 1st, 2nd and 3rd restore write (each leaves a consistent tree and no `NB4_PPDEFER`), a negative control (the old order with a 2nd-write failure leaves an inconsistent tree, and it is detected), the consistency rule, an embed sha mismatch, a load failure, an install failure, and every read-back label.
  - S3: 2. One is `nb6_unit_tests.py` on NB6Q: 85 / 86, where the only fail is the NB6-only push-id check, as expected. The other is the NB6Q push metadata.
  - S4: 1, which runs `nb4_ppack_tests.py` (247 / 247).
- **CPU kits:** built, not yet run. See `build_e25_nb6q_cpu_kit.py` and `NB6kit_to_NB6Qkit_effective.diff`. There are 4 kits: units, e2e-rerun, e2e-commit and real. The e2e-commit kit now expects 50 min; NB6's kit wrongly expected 40.

## Known facts to weigh (are any of them blockers?)
- **NB4S tested Q-defer in a narrower setup than NB6's production config:**
  - 8 streams;
  - its own capture list `[1..32]`;
  - profiler on;
  - **no** `MERLIN_SHARE_DRAFT_WORKSPACE=1`;
  - short windows, with 0 preemptions.

  NB6Q runs it with `MERLIN_SHARE_DRAFT_WORKSPACE=1`, launch seqs 9 / 8 / 8 by pin step, CAPS16 captures `[1..64]`, 104k-token attempts, prefix caching and about 12 h of Duck traffic, including preemptions.
- **An applied patch that later makes a boot fail** (not ready, or a stall) goes down E18's ladder to the next pin step with `NB4_PPDEFER=1` still set. No no-defer fallback was added, because the "nothing else changes" rule applies.
- **The final read-back** reads only the `NB4_PPQ` lines of the whole server log, streamed. It runs after the server stopped, inside the time the rerun has after its solve.

## Files in this zip (flat)
- **The notebook and its build:**
  - `Q27-XHIGH-E25_NB6Q_SUBMIT.ipynb`, sha 499a4319;
  - `build_e25_nb6q.py`;
  - `nb6q_code_export.py`;
  - `nb6q_build_facts.json`.
- **The patch module and its tests:**
  - `nb6q_lib.py`, the readable form of the packed functions;
  - `nb4_ppack.py`;
  - `nb4_ppack_tests.py`;
  - `nb6q_unit_tests.py`.
- **The CPU kit builder:** `build_e25_nb6q_cpu_kit.py`.
- **The evidence:** `E25_NB4S_GPU_v1_2026-11-01.md`.
- **NB6, for diffing:**
  - `build_e25_nb6.py`, NB6's builder;
  - `NB6_to_NB6Q_cells.diff`;
  - `NB6kit_to_NB6Qkit_effective.diff`.
- **The local test logs:**
  - `LOCAL_nb6q_unit_tests.log`;
  - `LOCAL_nb6_unit_tests_on_nb6q.log`;
  - `LOCAL_nb4_ppack_tests.log`.
