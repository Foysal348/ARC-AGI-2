# FINAL GPU audit: NB-S1 (DFlash2 D3s base + 5 lever arms), Kaggle 4xL4, klee100 on Merlin v3.0.0

**Answer GO or NO-GO on the first line. Then list ONLY BLOCKERS and SEVERE bugs** (crash, an arm that cannot launch, a wasted
run, wrong data recorded, an arm skipped by anything but a real failure / the time budget). Each with file:line, why, fix.
No style items, no new features. Verdict-label / ranking quality is out of scope (deferred by the user; raw numbers are read
by hand).

The GPU notebook is `NB__PUSH_q27-xhigh-e25-nbs1.ipynb` (sha f7dc469c2cc7b9eecd11f83783b4e5695fdbb189c4a480045b9664431d464206), the GATED build (KV gate open from the real kit:
`KIT__nbs1_real_report_ALL_OK.json`; `VERIFY__nbdf_gate_verify_output.txt` ok, exit 0).
- Arms: B = NBDF-K100 D3s (DFlash2 K3, SW-1024, BF16 drafter KV, seam, seqs 24, pin 7,933,526,016), then G1
  (VLLM_GDN_DECODE_FASTPATH=1), G2 (VLLM_GDN_SHARED_ALIGN_INDEX=1), EH (DFLASH_DRAFT_EMBED_HOST=1), F8 (fp8 drafter KV,
  TRITON_ATTN, SW 2048), DYN (num_speculative_tokens_per_batch_size [[1,8,4],[9,24,3]]).
- The previous NBDF-K100 GPU run died at capture for every DFlash arm: Merlin's `v1/e2_guards.py` did not know the DFlash
  speculator's `query_cudagraph_manager`. Fixed by the seam edit GRD (`BUILD__dflash_seam.py`) and checked on the real
  installed tree in the real kit (R13, `e2_guard_dflash_ok`). The same run lost Q's later items to a LOW_VARIETY garbage
  heuristic on ARC digit grids; now only hard breakage (EMPTY / REPEATED_CHAR / BANG / request errors / NaN / zero accept /
  launch failure) stops an arm; heuristics are recorded only (`REPORT__B1_B2_fix_agent_report.md`).

Questions: (1) after the gate, can any arm be skipped or stopped by anything except a real failure of that arm or the time
budget? (2) anything else that would make DFlash2 fail at boot / capture / first decode on GPU that the CPU kit cannot see?
(3) does any arm's env / argv differ from its plan? List each with file:line.
