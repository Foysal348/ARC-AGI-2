# Review: generated-tail prefix checkpoint for Merlin (vLLM 0.32 fork), Qwen3.8-Flash-Next hybrid GDN+QSA, TP2 x PP2, MTP K3, RecoverSSM, mamba_cache_mode align

Read DESIGN__generated_tail_checkpoint.md first (and the DATA report: 72.7 % of fresh prefill is the previous turn's generated
tokens; a perfect checkpoint is worth ~6-8 % of the run). Merlin source files are included (MERLIN__*), plus a pure-python
prototype of the position / fence logic with tests (PROTO__*).

Answer: (1) Is Option B (publish the 4096-boundary state the decode commit already writes; producer rule + PP fence
processed_step_seq >= T + pp_size; attention partial key at floor(valid/64)*64; grace pin) CORRECT? List every way it could
publish a wrong or stale recurrent state (PP0 late commit, block reuse, MTP reprefillable tokens, stop truncation, aborts),
with file:line in the included source. (2) Concrete minimal patch for Option B: exact functions / lines to change, as a diff
sketch. (3) Is there a simpler correct design we missed? (4) The cheapest decisive GPU test and its pass gates.
Be concrete; no generic advice.
