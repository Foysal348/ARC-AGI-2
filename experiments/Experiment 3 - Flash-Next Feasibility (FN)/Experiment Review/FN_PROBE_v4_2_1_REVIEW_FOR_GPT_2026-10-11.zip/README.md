# FN-PROBE v4.2.1 — third review bundle (2026-10-11)

This follows your second review of v4.2. You wrote that with four small patches you would say **GO**. Every point you raised was checked against the code before it was changed.

**Notebook:** `notebook/FN-PROBE-FLASHNEXT-v4_2_1.ipynb`. For the diff, `notebook/FN-PROBE-FLASHNEXT-v4_2.ipynb` is included.

## Your v4.2 findings → v4.2.1

| Your finding | Checked | Change |
|---|---|---|
| P0: the decode estimate used the warm-up timing, which includes first-use JIT | True. Eager mode JIT-compiles Triton kernels on the first use of each batch shape. | The warm-up is no longer timed. A timed 256-token calibration run follows it, and `incremental_decode_tok_s_est = (tok_main − tok_cal) / (wall_main − wall_cal)`. |
| Add SGLang's own metric | True. `metrics_reporter.py:892` prints `gen throughput (token/s): X`. | `server_gen_tok_s_median` and `server_gen_tok_s_samples` come from the serve.log slice written during the main run. |
| P0: stage 6 could PASS with only incomplete rows | True. The old test was `any("aggregate_tok_s" in r)`. | Stage 6 passes only if the full-concurrency row (`LEVELS[0]`) is complete; the report adds `full_concurrency_complete`. |
| P1: the preflight did not check the prefetch flags or the exact version | True | `need` now includes `--weight-loader-prefetch-checkpoints` and `--weight-loader-prefetch-num-threads`. The probe asserts `sglang.__version__ == '0.5.19+gd00d88efc8d6'`. |
| P1: the r4 fallback's graph reload used `--cuda-graph-max-bs 8` | True | It now uses `str(SERVER_MAX_RUNNING)`. |
| Cell 8 printed "BELOW" when nothing was measured | True (`or [0]`) | Prints `THROUGHPUT: NO VALID COMPLETE MEASUREMENT` instead. |
| Stale non-listening GPU worker | Plausible | `gpu_apps_before` records the `nvidia-smi --query-compute-apps` output before every launch. **Report only, no abort.** We could not rule out that Kaggle shows unrelated or own processes there, and a false abort would waste the run. |
| Harness was not self-contained | True | `os.chdir(HERE)` at the start, and synthetic ARC fixtures are generated in the temp dir. |

Unchanged, as you recommended: lookahead prefetch with 4 threads, 2048 decode tokens, the 15-min reserve, TP4/EP4, and the shim.

## Local verification
- `build/test_shim.py`: all PASS.
- `harness/fn_harness.py`: **10/10 PASS** — `ok`, `short_main` (new), `stall_a1`, `slow_a1`, `exit_a1`, `orphan_a1`, `stale`, `graphs_fail`, `rerun`, `slow_both`.
  - The fake server now has a 0.4 s one-off "JIT" on the first request of each size.
  - It also prints SGLang-style `gen throughput` lines.
  - With `FAKE_SHORT=1` it returns decodes that stop early.
- **Estimator check (`ok`).** The true fake decode rate is 2000 tok/s per request.

  | Concurrency | `incremental_decode_tok_s_est` | True rate | `aggregate_tok_s` (includes prefill) |
  |---|---|---|---|
  | 8 | 16,061 | 16,000 | 9,459 |
  | 4 | 8,048 | 8,000 | 6,149 |
  | 1 | 2,011 | 2,000 | 1,541 |

- **`short_main`.** Stage 6 FAILs (`stopped_at = 6_throughput_eager`), cell 8 prints `NO VALID COMPLETE MEASUREMENT`, and stage 7 is skipped.
- **r4 scenarios.** The graph relaunch uses `--cuda-graph-max-bs 4` (the harness asserts this).
- **Still untestable locally:** real Linux process groups (you tested `orphan_a1` on Linux), the real SGLang and GPU, and cells 2–5.

## Question
Is v4.2.1 a GO for the Kaggle 4×L4 run? If not, which concrete line or lines would waste the run?

## Files
`notebook/`, `build/` (v4.2.1 builder and generated source, `c_probe.txt`, shim and test), `harness/` (`fn_harness.py`, `serve`, `outputs/`), `run1_v4_outputs/`.
