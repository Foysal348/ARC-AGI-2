# Review request R3: FN-SMOKE v3.1 after the first real 4×L4 run

The overlay upload succeeded: 22 files, 51.244 GB, sizes verified through the Kaggle API. FN-SMOKE v3 then ran once on
Kaggle 4×L4 (run evidence in `run1_2026-10-05/`).

v3.1 fixes the launch. Before the next 4×L4 run (~1.7 quota-hours), please check the launch arguments against the
Pennyroyal source excerpts in `evidence/`. You do not have the wheel, so the relevant source is quoted there.

Report real defects only. Cite the file and line for each, and for every claim say whether it was verified against the
quoted source or inferred.

## Run 1 facts (`run1_2026-10-05/fn_smoke_report.json`, `serve.log`)
| stage | result |
|---|---|
| 0 environment | PASS. 4×L4 (8.9), driver 580.178.04 / CUDA 13.0, RAM 202.6 GB total / 198.9 GB available, 48 CPUs, /tmp 1.1 TB. **RLIMIT_MEMLOCK soft = hard = 8 MiB (could not be raised).** |
| 1 inputs | PASS. 25 shards (15 Intel + 10 overlay); full SHA256 of 124.8 GB matched in 192.5 s; config `ple_embedding_dtype = float8_e4m3fn`. |
| 2 install | PASS (30 s), `sglang-0.5.19+gd00d88efc8d6` |
| 3 preflight | PASS. torch 2.13.0+cu130, triton 3.7.1, 4×(8,9), matmul OK. Harmless note: Kaggle's sitecustomize cannot import `wrapt` inside the venv. |
| 4 launch | **FAIL, both attempts after ~15 s, in argument resolution**: `ValueError: --language-model-only does not support ['Qwen4ExpForConditionalGeneration']. Supported: ['MuseGlimmerForConditionalGeneration']` |

## v3.1 changes (`build/patch_v3_1.py`)
1. `--language-model-only` is removed. It was added in v2 on the R1 reviewer's "minimal profile" advice without
   checking its support (`evidence/pennyroyal_launch_arg_rules.txt`, `LANGUAGE_MODEL_ONLY_ARCHITECTURES`).
2. The next check would also have failed:
   - Qwen4Exp's compressed QSA pins `page_size = 64` (`evidence/pennyroyal_qwen4exp_overrides.txt`).
   - The default mamba radix strategy `no_buffer` asserts `page_size in (1, None)`.
   - Attempt 1 therefore uses dfranzen's settings: `--mamba-radix-cache-strategy extra_buffer --mamba-track-interval 64`
     (`evidence/dfranzen_launch_args.txt`).
   - `extra_buffer` is allowed for Qwen4Exp when `linear_attn_backend == "triton"`, which is the default, and needs
     `mamba_track_interval % page_size == 0`.
3. Attempt 2, the most conservative: `--disable-radix-cache --attention-backend triton --moe-runner-backend triton`.

Unchanged base profile:
- `--tensor-parallel-size 4 --ep-size 4`, `--quantization auto-round`, `--ple-offload-embedding`
- `--kv-cache-dtype auto`, `--context-length 8192`, `--max-running-requests 1`
- `--chunked-prefill-size 2048 --max-prefill-tokens 4096`, `--max-mamba-cache-size 4`
- triton mamba / linear-attention decode / prefill backends
- `--disable-cuda-graph` (deprecated alias; only warns), `--mem-fraction-static 0.80`

## Questions
1. Using only the quoted rules, will any v3.1 argument combination still fail in argument resolution? Consider
   TP4 + EP4 + auto-round + extra_buffer + page 64 + chunked prefill 2048 (the source warns when chunked prefill is
   smaller than `mamba_cache_chunk_size`).
2. Memlock is 8 MiB and cannot be raised. The PLE table (51.2 GB total, 12.8 GB per rank) is pinned with
   `mmap(MAP_PRIVATE|MAP_ANONYMOUS)` + `cudaHostRegister(PORTABLE|MAPPED)` (`evidence/pennyroyal_ple_pinning.txt`).
   - My position: the NVIDIA driver's page pinning is not charged against RLIMIT_MEMLOCK.
   - Supporting fact: dfranzen pins the 102 GB BF16 table the same way on Kaggle without touching ulimit.
   - Agree or disagree, with evidence. If you disagree, what is the fallback?
3. Is the attempt order right: attempt 1 close to dfranzen's flags, attempt 2 all-triton with no radix cache?
   Would you change any other flag for a first load on sm89?
4. Anything else that would waste the next 4×L4 run?

## Reproduce
```
python build/validate_v3.py                                      # includes static checks of the v3.1 launch arguments
python build/patch_v3.py && python build/make_fn_smoke_v3.py && python build/patch_v3_1.py && python build/make_fn_smoke_v3_1.py
```
