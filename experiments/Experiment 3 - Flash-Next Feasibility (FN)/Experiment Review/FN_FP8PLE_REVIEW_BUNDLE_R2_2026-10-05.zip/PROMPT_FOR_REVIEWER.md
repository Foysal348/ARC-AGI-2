# Review request R2: FN-PLEFP8-UPLOAD + FN-SMOKE v3 (Qwen3.8-Flash-Next W4A16 + FP8 PLE on Kaggle 4×L4)

This is round 2.

1. Read `REVIEW_RESPONSE_R1.md` first. It holds my verdict on each of your round-1 claims, with evidence. Where I
   marked a claim INCORRECT, check my evidence and either accept it or show why it is wrong.
2. Then review the notebooks again. Report real defects only, citing the cell and line for each.

## Layout (all paths relative; nothing outside the zip is needed)
- `notebooks/FN-PLEFP8-UPLOAD.ipynb`
  - CPU, internet ON, run once from the Kaggle editor with secrets attached.
  - Streams 21 files (51.24 GB) from albucino@c6af9fe on HF into a private Kaggle model of foysalemonshanto.
  - Hash-verified; the instance is created only if every hash matches; the final verification is fail-closed.
- `notebooks/FN-SMOKE-FLASHNEXT-FP8PLE-4XL4.ipynb`
  - 4×L4, load-only, 50-min deadline.
  - Builds the model folder from the 15 main shards of dfranzen's Intel mount plus everything else from the overlay.
  - Verifies each shard: size, header hash and full SHA256.
  - Gates: 4×L4 sm89, driver ≥ 580 / CUDA 13, MemAvailable ≥ 75 GB (re-checked before launch), /tmp ≥ 25 GB.
  - Then Pennyroyal install, preflight, TP4+EP4 launch, and one 64-token generation.
  - Dual mode: in a competition rerun it writes only a fallback submission.json.
- `reference/`: the proven ARC-AGI-3 uploader the first notebook is built from.
- `build/`: manifest (pinned HF hashes), builders, validators and their outputs.
- `tests/fake_comp/`: tiny competition files for the local runs.

## Reproduce
```
python build/validate_upload.py            # add --network to also test the real HF reader
python build/validate_v3.py
python build/adapt_streaming_uploader.py   # rebuilds notebooks/FN-PLEFP8-UPLOAD.ipynb from reference/ (same sha256)
python build/patch_v3.py && python build/make_fn_smoke_v3.py   # rebuilds the smoke notebook from the reviewed v2 builder
```

## Verified facts (unchanged from R1)
- albucino's 15 main shards are byte-identical to Intel@4c67bf6 (LFS sha256).
- albucino's config = Intel's config + `text_config.ple_embedding_dtype: "float8_e4m3fn"`.
- Pennyroyal builds the PLE as FP8 for that dtype. With `--ple-offload-embedding` it is built on meta and then pinned
  once, at exact size, via mmap + cudaHostRegister. Embeddings are multiplied by `weight_scale`.

## Questions
1. Do you accept the R1 ledger, especially #1 (license label) and #3 (memlock)?
2. Any remaining defect that would waste the upload (51 GB) or the 4×L4 run (≈1.7 quota-hours)?
3. Is the run order right: upload first, then the smoke?
