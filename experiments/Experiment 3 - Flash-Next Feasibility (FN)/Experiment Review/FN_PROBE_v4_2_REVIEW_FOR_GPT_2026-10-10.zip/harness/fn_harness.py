"""Local harness for FN-PROBE v4.2 cells 1, 6, 7, 8 with a fake `sglang serve` (./serve) and time scaled by _S
(1 notebook minute = 60*_S seconds). Cells 2-5 (install, inputs, shim) need Kaggle and are skipped.
Windows: process groups are emulated (env FAKE_PG inherited by the fake server's children) and os.killpg is shimmed.
usage: python fn_harness.py <notebook> <scenario>"""
import json, os, shutil, signal, socket, subprocess, sys, tempfile, time
from pathlib import Path
import psutil

NB, SC = sys.argv[1], sys.argv[2]
HERE = Path(__file__).resolve().parent
COMP = HERE.parent / "fake_input" / "competitions" / "arc-prize-2026-arc-agi-2"
_S = 0.02
PORT = 8001

# ---- Windows shims: emulated process groups
if not hasattr(signal, "SIGKILL"):
    signal.SIGKILL = 9
def _group(pgid):
    out = []
    for p in psutil.process_iter(["pid"]):
        try:
            if p.pid == pgid or p.environ().get("FAKE_PG") == str(pgid):
                out.append(p)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass
    return out
def _killpg(pgid, sig):
    procs = [p for p in _group(pgid) if p.is_running() and p.status() != psutil.STATUS_ZOMBIE]
    if not procs:
        raise ProcessLookupError(pgid)
    if sig == 0:
        return
    for p in procs:
        try: p.kill()
        except psutil.NoSuchProcess: pass
if not hasattr(os, "killpg"):
    os.killpg = _killpg

def port_open():
    try:
        with socket.create_connection(("127.0.0.1", PORT), timeout=0.3): return True
    except OSError: return False

def fake_leftovers():
    out = []
    for p in psutil.process_iter(["pid", "cmdline"]):
        try:
            if p.environ().get("FAKE_PG"): out.append((p.pid, " ".join(p.info["cmdline"] or [])[-80:]))
        except (psutil.NoSuchProcess, psutil.AccessDenied): pass
    return out

assert not port_open(), "port 8001 busy before the harness started"
modes = {"ok": dict(A1="ok:3", A2="ok:3", G="ok:3"),
         "stall_a1": dict(A1="stall", A2="ok:3", G="ok:3"),
         "slow_a1": dict(A1="slow", A2="ok:3", G="ok:3"),
         "exit_a1": dict(A1="exit", A2="ok:3", G="ok:3"),
         "orphan_a1": dict(A1="orphan", A2="ok:3", G="ok:3"),
         "stale": dict(A1="ok:3", A2="ok:3", G="ok:3"),
         "graphs_fail": dict(A1="ok:3", A2="ok:3", G="exit"),
         "rerun": dict(A1="ok:3", A2="ok:3", G="ok:3"),
         "slow_both": dict(A1="slow", A2="slow", G="ok:3")}[SC]
work = Path(tempfile.mkdtemp(prefix="fnh_"))
os.environ.update({"FN_SMOKE_WORK": str(work), "FN_SMOKE_COMP": str(COMP)})
os.environ.pop("KAGGLE_IS_COMPETITION_RERUN", None)
if SC == "rerun":
    os.environ["KAGGLE_IS_COMPETITION_RERUN"] = "1"

cells = ["".join(c["source"]) for c in json.load(open(NB, encoding="utf-8"))["cells"]]
def scaled(src):
    src = src.replace(" * 60", " * 60 * _S").replace("SAFETY_SEC = 60 ", "SAFETY_SEC = 60 * _S ")
    return src.replace("time.sleep(5)", "time.sleep(0.1)")
G = {"__name__": "__main__", "_S": _S}
exec(scaled(cells[1]), G)
G.update(SGLANG=sys.executable, SERVE_ENV=dict(os.environ, **{f"FAKE_MODE_{k}": v for k, v in modes.items()}),
         mem_available_gb=lambda: 200.0)
for k in ("0_environment", "1_inputs", "2_install", "3_preflight", "3_pinned_memory", "3_fa2_shim"):
    if not G["REPORT"]["stopped_at"]:
        G["stage"](k, True, harness="skipped (needs Kaggle)")
stale = None
if SC == "stale":
    stale = subprocess.Popen([sys.executable, str(HERE / "serve"), "--child-serve", "--port", str(PORT)],
                             env=dict(os.environ, FAKE_PG="stale"))
    for _ in range(50):
        if port_open(): break
        time.sleep(0.1)
t0 = time.time()
for i in (6, 7, 8):
    exec(scaled(cells[i]), G)
wall = time.time() - t0
R = json.loads((work / "fn_smoke" / "fn_smoke_report.json").read_text())
if stale is not None:
    stale.kill(); stale.wait()
    time.sleep(0.5)
st = R["stages"]
att = st.get("4_launch", {}).get("attempts", [])
rows = st.get("6_throughput_eager", {}).get("rows", [])
log = (work / "fn_smoke" / "serve.log").read_text(errors="replace") if (work / "fn_smoke" / "serve.log").exists() else ""
summary = {"stopped_at": R["stopped_at"], "total_sec": R.get("total_sec"), "budget_sec": round(110 * 60 * _S, 1),
           "attempts": [{k: a.get(k) for k in ("attempt", "ready", "sec", "stalled", "exit_code", "skipped")} for a in att],
           "server_max_running": R.get("server_max_running_requests"),
           "rows": [{k: r.get(k) for k in ("concurrency", "complete", "aggregate_tok_s", "decode_tok_s_est", "skipped", "error")} for r in rows],
           "graphs": {k: R.get("graphs", {}).get(k) for k in ("ran", "sanity_ok", "best_aggregate_tok_s")},
           "port_open_after": port_open(), "leftover_fake_processes": fake_leftovers(),
           "prefetch_flag_in_launch": "prefetch=True" in log, "bundle": (work / "FN_PROBE_BUNDLE.zip").exists(),
           "submission": (work / "submission.json").exists()}
print(json.dumps(summary, indent=1))

# ---- assertions
assert summary["bundle"] and summary["submission"]
assert not summary["port_open_after"], "a server still listens after cell 8"
assert not summary["leftover_fake_processes"], summary["leftover_fake_processes"]
assert R["total_sec"] <= 110 * 60 * _S + 5, "probe ran past its budget"
names = [a["attempt"] for a in summary["attempts"]]
if SC == "rerun":
    assert R["stopped_at"] == "rerun_mode_fallback_only" and not att
elif SC == "slow_both":   # both loads keep progressing until their limits; the probe must stop cleanly in budget
    assert R["stopped_at"] == "4_launch" and len(att) == 2 and not any(a.get("ready") for a in att), summary["attempts"]
    a2 = att[1]["sec"]; lim = (110 - 15 - 1) * 60 * _S - att[0]["sec"]
    assert a2 <= lim + 3, (a2, lim)       # attempt 2 never eats the 15-min benchmark reserve
elif SC == "stale":
    assert summary["attempts"][0].get("skipped", "").startswith("port 8001"), summary["attempts"]
    assert R["stopped_at"] == "4_launch"
else:
    assert st["4_launch"]["ok"] and st["5_sanity"]["ok"] and st["6_throughput_eager"]["ok"], R["stopped_at"]
    assert summary["prefetch_flag_in_launch"]
    assert all(r["complete"] and r["decode_tok_s_est"] and r["decode_tok_s_est"] > 0 for r in summary["rows"]), summary["rows"]
    if SC in ("ok", "graphs_fail"):
        assert names == ["noradix_eager_mf096_r8"] and summary["server_max_running"] == 8
        assert [r["concurrency"] for r in summary["rows"]] == [8, 4, 1]
        assert summary["graphs"]["ran"] is True
        assert (summary["graphs"]["sanity_ok"] is True) == (SC == "ok")
    else:
        assert names == ["noradix_eager_mf096_r8", "noradix_eager_mf093_r4"], names
        assert summary["attempts"][1]["ready"] is True and summary["server_max_running"] == 4
        assert [r["concurrency"] for r in summary["rows"]] == [4, 1], summary["rows"]
        a1 = summary["attempts"][0]
        if SC == "stall_a1":
            assert a1["stalled"] is True and a1["sec"] < 50 * 60 * _S
        if SC == "slow_a1":
            assert a1["stalled"] is False and a1["sec"] >= 50 * 60 * _S - 1
        if SC in ("exit_a1", "orphan_a1"):
            assert a1["exit_code"] == 1
print(f"HARNESS PASS {SC} (wall {wall:.1f}s)")
shutil.rmtree(work, ignore_errors=True)
