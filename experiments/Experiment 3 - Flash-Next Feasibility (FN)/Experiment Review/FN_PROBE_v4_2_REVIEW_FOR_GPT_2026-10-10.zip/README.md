# FN-PROBE v4.2 — second review bundle (2026-10-10)

**Please review `notebook/FN-PROBE-FLASHNEXT-v4_2.ipynb` before we spend a 1–2 h Kaggle 4×L4 run on it.**
This bundle follows your review of v4.1 and your research report. Each point below was checked against the code, and where possible reproduced or tested.

## Goal (unchanged)
Measure whether Qwen3.8-Flash-Next decodes faster than our Qwen3.8-27B on Kaggle 4×L4, and by how much.
- Model: Intel W4A16 AutoRound plus FP8 PLE.
- Engine: Pennyroyal SGLang `0.5.19+gd00d88efc8d6`, TP4 / EP4.

The probe is not a submission notebook. Please don't propose another model, engine or solver.

## What changed v4.1 → v4.2

### A. Your v4.1 review: all seven "must" items
| # | Your finding | How we checked it | Fix in v4.2 (cell) |
|---|---|---|---|
| 1 | `kill_server()` skipped the process group once the launcher had exited | Code read; reproduced in the harness (`orphan_a1`) | Unconditional `killpg` (SIGTERM, poll/reap, SIGKILL after 20 s). Bounded at about 25 s (cell 6). |
| 2 | 2 × 50 min attempts left no time for stage 6 | Arithmetic; harness `slow_a1` and `slow_both` | `launch_budget() = min(50 min, remaining − 60 s − 15 min)`. An attempt is skipped if its limit is under 10 min (cell 6). |
| 3 | The r4 fallback reported "concurrency 8" | Code read | `LEVELS` come from the launched `--max-running-requests`, using the last occurrence, which is how SGLang resolves it — confirmed in run 1's server_args. Levels run largest first; `server_max_running_requests` is recorded (cell 7). |
| 4 | Shim crashed when K was empty everywhere | **Reproduced**: the old shim raises `IndexError` | Returns zeros early (shim). |
| 5 | Shim decode test `total_q == b` was wrong | **Reproduced** for q lengths [0, 2] | Now also requires `int(max_seqlen_q) == 1`. SGLang's real call (`_forward_paged_attention`) passes the Python int 1 and `max_seqlen_k=topk`, so there is no host sync and it stays graph-safe. Shape asserts added. |
| 6 | Stage-7 `clamp()` was re-evaluated in every loop | Code read | The limit is computed once: `min(50 min, remaining − 60 s − 6 min)` (cell 7). |
| 7 | A stale server on port 8001 could look ready | Harness `stale` | `port_free_after_kill()` runs before every launch, in stage 4 and stage 7. |

### B. Your measurement recommendations
- **Same prompt at every level:** one fixed ARC prompt, replicated `level` times. The radix cache is off, so this gives no cache hits.
- **Warm-up before each level:** 128 tokens at the same batch size.
- **Decode length 2048, not 4096.** With a 15-min reserve and an unknown, possibly slow decode, 4096 tokens could fill the whole reserve with a single level. Instead the largest concurrency runs first, so the most important number is always measured. Please tell us if you disagree.
- **Complete rows only:** `complete = all(tokens >= 2048)`, and only complete rows count towards "best".
- **Wording:** the result is reported as "ABOVE/BELOW the 27B reference (reference only …)".

### C. Our own additions
1. **Decode-only rate:** `decode_tok_s_est = (tokens_main − tokens_warmup) / (wall_main − wall_warmup)`. Both runs prefill identical prompts, so prefill cancels. `aggregate_tok_s` still includes prefill, and the 27B's 373 tok/s was decode-dominated. A noise guard returns `None` when the difference is under 10 % of the wall time.
2. **`--weight-loader-prefetch-checkpoints`**, taken from your research report and verified in source.
   - The flag exists in this exact build (`server_args.py`, `model_loader/loader.py`, `weight_utils.py`). dfranzen's Kaggle notebook sets `PREFETCH_CHECKPOINTS=True`.
   - With the flag on, the default lookahead mode stages the current shard and one shard ahead, using 4 range-reader threads per process. It also turns off the multi-threaded safetensors loader.
   - In run 1 that multi-threaded loader had 4 ranks × many threads reading the slow `/kaggle/input` (`Multi-thread loading shards`, 5/25 shards in 16 min).
   - We did not add `--weight-loader-drop-cache-after-load`. dfranzen uses it with TP1; with TP4 it would evict pages that other ranks still need.
3. **The launcher must be alive for "ready":** `/health == 200` counts only while `SERVER.poll() is None`, in both stage 4 and stage 7. The harness `orphan_a1` scenario found a race: the dead launcher's child answered `/health` and was taken as ready.

## Verification done locally (Windows host, no GPU)
- **`build/test_shim.py`:** all cases PASS, including both new edge cases. Max error is 0.0073 against a float64 reference.
- **`harness/fn_harness.py`:** runs cells 1, 6, 7 and 8 of the real notebook against a fake `sglang serve` (`harness/serve`).
  - Time is scaled: 1 notebook minute = 1.2 s.
  - Cells 2–5 need Kaggle and are skipped.
  - Process groups are emulated: env `FAKE_PG` is inherited by children, and `os.killpg` is shimmed with psutil.
  - **9/9 scenarios PASS:** `ok`, `stall_a1`, `slow_a1`, `exit_a1`, `orphan_a1`, `stale`, `graphs_fail`, `rerun`, `slow_both`.
  - Every scenario checks: the bundle and submission exist, no fake server process is left, port 8001 is closed at the end, the total stays within budget, and the prefetch flag was passed.
  - Outputs are in `harness/outputs/`.
- **Limits of this verification:** real Linux process-group semantics (zombies, NCCL ranks), the real SGLang `/health` behaviour, real decode speed, and anything in cells 2–5 are untested here.

## Questions for this review
1. **Prefetch flag on TP4/EP4 from `/kaggle/input`.** Is the lookahead mode right, or is the eager split mode better (`SGLANG_WEIGHT_LOADER_PREFETCH_LOOKAHEAD=0`, each rank prefetches 1/4 of the shards)? Is there any risk that it slows loading or deadlocks? See `weight_utils.py` `_lookahead_prefetch_files` / `_prefetch_all_checkpoints`; the relevant source excerpts are in `sglang_excerpts/`.
2. **Decode-only estimate.** Is the warm-up-difference method sound? Any bias from the 128-token warm-up having a different batch shape over time?
3. **`kill_server()`** — is the poll/reap + `killpg(pgid, 0)` loop correct on Linux?
4. Anything else that could waste the run, especially in cells 2–5, which our harness cannot execute.

## Files
- `notebook/FN-PROBE-FLASHNEXT-v4_2.ipynb` — the notebook to review.
- `notebook/FN-PROBE-FLASHNEXT-v4_1.ipynb` — the previous version, for diffing.
- `build/make_fn_probe_v42.py` — v4.2 builder (the v4 builder plus the v4.1 and v4.2 patches on the v3.3 builder).
- `build/make_fn_probe_v42_generated.py` — generated source.
- `build/make_fn_smoke_v3_3.py` — the v3.3 builder everything starts from.
- `build/c_probe.txt` — stages 5–7.
- `build/q27_fa2_varlen_shim.py` — the shim.
- `build/test_shim.py` — shim tests.
- `build/q27_fa2_varlen_shim_v4.py` — the old shim, for comparison.
- `harness/` — `fn_harness.py`, the fake `serve`, and `outputs/h_<scenario>.txt`.
- `sglang_excerpts/` — the prefetch-related source of this exact SGLang build, plus the QSA call site.
- `run1_v4_outputs/` — report, `serve.log` and Kaggle log of v4 run 1 (slow-disk load timeout).
- `previous_run_v3_3/` — v3.3 report and `serve.log` (fast disk, FA4 crash).
