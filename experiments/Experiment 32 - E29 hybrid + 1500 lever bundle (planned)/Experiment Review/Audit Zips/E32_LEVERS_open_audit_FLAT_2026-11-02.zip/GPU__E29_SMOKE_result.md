# E29_DFLASH_D3S GPU smoke v1 (hosen42, 2026-11-02 05:59-07:01 BDT)

**Run.** Notebook 4b6bfd63 = rev 2e: every C item goes to DIRECT; this was before the rev 2f C1 scope. Profile E29SMOKE: 12 eval tasks, 40-min window, 70-min budget. Status COMPLETE. Outputs are in `_scratch/e29_smoke_out/`.

## Engine
- **First try `pin508_df3r0`** (KV 7.93 GB):
  - Ready at 17.9 min, pool 539 blocks.
  - DFlash canary AL 2.845.
  - F2 first-prefill probe at 130k: free MiB [999, 995, 465, 465] → `E29_DFLASH_LOW_FREE` → one ladder step.
- **Second try `pin483_df3r2`** (KV 7.665 GB):
  - Ready at 24.4 min, pool 521 blocks (-3.3 %).
  - Canary AL 2.817.
  - Probe free MiB [1443, 1439, 903, 903] → DONE.
  - Boot ended at 26.2 min.
- **Read-backs:** DFlash ENGAGED, GRD True, EMBED_HOST True, QSA_VERIFIED (128/64 on all ranks). No relaunch, no XID, no OOM.
- **Solve window:** 2,089 s.
  - Throughput 262.4 tok/s; per 15 min: 312 / 238 / 188.
  - AL 2.823, 0 preemptions, prefix hit 62.6 %.
  - Mean running streams 7.36 of 24: only 12 tasks, so not a throughput measurement.
- **Host cgroup:** peak 177,078 of 177,152 MiB. LIVE `avail_mib` 3.7 GB, i.e. mostly reclaimable cache. Watch this in long runs.

## Scheduler / DIRECT
- **Started / done:** A 12/12, C 7/7.
- **DIRECT:** 5 started, 5 records, 0 errors. Two late C items went to Duck C (F1 path, why `late`).
- **All 5 DIRECT ended `forced_close`** at about 35.3 min, after only 2.6k-10.8k thinking tokens. Cause: the drain point = the scheduler deadline (61.3 min) - drain_min 26. This is a smoke-window artifact (a 35-min window against a 26-min drain).
- **DIRECT per-request speed:** 29-33 tok/s.
- **DIRECT ran on 5 A-accepted (train-pass) tasks**, the rev 2e routing:
  - attempt_2 was replaced on 4 of them;
  - DIRECT exact only on 2ba387bc, where attempt_1 was already exact.
  - Rev 2f (C1 only) sends these items to Duck C.
- **Duck C:** 31f7f899 accepted + exact; 800d221b accepted, not exact.
- **Score:** eval 6/15 queries, 5/12 tasks, task-norm 44.44 %. Four A attempts were INCOMPLETE at the window end. This is not a quality measurement.

## Record-only items seen (not blockers)
- `submission ok False, missing 12`: a false alarm in eval mode.
  - submission.json is the CELL 0 identity file over the 240 test tasks (the proven commit behaviour). The check compares it with the 12 eval task ids.
  - In RERUN the task sets are the same.
- The final LIVE lines re-print A records at the window end ("A 13/12 … 24/12"). Print-only.
- Analyzer request timeouts at the window end (normal Duck window-end behaviour).
