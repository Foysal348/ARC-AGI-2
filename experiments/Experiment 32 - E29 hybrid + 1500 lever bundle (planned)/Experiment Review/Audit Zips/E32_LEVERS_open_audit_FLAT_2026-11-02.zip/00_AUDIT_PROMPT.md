# Open audit: E32 lever-bundle notebook (Kaggle ARC-AGI-2, Qwen3.8-Flash-Next on 4×L4)

**What I want from you:** an independent audit, with your own judgment and your own method. Find every bug, risk, blocker and weak point you can, including problems nobody has thought of. Nothing below limits you; it is only context. Read the code itself, not just our descriptions of it. Our reports may be wrong. Our tests may share blind spots with the code.

## What the notebook is
- **`Q27-XHIGH-E32_LEVERS.ipynb`** (readable code: `e32_levers_code_export.py`) is a Kaggle notebook. It is a production candidate: its commit is a 6-h EVAL120 run on the 120 public evaluation tasks; a competition submission reruns it for 12 h on the hidden tasks and writes the real `submission.json`.
- **The base is E29_DFLASH_D3S** (`BASE__e29_dflash_d3s_code_export.py`; diff: `e29_vs_e32_export.diff`).
  - The model is Qwen3.8-Flash-Next klee100 3bpw on Merlin (a vLLM-0.32 fork), TP2×PP2.
  - Speculative decoding is DFlash2 D3s with EMBED_HOST and QSA 128/64, 24 seqs.
  - The KV pin ladder starts at 7,665,090,560 B.
  - The solver is a Duck agent harness with an A / B / C scheduler; DIRECT is the second attempt.
  - **GPU evidence for this base:** `GPU__E29_SMOKE_result.md` and `GPU__e29_smoke_log.txt` (one 70-min smoke).
- **E32 adds 7 speed levers at once, never run on a GPU:**
  - 28 seqs;
  - DFlash K4 + dynamic K per batch size (DYN);
  - long-prefill chunking (LP);
  - the mamba shared-prefix checkpoint (SPC);
  - the indexer fp8 (IDX);
  - two GDN env flags (G1 / G2).
- **On failure:** a drop-one-lever-per-failure fallback, and a ~13-min speed pass after boot.
- **The rest:** design and switches in `README.md`; the builder's report in `REPORT__E32_build_agent.md`.
- **Where the levers come from:** a per-lever measurement notebook, NB-D1 (`REF__nbd1_lib.py`, CPU kit verdicts in `REF__nbd1_kit_real_report.json`). The research plan is `REF__PLAN_1500.md`.

## Things you may find useful (not a checklist)
- **Our hard rules:**
  - A run must never stop because of a lever.
  - Only real failures (crash, OOM, a flag rejected, the drafter not engaged, zero accept) may change the config. Labels are record-only.
  - The thinking floor is 60,000 tokens.
  - The submission path (CELL 0, the writer, the rerun, the clock) must stay identical to the proven one.
  - The notebook must stay under 400,000 bytes (it is 398,296).
- **Silent failure matters most.** A wrong or missing answer, a lever that silently does nothing, a fallback that hides a failure, a measurement that measures the wrong thing, wasted GPU hours, a broken 12-h rerun.
- **GPU-only risks count too,** even if no CPU test can show them: memory on PP1, CUDA graphs, numerics, preemption, timing.

## Output
1. GO / NO-GO for (a) a ~100-min GPU smoke and (b) the 6-h EVAL120 commit.
2. Every finding, ranked BLOCKER / SEVERE / HIGH / MEDIUM / LOW. For each: file:line, what fails and the trigger, the impact, the evidence, CONFIRMED or PLAUSIBLE, the exact fix, and the test that proves the fix.
3. What you could not check.
4. Anything you would do differently in the design.

`00_MANIFEST_SHA256.json` lists every file and its sha256.
