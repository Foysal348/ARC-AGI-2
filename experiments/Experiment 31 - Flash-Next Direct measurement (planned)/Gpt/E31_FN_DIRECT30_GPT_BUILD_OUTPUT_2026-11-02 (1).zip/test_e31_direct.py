"""Run directly: python test_e31_direct.py (no pytest)."""
import json
import os
from pathlib import Path
import queue
import socket
import tempfile
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from types import SimpleNamespace
import e31_direct as d

PASS=0

def test(fn):
    global PASS
    fn();PASS+=1;print('PASS',fn.__name__)

class FakeTokenizer:
    def __init__(self): self.last=[]
    def encode(self,s,add_special_tokens=False):
        # a deterministic, lossless, artificial tokenizer; simulated EOS and think closure.
        return [248069 if x == '\u0001' else ord(x) for x in s.replace('</think>', '\u0001')]
    def decode(self,ids,skip_special_tokens=False):
        return ''.join('</think>' if x==248069 else chr(x) for x in ids)
    def apply_chat_template(self,msgs,**kw):
        return '<system>xhigh</system>\n'+msgs[0]['content']+'\n<think>\n'

def ch(n=1):
    return {'train':[{'input':[[1]],'output':[[2]]}],
            'test':[{'input':[[j+1,0]]} for j in range(n)]}

def parser_cases():
    s='```grid 2\n2 2\n```\n```grid 1\n1 1\n```'
    assert [x['grid'] for x in d.parse_test_grids(s,2)]==[[[1,1]],[[2,2]]]
    assert [x['mapping_source'] for x in d.parse_test_grids(s,2)]==['label','label']
    dup=s+'\n```grid 1\n9 9\n```'
    assert d.parse_test_grids(dup,2)[0]['grid']==[[9,9]]
    miss='```grid 2\n2 2\n```\n```python\n9 9\n```'
    m=d.parse_test_grids(miss,2)
    assert m[0]['grid'] is None and m[1]['grid']==[[2,2]]
    assert m[0]['fallback_reason']=='missing_label'
    none='```text\n1 1\n```\n```grid\n2 2\n```'
    assert [x['grid'] for x in d.parse_test_grids(none,2)]==[[[1,1]],[[2,2]]]
    extra=none+'\n```python\n3 3\n```'
    assert all(x['grid'] is None for x in d.parse_test_grids(extra,2))
    partial='```grid 1\n1 1\n```\n```grid 2\n2 2\n'
    assert d.parse_test_grids(partial,2)[0]['grid']==[[1,1]]
    assert d.parse_test_grids(partial,2)[1]['grid'] is None
    triples='```grid 3\n3 3\n```\n```grid 1\n1 1\n```\n```grid 2\n2 2\n```'
    assert [v['grid'] for v in d.parse_test_grids(triples,3)]==[[[1,1]],[[2,2]],[[3,3]]]
    assert d.parse_test_grids('```grid 1\n1 4\n2\n```',2)[0]['grid'] is None
    assert d.parse_test_grids('```grid\n4 4\n```',1)[0]['grid']==[[4,4]]

def attempts_cases():
    inp=[[1,2]]
    assert d.make_attempts(inp,[[9,9]])['attempt_1']==[[9,9]]
    assert d.make_attempts(inp,[[1,2]])['attempt_2']==[[2,1]]
    assert d.make_attempts(inp,None)['attempt_1']==inp
    assert d.make_attempts([[1,1]],None)['attempt_2']==[[1,1]]

def adapter_cases():
    challenges={f't{n}':ch(n) for n in (1,2,3)}
    records={}
    for n in (1,2,3):
        rows=[]
        for j,t in enumerate(challenges[f't{n}']['test']):
            grid=[[9,9]] if j%2==0 else None
            rows.append({'query_index':j,'attempts':d.make_attempts(t['input'],grid)})
        records[f't{n}']=[{'branch':0,'publish_seq':1,'status':'done','direct_queries':rows,
                           'submissions':[{'test_outputs':[[[8,8]]]*n,'accepted':True,'train_exact':[True]}]}]
    actual=d.e31_build_submission(challenges,records)
    for n in (1,2,3):
        for j,r in enumerate(actual[f't{n}']):
            assert r['attempt_1']==([[9,9]] if j%2==0 else [[j+1,0]])
    # A CPU rule candidate may be correct, but must never appear in DIRECT output.
    assert actual['t1'][0]['attempt_1'] != [[2]]
    assert d.e31_build_submission({'a':ch()}, {})['a'][0]['attempt_1']==[[1,0]]

def original_e10_parity():
    # Extract the actual E10 ORDER2 functions, not an independently retyped expected value.
    import ast
    src=''.join(json.loads(Path('SRC__E10_ORDER2_DIRECT_notebook.ipynb').read_text())['cells'][5]['source'])
    tree=ast.parse(src)
    names={'valid_grid','_parse_row','_first_row_run','_grid_from_obj',
           '_json_rows_grid','_grid_from_block','parse_grid','make_attempts'}
    selected=[node for node in tree.body if isinstance(node,ast.FunctionDef) and node.name in names]
    import re
    ns={'re':re,'json':json,'CHALLENGES':{'x':ch()},'UNIT_TASK':{'x#0':'x'},'UNIT_Q':{'x#0':0}, '_FENCE_RE':d._FENCE_RE,'_SEP_ROW':d._SEP_ROW,'_JSON_ROW':d._JSON_ROW}
    exec(compile(ast.Module(body=selected,type_ignores=[]),'E10-cell4','exec'),ns)
    layouts=['```grid\n1 0\n```','```json\n[[2,3]]\n```',
             'not a grid','```grid\n1 2\n3 4\n```','```grid\n1 10\n```']
    for layout in layouts:
        assert ns['parse_grid'](layout)==d.parse_grid(layout),layout
    for grid in (None,[[9,9]],[[1,0]]):
        old=ns['make_attempts']('x#0',grid)
        new=d.make_attempts(ch()['test'][0]['input'],grid)
        assert old==new
    prompt_src=''.join(json.loads(Path('SRC__E10_ORDER2_DIRECT_notebook.ipynb').read_text())['cells'][4]['source'])
    tr=ast.parse(prompt_src)
    names={'render_grid','build_user_message'}
    selected=[node for node in tr.body if isinstance(node,ast.FunctionDef) and node.name in names]
    ns2={}
    exec(compile(ast.Module(body=selected,type_ignores=[]),'E10-cell3','exec'),ns2)
    assert ns2['build_user_message'](ch()['train'],ch()['test'][0]['input'])==d.build_user_message(ch()['train'],ch()['test'][0]['input'])

def single_prompt():
    t=ch(1)
    m=d.build_multi_message(t['train'],t['test'])
    assert m==d.build_user_message(t['train'],t['test'][0]['input'])
    assert m.endswith('Output nothing after the block.')
    assert 'FINAL INPUT 1' not in m
    m=d.build_multi_message(ch(3)['train'],ch(3)['test'])
    assert all(f'FINAL INPUT {i}:' in m and f'```grid {i}\n' in m for i in (1,2,3))

class FakeServer(ThreadingHTTPServer):
    daemon_threads=True
    allow_reuse_address=True

class FakeHandler(BaseHTTPRequestHandler):
    def log_message(self,*x): pass
    def do_POST(self):
        if self.path != '/v1/completions':
            self.send_error(404);return
        data=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
        self.server.calls.append(data)
        self.server.urls.append(self.path)
        self.send_response(200)
        self.send_header('Content-Type','text/event-stream')
        self.end_headers()
        prefix=data['prompt']
        phase2=(d.STOP_THINKING_TEXT.endswith('') and
                any(x==248069 for x in prefix[-300:]))
        if self.server.kill and len(self.server.calls)==self.server.kill:
            self.close_connection=True;return
        # One instruction stream; phase 1 can run forever; phase 2 returns a grid.
        try:
            if phase2:
                body='```grid 1\n9 9\n```\n```grid 2\n8 8\n```\n```grid 3\n7 7\n```'
                for part in [body[:len(body)//2],body[len(body)//2:]]:
                    ids=[ord(x) for x in part]
                    obj={'choices':[{'token_ids':ids,'text':part,'finish_reason':None}]}
                    self.wfile.write(('data: '+json.dumps(obj)+'\n\n').encode());self.wfile.flush()
                self.wfile.write(b'data: {"choices":[{"token_ids":[],"finish_reason":"stop"}]}\n\n')
                self.wfile.flush()
            else:
                self.wfile.write(b'data: {"choices":[{"token_ids":[65,66,67],"finish_reason":null}]}\n\n')
                self.wfile.flush()
                if self.server.never_close:
                    while True:
                        self.wfile.write(b': heartbeat\n\n');self.wfile.flush();time.sleep(.02)
                else:
                    self.wfile.write(b'data: {"choices":[{"token_ids":[],"finish_reason":"length"}]}\n\n')
                    self.wfile.flush()
            self.wfile.write(b'data: [DONE]\n\n');self.wfile.flush()
        except (BrokenPipeError,ConnectionResetError,OSError):
            self.server.aborts+=1

def with_server(fn,**options):
    server=FakeServer(('127.0.0.1',0),FakeHandler)
    server.calls=[];server.urls=[];server.aborts=0
    server.never_close=options.get('never_close',False)
    server.kill=options.get('kill',0)
    th=threading.Thread(target=server.serve_forever,daemon=True);th.start()
    try: fn(server)
    finally:server.shutdown();server.server_close();th.join(timeout=1)

def fake_stream_server():
    def run(s):
        c=d.TokenStreamClient(f'http://127.0.0.1:{s.server_port}/v1','q27',timeout=3)
        ids=[]
        reason,usage=c.stream([1,2,3],500,5,.6,d.Cancel(),ids.extend)
        assert reason=='length' and ids==[65,66,67]
        assert s.calls[0]['prompt']==[1,2,3]
        assert s.calls[0]['return_token_ids'] and s.urls==['/v1/completions']
    with_server(run)

def fake_server_kill_not_success():
    def run(s):
        c=d.TokenStreamClient(f'http://127.0.0.1:{s.server_port}/v1','q27',timeout=2)
        try:
            c.stream([1],30,1,.6,d.Cancel(),lambda ids:None)
        except RuntimeError as exc:
            assert 'without finish_reason' in str(exc)
        else:raise AssertionError('server kill counted as completion')
    with_server(run,kill=1)

def fake_24_task_e2e():
    def run(s):
        ns=SimpleNamespace(solve_all_r6=lambda *a,**k:None,build_submission=lambda *a,**k:None,SCHED_LAST={})
        tok=FakeTokenizer()
        challenges={f't{i:02d}':ch(i%3+1) for i in range(30)}
        with tempfile.TemporaryDirectory() as temp:
            cfg={'think':100,'answer':100,'window_min':16,'workers':24,'temperature':.6,
                 'drain_min':3,'allow_test_server':True,'test_minute_sec':.08,
                 'max_model_len':8192}
            h=d.install(ns,tokenizer=tok,challenges=challenges,
                 sgl_url=f'http://127.0.0.1:{s.server_port}',cfg=cfg,out_dir=temp)
            done=[]
            rows=h.solve_all_r6(challenges,list(challenges),
                 deadline=time.monotonic()+3,base_url=h.base_url+'/v1',
                 on_branch_done=lambda r:done.append(r),workers=24)
            assert len(s.calls)>=24, len(s.calls)
            assert len(rows)==30 and len(done)>=24
            assert any(r[0].get('mode')=='forced_close' for r in rows.values())
            # Phase-2 prompt is raw prompt ids + streamed partial ids + STOP_IDS.
            phase2=[x for x in s.calls if 248069 in x['prompt'][-300:]]
            assert phase2
            assert all('token_ids' not in x for x in [])
            assert Path(temp,'e31_direct_report.json').exists()
            assert Path(temp,'e31_direct_records.jsonl').exists()
            result=ns.build_submission(challenges,rows)
            assert all(len(result[t])==len(challenges[t]['test']) for t in rows)
            assert ns.SCHED_LAST['mode']=='E31_DIRECT'
            h.uninstall()
    with_server(run,never_close=True)

for f in (parser_cases,attempts_cases,adapter_cases,single_prompt,original_e10_parity,
          fake_stream_server,fake_server_kill_not_success,fake_24_task_e2e):
    test(f)
print('ALL',PASS,'TEST GROUPS PASS')
