# E31: place AFTER the E28 function-definition CELL 6/7 and BEFORE CELL 8.
# Stage e31_direct.py as a Kaggle dataset (the ZIP includes the exact file).
# No E18 engine/server is created. This installation is commit-only.
if PROFILE == 'E31DIRECT30' and not RERUN:
    import importlib.util as _e31_importlib
    import hashlib as _e31_hashlib
    from pathlib import Path as _e31_Path
    _e31_modpath = _e31_Path('/kaggle/input/e31-direct-module/e31_direct.py')
    assert _e31_modpath.is_file(), 'stage e31_direct.py as Kaggle dataset e31-direct-module'
    _e31_sha = 'MODULE_SHA256_PLACEHOLDER'
    assert _e31_hashlib.sha256(_e31_modpath.read_bytes()).hexdigest() == _e31_sha, 'E31 module SHA mismatch'
    _e31_spec = _e31_importlib.spec_from_file_location('e31_direct', str(_e31_modpath))
    _e31_mod = _e31_importlib.module_from_spec(_e31_spec)
    _e31_spec.loader.exec_module(_e31_mod)

    class _E31DeferredTokenizer:
        # _HF is created by E28 nb5_rc2_prompts() in CELL 8, after this cell.
        def encode(self, text, add_special_tokens=False):
            return _HF.encode(text, add_special_tokens=add_special_tokens)
        def decode(self, ids, skip_special_tokens=False):
            return _HF.decode(ids, skip_special_tokens=skip_special_tokens)
        def apply_chat_template(self, *a, **kw):
            return _HF.apply_chat_template(*a, **kw)

    _E31_HANDLE = _e31_mod.install(
        E12A, tokenizer=_E31DeferredTokenizer(), challenges=CHALLENGES,
        sgl_url=SGL_URL, cfg=E31_CFG, out_dir=OUT / 'q27x', log=print,
        solutions=SOLUTIONS)
    assert not P.get('e28_sched'), 'E31 must not apply E28 Duck scheduler'
    print('E31 DIRECT-only adapter installed (E28 retains server lifecycle)', flush=True)
