"""Build from pinned E28 parent; fail closed if source patterns differ."""
import hashlib,json,re
from pathlib import Path
ROOT=Path(__file__).resolve().parent
n=json.loads((ROOT/'SRC__E28_K100_notebook.ipynb').read_text())
src=''.join(n['cells'][2]['source'])
assert 'K100_DEADMAN_SEC = 24900' in src
assert 'NB5_DEFAULT_PROFILE = "E28EVAL120"' in src
assert 'K100_PROFILES = ("E28EVAL120", "RERUN_PROD")' in src
assert 'PROFILE_TABLE["RERUN_PROD"] = ' in src
assert 'if PROFILE not in PROFILE_TABLE:' in src
assert 'E28EVAL120' in src
src=src.replace('K100_DEADMAN_SEC = 24900','K100_DEADMAN_SEC = 12300',1)
src=src.replace('NB5_DEFAULT_PROFILE = "E28EVAL120"','NB5_DEFAULT_PROFILE = "E31DIRECT30"',1)
src=src.replace('K100_PROFILES = ("E28EVAL120", "RERUN_PROD")',
                'K100_PROFILES = ("E28EVAL120", "E31DIRECT30", "RERUN_PROD")',1)
tasks='2d0172a1 35ab12c3 409aa875 446ef5d2 4c3d4a41 4c416de3 5545f144 7491f3cf 7b5033c1 800d221b 89565ca0 9385bd28 a47bf94d a6f40cea b6f77b65 cbebaa4b 142ca369 247ef758 36a08778 581f7754 71e489b6 88e364bc a32d8b75 f931b4a8 135a2760 136b0064 1818057f 0934a4d8 13e47133 16b78196'.split()
assert len(tasks)==30 and len(set(tasks))==30
conf="""E31_CFG = {'think': 104000, 'answer': 8192, 'window_min': 170, 'workers': 24,
           'temperature': 0.6, 'drain_min': 26,
           'max_model_len': 131072,
           'groups': {**dict.fromkeys(%r, 'main'),
                      **dict.fromkeys(%r, 'partial'),
                      **dict.fromkeys(%r, 'control')}}
"""% (tasks[:16],tasks[16:24],tasks[24:])
assert src.startswith('# ')
src=conf+src
row="""# E31 standalone 30-task DIRECT; no E28 scheduler; no engine change.
_E31_TASKS = %r
assert len(_E31_TASKS) == len(set(_E31_TASKS)) == 30
assert 205*60-5*60-180-E31_CFG['window_min']*60 >= 15*60, 'E31 170 min window lacks boot reserve'
PROFILE_TABLE['E31DIRECT30'] = dict(_NB5_T, time_budget_sec=205*60,
    hard_margin_sec=5*60, source='eval', task_list=_E31_TASKS,
    quality_ab=True, equal_windows=True, fixed_window_sec=E31_CFG['window_min']*60,
    nb5_phases=[['Q_E31_DIRECT30', 'all', None, 'on', 'A', 'fp8']],
    **dict(E28_LEVERS, e28_sched=False))
"""%tasks
needle='if PROFILE not in PROFILE_TABLE:'
src=src.replace(needle,row+needle,1)
# Keep trusted E28 code cells untouched apart from CELL 1, insert only E31 import cell.
n['cells'][2]['source']=src.splitlines(True)
cell=(ROOT/'e31_cell.py').read_text().replace('MODULE_SHA256_PLACEHOLDER',hashlib.sha256((ROOT/'e31_direct.py').read_bytes()).hexdigest())
n['cells'].insert(7,{'cell_type':'code','execution_count':None,'metadata':{},'outputs':[],'source':cell.splitlines(True)})
out=ROOT/'E31_FN_DIRECT30_candidate.ipynb'
out.write_text(json.dumps(n,ensure_ascii=False,separators=(',',':'))+'\n')
assert len(out.read_bytes())<400000,(out,len(out.read_bytes()))
print('notebook bytes',out.stat().st_size,'sha',hashlib.sha256(out.read_bytes()).hexdigest())
print('module sha',hashlib.sha256((ROOT/'e31_direct.py').read_bytes()).hexdigest())
