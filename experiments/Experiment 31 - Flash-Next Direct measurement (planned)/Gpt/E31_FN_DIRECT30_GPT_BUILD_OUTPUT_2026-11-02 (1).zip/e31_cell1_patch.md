# Exact E31 CELL 1 changes (applied in `E31_FN_DIRECT30_candidate.ipynb`)

The reproducible builder is `build_e31_notebook.py` and makes the edits below against `SRC__E28_K100_notebook.ipynb`. The output cell contains the literal values; inspect it before GPU execution.

1. **At the very top**, add this editable configuration (30 task groups are populated by the builder from the design's exact 16/8/6 list):

```python
E31_CFG = {'think': 104000, 'answer': 8192, 'window_min': 170, 'workers': 24,
           'temperature': 0.6, 'drain_min': 26,
           'max_model_len': 131072,
           'groups': {**dict.fromkeys(MAIN_16, 'main'),
                      **dict.fromkeys(PARTIAL_8, 'partial'),
                      **dict.fromkeys(CONTROL_6, 'control')}}
```

`MAIN_16`, `PARTIAL_8`, and `CONTROL_6` above are explanatory placeholders; the actual notebook contains the full literal ID lists, not unresolved names.

2. Replace:

```python
NB5_DEFAULT_PROFILE = "E28EVAL120"
K100_DEADMAN_SEC = 24900
K100_PROFILES = ("E28EVAL120", "RERUN_PROD")
```

with:

```python
NB5_DEFAULT_PROFILE = "E31DIRECT30"
K100_DEADMAN_SEC = 12300   # 205 minutes, COMMIT only
K100_PROFILES = ("E28EVAL120", "E31DIRECT30", "RERUN_PROD")
```

3. Insert **before** `if PROFILE not in PROFILE_TABLE:`:

```python
_E31_TASKS = [  # exact 30 task IDs from the design
    '2d0172a1', '35ab12c3', '409aa875', '446ef5d2', '4c3d4a41',
    '4c416de3', '5545f144', '7491f3cf', '7b5033c1', '800d221b',
    '89565ca0', '9385bd28', 'a47bf94d', 'a6f40cea', 'b6f77b65',
    'cbebaa4b', '142ca369', '247ef758', '36a08778', '581f7754',
    '71e489b6', '88e364bc', 'a32d8b75', 'f931b4a8',
    '135a2760', '136b0064', '1818057f', '0934a4d8',
    '13e47133', '16b78196'
]
assert len(_E31_TASKS) == len(set(_E31_TASKS)) == 30
assert 205*60 - 5*60 - 180 - E31_CFG['window_min']*60 >= 15*60
PROFILE_TABLE['E31DIRECT30'] = dict(
    _NB5_T, time_budget_sec=205*60, hard_margin_sec=5*60,
    source='eval', task_list=_E31_TASKS, quality_ab=True,
    equal_windows=True, fixed_window_sec=E31_CFG['window_min']*60,
    nb5_phases=[['Q_E31_DIRECT30', 'all', None, 'on', 'A', 'fp8']],
    **dict(E28_LEVERS, e28_sched=False))
```

4. Insert `e31_cell.py` after the E28 CELL 6/7 definitions, before CELL 8. The cell uses the provided `e31_direct.py`, stages it as a versioned Kaggle dataset, and verifies its SHA-256. Only E31 commit activates the DIRECT rebind. E28 retains the engine lifecycle. **Do not enable `e28_sched` for E31.**

5. There is **no change to E28 CELL 0, CELL 3, CELL 5, CELL 6/7, CELL 8, or CELL 9**. The original hidden-rerun branch remains `RERUN_PROD`, unmodified by this E31 install.

The profile only reserves ~27 minutes between the nominal 15-minute boot and the maximum 170-minute window. Two slower boots can shorten it via the existing E28 `nb5_phase` clamp; a 170-minute window is therefore a cap, not a guarantee.
