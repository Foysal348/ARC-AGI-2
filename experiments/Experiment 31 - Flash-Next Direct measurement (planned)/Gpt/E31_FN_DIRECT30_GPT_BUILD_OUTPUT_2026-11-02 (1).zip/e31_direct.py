"""E31 Flash-Next DIRECT task solver; no independent engine lifecycle.

Uses the existing E28 model endpoint, notebook clock and E28 writer. A task (not
query) is the admission unit; recorded output contains exactly one branch.
"""
from __future__ import annotations
import concurrent.futures
import json
import os
import re
import threading
import time
import urllib.request
from pathlib import Path
from collections import Counter

SEED = 20261005
STOP_THINKING_TEXT = "\n\nConsidering the limited time by the user, I have to give the solution based on the thinking directly now.\n</think>\n\n"
_FENCE_RE = re.compile(r"```([^\n`]*)\n(.*?)```", re.S)
_SEP_ROW = re.compile(r"\[?\s*\d(?:\s*[, ]\s*\d)*\s*\]?,?")
_JSON_ROW = re.compile(r"\[\s*\d(?:\s*,\s*\d)*\s*\]")
_LABEL_RE = re.compile(r"^grid\s+(\d+)\s*$", re.I)


def valid_grid(g):
    return (isinstance(g, list) and 1 <= len(g) <= 30 and
            all(isinstance(r, list) and 1 <= len(r) <= 30 for r in g) and
            len({len(r) for r in g}) == 1 and
            all(type(v) is int and 0 <= v <= 9 for r in g for v in r))


def render_grid(g):
    return "\n".join(" ".join(str(int(v)) for v in row) for row in g)


def build_user_message(train, test_input):
    """Verbatim E10 ORDER2 for single-test tasks."""
    parts = ["You are solving an abstract reasoning puzzle. Each example has an "
             "INPUT grid and its OUTPUT grid (digits 0-9 are colors; 0 is usually "
             "background). Infer the ONE rule that maps every input to its output, "
             "then apply it to the FINAL INPUT.\n"]
    for i, p in enumerate(train):
        parts.append("Example %d INPUT:\n%s\nExample %d OUTPUT:\n%s\n" %
                     (i + 1, render_grid(p["input"]), i + 1, render_grid(p["output"])))
    parts.append("FINAL INPUT:\n%s\n" % render_grid(test_input))
    parts.append("Reason step by step however you like. Then give ONLY the final "
                 "output grid as rows of space-separated digits inside a fenced "
                 "block:\n```grid\n<rows>\n```\nOutput nothing after the block.")
    return "\n".join(parts)


def build_multi_message(train, tests):
    if len(tests) == 1:
        return build_user_message(train, tests[0]["input"])
    parts = ["You are solving an abstract reasoning puzzle. Each example has an "
             "INPUT grid and its OUTPUT grid (digits 0-9 are colors; 0 is usually "
             "background). Infer the ONE rule that maps every input to its output, "
             "then apply it to the FINAL INPUT.\n"]
    for i, p in enumerate(train):
        parts.append("Example %d INPUT:\n%s\nExample %d OUTPUT:\n%s\n" %
                     (i + 1, render_grid(p["input"]), i + 1, render_grid(p["output"])))
    for qi, t in enumerate(tests, 1):
        parts.append("FINAL INPUT %d:\n%s\n" % (qi, render_grid(t["input"])))
    labels = "\n".join("```grid %d\n<rows>\n```" % i for i in range(1, len(tests)+1))
    parts.append("Reason step by step however you like. Then give ONLY the final "
                 "output grids as rows of space-separated digits inside labeled fenced "
                 "blocks, one for each FINAL INPUT in order:\n" + labels +
                 "\nOutput nothing after the last block.")
    return "\n".join(parts)


def _parse_row(s):
    s = s.strip()
    if not s:
        return None
    if re.fullmatch(r"\d+", s):
        return [int(c) for c in s]
    if _SEP_ROW.fullmatch(s):
        return [int(c) for c in re.findall(r"\d", s)]
    return None


def _first_row_run(lines):
    rows = []
    for line in lines:
        r = _parse_row(line)
        if r is None:
            if rows:
                break
            continue
        rows.append(r)
    return rows if valid_grid(rows) else None


def _grid_from_obj(obj):
    if isinstance(obj, dict):
        for key in ("output", "grid", "test_output", "answer", "test_outputs"):
            if key in obj:
                return _grid_from_obj(obj[key])
        return None
    if valid_grid(obj):
        return obj
    if isinstance(obj, list) and obj and valid_grid(obj[-1]):
        return obj[-1]
    return None


def _json_rows_grid(body):
    grids, cur = [], []
    for m in _JSON_ROW.finditer(body):
        cur.append(json.loads(m.group(0)))
        if body[m.end():].lstrip().startswith("]"):
            grids.append(cur)
            cur = []
    if cur:
        grids.append(cur)
    for g in reversed(grids):
        if valid_grid(g):
            return g
    return None


def _grid_from_block(body):
    body = body.strip()
    if body[:1] in ("[", "{"):
        try:
            g = _grid_from_obj(json.loads(body))
        except (ValueError, TypeError):
            g = None
        if g is None:
            g = _json_rows_grid(body)
        if g is not None:
            return g
    return _first_row_run(body.splitlines())


def parse_grid(text):
    """Verbatim E10-style parser; single-test may use unfenced last row run."""
    for _, body in reversed(_FENCE_RE.findall(text or "")):
        g = _grid_from_block(body)
        if g is not None:
            return g
    runs, cur = [], []
    for line in (text or "").splitlines():
        r = _parse_row(line)
        if r is None:
            if cur:
                runs.append(cur)
                cur = []
        else:
            cur.append(r)
    if cur:
        runs.append(cur)
    for run in reversed(runs):
        if valid_grid(run):
            return run
    return None


def parse_test_grids(text, n_tests):
    """Fail-closed multi-test mapping. No positional fallback after ANY label."""
    if n_tests == 1:
        g = parse_grid(text)
        return [{"query_index": 0, "grid": g, "mapping_source": "single" if g else "fallback",
                 "fallback_reason": None if g else "missing_or_invalid_grid"}]
    blocks = _FENCE_RE.findall(text or "")
    labels_present = any(_LABEL_RE.fullmatch(label.strip()) for label, _ in blocks)
    result = [None] * n_tests
    if labels_present:
        for label, body in blocks:
            m = _LABEL_RE.fullmatch(label.strip())
            if m and 1 <= int(m.group(1)) <= n_tests:
                g = _grid_from_block(body)
                if g is not None:
                    result[int(m.group(1)) - 1] = g
        source = "label"
    else:
        valid = [_grid_from_block(body) for _, body in blocks]
        valid = [g for g in valid if g is not None]
        if len(valid) == n_tests:
            result = valid
        source = "positional"
    return [{"query_index": i, "grid": g,
             "mapping_source": source if g is not None else "fallback",
             "fallback_reason": None if g is not None else ("missing_label" if labels_present else "ambiguous_block_count")}
            for i, g in enumerate(result)]


def make_attempts(test_input, grid):
    cands = ([('model', grid)] if valid_grid(grid) else []) + [
        ('test_input', test_input), ('mirror', [list(reversed(row)) for row in test_input])]
    uniq = []
    for src, g in cands:
        if all(g != old for _, old in uniq):
            uniq.append((src, g))
    while len(uniq) < 2:
        uniq.append(uniq[-1])
    return {'attempt_1': uniq[0][1], 'attempt_2': uniq[1][1],
            'src_1': uniq[0][0], 'src_2': uniq[1][0]}


def e31_build_submission(challenges, records):
    """Never inspect Duck candidates or CPU train-exact rules."""
    out = {}
    for tid, ch in challenges.items():
        rows = records.get(tid) or []
        rec = max((r for r in rows if r.get('branch') == 0),
                  key=lambda r: int(r.get('publish_seq') or 0), default=None)
        by_q = {}
        if rec:
            for row in rec.get('direct_queries', []):
                by_q[row['query_index']] = row
        out[tid] = []
        for qi, t in enumerate(ch['test']):
            att = by_q.get(qi, {}).get('attempts')
            if att is None:
                att = make_attempts(t['input'], None)
            out[tid].append({'attempt_1': att['attempt_1'], 'attempt_2': att['attempt_2']})
    return out


def _order_score(ch):
    return int(len(ch['train']) >= 3) + int(len(ch['test']) == 1)


def _write_json_atomic(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + '.tmp.' + str(threading.get_ident()))
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False)
    os.replace(tmp, path)


def _decode(tokenizer, ids):
    return tokenizer.decode(ids, skip_special_tokens=False)


class StreamCancelled(Exception):
    pass


class TokenStreamClient:
    """No engine ownership. Uses ONLY server's /v1/completions SSE token IDs."""
    def __init__(self, base_url, model_id, timeout=180):
        self.base_url = base_url.rstrip('/')
        self.model_id = model_id
        self.timeout = timeout

    def stream(self, prompt_ids, cap, seed, temperature, cancel, on_tokens):
        data = {'model': self.model_id, 'prompt': list(map(int, prompt_ids)),
                'max_tokens': int(cap), 'temperature': float(temperature),
                'top_p': 0.95, 'top_k': 20, 'seed': int(seed),
                'stream': True, 'return_token_ids': True, 'skip_special_tokens': False}
        req = urllib.request.Request(self.base_url + '/completions', method='POST',
                                     headers={'Content-Type': 'application/json'},
                                     data=json.dumps(data).encode('utf-8'))
        reason = None
        usage = {}
        response = None
        # response.read() is intentionally never used: disconnect on cancellation.
        try:
            response = urllib.request.urlopen(req, timeout=self.timeout)
            # Cancellation closes the socket while another thread is blocked reading.
            cancel.set_closer(response.close)
            if cancel.is_set():
                raise StreamCancelled()
            for raw in response:
                if cancel.is_set():
                    raise StreamCancelled()
                line = raw.strip()
                if not line.startswith(b'data:'):
                    continue
                content = line[5:].strip()
                if content == b'[DONE]':
                    break
                obj = json.loads(content)
                if obj.get('error') or obj.get('object') == 'error':
                    raise RuntimeError('SSE error: ' + str(obj.get('error', obj))[:250])
                usage.update(obj.get('usage') or {})
                for ch in obj.get('choices') or []:
                    ids = ch.get('token_ids')
                    if ids is None:
                        if ch.get('text'):
                            raise RuntimeError('stream text without token_ids: refusing retokenization')
                        ids = []
                    if ids:
                        on_tokens([int(x) for x in ids])
                    if ch.get('finish_reason') is not None:
                        reason = str(ch['finish_reason'])
                if reason is not None:
                    break
            if cancel.is_set():
                raise StreamCancelled()
            if reason is None:
                raise RuntimeError('stream closed without finish_reason')
            return reason, usage
        finally:
            cancel.set_closer(None)
            if response is not None:
                try:
                    response.close()
                except Exception:
                    pass


class Cancel:
    def __init__(self):
        self.ev = threading.Event()
        self.lock = threading.Lock()
        self.closer = None

    def is_set(self):
        return self.ev.is_set()

    def set_closer(self, closer):
        with self.lock:
            self.closer = closer
            if self.ev.is_set() and closer:
                try:
                    closer()
                except Exception:
                    pass

    def cancel(self):
        with self.lock:
            self.ev.set()
            if self.closer:
                try:
                    self.closer()
                except Exception:
                    pass


class DirectHandle:
    def __init__(self, E12A, tokenizer, challenges, sgl_url, cfg, out_dir, log, solutions=None):
        self.E12A, self.tokenizer, self.challenges = E12A, tokenizer, challenges
        self.base_url = str(sgl_url).rstrip('/')
        self.cfg, self.out_dir, self.log = dict(cfg), Path(out_dir), log
        self.solutions = solutions
        assert self.base_url.endswith(':8001') or self.cfg.get('allow_test_server'), 'must use E28 SGL_URL :8001'
        self.stop_ids = self.think_close_ids = None  # tokenizer is loaded by E28 CELL 8, after install

        self.out_dir.mkdir(parents=True, exist_ok=True)
        self.original_solve = E12A.solve_all_r6
        self.original_submission = E12A.build_submission
        E12A.solve_all_r6 = self.solve_all_r6
        E12A.build_submission = e31_build_submission
        self.last_report = None

    def uninstall(self):
        self.E12A.solve_all_r6 = self.original_solve
        self.E12A.build_submission = self.original_submission

    def _prompt(self, ch):
        message = build_multi_message(ch['train'], ch['test'])
        text = self.tokenizer.apply_chat_template(
            [{'role':'user','content':message}], tokenize=False,
            add_generation_prompt=True, enable_thinking=True, reasoning_effort='xhigh')
        return self.tokenizer.encode(text, add_special_tokens=False)

    def _write_trace(self, tid, phase, ids, reason, metadata):
        path = self.out_dir / ('e31_' + tid + '_' + phase + '.json')
        _write_json_atomic(path, {'task_id':tid, 'phase':phase, 'ids':ids, 'finish_reason':reason,
                                  'text':_decode(self.tokenizer, ids), **metadata})
        return str(path)

    def _one_task(self, tid, ch, deadline, drain_at, answer_stop, client, rank, context, active):
        begin = time.monotonic()
        prompt = self._prompt(ch)
        n_tests = len(ch['test'])
        think_max = min(int(self.cfg.get('think',104000)),
                        max(0, context-len(prompt)-int(self.cfg.get('answer',8192))*n_tests-256))
        floor_possible = think_max >= 60000
        rec = {'task_id':tid, 'branch':0, 'publish_seq':1, 'accepted':False,
               'status':'error', 'mode':'error', 'prompt_tokens':len(prompt),
               'think_cap':think_max, 'floor_60k_possible':floor_possible,
               'group':self.cfg.get('groups',{}).get(tid, 'unknown')}
        p1, p2 = [], []
        p1_cancel, p2_cancel = Cancel(), Cancel()
        active[tid] = (p1_cancel, p2_cancel)
        phase1_reason = phase2_reason = None
        errors=[]
        try:
            if think_max < 1:
                raise ValueError('no room for phase 1')
            if time.monotonic() >= drain_at:
                raise TimeoutError('not admitted by drain')
            seed = SEED + 10*rank
            try:
                phase1_reason, phase1_usage = client.stream(prompt, think_max, seed+1,
                    self.cfg.get('temperature',0.6), p1_cancel,
                    lambda chunk:p1.extend(chunk))
            except StreamCancelled:
                phase1_reason = 'drained'
            except Exception as exc:
                errors.append('phase1: '+repr(exc))
                phase1_reason = 'error'
            finally:
                self._write_trace(tid,'phase1',p1,phase1_reason,{'prompt_tokens':len(prompt)})
            # A genuine transport/server error is never marked completed, even if text exists.
            if phase1_reason == 'error':
                raise RuntimeError(errors[-1] if errors else 'phase 1 error')
            if time.monotonic() >= answer_stop:
                rec['mode'] = 'partial_phase1'
            else:
                closed = self.think_close_ids[0] in p1
                prefix = prompt + p1 + ([] if closed else self.stop_ids)
                cap = min(int(self.cfg.get('answer',8192))*n_tests,
                          max(0, context-len(prefix)-8))
                rec['mode'] = 'continue' if closed else 'forced_close'
                rec['phase2_prefix_len'] = len(prefix)
                rec['phase2_prefix_sha256'] = __import__('hashlib').sha256(json.dumps(prefix).encode()).hexdigest()
                if cap > 0:
                    try:
                        phase2_reason, phase2_usage = client.stream(prefix, cap, seed+2,
                             self.cfg.get('temperature',0.6), p2_cancel, lambda chunk:p2.extend(chunk))
                    except StreamCancelled:
                        phase2_reason='drained'
                    except Exception as exc:
                        errors.append('phase2: '+repr(exc))
                        phase2_reason='error'
                    finally:
                        self._write_trace(tid,'phase2',p2,phase2_reason,
                                          {'prefix_ids':prefix, 'prefix_tokens':len(prefix)})
                else:
                    rec['mode']='no_answer_room'
            text = _decode(self.tokenizer,p2 if p2 else p1)
            mapped = parse_test_grids(text,n_tests)
            direct_queries=[]
            for m in mapped:
                qi = m['query_index']
                att = make_attempts(ch['test'][qi]['input'],m['grid'])
                direct_queries.append({**m,'attempts':att,'has_grid':m['grid'] is not None})
            rec.update(status='done' if not errors else 'error',
                       submissions=[{'test_outputs':[x['grid'] for x in direct_queries],
                                     'accepted':False,'train_exact':[],'branch':0}],
                       direct_queries=direct_queries,
                       attempts_1=[x['attempts']['attempt_1'] for x in direct_queries],
                       think_tokens=len(p1), answer_tokens=len(p2),
                       generated_tokens=len(p1)+len(p2),
                       p1_finish=phase1_reason,p2_finish=phase2_reason,
                       error='; '.join(errors) if errors else None)
        except Exception as exc:
            rec['error'] = repr(exc)
            rec['generated_tokens']=len(p1)+len(p2)
            rec['think_tokens']=len(p1)
            rec['answer_tokens']=len(p2)
        finally:
            rec['elapsed_sec']=round(time.monotonic()-begin,3)
            active.pop(tid,None)
        return rec

    def solve_all_r6(self, challenges, task_ids, *, out_dir=None, deadline=None,
                     base_url=None, model_id='q27', on_branch_done=None, workers=None, **kwargs):
        if base_url is not None and base_url.rstrip('/') != self.base_url+'/v1':
            raise ValueError('E31 endpoint mismatch; E28 SGL_URL must own lifecycle')
        if deadline is None:
            raise ValueError('solve_all_r6 requires E28 monotonic deadline')
        self.stop_ids = self.tokenizer.encode(STOP_THINKING_TEXT, add_special_tokens=False)
        self.think_close_ids = self.tokenizer.encode('</think>', add_special_tokens=False)
        if len(self.think_close_ids) != 1 or self.think_close_ids[0] not in self.stop_ids:
            raise ValueError('E10 stop tokens incompatible with target tokenizer')
        start = time.monotonic()
        hard_end = min(float(deadline), start+(60 if not self.cfg.get('allow_test_server') else float(self.cfg.get('test_minute_sec',60)))*float(self.cfg.get('window_min',170)))
        drain_min = float(self.cfg.get('drain_min',26))
        if drain_min < 1 or drain_min >= float(self.cfg.get('window_min',170))-12:
            raise ValueError('invalid drain reserve')
        minute = 60.0 if not self.cfg.get('allow_test_server') else float(self.cfg.get('test_minute_sec',60.0))
        # Test compression is opt-in and forbidden for production endpoint.
        if not self.cfg.get('allow_test_server') and minute != 60.0:
            raise ValueError('production timing override')
        no_admit = hard_end-12*minute
        drain_at = hard_end-drain_min*minute
        answer_stop = hard_end-minute
        nworkers = max(1, min(24, int(self.cfg.get('workers',24)),
                              int(workers) if workers is not None else 24))  # respect E28 isolation fail-safe
        client = TokenStreamClient(self.base_url+'/v1',model_id,timeout=float(self.cfg.get('stream_idle',180)))
        order = sorted(task_ids,key=lambda t:(-_order_score(challenges[t]),list(sorted(task_ids)).index(t)))
        indexed = {tid:i for i,tid in enumerate(sorted(task_ids))}
        active={}
        records={}
        completed=0
        emitted=[]
        # Publish only once per completed request. Error records are diagnostic, not a success.
        def finish(tid, future):
            nonlocal completed
            try:
                rec=future.result()
            except Exception as exc:
                rec={'task_id':tid,'branch':0,'publish_seq':1,'accepted':False,'status':'error',
                     'error':repr(exc),'direct_queries':[]}
            records[tid]=[rec]
            emitted.append(rec)
            if rec['status']=='done':
                completed+=1
            if on_branch_done:
                on_branch_done(rec)
        pending={}
        next_i=0
        with concurrent.futures.ThreadPoolExecutor(max_workers=nworkers) as pool:
            while (next_i<len(order) or pending) and time.monotonic()<answer_stop:
                now=time.monotonic()
                while next_i<len(order) and len(pending)<nworkers and now<no_admit and now<drain_at:
                    tid=order[next_i]
                    next_i+=1
                    pending[pool.submit(self._one_task,tid,challenges[tid],hard_end,drain_at,
                        answer_stop,client,indexed[tid],int(self.cfg.get('max_model_len',131072)),active)]=tid
                if now>=drain_at:
                    for p1,p2 in list(active.values()):
                        p1.cancel()
                if now>=answer_stop:
                    for p1,p2 in list(active.values()):
                        p1.cancel();p2.cancel()
                done,_=concurrent.futures.wait(pending,timeout=0.1,
                    return_when=concurrent.futures.FIRST_COMPLETED)
                for f in done:
                    finish(pending.pop(f),f)
                if not pending and (next_i==len(order) or now>=no_admit):
                    break
            for p1,p2 in list(active.values()):
                p1.cancel();p2.cancel()
            # Do not block arbitrarily on failed network reads after answer deadline.
            for f,tid in list(pending.items()):
                try:
                    finish(tid,f)
                except Exception:
                    pass
        # Every completed task has one callback; skipped tasks are recorded distinctly.
        for tid in order[next_i:]:
            rec={'task_id':tid,'branch':0,'publish_seq':1,'status':'skipped_budget',
                 'accepted':False,'direct_queries':[],'generated_tokens':0}
            records[tid]=[rec]
            emitted.append(rec)
        self.E12A.SCHED_LAST={'mode':'E31_DIRECT','completed':completed,'total':len(order),
            'workers':nworkers,'elapsed_sec':round(time.monotonic()-start,2),
            'skipped':len(order)-len(pending)-next_i,'stragglers':0,'gauges':[],
            'branches_done':completed,'branches_accepted':0}
        self._write_reports(records,challenges,start,hard_end,emitted)
        return records

    def _write_reports(self, records, challenges, start, hard_end, emitted):
        attempts=e31_build_submission(challenges,records)
        dest=self.out_dir
        with open(dest/'e31_direct_records.jsonl','w',encoding='utf8') as f:
            for rec in emitted:
                for row in rec.get('direct_queries') or [{'query_index':i,'mapping_source':'fallback',
                                  'fallback_reason':'task_not_completed','has_grid':False}
                                  for i in range(len(challenges[rec['task_id']]['test']))]:
                    qi = row['query_index']
                    att = attempts[rec['task_id']][qi]
                    hit = (int(att['attempt_1'] == self.solutions[rec['task_id']][qi] or
                               att['attempt_2'] == self.solutions[rec['task_id']][qi])
                           if self.solutions is not None and rec['task_id'] in self.solutions else None)
                    f.write(json.dumps({'task_id':rec['task_id'],'group':rec.get('group'),
                           'mode':rec.get('mode'),'status':rec.get('status'), 'hit':hit,
                           'think_tokens':rec.get('think_tokens',0), 'answer_tokens':rec.get('answer_tokens',0),
                           'generated_tokens':rec.get('generated_tokens',0),
                           'p1_finish':rec.get('p1_finish'),'p2_finish':rec.get('p2_finish'),
                           **{k:v for k,v in row.items() if k!='grid'}},ensure_ascii=False)+'\n')
        totals={'queries':0,'query_hits':0,'fully_solved_tasks':0,'task_norm_sum':0.0,'tasks':0}
        groups={}
        by_task={}
        for tid,ch in challenges.items():
            rec=(records.get(tid) or [{}])[0]
            group=self.cfg.get('groups',{}).get(tid,'unknown')
            g=groups.setdefault(group,totals.copy())
            qh=0
            for qi,att in enumerate(attempts[tid]):
                if self.solutions is not None and tid in self.solutions:
                    gold=self.solutions[tid][qi]
                    qh+=int(att['attempt_1']==gold or att['attempt_2']==gold)
            n=len(ch['test'])
            by_task[tid]={'group':group,'queries':n,'query_hits':qh if self.solutions else None,
                          'fully_solved':bool(qh==n) if self.solutions else None,
                          'think_tokens':rec.get('think_tokens',0),
                          'answer_tokens':rec.get('answer_tokens',0),
                          'mode':rec.get('mode'), 'status':rec.get('status')}
            if self.solutions is not None:
                for groupstat in (g,totals):
                    groupstat['queries']+=n;groupstat['query_hits']+=qh
                    groupstat['fully_solved_tasks']+=int(qh==n)
                    groupstat['task_norm_sum']+=qh/n
            g['tasks']+=1;totals['tasks']+=1
        for x in [totals,*groups.values()]:
            x['task_norm_pct']=(100*x['task_norm_sum']/x['tasks'] if self.solutions and x['tasks'] else None)
        duration=max(1e-6,time.monotonic()-start)
        decoded=sum(r.get('generated_tokens',0) for rows in records.values() for r in rows)
        coverage={str(k):sum(int((rows or [{}])[0].get('think_tokens',0)>=k)
                   for rows in records.values()) for k in (60000,78000,104000)}
        report={'mode':'E31_DIRECT30','solve_wall_sec':duration,'window_sec':hard_end-start,
                'aggregate_decode_tok_s':decoded/duration,
                'decoded_tokens':decoded,'prefill_tokens':sum(r.get('prompt_tokens',0) for rows in records.values() for r in rows),
                'per_request_tok_s':{tid:rec[0].get('generated_tokens',0)/max(.001,rec[0].get('elapsed_sec',1))
                                     for tid,rec in records.items()},
                'coverage_think_tokens':coverage,'overall':totals,'by_group':groups,
                'multi_test':{tid:v for tid,v in by_task.items() if len(challenges[tid]['test'])>1},
                'per_task':by_task,'status_counts':dict(Counter(r[0].get('status') for r in records.values())),
                'comparison':self.cfg.get('comparison',{}),
                'note':'DIRECT-only attempts; attempted score is pass@2; gold not present in hidden rerun.'}
        _write_json_atomic(dest/'e31_direct_report.json',report)
        self.last_report=report


def install(E12A, *, tokenizer, challenges, sgl_url, cfg, out_dir, log=print, solutions=None):
    """Install E31 on the exact module E28 calls; pass SGL_URL, never E18 port."""
    return DirectHandle(E12A,tokenizer,challenges,sgl_url,cfg,out_dir,log,solutions)
