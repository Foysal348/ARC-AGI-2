from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import json, hashlib, ast, base64, lzma, difflib, re, shutil
src=Path(__file__).resolve().parent/'BASELINE'
out=Path(__file__).resolve().parent/'REBUILT';out.mkdir(exist_ok=True)
original=(src/'BUILD__e31_direct.py').read_text()
s=original

def rep(old,new,tag):
 global s
 n=s.count(old)
 if n!=1: raise ValueError((tag,n))
 s=s.replace(old,new,1)
rep('LIB_VERSION = "e31_direct 1.0 (2026-11-01)"', 'LIB_VERSION = "e31_direct 1.1 (2026-11-02 GPU audit fix)"', 'lib_version')
rep('"temperature": 0.6, "drain_min": 23}', '"temperature": 0.6, "drain_min": 26}', 'drain-default')
rep('    assert THINK_CLOSE_ID in STOP_IDS, STOP_IDS\n', '''    # Verify the *actual* pinned tokenizer, not merely record a possible mismatch.
    # Fake-tokenizer harnesses may not use these Flash-Next IDs.
    if not harness:
        assert THINK_CLOSE_ID == FN_THINK_CLOSE_ID, ("E31_THINK_CLOSE_ID_MISMATCH", THINK_CLOSE_ID)
        assert STOP_IDS == FN_STOP_IDS, ("E31_STOP_IDS_MISMATCH", STOP_IDS)
    assert THINK_CLOSE_ID in STOP_IDS, STOP_IDS
''', 'stop-guard')
rep('        cap = phase1_cap(len(ids), think, answer, max_model_len)\n', '        cap = phase1_cap(len(ids), think, answer * NTEST[tid], max_model_len)\n', 'per-test-answer-budget')
rep('             "stop_ids": STOP_IDS, "stop_ids_equal_spec": STOP_IDS == FN_STOP_IDS, "think_close_id": THINK_CLOSE_ID,\n',
    '             "stop_ids": STOP_IDS, "stop_ids_equal_spec": STOP_IDS == FN_STOP_IDS, "think_close_id": THINK_CLOSE_ID,\n', 'stats-guard') if False else None
rep('"error_retries": 0, "error_finishes": 0, "server_down_polls": 0,', '"error_retries": 0, "error_finishes": 0, "phase1_resumes": 0, "phase2_resumes": 0, "server_down_polls": 0,', 'stats-retries')
rep('''        prefix = list(st["prompt_ids"]) + list(st["p1_ids"]) + list(st["p2_prefix"])
        room = max_model_len - len(prefix) - 8
        cap = min(int(answer_cap(st["tid"])), room)
        if cap < 64:
            return False
        st["phase"] = 2; st["p2_cap"] = cap; st["p2_ids"] = []; st["p2_prefix_len"] = len(prefix)
''', '''        # On a phase-2 transport error, preserve every streamed answer token.
        # A new request continues the exact token prefix rather than restarting
        # (which previously discarded partial grids). Keep one total answer budget.
        if resend:
            while st["p2_ids"] and st["p2_ids"][-1] in EOS_IDS:
                st["p2_ids"].pop()
        prefix = list(st["prompt_ids"]) + list(st["p1_ids"]) + list(st["p2_prefix"])
        if resend:
            prefix += list(st["p2_ids"])
        room = max_model_len - len(prefix) - 8
        cap = min(int(answer_cap(st["tid"])) - (len(st["p2_ids"]) if resend else 0), room)
        if cap < 1:
            return False
        st["phase"] = 2; st["p2_cap"] = cap; st["p2_prefix_len"] = len(prefix)
        if not resend:
            st["p2_ids"] = []
''', 'phase2-preserve')
rep('''        eng.add_request(st["p2_rid"], prefix, cap, temp, task_seed(TASK_INDEX[st["tid"]], 2))
        return True

    def finish(st, reason):''', '''        eng.add_request(st["p2_rid"], prefix, cap, temp, task_seed(TASK_INDEX[st["tid"]], 2))
        return True

    def resume_phase1(st):
        """Resume after transport failure WITHOUT promoting a partial/zero-token
        reasoning trace into an answer. Keep the original cap, token-ID prefix,
        and phase-1 seed. This is a new request, not a continuation of an open one.
        """
        while st["p1_ids"] and st["p1_ids"][-1] in EOS_IDS:
            st["p1_ids"].pop()
        left = P1_CAPS[st["tid"]] - len(st["p1_ids"])
        prefix = list(st["prompt_ids"]) + list(st["p1_ids"])
        if left < 1 or len(prefix) + left > max_model_len:
            return False
        st["phase"] = 1
        st["p1_rid"] = rid(st["tid"], 1, st["retries"])
        eng.add_request(st["p1_rid"], prefix, left, temp, task_seed(TASK_INDEX[st["tid"]], 1))
        SCHED["phase1_resumes"] += 1
        return True

    def finish(st, reason):''', 'resume-phase1')
rep('''                    if not start_phase2(s, resend=(kind == "p2")):
                        finish(s, "no_room_for_answer")
''', '''                    if kind == "p1" and now < DRAIN:
                        # A transient HTTP 500 / server restart is NOT the signal
                        # to stop thinking. Only the configured drain may force close.
                        if not resume_phase1(s):
                            if not start_phase2(s):
                                finish(s, "no_room_for_answer")
                    elif kind == "p1":
                        if not start_phase2(s):
                            finish(s, "no_room_for_answer")
                    else:
                        SCHED["phase2_resumes"] += 1
                        if not start_phase2(s, resend=True):
                            finish(s, "no_room_for_answer")
''', 'pending-resume')
# explicit partial transcript retained during P2 retry: existing finish already concatenates p2_ids
# file and notebook
(out/'e31_direct.py').write_text(s)
(out/'original_e31_direct.py').write_text(original)
(out/'e31_direct.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),s.splitlines(True),fromfile='a/e31_direct.py',tofile='b/e31_direct.py')))
nb=json.loads((src/'NB__PUSH_q27-xhigh-e31-fn-direct30.ipynb').read_text())
code1=''.join(nb['cells'][2]['source']); c7=''.join(nb['cells'][7]['source'])
# Resolve source bundle via AST without evaluating uploaded code.
tree=ast.parse(code1)
assign=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='E28_SRC' for t in n.targets))
b85call=next(n for n in ast.walk(assign.value) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='b85decode')
assert isinstance(b85call.args[0],ast.Constant)
old_b85=b85call.args[0].value
old_js=lzma.decompress(base64.b85decode(old_b85)).decode()
mods=json.loads(old_js); assert mods['e31_direct.py']==original
(out/'e28k100_lib.py').write_text(mods['e28k100_lib.py'])
mods['e31_direct.py']=s
new_js=json.dumps(mods,sort_keys=True,separators=(',',':'))
new_hash=hashlib.sha256(new_js.encode()).hexdigest()
new_b85=base64.b85encode(lzma.compress(new_js.encode(),preset=9|lzma.PRESET_EXTREME)).decode('ascii')
assert old_b85 in code1
code1=code1.replace(old_b85,new_b85)
# sha-pinned runtime literal wrapper, and edit at the beginning of CELL 1
old_hash=hashlib.sha256(old_js.encode()).hexdigest(); assert old_hash in code1
code1=code1.replace(old_hash,new_hash)
old_cfg="E31_CFG = {'think': 104000, 'answer': 8192, 'window_min': 170, 'workers': 24, 'temperature': 0.6, 'drain_min': 23}"
new_cfg=old_cfg.replace("'drain_min': 23","'drain_min': 26")
assert code1.count(old_cfg)==1
code1=code1.replace(old_cfg,new_cfg)
# adapt record-only report to fail on token IDs mismatch at solver entry (and keep it visible in cell7b)
oldw='_w = min(int(workers), int(E31_CFG["workers"]))'
neww='_w = min(int(E31_CFG["workers"]), int(E12_RUN.get("streams") or workers))  # DIRECT has no Duck Python sandbox isolation restriction'
assert c7.count(oldw)==1
c7=c7.replace(oldw,neww)
nb['cells'][2]['source']=code1.splitlines(keepends=True)
nb['cells'][7]['source']=c7.splitlines(keepends=True)
for idx,c in enumerate(nb['cells']):
 if c['cell_type']=='code':
  compile(''.join(c['source']),f'cell{idx}','exec')
new_nb=(json.dumps(nb,separators=(',',':'),ensure_ascii=False)+'\n').encode()
name='E31_FN_DIRECT30_AUDITED_FIX.ipynb'; (out/name).write_bytes(new_nb)
# reference for reading changes - E31 cell7b and sha-pinned module summary
(out/'CELL7B_PATCHED.py').write_text(c7)
facts=json.loads((src/'BUILD__e31_build_facts.json').read_text())
facts.update(notebook_sha256=hashlib.sha256(new_nb).hexdigest(),bytes=len(new_nb),notebook=name,modules={k:hashlib.sha256(v.encode()).hexdigest() for k,v in mods.items()},modules_json_sha256=new_hash)
facts['e31'].update(lib='e31_direct 1.1 (2026-11-02 GPU audit fix)', cfg={**facts['e31']['cfg'],'drain_min':26},cfg_line=new_cfg,direct_sha256=hashlib.sha256(s.encode()).hexdigest(),cell7b_sha256=hashlib.sha256(c7.encode()).hexdigest())
facts['e31']['edits'] += ['AUDIT: p1 failure resumes before DRAIN; p2 failure keeps streamed tokens','AUDIT: multi-test p1 budget reserves answer*N','AUDIT: direct workers use server stream cap, not Duck sandbox floor','AUDIT: stop-id fail-closed and drain reserve 26 minutes']
# Export reconstructed readable cell6/7 using the existing readable export as original baseline
orig_export=(src/'BUILD__e31_code_export.py').read_text()
original_code1=''.join(json.loads((src/'NB__PUSH_q27-xhigh-e31-fn-direct30.ipynb').read_text())['cells'][2]['source'])
original_c7=''.join(json.loads((src/'NB__PUSH_q27-xhigh-e31-fn-direct30.ipynb').read_text())['cells'][7]['source'])
assert orig_export.count(original_code1)==1
assert orig_export.count(original_c7)==1
new_export=orig_export.replace(original_code1,code1).replace(original_c7,c7)
(out/'e31_code_export.py').write_text(new_export)
facts['export_sha256']=hashlib.sha256(new_export.encode()).hexdigest()
facts['export']='e31_code_export.py'
facts['module_paths']={'e28k100_lib.py':'e28k100_lib.py','e31_direct.py':'e31_direct.py'}
(out/'e31_build_facts.json').write_text(json.dumps(facts,indent=2,ensure_ascii=False)+'\n')
print('Original',len((src/'NB__PUSH_q27-xhigh-e31-fn-direct30.ipynb').read_bytes()),'patched notebook bytes:',len(new_nb),'new module:',len(s),'module SHA:',facts['e31']['direct_sha256'])
assert len(new_nb)<400000, 'notebook exceeds 400 kB'
assert json.loads(lzma.decompress(base64.b85decode(new_b85)))['e31_direct.py']==s
print('SUCCESS',out)
