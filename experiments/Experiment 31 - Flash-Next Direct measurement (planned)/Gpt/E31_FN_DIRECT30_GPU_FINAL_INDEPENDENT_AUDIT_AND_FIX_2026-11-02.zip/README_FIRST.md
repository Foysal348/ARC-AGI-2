# E31 DIRECT30 — independent GPU-final audit output ZIP

**Start with `00_AUDIT_REPORT.md`**. The original notebook has a confirmed severe Phase-1 error-recovery bug (transient HTTP error becomes premature forced close), plus answer-loss and budget risks. This archive contains the corrected notebook, patch, source, tests, identity metadata and an exact portable rebuild from the included old snapshot.

## Main files

- **`E31_FN_DIRECT30_AUDITED_FIX.ipynb`** — patched 395,152-byte notebook. This is the only notebook in the root to consider for a new Kaggle GPU diagnostic after CPU-kit verification.
- `e31_direct.py` — patched server client + solver.
- `e31_direct.patch` — explicit source diff.
- `CELL7B_PATCHED.py` — adjusted notebook integration cell (DIRECT worker count).
- `e31_build_facts.json` — current module / notebook SHA identity.
- `e31_unit_tests_UPDATED.py` — update of the original fixture-dependent suite (its full run needs unavailable external EVAL/tokenizer fixtures).
- `test_adversarial_e31.py` — **18/18 independently passed** local adversarial tests.
- `test_real_http_sse.py` — **2/2 independently passed** real urllib/SSE tests, including HTTP500 + recovery.
- `rebuild_from_baseline.py` — regenerates files under `REBUILT/` using only `BASELINE/`. Byte equality to delivered patched notebook/code/export/facts verified.
- `KIT_*__*.json` — old notebook's **recorded** CPU-kit reports for provenance; they do **not** validate the new notebook.
- `00_MANIFEST_SHA256.json` — archive contents SHA256.

## Reproduce locally

```bash
python test_adversarial_e31.py
python test_real_http_sse.py
python rebuild_from_baseline.py
```

After rebuild compare `REBUILT/E31_FN_DIRECT30_AUDITED_FIX.ipynb` byte-for-byte with the root notebook. No external Python dependencies are required by these three commands.

## Important

The original Kaggle units kit showed **74/75** (missing `typing.Any` in the kit contrast fixture); original `real` and `e2e-commit` reports were `ALL_OK`. The revised source is **a new SHA** and still needs its own Kaggle CPU kits and GPU execution.

Do **not** use the `BASELINE/` notebook for a new commit. It is retained only as a reproducibility source.
