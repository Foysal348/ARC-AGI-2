# ==================================================================== CELL 7b — E31: the DIRECT solver replaces Duck (E12A.solve_all_r6)
# User 2026-11-01 (Exp 31): e21_cell6 looks E12A.solve_all_r6 up at call time, so this rebind swaps Duck for the proven ORDER2
# direct method (e31_direct.py, sha-pinned in CELL 1's E28_SRC literal) with Duck's signature, return and record contract:
# e21_cell6 (window, preflight, watchdog, the E15B writer callback), e21_cell7 (score, bundle), the nb5 phase record and the
# E28 report run unchanged. E12A.build_submission -> e31_build_submission, DIRECT-only (audit E31-2): the direct records' own
# ORDER2 make_attempts (attempt_1 = the model grid, attempt_2 = the test input / its mirror), the identity for a task without a
# record; no Duck candidate / CPU rule. The solver returns as soon as every task is done (E31_CFG window_min is a cap). Full
# thinking of every request: phase dir duck/<task>_b0/ (transcript.txt + token_ids.json).
E31_RUN = {"calls": [], "tokenizer": None}


def e31_tok():
    """The checkpoint's own tokenizer + chat template (CELL 8's NB5_LOCAL_TOK: the pinned klee100 tokenizer / template hashes
    verified), ORDER2's render (enable_thinking True, reasoning_effort xhigh) and decode; EOS ids from generation_config.json."""
    if not NB5_LOCAL_TOK.get("verified"):
        raise RuntimeError("E31: the Flash-Next tokenizer / template are not the pinned ones: " + str(NB5_LOCAL_TOK.get("why")))
    _hf, _tp = NB5_LOCAL_TOK["hf"], NB5_LOCAL_TOK["template"]
    _gp = next((p_ for p_ in (CKPT / "generation_config.json", Path(str(globals().get("K100_DIR") or "/nonexistent")) / "generation_config.json")
                if p_.is_file()), None)
    _eos = (json.loads(_gp.read_text(encoding="utf-8")).get("eos_token_id") if _gp is not None else None) or []
    t_ = {"render": lambda m_: _hf.apply_chat_template(m_, tokenize=False, add_generation_prompt=True, enable_thinking=True,
                                                      reasoning_effort="xhigh", chat_template=_tp),
          "encode": lambda s_: TOK.encode(s_, add_special_tokens=False).ids,
          "decode": lambda i_, k_: TOK.decode(list(i_), skip_special_tokens=bool(k_)),
          "eos_ids": _eos if isinstance(_eos, list) else [_eos]}
    E31_RUN["tokenizer"] = {"generation_config": str(_gp), "eos_ids": t_["eos_ids"],
                            "stop_ids_equal_spec": t_["encode"](E31D.STOP_THINKING_TEXT) == E31D.FN_STOP_IDS,
                            "think_close_ids": t_["encode"]("</think>")}
    return t_


def e31_solve_all_r6(tasks, order, *, out_dir, deadline, base_url, model_id, on_branch_done=None, workers=10,
                     capacity_probe=None, **_rest):
    """E12A.solve_all_r6's signature: Duck-only keyword arguments are recorded (ignored_args), never used."""
    _w = min(int(E31_CFG["workers"]), int(E12_RUN.get("streams") or workers))  # DIRECT has no Duck Python sandbox isolation restriction
    # audit E31-6: the client talks to THIS notebook's booted server only (E28's SGL_URL, port NB5_PORT; never E18's 8011);
    # e21_relaunch keeps the port, so the URL holds across a relaunch; the E15B watchdog is the one lifecycle owner
    _srv_url = str(getattr(E11_SERVER, "url", "") or "").rstrip("/")
    assert SGL_URL and SGL_URL.rstrip("/") == _srv_url and SGL_URL.rstrip("/").endswith(f":{NB5_PORT}") \
        and str(base_url).rstrip("/") == SGL_URL.rstrip("/") + "/v1", ("E31: base_url != the booted server", SGL_URL, _srv_url, base_url, NB5_PORT)
    E31_RUN["calls"].append({"tasks": len(tasks), "workers_arg": int(workers), "workers": _w, "base_url": base_url,
                             "model_id": model_id, "deadline_in_sec": round(deadline - time.monotonic(), 1), "ignored": sorted(_rest)})
    return E31D.solve_all_direct(tasks, order, out_dir=out_dir, deadline=deadline, base_url=SGL_URL, model_id=model_id,
                                 on_branch_done=on_branch_done, workers=_w, capacity_probe=capacity_probe, cfg=E31_CFG,
                                 tok=e31_tok(), solutions=SOLUTIONS, report_dir=BASE_OUT, server_down=E12A.SERVER_DOWN,
                                 metrics=e21_counters, sched_last=E12A.SCHED_LAST, sampler_path=OUT / "nb5_sampler.jsonl",
                                 t0_pc=NOTEBOOK_T0, harness=E11_HARNESS, ignored=sorted(_rest))


if not hasattr(E12A, "_e31_orig_solve_all_r6"):      # once (a re-run of this cell never wraps twice)
    E12A._e31_orig_solve_all_r6, E12A._e31_orig_build_submission = E12A.solve_all_r6, E12A.build_submission


def e31_build_submission(tasks, records):
    """audit E31-2: DIRECT-only (no Duck candidate, no harvested program, no CPU train-exact rule): the direct record's ORDER2
    make_attempts per test input; a task without a direct record = the identity (ORDER2 write_submission)."""
    return E31D.build_submission_direct(tasks, records)


E12A.solve_all_r6, E12A.build_submission = e31_solve_all_r6, e31_build_submission
CONFIG["e31_solver"] = {"lib": E31D.LIB_VERSION, "solve_all_r6": "e31_solve_all_r6", "build_submission": "e31_build_submission"}
print("E31: E12A.solve_all_r6 -> the direct solver (", E31D.LIB_VERSION, ") | E31_CFG", json.dumps(E31_CFG), "| budget",
      E31_BUDGET_MIN, "min | deadman", K100_DEADMAN_SEC, "s", flush=True)
