"""Independent adversarial CPU tests for E31 GPU-final audit fixes.
Run: python test_adversarial_e31.py (no Kaggle/GPU/real tokenizer required).
Script validates the *patched* e31_direct.py from this package.
"""
import importlib.util, json, tempfile, time, hashlib, ast
from pathlib import Path

D=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('e31_direct_audit',D/'e31_direct.py')
E=importlib.util.module_from_spec(spec); spec.loader.exec_module(E)

class FakeStream:
    scenarios={}
    instances=[]
    def __init__(self,*args,**kw):
        self.requests=[]; self.events=[];self.stats={'fake':True};self.req_stats={}
        FakeStream.instances.append(self)
    def add_request(self,rid,prompt,max_tokens,temperature,seed):
        n=len(self.requests)
        phase=int(rid.split('|')[1]); att=int(rid.split('|')[2]);tid=rid.split('|')[0]
        self.requests.append({'rid':rid,'prompt':list(prompt),'cap':max_tokens,'seed':seed})
        mode=FakeStream.scenarios.get(tid,'p1_zero_error')
        if phase==1:
            if att==0 and mode in ('p1_zero_error','p1_partial_error'):
                ids=[111,248046] if mode=='p1_partial_error' else []
                reason='error'
            elif mode=='p2_partial_error':
                ids=[111];reason='length'
            else:
                ids=[E.FN_THINK_CLOSE_ID,999];reason='stop'
        else:
            if att==0 and mode=='p2_partial_error':ids=[999];reason='error'
            else:ids=[998];reason='stop'
        self.events.append(E._Output(rid,ids,reason))
        self.req_stats[rid]={'t0':time.time(),'t_first':time.time(),'t_end':time.time(),'n':len(ids),'finish':reason,'max_tokens':max_tokens,'seed':seed}
    def step(self):
        if self.events: return [self.events.pop(0)]
        time.sleep(0.005);return []
    def abort_request(self,ids):
        for rid in ids:self.events=[x for x in self.events if x.request_id!=rid]
    def live(self):return 0

E.StreamEngine=FakeStream
old_a,old_h=E.ADMIT_STOP_BEFORE_END_SEC,E.HARD_BEFORE_END_SEC
E.ADMIT_STOP_BEFORE_END_SEC=.1
E.HARD_BEFORE_END_SEC=.15

def encode(text):
    if text=='</think>':return [E.FN_THINK_CLOSE_ID]
    if text==E.STOP_THINKING_TEXT:return list(E.FN_STOP_IDS)
    return [123]*6000  # long prompt, material difference for three-test cap

def decode(ids,skip):
    if 999 in ids:return '```grid\n1\n```'
    return ''

TOK={'render':lambda msgs:msgs[0]['content'],'encode':encode,'decode':decode,'eos_ids':[248046,248044]}

def task(n):return {'train':[{'input':[[0]],'output':[[1]]}], 'test':[{'input':[[0]]} for _ in range(n)]}

count=0

def check(name,cond):
    global count
    assert cond,name
    count+=1;print('PASS',name)

def run(mode,n=1,harness=True):
    FakeStream.instances.clear();FakeStream.scenarios={'a1':mode}
    work=Path(tempfile.mkdtemp(prefix='e31audit_',dir='/tmp'))
    records=[];s={}
    result=E.solve_all_direct({'a1':task(n)},out_dir=work/'duck',report_dir=work,deadline=time.monotonic()+4,
        base_url='http://127.0.0.1:8001',model_id='test',workers=24, cfg={'think':104000,'answer':8192,'drain_min':.015},
        tok=TOK,solutions={'a1':[{'output':[[1]]} for _ in range(n)]},sched_last=s,on_branch_done=records.append,
        health=lambda:True,harness=harness,log=lambda *a,**k:None)
    return FakeStream.instances[0],result,records,s

try:
    eng,res,records,s=run('p1_zero_error')
    r=records[0]
    check('HTTP 500: phase1 request retried rather than forced-close',len(eng.requests)==2 and all('|1|' in x['rid'] for x in eng.requests))
    check('zero-token error: retry cap equals original cap',eng.requests[0]['cap']==eng.requests[1]['cap'])
    check('zero-token error: mode NATURAL, 1 error, not counted as successful error',r['e31']['mode']=='natural' and r['e31']['end_reason']=='natural' and s['e31']['request_errors']==1 and s['e31']['error_finishes']==0)
    check('zero-token error: original phase1 seed preserved',eng.requests[0]['seed']==eng.requests[1]['seed'])
    check('zero-token error: resumed phase1 metric',s['e31']['phase1_resumes']==1)
    eng,res,records,s=run('p1_partial_error')
    check('partial phase1: resumed prompt has exact retained tokens, EOS stripped',eng.requests[1]['prompt']==eng.requests[0]['prompt']+[111])
    check('partial phase1: remaining cap decrements by retained length',eng.requests[1]['cap']==eng.requests[0]['cap']-1)
    check('partial phase1: no premature Phase2 call',all('|1|' in x['rid'] for x in eng.requests))
    eng,res,records,s=run('p2_partial_error')
    check('phase2 error: second attempt retains partial output in prompt',len(eng.requests)==3 and eng.requests[2]['prompt']==eng.requests[1]['prompt']+[999])
    check('phase2 error: retry has remaining answer budget',eng.requests[2]['cap']==eng.requests[1]['cap']-1)
    check('phase2 error: combined generated P2 token history kept',records[0]['e31']['p2_tokens']==2 and s['e31']['phase2_resumes']==1)
    eng,res,records,s=run('p1_zero_error',3)
    expected=E.phase1_cap(6000,104000,8192*3,131072)
    check('3-test Phase1 cap reserves answer x 3',eng.requests[0]['cap']==expected and expected==100240)
    check('3-test DIRECT-only submissions cannot add Duck candidates',set(res)=={'a1'} and len(E.build_submission_direct({'a1':task(3)},res)['a1'])==3)
    code=(D/'CELL7B_PATCHED.py').read_text()
    check('DIRECT workers use E12 configured server streams, not Duck isolation floor','E12_RUN.get("streams") or workers' in code and 'min(int(workers), int(E31_CFG' not in code)
    check('default drain gives >= full 3-test budget plus one-minute hard margin',E.CFG_DEFAULT['drain_min']>=E.drain_need_min(3,8192)+1)
    # Test non-harness fail-closed pinned tokenizer check using deliberate mismatch.
    bad=dict(TOK,encode=lambda t: [1] if t=='</think>' else encode(t))
    try:
        E.solve_all_direct({'a1':task(1)},out_dir=Path(tempfile.mkdtemp()),deadline=time.monotonic()+4,
            base_url='http://127.0.0.1:8001',model_id='test',tok=bad,health=lambda:True,harness=False,
            cfg={'think':104000,'answer':8192},log=lambda *a,**k:None)
    except AssertionError as ex:
        check('real-mode tokenizer mismatch FAILS BEFORE first request', 'E31_THINK_CLOSE_ID_MISMATCH' in str(ex))
    else: raise AssertionError('real-mode mismatch accepted')
    # Static notebook identity and module inside compressed literal, without eval(uploaded code).
    import base64,lzma
    nb=json.loads((D/'E31_FN_DIRECT30_AUDITED_FIX.ipynb').read_text())
    for c in nb['cells']:
        if c['cell_type']=='code':compile(''.join(c['source']),'<notebook>','exec')
    c1=''.join(nb['cells'][2]['source']);tree=ast.parse(c1)
    assign=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='E28_SRC' for t in n.targets))
    call=next(n for n in ast.walk(assign.value) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='b85decode')
    mods=json.loads(lzma.decompress(base64.b85decode(call.args[0].value)))
    check('patched notebook embeds exact patched solver source',mods['e31_direct.py']==(D/'e31_direct.py').read_text())
    check('patched notebook 400KB limit',len((D/'E31_FN_DIRECT30_AUDITED_FIX.ipynb').read_bytes())<400000)
    print(f'\n{count}/{count} PASS')
finally:
    E.ADMIT_STOP_BEFORE_END_SEC=old_a
    E.HARD_BEFORE_END_SEC=old_h
