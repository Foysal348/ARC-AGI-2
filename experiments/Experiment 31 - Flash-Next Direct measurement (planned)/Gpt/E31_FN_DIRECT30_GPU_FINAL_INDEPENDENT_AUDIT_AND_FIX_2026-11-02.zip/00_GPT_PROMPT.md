# FINAL GPU audit: E31 Flash-Next DIRECT 30 (Kaggle 4xL4, klee100 on Merlin vLLM-0.32 fork, hosted in the E28 K100 notebook)

**Answer GO or NO-GO on the first line. Then list ONLY BLOCKERS and SEVERE bugs** (crash, wasted run, wrong / lost answer,
wrong grid-to-test mapping, a request error counted as a finish, deadline overrun, wrong score), each with file:line, why,
fix. No style items, no new features.

The GPU notebook is `NB__PUSH_q27-xhigh-e31-fn-direct30.ipynb` (sha 1939954665c723dcf9321ac383cd1f9fdf15c00b483782936223baf91661e55b); readable code `BUILD__e31_code_export.py`, solver `BUILD__e31_direct.py`.
Design + the 3 design-audit fix list: `DESIGN__E31.md`, `FIXLIST__design_audits.md` (CONSOLIDATED list at the end). Build
report: `REPORT__E31_build_agent_report_2026-11-02.md`. CPU kits on this exact sha: `KIT_real__*` ALL OK, `KIT_e2e-commit__*`
ALL OK (fake streaming token-id server, 24 streams, kill + relaunch), `KIT_units__*` 74/75 (the 1 fail = a kit-only test that
exec's Duck's select_attempts_r5 without `from typing import Any`, Py3.12 evaluates annotations; not notebook code).

A comparison of this build vs 3 independent builds (`REPORT__E31_four_build_comparison_agent_report_2026-11-02.md`) found in
THIS build: (1) a phase-1 request error (HTTP 500 / kill) is followed, after the server recovers, by an immediate forced-close
phase 2 (e31_direct.py ~774-778) even with 0 thinking tokens -> proposed fix: before the drain, resend phase 1 with prompt +
kept phase-1 ids (EOS stripped), cap = remaining, same seed; forced close only at/after the drain; (2) phase-1 cap uses
`answer` not `answer x N` (e31_direct.py:563; only b6f77b65 changes); (3) workers = min(E28 isolation-gated workers, cfg)
-> the Duck sandbox fail-safe (6) would cap DIRECT; (4) STOP_IDS / </think> only recorded, not asserted. Confirm or refute
each, say whether any is a blocker, and list anything else.
Questions: (a) can any task's answer be lost / mis-mapped / mis-scored? (b) can a request error ever be counted as a finish?
(c) can the run exceed its deadline or idle to the window end? (d) is the DIRECT-only submission adapter exact (no Duck / CPU
candidate can enter) for 1/2/3-test tasks? (e) anything that would crash on GPU that the CPU kits cannot see?
