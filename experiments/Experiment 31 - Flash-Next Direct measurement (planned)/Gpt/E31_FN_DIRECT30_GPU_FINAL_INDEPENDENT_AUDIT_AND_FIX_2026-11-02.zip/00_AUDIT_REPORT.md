# NO-GO (original) — E31 FN DIRECT30 GPU FINAL independent audit / patched candidate

**Source ZIP:** `E31_FN_DIRECT30_GPU_FINAL_audit_FLAT_2026-11-02(2).zip` (2026-11-02). 31 source-manifest entries were independently SHA256 checked, with zero mismatches. The original notebook is `NB__PUSH_q27-xhigh-e31-fn-direct30.ipynb`, SHA256 `1939954665c723dcf9321ac383cd1f9fdf15c00b483782936223baf91661e55b`, 394,400 bytes. It is the exact SHA referred to by its archived reports.

## Required, demonstrated source-level fixes

| Severity | Evidence in **original** bundle | Failure condition | Patch in this package | Validation |
|---|---|---|---|---|
| **HIGH, wrong/lost answer** | `BUILD__e31_direct.py:774–778`, `:799–813` | A phase-1 HTTP 500/server restart marks phase-1 pending; once health returns it calls `start_phase2` **unconditionally**, sometimes with zero thinking tokens | `resume_phase1()` retains streamed tokens, strips trailing EOS, keeps seed, subtracts retained tokens from cap. Only the configured drain can force-close | Test: 0-token error, partial-token error, same seed/cap, real urllib HTTP500/SSE |
| **HIGH, lost answer on retry** | `BUILD__e31_direct.py:592–612`, especially `:607` | A phase-2 error calls `start_phase2(resend=True)`, which resets `p2_ids=[]`; already streamed grids are lost | A resumed phase-2 includes retained answer-token IDs in its new exact prompt, preserves `p2_ids` and subtracts already generated output tokens from the cap | Test: phase-2 partial-grid error followed by successful continuation |
| **HIGH risk, answer truncation** | `BUILD__e31_direct.py:563` | Phase 1 reserves only one `answer` allocation instead of `answer × n_test`. The supplied comparison report says the 3-test task `b6f77b65` has cap 104000, vs desired 102234 | `phase1_cap(len(ids), think, answer * NTEST[tid], max_model_len)` | Test: 6000-token prompt, 3 tests => 100240 cap |
| **Conditional HIGH, experiment coverage** | `BUILD__e31_code_export.py:4818`, CELL 7b | DIRECT inherits the Duck Python-sandbox isolation floor (possibly 6 workers), even though DIRECT has no tool sandbox | `min(E31_CFG['workers'], E12_RUN['streams'])`, preserving configured max server streams | Static notebook assertion and CPU fake 24-worker tests from archived report |
| **HIGH risk, deadline/answer cut** | `BUILD__e31_direct.py:37–56` | `drain_min=23`, but actual phase-2 execution ends at `T−1 min`. At 18 tok/s, 3×8192 tokens need 22.76 min; the original gives only 22 min before hard-stop | Default `drain_min=26` in both solver and editable CELL 1 | Unit formula check, notebook consistency |
| **Fail-closed validation** | `BUILD__e31_direct.py:530–550` | `FN_STOP_IDS`/`FN_THINK_CLOSE_ID` equality is recorded, but a valid-looking alternate encoding could proceed | Strict equality assertions in real mode, before any inference request | Deliberately mismatched tokenizer is rejected |

No evidence of a new wrong 1/2/3-test grid mapping for the explicit `grid K` contract. `build_submission_direct()` selects only `e31_attempts`; the archived `e2e-commit` report and reviewer comparison exercise DIRECT-only scoring. **Real model quality and GPU correctness remain unverified.**

## Tests and provenance

| Layer | Result | Basis |
|---|---|---|
| Original input ZIP manifest | **31/31 PASS** | Independently SHA256 checked |
| Original notebook identity | **PASS** | Independently compared to build facts |
| Original Kaggle real CPU kit | **ALL_OK** | Recorded archived report, **original SHA only** |
| Original Kaggle e2e-commit kit | **ALL_OK** | Recorded archived report, **original SHA only** |
| Original Kaggle units kit | **74/75; ALL_OK=false** | Reported failure due to missing `Any` import in test fixture, not notebook runtime |
| Patched module/adversarial CPU tests | **18/18 PASS** | Independently executed locally |
| Patched real `urllib` + SSE + HTTP500 tests | **2/2 PASS** | Independently executed locally |
| Patched notebook compile / packed module SHA | **PASS** | 9 code cells compile; exact embedded source matched |
| Portable rebuild | **BYTE IDENTICAL** | Regenerated notebook, solver, code export, build facts from included baseline |
| Patched Kaggle CPU kits | **NOT RUN** | Old kit reports are not transferable to new SHA |
| Patched Merlin 4×L4 GPU execution | **NOT RUN / UNVERIFIED** | No GPU session was run |

### Patched artifact

- `E31_FN_DIRECT30_AUDITED_FIX.ipynb` — ready-to-review Kaggle notebook, **395,152 bytes**, SHA256 `4862b02c05cfc099a388...` (full SHA in `e31_build_facts.json` and manifest)
- `e31_direct.py` — patched solver, SHA256 `3eee523002c99f1ce7c031866fb5477b8c3d2ce433b877ce786d1c6550fb33fe`
- `e31_direct.patch` — unified diff
- `CELL7B_PATCHED.py` — exact notebook binding cell
- `e31_unit_tests_UPDATED.py` — updates the old data-dependent Kaggle unit fixture to new semantics and fixes the `typing.Any` missing import. **Not fully rerun; requires the real EVAL, pinned tokenizer and Merlin fixtures.**
- `test_adversarial_e31.py`, `test_real_http_sse.py` — self-contained independent tests, no original private fixtures required.
- `rebuild_from_baseline.py` + `BASELINE/` — reproduces patched files byte-for-byte from the exact uploaded snapshot.

## Before the GPU commit

1. Use the patched notebook, **not** `BASELINE/NB__PUSH...ipynb`.
2. Run the updated unit suite with Kaggle's pinned tokenizer and actual 30-task EVAL challenges/solutions; fix any unexpected test failures. `E31T_NB` must point to the patched notebook and `E31T_FACTS` to its matched `e31_build_facts.json`.
3. Rebuild/re-run `real` and `e2e-commit` CPU kits against the **new SHA**. The old kit reports are for the previous notebook and do not authorize a new GPU verdict.
4. GPU run: verify server relaunch, 24 active requests, no false forced-close after an HTTP error, token-ID trace retention, 3-test labeled grid mapping, and scoring via DIRECT-only `e31_attempts`.
5. Preserve your existing E28 K100 production notebook untouched.

**Verdict:** NO-GO for uploading the original exact GPU notebook. **Patched candidate: GO for new Kaggle CPU-kit validation; GPU launch only after the rebuilt kits pass.** No production-performance claim.
