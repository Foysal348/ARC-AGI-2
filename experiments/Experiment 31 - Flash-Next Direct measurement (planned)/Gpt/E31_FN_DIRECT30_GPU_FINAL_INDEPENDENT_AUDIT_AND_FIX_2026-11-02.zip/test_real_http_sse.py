"""Real urllib streaming transport / HTTP500-resume regression, no GPU needed."""
import importlib.util, json, tempfile, time, threading
from pathlib import Path
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
D=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('e31_sse',D/'e31_direct.py')
E=importlib.util.module_from_spec(spec);spec.loader.exec_module(E)
class H(BaseHTTPRequestHandler):
 def log_message(self,*args):pass
 def do_GET(self):
  self.send_response(200);self.send_header('Content-Length','0');self.end_headers()
 def do_POST(self):
  b=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
  self.server.reqs.append(b)
  if len(self.server.reqs)==1:
   self.send_error(500,'transient');return
  self.send_response(200);self.send_header('Content-Type','text/event-stream');self.send_header('Connection','close');self.end_headers();self.close_connection=True
  d={'choices':[{'index':0,'text':'','token_ids':[E.FN_THINK_CLOSE_ID,999], 'finish_reason':'stop'}]}
  self.wfile.write(b'data: '+json.dumps(d).encode()+b'\n\ndata: [DONE]\n\n');self.wfile.flush()
srv=ThreadingHTTPServer(('127.0.0.1',0),H);srv.reqs=[]
threading.Thread(target=srv.serve_forever,daemon=True).start()
old_a,old_h=E.ADMIT_STOP_BEFORE_END_SEC,E.HARD_BEFORE_END_SEC
E.ADMIT_STOP_BEFORE_END_SEC=.1;E.HARD_BEFORE_END_SEC=.2
try:
 def encode(t):
  if t=='</think>':return [E.FN_THINK_CLOSE_ID]
  if t==E.STOP_THINKING_TEXT:return list(E.FN_STOP_IDS)
  return [123,124]
 tok={'encode':encode,'render':lambda m:'fake prompt','decode':lambda i,skip:'```grid\n1\n```' if 999 in i else '', 'eos_ids':[248046,248044]}
 done=[];sched={};t=time.monotonic()
 E.solve_all_direct({'a1':{'train':[],'test':[{'input':[[0]]}]}},out_dir=Path(tempfile.mkdtemp()),
  deadline=t+6,base_url=f'http://127.0.0.1:{srv.server_address[1]}',model_id='fake',workers=1,
  tok=tok,health=lambda:True,harness=True,solutions={'a1':[{'output':[[1]]}]},
  cfg={'think':104000,'answer':8192,'drain_min':.02},on_branch_done=done.append,sched_last=sched, log=lambda *a,**k:None)
 assert len(srv.reqs)==2, len(srv.reqs)
 assert all(x['seed']==E.SEED+1 for x in srv.reqs),srv.reqs
 assert all(x['prompt']==[123,124] for x in srv.reqs),srv.reqs
 assert done[0]['e31']['end_reason']=='natural', done[0]['e31']
 assert sched['e31']['request_errors']==1 and sched['e31']['phase1_resumes']==1
 assert time.monotonic()<t+6
 print('PASS HTTP 500 -> same-seed phase-1 retry over real urllib/SSE -> natural finish')
 print('PASS finished before deadline with 1 transport error and 0 false model finishes')
finally:
 E.ADMIT_STOP_BEFORE_END_SEC=old_a;E.HARD_BEFORE_END_SEC=old_h;srv.shutdown();srv.server_close()
