Strict audit and proposed remediation only. Original notebook has NOT been patched. See E31_STRICT_AUDIT.md.
