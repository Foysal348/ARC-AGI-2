"""Run: python test_e31_direct.py (stdlib only, 0 GPU)."""
import json, sys, threading, time, tempfile, types
from pathlib import Path
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
sys.path.insert(0,str(Path(__file__).parent))
import e31_direct as e

class Tok:
    def __init__(self):self.calls=[]
    def encode(self,s,add_special_tokens=False):
        self.calls.append(s)
        if s==e.STOP_TEXT:return list(e.STOP_IDS_EXPECTED)
        if s=='</think>':return [e.THINK_CLOSE_ID]
        return [101, int(s.count('FINAL INPUT ') or 1), 102]
    def decode(self,ids,skip_special_tokens=True):
        mapping={901:'```grid\n1 2\n```',902:'```grid 1\n1 2\n```\n```grid 2\n3 4\n```',
                 903:'```grid 1\n1 2\n```\n```grid 2\n3 4\n```\n```grid 3\n5 6\n```'}
        return ''.join(mapping.get(i,'') for i in ids)
    def apply_chat_template(self,msg,**kw):return msg[0]['content']+'<think>\n'

TESTS=0
def check(x):
    global TESTS
    TESTS+=1
    assert x, 'failed assertion '+str(TESTS)

def task(n=1):
    return {'train':[{'input':[[1]],'output':[[2]]}],
            'test':[{'input':[[i+1,i+2]]} for i in range(n)]}

def parser_tests():
    G1=[[1,2]];G2=[[3,4]];G3=[[5,6]]
    check(e.user_message(task(1)['train'],[[[1,2]]]) ==
        'You are solving an abstract reasoning puzzle. Each example has an INPUT grid and its OUTPUT grid (digits 0-9 are colors; 0 is usually background). Infer the ONE rule that maps every input to its output, then apply it to the FINAL INPUT.\n\nExample 1 INPUT:\n1\nExample 1 OUTPUT:\n2\n\nFINAL INPUT:\n1 2\n\nReason step by step however you like. Then give ONLY the final output grid as rows of space-separated digits inside a fenced block:\n```grid\n<rows>\n```\nOutput nothing after the block.')
    a=e.map_test_grids('```grid 2\n3 4\n```\n```grid 1\n1 2\n```',2)
    check([v[0] for v in a]==[G1,G2])
    check([v[1] for v in a]==['label','label'])
    check(e.map_test_grids('```grid 2\n3 4\n```',2)[0][0] is None)
    check(e.map_test_grids('```grid 1\n1 2\n```',2)[1][0] is None)
    check(e.map_test_grids('```grid 1\n5 6\n```\n```grid 1\n1 2\n```',2)[0][0]==G1)
    check(e.map_test_grids('```grid 3\n5 6\n```\n```grid 1\n1 2\n```\n```grid 2\n3 4\n```',3)[2][0]==G3)
    check(e.map_test_grids('```grid 1\n1 2\n```\n```\n3 4\n```',2)[1][0] is None)
    check([x[0] for x in e.map_test_grids('```\n1 2\n```\n```\n3 4\n```',2)]==[G1,G2])
    check(all(x[0] is None for x in e.map_test_grids('```\n1 2\n```\n```\n3 4\n```\n```\n5 6\n```',2)))
    check(all(x[0] is None for x in e.map_test_grids('```grid 2\n3 4\n```\n```grid 1\n1 2',2) if x[1]=='fallback') )
    check(e.map_test_grids('```grid 1\n1 2\n```\n```grid 2\n3 4\n```\n```grid 3\n5 6\n```',3)[2][0]==G3)
    check(e.map_test_grids('```grid 8\n9\n```\n```\n1 2\n```',2)[0][0] is None)
    check(e.parse_grid('```grid\n1 0 2\n3 4 5\n```')==[[1,0,2],[3,4,5]])
    check(e.parse_grid('```json\n[[1,2],[3,4]]\n```')==[[1,2],[3,4]])
    check(e.parse_grid('```grid\n1 10\n```') is None)
    check(e.make_attempts([[1,2]],[[3,4]])['attempt_1']==[[3,4]])
    check(e.make_attempts([[1,2]],[[1,2]])['attempt_2']==[[2,1]])
    check(e.make_attempts([[1,2]],None)['attempt_1']==[[1,2]])
    check(e.make_attempts([[1,2]],None)['attempt_2']==[[2,1]])
    check(e.make_attempts([[1,1]],None)['attempt_2']==[[1,1]])
    prefix,stop=e.phase2_prefix([11,12],[25,248046,248044],False,e.STOP_IDS_EXPECTED)
    check(prefix==[11,12,25]+e.STOP_IDS_EXPECTED)
    check(stop==e.STOP_IDS_EXPECTED)
    prefix,stop=e.phase2_prefix([11],[e.THINK_CLOSE_ID,99],True,e.STOP_IDS_EXPECTED)
    check(prefix==[11,e.THINK_CLOSE_ID,99] and not stop)
    check(e.answer_text(Tok(),[e.THINK_CLOSE_ID,901],[],[])[0]=='```grid\n1 2\n```')
    check(len(e.TASKS)==30 and sum(map(len,e.GROUPS.values()))==30)

class Server(ThreadingHTTPServer):
    request_queue_size=64

class SSE(BaseHTTPRequestHandler):
    requests=[];lock=threading.Lock();ever=False;kill=False
    def do_POST(self):
        n=int(self.headers.get('Content-Length','0'))
        body=json.loads(self.rfile.read(n))
        with self.lock:self.requests.append((self.path,body))
        if self.path!='/v1/completions':self.send_error(404);return
        if self.kill:
            self.close_connection=True;return
        self.send_response(200);self.send_header('Content-Type','text/event-stream');self.end_headers()
        try:
            if self.ever:
                while True:
                    self.wfile.write(b'data: {"choices":[{"token_ids":[501],"finish_reason":null}]}\n\n');self.wfile.flush()
                    time.sleep(.025)
            else:
                tests=body['prompt'][1]
                ids=[e.THINK_CLOSE_ID,900+tests] if len(body['prompt'])<=3 else [900+tests]
                self.wfile.write(('data: '+json.dumps({'choices':[{'token_ids':ids,'finish_reason':'stop'}]})+'\n\n').encode())
                self.wfile.write(b'data: [DONE]\n\n');self.wfile.flush()
        except (BrokenPipeError,ConnectionResetError,ValueError,OSError):pass
    def log_message(self,*a):pass

def e2e_tests():
    with tempfile.TemporaryDirectory() as tmp:
        s=Server(('127.0.0.1',0),SSE)
        s.timeout=.1
        thr=threading.Thread(target=s.serve_forever,daemon=True);thr.start()
        port=s.server_address[1]
        # Server/root binding is strictly :8001 in production. For local test, monkeypatch property.
        class E12: SCHED_LAST={}
        tok=Tok();tasks={str(i):task(1+(i%3)) for i in range(30)}
        cfg={'think':104000,'answer':8192,'window_min':170,'workers':24,'temperature':.6,'drain_min':24,
             'solutions':{str(i):[[[9,9]] for _ in range(1+(i%3))] for i in range(30)}}
        h=e.E31Handle(E12,tok,tasks,lambda:'http://127.0.0.1:8001',cfg,tmp,print)
        # E31 actual server endpoint strict check must never use E18 8011.
        check(h.url.endswith(':8001'))
        # Bind local HTTP server only at stream layer for fake E2E; no lifetime / relaunch code used.
        old=e.stream_ids
        def patched_stream(url,*args,**kw):return old('http://127.0.0.1:'+str(port),*args,**kw)
        e.stream_ids=patched_stream
        try:
            # For test: synthetic deadline compression (production deadlines stay 170 minutes).
            clock=e.time.monotonic
            e.time.monotonic=lambda:clock()*60
            # Instead do not execute solver under compressed clock: stream/timeout use real timestamps.
            e.time.monotonic=clock
            # Explicitly verify adapter for 1/2/3-test and no Duck candidates.
            h.records={'1':{'attempts':[e.make_attempts([[1,2]],[[3,4]])]}}
            sub=h.submission({'1':task(1)})
            check(sub['1'][0]['attempt_1']==[[3,4]])
            check(sub['1'][0]['attempt_2']==[[1,2]])
            check(sub['1'][0]['attempt_1']!=[[9,9]]) # would be a correct CPU rule; DIRECT remains wrong.
            h.records={}
            # Avoid running 170 real minutes: pass a test-time clock with scale only to solver.
            # For E2E, use direct concurrent stream clients with 24 threads, as in actual worker implementation.
            def one(i):
                return e.stream_ids(h.url,'model',[101,1,102],16,i,.6,threading.Event())
            with __import__('concurrent.futures').futures.ThreadPoolExecutor(max_workers=24) as pool:
                rows=list(pool.map(one,range(30)))
            check(len(rows)==30 and all(r[1]=='stop' for r in rows))
            check(len(SSE.requests)>=30 and all(p=='/v1/completions' for p,_ in SSE.requests))
            check(all(x['return_token_ids'] is True for _,x in SSE.requests))
            # Server kill produces an error, never an apparent successful finish.
            SSE.kill=True
            try:e.stream_ids(h.url,'model',[101,1,102],3,1,.6,threading.Event())
            except e.StreamFailure:pass
            else:raise AssertionError('server kill considered a finish')
            SSE.kill=False;SSE.ever=True
            flag=threading.Event();got={}
            def stream():got['x']=e.stream_ids(h.url,'model',[101,1,102],100,1,.6,flag)
            t=threading.Thread(target=stream,daemon=True);t.start();time.sleep(.12);flag.set();t.join(3)
            check(not t.is_alive() and got['x'][1]=='aborted')
            # Full 30-task fake solver, 24 concurrent workers, mixed 1/2/3 test queries.
            # The private clock test flag never applies in production.
            SSE.ever=False
            import os
            os.environ['E31_TEST_CLOCK']='1'
            h.cfg['_test_seconds_per_minute']=.016
            callbacks=[]
            order=list(tasks)
            try:
                report=h.solve(tasks,order,model_id='fake',on_branch_done=callbacks.append,workers=24)
            finally:
                os.environ.pop('E31_TEST_CLOCK',None)
            check(report['done']==30 and not report['failed'])
            check(len(callbacks)==30)
            check(all(x['branch']==0 and x['status']=='done' for x in callbacks))
            check(len(h.submission(tasks))==30)
            check(sum(len(v) for v in h.submission(tasks).values())==60)
            check((Path(tmp)/'q27x/e31_direct_report.json').exists())
            check(len((Path(tmp)/'q27x/e31_direct_records.jsonl').read_text().splitlines())==30)
            check(h.last_report['query_total']==60)
            check(h.E12A.SCHED_LAST['done']==30)
            check(h.last_report['groups']['other']['multi_test_tasks']==20)
            check(h.last_report['multi_test']['tasks']==20)
            # Every phase-1 stream refuses to close thinking; 24 simultaneous
            # forced-close continuations must be attempted at the drain boundary.
            SSE.ever=True
            before=len(SSE.requests)
            subset={k:tasks[k] for k in list(tasks)[:24]}
            os.environ['E31_TEST_CLOCK']='1'
            h.cfg['_test_seconds_per_minute']=.019
            try:
                drained=h.solve(subset,list(subset),model_id='fake',workers=24)
            finally:
                os.environ.pop('E31_TEST_CLOCK',None)
            check(drained['done']==24)
            check(drained['stragglers']<=24)
            check(len(h.records)==24)
            check(all(st['mode']=='forced_close' for st in h.records.values()))
            check(all(st['p2_injected_ids']==e.STOP_IDS_EXPECTED for st in h.records.values()))
            check(all(st['p1_finish']=='aborted' for st in h.records.values()))
            check(len(SSE.requests)-before>=48)  # 24 phase1 + 24 phase2
        finally:
            e.stream_ids=old;s.shutdown();s.server_close()

if __name__=='__main__':
    parser_tests();e2e_tests();print('PASS',TESTS,'assertions')
