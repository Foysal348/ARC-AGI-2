# E31 research injection: after E28 CELL 6/7 definitions; before CELL 8 boot/phase execution.
# Hidden competition rerun intentionally keeps the existing E28 Duck implementation unchanged.
if not RERUN and PROFILE == "E31_DIRECT30":
    import hashlib as _e31_hashlib, importlib.util as _e31_importlib, os as _e31_os
    from pathlib import Path as _e31_Path
    _e31_paths = ([_e31_Path(_e31_os.environ["E31_MODULE_PATH"])]
                   if _e31_os.environ.get("E31_MODULE_PATH") else
                   list(_e31_Path("/kaggle/input").glob("**/e31_direct.py")))
    if len(_e31_paths) != 1:
        raise RuntimeError("E31 source dataset missing/ambiguous: set E31_MODULE_PATH to exactly one e31_direct.py")
    _e31_src = _e31_paths[0]
    _e31_expected = "ed896fae21035d70e9d6b71988c0f45561e89d03fbb077bf2a7f8b2a72ae7599"
    if _e31_hashlib.sha256(_e31_src.read_bytes()).hexdigest() != _e31_expected:
        raise RuntimeError("E31_DIRECT_MODULE_SHA_MISMATCH: source dataset differs from audited module")
    _e31_spec = _e31_importlib.spec_from_file_location("e31_direct", str(_e31_src))
    _E31_MOD = _e31_importlib.module_from_spec(_e31_spec)
    _e31_spec.loader.exec_module(_E31_MOD)
    class _E31Tokenizer:
        # E28's TOK is tokenizers.Tokenizer; the verified HF object renders the chat template.
        def encode(self, text, add_special_tokens=False):
            return TOK.encode(text, add_special_tokens=add_special_tokens).ids
        def decode(self, ids, skip_special_tokens=True):
            return TOK.decode(ids, skip_special_tokens=skip_special_tokens)
        def apply_chat_template(self, messages, **kwargs):
            return _HF.apply_chat_template(messages, chat_template=_tpl, **kwargs)
    _E31_LOCAL_CFG = dict(E31_CFG)
    _E31_LOCAL_CFG['solutions'] = lambda: SOLUTIONS
    E31_HANDLE = _E31_MOD.install(E12A, tokenizer=lambda: _E31Tokenizer(),
                                    challenges=CHALLENGES, sgl_url=lambda: SGL_URL,
                                    cfg=_E31_LOCAL_CFG, out_dir=lambda: OUT, log=print)
    print('E31 DIRECT module installed', _e31_expected[:16], 'for eval-only', flush=True)
else:
    print('E31 not installed: preserve E28 hidden-rerun engine/solver', flush=True)
