"""Offline, fail-closed E31 research notebook builder. Never launches a GPU.
Usage: python build_e31_direct_notebook.py [path-to-E28-notebook]
The E31 module stays a separate Kaggle dataset to keep notebook <400KB.
"""
import json, hashlib, sys, pathlib, textwrap
ROOT=pathlib.Path(__file__).resolve().parent
SOURCE=pathlib.Path(sys.argv[1]) if len(sys.argv)>1 else ROOT/'BASE__E28_K100_notebook.ipynb'
NOTEBOOK=ROOT/'E31_FN_DIRECT30_RESEARCH.ipynb'
MODULE=ROOT/'e31_direct.py'
module_hash=hashlib.sha256(MODULE.read_bytes()).hexdigest()
base=json.loads(SOURCE.read_text())
assert len(base['cells'])==9
assert 'CELL 1' in ''.join(base['cells'][2]['source'])
assert 'CELL 6/7' in ''.join(base['cells'][6]['source'])
assert 'CELL 8' in ''.join(base['cells'][7]['source'])
config=''.join(base['cells'][2]['source'])
def once(old,new):
    global config
    if config.count(old)!=1:raise RuntimeError(f'anchor count={config.count(old)}: {old[:100]}')
    config=config.replace(old,new,1)

CFG_LINE="E31_CFG = {'think': 104000, 'answer': 8192, 'window_min': 170, 'workers': 24, 'temperature': 0.6, 'drain_min': 24}\n"
config=config.replace('# ==================================================================== CELL 1',CFG_LINE+'# ==================================================================== CELL 1',1)
once('K100_DEADMAN_SEC = 24900','K100_DEADMAN_SEC = 205 * 60')
once('NB5_DEFAULT_PROFILE = "E28EVAL120"','NB5_DEFAULT_PROFILE = "E31_DIRECT30"')
once('K100_PROFILES = ("E28EVAL120", "RERUN_PROD")',
     'K100_PROFILES = ("E28EVAL120", "E31_DIRECT30", "RERUN_PROD")')
# Deliberately preserve the original E28EVAL120 row, so the hidden RERUN_PROD is byte-equivalent in engine settings.
insert = '''
# E31 standalone evaluation: no E28 Duck A/B/C scheduler; DIRECT does its own ORDER2 queue.
E31_TASKS = %r
assert len(E31_TASKS) == len(set(E31_TASKS)) == 30
E31_LEVERS = dict(E28_LEVERS, e28_sched=False, plain_order=False)
PROFILE_TABLE["E31_DIRECT30"] = dict(
    _NB5_T, time_budget_sec=205*60, hard_margin_sec=5*60,
    source="eval", n_tasks=30, task_list=E31_TASKS,
    quality_ab=True, equal_windows=True,
    fixed_window_sec=E31_CFG['window_min']*60,
    nb5_phases=[["Q_E31_FN_DIRECT30", "all", None, "on", "A", "fp8"]],
    **E31_LEVERS)
assert PROFILE_TABLE["E31_DIRECT30"]["time_budget_sec"] >= (E31_CFG["window_min"]+35)*60
assert E31_CFG["drain_min"] >= 24 and E31_CFG["drain_min"] < E31_CFG["window_min"]-3
if not RERUN and PROFILE != "E31_DIRECT30":
    raise RuntimeError("This audit notebook is E31_DIRECT30-only in commit mode")
''' % ('2d0172a1 35ab12c3 409aa875 446ef5d2 4c3d4a41 4c416de3 5545f144 7491f3cf 7b5033c1 800d221b 89565ca0 9385bd28 a47bf94d a6f40cea b6f77b65 cbebaa4b 142ca369 247ef758 36a08778 581f7754 71e489b6 88e364bc a32d8b75 f931b4a8 135a2760 136b0064 1818057f 0934a4d8 13e47133 16b78196'.split(),)
once('PROFILE_TABLE["RERUN_PROD"] = dict(PROFILE_TABLE["RERUN_PROD"], **E28_LEVERS)',
     insert+'\nPROFILE_TABLE["RERUN_PROD"] = dict(PROFILE_TABLE["RERUN_PROD"], **E28_LEVERS)')
base['cells'][2]['source']=config.splitlines(True)
# One self-contained cell, no E18 engine class and no Merlin lifecycle modifications.
cell=f'''# E31 research injection: after E28 CELL 6/7 definitions; before CELL 8 boot/phase execution.
# Hidden competition rerun intentionally keeps the existing E28 Duck implementation unchanged.
if not RERUN and PROFILE == "E31_DIRECT30":
    import hashlib as _e31_hashlib, importlib.util as _e31_importlib, os as _e31_os
    from pathlib import Path as _e31_Path
    _e31_paths = ([_e31_Path(_e31_os.environ["E31_MODULE_PATH"])]
                   if _e31_os.environ.get("E31_MODULE_PATH") else
                   list(_e31_Path("/kaggle/input").glob("**/e31_direct.py")))
    if len(_e31_paths) != 1:
        raise RuntimeError("E31 source dataset missing/ambiguous: set E31_MODULE_PATH to exactly one e31_direct.py")
    _e31_src = _e31_paths[0]
    _e31_expected = "{module_hash}"
    if _e31_hashlib.sha256(_e31_src.read_bytes()).hexdigest() != _e31_expected:
        raise RuntimeError("E31_DIRECT_MODULE_SHA_MISMATCH: source dataset differs from audited module")
    _e31_spec = _e31_importlib.spec_from_file_location("e31_direct", str(_e31_src))
    _E31_MOD = _e31_importlib.module_from_spec(_e31_spec)
    _e31_spec.loader.exec_module(_E31_MOD)
    class _E31Tokenizer:
        # E28's TOK is tokenizers.Tokenizer; the verified HF object renders the chat template.
        def encode(self, text, add_special_tokens=False):
            return TOK.encode(text, add_special_tokens=add_special_tokens).ids
        def decode(self, ids, skip_special_tokens=True):
            return TOK.decode(ids, skip_special_tokens=skip_special_tokens)
        def apply_chat_template(self, messages, **kwargs):
            return _HF.apply_chat_template(messages, chat_template=_tpl, **kwargs)
    _E31_LOCAL_CFG = dict(E31_CFG)
    _E31_LOCAL_CFG['solutions'] = lambda: SOLUTIONS
    E31_HANDLE = _E31_MOD.install(E12A, tokenizer=lambda: _E31Tokenizer(),
                                    challenges=CHALLENGES, sgl_url=lambda: SGL_URL,
                                    cfg=_E31_LOCAL_CFG, out_dir=lambda: OUT, log=print)
    print('E31 DIRECT module installed', _e31_expected[:16], 'for eval-only', flush=True)
else:
    print('E31 not installed: preserve E28 hidden-rerun engine/solver', flush=True)
'''
base['cells'].insert(7,{'cell_type':'code','execution_count':None,'metadata':{},'outputs':[],
                       'source':cell.splitlines(True)})
for i,c in enumerate(base['cells']):
    if c['cell_type']=='code':
        code=''.join(c['source']);compile(code,f'<cell{i}>','exec')
NOTEBOOK.write_text(json.dumps(base,ensure_ascii=False,separators=(',',':'))+'\n')
size=NOTEBOOK.stat().st_size
if size>=400000:raise RuntimeError(f'notebook {size} bytes >=400k; do not ship')
print('NOTEBOOK',NOTEBOOK, 'bytes',size,'sha256',hashlib.sha256(NOTEBOOK.read_bytes()).hexdigest())
print('MODULE',MODULE,'bytes',MODULE.stat().st_size,'sha256',module_hash)
