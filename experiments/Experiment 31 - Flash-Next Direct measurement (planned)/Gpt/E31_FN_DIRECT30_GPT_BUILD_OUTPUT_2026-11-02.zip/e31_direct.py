"""E31 DIRECT30 experimental solver; E28 owns the server lifecycle.

No Kaggle GPU execution is represented by this module. Direct candidates only.
"""
from __future__ import annotations
import concurrent.futures, json, math, os, re, socket, threading, time, urllib.request
from pathlib import Path

STOP_TEXT = "\n\nConsidering the limited time by the user, I have to give the solution based on the thinking directly now.\n</think>\n\n"
STOP_IDS_EXPECTED = [271,79939,279,6973,854,539,279,1156,11,353,599,310,2873,279,6093,3018,383,279,7047,5774,1381,13,198,248069,271]
THINK_CLOSE_ID = 248069
EOS_IDS = {248046, 248044}
MAX_LEN = 131072
SAFETY = 256
GROUPS = {
    "main": "2d0172a1 35ab12c3 409aa875 446ef5d2 4c3d4a41 4c416de3 5545f144 7491f3cf 7b5033c1 800d221b 89565ca0 9385bd28 a47bf94d a6f40cea b6f77b65 cbebaa4b".split(),
    "partial": "142ca369 247ef758 36a08778 581f7754 71e489b6 88e364bc a32d8b75 f931b4a8".split(),
    "control": "135a2760 136b0064 1818057f 0934a4d8 13e47133 16b78196".split(),
}
TASKS = sum((v for v in GROUPS.values()), [])
assert len(TASKS) == len(set(TASKS)) == 30
GROUP_BY_TASK = {x: g for g, xs in GROUPS.items() for x in xs}
FENCE = re.compile(r"```([^\n`]*)\n(.*?)```", re.S)
JSON_ROW = re.compile(r"\[\s*\d(?:\s*,\s*\d)*\s*\]")
SEP_ROW = re.compile(r"\[?\s*\d(?:\s*[, ]\s*\d)*\s*\]?,?")
LABEL = re.compile(r"^\s*grid\s+(\d+)\s*$", re.I)


def valid_grid(g):
    return (isinstance(g,list) and 1 <= len(g) <= 30 and
            all(isinstance(r,list) and 1 <= len(r) <= 30 for r in g) and
            len({len(r) for r in g}) == 1 and
            all(type(v) is int and 0 <= v <= 9 for r in g for v in r))


def parse_row(s):
    s = s.strip()
    if not s: return None
    if re.fullmatch(r"\d+",s): return [int(c) for c in s]
    if SEP_ROW.fullmatch(s): return [int(c) for c in re.findall(r"\d",s)]
    return None


def first_row_run(lines):
    rows=[]
    for line in lines:
        v=parse_row(line)
        if v is None:
            if rows: break
            continue
        rows.append(v)
    return rows if valid_grid(rows) else None


def from_obj(obj):
    if isinstance(obj,dict):
        for k in ('output','grid','test_output','answer','test_outputs'):
            if k in obj:return from_obj(obj[k])
        return None
    if valid_grid(obj): return obj
    if isinstance(obj,list) and obj and valid_grid(obj[-1]): return obj[-1]
    return None


def grid_from_block(body):
    b=body.strip()
    if b[:1] in ('[','{'):
        try: g=from_obj(json.loads(b))
        except (ValueError,TypeError): g=None
        if g is not None:return g
        grids=[];cur=[]
        for m in JSON_ROW.finditer(b):
            cur.append(json.loads(m.group()))
            if b[m.end():].lstrip().startswith(']'):
                grids.append(cur);cur=[]
        if cur:grids.append(cur)
        for g in reversed(grids):
            if valid_grid(g):return g
    return first_row_run(b.splitlines())


def parse_grid(text):
    # E10 ORDER2: last valid fenced grid; otherwise last valid plain row-run.
    for _, body in reversed(FENCE.findall(text or '')):
        g=grid_from_block(body)
        if g is not None:return g
    runs=[];cur=[]
    for line in (text or '').splitlines():
        v=parse_row(line)
        if v is None:
            if cur:runs.append(cur);cur=[]
        else:cur.append(v)
    if cur:runs.append(cur)
    return next((g for g in reversed(runs) if valid_grid(g)),None)


def map_test_grids(text, n):
    """Fail-closed for ambiguous multi-test answers. Never cross-assign labeled grids."""
    if n == 1:
        g = parse_grid(text)
        return [(g,'single' if g is not None else 'fallback',None if g is not None else 'no_valid_grid')]
    blocks=FENCE.findall(text or '')
    labeled={}; labeled_exists=False; valid_unlabeled=[]
    for header,body in blocks:
        m=LABEL.fullmatch(header)
        if m:
            labeled_exists=True
            k=int(m.group(1))
            if 1 <= k <= n:
                g=grid_from_block(body)
                if g is not None:labeled[k-1]=g
        else:
            g=grid_from_block(body)
            if g is not None:valid_unlabeled.append(g)
    if labeled_exists:
        return [(labeled[i],'label',None) if i in labeled else (None,'fallback','missing_label') for i in range(n)]
    # No positional inference if an out-of-range labeled block exists, or a different block count.
    if len(valid_unlabeled) == n:
        return [(g,'positional',None) for g in valid_unlabeled]
    return [(None,'fallback','ambiguous_or_missing_blocks') for _ in range(n)]


def make_attempts(input_grid, model_grid):
    cands = ([('model',model_grid)] if valid_grid(model_grid) else []) + [
        ('test_input',input_grid),('mirror',[list(reversed(r)) for r in input_grid])]
    uniq=[]
    for source,grid in cands:
        if all(grid != prev for _,prev in uniq):uniq.append((source,grid))
    while len(uniq)<2:uniq.append(uniq[-1])
    return {'attempt_1':uniq[0][1], 'attempt_2':uniq[1][1],
            'src_1':uniq[0][0], 'src_2':uniq[1][0]}


def render_grid(grid):
    return '\n'.join(' '.join(str(int(v)) for v in row) for row in grid)


def user_message(train,test_inputs):
    # Single-test path byte-matches E10 ORDER2's build_user_message().
    parts=["You are solving an abstract reasoning puzzle. Each example has an "
           "INPUT grid and its OUTPUT grid (digits 0-9 are colors; 0 is usually "
           "background). Infer the ONE rule that maps every input to its output, "
           "then apply it to the FINAL INPUT.\n"]
    for i,p in enumerate(train):
        parts.append("Example %d INPUT:\n%s\nExample %d OUTPUT:\n%s\n" % (
            i+1,render_grid(p['input']),i+1,render_grid(p['output'])))
    if len(test_inputs)==1:
        parts.append("FINAL INPUT:\n%s\n" % render_grid(test_inputs[0]))
        parts.append("Reason step by step however you like. Then give ONLY the final "
                     "output grid as rows of space-separated digits inside a fenced "
                     "block:\n```grid\n<rows>\n```\nOutput nothing after the block.")
    else:
        for i,g in enumerate(test_inputs):
            parts.append('FINAL INPUT %d:\n%s\n' % (i+1,render_grid(g)))
        parts.append('Reason step by step however you like. Then give ONLY the final '
                     'output grid for EACH FINAL INPUT, in order, as rows of space-separated digits '
                     'inside a separately labeled fenced block for each input:\n'
                     '```grid 1\n<rows>\n```\n...\n```grid %d\n<rows>\n```\n'
                     'Output nothing after the last block.' % len(test_inputs))
    return '\n'.join(parts)


def render_prompt(tokenizer,train,test_inputs):
    return tokenizer.apply_chat_template([{'role':'user','content':user_message(train,test_inputs)}],
            tokenize=False,add_generation_prompt=True,enable_thinking=True,reasoning_effort='xhigh')


def tokenize(tokenizer,text):
    v=tokenizer.encode(text,add_special_tokens=False)
    return [int(x) for x in (v.ids if hasattr(v,'ids') else v)]


def decode(tokenizer,ids):
    return tokenizer.decode([int(x) for x in ids],skip_special_tokens=True)


def answer_text(tokenizer,p1,p2prefix,p2):
    ids=list(p1)+list(p2prefix)+list(p2)
    if THINK_CLOSE_ID not in ids:return '',False
    k=len(ids)-1-ids[::-1].index(THINK_CLOSE_ID)
    return decode(tokenizer,ids[k+1:]),True


def phase2_prefix(prompt_ids,p1_ids,closed,stop_ids):
    one=list(p1_ids)
    if not closed:
        while one and one[-1] in EOS_IDS:one.pop()
    injection=[] if closed else list(stop_ids)
    return list(prompt_ids)+one+injection,injection


class StreamFailure(RuntimeError): pass


def stream_ids(url,model_id,prompt_ids,max_tokens,seed,temperature,cancel,*,timeout=120):
    """vLLM 0.32 SSE contract: requires actual token_ids, never text retokenization."""
    body={'model':model_id,'prompt':list(prompt_ids),'max_tokens':int(max_tokens),
          'temperature':float(temperature),'top_p':0.95,'top_k':20,'seed':int(seed),
          'stream':True,'return_token_ids':True,'skip_special_tokens':False}
    req=urllib.request.Request(url.rstrip('/')+'/v1/completions', data=json.dumps(body).encode(),
            headers={'Content-Type':'application/json'},method='POST')
    ids=[];finish=None;usage={};response=None;finished=threading.Event()
    try:
        response=urllib.request.urlopen(req,timeout=timeout)
        def close_on_cancel():
            while not finished.is_set():
                if cancel.wait(.05):
                    if response is not None:
                        # Closing a buffered HTTPResponse from another thread can
                        # wait on readline's lock. Shutdown the underlying socket
                        # first so blocked SSE reads wake immediately.
                        try:
                            sock=getattr(getattr(response.fp,'raw',None),'_sock',None)
                            if sock:sock.shutdown(socket.SHUT_RDWR)
                        except Exception:pass
                        try: response.close()
                        except Exception: pass
                    break
        threading.Thread(target=close_on_cancel,daemon=True).start()
        for raw in response:
            if cancel.is_set():return ids,'aborted',usage
            line=raw.strip()
            if not line.startswith(b'data:'):continue
            payload=line[5:].strip()
            if payload==b'[DONE]':break
            obj=json.loads(payload)
            if obj.get('error') or obj.get('object')=='error':raise StreamFailure(str(obj.get('error') or obj)[:300])
            if isinstance(obj.get('usage'),dict):usage.update(obj['usage'])
            for ch in obj.get('choices') or []:
                chunk=ch.get('token_ids')
                if chunk is None:
                    if ch.get('text'):raise StreamFailure('MISSING_STREAM_TOKEN_IDS')
                    chunk=[]
                ids.extend(int(v) for v in chunk)
                if ch.get('finish_reason') is not None:finish=str(ch['finish_reason'])
            if finish is not None:break
        if cancel.is_set():return ids,'aborted',usage
        if finish is None:raise StreamFailure('SSE_EOF_WITHOUT_FINISH_REASON')
        return ids,finish,usage
    except Exception as e:
        if cancel.is_set():return ids,'aborted',usage
        raise StreamFailure(str(e)[:300]) from e
    finally:
        finished.set()
        if response is not None:response.close()


def order2(challenges,order):
    rank={tid:i for i,tid in enumerate(order)}
    return sorted(order,key=lambda t:(-(int(len(challenges[t]['train'])>=3)+int(len(challenges[t]['test'])==1)),rank[t]))


def atomic_json(path,value):
    p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    tmp=p.with_name(p.name+'.'+str(threading.get_ident())+'.tmp')
    with tmp.open('w',encoding='utf-8') as f:json.dump(value,f,ensure_ascii=False)
    os.replace(tmp,p)


def append_jsonl(path,value,lock):
    with lock:
        p=Path(path);p.parent.mkdir(parents=True,exist_ok=True)
        with p.open('a',encoding='utf-8') as f:f.write(json.dumps(value,ensure_ascii=False)+'\n')


class E31Handle:
    def __init__(self,E12A,tokenizer,challenges,sgl_url,cfg,out_dir,log):
        self.E12A=E12A;self._tokenizer=tokenizer;self.challenges=challenges
        self._sgl_url=sgl_url;self.cfg=dict(cfg)
        self._out_dir=out_dir;self.log=log or print;self.lock=threading.Lock()
        self.records={};self.completed=set();self.last_report={}
        self.stop_ids=None
        if not 0 < int(cfg['workers']) <= 24:raise ValueError('workers must be 1..24')
        if not 1 < float(cfg['drain_min']) < float(cfg['window_min'])-3:raise ValueError('invalid drain')

    @property
    def out_dir(self):
        p=self._out_dir() if callable(self._out_dir) else self._out_dir
        return Path(p)/'q27x'

    @property
    def tokenizer(self):
        return self._tokenizer() if callable(self._tokenizer) else self._tokenizer

    @property
    def url(self):
        url = self._sgl_url() if callable(self._sgl_url) else self._sgl_url
        return str(url or '').rstrip('/')

    def submission(self,challenges,records=None):
        # No Duck CPU-rule candidates, no harvested agents; only E31 direct attempts.
        return {tid:[{k:attempt[k] for k in ('attempt_1','attempt_2')}
                     for attempt in self.records.get(tid,{}).get('attempts',[
                         make_attempts(q['input'],None) for q in ch['test']])]
                for tid,ch in challenges.items()}

    def solve(self,challenges,order,*,out_dir=None,deadline=None,base_url=None,model_id='q27',
              on_branch_done=None,workers=None,**kwargs):
        if base_url is not None and base_url.rstrip('/') != self.url+'/v1':
            raise RuntimeError('E31 base_url does not match E28 SGL_URL')
        if not self.url.endswith(':8001'):
            raise RuntimeError('E31 SGL_URL mismatch (expected E28 :8001)')
        self.stop_ids=tokenize(self.tokenizer,STOP_TEXT)
        if tokenize(self.tokenizer,'</think>') != [THINK_CLOSE_ID] or self.stop_ids != STOP_IDS_EXPECTED:
            raise RuntimeError('TOKENIZER_STOP_IDS_MISMATCH')
        unit=(float(self.cfg['_test_seconds_per_minute'])
              if os.environ.get('E31_TEST_CLOCK')=='1' and '_test_seconds_per_minute' in self.cfg else 60.0)
        if not 0 < unit <= 60:raise ValueError('invalid clock unit')
        now=time.monotonic();deadline=float(deadline) if deadline else now+unit*float(self.cfg['window_min'])
        total_end=min(deadline,now+unit*float(self.cfg['window_min']))
        drain=total_end-unit*float(self.cfg['drain_min']);
        no_admit=total_end-max(12*unit,(float(self.cfg['drain_min'])+2)*unit)
        answer_end=total_end-unit
        if not now < no_admit < drain < answer_end < total_end:
            raise RuntimeError('E31 solve window shortened below required drain margins')
        self.records={};self.completed=set()
        task_order=order2(challenges,list(order)); queue=list(task_order)
        parallel=min(int(self.cfg['workers']),int(workers) if workers else int(self.cfg['workers']))
        report={'mode':'E31_DIRECT','tasks':len(task_order),'workers':parallel,'started_epoch':time.time(),
                'planned_window_sec':round(total_end-now,3),'drain_min':self.cfg['drain_min'],
                'task_order':task_order,'groups':{},'errors':[],'stragglers':0}
        cancel_all=threading.Event(); done_lock=threading.Lock(); futures={};failed=[]
        # Partials are captured by streaming in the worker and finalized only after the phase2 window.
        def one_task(tid):
            ch=challenges[tid];inputs=[q['input'] for q in ch['test']];t0=time.monotonic()
            text=render_prompt(self.tokenizer,ch['train'],inputs)
            prompt=tokenize(self.tokenizer,text)
            room=MAX_LEN-len(prompt)-len(inputs)*int(self.cfg['answer'])-SAFETY
            cap=max(0,min(int(self.cfg['think']),room))
            st={'task_id':tid,'group':GROUP_BY_TASK.get(tid,'other'), 'prompt_tokens':len(prompt),
                'phase1_cap':cap,'thinking_floor_met':cap>=60000,'p1_ids':[], 'p2_ids':[],
                'mode':'unknown','error':None,'p1_finish':None,'p2_finish':None,'t0_epoch':time.time()}
            if cap<64:
                st['error']='INSUFFICIENT_CONTEXT';return self._finish_task(tid,ch,st,on_branch_done)
            # One task = one prompt, one thinking stream, one optional continuation.
            p1_cancel=threading.Event();p2_cancel=threading.Event()
            def trip_drain():
                while time.monotonic()<drain and not cancel_all.is_set() and not p1_cancel.is_set():
                    time.sleep(min(.05,max(.001,drain-time.monotonic())))
                if time.monotonic()>=drain:p1_cancel.set()
            threading.Thread(target=trip_drain,daemon=True).start()
            try:
                st['p1_ids'],st['p1_finish'],st['p1_usage']=stream_ids(self.url,model_id,prompt,cap,
                    20261005+10*task_order.index(tid)+1,self.cfg['temperature'],p1_cancel)
                st['mode']='natural'
            except StreamFailure as e:
                st['error']='PHASE1_STREAM_ERROR: '+str(e)
                st['wall_sec']=time.monotonic()-t0
                return self._finish_task(tid,ch,st,on_branch_done,success=False)
            finally:
                p1_cancel.set()
            closed=THINK_CLOSE_ID in st['p1_ids']
            if not (closed and st['p1_finish']!='length') and time.monotonic()<answer_end:
                prefix,injected=phase2_prefix(prompt,st['p1_ids'],closed,self.stop_ids)
                st['p2_injected_ids']=injected
                cap2=min(len(inputs)*int(self.cfg['answer']),MAX_LEN-len(prefix)-8)
                if cap2>=64:
                    st['phase2_attempted']=True
                    st['mode']='continue' if closed else 'forced_close'
                    def trip_answer():
                        while time.monotonic()<answer_end and not cancel_all.is_set() and not p2_cancel.is_set():
                            time.sleep(min(.05,max(.001,answer_end-time.monotonic())))
                        if time.monotonic()>=answer_end:p2_cancel.set()
                    threading.Thread(target=trip_answer,daemon=True).start()
                    try:
                        st['p2_ids'],st['p2_finish'],st['p2_usage']=stream_ids(self.url,model_id,prefix,cap2,
                            20261005+10*task_order.index(tid)+2,self.cfg['temperature'],p2_cancel)
                    except StreamFailure as e:
                        st['error']='PHASE2_STREAM_ERROR: '+str(e)
                        st['wall_sec']=time.monotonic()-t0
                        return self._finish_task(tid,ch,st,on_branch_done,success=False)
                    finally:
                        p2_cancel.set()
                else:st['mode']='no_room_for_answer'
            elif not closed:st['mode']='forced_close_no_budget'
            st['t1_epoch']=time.time();st['wall_sec']=time.monotonic()-t0
            return self._finish_task(tid,ch,st,on_branch_done)
        late_ids=[]
        with concurrent.futures.ThreadPoolExecutor(max_workers=parallel) as pool:
            while queue or futures:
                t=time.monotonic()
                while queue and t<no_admit and len(futures)<parallel:
                    tid=queue.pop(0);future=pool.submit(one_task,tid);futures[future]=tid
                if not futures:break
                done,_=concurrent.futures.wait(futures,timeout=min(.1,max(.01,total_end-time.monotonic())),
                                                    return_when=concurrent.futures.FIRST_COMPLETED)
                for f in done:
                    tid=futures.pop(f)
                    try:
                        result=f.result()
                        if result.get('error'):failed.append(tid)
                        else:self.completed.add(tid)
                    except Exception as e:
                        failed.append(tid);report['errors'].append({'task_id':tid,'error':repr(e)[:400]})
                if time.monotonic()>=total_end:
                    cancel_all.set()
                    late_ids=[tid for f,tid in futures.items() if not f.done()]
                    break
        # ThreadPoolExecutor waits for cancellation/close to finish. Reconcile the
        # completed callbacks after the join, otherwise the last 24 near-deadline
        # answers get persisted but are absent from scheduler.done.
        for f,tid in list(futures.items()):
            try:
                result=f.result()
                if result.get('error'):failed.append(tid)
                else:self.completed.add(tid)
            except Exception as ex:
                failed.append(tid)
                report['errors'].append({'task_id':tid,'error':repr(ex)[:400]})
        report['stragglers']=len(late_ids)
        report['late_task_ids']=late_ids
        report.update(done=len(self.completed),failed=len(failed),unadmitted=list(queue),
                      stopped_epoch=time.time(),solve_wall_sec=time.monotonic()-now,
                      deadline_overrun_sec=round(max(0.,time.monotonic()-total_end),3))
        self._write_report(report,challenges)
        self.E12A.SCHED_LAST.clear();self.E12A.SCHED_LAST.update(report)
        return report

    def _finish_task(self,tid,ch,st,on_branch_done,success=True):
        # Persist the full thinking stream, even for errors, without decode/re-tokenize for continuation.
        dest=self.out_dir/'thinking'/tid;dest.mkdir(parents=True,exist_ok=True)
        p1=list(st.get('p1_ids') or []);p2=list(st.get('p2_ids') or []);inject=st.get('p2_injected_ids') or []
        (dest/'phase1.txt').write_text(decode(self.tokenizer,p1),encoding='utf-8')
        (dest/'phase2.txt').write_text(decode(self.tokenizer,p2),encoding='utf-8')
        atomic_json(dest/'token_ids.json',{'phase1_ids':p1,'phase2_ids':p2,'injection_ids':inject})
        ans,has_close=answer_text(self.tokenizer,p1,inject,p2)
        mapped=map_test_grids(ans,len(ch['test']))
        attempts=[];queries=[]
        for i,(grid,source,reason) in enumerate(mapped):
            att=make_attempts(ch['test'][i]['input'],grid)
            attempts.append(att)
            queries.append({'query_index':i,'mapping_source':source,'fallback_reason':reason,
                            'has_grid':grid is not None,'attempt_source':att['src_1'],
                            'mode':st['mode'],'generated_tokens':len(p1)+len(p2),'error':st.get('error'),
                            'group':st['group'],'test_outputs':att})
        st['queries']=queries;st['attempts']=attempts;st['has_close']=has_close
        st['generated_tokens']=len(p1)+len(p2)
        required_usages=['p1_usage'] + (['p2_usage'] if st.get('phase2_attempted') else [])
        if all(isinstance(st.get(k),dict) and st[k].get('prompt_tokens') is not None
               for k in required_usages):
            entries=[st[k] for k in required_usages]
            p_sum=sum(int(u['prompt_tokens']) for u in entries)
            c_sum=sum(int((u.get('prompt_tokens_details') or {}).get('cached_tokens')
                          or u.get('cached_tokens') or 0) for u in entries)
            st['actual_prefill_tokens']=max(0,p_sum-c_sum)
            st['cached_tokens']=c_sum
        else:
            st['actual_prefill_tokens']=None
        self.records[tid]=st
        append_jsonl(self.out_dir/'e31_direct_records.jsonl',st,self.lock)
        if on_branch_done:
            # Minimal E28 branch record: DIRECT-only submission is retained by adapter, not Duck selector.
            rec={'task_id':tid,'branch':0,'publish_seq':1,'status':'done' if success and not st.get('error') else 'error',
                 'accepted':False,'train_exact':[], 't0':st.get('t0_epoch',time.time()),'t1':time.time(),
                 'submissions':[{'test_outputs':[a['attempt_1'] for a in attempts],
                                 'accepted':False,'train_exact':[],'publish_seq':1}],
                 'generated_tokens':st['generated_tokens'],'e31_direct':True}
            on_branch_done(rec)
        return st

    def _write_report(self,report,challenges):
        sols=self.cfg.get('solutions')
        if callable(sols):sols=sols()
        group_rows={}
        multi={'tasks':0,'queries':0,'query_hits':0,'fully_solved_tasks':0,'task_norm_sum':0.0}
        for tid,st in self.records.items():
            g=st['group'];entry=group_rows.setdefault(g,{'tasks':0,'queries':0,'query_hits':0,'fully_solved_tasks':0,
                            'task_norm':None,'generated_tokens':0,'prompt_tokens':0,
                            'multi_test_tasks':0,'coverage_60k':0,'coverage_78k':0,'coverage_104k':0})
            entry['tasks']+=1;n=len(st['queries']);entry['queries']+=n
            entry['multi_test_tasks']+=int(n>1)
            count=st.get('generated_tokens',0);entry['generated_tokens']+=count
            entry['prompt_tokens']+=st.get('prompt_tokens',0)
            for v,k in ((60000,'coverage_60k'),(78000,'coverage_78k'),(104000,'coverage_104k')):
                entry[k]+=int(len(st.get('p1_ids') or [])>=v)
            if n>1:
                multi['tasks']+=1;multi['queries']+=n
            if sols and tid in sols:
                hits=sum(int(a['attempt_1']==sols[tid][i] or a['attempt_2']==sols[tid][i]) for i,a in enumerate(st['attempts']))
                entry['query_hits']+=hits;entry['fully_solved_tasks']+=int(hits==n)
                entry['task_norm_sum']=entry.get('task_norm_sum',0.0)+hits/n
                entry['model_query_hits']=entry.get('model_query_hits',0)+sum(int(a['attempt_1']==sols[tid][i]) for i,a in enumerate(st['attempts']))
                if n>1:
                    multi['query_hits']+=hits;multi['fully_solved_tasks']+=int(hits==n)
                    multi['task_norm_sum']+=hits/n
        for g,e in group_rows.items():
            if sols and e['tasks']:e['task_norm']=round(e.pop('task_norm_sum',0.0)/e['tasks'],6)
        for group in GROUPS:
            group_rows.setdefault(group,{'tasks':0,'queries':0,'query_hits':0,'fully_solved_tasks':0,
                                     'model_query_hits':0,'task_norm':None,'generated_tokens':0,'prompt_tokens':0,
                                     'multi_test_tasks':0,'coverage_60k':0,'coverage_78k':0,'coverage_104k':0})
        multi['task_norm']=(round(multi.pop('task_norm_sum')/multi['tasks'],6)
                            if sols and multi['tasks'] else None)
        report['multi_test']=multi
        report['groups']=group_rows;report['query_total']=sum(len(c['test']) for c in challenges.values())
        report['completed_task_ids']=sorted(self.records)
        report['generated_tokens']=sum(s['generated_tokens'] for s in self.records.values())
        report['prompt_tokens']=sum(s['prompt_tokens'] for s in self.records.values())
        _pf=[s.get('actual_prefill_tokens') for s in self.records.values()]
        report['actual_prefill_tokens']=sum(_pf) if _pf and all(v is not None for v in _pf) else None
        report['prefill_telemetry_complete']=bool(_pf) and all(v is not None for v in _pf)
        report['aggregate_decode_tok_s']=round(report['generated_tokens']/max(.001,report['solve_wall_sec']),3)
        report['per_request_tok_s']={t:round(st['generated_tokens']/max(.001,st.get('wall_sec',1)),3)
                                    for t,st in self.records.items()}
        atomic_json(self.out_dir/'e31_direct_report.json',report)
        self.last_report=report


def install(E12A,*,tokenizer,challenges,sgl_url,cfg,out_dir,log=print):
    h=E31Handle(E12A,tokenizer,challenges,sgl_url,cfg,out_dir,log)
    E12A.solve_all_r6=h.solve
    E12A.build_submission=h.submission
    return h
