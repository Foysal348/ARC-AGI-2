# E31 CELL 1 / module injection — exact build instructions

This patch is already applied to `E31_FN_DIRECT30_RESEARCH.ipynb`. The builder `build_e31_direct_notebook.py` applies the same anchored changes to the included original E28 K100 reference notebook. Do not hand-edit the module literal or its SHA; rebuild.

## CELL 1 edits

Insert as the first statement in CELL 1:

```python
E31_CFG = {'think': 104000, 'answer': 8192, 'window_min': 170, 'workers': 24, 'temperature': 0.6, 'drain_min': 24}
```

Replace the original E28 default profile with:

```python
NB5_DEFAULT_PROFILE = "E31_DIRECT30"
K100_PROFILES = ("E28EVAL120", "E31_DIRECT30", "RERUN_PROD")
```

**The deadman is declared and armed from CELL 1, not CELL 0 in the provided E28 notebook.** Change the original literal:

```python
K100_DEADMAN_SEC = 205 * 60
```

Insert after the original `PROFILE_TABLE` definition and before the `RERUN_PROD` lever override:

```python
E31_TASKS = [
 '2d0172a1','35ab12c3','409aa875','446ef5d2','4c3d4a41','4c416de3',
 '5545f144','7491f3cf','7b5033c1','800d221b','89565ca0','9385bd28',
 'a47bf94d','a6f40cea','b6f77b65','cbebaa4b',
 '142ca369','247ef758','36a08778','581f7754','71e489b6','88e364bc',
 'a32d8b75','f931b4a8',
 '135a2760','136b0064','1818057f','0934a4d8','13e47133','16b78196'
]
assert len(E31_TASKS) == len(set(E31_TASKS)) == 30
E31_LEVERS = dict(E28_LEVERS, e28_sched=False, plain_order=False)
PROFILE_TABLE['E31_DIRECT30'] = dict(
    _NB5_T, time_budget_sec=205*60, hard_margin_sec=5*60,
    source='eval', n_tasks=30, task_list=E31_TASKS,
    quality_ab=True, equal_windows=True,
    fixed_window_sec=E31_CFG['window_min']*60,
    nb5_phases=[['Q_E31_FN_DIRECT30','all',None,'on','A','fp8']],
    **E31_LEVERS)
assert PROFILE_TABLE['E31_DIRECT30']['time_budget_sec'] >= (E31_CFG['window_min']+35)*60
```

The actual builder also explicitly rejects a non-E31 profile in commit mode to prevent accidental runs against the modified 205-minute deadman.

## New cell

Place the full text of `e31_cell.py` **after E28's combined CELL 6/7 definitions and before CELL 8**, which boots the server and calls `nb5_phase`. The new cell must be loaded before `nb5_phase` so E28's `E12A.solve_all_r6` and `E12A.build_submission` call sites use the DIRECT adapter. The module source is SHA-pinned and must be staged as an offline Kaggle Dataset; leave E28 as the sole model-server lifecycle owner.

## Budget reasoning

205 min total − 5 min hard margin = 200 min hard deadline; a 170 min solve window leaves 30 min for engine startup, preflight, reports and other bookkeeping in the favorable case. **205 min is not a guarantee of the full 170-minute solve window** if boot/preflight takes longer; the E28 budget gate can shorten/skip the run. The deadman fires at +205 min. The default drain reserves 24 min for up to 3×8192 answer tokens; the admission cutoff is at T−26 min (not T−12), because admission must stop *before* the drain. All timing is a safety heuristic until actual 24-stream phase-2 speeds are measured.

## Hidden rerun

`RERUN_PROD` remains the existing E28 production/hidden-rerun configuration. In the E31 notebook the new module installs **only when not RERUN and PROFILE==E31_DIRECT30**; otherwise the E28 Duck solver remains untouched. This is a research/diagnostic notebook, not a replacement hidden-submission policy.
