# E31 FN DIRECT30 build — evidence, tests, caveats

## Files

- `E31_FN_DIRECT30_RESEARCH.ipynb` — rebuilt E28 K100 notebook, with a 30-task E31 eval profile and one SHA-pinned module-injection cell. Serialized as compact JSON to meet the 400,000-byte notebook requirement.
- `e31_direct.py` — standalone DIRECT-only solver, no GPU/model-server boot/relaunch code.
- `e31_cell.py` — complete injection cell source, present in the notebook.
- `e31_cell1_patch.md` — exact config/profile/deadman edits and budget contract.
- `test_e31_direct.py` — stdlib fake-server/unit suite.
- `build_e31_direct_notebook.py` and `BASE__E28_K100_notebook.ipynb` — reproducible anchored build and exact donor.
- `KAGGLE_INPUT__E31_DIRECT_MODULE.zip` — nested dataset payload containing `e31_direct.py` (stage this as an offline Kaggle Dataset before notebook execution).
- `BUILD_SHA256SUMS.json` — final integrity manifest.

## Verified from user-supplied sources

- E10 ORDER2's single-test prompt, `STOP_TEXT`, 25 STOP IDs, `</think>` ID 248069, row/grid parsing and model/test-input/mirror attempt order: `SRC__E10_ORDER2_DIRECT_notebook.ipynb` cells 2–5 and `REPORT__DIRECT_solver_spec_E10_ORDER2.md` sections 3–5.
- Streaming raw token IDs over `/v1/completions`, cancellation by closing the stream and E18's **separate** server lifecycle: `SRC__E18_vllm032_shim_e18_engine_cell.py` methods `_stream`, `abort_request`; only streaming client behavior was copied.
- E28 call contract: `SRC__E28_k100_code_export.py` around lines 4274–4292; E28 callback record replacement around lines 3727–3749; `e21_cell7` uses `E12A.build_submission`, around lines 4412–4415.
- E28 `TOK` is a `tokenizers.Tokenizer`, while `_HF` and `_tpl` render the xhigh chat template: `nb5_rc2_prompts()` around lines 2045–2075. Therefore the new injection cell supplies a thin adapter instead of calling `TOK.apply_chat_template` (which does not exist).
- E28 `nb5_phase()` updates `OUT`, `CHALLENGES`, `SOLUTIONS` and `SGL_URL` **after** the injection cell; the E31 module takes lazy callables for them.
- The original E28 hidden-rerun path remains active when `RERUN` is true.

## Independently tested

- Python syntax of module, new injection cell, builder and all notebook executable cells.
- E10 single-test prompt byte equality for a fixture.
- 1/2/3-test parsing: labeled, reordered, duplicate, missing, malformed, unlabeled exact-N, extra example and no-grid fallbacks.
- Token-exact `phase2_prefix` (no decode/re-tokenize), trailing EOS stripping, `STOP_IDS`.
- DIRECT attempt_1/attempt_2 selection, with model==input and no model grid.
- Fake SSE server: 24 concurrent streams, 30 tasks including multi-test, strict token-ID response, a server-kill injection classified as an error, cancellation, and a never-ending-thinking drain (24 phase1 + 24 forced-close requests).
- Direct-only adapter never imports a correct Duck/CPU-rule candidate into the score.
- The fake deadline test uses `E31_TEST_CLOCK=1` and `_test_seconds_per_minute` solely inside the harness. Production always uses 60 seconds per minute.

## Important unverified facts / limitations

1. **NO GPU RUN PERFORMED.** The real E28 Merlin+RecoverSSM+PP2 server has not exercised the new E31 module. CPU fake SSE tests are not a substitute for GPU or Kaggle scoring.
2. **Dataset staging required.** Before upload, publish `e31_direct.py` as a Kaggle Dataset and attach it to this notebook; use `E31_MODULE_PATH` if autodiscovery is ambiguous. The notebook fails closed if the module SHA is wrong or absent. Do not change only the staged module without regenerating the notebook SHA pin.
3. **E28 CELL 7 actual scorer NOT executed here.** Its source was inspected and the `E12A.build_submission` interface was rebound; the required full real E28 E2E scorer/identity writer test depends on runtime packages and Kaggle fixtures absent from this ZIP. The report must not be described as FULL E2E PASS.
4. **Deadline drain may shorten phase-1 coverage.** To reserve roughly 24 minutes for 3-test outputs, no-admission begins at T−26 minutes and drain at T−24. This intentionally overrides the inconsistent T−12 cutoff in the build prompt. At T−1, all phase-2 streams are cancelled and partial content parsed; record deadline overruns and stragglers. This default is NOT measured on 4×L4.
5. **Full thinking output size:** full phase1/phase2 transcripts and numeric ID arrays are written per task; expect many megabytes of Kaggle output. The source uses safe per-file `os.replace()` for JSON and a locked JSONL append.
6. **Token IDs:** initial STOP values are verified against the actual runtime tokenizer at solve start. The E31 model prompt is rendered with E28 `_HF` and `_tpl`; if hashes mismatch, the existing E28 prompt/tokenizer gate should refuse the boot.
7. **Multi-test prompts are new.** The one-task/three-query prompt and labeled `grid K` output are an experiment, not independently validated model behavior.
8. **Memory & concurrency:** 24 configured threads are not 24 indefinitely KV-resident 104K requests. Expected preemptions and limited long-context capacity remain recorded, not used as a quality gate.
9. **Module staging & hidden mode:** the research notebook operates DIRECT-only on its 30 evaluation tasks in commit mode. Hidden rerun preserves original E28 Duck production behavior; no covert change to submission strategy.
10. **No autonomous model relaunch.** All stream errors become error records. E28 remains the sole server lifecycle/watchdog owner. Failed streams do not count as successful completions.

## Final readiness

**GO for CPU integration and Kaggle CPU/fake-server E2E checks.** **NOT certified GO for real 4×L4** until a pinned dataset, real `E28_CELL7` scorer/identity writer contract, model-stream token IDs, phase2 cancellation, and full 30-task correctness pass on the intended platform. User authorization is required for any GPU execution/push.
