# E31 Flash-Next DIRECT30 — build notes and verification

## What's included

- **`E31_FN_DIRECT30.ipynb`** — actual integrated 10-cell notebook; 388,767 bytes (under the 400,000-byte limit); no additional Kaggle dataset required for the E31 DIRECT module.
- `e31_direct.py` — self-contained, stdlib-only task-level solver (under 60 kB).
- `e31_cell.py` — exact SHA-pinned notebook cell.
- `e31_cell1_patch.md` — exact CELL 1 changes, task list and deadline arithmetic.
- `build_e31_notebook.py` — reproducible notebook builder, with SHA gate for the donor's packed E28 library.
- `test_e31_direct.py` — no pytest; uses an independent fake token-ID HTTP streaming server and executes the **actual donor E28 `e21_cell7()`** scoring code on an adversarial fixture.
- `BUILD_FACTS_E31.json`, `TEST_RESULTS_E31.txt` and donor notebooks/reference source. The donor files are build/test fixtures, not deployable replacement modules.

## Source-verified contracts

1. **E10 prompt** copied byte-for-byte from `SRC__E10_ORDER2_DIRECT_notebook.ipynb` JSON cell 4: `render_grid` and `build_user_message`; verified by extracting and running these donor functions inside the test suite.
2. **E10 answer and attempts** from the same donor's cell 5: `parse_grid`, `make_attempts`, STOP text, last `</think>` decode. `STOP_THINKING_TEXT` is tokenized once. For production, `</think>` must be **248069** and STOP string **25 tokens**; otherwise the setup fails closed.
3. **E18 SSE client** from `SRC__E18_vllm032_shim_e18_engine_cell.py:279-382`: raw prompt IDs, `/v1/completions`, `return_token_ids`, `temperature=0.6`, `top_p=0.95`, `top_k=20`, `seed`; response chunks carry token IDs. No E18 server boot/relaunch. The request socket has **no idle timeout** (as in E18) because a preempted request can wait for KV allocation. Closing the socket aborts a request.
4. **E28 integration** from `SRC__E28_k100_code_export.py:3663-3737,4274-4292,4406-4820`: `E12A.solve_all_r6` call accepts one completed branch per task, `on_branch_done`, `E12A.SCHED_LAST`, and `E12A.build_submission`. The notebook calls the original E28 scorer and writer after the solver returns.
5. **E28 server** uses `SGL_URL` (normally `http://127.0.0.1:8001`), not E18's port 8011. The module checks that the E28 solver `base_url` matches `SGL_URL + '/v1'` and never owns/starts/relaunches a Merlin server.
6. **Task units and groups** copied from `DESIGN__E31_FN_DIRECT30.md`: exactly 30 tasks, 16 main / 8 partial / 6 control. Reference statuses for K100, W4, 27B-Direct and 27B-Duck are from `DATA__EVAL120_K100_W4_Direct_Duck_per_task.md`. `◐` stays partial; no false 'fully solved' label.
7. **New multi-test code**: 1 prompt per task for 2–3 tests, label-only mapping if *any* valid grid-K label is present; unlabeled positional mapping only when there are exactly N complete, valid fenced blocks. Missing entries use only that test's E10 input/mirror fallback.
8. **No contamination**: `E12A.build_submission` is replaced only for the E31 evaluation profile with the DIRECT-only adapter. The host's original E28 report scorer received deliberately false DIRECT attempts alongside a correct-looking CPU rule, and reported **0 / 6**.

## Executed verification

Run `python test_e31_direct.py` from this extracted directory. Tests cover:

- E10 donor prompt bytes, single-output parser and E10 attempt behavior.
- 2/3-test mapping: swapped labels, partial labels, duplicate labels, malformed/missing last fence, unrelated fences and completely unlabeled exact-N outputs.
- Token-ID continuation, stop IDs and EOS removal without decode/retokenize.
- Direct-only attempt selection with a fraudulent accepted external candidate.
- A simulated 30-task, 24-worker token-ID SSE server: early natural completions, long-running thinking, forced-close phase 2, one connection-failure injection, prompt-ID continuation and generated JSONL/report/full traces.
- E31 notebook structure and Python compilation of every code cell.
- Actual donor **E28 `e21_cell7()` scorer** running on three tasks / six test inputs where all DIRECT answers are wrong but the record's CPU-side candidate is right: **0 / 6**.

The tests are CPU/fake-server **only**. No Merlin boot, Flash-Next model decode, 4x L4 GPU run, hidden Kaggle rerun or 170-minute real deployment has been performed. The original Duck fallback runs in the hidden-rerun profile; the E31 DIRECT module is installed only in the 30-task evaluation profile.

## Known risks / limits

- E28's Duck-specific isolation preflight still runs because CELL 6 is intentionally unchanged. DIRECT's 24 client workers ignore its optional six-worker sandbox fallback (DIRECT runs no Python tools); Merlin's own `--max-num-seqs` and actual KV admission remain authoritative. GPU preemption is possible and must be measured.
- HTTP streaming token IDs must be present; if the server emits text-only deltas, the request is recorded as an **error**, not guessed by retokenization. This is an important real-GPU smoke gate.
- E28 retains its watchdog and may relaunch the server, but a connection killed during streaming is marked error; there is **no automatic replay** of a broken stream in E31. This prevents false successful completions and preserves token provenance.
- When multiple tests exist, 3×8192 answer tokens need approximately 22.8 minutes at 18 tok/s; `drain_min=24` is chosen for that scenario, not guaranteed by runtime performance. A slower server can still cause partial outputs at T−1 min; those are parsed and recorded.
- E28's donor-specific `e21_cell7` metrics are Duck-oriented; E31's `q27x/e31_direct_report.json` is the authoritative Direct-only per-task accuracy/throughput report. Its rates use full wall time and are not a GPU-kernel-only measurement.
- A single request can output fewer than 60k thinking tokens because of context limits, an early natural answer or the global time boundary. This is reported, **never used to stop/skip on a quality heuristic**.

## How to use

The ready notebook `E31_FN_DIRECT30.ipynb` already embeds the module and the E31 switch cell. Upload/attach it in Kaggle with **the same E28 K100 model, wheelhouse and datasets** (the original E28 notebook's external dependencies have not been altered). Keep the current E28 production notebook unchanged. For reproducible rebuilding from this bundle, run:

```bash
python build_e31_notebook.py
python test_e31_direct.py
```

On the initial GPU diagnostic verify: server URL and `/v1/completions` token IDs; 24 submitted clients vs actual Merlin running count; final E28 CELL 7 score vs `e31_direct_report.json`; 60k/78k/104k coverage; preemptions, `E12_RUN` solve deadline; per-query `mapping_source`; 30 tasks and full E31 traces under `q27x`.
