#!/usr/bin/env python3
"""Deterministic E31 build from supplied E28 K100 donor notebook.
No GPU/network; packs e31_direct.py into a SHA-pinned notebook cell.
"""
import base64
import copy
import hashlib
import json
import lzma
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent
DONOR = HERE / 'SRC__E28_K100_notebook.ipynb'
MODULE = HERE / 'e31_direct.py'
E31_TASKS = ('2d0172a1 35ab12c3 409aa875 446ef5d2 4c3d4a41 4c416de3 5545f144 7491f3cf '
             '7b5033c1 800d221b 89565ca0 9385bd28 a47bf94d a6f40cea b6f77b65 cbebaa4b '
             '142ca369 247ef758 36a08778 581f7754 71e489b6 88e364bc a32d8b75 f931b4a8 '
             '135a2760 136b0064 1818057f 0934a4d8 13e47133 16b78196').split()
assert len(set(E31_TASKS)) == 30


def pack_cell(raw):
    sha = hashlib.sha256(raw).hexdigest()
    enc = base64.b85encode(lzma.compress(raw)).decode('ascii')
    cell = f'''# E31 - DIRECT-only module, SHA256 pinned (between E28 CELL 6/7 and CELL 8).
import base64 as _e31_b64, hashlib as _e31_hash, lzma as _e31_lzma, types as _e31_types, sys as _e31_sys
_E31_CODE = _e31_lzma.decompress(_e31_b64.b85decode({enc!r}))
assert _e31_hash.sha256(_E31_CODE).hexdigest() == {sha!r}, 'E31 module SHA mismatch'
_E31_MOD = _e31_types.ModuleType('e31_direct')
_e31_sys.modules['e31_direct'] = _E31_MOD
exec(compile(_E31_CODE, 'e31_direct.py', 'exec'), _E31_MOD.__dict__)
if PROFILE == 'E31DIRECT30' and not RERUN:
    assert not P.get('e28_sched'), 'E31 must run without E28 A/B/C scheduler'
    E31_HANDLE = _E31_MOD.install(
        E12A, tokenizer=lambda: NB5_LOCAL_TOK.get('hf'),
        challenges=lambda: CHALLENGES, sgl_url=lambda: SGL_URL,
        cfg=dict(E31_CFG, _solutions=lambda: globals().get('SOLUTIONS')),
        out_dir=OUT / 'duck', log=log)
    print('E31 DIRECT installed (client bound after server boot):', {sha[:12]!r}, flush=True)
'''
    return cell, sha


def build():
    nb = json.loads(DONOR.read_text(encoding='utf-8'))
    assert len(nb['cells']) == 9
    s = ''.join(nb['cells'][2]['source'])
    assert 'K100_DEADMAN_SEC = 24900' in s
    cfg = "E31_CFG = {'think': 104000, 'answer': 8192, 'window_min': 170, 'workers': 24, 'temperature': 0.6, 'drain_min': 24}\n"
    s = s.replace('K100_DEADMAN_SEC = 24900', 'K100_DEADMAN_SEC = 205 * 60')
    s = cfg + s
    s = s.replace('NB5_DEFAULT_PROFILE = "E28EVAL120"', 'NB5_DEFAULT_PROFILE = "E31DIRECT30"')
    s = s.replace('K100_PROFILES = ("E28EVAL120", "RERUN_PROD")',
                  'K100_PROFILES = ("E28EVAL120", "RERUN_PROD", "E31DIRECT30")')
    needle = 'PROFILE_TABLE["RERUN_PROD"] = dict(PROFILE_TABLE["RERUN_PROD"], **E28_LEVERS)'
    assert needle in s
    newrow = '''# E31: one prompt per TASK, 30 eval tasks, E28 model/boot unchanged, no E28 scheduler.
E31_TASK_LIST = %s
assert len(E31_TASK_LIST) == 30 and len(set(E31_TASK_LIST)) == 30
assert E31_CFG['window_min'] * 60 + 15 * 60 + 15 * 60 <= 205 * 60, 'E31 window + boot + finalization exceeds 205 min'
assert E31_CFG['drain_min'] >= 24 and E31_CFG['drain_min'] < E31_CFG['window_min'] - 12
PROFILE_TABLE['E31DIRECT30'] = dict(_NB5_T, time_budget_sec=205 * 60, hard_margin_sec=5 * 60,
    source='eval', task_list=E31_TASK_LIST, quality_ab=False,
    equal_windows=True, fixed_window_sec=int(E31_CFG['window_min'] * 60),
    nb5_phases=[['E31_DIRECT30', 'all', None, 'on', 'A', 'fp8']],
    **dict(E28_LEVERS, e28_sched=False, plain_order=False))
# The E31 eval notebook deliberately keeps hidden rerun on the original Duck fallback.
PROFILE_TABLE['RERUN_PROD'] = dict(PROFILE_TABLE['RERUN_PROD'], **dict(E28_LEVERS, e28_sched=False))
''' % repr(E31_TASKS)
    # Replace, not append, original rerun mutation (which enables E28 scheduler).
    original_row = next(line for line in s.splitlines(keepends=True) if line.startswith(needle))
    s = s.replace(original_row, newrow)
    assert 'E12_BRANCHES = int(os.environ.get("E12_BRANCHES", 2))' in s
    s = s.replace('E12_BRANCHES = int(os.environ.get("E12_BRANCHES", 2))',
                  'E12_BRANCHES = 1 if PROFILE == "E31DIRECT30" else int(os.environ.get("E12_BRANCHES", 2))')
    # Shrink unused E28 scheduler embedded module; preserve e28k100_lib, and SHA-pin the new payload.
    original_line = next(line for line in s.splitlines(keepends=True) if line.startswith('E28_SRC ='))
    original_enc = re.search(r'b85decode\("([^\"]+)"\)', original_line).group(1)
    loaded = lzma.decompress(base64.b85decode(original_enc)).decode('utf-8')
    loaded_sha = hashlib.sha256(loaded.encode()).hexdigest()
    assert loaded_sha == 'd4165f6c859b32ed2f2438d92290b6ba1f7093136196497b94238d6c2836c241'
    mods = json.loads(loaded)
    assert 'e28_sched_patch.py' in mods and 'e28k100_lib.py' in mods
    mods.pop('e28_sched_patch.py')
    new_raw = json.dumps(mods, ensure_ascii=False, separators=(',', ':'))
    new_enc = base64.b85encode(lzma.compress(new_raw.encode())).decode()
    new_sha = hashlib.sha256(new_raw.encode()).hexdigest()
    new_line = original_line.replace(loaded_sha, new_sha).replace(original_enc, new_enc)
    s = s.replace(original_line, new_line)
    # Do not remove E28 code, only its inactive scheduler payload and CELL 1 profile/config changes.
    compile(s, 'E31_CELL_1.py', 'exec')
    nb['cells'][2]['source'] = s.splitlines(keepends=True)
    cell, module_sha = pack_cell(MODULE.read_bytes())
    new_cell = {'cell_type':'code','execution_count':None,'id':'e31-direct-only',
                'metadata':{},'outputs':[],'source':cell.splitlines(keepends=True)}
    # Insert after the E28 CELL 6/7 function definitions, before CELL 8 which boots/solves.
    assert 'def e21_cell6()' in ''.join(nb['cells'][6]['source'])
    assert 'CELL 8' in ''.join(nb['cells'][7]['source'])[:200]
    nb['cells'].insert(7, new_cell)
    for c in nb['cells']:
        if c['cell_type'] == 'code':
            compile(''.join(c['source']), c.get('id', 'notebook-cell'), 'exec')
    outp = HERE / 'E31_FN_DIRECT30.ipynb'
    txt = json.dumps(nb, ensure_ascii=False, separators=(',', ':'))
    outp.write_text(txt, encoding='utf-8')
    # E28 project size requirement is the actual notebook bytes, not the ZIP size.
    assert len(txt.encode('utf-8')) < 400_000, f'E31 notebook too big: {len(txt)}'
    (HERE / 'e31_cell.py').write_text(cell, encoding='utf-8')
    summary = dict(notebook_sha256=hashlib.sha256(txt.encode()).hexdigest(),
                   module_sha256=module_sha, e28_lib_only_sha256=new_sha,
                   notebook_bytes=len(txt.encode()), cells=len(nb['cells']),
                   e31_tasks=E31_TASKS, drain_min=24, window_min=170, budget_min=205)
    (HERE / 'BUILD_FACTS_E31.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary,indent=2))


if __name__ == '__main__':
    build()
