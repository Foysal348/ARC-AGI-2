# E31 CELL 1 patch — exact source edits (already applied to `E31_FN_DIRECT30.ipynb`)

**Donor:** `SRC__E28_K100_notebook.ipynb` (same binary as the supplied E31 build package). Build reproducibly with `python build_e31_notebook.py`.

Only CELL 1 profile/deadline/config changes, the removal of the **unused** packed `e28_sched_patch.py` from that CELL's embedded `E28_SRC`, and insertion of the SHA-pinned E31 installation cell were made. Other original notebook cells are not modified.

1. At the **very beginning** of CELL 1 (before its original header), insert the editable line:

```python
E31_CFG = {'think': 104000, 'answer': 8192, 'window_min': 170, 'workers': 24, 'temperature': 0.6, 'drain_min': 24}
```

2. Replace:

```python
K100_DEADMAN_SEC = 24900
NB5_DEFAULT_PROFILE = "E28EVAL120"
K100_PROFILES = ("E28EVAL120", "RERUN_PROD")
E12_BRANCHES = int(os.environ.get("E12_BRANCHES", 2))
```

with the respective individual lines:

```python
K100_DEADMAN_SEC = 205 * 60
NB5_DEFAULT_PROFILE = "E31DIRECT30"
K100_PROFILES = ("E28EVAL120", "RERUN_PROD", "E31DIRECT30")
E12_BRANCHES = 1 if PROFILE == "E31DIRECT30" else int(os.environ.get("E12_BRANCHES", 2))
```

3. Replace the original `PROFILE_TABLE["RERUN_PROD"] = dict(..., **E28_LEVERS)` line with:

```python
E31_TASK_LIST = ['2d0172a1', '35ab12c3', '409aa875', '446ef5d2', '4c3d4a41', '4c416de3', '5545f144', '7491f3cf', '7b5033c1', '800d221b', '89565ca0', '9385bd28', 'a47bf94d', 'a6f40cea', 'b6f77b65', 'cbebaa4b', '142ca369', '247ef758', '36a08778', '581f7754', '71e489b6', '88e364bc', 'a32d8b75', 'f931b4a8', '135a2760', '136b0064', '1818057f', '0934a4d8', '13e47133', '16b78196']
assert len(E31_TASK_LIST) == 30 and len(set(E31_TASK_LIST)) == 30
assert E31_CFG['window_min'] * 60 + 15 * 60 + 15 * 60 <= 205 * 60
assert E31_CFG['drain_min'] >= 24 and E31_CFG['drain_min'] < E31_CFG['window_min'] - 12
PROFILE_TABLE['E31DIRECT30'] = dict(_NB5_T, time_budget_sec=205 * 60, hard_margin_sec=5 * 60,
    source='eval', task_list=E31_TASK_LIST, quality_ab=False,
    equal_windows=True, fixed_window_sec=int(E31_CFG['window_min'] * 60),
    nb5_phases=[['E31_DIRECT30', 'all', None, 'on', 'A', 'fp8']],
    **dict(E28_LEVERS, e28_sched=False, plain_order=False))
PROFILE_TABLE['RERUN_PROD'] = dict(PROFILE_TABLE['RERUN_PROD'], **dict(E28_LEVERS, e28_sched=False))
```

4. For notebook size below 400,000 bytes, the packed `E28_SRC` dictionary inside CELL 1 has `e28_sched_patch.py` removed; `e28k100_lib.py` remains **byte-identical** after extraction. The packed string and its SHA256 are recalculated. `build_e31_notebook.py` performs this transformation with a source SHA check. E31's `e28_sched=False` means this dropped module is not executed.

5. Insert the complete `e31_cell.py` **after** E28 CELL 6/7 function definitions (JSON cell index 6), **before** E28 CELL 8 boot/phase execution (original JSON index 7). It defers reading the Flash-Next tokenizer and `SGL_URL` until after the original E28 boot; installs only for `PROFILE == 'E31DIRECT30' and not RERUN`.

## Deadline arithmetic

- E31 notebook budget: 205 min, hard stop: 200 min, deadman: 205 min after notebook start.
- Example 15-min boot leaves 185 min until hard stop; fixed solve window is 170 min with approximately 15-min finalization margin.
- Actual E28 `nb5_phase()` truncates a window on late boot. This change does not guarantee 170 min if the boot exceeds the reserved setup allowance; that truncation is recorded.
- Drain starts **24 min** before the actual solve deadline to permit 3×8192 answer tokens at roughly 18 tok/s per stream, plus final one minute for write/partial parse.
- To avoid starting phase-1 requests after drain begins, new admission stops at `min(T−12 min, T−24 min) = T−24 min`. This is **earlier** than the allowed latest T−12 deadline, not later.
- The thinking floor 60k is an observational flag, never an admission/quality skip rule.
