# E31 Flash-Next DIRECT30 — runnable build and independent CPU checks

## Primary artifact

**E31_FN_DIRECT30.ipynb** — complete 30-task DIRECT Kaggle notebook, integrated with the supplied E28 K100 donor. This is an experimental GPU diagnostic, **not** a proven 4xL4 deployment.

Notebook size: **388,767 bytes** (< 400,000 bytes). 10 notebook cells. E31-only module is SHA-pinned in the notebook; no additional Kaggle dataset is required for it. Reuse the original E28 wheelhouse, model and datasets.

## Read in this order

1. `NOTES.md` — scope, provenance, executed tests, GPU limitations.
2. `BUILD_FACTS_E31.json` — exact notebook and module SHA256, task list, budgets.
3. `TEST_RESULTS_E31.txt` — actual local test output.
4. `e31_cell1_patch.md` — exact E28 donor edits.

## Build / validation

Run from this extracted directory:

```bash
python build_e31_notebook.py
python test_e31_direct.py
```

The builder uses the included original E28 donor and fails closed on a source hash mismatch. Tests are CPU-only and include a 30-task threaded fake SSE server and actual E28 donor scorer adversarial evaluation. **No real Merlin or GPU execution was performed.**

The notebook uses 24 client workers, 170-min maximum solve window with 24-min early drain, 205-min notebook budget, 104k thinking cap and 8192 answer cap. The E28 Merlin server is the sole lifecycle owner; E31 binds to its existing `SGL_URL`. Full traces and reports go to `q27x/e31_direct_*.json`.

`MANIFEST_SHA256.json` hashes the other included files.
