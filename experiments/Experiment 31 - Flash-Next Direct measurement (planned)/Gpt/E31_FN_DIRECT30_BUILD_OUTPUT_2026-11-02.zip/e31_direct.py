"""E31 FN DIRECT30: E10 ORDER2 prompts/attempts, E18 token-id SSE, E28 callback/writer.

This module owns no Merlin process. All times use monotonic clock. No external
packages; uses exactly the already running E28 OpenAI-compatible server.
"""
from __future__ import annotations
import json
import os
import re
import math
import queue
import socket
import threading
import time
import urllib.request
from pathlib import Path

STOP_THINKING_TEXT = "\n\nConsidering the limited time by the user, I have to give the solution based on the thinking directly now.\n</think>\n\n"
SEED = 20261005
MAX_MODEL_LEN = 131072
CONTEXT_SAFETY = 256
GROUPS = {
    "main": "2d0172a1 35ab12c3 409aa875 446ef5d2 4c3d4a41 4c416de3 5545f144 7491f3cf 7b5033c1 800d221b 89565ca0 9385bd28 a47bf94d a6f40cea b6f77b65 cbebaa4b".split(),
    "partial": "142ca369 247ef758 36a08778 581f7754 71e489b6 88e364bc a32d8b75 f931b4a8".split(),
    "control": "135a2760 136b0064 1818057f 0934a4d8 13e47133 16b78196".split(),
}
GROUP_OF = {task: group for group, tasks in GROUPS.items() for task in tasks}
TASKS = sorted(GROUP_OF)
assert len(TASKS) == len(set(TASKS)) == 30


def render_grid(g):
    return "\n".join(" ".join(str(int(v)) for v in row) for row in g)


def build_user_message(train, test_input):
    """BYTE-IDENTICAL to E10 ORDER2 single-test prompt."""
    parts = ["You are solving an abstract reasoning puzzle. Each example has an "
             "INPUT grid and its OUTPUT grid (digits 0-9 are colors; 0 is usually "
             "background). Infer the ONE rule that maps every input to its output, "
             "then apply it to the FINAL INPUT.\n"]
    for i, p in enumerate(train):
        parts.append("Example %d INPUT:\n%s\nExample %d OUTPUT:\n%s\n" %
                     (i + 1, render_grid(p["input"]), i + 1, render_grid(p["output"])))
    parts.append("FINAL INPUT:\n%s\n" % render_grid(test_input))
    parts.append("Reason step by step however you like. Then give ONLY the final "
                 "output grid as rows of space-separated digits inside a fenced "
                 "block:\n```grid\n<rows>\n```\nOutput nothing after the block.")
    return "\n".join(parts)


def build_multi_message(train, test_inputs):
    assert 2 <= len(test_inputs) <= 3, "E31 supported multi-test task has 2 or 3 inputs"
    parts = ["You are solving an abstract reasoning puzzle. Each example has an "
             "INPUT grid and its OUTPUT grid (digits 0-9 are colors; 0 is usually "
             "background). Infer the ONE rule that maps every input to its output, "
             "then apply it to the FINAL INPUT.\n"]
    for i, p in enumerate(train):
        parts.append("Example %d INPUT:\n%s\nExample %d OUTPUT:\n%s\n" %
                     (i + 1, render_grid(p["input"]), i + 1, render_grid(p["output"])))
    parts.append("\n".join("FINAL INPUT %d:\n%s" % (i+1, render_grid(g)) for i, g in enumerate(test_inputs)) + "\n")
    parts.append("Reason step by step however you like. Then give ONLY the final "
                 "output grids as rows of space-separated digits inside one labeled "
                 "fenced block per FINAL INPUT, using exactly these labels in order:\n" +
                 "\n".join("```grid %d\n<rows>\n```" % (i+1) for i in range(len(test_inputs))) +
                 "\nOutput nothing after the last block.")
    return "\n".join(parts)


def valid_grid(g):
    return (isinstance(g, list) and 1 <= len(g) <= 30
            and all(isinstance(r, list) and 1 <= len(r) <= 30 for r in g)
            and len({len(r) for r in g}) == 1
            and all(isinstance(v, int) and not isinstance(v, bool) and 0 <= v <= 9 for r in g for v in r))


_FENCE_RE = re.compile(r"```([^\n`]*)\n(.*?)```", re.S)
_SEP_ROW = re.compile(r"\[?\s*\d(?:\s*[, ]\s*\d)*\s*\]?,?")
_JSON_ROW = re.compile(r"\[\s*\d(?:\s*,\s*\d)*\s*\]")
_LABEL_RE = re.compile(r"\bgrid\s+([1-9]\d*)\b", re.I)


def _parse_row(s):
    s = s.strip()
    if not s:
        return None
    if re.fullmatch(r"\d+", s):
        return [int(c) for c in s]
    if _SEP_ROW.fullmatch(s):
        return [int(c) for c in re.findall(r"\d", s)]
    return None


def _first_row_run(lines):
    rows = []
    for line in lines:
        r = _parse_row(line)
        if r is None:
            if rows:
                break
            continue
        rows.append(r)
    return rows if valid_grid(rows) else None


def _grid_from_obj(obj):
    if isinstance(obj, dict):
        for k in ("output", "grid", "test_output", "answer", "test_outputs"):
            if k in obj:
                return _grid_from_obj(obj[k])
        return None
    if valid_grid(obj):
        return obj
    if isinstance(obj, list) and obj and valid_grid(obj[-1]):
        return obj[-1]
    return None


def _json_rows_grid(b):
    grids, cur = [], []
    for m in _JSON_ROW.finditer(b):
        cur.append(json.loads(m.group(0)))
        if b[m.end():].lstrip().startswith("]"):
            grids.append(cur)
            cur = []
    if cur:
        grids.append(cur)
    for g in reversed(grids):
        if valid_grid(g):
            return g
    return None


def _grid_from_block(body):
    b = body.strip()
    if b[:1] in ("[", "{"):
        try:
            g = _grid_from_obj(json.loads(b))
        except Exception:
            g = None
        if g is None:
            g = _json_rows_grid(b)
        if g is not None:
            return g
    return _first_row_run(b.splitlines())


def parse_grid(text):
    """E10 ORDER2 single-grid parser, including last-run unfenced fallback."""
    for _lab, body in reversed(_FENCE_RE.findall(text or "")):
        g = _grid_from_block(body)
        if g is not None:
            return g
    runs, cur = [], []
    for line in (text or "").splitlines():
        r = _parse_row(line)
        if r is None:
            if cur:
                runs.append(cur)
                cur = []
        else:
            cur.append(r)
    if cur:
        runs.append(cur)
    for run in reversed(runs):
        if valid_grid(run):
            return run
    return None


def parse_multi(text, n):
    """Label-only if ANY recognized label appears; positional iff 0 labels and exactly n fences.

    Partial/malformed blocks are never guessed into another query. Each entry
    carries the source required by the E31 correctness audit.
    """
    assert n in (2, 3)
    frames = list(_FENCE_RE.finditer(text or ""))
    annotated = []
    for f in frames:
        lab, body = f.group(1).strip(), f.group(2)
        m = _LABEL_RE.search(lab)
        if m is None:
            # Support a label immediately preceding the fence; not arbitrary explanation text.
            prefix = (text or "")[:f.start()].rstrip().splitlines()
            if prefix:
                mm = re.fullmatch(r"(?:FINAL\s+OUTPUT\s+)?grid\s+([1-9]\d*)\s*:?", prefix[-1].strip(), re.I)
                if mm:
                    m = mm
        num = int(m.group(1)) if m else None
        annotated.append((num, _grid_from_block(body), f.start()))
    found_label = any(x[0] is not None for x in annotated)
    results = [{"query_index": i, "grid": None, "mapping_source": "fallback",
                "fallback_reason": "missing_label" if found_label else "no_exact_positional_mapping"} for i in range(n)]
    if found_label:
        for k, grid, _offset in annotated:
            if k is not None and 1 <= k <= n and valid_grid(grid):
                results[k - 1].update(grid=grid, mapping_source="label", fallback_reason=None)
    else:
        good = [grid for _, grid, _ in annotated if valid_grid(grid)]
        if len(annotated) == n and len(good) == n:
            for i, grid in enumerate(good):
                results[i].update(grid=grid, mapping_source="positional", fallback_reason=None)
    return results


def make_attempts(inp, grid):
    assert valid_grid(inp), "invalid ARC input grid"
    cands = ([('model', grid)] if valid_grid(grid) else []) + [
        ('test_input', inp), ('mirror', [list(reversed(r)) for r in inp])]
    uniq = []
    for src, g in cands:
        if all(g != old[1] for old in uniq):
            uniq.append((src, g))
    while len(uniq) < 2:
        uniq.append(uniq[-1])
    return {"attempt_1": uniq[0][1], "attempt_2": uniq[1][1],
            "src_1": uniq[0][0], "src_2": uniq[1][0]}


def order2(challenges, order):
    # E10: stable sorted task-id ties, with score = [3+ train] + [one test].
    ids = sorted(t for t in order if t in challenges)
    return sorted(ids, key=lambda t: (-(int(len(challenges[t]['train']) >= 3) +
                                       int(len(challenges[t]['test']) == 1)), ids.index(t)))


def phase1_cap(prompt_tokens, n_tests, cfg):
    return max(0, min(int(cfg['think']), MAX_MODEL_LEN - int(prompt_tokens)
                      - int(cfg['answer']) * n_tests - CONTEXT_SAFETY))


def continuation_ids(prompt_ids, p1_ids, stop_ids, close_id, eos_ids):
    p1 = list(p1_ids)
    closed = close_id in p1
    if not closed:
        while p1 and p1[-1] in eos_ids:
            p1.pop()
    return list(prompt_ids) + p1 + ([] if closed else list(stop_ids)), ([] if closed else list(stop_ids))


def answer_text(tok, close_id, p1, p2_prefix, p2):
    ids = list(p1) + list(p2_prefix) + list(p2)
    if close_id not in ids:
        return '', 0, False
    k = len(ids) - 1 - ids[::-1].index(close_id)
    return tok.decode(ids[k+1:], skip_special_tokens=True), k, True


class StreamHandle:
    def __init__(self):
        self.cancel = threading.Event()
        self.response = None
        self.lock = threading.Lock()

    def abort(self):
        self.cancel.set()
        with self.lock:
            resp = self.response
        if resp is not None:
            try:
                resp.fp.raw._sock.shutdown(socket.SHUT_RDWR)
            except Exception:
                pass
            try:
                resp.close()
            except Exception:
                pass


class TokenIdClient:
    """E18 streaming client ONLY. No health checking, server boot or relaunch."""
    def __init__(self, base_url, model_id, idle_timeout=None):
        self.base_url = base_url.rstrip('/')
        self.model_id = model_id
        self.idle_timeout = idle_timeout

    def stream(self, prompt_ids, max_tokens, seed, temperature, on_ids, handle, *, top_p=0.95, top_k=20):
        payload = {"model": self.model_id, "prompt": [int(x) for x in prompt_ids],
                   "max_tokens": int(max_tokens), "seed": int(seed), "temperature": float(temperature),
                   "top_p": float(top_p), "top_k": int(top_k), "stream": True,
                   "return_token_ids": True, "skip_special_tokens": False}
        request = urllib.request.Request(self.base_url + '/v1/completions',
                                         data=json.dumps(payload).encode(), method='POST',
                                         headers={'Content-Type': 'application/json'})
        finish, err, prompt_used, cached = None, None, None, None
        got_done = False
        start = time.monotonic()
        response = None
        try:
            response = urllib.request.urlopen(request, timeout=self.idle_timeout)
            with handle.lock:
                handle.response = response
            if handle.cancel.is_set():
                return 'aborted', None, 0, 0, time.monotonic() - start
            for raw in response:
                if handle.cancel.is_set():
                    break
                line = raw.strip()
                if not line.startswith(b'data:'):
                    continue
                data = line[5:].strip()
                if data == b'[DONE]':
                    got_done = True
                    break
                d = json.loads(data)
                if d.get('error') or d.get('object') == 'error':
                    err = str(d.get('error') or d.get('message') or 'server-error')[:300]
                    break
                usage = d.get('usage') or {}
                if usage:
                    prompt_used = usage.get('prompt_tokens', prompt_used)
                    ptd = usage.get('prompt_tokens_details') or {}
                    cached = ptd.get('cached_tokens', cached)
                for c in d.get('choices') or []:
                    ids = c.get('token_ids')
                    if ids is None:
                        # Never decode and retokenize text; fail closed on such a stream.
                        if c.get('text'):
                            err = 'MISSING_STREAM_TOKEN_IDS'
                            break
                        ids = []
                    ids = [int(i) for i in ids]
                    if ids:
                        on_ids(ids)
                    fr = c.get('finish_reason')
                    if fr is not None:
                        finish = str(fr)
                if err or finish is not None:
                    break
        except Exception as exc:
            if not handle.cancel.is_set():
                err = f'{type(exc).__name__}: {exc}'[:300]
        finally:
            with handle.lock:
                handle.response = None
            if response is not None:
                try:
                    response.close()
                except Exception:
                    pass
        if handle.cancel.is_set():
            finish = 'aborted'
        elif err or finish is None:
            finish = 'error'
            err = err or ('SSE_EOF_WITHOUT_FINISH' if got_done else 'SSE_CONNECTION_EOF')
        return finish, err, prompt_used, cached, time.monotonic() - start


def build_submission(challenges, records):
    """DIRECT ONLY: never call Duck's select_attempts_r5 or any train-exact rule."""
    out = {}
    for tid, ch in challenges.items():
        row = next((r for r in records.get(tid, [])
                    if r.get('branch') == 0 and r.get('e31_direct') is True), None)
        got = (row or {}).get('e31_attempts') or []
        out[tid] = []
        for qi, t in enumerate(ch['test']):
            item = got[qi] if qi < len(got) else make_attempts(t['input'], None)
            # Source-traceable: no selection or mixing between different queries.
            assert valid_grid(item['attempt_1']) and valid_grid(item['attempt_2'])
            out[tid].append({'attempt_1': item['attempt_1'], 'attempt_2': item['attempt_2']})
    return out


def _atomic_json(path, obj):
    path = Path(path)
    tmp = path.with_name(path.name + f'.{os.getpid()}.{threading.get_ident()}.tmp')
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(obj, f, ensure_ascii=False, default=str)
    os.replace(tmp, path)


def _read_reference():
    # Imported and statically embedded from DATA__EVAL120... by the build script.
    return dict(REFERENCE_RESULTS)

REFERENCE_RESULTS = {'0934a4d8': {'Direct27B': '❌', 'Duck27B': '❌', 'K100': '✅', 'W4': '❌'},
 '135a2760': {'Direct27B': '✅', 'Duck27B': '✅', 'K100': '✅', 'W4': '✅'},
 '136b0064': {'Direct27B': '✅', 'Duck27B': '✅', 'K100': '✅', 'W4': '✅'},
 '13e47133': {'Direct27B': '❌', 'Duck27B': '❌', 'K100': '✅', 'W4': '✅'},
 '142ca369': {'Direct27B': '❌', 'Duck27B': '✅', 'K100': '◐', 'W4': '✅'},
 '16b78196': {'Direct27B': '❌', 'Duck27B': '❌', 'K100': '✅', 'W4': '✅'},
 '1818057f': {'Direct27B': '✅', 'Duck27B': '✅', 'K100': '✅', 'W4': '✅'},
 '247ef758': {'Direct27B': '◐', 'Duck27B': '◐', 'K100': '◐', 'W4': '✅'},
 '2d0172a1': {'Direct27B': '❌', 'Duck27B': '❌', 'K100': '❌', 'W4': '◐'},
 '35ab12c3': {'Direct27B': '❌', 'Duck27B': '❌', 'K100': '❌', 'W4': '✅'},
 '36a08778': {'Direct27B': '❌', 'Duck27B': '✅', 'K100': '◐', 'W4': '✅'},
 '409aa875': {'Direct27B': '✅', 'Duck27B': '❌', 'K100': '❌', 'W4': '✅'},
 '446ef5d2': {'Direct27B': '◐', 'Duck27B': '❌', 'K100': '❌', 'W4': '❌'},
 '4c3d4a41': {'Direct27B': '❌', 'Duck27B': '❌', 'K100': '❌', 'W4': '✅'},
 '4c416de3': {'Direct27B': '❌', 'Duck27B': '❌', 'K100': '❌', 'W4': '✅'},
 '5545f144': {'Direct27B': '❌', 'Duck27B': '❌', 'K100': '❌', 'W4': '✅'},
 '581f7754': {'Direct27B': '◐', 'Duck27B': '◐', 'K100': '◐', 'W4': '◐'},
 '71e489b6': {'Direct27B': '◐', 'Duck27B': '✅', 'K100': '◐', 'W4': '✅'},
 '7491f3cf': {'Direct27B': '✅', 'Duck27B': '❌', 'K100': '❌', 'W4': '✅'},
 '7b5033c1': {'Direct27B': '✅', 'Duck27B': '❌', 'K100': '❌', 'W4': '❌'},
 '800d221b': {'Direct27B': '❌', 'Duck27B': '✅', 'K100': '❌', 'W4': '❌'},
 '88e364bc': {'Direct27B': '◐', 'Duck27B': '❌', 'K100': '◐', 'W4': '◐'},
 '89565ca0': {'Direct27B': '❌', 'Duck27B': '✅', 'K100': '❌', 'W4': '✅'},
 '9385bd28': {'Direct27B': '◐', 'Duck27B': '❌', 'K100': '❌', 'W4': '✅'},
 'a32d8b75': {'Direct27B': '❌', 'Duck27B': '❌', 'K100': '◐', 'W4': '✅'},
 'a47bf94d': {'Direct27B': '✅', 'Duck27B': '❌', 'K100': '❌', 'W4': '❌'},
 'a6f40cea': {'Direct27B': '✅', 'Duck27B': '❌', 'K100': '❌', 'W4': '❌'},
 'b6f77b65': {'Direct27B': '◐', 'Duck27B': '◐', 'K100': '❌', 'W4': '❌'},
 'cbebaa4b': {'Direct27B': '◐', 'Duck27B': '❌', 'K100': '❌', 'W4': '❌'},
 'f931b4a8': {'Direct27B': '◐', 'Duck27B': '✅', 'K100': '◐', 'W4': '❌'}}


class DirectRunner:
    def __init__(self, E12A, tokenizer, challenges, sgl_url, cfg, out_dir, log):
        self.E12A, self._tokenizer = E12A, tokenizer
        self._challenges, self._sgl_url = challenges, sgl_url
        self.cfg = dict(cfg)
        self.out_dir = Path(out_dir)
        self.log = log if callable(log) else print
        self.results, self.active, self.threads = {}, {}, {}
        self.lock = threading.RLock()
        self.trace_lock = threading.Lock()
        self.streams = {}
        self.started, self.admitted, self.finished = 0, 0, 0
        self.errors = []

    def _resolve(self, value):
        return value() if callable(value) else value

    def _tokens(self, tok, s):
        return [int(x) for x in tok.encode(s, add_special_tokens=False)]

    def _setup(self, challenges, order, deadline, base_url, model_id, workers):
        tok = self._resolve(self._tokenizer)
        if tok is None:
            raise RuntimeError('E31 tokenizer unavailable after E28 boot')
        supplied = self._resolve(self._sgl_url)
        if not supplied or supplied.rstrip('/') + '/v1' != base_url.rstrip('/'):
            raise RuntimeError(f'E31 server binding mismatch: install={supplied!r}, call={base_url!r}')
        self.tok = tok
        self.sgl_url = supplied.rstrip('/')
        self.client = TokenIdClient(self.sgl_url, model_id)
        self.stop_ids = self._tokens(tok, STOP_THINKING_TEXT)
        close = self._tokens(tok, '</think>')
        if len(close) != 1 or close[0] not in self.stop_ids:
            raise RuntimeError('E31 </think> token ID mismatch')
        self.close_id = close[0]
        if self.cfg.get('enforce_flash_next_ids', True) and (close[0] != 248069 or len(self.stop_ids) != 25):
            raise RuntimeError('E31 expected Flash-Next STOP_IDS length/close mismatch')
        eos = getattr(tok, 'eos_token_id', None)
        if eos is None:
            eos = []
        self.eos_ids = set([int(eos)] if isinstance(eos, int) else [int(v) for v in eos])
        self.eos_ids.update([248046, 248044])
        selected = {t: challenges[t] for t in order if t in challenges}
        self.challenges = selected
        self.order = order2(selected, order)
        self.deadline = float(deadline)
        # The E28 workers argument can be reduced to 6 by a Duck Python-sandbox
        # isolation preflight. DIRECT does not execute Python tools; do not use
        # that unrelated gate as a concurrency cap. Merlin owns GPU admission.
        self.e28_suggested_workers = int(workers)
        self.worker_count = int(self.cfg.get('workers', 24))
        if not 1 <= self.worker_count <= 24:
            raise RuntimeError('E31 workers out of range')
        self.scale = float(self.cfg.get('_test_time_scale', 60.0))
        if self.scale != 60.0 and not self.cfg.get('_test_mode', False):
            raise RuntimeError('E31 test clock scale forbidden in production')
        drain = float(self.cfg.get('drain_min', 24)) * self.scale
        self.drain_at = self.deadline - drain
        self.admit_until = min(self.deadline - 12 * self.scale, self.drain_at)
        self.answer_until = self.deadline - self.scale
        if not self.admit_until < self.drain_at + 0.001 <= self.answer_until:
            raise RuntimeError('E31 invalid admission / drain / answer deadlines')
        # E28 passes OUT/duck, where OUT is q27x/phase_E31_DIRECT30.
        # Write E31 reports to the enclosing q27x so collection is predictable.
        parent = self.out_dir.parent
        self.qdir = parent.parent if parent.name.startswith('phase_') else parent / 'q27x'
        self.qdir.mkdir(parents=True, exist_ok=True)
        self.records_file = self.qdir / 'e31_direct_records.jsonl'
        self.report_file = self.qdir / 'e31_direct_report.json'
        self.records_file.write_text('', encoding='utf-8')
        self.start_pc = time.monotonic()
        self.start_epoch = time.time()
        self.info = {}
        for idx, tid in enumerate(self.order):
            ch = selected[tid]
            test = [v['input'] for v in ch['test']]
            if len(test) not in (1, 2, 3):
                raise RuntimeError(f'E31 unsupported N tests for {tid}: {len(test)}')
            user = (build_user_message(ch['train'], test[0]) if len(test) == 1
                    else build_multi_message(ch['train'], test))
            rendered = tok.apply_chat_template([{'role': 'user', 'content': user}], tokenize=False,
                                               add_generation_prompt=True, enable_thinking=True, reasoning_effort='xhigh')
            prompt_ids = self._tokens(tok, rendered)
            cap = phase1_cap(len(prompt_ids), len(test), self.cfg)
            self.info[tid] = dict(prompt_ids=prompt_ids, cap=cap, n=len(test), idx=idx,
                                  thinking_floor_reachable=(cap >= 60000), group=GROUP_OF.get(tid, 'other'))
        self.E12A.SCHED_LAST = {}

    def _emit_ids(self, st, phase, ids):
        with st['lock']:
            st[f'p{phase}_ids'].extend(ids)

    def _phase(self, tid, st, phase, prompt, cap, seed):
        handle = StreamHandle()
        st['phase'] = phase
        with self.lock:
            self.active[tid] = (phase, handle)
        st[f'p{phase}_prompt'] = len(prompt)
        t0 = time.monotonic()
        try:
            finish, err, used, cached, wall = self.client.stream(prompt, cap, seed,
                       self.cfg.get('temperature', 0.6), lambda ids: self._emit_ids(st, phase, ids), handle)
        except Exception as exc:
            finish, err, used, cached, wall = 'error', repr(exc)[:300], None, None, time.monotonic() - t0
        with self.lock:
            if self.active.get(tid, (None,))[1:2] == (handle,):
                self.active.pop(tid, None)
        st[f'p{phase}_finish'] = finish
        st[f'p{phase}_error'] = err
        st[f'p{phase}_wall_sec'] = round(wall, 3)
        st[f'p{phase}_prompt_used'] = used
        st[f'p{phase}_cached'] = cached
        return finish

    def _do_task(self, tid, callback):
        data = self.info[tid]
        st = {'lock': threading.RLock(), 'p1_ids': [], 'p2_ids': [], 'p2_prefix': [],
              'phase': 1, 't0': time.time(), 't0_pc': time.monotonic(), 'mode': 'natural',
              'status': 'done', 'error': None}
        try:
            if data['cap'] <= 0:
                st.update(status='error', error='PROMPT_EXCEEDS_MODEL_CONTEXT', mode='no_context')
            else:
                fr = self._phase(tid, st, 1, data['prompt_ids'], data['cap'],
                                 SEED + 10 * sorted(self.challenges).index(tid) + 1)
                with st['lock']:
                    p1 = list(st['p1_ids'])
                if fr == 'error':
                    st.update(status='error', error=st.get('p1_error'), mode='request_error')
                elif self.close_id in p1 and fr != 'length':
                    st['mode'] = 'natural'
                elif time.monotonic() < self.answer_until:
                    prefix, p2pref = continuation_ids(data['prompt_ids'], p1, self.stop_ids,
                                                      self.close_id, self.eos_ids)
                    remaining = MAX_MODEL_LEN - len(prefix) - 8
                    cap = min(int(self.cfg['answer']) * data['n'], remaining)
                    if cap < 64:
                        st.update(mode='no_room_for_answer', status='done')
                    else:
                        st['mode'] = 'continue' if not p2pref else 'forced_close'
                        st['p2_prefix'] = p2pref
                        st['p2_input_ids'] = prefix    # explicitly saved for token-exact audit
                        f2 = self._phase(tid, st, 2, prefix, cap,
                                         SEED + 10 * sorted(self.challenges).index(tid) + 2)
                        if f2 == 'error':
                            st.update(status='error', error=st.get('p2_error'))
                else:
                    st.update(mode='hard_stop_partial', status='done')
        except Exception as exc:
            st.update(status='error', error=f'{type(exc).__name__}: {exc}'[:400])
        finally:
            st['t1'] = time.time()
            st['wall'] = time.monotonic() - st['t0_pc']
            try:
                self._finalize(tid, st, callback)
            finally:
                with self.lock:
                    self.active.pop(tid, None)
                    self.threads.pop(tid, None)

    def _finalize(self, tid, st, callback):
        data, ch = self.info[tid], self.challenges[tid]
        with st['lock']:
            p1, p2 = list(st['p1_ids']), list(st['p2_ids'])
        answer, think_tokens, has_close = answer_text(self.tok, self.close_id, p1, st['p2_prefix'], p2)
        parsed = ([{'query_index': 0, 'grid': parse_grid(answer), 'mapping_source': 'single_e10',
                    'fallback_reason': None}] if data['n'] == 1 else parse_multi(answer, data['n']))
        qrows, outs = [], []
        solutions = self._resolve(self.cfg.get('_solutions'))
        for qi, item in enumerate(parsed):
            grid = item['grid']
            if not valid_grid(grid):
                grid = None
            attempt = make_attempts(ch['test'][qi]['input'], grid)
            hit = None
            if solutions is not None and tid in solutions and len(solutions[tid]) > qi:
                gold = solutions[tid][qi]
                hit = int(attempt['attempt_1'] == gold or attempt['attempt_2'] == gold)
            row = dict(task_id=tid, query_index=qi, grid=grid,
                       mapping_source=item['mapping_source'] if grid is not None else 'fallback',
                       fallback_reason=item['fallback_reason'] if grid is None else None,
                       has_grid=grid is not None, hit=hit, attempt_1=attempt['attempt_1'],
                       attempt_2=attempt['attempt_2'], src_1=attempt['src_1'], src_2=attempt['src_2'])
            assert row['query_index'] == qi and row['attempt_1'] == attempt['attempt_1']
            qrows.append(row)
            outs.append(attempt)
        rec = dict(e31_direct=True, task=tid, task_id=tid, branch=0, view='direct',
                   status=st['status'], accepted=False, publish_seq=1,
                   submissions=[{'test_outputs': [x['attempt_1'] for x in outs],
                                 'accepted': False, 'train_exact': []}],
                   e31_attempts=outs, e31_queries=qrows, mode=st['mode'],
                   note=st.get('error'), error=st.get('error'),
                   p1_finish=st.get('p1_finish'), p2_finish=st.get('p2_finish'),
                   p1_tokens=len(p1), p2_tokens=len(p2),
                   prompt_tokens=len(data['prompt_ids']),
                   generated_tokens=len(p1)+len(p2), total_tokens=len(data['prompt_ids'])+len(p1)+len(p2),
                   think_tokens=think_tokens, think_closed=has_close,
                   phase1_cap=data['cap'], thinking_floor_reachable=data['thinking_floor_reachable'],
                   t0=st['t0'], t1=st['t1'], turns=1+(1 if 'p2_finish' in st else 0),
                   failures=int(st['status'] != 'done'),
                   usage=[{'prompt': st.get('p1_prompt_used') or len(data['prompt_ids']),
                           'cached': st.get('p1_cached') or 0,
                           'completion': len(p1)}] +
                         ([{'prompt': st.get('p2_prompt_used') or len(st.get('p2_input_ids', [])),
                            'cached': st.get('p2_cached') or 0, 'completion': len(p2)}] if 'p2_finish' in st else []),
                   order_score=int(len(ch['train']) >= 3)+int(len(ch['test']) == 1),
                   admit_rank=data['idx'], group=data['group'], query_count=data['n'],
                   sec=round(st['wall'], 3),
                   t_admit_min=round((st['t0_pc']-self.start_pc)/60, 3),
                   t_done_min=round((time.monotonic()-self.start_pc)/60, 3),
                   per_request_tok_s=(len(p1)+len(p2))/max(st['wall'], 0.001))
        trace = dict(task_id=tid, mode=st['mode'], status=st['status'], error=st.get('error'),
                     p1_ids=p1, p2_ids=p2, p2_prefix=st['p2_prefix'],
                     p2_input_ids=st.get('p2_input_ids'),
                     p1_text=self.tok.decode(p1, skip_special_tokens=False),
                     p2_text=self.tok.decode(p2, skip_special_tokens=False),
                     answer_text=answer)
        _atomic_json(self.qdir / f'e31_trace_{tid}.json', trace)
        with self.trace_lock:
            with open(self.records_file, 'a', encoding='utf-8') as f:
                f.write(json.dumps(rec, ensure_ascii=False, default=str)+'\n')
        with self.lock:
            self.results[tid] = rec
            if st['status'] == 'done':
                self.finished += 1
            else:
                self.errors.append((tid, st.get('error')))
        try:
            callback(rec)
        except Exception as exc:
            self.log('E31 callback failed:', tid, repr(exc)[:300])

    def _abort_phase(self, phase):
        with self.lock:
            targets = [handle for current, handle in self.active.values() if current == phase]
        for handle in targets:
            handle.abort()
        return len(targets)

    def _report(self, wall, order):
        results = dict(self.results)
        solutions = self._resolve(self.cfg.get('_solutions'))
        groups = {}
        for name, tids in list(GROUPS.items()) + [('multi_test', [t for t in order if len(self.challenges[t]['test']) > 1])]:
            ts = [t for t in tids if t in self.challenges]
            nqueries = sum(len(self.challenges[t]['test']) for t in ts)
            qhits = [q.get('hit') for t in ts for q in (results.get(t, {}).get('e31_queries') or [])]
            sumhits = sum(x for x in qhits if x is not None)
            task_fracs = []
            fully = 0
            for tid in ts:
                hits = [q.get('hit') for q in results.get(tid, {}).get('e31_queries') or []]
                frac = (sum(h for h in hits if h is not None) / len(self.challenges[tid]['test']))
                task_fracs.append(frac)
                fully += int(len(hits) == len(self.challenges[tid]['test']) and all(h == 1 for h in hits))
            groups[name] = {'tasks': len(ts), 'queries': nqueries,
                            'query_hits': sumhits if solutions is not None else None,
                            'fully_solved_tasks': fully if solutions is not None else None,
                            'task_normalized_pct': (100*sum(task_fracs)/len(ts)) if solutions is not None and ts else None}
        gen = sum(r['generated_tokens'] for r in results.values())
        per_req = [r['per_request_tok_s'] for r in results.values()]
        report = {
            'status': 'CPU_OR_GPU_RUN_COMPLETE', 'tasks_planned': len(order),
            'tasks_admitted': self.admitted, 'tasks_finished': self.finished,
            'tasks_error': len(self.errors), 'tasks_terminal': len(results),
            'queries_planned': sum(len(self.challenges[t]['test']) for t in order),
            'solving_wall_sec': wall, 'aggregate_decode_tok_s': gen/max(wall, 0.001),
            'per_request_tok_s': per_req, 'total_generated_tokens': gen,
            'prefill_tokens': sum(u.get('prompt', 0) for r in results.values() for u in r['usage']),
            'cached_prefill_tokens': sum(u.get('cached', 0) for r in results.values() for u in r['usage']),
            'coverage': {str(k): sum(r['p1_tokens'] >= k for r in results.values()) for k in (60000, 77824, 104000)},
            'groups': groups, 'multi_test_tasks': groups['multi_test'],
            'comparison_reference': {tid: REFERENCE_RESULTS.get(tid) for tid in order},
            'per_task': {t: {'status': r['status'], 'group': r['group'], 'query_hits':
                        sum(q.get('hit') or 0 for q in r['e31_queries']) if solutions is not None else None,
                        'fully_solved': all(q.get('hit') == 1 for q in r['e31_queries']) if solutions is not None else None,
                        'task_normalized': sum(q.get('hit') or 0 for q in r['e31_queries'])/len(r['e31_queries'])
                        if solutions is not None else None,
                        'reference': REFERENCE_RESULTS.get(t)} for t,r in results.items()},
            'errors': self.errors, 'modes': {m:sum(r['mode']==m for r in results.values())
                                          for m in ('natural','continue','forced_close','no_room_for_answer','hard_stop_partial')},
            'worker_policy': {'direct_workers': self.worker_count, 'e28_duck_preflight_workers': self.e28_suggested_workers},
            'deadline_policy': {'admit_until': self.admit_until, 'drain_at': self.drain_at,
                                'answer_until': self.answer_until, 'deadline': self.deadline},
        }
        _atomic_json(self.report_file, report)
        self.E12A.SCHED_LAST = {
            'status': 'DONE' if not self.errors and len(results)==len(order) else 'INCOMPLETE',
            'requests_started': self.admitted, 'requests_finished': self.finished,
            'branches_done': self.finished, 'tasks': len(order), 'errors': len(self.errors),
            'stragglers': [t for t in order if t not in results],
            'gauges': [], 'scheduler': 'E31_DIRECT_ORDER2',
            'wall_sec': round(wall, 3), 'throughput_tok_s': report['aggregate_decode_tok_s']}
        return report

    def solve_all_r6(self, challenges, order, *, out_dir=None, deadline=None, base_url=None,
                     model_id='q27', branches=1, max_generated_tokens=None,
                     save_request_logs=True, on_branch_done=None, workers=24,
                     first_exposure_tokens=None, b1_view=None, min_admit_sec=None,
                     capacity_probe=None, kv_admit_limit=None, kv_poll_sec=None,
                     min_chunk_tokens=None, fair_share=None, stage2_p90_cutoff=None,
                     join_grace_sec=None, max_generated_tokens_b1=None,
                     skip_b1_if_accepted=None, extra_attempts=None, max_attempts=None,
                     b1_accepted_mode=None, weak_commit=None, **kwargs):
        if not callable(on_branch_done):
            raise RuntimeError('E31 requires E28 branch completion callback')
        if out_dir is not None:
            self.out_dir = Path(out_dir)
        self.results, self.active, self.threads = {}, {}, {}
        self.admitted = self.finished = 0
        self.errors = []
        self._setup(challenges, order, deadline, base_url, model_id, workers)
        cursor = 0
        inflight = {}
        drained = False
        p2_stopped = False
        while True:
            now = time.monotonic()
            if not drained and now >= self.drain_at:
                drained = True
                self._abort_phase(1)
            if not p2_stopped and now >= self.answer_until:
                p2_stopped = True
                self._abort_phase(2)
            with self.lock:
                # A new admission can never start after the drain point.
                while (cursor < len(self.order) and len(self.threads) < self.worker_count
                       and now < self.admit_until):
                    tid = self.order[cursor]
                    cursor += 1
                    self.admitted += 1
                    th = threading.Thread(target=self._do_task, args=(tid, on_branch_done),
                                          daemon=True, name='e31_' + tid)
                    self.threads[tid] = th
                    th.start()
                alive = len(self.threads)
            if not alive and cursor == len(self.order):
                break  # early return: all tasks done, no need to exhaust the window
            if now >= self.deadline:
                self._abort_phase(1)
                self._abort_phase(2)
                break
            if not alive and now >= self.admit_until:
                break
            time.sleep(0.02 if self.cfg.get('_test_mode') else 0.15)
        # Bounded grace for socket-close workers; the user-visible result is never held by an orphan thread.
        grace = min(self.deadline - time.monotonic(), 10 if not self.cfg.get('_test_mode') else 0.3)
        end_join = time.monotonic() + max(0, grace)
        for th in list(self.threads.values()):
            th.join(timeout=max(0, end_join - time.monotonic()))
        wall = time.monotonic() - self.start_pc
        return self._report(wall, self.order)


def install(E12A, *, tokenizer, challenges, sgl_url, cfg, out_dir, log=print):
    """Install ONLY in E31 notebook, before E28 CELL 8 boot/phase execution.

    Deferred callable tokenizer/sgl_url are resolved AFTER E28 boots the server.
    """
    inst = DirectRunner(E12A, tokenizer, challenges, sgl_url, cfg, out_dir, log)
    E12A.solve_all_r6 = inst.solve_all_r6
    E12A.build_submission = build_submission
    return inst
