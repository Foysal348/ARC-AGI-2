"""Pure-stdlib E31 test kit. Run: python test_e31_direct.py"""
import ast
import json
import os
import socket
import sys
import tempfile
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import e31_direct as D

PASS = 0

def check(label, fn):
    global PASS
    fn()
    PASS += 1
    print('PASS', label, flush=True)


def eq(a, b):
    assert a == b, (a, b)

class FakeTokenizer:
    eos_token_id = 248046
    def encode(self, text, add_special_tokens=False):
        out = []
        while text:
            if text.startswith('</think>'):
                out.append(248069)
                text = text[len('</think>'):]
            else:
                out.append(1000 + ord(text[0]))
                text = text[1:]
        return out
    def decode(self, ids, skip_special_tokens=False):
        s = ''
        for v in ids:
            if v == 248069:
                s += '</think>'
            elif v in (248046, 248044):
                if not skip_special_tokens:
                    s += '<|im_end|>'
            elif 1000 <= v < 1114112+1000:
                s += chr(v-1000)
            else:
                s += '?'
        return s
    def apply_chat_template(self, msgs, tokenize=False, add_generation_prompt=True, enable_thinking=True,
                            reasoning_effort='xhigh'):
        return '<|im_start|>user\n'+msgs[0]['content']+'<|im_end|>\n<|im_start|>assistant\n<think>\n'

TOK = FakeTokenizer()

def task(n=1, correct=1):
    return {'train':[{'input':[[1]],'output':[[1]]},{'input':[[2]],'output':[[2]]},{'input':[[3]],'output':[[3]]}],
            'test':[{'input':[[i+3, 0]],} for i in range(n)]}

def test_prompt():
    donor = Path(__file__).parent / 'SRC__E10_ORDER2_DIRECT_notebook.ipynb'
    nb = json.loads(donor.read_text())
    src = ''.join(nb['cells'][4]['source'])
    tree = ast.parse(src)
    nodes = [x for x in tree.body if isinstance(x, ast.FunctionDef) and x.name in ('render_grid','build_user_message')]
    ns = {}
    exec(compile(ast.Module(body=nodes,type_ignores=[]), str(donor), 'exec'), ns)
    for train in (task()['train'], []):
        for inp in ([[1, 2], [0, 3]], [[4]]):
            eq(D.build_user_message(train, inp), ns['build_user_message'](train, inp))
    assert 'FINAL INPUT 1' in D.build_multi_message(task()['train'], [[[1]], [[2]]])
    assert '```grid 2\n' in D.build_multi_message(task()['train'], [[[1]], [[2]]])

def test_single_parser():
    layouts = {
       'grid_fence':'Done.\n```grid\n1 0 2\n3 4 5\n```',
       'no_label':'```\n1 0 2\n3 4 5\n```',
       'text_contiguous':'```text\n102\n345\n```',
       'comma_rows':'```grid\n1,0,2\n3,4,5\n```',
       'header':'```grid\nOutput:\n1 0 2\n3 4 5\n```',
       'json':'```json\n[[1, 0, 2], [3, 4, 5]]\n```',
       'unclosed':'```grid\n1 0 2\n3 4 5\n',
       'last_wrong':'```grid\n1 0 2\n3 4 5\n```\n```python\nhi\n```',
    }
    for src, txt in layouts.items():
        eq(D.parse_grid(txt), [[1,0,2],[3,4,5]])
    eq(D.parse_grid('```grid\n1 10 2\n```'), None)

def test_multi_parser():
    vals = [ [[1]], [[2]], [[3]] ]
    cases = [
       ('```grid 2\n2\n```\n```grid 1\n1\n```',2, [vals[0],vals[1]]),
       ('```grid 1\n1\n```\n```grid\n2\n```',2, [vals[0],None]),
       ('```grid\n1\n```\n```grid 2\n2\n```',2, [None,vals[1]]),
       ('```grid 1\n5\n```\n```grid 1\n1\n```\n```grid 2\n2\n```',2,[vals[0],vals[1]]),
       ('```grid 3\n3\n```\n```grid 1\n1\n```\n```grid 2\n2\n```',3,vals),
       ('```grid\n1\n```\n```grid\n2\n```',2,[vals[0],vals[1]]),
       ('```grid\n1\n```\n```grid\n2\n```\n```grid\n3\n```',2,[None,None]),
       ('```grid 1\n1\n```\n```grid 2\n2\n',2,[vals[0],None]),
       ('grid 1\n```grid\n1\n```\ngrid 2\n```grid\n2\n```',2,[vals[0],vals[1]]),
       ('```grid 1\n1 2\n3\n```\n```grid 2\n2\n```',2,[None,vals[1]]),
       ('```grid 2\n2\n```\n```grid 1\n1\n```\n```grid 2\n0\n```',2,[vals[0],[[0]]]),
    ]
    for txt, n, expected in cases:
        got = D.parse_multi(txt,n)
        eq([x['grid'] for x in got],expected)
        eq([x['query_index'] for x in got],list(range(n)))
        if any(x['mapping_source']=='label' for x in got):
            assert all(x['mapping_source']!='positional' for x in got)

def test_fallback():
    inp = [[3, 0, 4]]
    got = D.make_attempts(inp, [[7]])
    eq(got['attempt_2'],inp)
    eq(D.make_attempts(inp, None)['attempt_1'],inp)
    eq(D.make_attempts(inp, None)['attempt_2'],[[4,0,3]])
    eq(D.make_attempts(inp,inp)['attempt_2'],[[4,0,3]])
    eq(D.make_attempts([[1,1]],None)['attempt_2'],[[1,1]])

def test_direct_only():
    ts = D.TASKS[:3]
    ch = {ts[i]:task(i+1) for i in range(3)}
    rows = {}
    for i,tid in enumerate(ts):
        qs=[]
        for qi in range(i+1):
            g = None if qi==1 else ([[qi+4,0]] if qi==0 else ch[tid]['test'][qi]['input'])
            qs.append(D.make_attempts(ch[tid]['test'][qi]['input'],g))
        rows[tid] = [dict(e31_direct=True, branch=0, e31_attempts=qs,
                          submissions=[dict(accepted=False, train_exact=[True, True], test_outputs=[[[9]]])],
                          checked=[dict(accepted=True,test_outputs=[[[9]]])])]
    sub=D.build_submission(ch,rows)
    for i,tid in enumerate(ts):
        for qi,v in enumerate(sub[tid]):
            eq(v['attempt_1'],rows[tid][0]['e31_attempts'][qi]['attempt_1'])
            assert v['attempt_1'] != [[9]]
    # Exactly the E28 CELL7 scorer's trust boundary: DIRECT wrong, CPU 'correct' is irrelevant.
    eq(D.build_submission({ts[0]:ch[ts[0]]}, {ts[0]:rows[ts[0]]})[ts[0]][0]['attempt_1'], [[4,0]])
    eq(D.build_submission({ts[0]:ch[ts[0]]}, {})[ts[0]][0]['attempt_1'], ch[ts[0]]['test'][0]['input'])

def test_ids():
    stop=TOK.encode(D.STOP_THINKING_TEXT)
    close=TOK.encode('</think>')[0]
    p=[5,6]; p1=[7,8,248046]
    pref, suffix = D.continuation_ids(p,p1,stop,close,{248046,248044})
    eq(pref,p+[7,8]+stop)
    eq(suffix,stop)
    pref2,suffix2=D.continuation_ids(p,[7,close,8],stop,close,{248046})
    eq(pref2,p+[7,close,8]);eq(suffix2,[])
    assert close in stop

def test_caps():
    eq(D.phase1_cap(5000,1,dict(think=104000,answer=8192)),104000)
    assert D.phase1_cap(100_000,3,dict(think=104000,answer=8192)) < 60000
    assert D.phase1_cap(110_000,3,dict(think=104000,answer=8192)) == 0

class FakeE12A:
    def __init__(self):
        self.SCHED_LAST = {}
        self.solve_all_r6 = None
        self.build_submission = lambda ch,recs: {tid:[{'attempt_1':[[9]],'attempt_2':[[9]]}]*len(c['test']) for tid,c in ch.items()}

class FakeStreamingServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address=True
    def __init__(self,*args, **kwargs):
        super().__init__(*args,**kwargs)
        self.active=0;self.max_active=0;self.phases=[];self.lock=threading.Lock()
        self.phase1_calls=0;self.fail_once=False;self.killed=0

class FakeHandler(BaseHTTPRequestHandler):
    protocol_version='HTTP/1.1'
    def log_message(self,*args):pass
    def do_POST(self):
        if self.path != '/v1/completions':
            self.send_error(404);return
        body=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
        ids=body['prompt']
        is_p2=any(v == 248069 for v in ids[-400:])
        with self.server.lock:
            self.server.phases.append((is_p2,body))
            self.server.active+=1
            self.server.max_active=max(self.server.max_active,self.server.active)
            if not is_p2:
                self.server.phase1_calls+=1
                number=self.server.phase1_calls
            else: number=None
        self.send_response(200);self.send_header('Content-Type','text/event-stream');self.send_header('Cache-Control','no-cache');self.end_headers()
        def send(ids, reason=None):
            payload={'choices':[{'token_ids':ids,'text':'', 'finish_reason':reason}]}
            self.wfile.write(b'data: '+json.dumps(payload).encode()+b'\n\n');self.wfile.flush()
        try:
            if not is_p2:
                if number == 4:
                    # Transport died: no finish; never count this as successful completion.
                    self.server.killed += 1
                    self.connection.shutdown(socket.SHUT_RDWR)
                    self.connection.close()
                    return
                if number <= 8:
                    send(TOK.encode('</think>\n```grid\n1\n```'), 'stop')
                    send([],None)
                else:
                    # Long-running thought, drained by closing the response at T-drain.
                    while True:
                        send(TOK.encode('thought '))
                        time.sleep(0.035)
            else:
                # Emit 1/2/3 labeled blocks, determined by FINAL INPUT count in prefix.
                # All task prompts have one or more test inputs; infer N by decoded prefix.
                decoded = TOK.decode(ids)
                n = max(1,decoded.count('FINAL INPUT '))
                txt='\n'.join('```grid %d\n%d\n```'%(i+1,i+1) for i in range(n))
                send(TOK.encode(txt),'stop')
        except (BrokenPipeError,ConnectionResetError,OSError):
            pass
        finally:
            with self.server.lock:
                self.server.active-=1
            self.close_connection=True


def test_24_fake_server():
    srv=FakeStreamingServer(('127.0.0.1',0),FakeHandler)
    thread=threading.Thread(target=srv.serve_forever,daemon=True);thread.start()
    host='http://127.0.0.1:%d'%srv.server_address[1]
    tmp=Path(tempfile.mkdtemp(prefix='e31_test_'))
    e12=FakeE12A()
    cfg={'think':100,'answer':100,'window_min':170,'workers':24,'temperature':0.6,
         'drain_min':24,'_test_time_scale':0.10,'_test_mode':True,'enforce_flash_next_ids':False}
    sols={tid:[t['input'] for t in task(1)['test']] for tid in D.TASKS}
    cfg['_solutions']=lambda:sols
    run=D.install(e12, tokenizer=lambda:TOK, challenges=lambda:None, sgl_url=lambda:host,
                  cfg=cfg, out_dir=tmp/'duck',log=lambda *args:None)
    selected={tid:task(1 if idx%5 else 2) for idx,tid in enumerate(D.TASKS)}
    order=list(reversed(D.TASKS))
    callbacks=[];lk=threading.Lock()
    def cb(rec):
        with lk:callbacks.append(rec)
    deadline=time.monotonic()+3.7
    try:
        summary=e12.solve_all_r6(selected,order,out_dir=tmp/'duck',
                    deadline=deadline,base_url=host+'/v1',model_id='q27',on_branch_done=cb, workers=24)
        # First 8 close early; the remaining 22 (with one connection-kill) must be admitted by drain.
        assert summary['tasks_admitted'] == 30, summary
        assert summary['tasks_terminal'] == 30, summary
        assert summary['tasks_error'] >= 1, summary
        assert summary['tasks_finished'] == 30-summary['tasks_error']
        assert 0 < srv.max_active <=24, srv.max_active
        assert len(callbacks)==30
        assert all(r['branch']==0 and r['e31_direct'] for r in callbacks)
        assert sum(r['mode']=='forced_close' for r in callbacks)>0
        assert any(r['status']=='error' for r in callbacks)
        assert len([p for is2,p in srv.phases if is2]) > 0
        # Phase-2 requests must use the raw token prefix and the exact STOP_IDS.
        for is2,body in srv.phases:
            if is2:
                assert body['prompt'][-1] in TOK.encode(D.STOP_THINKING_TEXT) or 248069 in body['prompt']
        assert summary['groups']['multi_test']['tasks']>0
        assert 'fully_solved_tasks' in summary['groups']['main']
        assert summary['coverage'].keys() >= {'60000','77824','104000'}
        assert (tmp/'q27x'/'e31_direct_records.jsonl').is_file()
        assert (tmp/'q27x'/'e31_direct_report.json').is_file()
        assert len(list((tmp/'q27x').glob('e31_trace_*.json'))) ==30
        assert len(e12.build_submission(selected,{r['task_id']:[r] for r in callbacks}))==30
        assert e12.SCHED_LAST['scheduler']=='E31_DIRECT_ORDER2'
    finally:
        srv.shutdown();srv.server_close();thread.join(timeout=2)




def test_real_e28_cell7_scorer():
    """Execute the donor's actual e21_cell7 function over DIRECT-only fixtures."""
    import types, zipfile, traceback
    donor_path=Path(__file__).parent/'SRC__E28_k100_code_export.py'
    tree=ast.parse(donor_path.read_text())
    node=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='e21_cell7')
    t=Path(tempfile.mkdtemp(prefix='e31_real_e28_'))
    (t/'duck').mkdir(parents=True,exist_ok=True)
    ids=D.TASKS[:3]
    ch={ids[0]:task(1),ids[1]:task(2),ids[2]:task(3)}
    gold={ids[0]:[[[9]]], ids[1]:[[[9]],[[8]]],ids[2]:[[[9]],[[8]],[[7]]]}
    # CPU train-exact candidates are right; DIRECT wrong: must still score 0.
    rr={}
    for tid,c in ch.items():
        at=[D.make_attempts(ti['input'], [[1]]) for ti in c['test']]
        rr[tid]=[dict(task_id=tid,branch=0,e31_direct=True,e31_attempts=at,
                      accepted=False,status='done',submissions=[{'accepted':False,
                      'train_exact':[True]*len(c['train']),
                      'test_outputs':gold[tid]}],
                      usage=[dict(prompt=10,cached=0,completion=4)],generated_tokens=4,
                      t0=1,t1=2)]
    e12=FakeE12A()
    D.install(e12,tokenizer=lambda:TOK,challenges=lambda:ch,
              sgl_url=lambda:'http://127.0.0.1:8001',cfg=dict(think=104000,answer=8192),out_dir=t/'duck')
    def writer(path,obj):
        with open(path,'w') as f:json.dump(obj,f)
    ns=dict(_E12_LOCK=threading.Lock(),E12_RECORDS=rr,E12A=e12,
            CHALLENGES=ch,TASK_IDS=ids,OUT=t,SOLUTIONS=gold,
            RUN_ID='cpu_e31',PROFILE='E31DIRECT30',RERUN=False,
            CONFIG={},ENGINE_INFO={},E12_RUN={'branches_accepted':0},E12_ORDER=ids,
            _E12_REV6=False,E11_SERVER=None,e11_decode_summary=lambda:{},
            e12_write_submission=lambda:None,write_json_atomic=writer,
            WORKING=t,E21_VARIANT='E31',E21_HALF='A',E12_OUT=t/'duck',
            SUBMISSION_PATH=t/'submission.json',zipfile=zipfile,
            traceback=traceback,json=json,engine=types.SimpleNamespace(),
            e11_kill_server=lambda **kwargs:None)
    exec(compile(ast.Module(body=[node],type_ignores=[]),str(donor_path),'exec'),ns)
    ns['e21_cell7']()
    report=json.loads((t/'e12_run_report.json').read_text())
    eq(report['eval_query_hits'],0)
    eq(report['eval_query_total'],6)
    eq(report['eval_task_norm_pct'],0.0)
    generated=json.loads((t/'e12_generated_attempts.json').read_text())
    assert all(generated[tid][qi]['attempt_1']==[[1]]
               for tid in ids for qi in range(len(ch[tid]['test'])))

def test_integrated_notebook():
    nb=json.loads((Path(__file__).parent/'E31_FN_DIRECT30.ipynb').read_text())
    assert len(nb['cells'])==10
    assert len((Path(__file__).parent/'E31_FN_DIRECT30.ipynb').read_bytes())<400000
    s=''.join(nb['cells'][2]['source'])
    assert s.startswith('E31_CFG =') and "'drain_min': 24" in s
    assert "NB5_DEFAULT_PROFILE = \"E31DIRECT30\"" in s
    assert "K100_DEADMAN_SEC = 205 * 60" in s
    assert "PROFILE_TABLE['E31DIRECT30']" in s
    assert 'e28_sched=False' in s
    assert 'E12_BRANCHES = 1 if PROFILE == "E31DIRECT30"' in s
    assert 'e28_sched_patch.py' not in ''.join(nb['cells'][7]['source'])
    for c in nb['cells']:
        if c['cell_type']=='code':compile(''.join(c['source']),'cell','exec')
    assert 'CELL 8' in ''.join(nb['cells'][8]['source'])[:200]

if __name__=='__main__':
    for name, fn in [('prompt_exact_E10',test_prompt), ('single_grid_E10',test_single_parser),
                     ('multi_labels_and_positional',test_multi_parser),('attempts',test_fallback),
                     ('DIRECT_only_candidate',test_direct_only),('token_exact',test_ids),
                     ('context_caps',test_caps),('fake_24_streams_and_kill',test_24_fake_server),
                     ('integrated_notebook',test_integrated_notebook),
                     ('donor_E28_cell7_actual_scorer',test_real_e28_cell7_scorer)]:
        check(name,fn)
    print('ALL_OK',PASS)
