# BUILD TASK: the E31 Flash-Next DIRECT solver module (Kaggle ARC-AGI-2, 4xL4, Merlin vLLM-0.32 fork)

You are one of three independent builders. Write production code, not a review. Your output will be compared with
other builds and the best parts merged, so follow the contract exactly and make every behaviour testable.

## Read first
1. `DESIGN__E31_FN_DIRECT30.md` (goal, design) and `FIXLIST__E31_design_audits_1_2_3.md` — the CONSOLIDATED E31 FIX LIST
   at its end is MANDATORY (8 items: label-only parser, DIRECT-only submission adapter, phased drain, ids only, client on
   SGL_URL :8001 with E28 as the single lifecycle owner, budget, report fields, e2e). Also: ONE unit per TASK (a
   multi-test task = one prompt with FINAL INPUT 1..N, one thinking, labeled ```grid K blocks); the solver returns as soon
   as all tasks are done (window = upper cap only).
2. `REPORT__DIRECT_solver_spec_E10_ORDER2.md` (the proven 27B DIRECT method: prompt verbatim, STOP text / STOP_IDS,
   phase 1 / phase 2 token-exact, parse_grid, make_attempts, ORDER2 order, seeds) and `SRC__E10_ORDER2_DIRECT_notebook.ipynb`.
3. `REPORT__E28_K100_notebook_hookpoints.md` + `SRC__E28_k100_code_export.py` (the host notebook: the
   `E12A.solve_all_r6(...)` call contract at E:4274, the record contract read by e21_cell7 / build_submission /
   E28 report, `E12A.SCHED_LAST`, `_e12_branch_done_r6`, SGL_URL, deadlines, nb5_phase margins).
4. `SRC__E18_vllm032_shim_e18_engine_cell.py` (proven streaming token-id `/v1/completions` client behaviour on vLLM 0.32:
   take ONLY the client behaviour, not its server / relaunch).

## Deliverables (all as complete files)
A. `e31_direct.py` — one self-contained module (stdlib + `requests` or `urllib`; no new deps) exposing:
   - `install(E12A, *, tokenizer, challenges, sgl_url, cfg, out_dir, log)`: rebinds `E12A.solve_all_r6` and
     `E12A.build_submission` (DIRECT-only adapter) and returns a handle; `cfg` = the CELL 1 line
     `E31_CFG = {'think': 104000, 'answer': 8192, 'window_min': 170, 'workers': 24, 'temperature': 0.6, 'drain_min': <you size it>}`.
   - the solver with E28's exact `solve_all_r6` signature / return / on_branch_done record contract, 24 worker threads,
     continuous admission in ORDER2 order, phase 1 streaming with token ids, forced-close / continue phase 2,
     phased drain (no admission after T-12 min, drain at T-drain_min, phase-2 abort at T-1 min with partial parse),
     early return when all tasks finish, request errors never counted as a finish, no relaunch of its own.
   - prompt builder (single-test = ORDER2 bytes verbatim; multi-test variant as specified), the label-only multi-test
     parser (record query_index / mapping_source / fallback_reason), make_attempts per test (ORDER2).
   - `E12A.SCHED_LAST` population, `q27x/e31_direct_records.jsonl` + `q27x/e31_direct_report.json` (fields in the design +
     fix list: per group main/partial/control, query_hits / fully_solved / task_norm, multi-test separately, coverage at
     60k / 78k / 104k, solve wall, aggregate decode tok/s, per-request tok/s, prefill tokens), full thinking of every
     request saved under q27x/.
B. `e31_cell.py` — the exact text of the ONE new notebook cell (placed between E28 CELL 6/7 and CELL 8) that loads the
   module (sha-pinned packed literal or a dataset file) and calls `install(...)` with the notebook's globals.
C. `e31_cell1_patch.md` — the exact CELL 1 edits: the E31_CFG plain line at the top, the new profile row (30 tasks
   task_list, ~205-min budget for a 170-min window, deadman literal, no e28_sched) and a build-time assertion of the window.
D. `test_e31_direct.py` — pytest-free unit tests (plain asserts, runnable as `python test_e31_direct.py`) covering every
   regression case in the fix list, including a fake streaming token-id server (threaded, 24 parallel streams,
   never-closing thinking, a kill injection) and the real-`build_submission`-free check that the adapter's attempts ==
   expected for 1/2/3-test, partial, no-grid, model==input; "DIRECT wrong + CPU rule right -> scored wrong".
E. `NOTES.md` — what you verified in the sources vs assumed (line refs), open risks, and the timeline estimate.

Constraints: proven methods are copied, never re-invented; no quality / label heuristic may stop or skip a request
(gates only on real failures); never decode-then-retokenize; thinking floor 60k (record if a prompt forbids it);
keep the module < 60 kB. Do not modify anything in E28 except via the rebinds in B / the CELL 1 edits in C.
