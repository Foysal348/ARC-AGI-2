# E31 FN DIRECT30 GPU FINAL — GPT severe-only audit

**NO-GO as submitted.** No new Kaggle GPU execution was performed.

## Package integrity
- Manifest: 31/31 file hash and size checks PASS (locally recomputed).
- Notebook SHA256: 1939954665c723dcf9321ac383cd1f9fdf15c00b483782936223baf91661e55b — matched prompt.
- Source Python AST parses; original supplied CPU units 74/75 and `ALL_OK=false` (test-only missing Any); e2e commit `ALL_OK=true`; real kit `ALL_OK=true`. These are supplied CPU tests, not GPU proof.

## HIGH 1: phase-1 server error prematurely forces close
`BUILD__e31_direct.py:773-778` handles a recovered pending `p1` by immediately invoking `start_phase2()`, even if phase-1 produced zero thinking tokens and ample thinking time remains. This is not counting the request error as a *natural finish*, but it prematurely terminates thinking and may destroy solution quality after server relaunch.

**Fix:** resend phase 1 with `prompt_ids + streamed p1_ids` (EOS handling left to forced-close), remaining original phase-1 budget, new request ID, same seed; do this while `now < DRAIN`. Once at/after DRAIN, preserve normal forced-close. A concrete source-level draft is included in `PATCHED__e31_direct.py` (not yet integration-tested on GPU).

**Test:** kill fake server after 0 and >0 phase1 tokens; recover well before DRAIN; assert the next POST is phase-1, prompt token IDs exactly original prompt + retained tokens, not STOP_IDS, and remaining cap is correct. Confirm repeated errors consume max_error_retries; post-DRAIN recovery starts phase2.

## HIGH 2: multi-test phase-1 budget reserves only one answer
`BUILD__e31_direct.py:563`: `phase1_cap(len(ids), think, answer, max_model_len)` despite `answer_cap()` using `answer * NTEST[tid]` at line 589. Three-test prompts can exhaust context and leave less than the configured 24,576 answer tokens, resulting in missing grids.

**Fix:** `phase1_cap(len(ids), think, answer * NTEST[tid], max_model_len)`; draft source patched.

**Test:** for N=1/2/3 near 131072 context bound assert `prompt + p1cap + answer*N + 256 <= max_model_len`, and `p1cap` decreases with N. Note the existing 60k floor is diagnostic, not always attainable for long prompts.

## HIGH 3 (conditional): 24-worker DIRECT run silently inherits Duck isolation cap 6
`BUILD__e31_code_export.py:4115-4116` uses `E12A.workers_for_isolation(...)`; FAIL/INCONCLUSIVE can return 6. `BUILD__e31_code_export.py:4818` uses `_w = min(int(workers), int(E31_CFG["workers"]))`. Thus a transient/failed isolation preflight changes DIRECT to 6 streams, which can jeopardize the 30-task 170-minute window without an explicit NO-GO. This does **not** prove that the current GPU run will be capped; it is a confirmed conditional path.

**Fix:** do not bypass a real isolation failure blindly. If `_w < E31_CFG["workers"]`, either fail closed with explicit `E31_DIRECT_WORKERS_GATE` before timing, or run a separate DIRECT isolation smoke and choose 24 only on its PASS; otherwise report degraded experimental validity rather than claiming a 24-worker result.

**Test:** simulate PASS, FAIL and INCONCLUSIVE from the preflight; FAIL/INCONCLUSIVE must not silently appear as 24-worker experiment, and the report must show actual worker count and coverage impact.

## Refuted / not proven blockers
- STOP_IDS is checked by CPU tests: 25 tokens, </think> = 248069. Runtime only asserts membership, not exact equality. Add `assert STOP_IDS == FN_STOP_IDS` as a useful fail-closed check, but existing pinned tokenizer evidence does not establish an actual wrong-token bug.
- DIRECT-only submission: `BUILD__e31_direct.py:869-881` reads `e31_attempts` only; Duck/CPU candidate cannot enter via this adapter. For 1/2/3-test tasks record construction asserts full cardinality. Parser handles mixed labeled/unlabeled conservatively. No confirmed new test-grid mis-mapping found in these paths.
- `HARD = T_END - 60`; loop breaks when no active work, not always at window end. A scheduling deadline overrun is not proven; external server/socket teardown can still be GPU dependent.
- Request errors are recorded as errors and retried; exhausted retry becomes `end_reason='error'` and fallback attempts. Not mistaken for a natural finish. Severe issue is premature forced close on recovery.

## Gate
**NO-GO as packaged**. Apply HIGH 1 + HIGH 2, rebuild the exact notebook with embedded/source SHA updated, resolve HIGH 3 via explicit worker admission policy, rerun fake-server kill/relaunch, 1/2/3-grid adapter tests, CPU units and e2e. Then GO for GPU smoke, not production certification.

`PATCHED__e31_direct.py` is a review patch sketch, syntax checked but not a complete rebuilt Kaggle notebook. Do not upload it as if already production-approved.
