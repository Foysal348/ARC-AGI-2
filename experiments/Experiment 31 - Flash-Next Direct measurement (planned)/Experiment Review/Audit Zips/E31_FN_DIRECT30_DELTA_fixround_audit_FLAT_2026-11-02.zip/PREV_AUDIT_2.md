# E31 FN DIRECT30 GPU FINAL — strict independent audit

**VERDICT: NO-GO as-is for the 30-task GPU experiment.** One confirmed severe loss-of-reasoning recovery bug; two concrete accuracy/throughput exposure defects. Existing model boot/selector integration is not disproven by this audit.

## Evidence

- Source ZIP: `E31_FN_DIRECT30_GPU_FINAL_audit_FLAT_2026-11-02(1).zip`
- Notebook SHA-256: `1939954665c723dcf9321ac383cd1f9fdf15c00b483782936223baf91661e55b` (independently matched).
- Manifest: 31/31 SHA and sizes matched; 9/9 notebook code cells compile.
- Supplied Kaggle real kit: ALL_OK for this notebook SHA.
- Supplied fake-stream E2E commit: ALL_OK for this notebook SHA.
- Supplied Kaggle unit kit: 74/75; the 1 fail is `NameError: Any` when a test execs Duck `select_attempts_r5` without importing `typing.Any`. The failure is in a test fixture, not evidence of a GPU solver crash. Do NOT report 75/75.
- Full GPU inference **not observed**. Kits contain fake server, source/static and real installed-tree probes, not a 30-task 4×L4 run.

## HIGH-1 — A phase-1 HTTP error destroys remaining thinking budget

`BUILD__e31_direct.py:773-778`, `:799-812`, `:592-612`.

When `pending == 'p1'` on recovered health, code immediately executes `start_phase2(st, resend=False)`, regardless of whether only zero or a few phase-1 tokens have been generated. This ends a 104k-reasoning attempt as a forced close. A server restart affecting 24 concurrent requests can irreversibly lose reasoning on all 24; an HTTP 500 before first token can produce a zero-thinking forced answer. `end_reason='forced_close'` masks that the transition was error-driven; the `request_errors` array alone discloses it.

**Fix:** implement `resume_phase1(st)` with `prompt_ids + p1_ids`, `remaining_cap=P1_CAPS[tid]-len(p1_ids)`, and a new unique phase-1 RID (`rid(tid,1, st['retries'])`). On recovery before `DRAIN`, resend phase 1 (do not erase existing p1 ids); at/after `DRAIN`, use phase 2. If a recovered stream already contains `</think>` and the answer is incomplete, use a continuation path; avoid appending a second `</think>`. Enforce the retry bound. Handle zero tokens and exactly exhausted remaining cap. Keep the previously streamed token IDs unmodified, except documented trailing EOS cleanup when forced-close is required.

**Test:** 0-token HTTP 500, 17-token failed stream, server down during 24 streams, recovery before/after DRAIN, repeated error until retry limit. Assert phase-1 retry request prompt contains exactly original prompt+retained p1 ids, no early STOP_IDS, no duplicate final grids, error never classified as a natural finish, and no orphan requests.

## HIGH-2 — Multi-test phase-1 cap omits reserve for multiple answers

`BUILD__e31_direct.py:563` currently calls `phase1_cap(len(ids), think, answer, max_model_len)` while `:589-590` correctly uses `answer*NTEST[tid]` for phase 2. With 3 tests, the intended context reserve is `3*8192`, not `8192`. The supplied four-build comparison reports task `b6f77b65` receives cap 104,000 rather than designed 102,234. This can truncate the final second/third grid through context exhaustion, particularly after long thinking.

**Fix:** `cap = phase1_cap(len(ids), think, answer * NTEST[tid], max_model_len)`.

**Test:** 1-,2-,3-test caps; ensure `prompt + cap + answer*N + CONTEXT_SAFETY <= max_model_len`. A 3-test answer must not run out of allocated room due to phase-1 cap. Mark exact task-specific adjustment in build facts.

## HIGH-3 (conditional) — Duck isolation gate silently caps DIRECT to 6 workers

`BUILD__e31_code_export.py:4108-4118` computes `_workers = E12A.workers_for_isolation(isolation_ok, E12_RUN['streams'])`, where FAIL/INCONCLUSIVE means 6. `BUILD__e31_code_export.py:4818` then does `_w = min(int(workers), E31_CFG['workers'])`.

DIRECT does not execute Duck's Python-tool sandbox. Nevertheless any unrelated Duck isolation smoke failure limits the intended 24-client experiment to 6, changing throughput and task coverage. This is **conditional**, not proof the included Kaggle kit fell back to 6; the real kit ALL_OK does not independently certify an entire 170-minute solve's worker count.

**Fix:** in the E31-only wrapper read the validated server stream cap (e.g. `E12_RUN['streams']`) and `E31_CFG['workers']` directly, instead of the Duck isolation-limited `workers`. Preserve the separate sandbox self-test and engine-start requirements; do not override actual server KV/max-num-seqs limits.

**Test:** isolation PASS and INCONCLUSIVE with server cap 24 should both pass 24 DIRECT workers, with actual `max_active==24`; server cap 12 should retain 12. Verify the full solver never admits more than effective server capacity.

## Additional verified distinctions / nonfatal gates

1. `STOP_IDS` verification is record-only (`BUILD__e31_direct.py:533-550`): `THINK_CLOSE_ID` membership asserted, exact `FN_STOP_IDS` equality merely logged. The real pinned tokenizer probe in supplied kit passed, but add a runtime fail-closed assertion before any request for dependable token-exact continuation. This is a quality safeguard, not an independently reproduced crash.
2. `drain_min=23` allows 23 min to `T`, but hard abort at `T−1 min` leaves only 22 min for max 3×8192 tokens; at assumed 18 tok/s this requires 22.76 min. Thus the **actual uninterrupted phase-2 budget is one minute shorter than the documented reserve**. The model can still output partial grids; use >=24 min drain or measure actual phase-2 rate, remembering many streams may experience preemption.
3. Hidden rerun configuration uses DIRECT for all test tasks in `RERUN_PROD`. A fixed 170-minute solve window cannot be assumed adequate for 240 tasks with 104k-token thinking. Do not treat a successful 30-task diagnostic as production submission readiness. Preserve the existing verified E28 candidate for final submission until measured score/workload evidence exists.
4. DIRECT-only `build_submission_direct` and labeled multi-test grid routing appear structurally consistent; no confirmed wrong-grid mapping or CPU-rule contamination in the supplied normal/E2E probes. Real L4 output distribution remains UNVERIFIED.
5. Error-exhausted tasks use `end_reason='error'` and `SCHED['error_finishes']` counters; these are explicitly distinguishable from successful natural finishes. The severe issue is the *early recovery transition*, not a demonstrated error-to-natural finish misclassification.

## Release gate

1. Patch HIGH-1 and HIGH-2, and resolve HIGH-3 before comparing 24-stream measurements.
2. Rebuild compact notebook with updated embedded `e31_direct` literal; DO NOT simply replace `BUILD__e31_direct.py` outside the notebook (the GPU notebook executes its embedded module). Recompute notebook hash and rerun 400kB size gate.
3. Replay source-derived error/relaunch fault injection and all supplied CPU kits on **new** notebook SHA; execute long-context smoke/oracle before a costly 170-minute experiment.
4. GO for research after these targeted patches; NO-GO to substitute this experimental DIRECT solver for established final hidden-rerun production without score evidence.

No GPU run/push was performed. The original uploaded notebook was not modified.
