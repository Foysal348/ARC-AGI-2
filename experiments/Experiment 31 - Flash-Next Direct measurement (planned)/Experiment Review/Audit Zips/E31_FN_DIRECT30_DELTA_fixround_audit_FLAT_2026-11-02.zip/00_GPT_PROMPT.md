# DELTA audit: E31 Flash-Next DIRECT 30 — the fix round only (Kaggle 4xL4, klee100 MTP on Merlin, hosted in E28 K100)

**Answer GO or NO-GO on the first line. Then list ONLY BLOCKERS and SEVERE bugs introduced or left by THIS fix round**
(crash, wrong / lost answer, a request error counted as a finish, wrong grid-to-test mapping, deadline overrun, wrong score),
each with file:line, why, fix. No style items, no new features, no re-review of unchanged code.

Scope = the diff `DIFF__e31_direct.py.diff` (+ `DIFF__e31_code_export.py.diff`: CELL 7b and CELL 1). Three earlier GPT audits
of the OLD build are included (`PREV_AUDIT_1..3.md`); their HIGH items were: (1) a phase-1 request error immediately
force-closes (even with 0 thinking), (2) phase-1 cap uses answer instead of answer x N tests, (3) CELL 7b workers inherit
Duck's isolation-gated 6, (4) STOP_IDS / </think> only recorded, plus drain_min 23 too small and a phase-2 resend that drops
the already streamed p2 ids. The fix round (`REPORT__E31_fix_round_agent_report.md`) applied: `resend_phase1` before the
drain (prompt + kept p1 ids, EOS stripped, cap = p1 cap - kept, same seed, new rid; < 64 left -> normal phase 2), cap x N,
workers = min(E31_CFG workers, E12_RUN streams), STOP_IDS fail-closed before any request, a kit-test typing fix. The pushed
notebook `NB__PUSH_...ipynb` (sha 445c3d3a08a2f5d3f577e9f38fa442596a800d423c314dd6dce4c5f89571928d) = the kit-passed build d57a7916 with ONE edit: the CELL 1 E31_CFG line
drain_min 23 -> 26. NOT changed (known, medium): a phase-2 resend restarts the answer (p2_ids reset) instead of keeping the
streamed p2 ids — say whether that is a blocker for a 30-task diagnostic.
Kits on d57a7916: `KIT_units__*` 81/81, `KIT_e2e-commit__*` ALL OK (fake streaming token-id server, 24 streams, kill +
relaunch), `KIT_real__*` ALL OK.
Questions: (a) is resend_phase1 correct for every case (0 tokens; k tokens; </think> already streamed with a partial answer;
an error at / after the drain; retries exhausted; stale stream ids after a resend)? (b) can the cap x N change push any task
below what its prompt allows or break phase 2's room? (c) can the fail-closed assert ever fire on the real tokenizer?
(d) does drain_min 26 with think 104000 / window 170 still leave phase 2 its time and keep the run inside its budget?
