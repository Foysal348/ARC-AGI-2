# DESIGN review: E31 Flash-Next DIRECT on 30 EVAL tasks (Kaggle 4xL4, klee100 on Merlin vLLM-0.32 fork)

**Answer GO / NO-GO for the DESIGN on the first line. Then list ONLY BLOCKERS and SEVERE design problems** (something that
would crash, waste the GPU run, write a wrong / missing answer, mis-map a grid to a test, or make the measurement
meaningless), each with the file / section, why, and the fix. No style items, no new features.

Read `DESIGN__E31_FN_DIRECT30.md` first (goal, base pieces, design, timeline, the reviewer questions at its end). The two
`REPORT__*` files are full specs of the two proven bases (27B DIRECT method E10 ORDER2; the Flash-Next E28 K100 boot
notebook). `SRC__*` are the real sources (the ORDER2 notebook, the E28 notebook + code export + builder + lib + CPU kit,
the E18 vLLM-0.32 streaming token-id shim). `DATA__*` = the per-task table (K100 / W4 / 27B Direct / 27B Duck) and the E28
run summary (engine tok/s, residents, preemptions, attempt tokens, boot).
The notebook itself is being built now from this design; your review decides changes before the build is final.
Rules from the user: proven methods are copied (no own safety rules); gates only on real failures; thinking floor 60k.
