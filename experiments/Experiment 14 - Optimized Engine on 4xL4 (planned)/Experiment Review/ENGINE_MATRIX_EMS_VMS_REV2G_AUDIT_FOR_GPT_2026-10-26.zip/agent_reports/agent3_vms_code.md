# VMS notebook audit: control flow and crash / wrong-result paths in cells 5-7 (agent 3)

Scope: `D:/ARC AGI 2/_scratch/engine_audit_cells/vms/cell5.py` (CELL V1), `cell6.py` (CELL V2), `cell7.py` (CELL V3), read in full, plus cells 0-4 for the names they use (HARD_STOP, `_ts`, E14_STATE, e14_save, the prompts). I checked vLLM 0.32.0 behaviour against the partial 0.32.0 sources on disk: `D:/ARC AGI 2/_scratch/vllm_whl/src032/` (metrics loggers, cli serve, core_client), plus files I pulled from the truncated wheel `D:/ARC AGI 2/_scratch/vllm_whl/vllm-0.32.0-...whl` by scanning its local file headers (scheduler.py, completion/serving.py, sampling_params.py, spec_decode/metrics.py, envs.py, multiproc_executor.py). Those copies are in `D:/DevCache/Temp/claude/d--ARC-AGI-2/1c6db7aa-c78b-4b3a-b97a-5c67187fe52f/scratchpad/vllmsrc/`. Nothing was executed. "Verified" means I read it in the code or the vLLM source. "UNVERIFIED" means it depends on runtime behaviour I could not check.

None of the paths below crashes the notebook. Every exception inside an arm is caught, and the report cell handles skipped arms. The real risks are wasted time, the 2 x TP2 reserve being eaten, and measurements or verdicts that are biased or wrong.

---

## Findings

### F1. The 2 x TP2 reserve and the per-arm cap only apply at launch. After launch, an arm can run into the reserve. Wrong result (2 x TP2 skipped or cut short), medium-high
- Where: cell6.py:9-10 (`left = HARD_STOP - now - VMS_RESERVE - 8 min`, needs at least 12 min), :23 (`wait_ready(min(30 min, left))`), :105 and :134 (`t_end` only decides whether the long window starts), cell5.py:177 and :183 (vms_window only checks against `HARD_STOP`).
- Scenario: an arm passes the launch check with about 55 min left (reserve 35 + 8 + 12). After it is ready, the A/A or gate greedy runs with no deadline. Then the short window can wait up to 900 s for the level, plus 75 s. Then the long window starts if `t_end` has not passed and can wait another 900 s, plus 75 s. That is about 35 min after ready, on top of a launch of up to `left`. The slow case is realistic: a KV-bound arm (`fp8_mtp3_s24` / `s20` with 40k prompts) never reaches its level and waits the full 900 s (see F3). `tp2x2_fp8_mtp3` then finds less than 20 min left and is skipped, or launches with about 12 min and loses its windows (vms_window returns `skipped: deadline`).
- Fix: give each arm one deadline and pass it down:
  `arm_dl = min(time.perf_counter() + cap, HARD_STOP - VMS_RESERVE)` after ready, then `vms_window(..., deadline=arm_dl)`. Inside, use `deadline` in place of `HARD_STOP` in lines 177 and 183. Skip the long window when `arm_dl - now < 75 + 180`. Run the gate greedy only when `arm_dl - now > 5 min`.

### F2. `left` is computed before the old server is killed and the GPUs are polled, so the ready deadline slips by up to 4 min. Minor (can overrun)
- Where: cell6.py:9 (left), :14-18 (`kill()` waits up to 60 s, `_e11_gpu_free()` up to 180 s), :23 (`wait_ready` counts from `srv.t0`, which is set after those calls).
- Scenario: the last arm (reserve 0) can become ready at HARD_STOP - 4 min instead of HARD_STOP - 8 min. The ungated greedy (about 2 min) then ends close to HARD_STOP. The windows are skipped correctly.
- Fix: recompute `left` right before `srv.start()`. Also store the `_e11_gpu_free()` result in `rec["gpu_free"]`; it is thrown away now, so a launch that fails because a previous server still holds memory leaves no reason in the record.

### F3. vms_window: a dead server or a KV plateau burns 900 s and produces nothing. Wrong result / time, medium
- Where: cell5.py:183-200.
- Dead server: `vms_prom()` failures become `run = 0` (line 186-187) and the loop keeps polling up to 900 s. This happens when a server dies of OOM in the short window and the long window is still started, or when it dies while the level is filling. `VMS_SERVER.alive()` is never checked.
- KV-bound arm: if the KV pool cannot hold `level` sequences, `running` stays flat at the capacity, `num_requests_waiting > 0`, and `best < level - 1`. After 900 s the result is `error: never ran N` and no throughput at the plateau, which is exactly the number an s20 / s24 arm should report. Meanwhile, early streams can reach `max_tokens=8192` and finish during the 900 s wait (at about 20 tok/s each, 8192 tokens is about 410 s), so `running` even goes down.
- `measured_level` is the peak (`best`, line 188 and 193-194), not the level when the window starts. If the peak was level-1 and running then dropped, the window is labelled with a higher level than it measured. `running_mean` shows the truth, but the report's "streams" column shows `measured_level`.
- Fix: in the loop, `if VMS_SERVER is None or not VMS_SERVER.alive(): out["error"] = "server died"; stop gens; return`. Read `vllm:num_requests_waiting` too. If `running` is unchanged for about 30 s while `waiting > 0`, accept the plateau (`got = run`, `out["plateau"] = True`). Set `measured_level` to `run` at the moment `p0` is taken.

### F4. The window starts while the last admitted requests are still in chunked prefill, so tok/s is biased low, worst for the no-prefix arms. Wrong result, medium (verified in the scheduler)
- Where: cell5.py:189-191 and 201.
- Verified: vLLM 0.32.0 counts `num_requests_running = len(self.running)` (scheduler.py:2608-2610). A waiting request joins `self.running` as soon as its first prefill chunk is scheduled (scheduler.py:1169 `num_new_tokens = min(num_new_tokens, request_token_budget)`, then :1345 `self.running.append(request)`). So `run >= level` happens when the last request has started its prefill, not finished it.
- Scenario: long window, 40k-token prompts, `--max-num-batched-tokens 4096`. The last request still has about 9 chunks of 4096 to prefill inside the 75-s window, and every decode step shares a batch with them. The prefix-on arms reuse the shared 36k system block from the prefix cache (cell6.py:170-172 build all `_L` prompts on the same `_block`), so their leftover prefill is only the task part. The prefix-off arms (`fp8_target_only_noprefix`, `fp8_mtp3_noprefix`) prefill the full 40k. The 40k "prefix on vs off" comparison therefore mixes prefill into decode tok/s.
- Fix: after reaching the level, keep polling until `vllm:prompt_tokens_total` does not change between two polls 2 s apart and `vllm:num_requests_waiting == 0`, with a timeout. Only then take `p0`. Also record `prompt_tokens_total` delta inside the window (`p1 - p0`) so leftover prefill shows up in the record.

### F5. DP=2: `kv_max` adds up the two engines' `kv_cache_usage_perc`. Wrong result, minor (verified)
- Where: cell5.py:124-127 (vms_prom sums every label set of a metric name), :208.
- Verified: 0.32.0 labels every scheduler gauge with `["model_name", "engine"]` (metrics/loggers.py:499-504, :620-623). Adding up is right for `num_requests_running` and the counters, but `vllm:kv_cache_usage_perc` for the 2 x TP2 arms is the sum of two fractions, which can reach 2.0. `vllm:gpu_cache_usage_perc` no longer exists in 0.32.0 (only `kv_cache_usage_perc` is registered), so the second name on line 208 adds nothing.
- Fix: have vms_prom also return the per-series values, e.g. `out_max[name] = max(...)`, and use the max for `kv_cache_usage_perc`. Likewise cell6.py:26-29: `m[-1]` keeps only one engine's "GPU KV cache size" and "Maximum concurrency" line under DP. Store the whole `findall` list.

### F6. VGen ignores error events inside the stream. Wrong result, minor (verified)
- Where: cell5.py:157-161.
- Verified: on a mid-stream failure, vLLM 0.32.0 sends `data: {"error": ...}` and then `data: [DONE]` (entrypoints/openai/completion/serving.py:497-503). VGen reads `d.get("choices") or []`, finds nothing, and leaves `self.err = None`. So `stream_errors` stays 0 for a stream the engine failed, and a greedy row is just shorter or empty text, which is then counted as a "text difference" rather than an error.
- Fix: `if d.get("error"): self.err = json.dumps(d["error"])[:200]; break`. Also keep the last `finish_reason` (`c.get("finish_reason")`) so `abort` and `length` can be told apart.

### F7. VGen.stop() can block the main thread: `HTTPResponse.close()` waits for the reader thread's buffered lock. Can overrun, minor (UNVERIFIED by execution)
- Where: cell5.py:166-172, called from :197-198 and :212-213.
- Mechanism (from CPython semantics, not executed here): urllib's response `fp` is a `BufferedReader`. `BufferedReader.close()` takes the same lock that `readline()` holds while it waits for the socket. A stream that has no bytes coming (a request still queued, waiting for its first token, or a stalled engine) makes `stop()` wait until one byte arrives, or until the 3600-s socket timeout (`urlopen(..., timeout=3600)`, line 152).
- Normal case: stops run in submission order, so the earlier, running streams are aborted first and free capacity. The queued request is then scheduled and sends its first token after one prefill (seconds to tens of seconds). This affects `got = level - 1` and the `got is None` path. A stalled-but-alive engine could block up to 1 h per window. vLLM 0.32.0 lowers that risk: `VLLM_EXECUTE_MODEL_TIMEOUT_SECONDS=300` (envs.py:1872; multiproc_executor.py:349-379) kills a hung step.
- Fix: close the connection without the buffered lock, e.g. keep the socket (`self._sock = self._resp.fp.raw._sock` right after `urlopen`) and in `stop()` call `self._sock.shutdown(socket.SHUT_RDWR)` before `close()`. A shorter read timeout (e.g. 600 s) also caps the worst case.

### F8. vms_greedy joins one thread at a time, with no deadline. Can overrun, minor
- Where: cell5.py:228-239.
- Scenario: `concurrent=True` calls `join(900)` on each of 12 threads in turn, so a stalled server costs up to 12 x 900 s. The serial run costs up to 6 x 900 s. `vms_aa` (cell6.py:80-84) runs four of these, and none checks `HARD_STOP` or the reserve. A dead server is fine (connection refused or reset ends each thread quickly). The 300-s execute timeout above also limits this.
- Fix: `dl = min(time.perf_counter() + 900, deadline)`, then `g.join(max(0, dl - time.perf_counter()))`. Record unfinished threads as errors (`g.is_alive()`), and pass the arm deadline from F1.

### F9. vms_window does not stop its streams when `p0` or `p1` raise. Minor
- Where: cell5.py:201 and :211 (outside any try). The exception is caught in cell6.py:137-138.
- Scenario: `/metrics` times out (15 s, line 119) or the server dies. The arm records `error` but loses the short window it had already measured (`a["short"]` is never assigned). If the server is still alive, up to 16 x 8192-token streams keep generating until the next launch kills it. If this happens in the short window, the long window never runs either.
- Fix: wrap the body in `try: ... finally: for g in gens: g.stop()`, and on a failed `p1` return `out` with `error` instead of raising.

### F10. The oracle switch can FAIL every MTP arm, the production reference included, and the candidates' rows are never saved. Wrong verdict, medium (UNVERIFIED that it happens)
- Where: cell6.py:114-125 (switch), :87-97 (judge), :129-130.
- Logic checked (correct as written): the oracle's rows replace VMS_REF. The reference is judged from `VMS_ROWS["ref_fp8_mtp3_s16"]` (its first serial and concurrent passes), and its `gate` is overwritten in `VMS["arms"]`, which already exists because the reference arm finished earlier.
- Risk: the tolerance is the oracle's own A/A (+1 of 6 serial, +2 of 12 concurrent). That A/A does not cover the systematic numerical difference between speculative verification (k+1-token verify forward, prefill-style attention, different GEMM M-bucket) and 1-token target-only decode. Prefix-on candidates' concurrent pass also hits the cache for prompts 0-5, which the prefix-off oracle never does. If 256-token greedy outputs drift on 2 or more of 6 prompts, every MTP arm FAILs, including `ref_vs_oracle`, and the gate no longer tells arms apart.
- Also: `s` and `c` (cell6.py:129) are only reduced to counts, and `VMS_ROWS` is never written to disk, so nothing can be re-judged afterwards.
- Fix (small): `VMS_ROWS[name] = {"serial_a": s, "conc_a": c}`. Additionally judge against the reference's rows when they exist (`a["gate_vs_ref"] = vms_judge(s, c, VMS_ROWS["ref_fp8_mtp3_s16"])[0]`). Dump `VMS_ROWS` to `VMS_DIR / "greedy_rows.json"` in e14_save or cell 7. Report both verdicts.

### F11. The reference's A/A is never checked for usability. Wrong verdict, minor
- Where: cell6.py:111-113 compared with the oracle check at :114.
- Scenario: the reference server returns errors or empty text for the greedy requests (F6), and the oracle is unusable or its launch failed. VMS_REF then holds empty rows: `aa_serial = 0` (empty == empty), `aa_degenerate = 18`, every candidate FAILs on text and passes on degenerate output, and `gate_reference` (line 179) still names the reference. The `setdefault` text also says "the oracle A/A was not usable" when the oracle actually failed to launch or raised.
- Fix: run the same `aa["degenerate"] == 0 and all(...)` check for `gate == "ref"`. Only fill VMS_REF if it passes, otherwise `a["gate"] = "reference unusable"`. Set `gate_reference` explicitly for each outcome.

### F12. INT4 MTP static check: a partly packed MTP with dense linears that are not ignored passes as OK. Wrong result (wasted launches), minor-medium
- Where: cell6.py:66: `out["ok"] = bool(mtp) and (bool(packed) or not not_ign)`.
- Scenario: the MTP layers are stored quantized (`weight_packed` present) but a dense linear such as `mtp.fc.weight` is not in `ignore`. The check returns OK, yet that module would still be built quantized (the #58807 crash). The `int4_mtp3_s16`, `int4_mtp3_s20` and `tp2x2_int4_mtp3` launches would then each fail at load, costing a launch timeout's worth of minutes apiece.
- Fix: `out["ok"] = bool(mtp) and not not_ign`. A dense linear needs an ignore entry whether or not other MTP weights are packed. Keep `packed` for information only.

### F13. When the static check fails, `tp2x2_int4_mtp3` leaves no record. Minor
- Where: cell6.py:208-209. The PLAN loop (:199-202) records skipped INT4 arms, but the last INT4 arm is just left out of `VMS["arms"]` / `order`, so the report does not show it.
- Fix: an `else:` branch that records `{"ok": False, "skipped": "INT4 MTP static check failed: ..."}` and appends it to `order`.

### F14. The report hides why an arm failed. Minor
- Where: cell7.py:26 shows `log_errors or skipped`. `a["error"]` (exceptions), the launch `why` (cell6.py:24, kept only in `VMS["launches"]`), window `error` / `skipped` and `gate_detail` never appear. `ok` is True even when both windows were skipped or failed (cell6.py:136).
- Fix: copy `rec["why"]` into `a["launch_why"]` in vms_arm. In the table, show `a.get("error") or a.get("launch_why") if not ok`, plus `(a.get("short") or {}).get("error") or .get("skipped")`. Set `a["ok"] = bool(a.get("short_tok_s"))`.

### F15. `kill()` sends SIGKILL to the whole group straight away. Minor (UNVERIFIED impact)
- Where: cell5.py:102-115.
- SIGKILL skips vLLM's shutdown: the shared-memory broadcast segments (`/dev/shm/psm_*`) and their resource tracker die with the group without unlinking, and NCCL gets no teardown. Over about 15 launches the leftover /dev/shm could add up (size not checked). `log_f` is never closed (one fd per arm, harmless).
- Fix: `killpg(SIGTERM)`, `wait(30)`, then `killpg(SIGKILL)`. Close `log_f`. Optionally remove stale `/dev/shm/psm_*` before the next launch.

### F16. DP=2 starts two API servers by default. Note (verified), risk UNVERIFIED
- Verified: with internal load balancing, `api_server_count` defaults to `data_parallel_size` (entrypoints/cli/serve.py:107-130). That turns on multiprocess Prometheus (`setup_multiprocess_prometheus`, serve.py:283). The gauges use `multiprocess_mode="mostrecent"` (loggers.py:530, :622) and counters add up across processes, so summing in F5 is still right for running and the counters. Scheduler stats go to only one front-end per step (scheduler.py:2417-2422), and that is also fine once summed.
- Risk: each API server balances only its own share of the 16 requests (core_client.py:1642-1697, score `max(client_count x own inflight, snapshot)`). A 9/7 split over the 8-seq ranks gives 15 running = level - 1, which is accepted. A worse split would give the "never ran 16" error for the main 2 x TP2 arm.
- Fix (optional): add `--api-server-count 1` to the DP arms (one balancer, single-process metrics), or accept the plateau as in F3.

### F17. Dead code. Trivial
- cell6.py:132: `lv = level if not ... else level` gives the same value either way. cell6.py:6: `force` is never passed. cell6.py:131: `if True:`.

### Outside my scope, but it affects cell 6 launch time
- cell2.py:19-27 (and cell1b.py:67 `read_probe`) read `SGL_MODEL_PATH` (INT4) and `SGL_DRAFT_PATH` (DFlash2), because `ENGINE_BACKEND` defaults to "sglang" (cell1.py:204). VMS launches FP8 `MODEL_PATH` first, straight from /kaggle/input with no prefetch. The background `cat` of INT4 plus DFlash2 (the latter unused by VMS) competes with the first FP8 load over GCSFUSE, which has already pushed launches toward the 30-min timeout (cell6.py:23). Suggest prefetching `MODEL_PATH` first when `VMS_ON`, and dropping the DFlash2 read.

---

## Checked, no issue
- Install failure (missing installer, rc != 0, missing `VENV_PYTHON=` / `CUDA_HOME=` causing a KeyError, the 2400-s timeout): all caught at cell5.py:279-285. Cell 6 then takes the `else` branch (:212-214) and cell 7 still writes a report. The installer does print both keys (build_vllm_wheelhouse.py:174-175).
- Launch timeout or early exit: `srv.kill()`, `log_tail` saved, `VMS_SERVER` stays None, the next arm runs (cell6.py:31-36). An arm skipped by the reserve returns before touching the running server; the next real launch or cell 7 (:47-51) kills it.
- No uncaught exception in an arm: everything after a successful launch is inside `try/except BaseException` (cell6.py:106-138). `vms_launch` can only raise from `Popen` (missing launcher), which cannot happen after a successful install.
- The oracle check runs only when `gate in ("ref", "oracle")`; `True` and `False` do not match those strings. `gate=False` arms still get the greedy comparison, marked as `"diagnostic"`.
- vms_judge compares like with like: candidate serial and concurrent rows against the base `serial_a` / `conc_a`, the tolerance from the base's own A/A, and degenerate counts over the same 6 + 12 texts.
- The "measure even on FAIL" path always runs the windows. A FAIL only changes `gate`.
- vms_window cannot overrun HARD_STOP on its own: start check `secs + 180`, wait limit `HARD_STOP - now - secs - 120` (at least 60 s), 75-s window, prom calls with a 15-s timeout. It does overrun the reserve; see F1.
- Prometheus parsing: the regex handles labels and trailing timestamps. Label values containing `}` skip the line harmlessly. `_total` and `_created` are separate names. All metric names used exist in 0.32.0: `vllm:num_requests_running`, `vllm:kv_cache_usage_perc`, `vllm:generation_tokens(_total)`, `vllm:num_preemptions(_total)`, `vllm:spec_decode_num_drafts(_total)`, `vllm:spec_decode_num_accepted_tokens(_total)` (loggers.py:528, 620, 739, 799; spec_decode/metrics.py:40-42). `accept = 1 + accepted / drafts` is the mean acceptance length.
- SSE parsing: vLLM sends `data: {...}\n\n` and `data: [DONE]\n\n` (completion/serving.py:272-273, 443, 503). Line iteration over the chunked response, `startswith(b"data:")` and `json.loads(bytes)` are correct. The only gap is F6.
- Greedy request parameters: `top_k=-1` is accepted (`top_k < -1` is the rejected case, sampling_params.py:678), and temperature 0 forces greedy (`top_p=1`, `top_k=0`, :612-616). `ignore_eos` and token-id prompts are accepted.
- Report cell with skipped arms (`{"ok", "skipped"}` only): every access uses `.get` or `(... or {})`, `f(None)` gives "—", `xr` handles 0 and None, kernels default to `[]`. `order` and `arms` always match (cell6.py:144-145, :200-201). The whole cell is in `try/except BaseException`, and the final server kill runs either way.
- e14_save: everything put into VMS is JSON-safe (strings, numbers, lists, dicts; `env` is excluded from `install`).
- Rerun mode: `VMS_ON` is False, cell 6 records `skipped: rerun`, and cell 7 writes an empty table and the bundle.
