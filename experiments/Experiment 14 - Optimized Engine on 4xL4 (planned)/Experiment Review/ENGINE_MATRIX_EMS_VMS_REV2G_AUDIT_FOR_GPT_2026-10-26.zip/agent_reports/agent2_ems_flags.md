# EMS (Q27-XHIGH-EMS_ENGINE_MATRIX_SGLANG) flag audit vs SGLang 0.5.21 source — agent 2 (2026-10-26)

The agent could not write files (subagent harness rule), so the coordinator saved its returned report here. Sections 1-4 are reproduced verbatim. Section 5 holds the reconstructed command lines; it is the agent's own `cmds.txt`, copied next to this file as `agent2_ems_commands.txt`, with its rebuild script `agent2_recon2.py`.

Scope: every arm of cell7 plus the reference (the production launch from cell6), checked against `D:/ARC AGI 2/_scratch/session_1c6db7aa/sgl_src/src/sglang`. Earlier Kaggle logs were used as hard evidence where the exact pattern already ran on this stack:
- E15B R3K1 `sglang_server_try0.log`: the reference command, the full resolved server_args and the memory lines.
- E11-03 rev3b `server_B_int4_mtp_try0.log`: INT4 + EAGLE MTP 3/1/4, draft path = target dir, extra_buffer, fp32 SSM, ratio 0.9.
- E14A SLIM R2: target_only, width 4 / 6 / 8 relaunches, and `nccl_bench.json` (P2P).

Numbers marked "estimate" are derived from those logs. UNVERIFIED marks what is not provable from source or logs.

## 1. Summary

In the normal path every arm passes 0.5.21 flag parsing and server-arg validation: every flag name exists, every value is accepted, and nothing conflicts. The problems are capacity and timing.

| # | Severity | Arm(s) | What happens |
|---|---|---|---|
| F1 | HIGH | ntn_int4, ntn_fp8 | The mamba state cache caps concurrency at ~11 (INT4) / ~9 (FP8) instead of 17, so the arms are measured at 10 / ~8 client streams vs the reference's 16 |
| F2 | HIGH | tp2x2_dflash_w6, tp2x2_best-MTP | ~115-150k KV tokens per replica (estimate) vs 852k at TP4; cannot hold 8 streams x 50k; the short-band tok/s sum is not an adoption basis |
| F3 | MEDIUM | tp2x2_* | At world size 2 on PCIe the legacy CustomAllreduce turns on if the P2P test passes. On this VM P2P/IPC measured 5.5x slower than the NCCL baseline (E14A), so TP2 results may include a slow all-reduce |
| F4 | MEDIUM | ntn_fp8 | FP8 is not staged; it is read from /kaggle/input (GCSFUSE) under a hard 20-min relaunch limit, so a timeout is possible (UNVERIFIED) |
| F5 | MEDIUM-LOW | tp2x2_* | Two cold servers with new TP2 per-GPU shapes compile at once, under a hard 20-min wall with no stall rule (UNVERIFIED) |
| F6 | LOW | ntn_* | `--attention-backend flashinfer` and `--linear-attn-backend triton` equal what the reference already resolves to; `--max-prefill-tokens 4096` is moot under chunk 2048 |
| F7 | LOW (conditional) | dflash_w8, dflash_w6_s20/s24, the reference label | In the W1 fallback, dflash_w8 = the reference (a wasted launch) and the label "w6_s16" is wrong; in the streams12 fallback, s20/s24 will almost certainly fail |
| F8 | INFO | mtp_3_1_4_mem86 | ~0.65 GB less headroom after graph capture. The reference already late-loaded a kernel at 0.83 GiB free; it probably starts, runtime OOM is a risk (UNVERIFIED) |

Verified OK (details in section 3):
- EAGLE MTP with the draft path = the target dir, and the alias resolution.
- Draft quantization inheritance, and the 3/1/4 and 2/1/3 width rules.
- DFlash widths 4 / 6 / 8, and the `--min-free-slots-delay` handling in every arm.
- ReplaySSM-spec startup checks with extra_buffer_lazy at fp16 and fp32.
- target_only; the s20 / s24 graph lists and mamba sizing; TP2 port, IPC and shm isolation.

## 2. Findings

### F1 (HIGH, capped concurrency): ntn_int4 / ntn_fp8 are mamba-capped well below 17

- **Flags:**
  - `_ntn_drop` removes `--max-mamba-cache-size`.
  - `_NTN` sets `extra_buffer`, `float32` and ratio `0.5`, with EAGLE 3/1/4 (D = 4).
  - `--max-running-requests 17` is kept.
- **Source:**
  - `srt/mem_cache/kv_cache_configurator.py:2232-2261`: base 3 + 2 for extra_buffer with the overlap scheduler on (L179-184) = **5 slots per request**.
  - `:2505-2545`: K = `(budget - per_req*(1+D)) // (per_req*(1+D/ratio))` with budget = rest x ratio_mem / (1 + ratio_mem), i.e. rest / 3 at 0.5.
  - `:2292-2330`: `max_num_reqs = min(mrr, K // ratio)`, logged as "max_running_requests is capped to N by the mamba state cache".
  - No arm disables overlap (`srt/arg_groups/overrides.py:452-460`).
- **Numbers (estimate):**
  - INT4 + BF16 MTP leaves 15.63 GB/GPU (E11-03 B L99); pre-load 21.72 GB (R3K1 L54). Slack at mem 0.83 = 3.69 GB, so rest = 11.94 GB.
  - fp32 per slot = 35.9 MB (E11-03 B L108).
  - Budget 3.98 GB → K ≈ 58 → cap **11**. The formula reproduces E11-03 B (mem 0.6187, ratio 0.9 → cap 10, K = 50) within ~2 %.
  - FP8: rest ≈ 9.6 GB → K ≈ 46 → cap **~9** (UNVERIFIED: no SGLang FP8 load on record).
- **What happens:** the server starts; `_level()` runs the windows at capped_to - 1 = 10 / ~8 and `capped=True`. The arms are not comparable with 16 streams and also get more KV per stream (~1.0M tokens INT4).
- **Minimal fix:** put `"--max-mamba-cache-size": 85` (5 x 17) into `_NTN` and remove it from `_ntn_drop`. Once a size is given the ratio is ignored (`:2462-2484`); estimated KV is ~780k INT4 / ~490k FP8, and both start. Even the default ratio 0.9 gives only K ≈ 84 → 16. Or keep the exact sizing and report "competitor config at its own concurrency".

### F2 (HIGH, capacity): 2 x TP2 has far less KV per replica than production needs

- **Flags:** TP2, mrr 9, graphs 1..9, mamba 36, mem 0.83, DFlash W6.
- **Why:**
  - Per GPU, weights grow from INT4 4.62 + DFlash2 1.49 GB (TP4) to ~8.4-9.2 + ~3.0 GB (TP2), leaving ~9.5-10.3 GB free; rest ≈ 5.8-6.6 GB after the 3.69 GB slack.
  - Mamba per slot doubles (36.6 MB fp16): the state is 37 x 36.6 MB = 1.35 GB, the intermediate (9+1) x 6 x ~35 MB = 2.1 GB (`:2462-2484`), so ~2.4-3.2 GB is left for KV.
  - KV per token roughly doubles (target 7.63 KB + draft 2.4 KB at TP4, R3K1 L116/L120) to ~20 KB at TP2.
  - Result: **~115-150k KV tokens per replica** (estimate, UNVERIFIED).
- **What happens:** both replicas start, `long_per = min(8, kv // 45000)` = 2-3, and the 8+8 short band fits and looks fast. But production needs ~800k (16 x 50k) and 2 x TP2 holds ~230-300k, so it cannot be adopted for production, while it uses the 30-min slot.
- **Minimal fix:** record and gate on `kv_tokens_per_replica >= per * SGL_KV_PER_REQUEST`; mark the arm "diagnostic only" if that fails, or drop the slot.

### F3 (MEDIUM): TP2 custom all-reduce on PCIe

- **Source:**
  - `dispatch_custom_allreduce` tries V2 first (`custom_all_reduce.py:344-369`); V2 needs `full_nvlink` (`custom_all_reduce_v2.py:482-497`), so the L4 falls back to the legacy CustomAllreduce.
  - The legacy init refuses only world_size > 2 without NVLink (`custom_all_reduce_utils.py:492-498`). At world size 2 it runs the P2P test (L504-510) and enables custom AR if the test passes.
  - `should_custom_ar` then serves every all-reduce up to 8 MB (`custom_all_reduce.py:270-275`).
- **Platform evidence:** E14A `nccl_bench.json`: `p2p_sys` (P2P/IPC) 1880 us/call, 0.42 GB/s vs baseline 344 us, 4.9 GB/s, so P2P works but is ~5.5x slower.
- **Minimal fix:** add `--disable-custom-all-reduce` to the TP2 dict, or run TP2 both ways if the slot allows.
- **Separate idea:** 0.5.21's opt-in FlashInfer PCIe-IPC all-reduce `SGLANG_ENABLE_PCIE_IPC_ALLREDUCE=1` (`pcie_ipc_ar.py:98-114`; world 2 / 4 / 8) as a TP4 arm. Whether this FlashInfer 0.6.18 build ships `pcie_ipc_comm`, and whether it beats NCCL on L4, is UNVERIFIED.

### F4 (MEDIUM, startup): ntn_fp8 reads FP8 from /kaggle/input under a 20-min limit

- cell2 L74 stages only INT4 + the drafter, and `e14_launch` waits `min(SGL_RELAUNCH_TIMEOUT_SEC = 20 min, room)`.
- An INT4 load from /kaggle/input once took ~1,197 s, so a timeout is plausible (UNVERIFIED).
- **Fix:** stage MODEL_PATH (if RAM allows), or a 30-min limit for this arm, or pre-read the FP8 shards in the background.

### F5 (MEDIUM-LOW, launch time): 2 x TP2 cold compile under a hard 20-min wall

- First TP4 launches spent 372-388 s in "Capture target verify CUDA graph"; warm relaunches took 6-9 s.
- TP2 changes every per-GPU shape, so the copied cache is mostly cold, and both replicas compile at once (`MAX_JOBS=4` each).
- **Fix:** StallMonitor per replica, or a staggered start, or a 30-min wall.

### F6 (LOW, no-op flags): NTN flags that change nothing

- The R3K1 reference already resolves to attention flashinfer and linear triton (the field default is "triton").
- `--max-prefill-tokens 4096` with chunk 2048: PrefillAdder charges both budgets (`schedule_policy.py:905-917`) and stops when either is exhausted (`:859-866`), so it is moot (corner cases UNVERIFIED).
- The real NTN differences vs mtp_3_1_4 are: the checkpoint (FP8 arm), chunk 2048, extra_buffer, fp32 SSM, and the auto mamba size (F1).

### F7 (LOW, conditional): fallback paths make arms identical or doomed

- **W1 fallback:**
  - The reference becomes width 8, `--cuda-graph-max-bs-decode 16`, no delay flag, so dflash_w8 is identical to it (a wasted launch) and the label is wrong.
  - The default delayer turns on in every DFlash arm: min(4, max(2, 22 // 6)) = 3 at mrr 17 (`min_free_slots_delayer.py:20-22`).
  - An explicit `--cuda-graph-bs-decode` wins over max_bs (`memory_hook.py:190-197`).
- **streams12 fallback:** s20 / s24 will very likely fail (~2 x 20 min).
- **Fix:** read the reference width and mrr from `E11_SGL["launch_flags"]`; skip dflash_wN when N = the reference width; skip s20 / s24 under streams12; build the reference label from the real flags.

### F8 (INFO): mtp_3_1_4_mem86 headroom

- Slack = `pre_model_load*(1-mem_fraction_static)` (`kv_cache_configurator.py:2194`), so 0.83 → 0.86 moves ~0.65 GB/GPU into KV.
- The reference ended at available_gpu_mem 1.31 GB and late-loaded `_fused_mamba_state_scatter_with_mask_kernel` at 0.83 GiB free (R3K1 L182, L245).
- MTP verify / draft graphs are smaller than DFlash's (E11-03 B verify graph 0.32 GB), so startup is likely fine; a 4096-token prefill under 16 streams could OOM (UNVERIFIED).

## 3. Per-arm verification

**Flag mechanics**
- Every flag is a dataclass field exposed through `add_cli_args_from_dataclass` (`srt/arg_groups/arg_utils.py:336-417`).
- Booleans are `store_true` (L393-399) and are passed bare.
- `List[int]` fields are `nargs="+"`, `type=int` (L371-391), so `--cuda-graph-bs-decode 1 2 ... 17` is correct.
- The edit helper skips values up to the next `--`, and no value starts with `--`. The rebuilt argv has no duplicate or dangling flags.

**Choices checked**
- `--schedule-policy lpm` (`fields/schedule.py:82-97`).
- `--mamba-radix-cache-strategy` in {auto, no_buffer, extra_buffer, extra_buffer_lazy} (`fields/exec_.py:385-392`).
- `--mamba-ssm-dtype` in {float32, bfloat16, float16} (`:363-369`).
- `--speculative-draft-model-quantization unquant` (`choices.py:64`; it resolves to None, explicitly set).
- `--kv-cache-dtype fp8_e4m3`, attention flashinfer, linear triton.

| Arm | Delta vs reference | Verification | Mamba cap | Result |
|---|---|---|---|---|
| ref | — | DFLASH forces steps / topk to 1 (`speculative_hook.py:290-325`); width 6 ≠ block_size only warns (`dflash_worker_v2.py:480-490`); delay 1 disables the delayer (`min_free_slots_delayer.py:16-19`); lazy requires overlap (on); track interval 256 ≥ 6 | 68 // 4 = 17 | OK (R3K1) |
| target_only | drop spec + delay | E14A target_only log started with lazy, no spec | 17 | OK |
| mtp_3_1_4 | EAGLE, draft = INT4 dir, 3/1/4 | see "EAGLE MTP" below | 17; KV ≈ 1.16M (estimate) | OK; lazy + EAGLE has never run on our stack (runtime UNVERIFIED) |
| mtp_2_1_3 | 2/1/3 | 3 = 2 + 1, no auto-adjust (`speculative_hook.py:1144-1152`) | 17 | OK |
| mtp_3_1_4_mem86 | mem 0.86 | accepted | 17 | starts; F8 |
| mtp_replay_fp16 | `--enable-linear-replayssm-spec` | `attention_hook.py:361-440` all OK; the extra_buffer ban (L320-338) applies only to the decode ReplaySSM; fp16 warns; pool gets replayssm buffers (`memory_pool.py:660-760, 933-947`); intermediate skipped (L774-777); commit handles track indices (`spec_utils.py:985-1058`) | explicit 68, no intermediate reserve under replay; ring ~6 MB/req x 18 | startup OK; numerics / speed UNVERIFIED |
| mtp_replay_fp32 | + fp32 | recommended dtype (L421-427) | 69 x 35.9 MB = 2.48 GB; 17 | startup OK |
| ntn_int4 | F1 | extra_buffer works for Qwen3_5 (E11-03 B); chunk 2048 ≥ mamba_cache_chunk_size | ~58 // 5 = **11** | capped (F1) |
| ntn_fp8 | F1 + FP8 model / draft | Fp8Config needs capability 80 (`fp8.py:318-328`); block-128 on SM89 → `triton_w8a8_block_fp8_linear` (`fp8_utils.py:930-958`); MTP layers carry `weight_scale_inv`; mtp.fc is nn.Linear (`qwen3_5_mtp.py:128`) in modules_to_not_convert; draft quant inherits fp8 (`serving_hook.py:621-631`) | ~46 // 5 = **~9** | starts (UNVERIFIED), capped, slow load (F4) |
| dflash_w6_s20 | mrr 21, graphs 1..21, mamba 84 | explicit list wins (`memory_hook.py:190-197`), clamped to the pool (`base_cuda_graph_runner.py:64-97`) | 21; KV ≈ 780k | OK |
| dflash_w6_s24 | mrr 25, graphs 1..25, mamba 100 | same | 25; KV ≈ 710k | OK |
| best-MTP_s20 | MTP + streams 20 | same | 21 | OK |
| dflash_w4 / w8 | width 4 / 8 | E14A ran both | 17 | OK (w8 wasted only in the W1 fallback) |
| tp2x2_* | TP2, ports, mrr 9, graphs 1..9, mamba 36 | see below | 9 | starts; F2 / F3 / F5 |

**EAGLE MTP with draft = target dir**
- NEXTN / EAGLE → "EAGLE"; only Gemma4 becomes FROZEN_KV_MTP (`speculative_hook.py:108-115`).
- A draft `Qwen3_5ForConditionalGeneration` is rewritten to `Qwen3_5ForCausalLMMTP` with `num_nextn_predict_layers=1` (`srt/configs/model_config.py:981-1003`).
- Qwen3_5 is not in the auto-fill list (`speculative_hook.py:1008-1023`), so passing the target dir is required and correct.
- Draft quant inherits compressed-tensors, with the BF16 MTP layers falling back to UnquantizedLinearMethod. This exact pattern ran in E11-03 B.
- 3/1/4 and 2/1/3 satisfy `num_draft_tokens = steps + 1`.
- Dropping `--speculative-draft-model-quantization unquant` for MTP is correct.

**--min-free-slots-delay:** DFlash arms keep 1 (disabled); MTP / NTN / target_only drop it (None for non-DFlash). No unintended delayer except in the W1 fallback.

**Mamba sizing:** 4 slots for lazy and 5 for extra_buffer (overlap on everywhere). Every explicit size is 4 x mrr, so none is capped; only the NTN arms are (F1). `e11_slots()` uses the same rule.

**2 x TP2 shared resources:**
- IPC tempfiles + `nccl_port` only (`server_args.py:709-719`).
- shm_broadcast ZMQ ports bind randomly unless `SGLANG_PORT` is set (`shm_broadcast.py:213-222`).
- The Prometheus multiprocess dir is a per-process TemporaryDirectory (`common.py:2658-2673`).
- The P2P cache file is keyed by CUDA_VISIBLE_DEVICES under each replica's SGLANG_CACHE_DIR (`custom_all_reduce_utils.py:249-270`).
- `grpc_port` is used only in gRPC mode; graph batch alignment is 1; the physical GPU id comes from CUDA_VISIBLE_DEVICES with PCI_BUS_ID.
- **No port / IPC / shm collision.** Small gap: the FlashInfer JIT workspace is not in `jit_cache_env()` (UNVERIFIED, low risk).
  - Coordinator note: SGLang's `third_party_cache_defaults()` sets `FLASHINFER_WORKSPACE_BASE` to SGLANG_CACHE_DIR with setdefault (environ.py:1963-1975), so it already follows each replica's own SGLANG_CACHE_DIR.

## 4. Context notes

- The lazy-extra-buffer + speculative prealloc fix "43567" exists in `src/e14_sglang_patches.py`, but no cell applies E14P. It affects the reference and every lazy spec arm equally, not target_only; impact on the parity gate is UNVERIFIED.
- E14A already measured DFlash widths 4 / 6 / 8 and target_only at 12 streams. EMS re-measures them at 16 streams, a different regime.

## 5. Reconstructed final command lines

See `agent2_ems_commands.txt` (the agent's `cmds.txt`): every arm's full `python -m sglang.launch_server` line in the normal path, plus the W1 and streams12 fallback bases.
