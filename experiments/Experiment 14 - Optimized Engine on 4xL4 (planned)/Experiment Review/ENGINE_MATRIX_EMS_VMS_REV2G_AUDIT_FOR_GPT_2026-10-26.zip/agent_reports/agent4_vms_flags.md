# VMS vLLM 0.32.0 flag audit (agent 4): `Q27-XHIGH-VMS_ENGINE_MATRIX_VLLM.ipynb`, cells V1/V2

Scope: every `vllm serve` command built by `vms_flags()` (cell5.py:55-68) for the arms in cell6.py, checked against the vLLM **v0.32.0** source. Every file:line below is in `D:/ARC AGI 2/_scratch/vllm_whl/src032/` (path separators written as `_`; I fetched the extra files from the v0.32.0 tag). Read-only: no project file was edited and nothing ran on Kaggle.

## 0. Verdict

All flags exist in v0.32.0 with these spellings and values. No arm fails at argparse or config validation because of a flag.

There are five problems:

1. **`fp8_mtp3_lb_marlin` does nothing different from the reference.** On SM 8.9 the automatic choice for FP8 block-128 layers is already `MarlinFP8ScaledMMLinearKernel`, which is weight-only FP8 (W8A16). So the reference itself runs Marlin W8A16, not FP8 tensor-core W8A8.
2. `fp8_mtp3_lb_triton` is the only arm that runs real W8A8 FP8 (`TritonFp8BlockScaledMMKernel`).
3. The INT4 + MTP path is correct. The draft is built under prefix `mtp`, and `re:^mtp.*` exempts `mtp.fc`, the fused `qkv_proj` / `gate_up_proj` and the other MTP linears. #58807 is not a risk for this checkpoint.
4. In the DP2 x TP2 arms, `kv_max` and `kv_tokens` are recorded with the wrong meaning (a sum across engines, and one engine's value). `--disable-custom-all-reduce` only matters in these arms, where it may remove a lever.
5. `vms_kernels()` cannot see the `--linear-backend` fallback warnings.

## 1. The commands as reconstructed

Base: `/tmp/vllm-venv/bin/vllm serve`, then `vms_flags()` in order. SEED = 20261005 (cell1.py:140) and VMS_PORT = 8011.

**Reference `ref_fp8_mtp3_s16`:**
```
vllm serve <MODEL_PATH=FP8 repack> --tensor-parallel-size 4 --kv-cache-dtype fp8_e4m3 --max-model-len 106496
  --max-num-seqs 16 --max-num-batched-tokens 4096 --gpu-memory-utilization 0.9 --disable-custom-all-reduce
  --seed 20261005 --host 127.0.0.1 --port 8011 --served-model-name q27 --attention-backend FLASHINFER
  --trust-remote-code --enable-prefix-caching --speculative-config '{"method": "mtp", "num_speculative_tokens": 3}'
```

| Arm | Differences from the reference | Real change? |
|---|---|---|
| `fp8_target_only_noprefix` (oracle) | no `--speculative-config`; `--no-enable-prefix-caching` | yes (also switches mamba_cache_mode to `none`, see §5) |
| `fp8_mtp2` / `fp8_mtp4` | `num_speculative_tokens` 2 / 4 | yes (n_predict = 1 divides both: speculative.py:1490-1500) |
| `int4_mtp3_s16` | model = VMS_INT4 (RedHat compressed-tensors) | yes (Marlin W4A16, calibrated KV scales, see §3) |
| `fp8_mtp3_s20` / `_s24` | `--max-num-seqs 20` / `24` | yes |
| `int4_mtp3_s20` | INT4, `--max-num-seqs 20` | yes |
| `fp8_mtp3_ssm_fp16` | `+ --mamba-ssm-cache-dtype float16` | yes (default resolves to float32, see §5) |
| `fp8_mtp3_noprefix` | `--no-enable-prefix-caching` | yes |
| `fp8_mtp3_lb_marlin` | `+ --linear-backend marlin` | **NO: same kernel as the reference (F1)** |
| `fp8_mtp3_lb_triton` | `+ --linear-backend triton` | yes: Marlin W8A16 becomes Triton W8A8 block FP8 |
| `tp2x2_fp8_mtp3` | `--tensor-parallel-size 2 ... --data-parallel-size 2`, `--max-num-seqs 8` | yes (F4) |
| `tp2x2_int4_mtp3` | the same with INT4 | yes (F4) |

## 2. Each flag against v0.32.0 (item 1)

| Flag / value | v0.32.0 proof | Status |
|---|---|---|
| `--tensor-parallel-size` | standard ParallelConfig flag | OK |
| `--kv-cache-dtype fp8_e4m3` | arg_utils.py:1365; `CacheDType` literal includes `fp8_e4m3` (config/cache.py:39-44) | OK. FlashInfer lists `fp8_e4m3` (v1/attention/backends/flashinfer.py:448-453) |
| `--max-model-len 106496` | arg_utils.py:966 | OK. `max_position_embeddings` is 262144, so `VLLM_ALLOW_LONG_MAX_MODEL_LEN` is moot |
| `--max-num-seqs` | arg_utils.py:1717-1722 (scheduler, default None) | OK. Applies per engine under DP (F4) |
| `--max-num-batched-tokens 4096` | arg_utils.py:598 | OK. The hybrid block (~1.6k tokens, §5) is below 4096 |
| `--gpu-memory-utilization 0.9` | arg_utils.py:596 | OK |
| `--disable-custom-all-reduce` | arg_utils.py:1333-1336; bool, so BooleanOptionalAction (arg_utils.py:378-380) | OK. No-op at TP4 (F4c) |
| `--seed` | arg_utils.py:953 | OK |
| `--host` / `--port` | serve frontend | OK |
| `--served-model-name q27` | arg_utils.py:1006 | OK |
| `--attention-backend FLASHINFER` | arg_utils.py:1085-1087; parsed by `AttentionBackendEnum[value.upper()]` (config/attention.py:183-193), enum member at v1/attention/backends/registry.py:71 | OK. An explicit backend is validated and raises on failure, with no silent fallback (platforms/cuda.py:428-447). FlashInfer allows SM 8.0-12.1 and head 256 (flashinfer.py:566-579). Log line: `Using AttentionBackendEnum.FLASHINFER backend.` |
| `--trust-remote-code` | arg_utils.py:950 | OK. Has no effect because Qwen3.5 is built in |
| `--enable-prefix-caching` / `--no-enable-prefix-caching` | arg_utils.py:1369-1375 (default None), bool so `--no-` form exists (378-380) | OK. `--enable-` equals the hybrid default (§5) |
| `--speculative-config '{"method":"mtp","num_speculative_tokens":k}'` | arg_utils.py:1826-1829 (json.loads); `mtp` uses the target checkpoint (speculative.py:1147-1163); qwen3_5 and qwen3_5_text become `Qwen3_5MTP` with n_predict = `mtp_num_hidden_layers` = 1 (speculative.py:917-941) | OK |
| `--mamba-ssm-cache-dtype float16` | arg_utils.py:1395-1397; `MambaDType` literal (config/cache.py:62) | OK. Overrides float32 and logs a warning (models/config.py:868-878) |
| `--linear-backend marlin` / `triton` | arg_utils.py:1808-1810 (lowercases, `-` becomes `_`); literal at config/kernel.py:244-266; copied into KernelConfig only when not `auto` (arg_utils.py:2759-2760) | Accepted at startup, never rejected (F1) |
| `--data-parallel-size 2` | arg_utils.py:1209 (`-dp`) | OK. Dense model with internal LB is supported (F4) |

Environment variables (cell5.py:47-50 and cell1.py:201): `VLLM_ALLOW_LONG_MAX_MODEL_LEN`, `VLLM_NO_USAGE_STATS`, `VLLM_LOGGING_LEVEL`, `VLLM_CACHE_ROOT` and `VLLM_MEMORY_PROFILER_ESTIMATE_CUDAGRAPHS` all exist in envs.py. The last one already defaults to `"1"` in v0.32.0 (envs.py:2221-2223), so setting it changes nothing. `VLLM_TEST_FORCE_FP8_MARLIN` has 0 hits in envs.py, so dropping that arm was correct.

## 3. Findings

### F1 (HIGH): `fp8_mtp3_lb_marlin` gives the reference's kernel; the reference is Marlin W8A16 on L4
- **Arm / flag:** `fp8_mtp3_lb_marlin`, `--linear-backend marlin`. This also changes how `fp8_mtp3_lb_triton` and the reference should be read.
- **Proof:**
  - The FP8 repack has `quant_method: fp8`, `weight_block_size: [128,128]` and `activation_scheme: dynamic`. `Fp8LinearMethod` builds a per-group (1,128) activation key (quantization/fp8.py:261-270) and calls `init_fp8_linear_kernel(..., module_name="Fp8LinearMethod")` (fp8.py:347-354). That takes the block branch through `_POSSIBLE_FP8_BLOCK_KERNELS` (kernels/linear/__init__.py:745-763).
  - The CUDA priority list is: FlashInferFp8DeepGEMMDynamic, DeepGemm, CutlassFp8Block, B12xFp8Block, **MarlinFP8ScaledMM**, Humming, TritonFp8Block, BlockWiseTorch (kernels/linear/__init__.py:478-489).
  - On SM 8.9:
    - The FlashInfer/DeepGEMM dynamic kernel needs both halves supported (scaled_mm/BlockScaledMMLinearKernel.py:173-190). DeepGEMM needs SM 90/100/120 (scaled_mm/deep_gemm.py:47-52, utils/deep_gemm.py:111-116, platforms/cuda.py:689-695).
    - CUTLASS block FP8 needs SM 90 or higher (csrc/quantization/w8a8/cutlass/scaled_mm_entry.cu:161-174, used through quantization/utils/w8a8_utils.py:21-41 and scaled_mm/cutlass.py:290-297).
    - B12x needs the SM 12x family (scaled_mm/b12x.py:60-61).
    - Marlin FP8 needs only SM 7.5 or higher (marlin_utils_fp8.py:30-31; scaled_mm/marlin.py:35-49).
    - Humming is promoted only at SM 90 (quantization/utils/humming/priority.py:11, 26-47).
  - So with **auto**, the result is `MarlinFP8ScaledMMLinearKernel`, and `fp8.py:356` sets `use_marlin=True`, which means weight-only FP8 compute.
  - With `--linear-backend marlin`, `_resolve_backend_kernels` filters to the `"marlin"` set (kernels/linear/__init__.py:320-326, 378-428), which gives the same Marlin kernel.
  - With `triton`, the filter gives `TritonFp8BlockScaledMMKernel` (lines 327-331). Its `is_supported` is True on CUDA (scaled_mm/triton.py:201-206) and its base `can_implement` accepts dynamic activations (BlockScaledMMLinearKernel.py:77-85). This is W8A8 using FP8 tensor cores through Triton.
  - The bf16 linears (`mtp.fc`, `in_proj_a/b`, lm_head) are not touched by marlin or triton: `dispatch_unquantized_gemm` maps only FlashInfer bf16 backends (layers/utils.py:620-652).
- **What happens:** the `lb_marlin` arm uses one launch slot (startup plus about 2 x 75 s windows) to measure the reference again. The log should show `Selected MarlinFP8ScaledMMLinearKernel for Fp8LinearMethod` for both the reference and `lb_marlin`, and `Selected TritonFp8BlockScaledMMKernel for Fp8LinearMethod` for `lb_triton`. It will also likely show the misleading warning "Your GPU does not have native support for FP8 computation ... Weight-only FP8 compression will be used leveraging the Marlin kernel" (marlin_utils_fp8.py:109-110). Any reading of these arms as "reference = native FP8" is wrong.
- **Minimal fix:**
  - Remove `fp8_mtp3_lb_marlin` from PLAN, or record it as a duplicate of the reference.
  - Label `fp8_mtp3_lb_triton` as "W8A8 Triton block-FP8 vs reference W8A16 Marlin".
  - Optional replacement arm: `env VLLM_MARLIN_INPUT_DTYPE=fp8`. `get_marlin_input_dtype` allows fp8 activations exactly on SM 89 (marlin_utils.py:720-737; set per layer at fp8.py:189). Whether the FP8-weight Marlin path accepts fp8 activations is **UNVERIFIED**; this arm was not checked against that kernel.

### F2 (MEDIUM): `vms_kernels()` cannot record a `--linear-backend` fallback
- **Arm:** every arm, mainly `lb_marlin` and `lb_triton`.
- **Proof:**
  - The regex `((?:Selected|Using|Chose)\b.{0,60}?(?:Kernel|kernel|backend|Backend).{0,80})` (cell5.py:264) is case-sensitive and anchored on `Selected|Using|Chose`.
  - The real fallback lines are:
    - `"--linear-backend=%s has no kernel for this linear layer type; using automatic selection for that layer type."` (kernels/linear/__init__.py:386-389)
    - `"--linear-backend=%s was requested, but no %s kernel exists for %s layers; falling back ..."` (418-424)
    - `"--linear-backend=%s requested FlashInfer mm_bf16 backend %r, but it is unavailable ..."` (layers/utils.py:635-641)
  - None of these start with Selected/Using/Chose, and "using" is lowercase, so none of them is captured.
  - The regex does match the real selection lines:
    - `Selected %s for %s` (kernels/linear/__init__.py:758-763 and 797-802; the module name is `Fp8LinearMethod`, logged once with scope global)
    - `Using %s for mixed-precision linear` (line 923; INT4 gives `MarlinLinearKernel`, because CutlassW4A8 and Machete need SM 90: mixed_precision/cutlass.py:28-37, machete.py:24-34)
    - `Using %s backend.` (platforms/cuda.py:446)
    - `Using %s GDN prefill kernel (...)` (layers/mamba/gdn/qwen_gdn_linear_attn.py:221-224)
- **What happens:** for these arms no fallback actually occurs (marlin and triton both have an FP8-block kernel), but the saved record cannot show that. A future arm whose backend lacks a kernel would silently run auto with nothing logged.
- **Minimal fix:** add one alternative to the regex: `|(--linear-backend=.{0,160})`. Then after the arms run, compare `kernels` of each `lb_*` arm with the reference and mark identical lists as `"no-op"`.

### F3 (INFO, verified OK): INT4 + MTP prefix and ignore matching; #58807
- **Arms:** `int4_mtp3_s16`, `int4_mtp3_s20`, `tp2x2_int4_mtp3`.
- **Draft prefix:**
  - Model Runner V2 is the default for this config (§5). `MTPSpeculator` (v1/worker/gpu/spec_decode/__init__.py:63-66) calls `load_eagle_model`, which calls `get_model(vllm_config=..., model_config=draft_model_config)` with no prefix (v1/worker/gpu/spec_decode/eagle/utils.py:77-92).
  - The default prefix is `""` (model_executor/model_loader/__init__.py:131-143; model_loader/utils.py:74-95). The V1 path is the same (v1/spec_decode/llm_base_proposer.py:1304-1316).
  - `Qwen3_5MTP` builds the predictor with `maybe_prefix("", "mtp")`, which is `"mtp"` (qwen3_5_mtp.py:233-235). Under it: `mtp.fc` (98-106), `mtp.layers.0` (118-125), then `.self_attn.qkv_proj` / `.o_proj` (qwen3_next.py:324, 333; qwen3_5.py:163) and `.mlp.*` (qwen3_5.py:175/183).
  - The draft uses the target's own quant config. For `mtp` the draft model is the target checkpoint and the quantization is inherited (speculative.py:1148-1163). For compressed-tensors, `fc_quant` is the quant config (it is only removed for modelopt_fp4: qwen3_5_mtp.py:93-97), and the `dynamic "-:"` GPTQ escape does not apply (112-117).
- **Ignore matching in vLLM:**
  - `get_scheme_dict` calls `should_ignore_layer(layer_name, ignore, fused_mapping)` (compressed_tensors.py:1012-1015). That calls `find_matching_patterns`, which first matches the **fused** name directly with `re.match(pattern[3:], name)` (quantization/utils/config_utils.py:344-362, 392-412).
  - `re:^mtp.*` therefore matches `mtp.fc`, `mtp.layers.0.self_attn.qkv_proj`, `.o_proj`, `mtp.layers.0.mlp.gate_up_proj` and `.down_proj`. All of them get `UnquantizedLinearMethod` (compressed_tensors.py:159-183). I simulated this rule on the real config: all 5 fused names come out ignored.
  - The regex entry survives `apply_vllm_mapper` because `re:` targets are kept (compressed_tensors.py:141-155). Non-regex `mtp.*` entries would survive too: the `"mtp.": None` rule in the Qwen3.5 mappers (qwen3_5.py:327-329, 476-479) is removed by `get_rename_mapper` (models/utils.py:180-199) before `configure_quant_config` applies it (model_loader/utils.py:361-381). The same holds for the FP8 reference: `mtp.fc` stays in `modules_to_not_convert` (fp8.py:153-155).
- **Checkpoint facts:** `redhat_index.json` has 15 `mtp.*` keys and 0 `weight_packed`/`weight_scale` among them. `config.json` ignore = 304 entries and includes `re:^mtp.*` and `lm_head`.
- **#58807 (dense MTP missing from ignore):** not a risk for this checkpoint. `vms_int4_mtp_static()` will return ok=True with "MTP dense and exempted by the ignore list" (I reproduced this on the fixture files: 8 dense linear modules, `not_ignored=[]`). The issue text itself is UNVERIFIED.
- **Where the static check's rule differs from vLLM's** (no effect on this checkpoint):
  - (a) It treats a non-regex entry as a prefix match (`name.startswith(x + ".")`, cell6.py:57), but vLLM matches **exact name or `re:` only** (config_utils.py:403-412). A checkpoint with ignore `["mtp"]` would pass the static check and still crash in vLLM.
  - (b) `ok = bool(mtp) and (bool(packed) or not not_ign)` (cell6.py:66) passes a mixed checkpoint (some MTP linears packed, some dense and not ignored).
  - **Minimal fix:** replace the non-regex branch with `name == x` and use `ok = bool(mtp) and not not_ign_dense`, where the dense list excludes modules that have `weight_packed`.
- **KV side note:**
  - The RedHat checkpoint has calibrated FP8 `k_scale`/`v_scale` for the 16 full-attention layers (32 tensors), plus `kv_cache_scheme` in its config. The FP8 repack has none, so it uses scale 1.0.
  - The MTP attention layer gets `CompressedTensorsKVCacheMethod` even though it is ignored (compressed_tensors.py:213-214), and has no scale (default).
  - So FP8 and INT4 arms also differ in KV-quantization numerics. This is not a flag error; the INT4 arms are not gated anyway (`gate=False`).

### F4: DP2 x TP2 arms (`tp2x2_fp8_mtp3`, `tp2x2_int4_mtp3`)
- **(a) `--max-num-seqs` per rank: correct.**
  - No DP division happens in arg_utils (2601-2621, 3097-3185).
  - For a dense model each DP rank is an independent `EngineCoreProc` with its own scheduler: "Non-MoE DP ranks are completely independent, so treat like DP=1" (v1/engine/core.py:1473-1478; config/parallel.py:1172-1181).
  - So 8 per engine and 16 in all, as the cell comment says.
  - Load balancing is round-robin with per-client in-flight counts (v1/engine/core_client.py:1642-1680), so a burst of 16 should split 8/8. Whether that holds under real timing is UNVERIFIED.
- **(b) Ports and processes:**
  - Internal LB (no external-LB flags) makes `api_server_count` default to `data_parallel_size` = 2 (entrypoints/cli/serve.py:113-130). `run_multi_api_server` then runs, which sets up Prometheus multiprocess mode (serve.py:282-283) and binds `--port 8011` with SO_REUSEPORT in both API processes (serve.py:298).
  - A DP coordinator is started for non-MoE internal LB (config/vllm.py:846-864). Its ZMQ ports are allocated automatically, and no other user port is needed.
  - `/health` and `/metrics` can be answered by either API process.
  - `killpg` covers all the child processes, because they share the server's process group.
- **(c) `/metrics` covers both engines, but two recorded values change meaning.**
  - Multiprocess registry: prometheus.py:17-52. Labels are `{model_name="q27", engine="0"|"1"}` (v1/metrics/loggers.py:499-505).
  - `vllm:num_requests_running` and `vllm:kv_cache_usage_perc` are gauges with `multiprocess_mode="mostrecent"` (loggers.py:528-531, 620-623). Scheduler stats go to only one front end per step (v1/core/sched/scheduler.py:2417-2422). Counters are summed across processes.
  - `vms_prom()` sums every label set (cell5.py:121-129). So `running`, `tok_s` and `accept` are correct totals.
  - **But** `kv_max` becomes engine0 + engine1 usage, a 0..2 range, which cannot be compared with the TP4 arms. **Fix:** in `vms_prom`, keep per-label values for `kv_cache_usage_perc` and record the max.
  - `rec["kv_tokens"]` / `max_concurrency_at_max_len` take the **last** `GPU KV cache size ...` line (cell6.py:26-29). Each engine process logs its own line (v1/core/kv_cache_utils.py:2316-2334), so the value is one engine's capacity, about half the pool. **Fix:** keep all matches (`m` list) for DP arms.
  - Also, with 2 API servers the periodic throughput log lines are disabled (loggers.py:1385-1389). Prometheus is not affected.
- **(d) Custom all-reduce:**
  - For TP4 on PCIe, custom all-reduce turns itself off ("not supported on more than two PCIe-only GPUs", device_communicators/custom_all_reduce.py:270-276). So `--disable-custom-all-reduce` is a **no-op in all TP4 arms**.
  - For the TP2 groups (world size 2) that check does not apply. Custom all-reduce would run whenever `_can_p2p` passes (custom_all_reduce.py:281-291). In the tp2x2 arms the flag therefore actively removes a possible speedup.
  - Whether Kaggle L4 pairs have working P2P is UNVERIFIED; the E14 NCCL bench `p2p_sys` arm can answer it.
  - **Fix:** if the bench reports P2P OK, call the tp2x2 arms with `extra` and without `--disable-custom-all-reduce` (for example, add a `car=True` parameter to `vms_flags`).
- **(e) Gate caveat:** `tp2x2_fp8_mtp3` uses `gate=True` against the TP4 oracle. TP2 and TP4 reduce in different orders, so greedy text can diverge beyond A/A + 1 / + 2 without any bug. How large that effect is: UNVERIFIED. Suggest `gate=False` (diagnostic) for TP-changing arms.

### F5: prefix caching + MTP on the hybrid model (#53912 family)
- **Prefix caching is on by default.** `--enable-prefix-caching` equals the default for this hybrid model (`is_prefix_caching_supported` returns True for `hybrid`: config/model.py:2259-2261; applied at arg_utils.py:3021-3022). The flag is redundant but harmless.
- **Mamba cache mode is switched automatically:**
  - With prefix caching on, `MambaModelConfig` sets `mamba_cache_mode="align"` and `mamba_block_size = block_size`, logs "Mamba cache mode is set to 'align' ...", and asserts chunked prefill (models/config.py:685-699). This hook is called for every hybrid model (config/vllm.py:2660-2661, models/config.py:507-521).
  - With `--no-enable-prefix-caching` (oracle, `fp8_mtp3_noprefix`) it sets `none` and `mamba_block_size = max_model_len` (models/config.py:700-708).
  - The attention block size is then raised to the mamba page (platforms/interface.py:783-788, 939+).
  - My arithmetic with fp32 SSM (UNVERIFIED rounding): about 1,568 tokens at both TP4 and TP2. With fp16 SSM it is about 800 at TP4. So `fp8_mtp3_ssm_fp16` changes the prefix-cache granularity as well as the memory.
- **Nothing in v0.32.0 disables prefix caching or speculative decoding for Qwen3.5.** The only automatic disables are for encoder-only instances (config/vllm.py:1427-1438) and Unlimited-OCR (models/config.py:196-197).
- **SSM dtype:** `mamba_ssm_cache_dtype` `auto` resolves to the checkpoint's `mamba_ssm_dtype` = `float32` (models/config.py:853-867). So every arm except `ssm_fp16` runs an fp32 SSM state, and `ssm_fp16` is a real change. vLLM warns at models/config.py:868-878.
- **Model Runner V2 is the default and is not recorded.**
  - It is chosen whenever `VLLM_USE_V2_MODEL_RUNNER` is unset and no unsupported feature is present; MTP is not on that list (config/vllm.py:703-738, 2914-2953).
  - V2 supports align mode with speculative decoding (v1/worker/gpu/model_states/mamba_hybrid.py:89-116, 387-396).
  - In V2 the drafter **inherits** `--attention-backend FLASHINFER` (speculative.py:376-383, 1790-1800). V1 would auto-select it (llm_base_proposer.py:1282-1290).
  - **Fix:** add `VLLM_USE_V2_MODEL_RUNNER=1` to the env in `vms_install()` (it exists: envs.py:2151) so the runner is fixed and recorded.
- **Long-band interpretation:**
  - Every `_L` prompt shares the same ~36k-token "Reference tasks" system block (cell6.py:161-172).
  - Prefix-cache arms reuse it, in multiples of about 1.6k-token blocks under align mode. The oracle and `fp8_mtp3_noprefix` prefill it again for every request.
  - So their `long` tok/s differences include prefill recompute and are not only decode speed.
- **#53912 itself:** the issue text is UNVERIFIED (it is not in the source). The notebook's degenerate-text detector is the right guard for it.

### F6 (LOW, optional): the vision tower is loaded in every arm
- Both checkpoints are `Qwen3_5ForConditionalGeneration` (the RedHat index has 333 `visual` tensors).
- No arm passes `--language-model-only` (it exists: arg_utils.py:1460), so every arm loads the vision encoder and its profiling memory.
- It is the same in every arm, so it does not confound comparisons, but it costs KV capacity.

## 4. Arms that are no-ops versus the reference
- `fp8_mtp3_lb_marlin`: **full no-op** (F1).
- `--disable-custom-all-reduce` in every TP4 arm: no-op (custom AR is already off on 4 PCIe GPUs), harmless.
- `--enable-prefix-caching`: equals the default, harmless.
- `--trust-remote-code`: has no effect for this built-in architecture.
- `VLLM_MEMORY_PROFILER_ESTIMATE_CUDAGRAPHS=1`: equals the v0.32.0 default.

## 5. UNVERIFIED (cannot be proved from v0.32.0 source)
- What issues #53912 and #58807 actually say.
- Whether FP8-weight Marlin accepts `VLLM_MARLIN_INPUT_DTYPE=fp8`.
- Whether Kaggle L4 pairs pass `_can_p2p`.
- The exact hybrid block size after kernel-alignment rounding.
- The 8/8 split in practice, and how large greedy text differences between TP2 and TP4 are.
- That the RedHat Kaggle Model directory names its index `model.safetensors.index.json` (the static check reads that name).
