# EMS notebook audit: control flow, crash and wrong-result paths (cell 7, cell 8, their use of cell 6 and E14M)

Scope: `cell7.py` (CELL EMS) and `cell8.py` (CELL EMS-R) read in full; cells 0-6 read for the globals they use;
`e14_measure.py` read in full; `e14_loadpath.py` read for E14State, StallMonitor, `_io_counter` and `jit_cache_env`.
Read-only audit: nothing was edited or run. Line numbers: cellN.py = the extracted cell, E14M = e14_measure.py,
E14L = e14_loadpath.py.

Summary: I found no path that crashes cell 7 or cell 8 in a normal run, and no path that runs past HARD_STOP. The
main weakness is the probe half of `_gated`: it lets an arm through when the evidence is missing (F1). Dirty-server
detection does not see the parity and probe passes (F2). A dead server or a failed 40k band does not stop an arm
from being picked (F3).

---

## Findings

### F1. The `_gated` probe check lets an arm through when the probe has no evidence (wrong result, moderate)
- Where: cell7.py L299-306 (`_gated`); E14M L536-542 (`compare_passes` counts only completed rows).
- Scenario A: the probe is the last step of `_windows.run` (cell7 L244-248). If the phase deadline is close or past,
  or the server is slow or dead, the 12 probe requests time out: `post_json` raises at the deadline (E14M L68-71) and
  urllib times out after it. `compare_passes` then returns `compared 0, errors 12, large_margin_flips 0`. In `_gated`,
  `_pf = 0 <= _aa + 1` passes.
- Scenario B: the reference probe was skipped (for example after a failed `ref_clean` relaunch). `_probe_vs_ref`
  returns `{"skipped": ...}`, so `_pf` is None, and `_pf is None` passes.
- Scenario C: the oracle switch `if EMSR.get("probe_tgt_aa")` (L301) takes any dict as true, even an A/A where every
  row errored (compared 0). It then judges every arm against those empty rows.
- Effect: an MTP arm with no probe, or only a partial one, counts as gated. It can then be picked for `_s20`
  (L415-418) and for the TP2 MTP slot (L577-581). The arm_gate half is still strict (fail-closed), so this does not
  let a gate FAIL through. It only removes the 1,024-token check.
- Fix: add a helper `_cmp_complete(c) = bool(c) and c.get("expected") and c.get("compared") == c.get("expected") and
  not c.get("errors") and not c.get("missing_margins")`. In `_gated`, require it for the arm's probe compare and for
  the A/A it is judged against. Switch to the target oracle only when `_cmp_complete(EMSR["probe_tgt_aa"])`. Store
  `probe_complete` / `probe_complete_vs_target` in `_record` so `_gated` can read them.

### F2. Dirty-server detection does not see the A/A and probe passes (wrong result, moderate)
- Where: `_e14_dirty` cell7 L74-81 looks for `server_idle is False` / `server_not_idle is True` in the phase result.
  `parity_pass` puts its flag on `rows[0]["server_not_idle"]` (E14M L502-503). But `_ref_gate` (L210-213), `_tgt_aa`
  (L355-359), `_ref_probe` (L326-330), `_tgt_probe` (L363-369) and the arm probe (L246-248) return only
  `compare_passes` summaries. Their `rows` are new dicts (E14M L518-535), so the flag is lost. Only `arm_gate` passes
  it on (E14M L744).
- Scenario: in a reference or target A/A pass, requests are still running after the 20-s cleanup. E14_DIRTY stays
  False. Pass "b", the steady windows and the probe A/A then run on a busy server.
- Effect: (1) spurious A/A flips. `parity_ok` allows `arm flips <= A/A flips` (E14M L711), so a noisy reference A/A
  makes the gate looser for every later arm. (2) `_tgt_aa` sets EMS_TGT (L357-358) from those rows, so the loose A/A
  becomes the gate reference. (3) The reference and target windows can run at the wrong level.
- Fix: in `_aa_rows`, add `dirty = any(r.get("server_not_idle") for p in (a, b, c, c2) for r in p[:1])` to the
  returned summary as `"server_not_idle": dirty`. Do the same in the probe callers. In `_tgt_aa`, do not set EMS_TGT
  when dirty. `_gate_from_rows` should give INCOMPLETE when `_DFL` or `EMS_TGT` rows carry the flag.

### F3. A dead server, or a failed 40k band, can still give an arm that is "ok" and gated (wrong result, moderate-low)
- Where: `_record` cell7 L257 (`ok` = launch ok and no top-level `error`); `capped` L272-273 checks only
  `level_short`; `_gated` L305-306 checks ok / gate / log_errors / probe only.
- Scenario: an MTP arm passes the gate and the 8k window. Then the server dies during the 40k window, or the 40k
  window never reaches its level: `steady_window` puts `"error"` inside `out["long"]` (E14M L339-343) and
  `level_long` is None. The crash is invisible to `log_errors` when the server printed no "Traceback" or "out of
  memory" before it died, for example a host OOM-kill or a SIGKILL (E14M ERROR_SIGNS L768).
- Effect: the arm stays `ok=True`, is not marked capped, passes `_gated`, and can be the "best" MTP for `_s20` and
  TP2.
- It also wastes time: `wait_level` treats a dead server as "not yet" (prom raises, so `r=None`, E14M L306-318) and
  waits up to `min(600, left - secs - 30)` per window. The phase burns its whole cap (up to 12 min) before moving on.
- Fix: in `e14_phase`, record `res["server_alive_after"] = _srv.alive()`. In `_windows.run`, return early when
  `not E11_SERVER.alive()`. In `_record`, set `capped` also when `level_long` is None or below the wanted level, and
  add `long_error`. In `_gated`, require `server_alive_after`, `not capped`, and both windows without
  `error`/`skipped`.

### F4. TP2 `ok`, throughput sums and gate cover only part of the layout (wrong result, low)
- Where: cell7 L547-549 (sums with `or 0`), L566 (`ok`), L542 (gate on replica 0 only), L564-565 (`r=None`, so
  `log_errors` is always empty for TP2).
- Scenario: replica 1's window errors or is skipped while replica 0 measures.
- Effect: `short_tok_s_sum` = replica 0 alone, yet `ok=True`. `level_short` becomes 0 (L569), so the row is marked
  CAPPED, but `ok`, `x ref` and `short_tok_s` look like a real 2 x TP2 number at half the throughput. Replica 1 is
  never gated. Server-log errors of the TP2 servers are never checked.
- Fix: set `ok` only when both `sw` and both `lw` entries have `tok_s_p50` and no `error`/`skipped`. Run the gate on
  both replicas, in parallel with `_both`. Count `E14_LOG_SIGNS` in each replica's log since its start.

### F5. After the oracle switch, DFlash-family arms cannot be told apart from the DFlash reference itself (misleading result, design)
- Where: cell7 L374-383 (`EMS_REF = EMS_TGT`); PLAN L392-393, L399-400 (dflash_w6_s20/s24, dflash_w4/w8 gated vs
  target-only).
- Scenario: `dflash_vs_target_gate` = FAIL, which is exactly the #38009 / #36548 concern this switch was added for.
- Effect: every DFlash arm will then most likely read FAIL vs target-only for the same reason as the reference. The
  report cannot separate "this width or stream count broke something" from "DFlash differs from plain decoding". No
  verdict against the DFlash reference rows (`_DFL`) is kept.
- Fix (no GPU cost): `arm_gate` already writes its rows to `e14_parity_outputs.jsonl`. Have `arm_gate` (or a cell-7
  wrapper) also return `s`/`c`. For DFlash arms, add `gate_vs_dflash = _gate_from_rows({"serial_a": s,
  "conc_a": c}, _DFL, ...)` and show both verdicts in the report.

### F6. The best-MTP candidate filter misses `ntn_int4` (minor, selection)
- Where: cell7 L415, L577 filter on `k.startswith("mtp_")`.
- Effect: `ntn_int4` (L391) is also an MTP config (`_mtp()` on the same INT4 checkpoint, gated, with a probe), but it
  is never a candidate for `_s20` or the TP2 MTP slot, even if it is the fastest gated MTP.
- Also: at the `_s20` point (after `dflash_w6_s24`), the only `mtp_` arm that can exist is `mtp_3_1_4`, because of
  the PLAN order (L387-401). "Fastest gated MTP so far" therefore always means `mtp_3_1_4`. That is fine if intended.
- Fix: put `"family": "mtp"` in the `_record` extra of MTP arms (including ntn_int4) and filter on it.

### F7. The best picks do not require a valid, comparable window (minor)
- Where: cell7 L415-417, L577-580 rank by `short_tok_s` alone.
- Effect: there is no minimum number of decode lines. `window_stats` gives a median over whatever lines exist
  (E14M L170-178), and `adopt_speed`'s `min_lines=8` is not used here. There is also no check that the measured
  levels are equal. An arm with 2 decode lines, or one measured at the level-1 plateau, competes directly.
- Fix: in `_gated` (or the picks), require `_w(r, "short", "lines") >= 8` and `not a["capped"]`.

### F8. With a production fallback, the reference name and base flags no longer match the labels (minor, label; part UNVERIFIED)
- Where: cell6 L248-260 (streams12 / W1 fallbacks), L207-208 (W1 keeps the plain W1 flags: width 8,
  `--cuda-graph-max-bs-decode`, no `--min-free-slots-delay`); cell7 L185 (`LEVEL = SGL_MAX_RUNNING`), L332 (name
  hard-coded `ref_dflash_w6_s16`).
- Effect: after a 12-stream fallback, the "s16" reference ran at 12. After the W1 fallback, `dflash_w6_s20/s24` really
  run width 8. `_streams` then sends `--cuda-graph-bs-decode 1..21` while `--cuda-graph-max-bs-decode 16` is still in
  the flags. I could not verify how SGLang 0.5.21 combines the two (UNVERIFIED).
- Fix: build the reference name from `E14_VENV["cfg"]` / `SGL_MAX_RUNNING` and record `EMSR["base_cfg"]`. Add
  `--cuda-graph-max-bs-decode` to the drop list whenever `--cuda-graph-bs-decode` is set.

### F9. The gate and the probe can use different oracles (minor)
- Where: the gate oracle switches on `EMS_TGT` (cell7 L374); the `_gated` probe oracle switches on
  `EMSR["probe_tgt_aa"]` (L301).
- Effect: when the target A/A is incomplete but the target probe is complete, or the other way round, arms are gated
  against DFlash rows but probed against target-only, or the reverse. The report's "gate reference" line (cell8 L9)
  names only the gate oracle.
- Fix: use one flag, `EMSR["oracle"] = "target_only"`, set only when both the target A/A and the target probe A/A are
  complete (see F1 / F10). Use it for both and print it.

### F10. `_tgt_aa` can switch to an A/A that turns every later gate INCOMPLETE (minor, fail-closed but loses the fallback)
- Where: cell7 L357 checks `errors == 0 and compared > 0` only.
- Effect: `missing_margins` is not checked, and neither is a dirty server (F2). If the target A/A has a divergence
  with no margins, `parity_ok` returns INCOMPLETE for every arm (E14M L704-705). Nothing is gated, and there is no
  `_s20` or TP2 MTP. Meanwhile the DFlash reference, which may have been complete, is dropped as the oracle.
- Fix: also require `x["missing_margins"] == 0` and no dirty flag before setting EMS_TGT.

### F11. Rows for a failed target_only launch or a skipped reference window show gate "reference" (cosmetic)
- Where: cell7 L258: with `gate=None`, the default verdict is "reference" even when `r` is None.
- Fix: `"reference" if (gate is None and r) else ...`.

### F12. An empty prompt set makes every window raise ZeroDivisionError (minor)
- Where: cell7 L179-180 (`ems_prompts` failure leaves `_S = _L = []`); E14M L334-335 (`prompts[i % len(prompts)]`).
- Effect: e14_phase catches each error, so the run goes on, but it spends launches on arms that measure nothing.
  Also, when any step inside `run()` raises, the gate and window results already measured in that phase are thrown
  away (cell7 L103-106 replace `res`). I found no other step that realistically raises.
- Fix: `if not _S or not _L:` skip EMS with an explicit reason before the first launch.

### F13. Cell 7 has no top-level guard, and the TP2 start loop can leak a server (minor; Kaggle behaviour UNVERIFIED)
- Where: cell7 L172-583 has no try; `E11Server.start()` (Popen / open) at L55 and L491-492 is outside any try.
- Effect: an OSError there aborts the cell. In `ems_tp2`, a failure to start replica 1 leaves replica 0 running. If
  the Kaggle commit runner stops at the first failing cell (UNVERIFIED for this run mode), cell 8 (report + bundle)
  does not run. `e14_results.json` and the logs are still in /kaggle/working.
- Fix: wrap the EMS body in try/except/finally that records `EMSR["error"]` and always reaches EMS_DONE. In
  `ems_tp2`, wrap the start loop and kill the servers already started.

### F14. The skip message overstates the remaining-time floor (cosmetic)
- Where: cell7 L39, L470 print "less than 15 min before the hard stop". With reserve 0 the real threshold is
  `max(900, 400 + 480 + 120)` = 1,000 s = 16.7 min (E14M L791).

### F15. Per-replica cache isolation covers only the five `jit_cache_env` dirs (info, UNVERIFIED impact)
- Where: cell7 L450-464; E14L L808-813.
- Effect: FlashInfer's own JIT/workspace dir (default under ~/.cache/flashinfer) and the torch inductor cache are not
  split, so the two TP2 servers compile into them at the same time. I did not verify whether SGLang 0.5.21 with the
  flashinfer_jit_cache wheel compiles anything there, or whether FlashInfer locks it.

### F16. Capacity expectation (info; an estimate, launch durations UNVERIFIED)
- HARD_STOP = T0 + 198 min. PLAN arms may launch only while at least 2,800 s remain (reserve 1,800 + 400 + 480 + 120,
  E14M L791), that is until about T0 + 151 min.
- If READY comes at about T0 + 15-20 min, and the reference block (about 11 min) and the target block (launch plus
  about 15 min) finish around T0 + 45-55 min, about 95-105 min are left for PLAN.
- Each arm costs a launch (about 3-6 min) plus a phase (about 8 min of its 12-min cap), so about 7-9 of the 12 PLAN
  launches fit (11 arms + `_s20`). The last ones in PLAN order (`mtp_replay_fp32`, `dflash_w4`, `dflash_w8`) are the
  likely skips.
- The second TP2 slot (MTP) will most likely get no window, or only a partial one: the first TP2 uses about 20-25 of
  the 30 reserved minutes.
- If the later arms matter, reorder PLAN.

---

## Checked, no issue
- **Hard stop:** I found no path that runs past HARD_STOP.
  - Arm phases end at least 480 s + the reserve before it (phase_budget E14M L776-780).
  - Launches wait at most `HARD_STOP - now - reserve - 480` (cell7 L56-57) and are refused below the reserve
    (E14M L783-791).
  - The TP2 run deadline is at most `HARD_STOP - 480`. Steady windows stay inside their ctx deadline (warm, wait_level
    and the 75-s window are all sized from `ctx.left()`). The worst-case TP2 tail (cleanups, 2 x 60-s kills,
    `_e11_gpu_free` up to 195 s) ends about 100 s before HARD_STOP.
- **Reserve:** `E14_RESERVE` is set and cleared at module level (L336, L422), so `e14_launch` and `e14_phase` read the
  global. The reserve protects the TP2 slot from the target-only block on.
- **Oracle switch:** `EMS_REF` is rebound at module level (L378). `_windows.run` reads the global at call time, so
  every arm after the switch is gated against the target-only rows. `_DFL` keeps the DFlash rows.
- **`_gate_from_rows`:** the keys always exist (`gate_reference` builds all four). `verdict` is present in both
  branches of L376-377. `_ra.update` is guarded (L380). The argument order (base first) matches arm_gate.
- **Failure paths:**
  - A target_only launch failure or skip does not crash. The gate reference stays DFlash with a correct label, and
    the probe oracle stays DFlash.
  - A failed arm launch sets `E11_SERVER = None` and runs no phase; the next arm launches normally.
  - A failed or skipped dirty relaunch makes the phase record "dirty server" instead of measuring.
- **Gate verdicts:** an arm that failed the gate cannot pass `_gated`. arm_gate gives PASS only when both
  `parity_ok` are ok and the server is not dirty (E14M L744-746). A phase error, a skipped phase or `gate=False`
  gives gate None or "diagnostic", which are not in the accepted set. The only accepted non-PASS value,
  "reference", belongs to non-`mtp_` rows.
- **Arm names in the picks:** `_s20` arms are excluded from the TP2 pick. `tp2x2_*` names never match `mtp_`.
- **PLAN dicts:** `dict(_NTN, **_mtp(...), **{"--model-path": ...})` has no duplicate keyword keys. No `_kw` key is
  unknown to `_arm`.
- **`e14_edit_flags`:** it handles bare flags, list values and None (bare) correctly. Removal stops at the next
  `--` token, and no base flag value starts with `--`.
- **Report cell:** every lookup uses `.get` with defaults. `EMSR["arms"][k]` exists for every `k` in `order`
  (`_record` writes both). An empty or skipped EMSR renders a header-only table. The body is in try/except, and the
  server kill comes after it. The row and header have 14 columns each.
- **JSON:** everything I traced into E14_RESULTS / EMSR is str, int, float, bool, None, list or dict.
  `write_json_atomic` has no `default=str`, but nothing needs it.
- **`ems_topo`:** the parse ignores the escape-coded header and NIC rows, falls back to 0-1 / 2-3, and records the
  matrix. CUDA_DEVICE_ORDER=PCI_BUS_ID matches nvidia-smi indices.
- **`ems_replica_env`:** it never copies CUDA_CACHE_PATH and skips `nv/` at every level. It copies only when the
  destination is missing, so the second TP2 reuses the replica caches.
- **TP2 servers:** ports and NCCL ports are distinct. Both servers are killed on every path after both have started.
  A readiness loop with a dead replica exits at once.
- **Function signatures:** `E14State.enter` / `end` match how they are called. `wait_ready` → `StallMonitor.wait`
  returns `(ok, why, stats)` and does not raise (`_io_counter` catches everything).
