"""EMS rev 2b: the 2026-10-26 agent audit (agent 1 = EMS code paths, agent 2 = EMS flags vs SGLang 0.5.21), every claim
re-checked by me in the notebook code / e14_measure.py / the 0.5.21 source before this patch."""
from pathlib import Path

p = Path(r"D:/ARC AGI 2/experiments/Experiment 14 - Optimized Engine on 4xL4 (planned)/Experiment Notebooks/Build/build_ems.py")
t = p.read_text(encoding="utf-8")


def rep(a, b, n=1):
    global t
    assert t.count(a) == n, (t.count(a), a[:100])
    t = t.replace(a, b)


# ---- docstring
rep('''usage: python build_ems.py   -> ../Q27-XHIGH-EMS_ENGINE_MATRIX_SGLANG.ipynb"""''', '''rev 2b (4-agent audit 2026-10-26): own gate (oracle verdict + a verdict vs the DFlash reference rows); dirty-server flags
from every A/A and probe pass; one oracle flag (target-only only when its gate A/A AND probe A/A are complete); `_gated`
needs complete probe evidence, a live server, both bands, >= 8 decode lines and no cap; MTP family tag (ntn_int4 joins
the best-MTP pick); slots-aware stream sizing (extra_buffer = 5); NTN mamba 85 = 5 x 17 so 16 streams fit; ntn_fp8 30-min
launch + FP8 page-cache prefetch; reference name from the real launch flags, fallback-aware skips; 2 x TP2 gated on both
replicas, ok only with all four windows, KV-for-production flag, custom all-reduce off (P2P 5.5x slower here), 30-min
wall, start loop guarded; the whole cell in try / except so the report cell always runs.
usage: python build_ems.py   -> ../Q27-XHIGH-EMS_ENGINE_MATRIX_SGLANG.ipynb"""''')

# ---- e14_launch: per-arm launch timeout (ntn_fp8 reads FP8 from /kaggle/input; agent 2 F4)
rep('''def e14_launch(name, set_=None, drop=(), env=None, force=False):''', '''def e14_launch(name, set_=None, drop=(), env=None, force=False, timeout=None):''')
rep('''    ok, why = srv.wait_ready(min(SGL_RELAUNCH_TIMEOUT_SEC, max(60.0, _room)))''',
    '''    ok, why = srv.wait_ready(min(timeout or SGL_RELAUNCH_TIMEOUT_SEC, max(60.0, _room)))''')
rep('''        rec["skipped"] = "would eat the 2 x TP2 slot" if (not force and E14_RESERVE) else "less than 15 min before the hard stop"''',
    '''        rec["skipped"] = "would eat the 2 x TP2 slot" if (not force and E14_RESERVE) else "less than ~17 min before the hard stop"''')

# ---- prompts: skip EMS when there are none (agent 1 F12); reference name + FP8 prefetch
rep('''    _S, _L = EMS_PROMPTS["short"], EMS_PROMPTS["long"]''', '''    _S, _L = EMS_PROMPTS["short"], EMS_PROMPTS["long"]
    if not _S or not _L:       # rev 2b (agent 1 F12): every window would divide by zero
        raise RuntimeError(f"EMS: no prompts ({EMSR['prompts']}); nothing can be measured")
    # rev 2b (agent 1 F8, agent 2 F7): the reference name / width / streams from the flags the server really got
    _RF = [str(x) for x in (E11_SGL.get("launch_flags") or e11_flags(E14_VENV["cfg"]))]
    _RW = int(_RF[len(_RF) - 1 - _RF[::-1].index("--speculative-num-draft-tokens") + 1]) if "--speculative-num-draft-tokens" in _RF else 0
    REF_NAME = f"ref_dflash_w{_RW}_s{SGL_MAX_RUNNING}"
    EMSR["ref_name"], EMSR["base_cfg"] = REF_NAME, dict(E14_VENV["cfg"])
    try:      # rev 2b (agent 2 F4): FP8 is not staged; read it into the page cache while the INT4 arms run (best effort)
        _fp8 = sorted(str(x) for x in Path(MODEL_PATH).glob("*.safetensors"))
        if _fp8 and not E11_HARNESS:
            subprocess.Popen(["bash", "-c", "cat " + " ".join(shlex.quote(x) for x in _fp8) + " > /dev/null"],
                             stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        EMSR["fp8_prefetch"] = len(_fp8)
    except Exception as _e:
        EMSR["fp8_prefetch"] = repr(_e)[:200]''')
rep('''import re, shutil, statistics, subprocess, threading''', '''import re, shlex, shutil, statistics, subprocess, threading''')

# ---- slots-aware stream sizing (agent 2 F1, kv_cache_configurator.py:2232-2261)
rep('''    def _streams(n):          # n client streams: server cap n + 1, graphs 1..n+1, 4 mamba slots per request
        return {"--max-running-requests": n + 1, "--cuda-graph-bs-decode": list(range(1, n + 2)),
                "--max-mamba-cache-size": 4 * (n + 1)}''', '''    def _slots(s):            # kv_cache_configurator.py:2232-2261, overlap on: extra_buffer 5, extra_buffer_lazy 4
        return 5 if str((s or {}).get("--mamba-radix-cache-strategy", E14_VENV["cfg"].get("strategy"))) == "extra_buffer" else 4

    def _streams(n, slots=4):  # n client streams: server cap n + 1, graphs 1..n+1, `slots` mamba slots per request
        return {"--max-running-requests": n + 1, "--cuda-graph-bs-decode": list(range(1, n + 2)),
                "--max-mamba-cache-size": slots * (n + 1)}''')

# ---- completeness helper + dirty flags in the A/A and probe passes (agent 1 F1, F2, F10)
rep('''    EMS_PROBE_TGT = None
    EMS_TGT = None

    def _aa_rows(tag):
        a = E14M.parity_pass(E14_CTX, _S[:6], max_new=256, tag=tag + "_serial_a")
        b = E14M.parity_pass(E14_CTX, _S[:6], max_new=256, tag=tag + "_serial_b")
        c = E14M.parity_pass(E14_CTX, _S, max_new=256, concurrent=True, tag=tag + "_conc_a")
        c2 = E14M.parity_pass(E14_CTX, _S, max_new=256, concurrent=True, tag=tag + "_conc_b")
        return E14M.gate_reference(a, b, c, c2), {"serial_aa": E14M.compare_passes(a, b, tag + " serial A/A"),
                                                  "conc_aa": E14M.compare_passes(c, c2, tag + " all-at-once A/A")}''', '''    EMS_PROBE_TGT = None
    EMS_TGT = None
    _DFL = None

    def _cmp_complete(c):
        """rev 2b (agent 1 F1): a compare is evidence only when every planned row was compared, none errored and every
        divergence has both margins."""
        return bool(c) and bool(c.get("expected")) and c.get("compared") == c.get("expected") and not c.get("errors") \\
            and not c.get("missing_margins")

    def _dirty_rows(*passes):
        return any(r.get("server_not_idle") for p_ in passes for r in (p_ or [])[:1])

    def _aa_rows(tag):
        a = E14M.parity_pass(E14_CTX, _S[:6], max_new=256, tag=tag + "_serial_a")
        b = E14M.parity_pass(E14_CTX, _S[:6], max_new=256, tag=tag + "_serial_b")
        c = E14M.parity_pass(E14_CTX, _S, max_new=256, concurrent=True, tag=tag + "_conc_a")
        c2 = E14M.parity_pass(E14_CTX, _S, max_new=256, concurrent=True, tag=tag + "_conc_b")
        s_aa, c_aa = E14M.compare_passes(a, b, tag + " serial A/A"), E14M.compare_passes(c, c2, tag + " all-at-once A/A")
        dirty = _dirty_rows(a, b, c, c2)     # rev 2b (agent 1 F2): surfaces to e14_phase -> a clean relaunch
        return E14M.gate_reference(a, b, c, c2), {"serial_aa": s_aa, "conc_aa": c_aa, "server_not_idle": dirty,
                                                  "complete": _cmp_complete(s_aa) and _cmp_complete(c_aa) and not dirty}''')
rep('''    def _ref_gate():
        ref, summ = _aa_rows("ems_ref")
        globals()["EMS_REF"] = ref
        return summ''', '''    def _ref_gate():
        ref, summ = _aa_rows("ems_ref")
        globals()["EMS_REF"] = ref
        EMSR["ref_aa_complete"] = summ["complete"]
        return summ''')

# ---- own gate: verdict vs the oracle + vs the DFlash reference rows (agent 1 F5); base rows dirty = INCOMPLETE
rep('''    def _windows(tag, level, gate=True, probe=True, ctx=None):
        ctx = ctx or E14_CTX

        def run():
            out = {}
            if gate:
                out["gate"] = E14M.arm_gate(ctx, _S, EMS_REF, tag="gate_" + tag, identity=False)
                # EMS rev 2: a FAIL is recorded (no adoption), the speed is still measured; only a dirty server stops
                if out["gate"].get("server_not_idle"):
                    out["windows_skipped"] = "the server was not idle after the gate"
                    return out
                out["flush_after_gate"] = E14M.flush_cache(ctx)
            out["short"] = E14M.steady_window(ctx, _S, level=level, secs=_ts(75), tag=tag + "short")
            out["long"] = E14M.steady_window(ctx, _L, level=level, secs=_ts(75), tag=tag + "long")
            if probe:
                out["flush_before_probe"] = E14M.flush_cache(ctx)
                _rows = _probe(tag, ctx=ctx)
                out["probe"] = _probe_vs_ref(_rows, f"{tag} probe vs reference")
                out["probe_vs_target"] = _probe_vs_tgt(_rows, f"{tag} probe vs target-only")
            return out
        return run''', '''    def _gate2(ctx, tag):
        """rev 2b: E14M.arm_gate's rule (identity=False: flips decide; serial allowance 1, all at once 2) on our own passes,
        so the rows are kept: the verdict vs the gate reference (the oracle once switched) and, for every arm, a second
        verdict vs the DFlash reference rows (agent 1 F5: after the switch a DFlash width / stream arm is otherwise
        indistinguishable from "DFlash differs from plain decoding")."""
        if not EMS_REF or not EMS_REF.get("serial_a") or not EMS_REF.get("conc_a"):
            return {"ok": False, "verdict": "INCOMPLETE", "why": "no baseline reference"}
        if ctx.left() < ctx.m(120):
            return {"ok": False, "verdict": "INCOMPLETE", "why": "deadline"}
        s = E14M.parity_pass(ctx, _S[:6], max_new=256, tag=tag + "_serial")
        c = E14M.parity_pass(ctx, _S[:len(EMS_REF["conc_a"])], max_new=256, concurrent=True, tag=tag + "_conc")
        out = _gate_from_rows({"serial_a": s, "conc_a": c}, EMS_REF, tag)
        out["server_not_idle"] = _dirty_rows(s, c)
        if out["server_not_idle"]:
            out.update(ok=False, verdict="INCOMPLETE", why="dirty server")
        if _DFL is not None and _DFL is not EMS_REF:
            out["vs_dflash_ref"] = _gate_from_rows({"serial_a": s, "conc_a": c}, _DFL, tag + " vs DFlash reference")["verdict"]
        return out

    def _dead(ctx=None):
        return E11_SERVER is None or not E11_SERVER.alive()

    def _windows(tag, level, gate=True, probe=True, ctx=None):
        ctx = ctx or E14_CTX

        def run():
            out = {}
            if gate:
                out["gate"] = _gate2(ctx, "gate_" + tag)
                # EMS rev 2: a FAIL is recorded (no adoption), the speed is still measured; only a dirty server stops
                if out["gate"].get("server_not_idle"):
                    out["windows_skipped"] = "the server was not idle after the gate"
                    return out
                out["flush_after_gate"] = E14M.flush_cache(ctx)
            for band, ps in (("short", _S), ("long", _L)):
                if _dead():         # rev 2b (agent 1 F3): a dead server is not "waiting for the level"
                    out[band] = {"error": "the server died"}
                    out["server_alive_after"] = False
                    return out
                out[band] = E14M.steady_window(ctx, ps, level=level, secs=_ts(75), tag=tag + band)
            if probe and not _dead():
                out["flush_before_probe"] = E14M.flush_cache(ctx)
                _rows = _probe(tag, ctx=ctx)
                out["probe_dirty"] = _dirty_rows(_rows)
                if out["probe_dirty"]:
                    out["server_not_idle"] = True
                out["probe"] = _probe_vs_ref(_rows, f"{tag} probe vs reference")
                out["probe_vs_target"] = _probe_vs_tgt(_rows, f"{tag} probe vs target-only")
            out["server_alive_after"] = not _dead()
            return out
        return run''')

# ---- record: probe completeness, alive, long cap, lines, family, honest reference label (agent 1 F1, F3, F6, F7, F11)
rep('''             "gate": ((r or {}).get("gate") or {}).get("verdict", "reference" if gate is None else ("diagnostic" if not gate else None)),''',
    '''             "gate": ((r or {}).get("gate") or {}).get("verdict", ("reference" if r else "no data") if gate is None else ("diagnostic" if not gate else None)),
             "gate_vs_dflash_ref": ((r or {}).get("gate") or {}).get("vs_dflash_ref"),
             "probe_complete": _cmp_complete((r or {}).get("probe")), "probe_complete_vs_target": _cmp_complete((r or {}).get("probe_vs_target")),
             "server_alive_after": (r or {}).get("server_alive_after"), "lines_short": _w(r, "short", "lines"),
             "short_error": _w(r, "short", "error"), "long_error": _w(r, "long", "error"),''')
rep('''        _want = a.get("per_replica_streams") or a.get("level_wanted")
        a["capped"] = bool(_want and a.get("level_short") is not None and a["level_short"] < _want)''', '''        _want = a.get("per_replica_streams") or a.get("level_wanted")
        a["capped"] = bool(_want and a.get("level_short") is not None and a["level_short"] < _want)
        if a.get("layout") != "2xTP2" and _want and (a.get("level_long") is None or a["level_long"] < _want):
            a["capped"] = a["capped"] or bool(a.get("ok"))      # rev 2b (agent 1 F3): the 40k band counts too''')

# ---- _arm: slots-aware streams, launch timeout, family, graph-max dropped with an explicit graph list
rep('''    def _arm(name, set_=None, drop=(), streams=None, gate=True, probe=True, cap=12 * 60, env=None):
        s = dict(set_ or {})
        if streams:
            s.update(_streams(streams))
        _ok, _rec = e14_launch(name, set_=s, drop=drop, env=env)
        EMSR["launches"][name] = {k: _rec.get(k) for k in ("ok", "why", "sec", "caps", "skipped")}
        _lv = _level(_rec, streams or LEVEL)
        _r = e14_phase("EMS_" + name, _windows(name, _lv, gate=gate, probe=probe), _ts(cap)) if _ok else None
        return _record(name, _ok, _rec, _r, gate, {"set": s, "drop": list(drop), "level_wanted": streams or LEVEL})''',
    '''    def _arm(name, set_=None, drop=(), streams=None, gate=True, probe=True, cap=12 * 60, env=None, timeout=None):
        s = dict(set_ or {})
        if streams:
            s.update(_streams(streams, _slots(s)))
        drop = tuple(drop) + (("--cuda-graph-max-bs-decode",) if "--cuda-graph-bs-decode" in s else ())   # agent 1 F8
        _ok, _rec = e14_launch(name, set_=s, drop=drop, env=env, timeout=timeout)
        EMSR["launches"][name] = {k: _rec.get(k) for k in ("ok", "why", "sec", "caps", "skipped")}
        _lv = _level(_rec, streams or LEVEL)
        _r = e14_phase("EMS_" + name, _windows(name, _lv, gate=gate, probe=probe), _ts(cap)) if _ok else None
        fam = "mtp" if str(s.get("--speculative-algorithm", "")).upper() == "EAGLE" else ("target" if "--speculative-algorithm" in drop else "dflash")
        return _record(name, _ok, _rec, _r, gate, {"set": s, "drop": list(drop), "level_wanted": streams or LEVEL, "family": fam})''')

# ---- _gated: one oracle flag, complete probe, alive, both bands, lines, no cap (agent 1 F1, F3, F7, F9)
rep('''    def _gated(a):
        # EMS rev 2: judged against the target-only probe when it exists, else the DFlash reference's
        if EMSR.get("probe_tgt_aa"):
            _aa, _pf = (EMSR["probe_tgt_aa"].get("large_margin_flips") or 0), (a or {}).get("probe_flips_vs_target")
        else:
            _aa, _pf = ((EMSR.get("probe_ref_aa") or {}).get("large_margin_flips") or 0), (a or {}).get("probe_flips")
        return bool(a and a.get("ok") and a.get("gate") in ("PASS", "reference") and not a.get("log_errors")
                    and (_pf is None or _pf <= _aa + 1))''', '''    def _gated(a):
        """rev 2b: adoptable = gate PASS, complete probe evidence vs the SAME oracle as the gate (one flag), a live server,
        both bands measured with >= 8 decode lines, not capped, no log errors."""
        if not a or not a.get("ok") or a.get("gate") not in ("PASS", "reference") or a.get("log_errors"):
            return False
        if a.get("server_alive_after") is False or a.get("capped") or a.get("short_error") or a.get("long_error"):
            return False
        if (a.get("lines_short") or 0) < 8 or not a.get("short_tok_s") or not a.get("long_tok_s"):
            return False
        if EMSR.get("oracle") == "target_only":
            aa, ok_aa, pf, ok_pf = EMSR.get("probe_tgt_aa"), True, a.get("probe_flips_vs_target"), a.get("probe_complete_vs_target")
        else:
            aa, ok_aa, pf, ok_pf = EMSR.get("probe_ref_aa"), True, a.get("probe_flips"), a.get("probe_complete")
        if not _cmp_complete(aa) or not ok_pf or pf is None:
            return False
        return pf <= (aa.get("large_margin_flips") or 0) + 1''')

# ---- _gate_from_rows: dirty base rows = INCOMPLETE (agent 1 F2)
rep('''        ok = ps["ok"] and pc["ok"]
        return {"ok": ok, "verdict": "PASS" if ok else ("FAIL" if "FAIL" in (ps["verdict"], pc["verdict"]) else "INCOMPLETE"),
                "serial": ps, "all_at_once": pc}''', '''        ok = ps["ok"] and pc["ok"]
        v = "PASS" if ok else ("FAIL" if "FAIL" in (ps["verdict"], pc["verdict"]) else "INCOMPLETE")
        if _dirty_rows(base.get("serial_a"), base.get("serial_b"), base.get("conc_a"), base.get("conc_b")):
            ok, v = False, "INCOMPLETE"       # rev 2b: an A/A taken on a busy server is no reference
        return {"ok": ok, "verdict": v, "serial": ps, "all_at_once": pc}''')

# ---- reference record name
rep('''    _record("ref_dflash_w6_s16", True, {"caps": (E11_SGL.get("caps") or {}), "sec": ENGINE_INFO.get("load_sec")}, _r0, None,
            {"set": {}, "drop": [], "level_wanted": LEVEL})''', '''    _record(REF_NAME, True, {"caps": (E11_SGL.get("caps") or {}), "sec": ENGINE_INFO.get("load_sec")}, _r0, None,
            {"set": {}, "drop": [], "level_wanted": LEVEL, "family": "dflash", "flags": _RF})''')
rep('''    def _ref_probe():
        a, b = _probe("ref_a"), _probe("ref_b")
        globals()["EMS_PROBE_REF"] = (a, b)
        EMSR["probe_ref_aa"] = E14M.compare_passes(a, b, "reference probe A/A")
        return {"aa": EMSR["probe_ref_aa"]}''', '''    def _ref_probe():
        a, b = _probe("ref_a"), _probe("ref_b")
        globals()["EMS_PROBE_REF"] = (a, b)
        EMSR["probe_ref_aa"] = E14M.compare_passes(a, b, "reference probe A/A")
        return {"aa": EMSR["probe_ref_aa"], "server_not_idle": _dirty_rows(a, b)}''')

# ---- NTN: mamba 85 = 5 x 17 (agent 2 F1); no-op flags noted (agent 2 F6)
rep('''    _NTN.update(_MAMBA_RATIO)
    _ntn_drop = _SPEC + ("--max-mamba-cache-size", "--min-free-slots-delay")''', '''    _NTN.update(_MAMBA_RATIO)
    # rev 2b (agent 2 F1, kv_cache_configurator.py:2292-2330 / 2505-2545): with the auto size (ratio 0.5, fp32, 5 slots per
    # request) the server caps at ~11 (INT4) / ~9 (FP8) running; an explicit 5 x 17 = 85 slots makes it a 16-stream arm
    # (the ratio is then ignored, :2462-2484). --attention-backend flashinfer / --linear-attn-backend triton equal the
    # reference's resolved values and --max-prefill-tokens 4096 is moot under chunk 2048 (no-ops, kept as the bundle).
    _NTN["--max-mamba-cache-size"] = 5 * SGL_SERVER_MAX_RUNNING
    _ntn_drop = _SPEC + ("--min-free-slots-delay",)
    EMSR["notes"] = {"ntn": "NTN flag bundle + --max-mamba-cache-size 85 (5 x 17) so 16 streams fit; attention flashinfer / "
                            "linear triton = the reference's values; max-prefill 4096 moot under chunk 2048"}''')

# ---- oracle switch: target A/A complete AND target probe A/A complete, one flag (agent 1 F9, F10)
rep('''    _DFL = EMS_REF
    _tdrop = _SPEC + ("--min-free-slots-delay",)''', '''    _DFL = EMS_REF
    EMSR["oracle"] = "dflash_ref"
    _tdrop = _SPEC + ("--min-free-slots-delay",)''')
rep('''            ref, summ = _aa_rows("ems_tgt")
            if all(x["errors"] == 0 and x["compared"] > 0 for x in summ.values()):
                globals()["EMS_TGT"] = ref
            return dict(summ, complete=globals()["EMS_TGT"] is not None)''', '''            ref, summ = _aa_rows("ems_tgt")
            if summ["complete"]:      # rev 2b: no errors, no missing margins, not dirty
                globals()["EMS_TGT"] = ref
            return summ''')
rep('''            EMSR["dflash_vs_target_probe"] = (E14M.compare_passes(a, EMS_PROBE_REF[0][:len(a)], "DFlash reference probe vs target-only")
                                              if EMS_PROBE_REF else {"skipped": "no reference probe"})
            return {"aa": EMSR["probe_tgt_aa"], "dflash_vs_target": EMSR["dflash_vs_target_probe"]}''', '''            EMSR["dflash_vs_target_probe"] = (E14M.compare_passes(a, EMS_PROBE_REF[0][:len(a)], "DFlash reference probe vs target-only")
                                              if EMS_PROBE_REF else {"skipped": "no reference probe"})
            return {"aa": EMSR["probe_tgt_aa"], "dflash_vs_target": EMSR["dflash_vs_target_probe"], "server_not_idle": _dirty_rows(a, b)}''')
rep('''    if EMS_TGT:
        EMSR["gate_reference"] = "target_only (same INT4 checkpoint, no speculation)"''', '''    if EMS_TGT and not _cmp_complete(EMSR.get("probe_tgt_aa")):
        EMSR["gate_reference"] = "ref_dflash_w6 (target-only gate A/A complete, but its probe A/A was not)"
        EMS_TGT = None              # rev 2b: gate and probe always use the same oracle
    if EMS_TGT:
        EMSR["oracle"] = "target_only"
        EMSR["gate_reference"] = "target_only (same INT4 checkpoint, no speculation)"''')
rep('''        _ra = EMSR["arms"].get("ref_dflash_w6_s16")''', '''        _ra = EMSR["arms"].get(REF_NAME)''')
rep('''    EMSR["gate_reference"] = "ref_dflash_w6_s16 (target-only A/A unavailable)"''', '''    EMSR["gate_reference"] = REF_NAME + " (target-only A/A unavailable)"''')
rep('''_gate_from_rows(_DFL, EMS_TGT, "ref_dflash_w6_s16 vs target-only")''', '''_gate_from_rows(_DFL, EMS_TGT, REF_NAME + " vs target-only")''')

# ---- PLAN: ntn_fp8 30-min launch; fallback-aware skips (agent 2 F4, F7)
rep('''        ("ntn_fp8", dict(set_=dict(_NTN, **_mtp(path=MODEL_PATH), **{"--model-path": str(MODEL_PATH)}), drop=_ntn_drop,
                         gate=False, probe=False)),''', '''        ("ntn_fp8", dict(set_=dict(_NTN, **_mtp(path=MODEL_PATH), **{"--model-path": str(MODEL_PATH)}), drop=_ntn_drop,
                         gate=False, probe=False, timeout=30 * 60)),''')
rep('''    for _name, _kw in PLAN:
        _arm(_name, **_kw)
        if _name == "dflash_w6_s24":
            # the fastest gated MTP so far at 20 streams (the KV it frees is the reason to run it)
            _mt = {k: v for k, v in EMSR["arms"].items() if k.startswith("mtp_") and _gated(v) and v.get("short_tok_s")}''',
    '''    for _name, _kw in PLAN:
        _why = None
        if _name in ("dflash_w4", "dflash_w8") and int(_kw["set_"]["--speculative-num-draft-tokens"]) == _RW:
            _why = f"= the reference (it runs width {_RW})"
        if _name in ("dflash_w6_s20", "dflash_w6_s24") and E14_VENV["cfg"].get("streams12"):
            _why = "the reference fell back to 12 streams: 20 / 24 cannot fit the same memory"
        if _why:
            EMSR["arms"][_name] = {"ok": False, "skipped": _why}
            EMSR["order"].append(_name)
            continue
        _arm(_name, **_kw)
        if _name == "dflash_w6_s24":
            # the fastest gated MTP so far at 20 streams (the KV it frees is the reason to run it); rev 2b: by family
            _mt = {k: v for k, v in EMSR["arms"].items() if v.get("family") == "mtp" and _gated(v) and v.get("short_tok_s")}''')

# ---- the TP2 best-MTP pick by family
rep('''    _mt = {k: v for k, v in EMSR["arms"].items() if k.startswith("mtp_") and not k.endswith("_s20") and _gated(v)
           and v.get("short_tok_s")}''', '''    _mt = {k: v for k, v in EMSR["arms"].items() if v.get("family") == "mtp" and not k.endswith("_s20") and _gated(v)
           and v.get("short_tok_s")}''')

# ---- TP2: guarded start, slots-aware, custom AR off, 30-min wall, gate both, ok on all four windows, KV flag, log signs
rep('''            rec["skipped"] = "less than 15 min before the hard stop"
            return _record(name, False, rec, None, False, {"layout": "2xTP2"})''', '''            rec["skipped"] = "less than ~17 min before the hard stop"
            return _record(name, False, rec, None, False, {"layout": "2xTP2"})''')
rep('''        for r, (devs, port, nccl) in enumerate(((",".join(map(str, _pairs[0])), SGL_PORT, 41231),
                                                (",".join(map(str, _pairs[1])), SGL_PORT + 1, 41331))):
            s = dict(set_ or {})
            # ports: SGLang 0.5.21 without DP attention uses IPC temp files + the nccl port only (server_args.py:708-719)
            s.update({"--tp-size": 2, "--port": port, "--nccl-port": nccl, "--max-running-requests": per + 1,
                      "--cuda-graph-bs-decode": list(range(1, per + 2)), "--max-mamba-cache-size": 4 * (per + 1)})
            flags = e14_edit_flags(e11_flags(E14_VENV["cfg"]), drop=drop, set_=s)
            env = dict(E14_VENV["env"], CUDA_VISIBLE_DEVICES=devs)
            env.update(ems_replica_env(r))
            rec.setdefault("cache_dirs", []).append({k: env[k] for k in E14L.jit_cache_env()})
            srv = E11Server(E14_VENV["launch"] + flags, env, f"ems_{name}_r{r}")
            srv.start()
            servers.append((srv, port))
        t0, ready = time.perf_counter(), [False, False]
        limit = min(SGL_RELAUNCH_TIMEOUT_SEC, max(120.0, HARD_STOP - time.perf_counter() - 12 * 60))''', '''        try:          # rev 2b (agent 1 F13): a failed start never leaves the other replica running
            for r, (devs, port, nccl) in enumerate(((",".join(map(str, _pairs[0])), SGL_PORT, 41231),
                                                    (",".join(map(str, _pairs[1])), SGL_PORT + 1, 41331))):
                s = dict(set_ or {})
                # ports: SGLang 0.5.21 without DP attention uses IPC temp files + the nccl port only (server_args.py:708-719)
                s.update({"--tp-size": 2, "--port": port, "--nccl-port": nccl, **_streams(per, _slots(s)),
                          # rev 2b (agent 2 F3): at world size 2 the legacy CustomAllreduce turns on when the P2P test passes
                          # (custom_all_reduce_utils.py:442-512); here P2P measured 5.5x slower than NCCL (E14A p2p_sys)
                          "--disable-custom-all-reduce": None})
                flags = e14_edit_flags(e11_flags(E14_VENV["cfg"]), drop=tuple(drop) + ("--cuda-graph-max-bs-decode",), set_=s)
                env = dict(E14_VENV["env"], CUDA_VISIBLE_DEVICES=devs)
                env.update(ems_replica_env(r))
                rec.setdefault("cache_dirs", []).append({k: env[k] for k in E14L.jit_cache_env()})
                srv = E11Server(E14_VENV["launch"] + flags, env, f"ems_{name}_r{r}")
                srv.start()
                servers.append((srv, port))
        except Exception as e:
            rec["start_error"] = repr(e)[:300]
            for srv, _ in servers:
                srv.kill()
            _e11_gpu_free()
            return _record(name, False, rec, None, False, {"layout": "2xTP2", "error": rec["start_error"]})
        t0, ready = time.perf_counter(), [False, False]
        # rev 2b (agent 2 F5): two cold TP2 compiles at once (new per-GPU shapes): a 30-min wall, never past the hard stop
        limit = min(30 * 60, max(120.0, HARD_STOP - time.perf_counter() - 12 * 60))''')
rep('''            def run():
                out = {"gate_replica0": E14M.arm_gate(ctxs[0], _S, EMS_REF, tag="gate_" + name, identity=False)}
                for c in ctxs:
                    E14M.flush_cache(c)
                sw = _both(lambda c, i: E14M.steady_window(c, _S, level=per, secs=_ts(75), tag=f"{name}r{i}short"))
                lw = _both(lambda c, i: E14M.steady_window(c, _L, level=long_per, secs=_ts(75), tag=f"{name}r{i}long"))
                out.update(short=sw, long=lw, long_per_replica=long_per,
                           short_tok_s_sum=sum((x or {}).get("tok_s_p50") or 0 for x in sw),
                           long_tok_s_sum=sum((x or {}).get("tok_s_p50") or 0 for x in lw))
                return out''', '''            def run():
                # rev 2b (agent 1 F4): both replicas gated (in parallel), both logs scanned
                _off = [len(srv.log_text()) for srv, _ in servers]
                gates = _both(lambda c, i: _gate2(c, f"gate_{name}_r{i}"))
                out = {"gate_replicas": gates}
                for c in ctxs:
                    E14M.flush_cache(c)
                sw = _both(lambda c, i: E14M.steady_window(c, _S, level=per, secs=_ts(75), tag=f"{name}r{i}short"))
                lw = _both(lambda c, i: E14M.steady_window(c, _L, level=long_per, secs=_ts(75), tag=f"{name}r{i}long"))
                good = lambda x: bool(x) and bool(x.get("tok_s_p50")) and not x.get("error") and not x.get("skipped")
                out.update(short=sw, long=lw, long_per_replica=long_per, all_windows_ok=all(good(x) for x in sw + lw),
                           short_tok_s_sum=sum((x or {}).get("tok_s_p50") or 0 for x in sw),
                           long_tok_s_sum=sum((x or {}).get("tok_s_p50") or 0 for x in lw),
                           server_log_signs=[{s_: srv.log_text()[o:].count(s_) for s_ in E14_LOG_SIGNS if s_ in srv.log_text()[o:]}
                                             for (srv, _), o in zip(servers, _off)])
                vs = [(g or {}).get("verdict") for g in gates]
                out["gate_verdict"] = "PASS" if vs == ["PASS", "PASS"] else ("FAIL" if "FAIL" in vs else "INCOMPLETE")
                return out''')
rep('''                       {"ok": bool(all(ready) and res and not res.get("error") and (res.get("short_tok_s_sum") or 0) > 0),''',
    '''                       {"ok": bool(all(ready) and res and not res.get("error") and res.get("all_windows_ok")),
                        "kv_ok_for_production": bool(rec["replicas"]) and all(((x["caps"] or {}).get("kv_tokens") or 0) >= per * SGL_KV_PER_REQUEST
                                                                             for x in rec["replicas"]),
                        "log_errors": {k: v for x in (res or {}).get("server_log_signs") or [] for k, v in E14M.log_errors(x).items()},''')
rep('''                        "gate": (((res or {}).get("gate_replica0") or {}).get("verdict")),''', '''                        "gate": (res or {}).get("gate_verdict"),''')
p.write_text(t, encoding="utf-8", newline="\n")
print("patched")
