"""Exp 14 READMEs: rev 2d + rev 2e/2e-b/2e-c/2e-d sections (append / adjust only). Keeps each file's line endings."""
import hashlib
from pathlib import Path

ROOT = Path(r"D:/ARC AGI 2/experiments/Experiment 14 - Optimized Engine on 4xL4 (planned)")
NB = ROOT / "Experiment Notebooks"
S_EMS = hashlib.sha256((NB / "Q27-XHIGH-EMS_ENGINE_MATRIX_SGLANG.ipynb").read_bytes()).hexdigest()[:8]
S_VMS = hashlib.sha256((NB / "Q27-XHIGH-VMS_ENGINE_MATRIX_VLLM.ipynb").read_bytes()).hexdigest()[:8]
print("shas", S_EMS, S_VMS)


def patch(fn, pairs):
    p = ROOT / fn
    raw = p.read_bytes().decode("utf-8")
    crlf = "\r\n" in raw
    t = raw.replace("\r\n", "\n")
    for a, b in pairs:
        assert t.count(a) == 1, (fn, t.count(a), a[:70])
        t = t.replace(a, b)
    if crlf:
        t = t.replace("\n", "\r\n")
    p.write_bytes(t.encode("utf-8"))
    print("patched", fn, "crlf" if crlf else "lf")


patch("README_FINDINGS.md", [
    ("### 1.4 Concurrency\n", """### 1.3b SGLang radix-cache hits in real runs (log evidence, 2026-10-26)

Summed from the TP0 `Prefill batch, #new-token: X, #cached-token: Y` lines of our real Kaggle server logs:

| Runs | Radix-cache hit (cached / (new + cached)) |
|---|---|
| E15B EVAL120 R3K1 / R3K2 and the E15B SUBMIT commits | 91-93 % |
| EVAL120 G4B (LOW E16, XHIGH E16, XHIGH noE16) | 76-82 % |
| E14A SLIM R2 arms (the int8-mamba arm excluded: 1.1 % on 9 lines) | 59-78 % |

So the "hybrid prefix cache silently hits 0 %" concern (vLLM #45238 / #51250) has not been seen on our SGLang stack. EMS rev 2e-d still measures it per arm and band.

### 1.4 Concurrency
"""),
    ("| vLLM #53912 | hybrid MTP + prefix cache → empty / punctuation output | not proven on 0.32.0 | VMS oracle with prefix caching off + a degenerate-output count |",
     "| vLLM #53912 | hybrid MTP + prefix cache → empty / punctuation output | not proven on 0.32.0 | VMS oracle with prefix caching off; a grid-aware degenerate count over every started stream, with empty outputs counted separately (rev 2e / 2e-c) |"),
    ("| SGLang #36548 / #38009 | DFlash2 greedy output differs from plain decoding, worse when concurrent (other GPUs) | not reproduced on L4 | target-only identity oracle in EMS; every arm gets a verdict vs it and vs the DFlash reference |",
     "| SGLang #36548 / #38009 | DFlash2 greedy output differs from plain decoding, worse when concurrent (other GPUs) | not reproduced on L4 | target-only identity oracle in EMS; every arm gets a verdict vs it and vs the DFlash reference. rev 2e adds three guards: fail closed without the oracle, a cross-request sentinel canary, and an ~85k-context XL parity |"),
    ("| 10-26 | my first `vms_degenerate` used a distinct-character ratio that flags every long normal text | local harness |",
     """| 10-26 | my first `vms_degenerate` used a distinct-character ratio that flags every long normal text | local harness |
| 10-26 | rev 2b report lines and the try/except around the EMS body never applied (a silent `str.replace` miss) | rev 2d build; now asserted replacements |
| 10-26 | rev 2e dropped every window whose prefill did not settle in 120 s: the no-prefix arm (16 x 40k prefill) would lose valid data | self-audit (rev 2e-b): 300 s budget, kept as `mixed_load` |
| 10-26 | the rev 2e tail / degenerate rules flagged a normal ARC grid ("0 0 0 ...") as degenerate, which would FAIL correct arms | self-audit (rev 2e-c): grid-aware shared rule |
| 10-26 | the reports said BOUNDARY is "never auto-certified" while `adoptable` accepts it; the VMS no-prefix note said tok/s includes the prefix recompute (it is decode after settle) | self-audit (rev 2e-d): text fixed, `certified_exact` column |
| 10-26 | a first rev 2e-d try put the prefix-hit count in `src/e14_measure.py`, but the notebooks load the E14 modules from the Kaggle payload dataset shared with E15P | caught before any push; reverted, done inside the EMS cell |"""),
    ("## 6. Open (to be answered by the EMS / VMS GPU runs)\n",
     f"""## 6. Open (to be answered by the EMS / VMS GPU runs)

Status of the matrices: rev 2e-d (2026-10-26), EMS `{S_EMS}`, VMS `{S_VMS}`. Both independent audits of rev 2c were checked item by item and applied; see `Bug ang fix/EMS_VMS_rev2e_independent_audits_disposition_2026-10-26.md` and section 7.
"""),
    ("8. **Not in the 200-min matrices** (next round): target-only at 12/20/24, chunked prefill 2048 vs 4096, radix strategy (lazy / extra / none), `SGLANG_ENABLE_PCIE_IPC_ALLREDUCE`, vLLM `--language-model-only`, `--kv-cache-dtype auto`.",
     """8. **Not in the matrices** (next round): target-only at 12/20/24, chunked prefill 2048 vs 4096, radix strategy (lazy / extra / none), vLLM `--language-model-only`, `--kv-cache-dtype auto`. PCIe-IPC all-reduce has been in the matrices since rev 2d (`dflash_w6_pcie`, `mtp_3_1_4_pcie`, `fp8_mtp3_pcie`).
9. Speed at production context: the XL band (~85k block, positions to ~93k) per arm (rev 2d).
10. The real KV gain of the PR #45151 patch (KV tokens of `mtp_3_1_4_pr45151` vs `mtp_3_1_4`).

## 7. Before any production switch (cannot be closed on CPU)

1. The EMS and VMS GPU runs (user go; ~260 min each, ~9 h quota at 2x). The EMS PCIe arms and all of VMS need the dataset `foysalemonshanto/vllm-0-32-0-cu13-wheelhouse` attached.
2. Long generation (60k+ output tokens, with churn and rejected drafts) on the winner. The matrix covers only 256-token greedy gates, a 1,024-token probe and 75-s windows (the XL windows decode up to 8k tokens).
3. A real ARC task run (Poetiq / Duck) at production sampling (temperature 1, top_p 0.95, top_k 20) on the winner.
4. A BOUNDARY winner (near-tie divergences only: adoptable, but not bit-exact) must also be confirmed on ARC task accuracy. `certified_exact` marks the PASS_EXACT arms."""),
])

patch("README_PURPOSE_AND_WORK.md", [
    ("- **GPT audit packs:** `Experiment Review/ENGINE_MATRIX_EMS_VMS_REV2B_AUDIT_FOR_GPT_2026-10-26.zip`, then `..._REV2C_...zip` (current).\n",
     """- **GPT audit packs:** `Experiment Review/ENGINE_MATRIX_EMS_VMS_REV2B_AUDIT_FOR_GPT_2026-10-26.zip`, then `..._REV2C_...zip`, then `..._REV2E_...zip` (current).
- **rev 2d (user: "take 1 and 2"):** see `Bug ang fix/Rev2d_long_context_and_pcie_ipc_2026-10-26.md`.
  - An XL band: a shared ~85k-token block, streams = KV // 100k, a third 75-s window on every TP4 arm.
  - FlashInfer PCIe-IPC all-reduce arms:
    - EMS `dflash_w6_pcie` and `mtp_3_1_4_pcie`, through a FlashInfer 0.7.0.post1 overlay from the vLLM wheelhouse;
    - VMS `fp8_mtp3_pcie`, through the native `VLLM_ALLREDUCE_USE_FLASHINFER_PCIE_IPC`.
  - Budget 200 → 260 min.
  - rev 2d-b: the rev 2b report / try-except edits had silently not applied. They are now applied with asserts.
- **rev 2e: the two independent audits of rev 2c**, `Bug ang fix/README_EMS_VMS_REV2C_INDEPENDENT_AUDIT_2026-10-26.md` and `Bug ang fix/ENGINE_MATRIX_REV2C_INDEPENDENT_AUDIT_README_BN.md`.
  - Every item was checked in the code and the sources before the change. Disposition, item by item: `Bug ang fix/EMS_VMS_rev2e_independent_audits_disposition_2026-10-26.md`.
  - Fail closed: nothing is adoptable without the target-only oracle (EMS `_gated`, VMS `oracle_ready`).
  - VMS compares integer token ids (`return_token_ids`). Every greedy row needs `[DONE]` + `finish_reason`, else it is `INCOMPLETE_SSE`.
  - `gate_class` = INCOMPLETE / FAIL / BOUNDARY / PASS_EXACT, plus a post-divergence tail check.
  - Only healthy windows count: no stream error, empty or degenerate output, and an EMS running share ≥ 0.80 (our proposed bar).
  - VMS joins the streams, then requires an idle server between windows (otherwise `DIRTY_SERVER_AFTER_WINDOW`).
  - VMS records both decode tok/s and end-to-end tok/s. EMS tok/s is labelled decode only.
  - Prefix-cache counters: VMS reads the vLLM metrics. EMS (rev 2e-d) reads the SGLang prefill log lines.
  - Also added: a cross-request sentinel canary, an XL parity gate, and separate `measurement_ok` / `capacity_ok` / `correctness_ok` / `adoptable` fields.
  - The #45151 patch:
    - is written atomically, with both snippets verified;
    - is backed up and its sha recorded;
    - its arm is skipped unless the patch applied.
  - `ntn_fp8` moved after the 20/24-stream arms.
- **Self-audit (user: "research before changing, remove nothing without evidence"):**
  - **rev 2e-b:** an unsettled VMS window is kept as `mixed_load` (settle budget 300 s), not dropped. The next band is skipped only after a dirty or dead server.
  - **rev 2e-c:** a grid-aware degenerate / tail rule. The old rules flagged normal ARC grids.
  - **rev 2e-d:**
    - The report text now matches the code: BOUNDARY is adoptable under the documented near-tie rule, but it is not bit-exact. A `certified_exact` column was added.
    - The stale VMS no-prefix note was fixed.
    - EMS prefix-cache hits are measured inside the EMS cell, because the shared `e14_measure` comes from the Kaggle payload dataset.
"""),
    ("| 12 | Last: 2 x TP2 (DFlash W6, then the best MTP) |",
     """| 12 | Last: 2 x TP2 (DFlash W6, then the best MTP) |
| + | rev 2d: `dflash_w6_pcie` and `mtp_3_1_4_pcie` (PCIe-IPC all-reduce); an XL band on every TP4 arm. rev 2e: `ntn_fp8` runs after the 20/24-stream arms |"""),
    ("| 9 | Last: DP2 x TP2, FP8 and INT4 |",
     """| 9 | Last: DP2 x TP2, FP8 and INT4 |
| + | rev 2d: `fp8_mtp3_pcie` first after the oracle; an XL band. The order since rev 2e: pcie, noprefix, mtp2, mtp4, s20, s24, lb_triton, ssm_fp16, int4_s16, int4_s20 |"""),
    ("Time: about 10-15 min per arm. In 200 min the reference, the oracle, ~7-9 arms and the reserved TP2 slot fit. Later arms are skipped and recorded, never squeezed.",
     "Time: about 10-15 min per arm, plus the XL band. The budget is 260 min (rev 2d). Arms that do not fit are recorded as `NOT_TESTED_BUDGET: <reason>`; they are never squeezed and never reported as tested."),
    ("4. **GPU:** only on the user's go. The account needs ≥ 2 x 210 min of quota. Push with QUICK_SAVE and commit from the editor.",
     "4. **GPU:** only on the user's go. The account needs ≥ 2 x 270 min of quota (~9 h quota each at 2x). Attach the vLLM wheelhouse dataset to both notebooks. Push with QUICK_SAVE and commit from the editor."),
    ("## Status (2026-10-26)\n",
     f"""## Status (2026-10-26)

- **Current: EMS rev 2e-d** (`{S_EMS}`) and **VMS rev 2e-d** (`{S_VMS}`).
  - Local Python 3.12 harnesses: see `_scratch/ems/run13_py312.log` and `_scratch/vms/run13_py312.log`.
  - The Kaggle CPU kit v4 on these shas is pending.
  - GPT pack: `Experiment Review/ENGINE_MATRIX_EMS_VMS_REV2E_AUDIT_FOR_GPT_2026-10-26.zip`.
  - Open before production: `README_FINDINGS.md` section 7.
- Earlier (superseded):
"""),
])
