"""VMS rev 2e: the two independent GPT audits of rev 2c (2026-10-26; READMEs in Experiment 14 "Bug ang fix"), every
claim checked in the code / the vLLM v0.32.0 source before the change. The V1 measurement block (VGen .. vms_diverge) and
the V2 judging block (vms_aa .. vms_arm) are replaced as wholes; every other change is an asserted replacement."""
from pathlib import Path

p = Path(r"D:/ARC AGI 2/experiments/Experiment 14 - Optimized Engine on 4xL4 (planned)/Experiment Notebooks/Build/build_vms.py")
t = p.read_text(encoding="utf-8")


def rep(a, b, n=1):
    global t
    assert t.count(a) == n, (t.count(a), a[:100])
    t = t.replace(a, b)


def between(a, b, new):
    global t
    i, j = t.index(a), t.index(b)
    assert t.count(a) == 1 and t.count(b) == 1 and i < j, (a[:60], b[:60])
    t = t[:i] + new + t[j:]


rep("usage: python build_vms.py", """rev 2e (two independent GPT audits of rev 2c, 2026-10-26): integer token ids (return_token_ids; logprobs.tokens are
strings); [DONE] + finish_reason required for every greedy row; a post-divergence tail check; PASS_EXACT vs BOUNDARY;
oracle_ready (no certification without the target-only oracle); healthy windows (no stream error / empty / degenerate,
held level, running share); idle gate after every window; prefill-settle required; end-to-end tok/s, prefix-cache hits;
a cross-request sentinel canary; an XL (~85k) greedy parity check; measurement_ok / correctness_ok / capacity_ok /
adoptable kept apart; the order of the audit (no-prefix and MTP width before the INT4 and SSM arms).
usage: python build_vms.py""")

V1_NEW = r'''class VGen(threading.Thread):
    """One streaming /v1/completions request with prompt token ids; stop() closes the stream (vLLM aborts it).
    rev 2e (GPT audits E1, HIGH-2): integer token ids from return_token_ids (completion/protocol.py:171-180,
    serving.py:417-421; logprobs.tokens are decoded strings), the terminal [DONE] and the finish_reason recorded; a request
    we did not stop that lacks either is an error, never a valid row."""
    def __init__(self, ids, max_new, temperature=1.0, ignore_eos=True, seed=None, logprobs=0):
        super().__init__(daemon=True)
        self.body = {"model": "q27", "prompt": list(ids), "max_tokens": int(max_new), "temperature": temperature,
                     "top_p": 0.95 if temperature else 1.0, "top_k": 20 if temperature else -1, "stream": True,
                     "ignore_eos": ignore_eos, "return_token_ids": True}
        if seed is not None:
            self.body["seed"] = seed
        if logprobs:
            self.body["logprobs"] = int(logprobs)      # rev 2b: the gate compares tokens and top-1 / top-2 margins
        self.text, self.err, self._resp, self._halt = [], None, None, False   # NOT _stop: Thread._stop() is a method join() calls (Py3.12)
        self.tokens, self.margins = [], []
        self.done_seen, self.finish_reason, self.first_token_at = False, None, None

    def run(self):
        try:
            req = _urlreq.Request(VMS_URL + "/v1/completions", data=json.dumps(self.body).encode(), method="POST",
                                  headers={"Content-Type": "application/json"})
            self._resp = _urlreq.urlopen(req, timeout=3600)
            for raw in self._resp:
                if self._halt:
                    break
                line = raw.strip()
                if not line.startswith(b"data:"):
                    continue
                payload = line[5:].strip()
                if payload == b"[DONE]":
                    self.done_seen = True
                    break
                d = json.loads(payload)
                if "error" in d or d.get("object") == "error":     # rev 2b: an in-stream error event (serving.py:497-503)
                    self.err = ("stream error: " + json.dumps(d.get("error") or d.get("message") or d))[:200]
                    break
                for c in d.get("choices") or []:
                    self.text.append(c.get("text") or "")
                    ids_ = c.get("token_ids")
                    lp = c.get("logprobs") or {}
                    if ids_ is None:
                        if c.get("text") or lp.get("tokens"):
                            self.err = "MISSING_STREAM_TOKEN_IDS"
                    elif any(not isinstance(v, int) or isinstance(v, bool) for v in ids_):
                        self.err = "INVALID_STREAM_TOKEN_IDS"
                    else:
                        if ids_ and self.first_token_at is None:
                            self.first_token_at = time.perf_counter()
                        self.tokens.extend(ids_)
                    for top in lp.get("top_logprobs") or []:
                        vals = sorted((v for v in (top or {}).values() if isinstance(v, (int, float))), reverse=True)
                        self.margins.append(round(vals[0] - vals[1], 4) if len(vals) >= 2 else None)
                    if c.get("finish_reason") is not None:
                        self.finish_reason = c["finish_reason"]
                if self.err:
                    break
        except Exception as e:
            if not self._halt:
                self.err = repr(e)[:200]
        if not self._halt and not self.err and not (self.done_seen and self.finish_reason):
            self.err = "INCOMPLETE_SSE: [DONE] seen %s, finish_reason %s" % (self.done_seen, self.finish_reason)

    def stop(self):
        self._halt = True
        try:      # rev 2b: shut the socket down first, so a reader blocked in recv returns (close() alone can wait on it)
            self._resp.fp.raw._sock.shutdown(socket.SHUT_RDWR)
        except Exception:
            pass
        try:
            if self._resp is not None:
                self._resp.close()
        except Exception:
            pass

    def row(self):
        return {"text": "".join(self.text), "tokens": list(self.tokens), "margins": list(self.margins), "error": self.err,
                "done_seen": self.done_seen, "finish_reason": self.finish_reason}


def _vms_dead():
    return VMS_SERVER is not None and not VMS_SERVER.alive()


def vms_idle(wait=60.0):
    """rev 2e (GPT audit E6): 0 running and 0 waiting in 3 consecutive samples (2 s apart) within `wait`."""
    end, hits = time.perf_counter() + wait, 0
    while time.perf_counter() < end:
        try:
            p = vms_prom()
            hits = hits + 1 if (_met(p, "vllm:num_requests_running") == 0 and _met(p, "vllm:num_requests_waiting") == 0) else 0
        except Exception:
            hits = 0
        if hits >= 3:
            return True
        time.sleep(2)
    return False


def vms_window(prompts, level, secs, tag, deadline=None):
    """`level` streams; wait until vllm:num_requests_running reaches level, a stable level - 1, or a KV plateau (requests
    waiting while running stays flat for 30 s); then wait for the prefill to settle; then measure the counters.
    rev 2b: every wait ends at `deadline` (the arm's own: the 2 x TP2 reserve stays intact) and on a dead server.
    rev 2e (GPT audits E5-E7, HIGH-5, E9): the prefill must settle (3 equal prompt-token readings) or the window is
    PREFILL_NOT_SETTLED; the streams are joined and the server must be idle afterwards (else DIRTY_SERVER_AFTER_WINDOW);
    every started stream is checked for empty / degenerate text; steady decode tok/s and end-to-end output tok/s (from
    submission) are both kept; prefix-cache hits / queries / cached prompt tokens are recorded."""
    end = min(HARD_STOP - 120, deadline or HARD_STOP)
    if end - time.perf_counter() < secs + 60:
        return {"skipped": "NOT_TESTED_BUDGET: deadline"}
    gens = [VGen(prompts[i % len(prompts)], 8192) for i in range(level)]
    out = {"tag": tag, "level": level}
    p_sub = p0 = p1 = None
    t_sub = t0 = t1 = None
    try:
        try:
            p_sub = vms_prom()
        except Exception:
            p_sub = {}
        t_sub = time.perf_counter()
        for g in gens:
            g.start()
        t_w, got, best, hist, plateau = time.perf_counter(), None, 0, [], False
        while time.perf_counter() < min(t_w + 900, end - secs - 30):
            if _vms_dead():
                out["error"] = "the server died while the streams were admitted"
                return out
            try:
                p = vms_prom()
                run, wait = _met(p, "vllm:num_requests_running"), _met(p, "vllm:num_requests_waiting")
            except Exception:
                run, wait = 0, 0
            best = max(best, run)
            hist.append((time.perf_counter(), run))
            if run >= level:
                got = level
                break
            flat = [r for t_, r in hist if t_ >= hist[-1][0] - 30]
            if wait > 0 and run >= 1 and hist[-1][0] - hist[0][0] >= 30 and len(set(flat)) == 1:
                got, plateau = int(run), True        # KV-bound: measure what the server really holds
                break
            time.sleep(2)
        if got is None and best >= level - 1:
            got = int(best)
        out.update(measured_level=got, plateau=plateau, capacity_limited=plateau, wait_sec=round(time.perf_counter() - t_w, 1))
        if got is None:
            out["error"] = f"the server never ran {level} requests (max {best})"
            return out
        # a request counts as running once its first prefill chunk is scheduled: start only when nothing waits (or the
        # plateau) and 3 consecutive prompt-token readings are equal (<= 120 s)
        t_s, last, stable, settled = time.perf_counter(), None, 0, False
        while time.perf_counter() - t_s < 120 and time.perf_counter() < end - secs - 15:
            try:
                p = vms_prom()
                pt, wait = _met(p, "vllm:prompt_tokens_total"), _met(p, "vllm:num_requests_waiting")
            except Exception:
                break
            stable = stable + 1 if (last is not None and pt == last and (wait == 0 or plateau)) else 0
            if stable >= 2:
                settled = True
                break
            last = pt
            time.sleep(2)
        out.update(settle_sec=round(time.perf_counter() - t_s, 1), prefill_settled=settled)
        if not settled:
            out["error"] = "PREFILL_NOT_SETTLED"
            return out
        p0, t0 = vms_prom(), time.perf_counter()
        runs, kvs = [], []
        while time.perf_counter() - t0 < secs:
            time.sleep(2)
            if _vms_dead():
                out["error"] = "the server died inside the window"
                return out
            try:
                p = vms_prom()
                runs.append(_met(p, "vllm:num_requests_running"))
                kvs.append(p.get("vllm:kv_cache_usage_perc@max", 0.0))      # rev 2b: per engine, never the DP sum
            except Exception:
                pass
        p1, t1 = vms_prom(), time.perf_counter()
        out["_runs"], out["_kvs"] = runs, kvs
    except Exception as e:
        out["error"] = f"{type(e).__name__}: {e}"[:300]
        return out
    finally:
        for g in gens:
            g.stop()
        for g in gens:
            if g.ident is not None:
                g.join(timeout=5)
        out["threads_not_joined"] = sum(1 for g in gens if g.is_alive())
        out["idle_after"] = (not _vms_dead()) and vms_idle(60)
        if out["threads_not_joined"] or not out["idle_after"]:
            out["error"] = out.get("error") or "DIRTY_SERVER_AFTER_WINDOW"
        started = [g for g in gens if g.first_token_at is not None]
        texts = ["".join(g.text) for g in started]
        out.update(no_first_token=len(gens) - len(started), empty_outputs=sum(1 for x in texts if not x.strip()),
                   degenerate=vms_degenerate(texts), stream_errors=sum(1 for g in gens if g.err),
                   stream_error_samples=[g.err for g in gens if g.err][:3])
    runs, kvs = out.pop("_runs", []), out.pop("_kvs", [])
    dt = t1 - t0
    gen = _met(p1, "vllm:generation_tokens_total") - _met(p0, "vllm:generation_tokens_total")
    acc = _met(p1, "vllm:spec_decode_num_accepted_tokens_total") - _met(p0, "vllm:spec_decode_num_accepted_tokens_total")
    drf = _met(p1, "vllm:spec_decode_num_drafts_total") - _met(p0, "vllm:spec_decode_num_drafts_total")
    gen_all = _met(p1, "vllm:generation_tokens_total") - _met(p_sub, "vllm:generation_tokens_total")
    out.update(window_sec=round(dt, 1), tok_s=round(gen / dt, 1) if dt > 0 else None,
               end_to_end_tok_s=round(gen_all / (t1 - t_sub), 1) if t1 and t_sub and t1 > t_sub else None,
               accept=round(1 + acc / drf, 2) if drf > 0 else None, running_mean=round(statistics.mean(runs), 2) if runs else None,
               kv_max=round(max(kvs), 3) if kvs else None,
               preemptions=_met(p1, "vllm:num_preemptions_total") - _met(p0, "vllm:num_preemptions_total"),
               prefix_cache_hits=_met(p1, "vllm:prefix_cache_hits_total") - _met(p_sub, "vllm:prefix_cache_hits_total"),
               prefix_cache_queries=_met(p1, "vllm:prefix_cache_queries_total") - _met(p_sub, "vllm:prefix_cache_queries_total"),
               prompt_tokens_cached=_met(p1, "vllm:prompt_tokens_cached_total") - _met(p_sub, "vllm:prompt_tokens_cached_total"))
    return out


def vms_window_healthy(w, level):
    """rev 2e (2nd audit HIGH-3): speed is evidence only from a clean window that held its level."""
    return bool(w) and not w.get("error") and not w.get("skipped") and (w.get("tok_s") or 0) > 0 \
        and w.get("stream_errors", 0) == 0 and w.get("empty_outputs", 0) == 0 and w.get("degenerate", 0) == 0 \
        and (w.get("measured_level") or 0) >= level and (w.get("running_mean") or 0) >= 0.80 * level


def vms_greedy(prompts, n_tok=256, concurrent=False, deadline=None):
    """Greedy rows {text, token ids, top-1 / top-2 margins, error, [DONE], finish_reason}; rev 2b: one deadline for the
    whole pass; a row still running at the deadline is stopped and marked."""
    end = min(HARD_STOP - 120, deadline or HARD_STOP)
    gens = [VGen(p, n_tok, temperature=0.0, ignore_eos=False, logprobs=2) for p in prompts]
    if concurrent:
        for g in gens:
            g.start()
        for g in gens:
            g.join(max(0.0, min(900, end - time.perf_counter())))
    else:
        for g in gens:
            if end - time.perf_counter() < 30:
                g.err = "skipped: arm deadline"
                continue
            g.start()
            g.join(max(0.0, min(900, end - time.perf_counter())))
    for g in gens:
        if g.is_alive():
            g.stop()
            g.err = g.err or "stopped: arm deadline"
    return [g.row() for g in gens]


def vms_degenerate(texts):
    """rev 2 (GPT audit V1, vLLM #53912: silent empty / repeated-punctuation output with a normal finish): empty text, a
    run of 32+ identical characters, or >= 200 characters with < 8 distinct characters or < 10 % letters / digits.
    (A distinct-character RATIO would flag every long normal text: 8k characters of prose use ~100 distinct ones.)"""
    bad = 0
    for x in texts:
        s = (x or "").strip()
        if not s:
            bad += 1
            continue
        if re.search(r"(.)\1{31,}", s):
            bad += 1
            continue
        if len(s) >= 200 and (len(set(s)) < 8 or sum(ch.isalnum() for ch in s) / len(s) < 0.10):
            bad += 1
    return bad


def vms_kernels(txt):
    """rev 2 (GPT audit V6): the GEMM / attention kernels vLLM says it selected (never assume the default)."""
    seen = []
    for ln in txt.splitlines():
        m = re.search(r"((?:Selected|Using|Chose)\b.{0,60}?(?:kernel|backend).{0,80}|--linear-backend=.{0,160})", ln, re.I)
        if m and m.group(1).strip() not in seen:
            seen.append(m.group(1).strip())
    return seen[:30]


def vms_tail_bad(ids):
    """rev 2e (GPT audits E2 / HIGH-10): a continuation that degenerated after the first divergence: 16+ identical token
    ids in a row, or more than 50 % of its 8-grams repeated."""
    ids = list(ids or [])
    run = best = 0
    for i_ in range(1, len(ids)):
        run = run + 1 if ids[i_] == ids[i_ - 1] else 0
        best = max(best, run)
    grams = [tuple(ids[i_:i_ + 8]) for i_ in range(max(0, len(ids) - 7))]
    rep_ = 1 - len(set(grams)) / len(grams) if len(grams) >= 32 else 0.0
    return best >= 15 or rep_ > 0.5


def vms_diverge(a, b):
    """rev 2b (agent 3 F10): rows compared by integer token id (rev 2e) with the EMS compare_passes rule. A large-margin
    flip = a divergence where either run was confident (top-1 minus top-2 > 1 nat); a divergence without both margins is
    missing evidence, never "no flip"; an errored, incomplete (no [DONE] / finish_reason) or empty row is an error."""
    expected = max(len(a), len(b))
    per = []
    for i in range(expected):
        ra = a[i] if i < len(a) else {"error": "missing row"}
        rb = b[i] if i < len(b) else {"error": "missing row"}
        ia, ib = list(ra.get("tokens") or []), list(rb.get("tokens") or [])
        inc = [x for x in (ra, rb) if "done_seen" in x and not (x.get("done_seen") and x.get("finish_reason"))]
        if ra.get("error") or rb.get("error") or inc or not ia or not ib:
            per.append({"error": ra.get("error") or rb.get("error") or ("incomplete stream" if inc else "no tokens")})
            continue
        if ia == ib:
            per.append({"identical": True})
            continue
        k = next((j for j, (u, v) in enumerate(zip(ia, ib)) if u != v), min(len(ia), len(ib)))
        ma = (ra.get("margins") or [None] * (k + 1))[k] if k < len(ra.get("margins") or []) else None
        mb = (rb.get("margins") or [None] * (k + 1))[k] if k < len(rb.get("margins") or []) else None
        per.append({"identical": False, "first_divergence": k, "margin_a": ma, "margin_b": mb,
                    "missing_margin": ma is None or mb is None,
                    "large_margin_flip": ma is not None and mb is not None and max(ma, mb) > 1.0,
                    "tail_bad": vms_tail_bad(ib[k:])})
    ok = [x for x in per if "identical" in x]
    div = [x for x in ok if not x["identical"]]
    return {"expected": expected, "compared": len(ok), "errors": expected - len(ok),
            "identical": sum(1 for x in ok if x["identical"]), "differ": len(div),
            "large_margin_flips": sum(1 for x in div if x["large_margin_flip"]),
            "missing_margins": sum(1 for x in div if x["missing_margin"]),
            "tail_bad": sum(1 for x in div if x.get("tail_bad")),
            "first_divergence": [x.get("first_divergence") for x in per]}


'''
between("class VGen(threading.Thread):", "VMS_INST = None\nif VMS_ON:", V1_NEW)

V2_NEW = r'''def vms_aa(name, deadline=None):
    rows = {"serial_a": vms_greedy(_S[:6], deadline=deadline), "serial_b": vms_greedy(_S[:6], deadline=deadline),
            "conc_a": vms_greedy(_S, concurrent=True, deadline=deadline), "conc_b": vms_greedy(_S, concurrent=True, deadline=deadline)}
    if _X:      # rev 2e (GPT audits MEDIUM-7 / E11): a greedy parity reference at ~85k context too
        rows["xl_a"] = vms_greedy(_X[:4], concurrent=True, deadline=deadline)
        rows["xl_b"] = vms_greedy(_X[:4], concurrent=True, deadline=deadline)
    vms_save_rows(name + "_aa", rows)
    s, c = vms_diverge(rows["serial_a"], rows["serial_b"]), vms_diverge(rows["conc_a"], rows["conc_b"])
    complete = all(x["expected"] and x["compared"] == x["expected"] and not x["missing_margins"] for x in (s, c))
    return rows, {"serial": s, "conc": c, "complete": complete,
                  "xl": vms_diverge(rows["xl_a"], rows["xl_b"]) if _X else None,
                  "degenerate": vms_degenerate(_texts(rows["serial_a"] + rows["serial_b"] + rows["conc_a"] + rows["conc_b"]))}


def vms_judge(s, c, base, gate=True):
    """The EMS parity rule on integer-token rows against `base` (the oracle once it exists): large-margin flips may not
    exceed base's own A/A flips (serial and all at once); no more degenerate outputs than base's A/A; rev 2e: no more
    degenerated continuations after a divergence than base's A/A; INCOMPLETE when any compared row errored, was
    incomplete or a divergence has no margins (fail closed). gate_class: PASS_EXACT = every sequence identical,
    BOUNDARY = a PASS with near-tie divergences (a candidate for task-level evaluation, never auto-certified)."""
    cs, aa_s = vms_diverge(base["serial_a"], s), vms_diverge(base["serial_a"], base["serial_b"])
    cc, aa_c = vms_diverge(base["conc_a"], c), vms_diverge(base["conc_a"], base["conc_b"])
    dg, dg_aa = vms_degenerate(_texts(list(s) + list(c))), vms_degenerate(_texts(base["serial_a"] + base["conc_a"]))
    d = {"serial": cs, "conc": cc, "aa_serial": aa_s, "aa_conc": aa_c, "degenerate": dg, "aa_degenerate": dg_aa}
    if not gate:
        return "diagnostic", d
    if any(x["errors"] or x["missing_margins"] or not x["compared"] for x in (cs, aa_s, cc, aa_c)):
        d["gate_class"] = "INCOMPLETE"
        return "INCOMPLETE", d
    passed = cs["large_margin_flips"] <= aa_s["large_margin_flips"] and cc["large_margin_flips"] <= aa_c["large_margin_flips"] \
        and dg <= dg_aa and cs["tail_bad"] + cc["tail_bad"] <= aa_s["tail_bad"] + aa_c["tail_bad"]
    d["gate_class"] = ("PASS_EXACT" if cs["identical"] == cs["compared"] and cc["identical"] == cc["compared"] else "BOUNDARY") \
        if passed else "FAIL"
    return ("PASS" if passed else "FAIL"), d


def vms_judge_xl(x, base):
    """rev 2e: the ~85k greedy rows against the oracle's own XL A/A (flips and tails decide, as above)."""
    if not base.get("xl_a") or not x:
        return None
    cx, aa = vms_diverge(base["xl_a"], x), vms_diverge(base["xl_a"], base["xl_b"])
    if any(r["errors"] or r["missing_margins"] or not r["compared"] for r in (cx, aa)):
        return {"verdict": "INCOMPLETE", "cmp": cx, "aa": aa}
    ok = cx["large_margin_flips"] <= aa["large_margin_flips"] and cx["tail_bad"] <= aa["tail_bad"]
    return {"verdict": "PASS" if ok else "FAIL", "cmp": cx, "aa": aa}


VMS_CANARY = {}


def vms_canary(level, deadline=None):
    """rev 2e (GPT audit MEDIUM-9, SGLang #36548 cross-request bleed): `level` concurrent greedy requests, each asked to
    repeat its own random sentinel (thinking off); a sentinel found in ANOTHER request's output is a leak."""
    import random as _rnd
    rng = _rnd.Random(SEED + level)
    sent = ["Z%04d-%s" % (i, "".join(rng.choice("QWXJVK") for _ in range(6))) for i in range(level)]
    ids = [tokenizer.encode(tokenizer.apply_chat_template([{"role": "user", "content":
           f"Repeat this code exactly once and nothing else: {s_}"}], tokenize=False, add_generation_prompt=True,
           enable_thinking=False), add_special_tokens=False) for s_ in sent]
    rows = vms_greedy(ids, n_tok=32, concurrent=True, deadline=deadline)
    own = sum(1 for s_, r in zip(sent, rows) if s_ in (r.get("text") or ""))
    leaks = sum(1 for i, r in enumerate(rows) for j, s_ in enumerate(sent) if j != i and s_ in (r.get("text") or ""))
    return {"level": level, "own_hits": own, "foreign_leaks": leaks, "errors": sum(1 for r in rows if r.get("error"))}


def vms_arm(name, flags, *, level=16, gate=True, env_extra=None, cap=14 * 60):
    ok, rec = vms_launch(name, flags, env_extra)
    a = {"ok": False, "launch_sec": rec.get("sec"), "kv_tokens": rec.get("kv_tokens"), "skipped": rec.get("skipped"),
         "flags": flags, "env": env_extra or {}, "level_wanted": level, "kernels": rec.get("kernels")}
    if ok:
        # rev 2b (agent 3 F1): one deadline for the whole arm: its cap, and never into the 2 x TP2 reserve
        t_end = min(time.perf_counter() + cap, HARD_STOP - VMS_RESERVE - 120)
        a["deadline_in_sec"] = round(t_end - time.perf_counter())
        _dp = "--data-parallel-size" in [str(x) for x in flags]
        try:
            if gate in ("ref", "oracle"):
                rows, aa = vms_aa(name, deadline=t_end)
                VMS_ROWS[name] = rows
                a["aa"] = aa
                a["canary"] = vms_canary(level, deadline=t_end)
                if gate == "ref":
                    VMS_REF.update(rows)
                    a["gate"] = "reference" if aa["complete"] else "reference (A/A incomplete: every later gate INCOMPLETE)"
                elif aa["degenerate"] == 0 and aa["complete"] and not a["canary"]["foreign_leaks"]:
                    # rev 2: the oracle replaces the gate reference; the production reference is judged from its own rows
                    _r = VMS_ROWS.get("ref_fp8_mtp3_s16")
                    VMS_REF.clear()
                    VMS_REF.update(rows)
                    VMS["oracle_ready"] = True       # rev 2e (GPT audits HIGH-1 / E3): certification needs this
                    VMS["gate_reference"] = name + " (FP8, no speculation, prefix caching off)"
                    a["gate"] = "oracle"
                    if _r:
                        _v, _d = vms_judge(_r["serial_a"], _r["conc_a"], rows)
                        VMS["ref_vs_oracle"] = {"verdict": _v, "detail": _d, "xl": vms_judge_xl(_r.get("xl_a"), rows)}
                        if VMS["arms"].get("ref_fp8_mtp3_s16"):
                            VMS["arms"]["ref_fp8_mtp3_s16"].update(gate=_v, gate_class=_d.get("gate_class"),
                                                                  xl_gate=(VMS["ref_vs_oracle"]["xl"] or {}).get("verdict"))
                else:
                    a["gate"] = "oracle unusable (incomplete or degenerate A/A, or a canary leak)"
            elif VMS_REF:
                s, c = vms_greedy(_S[:6], deadline=t_end), vms_greedy(_S, concurrent=True, deadline=t_end)
                xg = vms_greedy(_X[:4], concurrent=True, deadline=t_end) if (_X and not _dp) else None
                vms_save_rows(name + "_gate", {"serial": s, "conc": c, "xl": xg})
                a["gate"], a["gate_detail"] = vms_judge(s, c, VMS_REF, gate=bool(gate))
                a["gate_class"] = a["gate_detail"].get("gate_class")
                a["xl_gate"] = (vms_judge_xl(xg, VMS_REF) or {}).get("verdict") if xg else None
                a["canary"] = vms_canary(level, deadline=t_end)
            # rev 2: a FAIL is recorded and never adopted, but the speed is still measured
            a["short"] = vms_window(_S, level, _ts(75), name + "_short", deadline=t_end)
            if time.perf_counter() < t_end and not _vms_dead() and not (a["short"] or {}).get("error"):
                a["long"] = vms_window(_L, level, _ts(75), name + "_long", deadline=t_end)
            # rev 2d: the XL band (~85k prompts + up to 8k generated, ~100k per stream), at the streams the KV holds
            if _X and not _dp and time.perf_counter() < t_end and not _vms_dead() and not (a.get("long") or {}).get("error"):
                _lx = max(1, min(level, (rec.get("kv_tokens") or 0) // 100_000)) if rec.get("kv_tokens") else min(level, 6)
                a["xl"] = vms_window(_X, _lx, _ts(75), name + "_xl", deadline=t_end)
            a["server_alive_after"] = not _vms_dead()
        except BaseException as _e:
            a["error"] = f"{type(_e).__name__}: {_e}"[:500]
        sig = VMS_SERVER.log_text() if VMS_SERVER is not None else ""
        a["log_errors"] = {k: sig.count(k) for k in ("Traceback", "out of memory", "OutOfMemory", "Preempt") if k in sig}
    if VMS_SERVER is not None and "VLLM_ALLREDUCE_USE_FLASHINFER_PCIE_IPC" in (env_extra or {}):
        _lt = VMS_SERVER.log_text()        # rev 2d: did the PCIe-IPC all-reduce really engage?
        a["pcie_ipc"] = {"initialized": "Initialized FlashInfer PCIe IPC all-reduce" in _lt,
                         "not_provided": "does not provide PcieIpcAllReduceWorkspace" in _lt,
                         "other_warning": [l[-200:] for l in _lt.splitlines() if "PCIe IPC" in l and "Initialized" not in l][:4]}
    for band in ("short", "long", "xl"):
        w = a.get(band) or {}
        a[band + "_tok_s"], a["accept_" + band], a["level_" + band] = w.get("tok_s"), w.get("accept"), w.get("measured_level")
        a[band + "_e2e_tok_s"] = w.get("end_to_end_tok_s")
    # rev 2e (GPT audits E8 / HIGH-3): speed, correctness, capacity and adoption kept apart
    a["measurement_ok"] = all(vms_window_healthy(a.get(b), level) for b in ("short", "long"))
    a["capacity_ok"] = all(((a.get(b) or {}).get("measured_level") or 0) >= level and not (a.get(b) or {}).get("capacity_limited")
                           for b in ("short", "long"))
    a["correctness_ok"] = a.get("gate") == "PASS" and a.get("xl_gate") in (None, "PASS") \
        and not ((a.get("canary") or {}).get("foreign_leaks") or (a.get("canary") or {}).get("errors"))
    a["adoptable"] = bool(VMS.get("oracle_ready") and a["measurement_ok"] and a["capacity_ok"] and a["correctness_ok"]
                          and a.get("server_alive_after") and not a.get("log_errors") and not a.get("error"))
    a["ok"] = a["measurement_ok"]        # "speed data from clean windows exists"; adoption is a["adoptable"]
    VMS["arms"][name] = a
    VMS["order"].append(name)
    e14_save()
    print("VMS arm", name, json.dumps({k: v for k, v in a.items() if k not in ("flags", "short", "long", "xl")}, default=str)[:700], flush=True)
    return a


'''
between("def vms_aa(name, deadline=None):", "if VMS_ON and VMS_INST and not VMS[\"install\"].get(\"error\"):", V2_NEW)

# ---- the order of the audits (MEDIUM 8 / E12): no-prefix and MTP width / streams before INT4 and SSM variants
rep('''        ("fp8_mtp2", vms_flags(MODEL_PATH, spec=2), {}),
        ("fp8_mtp4", vms_flags(MODEL_PATH, spec=4), {}),
        ("int4_mtp3_s16", vms_flags(VMS_INT4), dict(gate=False)),
        ("fp8_mtp3_s20", vms_flags(MODEL_PATH, seqs=20), dict(level=20)),
        ("fp8_mtp3_s24", vms_flags(MODEL_PATH, seqs=24), dict(level=24)),
        ("int4_mtp3_s20", vms_flags(VMS_INT4, seqs=20), dict(level=20, gate=False)),
        ("fp8_mtp3_ssm_fp16", vms_flags(MODEL_PATH, extra={"--mamba-ssm-cache-dtype": "float16"}), {}),
        ("fp8_mtp3_noprefix", vms_flags(MODEL_PATH, prefix=False), {}),''', '''        # rev 2e (GPT audit order): the prefix-cache isolation, MTP width, 20 / 24 streams, then INT4 and SSM variants
        ("fp8_mtp3_noprefix", vms_flags(MODEL_PATH, prefix=False), {}),
        ("fp8_mtp2", vms_flags(MODEL_PATH, spec=2), {}),
        ("fp8_mtp4", vms_flags(MODEL_PATH, spec=4), {}),
        ("fp8_mtp3_s20", vms_flags(MODEL_PATH, seqs=20), dict(level=20)),
        ("fp8_mtp3_s24", vms_flags(MODEL_PATH, seqs=24), dict(level=24)),''')
rep('''        ("fp8_mtp3_lb_triton", vms_flags(MODEL_PATH, extra={"--linear-backend": "triton"}), {}),
    ]''', '''        ("fp8_mtp3_lb_triton", vms_flags(MODEL_PATH, extra={"--linear-backend": "triton"}), {}),
        ("fp8_mtp3_ssm_fp16", vms_flags(MODEL_PATH, extra={"--mamba-ssm-cache-dtype": "float16"}), {}),
        ("int4_mtp3_s16", vms_flags(VMS_INT4), dict(gate=False)),
        ("int4_mtp3_s20", vms_flags(VMS_INT4, seqs=20), dict(level=20, gate=False)),
    ]''')
rep('''        rec["skipped"] = "reserved 2 x TP2 slot / hard stop"''', '''        rec["skipped"] = "NOT_TESTED_BUDGET: reserved 2 x TP2 slot / hard stop"''')
rep('''        rec["skipped"] = "reserved 2 x TP2 slot / hard stop (after the GPU wait)"''', '''        rec["skipped"] = "NOT_TESTED_BUDGET: reserved 2 x TP2 slot / hard stop (after the GPU wait)"''')

# ---- report: the new columns
rep('''XL tok/s (streams) | x ref | accept XL | PCIe-IPC initialized |",
         "|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|"]''', '''XL tok/s (streams) | x ref | accept XL | PCIe-IPC initialized | gate class / XL gate | canary leaks | e2e tok/s 8k / 40k | prefix hits / queries 40k | measurement / capacity / correctness | adoptable |",
         "|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|"]''')
rep('''                 f"{xr(a.get('xl_tok_s'), _rx)} | {f(a.get('accept_xl'), 2)} | {(a.get('pcie_ipc') or {}).get('initialized', '')} |")''',
    '''                 f"{xr(a.get('xl_tok_s'), _rx)} | {f(a.get('accept_xl'), 2)} | {(a.get('pcie_ipc') or {}).get('initialized', '')} | "
                 f"{a.get('gate_class') or ''} / {a.get('xl_gate') or ''} | {(a.get('canary') or {}).get('foreign_leaks', '')} | "
                 f"{f(a.get('short_e2e_tok_s'))} / {f(a.get('long_e2e_tok_s'))} | "
                 f"{f((a.get('long') or {}).get('prefix_cache_hits'))} / {f((a.get('long') or {}).get('prefix_cache_queries'))} | "
                 f"{a.get('measurement_ok')} / {a.get('capacity_ok')} / {a.get('correctness_ok')} | {a.get('adoptable')} |")''')
rep('''         f"gate reference: {VMS.get('gate_reference')}",''', '''         f"gate reference: {VMS.get('gate_reference')} | oracle_ready (certification possible): {bool(VMS.get('oracle_ready'))}",
         "tok/s = steady decode after the prefill settled; e2e = output tokens from submission to the window end / wall; "
         "BOUNDARY = PASS with near-tie divergences (a candidate for task-level evaluation, never auto-certified)",''')
p.write_text(t, encoding="utf-8", newline="\n")
print("patched")
