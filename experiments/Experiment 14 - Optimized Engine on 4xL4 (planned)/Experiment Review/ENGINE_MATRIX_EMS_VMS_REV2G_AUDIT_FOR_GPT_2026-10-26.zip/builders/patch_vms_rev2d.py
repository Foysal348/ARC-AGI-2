"""VMS rev 2d (user 2026-10-26: "take 1 and 2", budget may grow): the XL band (~85k-token prompts at the streams the KV
holds), the FlashInfer PCIe-IPC all-reduce arm (vLLM 0.32.0 cuda_communicator.py: VLLM_ALLREDUCE_USE_FLASHINFER_PCIE_IPC,
FlashInfer 0.7.0.post1 is already in this wheelhouse; the log line "Initialized FlashInfer PCIe IPC all-reduce" proves it
engaged), budget 200 -> 260 min. Every replacement asserted."""
from pathlib import Path

p = Path(r"D:/ARC AGI 2/experiments/Experiment 14 - Optimized Engine on 4xL4 (planned)/Experiment Notebooks/Build/build_vms.py")
t = p.read_text(encoding="utf-8")


def rep(a, b, n=1):
    global t
    assert t.count(a) == n, (t.count(a), a[:100])
    t = t.replace(a, b)


rep("usage: python build_vms.py", "rev 2d (user 2026-10-26, \"take 1 and 2\"): the XL band (~85k-token prompts) on every TP4 arm; the FlashInfer\n"
    "PCIe-IPC all-reduce arm fp8_mtp3_pcie (VLLM_ALLREDUCE_USE_FLASHINFER_PCIE_IPC=1); budget 260 min.\nusage: python build_vms.py")
rep('''                  "time_budget_sec": 200 * 60, "admit_frac": 0.90, "drain_frac": 0.94, "hard_margin_sec": 2 * 60,
                  "verify_margin_sec": 1 * 60, "drain_margin_sec": 8 * 60, "admit_margin_sec": 2 * 60, "vms": True},''',
    '''                  "time_budget_sec": 260 * 60, "admit_frac": 0.90, "drain_frac": 0.94, "hard_margin_sec": 2 * 60,
                  "verify_margin_sec": 1 * 60, "drain_margin_sec": 8 * 60, "admit_margin_sec": 2 * 60, "vms": True},   # rev 2d: 260 min''')

# ---- XL window per arm (TP4 only: DP2 x TP2 has half the KV per engine)
rep('''            if time.perf_counter() < t_end and not _vms_dead():
                a["long"] = vms_window(_L, level, _ts(75), name + "_long", deadline=t_end)''', '''            if time.perf_counter() < t_end and not _vms_dead():
                a["long"] = vms_window(_L, level, _ts(75), name + "_long", deadline=t_end)
            # rev 2d: the XL band (~85k prompts + up to 8k generated, ~100k per stream), at the streams the KV holds
            _dp = "--data-parallel-size" in [str(x) for x in flags]
            if _X and not _dp and time.perf_counter() < t_end and not _vms_dead():
                _lx = max(1, min(level, (rec.get("kv_tokens") or 0) // 100_000)) if rec.get("kv_tokens") else min(level, 6)
                a["xl"] = vms_window(_X, _lx, _ts(75), name + "_xl", deadline=t_end)''')
rep('''    for band in ("short", "long"):
        w = a.get(band) or {}''', '''    if VMS_SERVER is not None and "VLLM_ALLREDUCE_USE_FLASHINFER_PCIE_IPC" in (env_extra or {}):
        _lt = VMS_SERVER.log_text()        # rev 2d: did the PCIe-IPC all-reduce really engage?
        a["pcie_ipc"] = {"initialized": "Initialized FlashInfer PCIe IPC all-reduce" in _lt,
                         "not_provided": "does not provide PcieIpcAllReduceWorkspace" in _lt,
                         "other_warning": [l[-200:] for l in _lt.splitlines() if "PCIe IPC" in l and "Initialized" not in l][:4]}
    for band in ("short", "long", "xl"):
        w = a.get(band) or {}''')
rep('''    VMS["prompts"] = {"short_p50": statistics.median(len(x) for x in _S), "long_p50": statistics.median(len(x) for x in _L)}''',
    '''    # rev 2d: the XL band, a shared ~85k-token block (vLLM max_model_len 106,496: 85k + 8k generated fits)
    _bgx, _nx = list(_bg), _n
    for _t in sorted(_all):
        if _nx >= int(os.environ.get("E14_XL_TOKENS", 85000)):
            break
        if _t in CHALLENGES or _tt(_all[_t]) in _bgx:
            continue
        _bgx.append(_tt(_all[_t]))
        _nx += len(tokenizer.encode(_bgx[-1], add_special_tokens=False))
    _blockx = "Reference tasks (not to be solved):\\n" + "\\n".join(_bgx)
    _X = [_ids([{"role": "system", "content": _blockx}, {"role": "user", "content": _ask + "\\n" + _tt(CHALLENGES[t])}])
          for t in TASK_IDS]
    VMS["prompts"] = {"short_p50": statistics.median(len(x) for x in _S), "long_p50": statistics.median(len(x) for x in _L),
                      "xl_p50": statistics.median(len(x) for x in _X)}''')

# ---- the PCIe-IPC arm, right after the oracle (communication is ~half a TP4 step on this VM)
rep('''    PLAN = [
        ("fp8_mtp2", vms_flags(MODEL_PATH, spec=2), {}),''', '''    PLAN = [
        # rev 2d: FlashInfer PCIe-IPC all-reduce (cuda_communicator.py: dispatched after custom / quick all-reduce, both
        # off on 4 PCIe GPUs, before NCCL; bf16 / fp16 only)
        ("fp8_mtp3_pcie", vms_flags(MODEL_PATH), dict(env_extra={"VLLM_ALLREDUCE_USE_FLASHINFER_PCIE_IPC": "1"})),
        ("fp8_mtp2", vms_flags(MODEL_PATH, spec=2), {}),''')

# ---- report columns
rep('''         "| arm | ok | gate | streams (8k / 40k) | 8k tok/s | x ref | 40k tok/s | x ref | accept 8k / 40k | KV tokens | KV max | preemptions | degenerate 8k / 40k | log errors |",
         "|---|---|---|---|---|---|---|---|---|---|---|---|---|---|"]''', '''         "| arm | ok | gate | streams (8k / 40k) | 8k tok/s | x ref | 40k tok/s | x ref | accept 8k / 40k | KV tokens | KV max | preemptions | degenerate 8k / 40k | log errors | XL tok/s (streams) | x ref | accept XL | PCIe-IPC initialized |",
         "|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
    _rx = _ref.get("xl_tok_s") or 0''')
rep('''                 f"{a.get('log_errors') or a.get('skipped') or a.get('error') or (a.get('short') or {}).get('error') or (a.get('long') or {}).get('error') or ''} |")''',
    '''                 f"{a.get('log_errors') or a.get('skipped') or a.get('error') or (a.get('short') or {}).get('error') or (a.get('long') or {}).get('error') or ''} | "
                 f"{f(a.get('xl_tok_s'))} ({f(a.get('level_xl'))}){' ' + str((a.get('xl') or {}).get('error')) if (a.get('xl') or {}).get('error') else ''} | "
                 f"{xr(a.get('xl_tok_s'), _rx)} | {f(a.get('accept_xl'), 2)} | {(a.get('pcie_ipc') or {}).get('initialized', '')} |")''')
p.write_text(t, encoding="utf-8", newline="\n")
print("patched")
