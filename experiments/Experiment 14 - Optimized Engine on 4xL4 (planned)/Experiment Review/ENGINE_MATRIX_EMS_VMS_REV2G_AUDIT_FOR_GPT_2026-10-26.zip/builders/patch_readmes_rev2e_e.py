import hashlib
from pathlib import Path
ROOT = Path(r"D:/ARC AGI 2/experiments/Experiment 14 - Optimized Engine on 4xL4 (planned)")
def patch(fn, pairs):
    p = ROOT / fn; raw = p.read_bytes().decode("utf-8"); crlf = "\r\n" in raw; t = raw.replace("\r\n", "\n")
    for a, b in pairs:
        assert t.count(a) == 1, (fn, t.count(a), a[:70]); t = t.replace(a, b)
    if crlf: t = t.replace("\n", "\r\n")
    p.write_bytes(t.encode("utf-8")); print("patched", fn)
E1 = ("    - EMS prefix-cache hits are measured inside the EMS cell, because the shared `e14_measure` comes from the Kaggle payload dataset.\n")
patch("README_PURPOSE_AND_WORK.md", [(E1, E1 + """  - **rev 2e-e** (found by the rev 2e-d harness run; `_scratch/vms/patch_rev2e_e.py`):
    - VMS `vms_window` waited up to 900 s for `level` running requests even after the streams had died or finished. It now stops once fewer than `level` streams are alive, with the same error plus the stream errors. On the GPU this saves an arm's time cap.
    - The EMS reference record never got `probe_complete_vs_target`, so `_gated` could never mark the production reference adoptable. Fixed.
    - Harness only: both fake servers listen with a backlog of 256 (Windows dropped some of 16-24 simultaneous connects), and the negative tests use longer strings (Qwen BPE merges a run of '!' into few ids).
""")])
patch("README_FINDINGS.md", [("| 10-26 | a first rev 2e-d try put the prefix-hit count in",
 """| 10-26 | VMS `vms_window` waited up to 900 s for the level after its streams had died or finished; the EMS reference never got `probe_complete_vs_target`, so it could never be adoptable | rev 2e-d harness run (rev 2e-e fix) |
| 10-26 | a first rev 2e-d try put the prefix-hit count in""")])
