"""EMS rev 2d (user 2026-10-26: "1 ও 2 নাও" ("take 1 and 2"); "সময় ২০০ থেকে বাড়াতে চাইলে বাড়াও" ("increase the time from 200 if you want")):
1. an XL band, ~85k-token prompts (the context where production spends its 60k thinking), on every single-server arm,
   at the stream count the KV holds (kv_tokens // 100k, at most the arm's level);
2. FlashInfer PCIe-IPC all-reduce (SGLang 0.5.21 pcie_ipc_ar.py, env SGLANG_ENABLE_PCIE_IPC_ALLREDUCE; needs
   flashinfer.comm.PcieIpcAllReduceWorkspace = FlashInfer 0.7.0.post1, which our SGLang venv lacks (0.6.18)). An overlay
   dir with flashinfer-python 0.7.0.post1 + flashinfer-jit-cache 0.7.0.post1+cu130 + nccl-extensions 0.1.0 from the vLLM
   0.32.0 wheelhouse dataset is put on PYTHONPATH for the PCIe arms only; every other arm keeps the shipped 0.6.18.
   Arms: dflash_w6_pcie (right after target-only), mtp_3_1_4_pcie; the log line proves it really engaged.
3. budget 200 -> 260 min (the XL band adds ~2-3 min per arm)."""
from pathlib import Path

p = Path(r"D:/ARC AGI 2/experiments/Experiment 14 - Optimized Engine on 4xL4 (planned)/Experiment Notebooks/Build/build_ems.py")
t = p.read_text(encoding="utf-8")


def rep(a, b, n=1):
    global t
    assert t.count(a) == n, (t.count(a), a[:100])
    t = t.replace(a, b)


rep('''usage: python build_ems.py   -> ../Q27-XHIGH-EMS_ENGINE_MATRIX_SGLANG.ipynb"""''', '''rev 2d (user 2026-10-26, "take 1 and 2"): an XL band (~85k-token prompts, at the streams the KV holds) on every
single-server arm; FlashInfer 0.7 PCIe-IPC all-reduce arms (dflash_w6_pcie, mtp_3_1_4_pcie) through a per-arm FlashInfer
0.7.0.post1 overlay from the vLLM 0.32.0 wheelhouse (attach foysalemonshanto/vllm-0-32-0-cu13-wheelhouse); budget 260 min.
usage: python build_ems.py   -> ../Q27-XHIGH-EMS_ENGINE_MATRIX_SGLANG.ipynb"""''')

# ---- 3. budget
rep('''    "EMS":       {"source": "eval", "task_list": ''', '''    # rev 2d: 260 min (user 2026-10-26: the budget may grow; the XL band costs ~2-3 min per arm)
    "EMS":       {"source": "eval", "task_list": ''')
rep('''                  "time_budget_sec": 200 * 60, "admit_frac": 0.90, "drain_frac": 0.94, "hard_margin_sec": 2 * 60,
                  "verify_margin_sec": 1 * 60, "drain_margin_sec": 8 * 60, "admit_margin_sec": 2 * 60, "ems": True},''',
    '''                  "time_budget_sec": 260 * 60, "admit_frac": 0.90, "drain_frac": 0.94, "hard_margin_sec": 2 * 60,
                  "verify_margin_sec": 1 * 60, "drain_margin_sec": 8 * 60, "admit_margin_sec": 2 * 60, "ems": True},''')

# ---- 1. XL prompts
rep('''    block = "Reference tasks (not to be solved):\\n" + "\\n".join(bg)
    long_ = [_e14_chat_ids([{"role": "system", "content": block},
                            {"role": "user", "content": ask + "\\n" + _e14_task_text(CHALLENGES[t])}]) for t in TASK_IDS]
    return {"short": short, "long": long_,
            "tokens": {"short_p50": statistics.median(len(x) for x in short) if short else None,
                       "long_p50": statistics.median(len(x) for x in long_) if long_ else None}}''',
    '''    block = "Reference tasks (not to be solved):\\n" + "\\n".join(bg)
    long_ = [_e14_chat_ids([{"role": "system", "content": block},
                            {"role": "user", "content": ask + "\\n" + _e14_task_text(CHALLENGES[t])}]) for t in TASK_IDS]
    # rev 2d: the XL band, a shared ~85k-token block (production thinks to 60k on top of a 5-10k prompt, so decode spends
    # most of its time at 60-100k context; the 40k band never reached it)
    bgx, nx = list(bg), n
    for t in sorted(_all):
        if nx >= int(os.environ.get("E14_XL_TOKENS", 85000)):
            break
        if t in CHALLENGES or _e14_task_text(_all[t]) in bgx:
            continue
        bgx.append(_e14_task_text(_all[t]))
        nx += len(tokenizer.encode(bgx[-1], add_special_tokens=False))
    blockx = "Reference tasks (not to be solved):\\n" + "\\n".join(bgx)
    xl = [_e14_chat_ids([{"role": "system", "content": blockx},
                         {"role": "user", "content": ask + "\\n" + _e14_task_text(CHALLENGES[t])}]) for t in TASK_IDS]
    return {"short": short, "long": long_, "xl": xl,
            "tokens": {"short_p50": statistics.median(len(x) for x in short) if short else None,
                       "long_p50": statistics.median(len(x) for x in long_) if long_ else None,
                       "xl_p50": statistics.median(len(x) for x in xl) if xl else None}}''')
rep('''        EMS_PROMPTS = {"short": [], "long": [], "tokens": {"error": repr(_e)[:300]}}''',
    '''        EMS_PROMPTS = {"short": [], "long": [], "xl": [], "tokens": {"error": repr(_e)[:300]}}''')
rep('''    _S, _L = EMS_PROMPTS["short"], EMS_PROMPTS["long"]''', '''    _S, _L, _X = EMS_PROMPTS["short"], EMS_PROMPTS["long"], EMS_PROMPTS.get("xl") or []''')

# ---- 1. XL window inside every single-server arm (after the 8k and 40k bands; its own level)
rep('''    def _windows(tag, level, gate=True, probe=True, ctx=None):
        ctx = ctx or E14_CTX''', '''    def _xl_level(caps, level):
        """rev 2d: streams the KV holds at ~100k each (85k prompt + up to 4k generated + slack), never above `level`."""
        kv = (caps or {}).get("kv_tokens") or 0
        return max(1, min(level, kv // 100_000)) if kv else min(level, 6)

    def _windows(tag, level, gate=True, probe=True, ctx=None, xl_level=None):
        ctx = ctx or E14_CTX''')
rep('''                out[band] = E14M.steady_window(ctx, ps, level=level, secs=_ts(75), tag=tag + band)
            if probe and not _dead():''', '''                out[band] = E14M.steady_window(ctx, ps, level=level, secs=_ts(75), tag=tag + band)
            if xl_level and _X and not _dead():       # rev 2d: the XL band (flush first: the 40k block is not reused)
                out["flush_before_xl"] = E14M.flush_cache(ctx)
                out["xl"] = E14M.steady_window(ctx, _X, level=xl_level, secs=_ts(75), tag=tag + "xl")
            if probe and not _dead():''')
rep('''        _lv = _level(_rec, streams or LEVEL)
        _r = e14_phase("EMS_" + name, _windows(name, _lv, gate=gate, probe=probe), _ts(cap)) if _ok else None''',
    '''        _lv = _level(_rec, streams or LEVEL)
        _r = (e14_phase("EMS_" + name, _windows(name, _lv, gate=gate, probe=probe, xl_level=_xl_level(_rec.get("caps"), _lv)),
                        _ts(cap + 3 * 60)) if _ok else None)''')
rep('''    _r0 = e14_phase("EMS_ref_windows", _windows("ref", LEVEL, gate=False, probe=False), _ts(8 * 60))''',
    '''    _r0 = e14_phase("EMS_ref_windows", _windows("ref", LEVEL, gate=False, probe=False,
                                                xl_level=_xl_level(E11_SGL.get("caps"), LEVEL)), _ts(11 * 60))''')
rep('''        _rt = e14_phase("EMS_target_only", _windows("target_only", _level(_rec, LEVEL), gate=False, probe=False), _ts(8 * 60))''',
    '''        _rt = e14_phase("EMS_target_only", _windows("target_only", _level(_rec, LEVEL), gate=False, probe=False,
                                                    xl_level=_xl_level(_rec.get("caps"), _level(_rec, LEVEL))), _ts(11 * 60))''')
rep('''             "level_short": _w(r, "short", "measured_level"), "level_long": _w(r, "long", "measured_level"),''',
    '''             "level_short": _w(r, "short", "measured_level"), "level_long": _w(r, "long", "measured_level"),
             "xl_tok_s": _w(r, "xl", "tok_s_p50"), "accept_xl": _w(r, "xl", "accept_p50"), "step_ms_xl": _w(r, "xl", "step_ms_p50"),
             "level_xl": _w(r, "xl", "measured_level"), "xl_error": _w(r, "xl", "error"), "ctx_xl": _w(r, "xl", "ctx_per_req_p50"),''')

# ---- 2. the FlashInfer 0.7 overlay + the PCIe-IPC arms
rep('''    EMSR["pr45151_patch"] = ems_patch_pr45151()''', '''    EMSR["pr45151_patch"] = ems_patch_pr45151()

    EMS_FI07 = "/tmp/ems-fi07"

    def ems_fi07_overlay():
        """rev 2d: FlashInfer 0.7.0.post1 (+ jit-cache cu130 + nccl-extensions) into an overlay dir for the PCIe-IPC arms
        only (PYTHONPATH). Source: the vLLM 0.32.0 wheelhouse dataset; Kaggle drops '+' from file names, so the jit-cache
        wheel is copied back under its real name. Verified by importing flashinfer.comm.PcieIpcAllReduceWorkspace with the
        SGLang venv's python."""
        out = {"ok": False, "dir": EMS_FI07}
        try:
            if E11_HARNESS:
                out["why"] = "harness: no SGLang install"
                return out
            roots = [Path(x) for x in os.environ.get("EMS_FI07_WHEELHOUSE", "").split(os.pathsep) if x] + [
                Path("/kaggle/input/datasets/foysalemonshanto/vllm-0-32-0-cu13-wheelhouse"), Path("/kaggle/input")]
            want = {"flashinfer_python-0.7.0.post1-": None, "flashinfer_jit_cache-0.7.0.post1": None, "nccl_extensions-0.1.0-": None}
            for r_ in roots:
                if not r_.is_dir():
                    continue
                for f in r_.rglob("*.whl"):
                    for k in want:
                        if want[k] is None and f.name.startswith(k):
                            want[k] = f
                if all(want.values()):
                    break
            if not all(want.values()):
                out["why"] = "wheels not found (attach foysalemonshanto/vllm-0-32-0-cu13-wheelhouse): " + str({k: str(v) for k, v in want.items()})
                return out
            tmp = Path("/tmp/ems-fi07-wheels")
            tmp.mkdir(parents=True, exist_ok=True)
            wheels = []
            for f in want.values():
                name = f.name.replace("0.7.0.post1cu130", "0.7.0.post1+cu130")
                shutil.copy(f, tmp / name)
                wheels.append(str(tmp / name))
            r_ = subprocess.run([E14_VENV["launch"][0], "-m", "pip", "install", "--no-deps", "--no-index", "--target", EMS_FI07,
                                 "--upgrade"] + wheels, capture_output=True, text=True, timeout=1200)
            out["pip_rc"], out["pip_tail"] = r_.returncode, (r_.stdout + r_.stderr)[-600:]
            if r_.returncode != 0:
                return out
            chk = subprocess.run([E14_VENV["launch"][0], "-c", "import flashinfer, sys; from flashinfer.comm import "
                                  "PcieIpcAllReduceWorkspace; print(flashinfer.__version__, flashinfer.__file__)"],
                                 capture_output=True, text=True, timeout=600, env=dict(E14_VENV["env"], PYTHONPATH=EMS_FI07))
            out["import"] = (chk.stdout + chk.stderr).strip()[-400:]
            out["ok"] = chk.returncode == 0 and "0.7.0" in chk.stdout and EMS_FI07 in chk.stdout
        except Exception as e:
            out["why"] = f"{type(e).__name__}: {e}"[:300]
        return out
    EMSR["fi07_overlay"] = ems_fi07_overlay()
    print("EMS FlashInfer 0.7 overlay:", json.dumps(EMSR["fi07_overlay"])[:500], flush=True)
    # the env of a PCIe-IPC arm: the overlay first on the path, the SGLang 0.5.21 switch on (pcie_ipc_ar.py; it sits after
    # custom all-reduce, which is off on 4 PCIe GPUs, and before NCCL; bf16 decode reductions only)
    _PCIE = {"PYTHONPATH": EMS_FI07, "SGLANG_ENABLE_PCIE_IPC_ALLREDUCE": "1", "FLASHINFER_DISABLE_VERSION_CHECK": "1"}''')
rep('''    PLAN = [
        ("mtp_3_1_4", dict(set_=_mtp(), drop=_SPEC + ("--min-free-slots-delay",))),''', '''    PLAN = [
        # rev 2d: PCIe-IPC all-reduce on the reference config (communication = 51 % of a step, Notes/30), first after
        # the oracle; skipped (recorded) when the FlashInfer 0.7 overlay could not be built
        ("dflash_w6_pcie", dict(env=_PCIE, timeout=30 * 60)),
        ("mtp_3_1_4", dict(set_=_mtp(), drop=_SPEC + ("--min-free-slots-delay",))),''')
rep('''        ("mtp_3_1_4_pr45151", dict(set_=_mtp(), drop=_SPEC + ("--min-free-slots-delay",), env={"EMS_PR45151": "1"})),''',
    '''        ("mtp_3_1_4_pr45151", dict(set_=_mtp(), drop=_SPEC + ("--min-free-slots-delay",), env={"EMS_PR45151": "1"})),
        ("mtp_3_1_4_pcie", dict(set_=_mtp(), drop=_SPEC + ("--min-free-slots-delay",), env=_PCIE, timeout=30 * 60)),''')
rep('''        if _name in ("dflash_w6_s20", "dflash_w6_s24") and E14_VENV["cfg"].get("streams12"):''',
    '''        if _name.endswith("_pcie") and not (EMSR["fi07_overlay"].get("ok") or E11_HARNESS):
            _why = "FlashInfer 0.7 overlay: " + str(EMSR["fi07_overlay"].get("why") or EMSR["fi07_overlay"])[:300]
        if _name in ("dflash_w6_s20", "dflash_w6_s24") and E14_VENV["cfg"].get("streams12"):''')
# the log proves whether PCIe-IPC really engaged (pcie_ipc_ar.py log lines)
rep('''        fam = "mtp" if str(s.get("--speculative-algorithm", "")).upper() == "EAGLE" else ("target" if "--speculative-algorithm" in drop else "dflash")''',
    '''        fam = "mtp" if str(s.get("--speculative-algorithm", "")).upper() == "EAGLE" else ("target" if "--speculative-algorithm" in drop else "dflash")
        _px = {}
        if (env or {}).get("SGLANG_ENABLE_PCIE_IPC_ALLREDUCE") and E11_SERVER is not None:
            _lt = E11_SERVER.log_text()
            _px = {"pcie_ipc": {"enabled": "FlashInfer PCIe-IPC all-reduce enabled" in _lt,
                                "workspace_built": "FlashInfer PCIe-IPC workspace built" in _lt,
                                "no_pcie_ipc_comm": "has no pcie_ipc_comm" in _lt,
                                "workspace_failed": "PCIe-IPC workspace" in _lt and "failed" in _lt,
                                "flashinfer_version_lines": [l[-160:] for l in _lt.splitlines() if "flashinfer" in l.lower() and "version" in l.lower()][:3]}}''')
rep('''                                                   "env": dict(env or {})})''', '''                                                   "env": dict(env or {}), **_px})''')
p.write_text(t, encoding="utf-8", newline="\n")
print("patched part 1")
