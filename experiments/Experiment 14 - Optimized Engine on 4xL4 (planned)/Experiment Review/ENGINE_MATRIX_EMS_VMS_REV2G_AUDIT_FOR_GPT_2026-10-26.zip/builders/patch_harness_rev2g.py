from pathlib import Path
H = Path(r"D:/ARC AGI 2/experiments/Experiment 14 - Optimized Engine on 4xL4 (planned)/src/harness")
def rp(p, a, b):
    t = p.read_text(encoding="utf-8"); assert t.count(a) == 1, (p.name, t.count(a), a[:70]); p.write_text(t.replace(a, b), encoding="utf-8", newline="\n")
VMS_T = r'''# rev 2g: the GPT rev 2f audit negative tests, on the notebook's own functions (synthetic copies of a real arm)
import copy as _cp, tempfile as _tf
_cl, _wh, _txb, _ist = G["vms_classify"], G["vms_window_healthy"], G["vms_text_bad"], G["vms_int4_mtp_static"]
_good = _cp.deepcopy(A["fp8_mtp2"])
def _ad(**mut):
    a = _cp.deepcopy(_good)
    for k, v in mut.items():
        if v is _DEL:
            a.pop(k, None)
        else:
            a[k] = v
    return _cl(a)["adoptable"]
_DEL = object()
_lvl = _good.get("level_wanted") or 16
_neg = {"base adoptable": _ad(), "missing XL": not _ad(xl_gate=None), "XL INCOMPLETE": not _ad(xl_gate="INCOMPLETE"),
        "no canary": not _ad(canary=_DEL), "canary errors": not _ad(canary={"level": _lvl, "errors": 1, "foreign_leaks": 0, "own_hits": 3}),
        "canary leak": not _ad(canary={"level": _lvl, "errors": 0, "foreign_leaks": 1, "own_hits": 3}),
        "canary other level": not _ad(canary={"level": 12 if _lvl != 12 else 16, "errors": 0, "foreign_leaks": 0, "own_hits": 3}),
        "DP diagnostic": not _ad(diagnostic_only=True),
        "PCIe unverified": not _ad(env={"VLLM_ALLREDUCE_USE_FLASHINFER_PCIE_IPC": "1"}, pcie_ipc={"initialized": False})}
_w = _cp.deepcopy(_good["short"]); _w1 = dict(_w, no_first_token=1)
_neg["window healthy"] = _wh(_w, _lvl); _neg["window no_first_token=1 unhealthy"] = not _wh(_w1, _lvl)
_g30 = chr(10).join(" ".join("0" for _ in range(30)) for _ in range(30))
_neg["text 0*250 bad"] = _txb("0" * 250); _neg["text 0+!+0 bad"] = _txb("0" * 40 + "!" * 60 + "0" * 60)
_neg["text 0 0 0 x200 bad"] = _txb(" ".join("0" * 200)); _neg["text grids ok"] = not any(_txb(x) for x in ("[[0,0],[0,0]]", "0 0 1" + chr(10) + "0 0 0", _g30))
_neg["text prose ok"] = not _txb("Let me look at the first example carefully. The input grid has a red line. " * 6)
_one = {k: v[:1] for k, v in G["VMS_REF"].items() if k in ("serial_a", "serial_b", "conc_a", "conc_b")}
_neg["judge 1 row INCOMPLETE"] = G["vms_judge"](_one["serial_a"], _one["conc_a"], dict(G["VMS_REF"]))[0] == "INCOMPLETE"
def _st(keys, ign):
    d = Path(_tf.mkdtemp())
    (d / "config.json").write_text(json.dumps({"quantization_config": {"ignore": ign, "format": "pack-quantized"}}), encoding="utf-8")
    (d / "model.safetensors.index.json").write_text(json.dumps({"weight_map": {k: "x" for k in keys}}), encoding="utf-8")
    return _ist(d)["ok"]
_saved = G["VMS"].get("int4_mtp_static")
_neg["static dense+ignored ok"] = _st(["mtp.fc.weight", "mtp.layers.0.mlp.gate_proj.weight"], ["re:^mtp.*"])
_neg["static dense not ignored FAIL"] = not _st(["mtp.fc.weight", "mtp.layers.0.mlp.gate_proj.weight"], [])
_neg["static packed+ignored FAIL"] = not _st(["mtp.fc.weight_packed", "mtp.fc.weight_scale"], ["re:^mtp.*"])
_neg["static packed not ignored ok"] = _st(["mtp.fc.weight_packed", "mtp.fc.weight_scale"], [])
G["VMS"]["int4_mtp_static"] = _saved
check("rev 2g negative tests (GPT rev 2f audit R1-R5 / R2F-01..10): fail-closed classifier, first-token coverage, "
      "structural grid rule, planned row counts, INT4 MTP static check", all(_neg.values()), {k: v for k, v in _neg.items() if not v})
check("every planned arm ran and recorded ok with tok/s in both bands",'''
rp(H / "make_harness_vms.py", 'check("every planned arm ran and recorded ok with tok/s in both bands",', VMS_T)
EMS_T = r'''# rev 2g: the GPT rev 2f audit negative tests on _gated / _text_bad (synthetic copies of a real arm)
import copy as _cp
_gd, _txb = G["_gated"], G["_text_bad"]
_good = _cp.deepcopy(A["mtp_3_1_4"])
def _gt(**mut):
    a = _cp.deepcopy(_good); a.update(mut); return bool(_gd(a))
_oc = _cp.deepcopy(G["EMSR"].get("canary_oracle"))
_neg = {"base adoptable": _gt(), "missing XL": not _gt(xl_gate=None), "XL INCOMPLETE": not _gt(xl_gate="INCOMPLETE"),
        "PCIe unverified": not _gt(env={"SGLANG_ENABLE_PCIE_IPC_ALLREDUCE": "1"}, pcie_ipc={"workspace_built": False})}
G["EMSR"]["canary_oracle"] = dict(_oc or {}, errors=1); _neg["oracle canary errors"] = not _gt()
G["EMSR"]["canary_oracle"] = None; _neg["no oracle canary"] = not _gt()
G["EMSR"]["canary_oracle"] = _oc
_g30 = chr(10).join(" ".join("0" for _ in range(30)) for _ in range(30))
_neg["text 0*250 bad"] = _txb("0" * 250); _neg["text 0+!+0 bad"] = _txb("0" * 40 + "!" * 60 + "0" * 60)
_neg["text 0 0 0 x200 bad"] = _txb(" ".join("0" * 200)); _neg["text grids ok"] = not any(_txb(x) for x in ("[[0,0],[0,0]]", "0 0 1" + chr(10) + "0 0 0", _g30))
_neg["canary classification recorded"] = (G["EMSR"].get("canary_oracle") or {}).get("classification") in ("PASS_NO_OBSERVED_LEAK", "INCONCLUSIVE")
_neg["every arm has production_approved False"] = all(A[k].get("production_approved") is False for k in A if "adoptable" in A[k])
check("rev 2g negative tests (GPT rev 2f audit R2F-02 / R6 / R2F-06 / R2F-07): fail-closed _gated, structural grid rule",
      all(_neg.values()), {k: v for k, v in _neg.items() if not v})
_tb = G["_tail_bad"]'''
rp(H / "make_harness_ems.py", '_tb = G["_tail_bad"]', EMS_T)
rp(H / "make_harness_ems.py", '''(WORK / "Q27X_EMS_BUNDLE.zip").exists()''', '''any(WORK.glob("Q27X_EMS*_BUNDLE.zip"))''')
print("ok")
