"""rev 2e-c (both notebooks; user 2026-10-26: no change that throws valid data away without proof). The rev 2e tail check
(16 identical token ids / >50 % repeated 8-grams) and the degenerate rule (< 8 distinct characters over 200) both flag a
normal ARC grid printed in the reasoning ("0 0 0 0 ..." is one repeated token, 3 distinct characters). New rule, shared:
a text whose non-space characters are >= 30 % digits is grid-like and never degenerate; otherwise empty, a 32-character
run of one character, < 8 distinct characters over 200, or < 10 % letters / digits is degenerate (vLLM #53912 shapes:
empty, repeated punctuation). The tail check decodes the ids after the first divergence and applies the same rule."""
from pathlib import Path

B = Path(r"D:/ARC AGI 2/experiments/Experiment 14 - Optimized Engine on 4xL4 (planned)/Experiment Notebooks/Build")


def patch(fn, pairs):
    p = B / fn
    t = p.read_text(encoding="utf-8")
    for a, b in pairs:
        assert t.count(a) == 1, (fn, t.count(a), a[:90])
        t = t.replace(a, b)
    p.write_text(t, encoding="utf-8", newline="\n")
    print("patched", fn)


patch("build_vms.py", [
    (r'''    bad = 0
    for x in texts:
        s = (x or "").strip()
        if not s:
            bad += 1
            continue
        if re.search(r"(.)\1{31,}", s):
            bad += 1
            continue
        if len(s) >= 200 and (len(set(s)) < 8 or sum(ch.isalnum() for ch in s) / len(s) < 0.10):
            bad += 1
    return bad''', r'''    return sum(1 for x in texts if vms_text_bad(x))


def vms_grid_like(s):
    """rev 2e-c: ARC grids in the reasoning ("0 0 1\n0 0 0", "[[0, 1], ...]"): >= 30 % digits among non-space chars."""
    core = re.sub(r"\s", "", s or "")
    return bool(core) and sum(ch.isdigit() for ch in core) / len(core) >= 0.30


def vms_text_bad(x):
    """rev 2e-c: one text is degenerate when empty, or (not grid-like) a 32-character run of one character, < 8 distinct
    characters over 200, or < 10 % letters / digits. A grid is never degenerate (it repeats by nature)."""
    s = (x or "").strip()
    if not s:
        return True
    if vms_grid_like(s):
        return False
    if re.search(r"(.)\1{31,}", s):
        return True
    return len(s) >= 200 and (len(set(s)) < 8 or sum(ch.isalnum() for ch in s) / len(s) < 0.10)'''),
    (r'''def vms_tail_bad(ids):
    """rev 2e (GPT audits E2 / HIGH-10): a continuation that degenerated after the first divergence: 16+ identical token
    ids in a row, or more than 50 % of its 8-grams repeated."""
    ids = list(ids or [])
    run = best = 0
    for i_ in range(1, len(ids)):
        run = run + 1 if ids[i_] == ids[i_ - 1] else 0
        best = max(best, run)
    grams = [tuple(ids[i_:i_ + 8]) for i_ in range(max(0, len(ids) - 7))]
    rep_ = 1 - len(set(grams)) / len(grams) if len(grams) >= 32 else 0.0
    return best >= 15 or rep_ > 0.5''', r'''def vms_tail_bad(ids):
    """rev 2e (GPT audits E2 / HIGH-10), rev 2e-c: the continuation after the first divergence, decoded, is degenerate by
    the shared text rule (a grid is not; empty, repeated punctuation, near-alphabet-free text is)."""
    ids = list(ids or [])
    if len(ids) < 16:
        return False          # too short to judge
    try:
        return vms_text_bad(tokenizer.decode(ids, skip_special_tokens=True))
    except Exception:
        return False'''),
])

patch("build_ems.py", [
    (r'''        def _tail_bad(ids):
            """rev 2e (GPT audit HIGH-2): a continuation that degenerated: 16+ identical tokens in a row, or more than
            50 % of its 8-grams repeated (normal reasoning stays far below)."""
            ids = list(ids or [])
            run = best = 0
            for i_ in range(1, len(ids)):
                run = run + 1 if ids[i_] == ids[i_ - 1] else 0
                best = max(best, run)
            grams = [tuple(ids[i_:i_ + 8]) for i_ in range(max(0, len(ids) - 7))]
            rep_ = 1 - len(set(grams)) / len(grams) if len(grams) >= 32 else 0.0
            return best >= 15 or rep_ > 0.5''', r'''        def _text_bad(x):
            """rev 2e-c (shared with VMS): degenerate = empty, or (not grid-like: < 30 % digits among non-space chars) a
            32-character run of one character, < 8 distinct characters over 200, or < 10 % letters / digits. An ARC grid
            printed in the reasoning is never degenerate."""
            s = (x or "").strip()
            if not s:
                return True
            core = re.sub(r"\s", "", s)
            if core and sum(ch.isdigit() for ch in core) / len(core) >= 0.30:
                return False
            if re.search(r"(.)\1{31,}", s):
                return True
            return len(s) >= 200 and (len(set(s)) < 8 or sum(ch.isalnum() for ch in s) / len(s) < 0.10)

        def _tail_bad(ids):
            """rev 2e (GPT audit HIGH-2), rev 2e-c: the decoded continuation is degenerate by the shared text rule."""
            ids = list(ids or [])
            if len(ids) < 16:
                return False
            try:
                return _text_bad(tokenizer.decode(ids, skip_special_tokens=True))
            except Exception:
                return False'''),
])
