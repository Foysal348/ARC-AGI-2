"""rev 2e-e (found by the rev 2e-d harness run, 2026-10-26).
A (VMS, real bug): vms_window waited up to 900 s for `level` running requests even when the streams had already died or
  finished (harness: 4 of 16 died at connect, 12 finished, the loop sat 15 min at running 0). Now it stops as soon as
  fewer than `level` streams are alive and running is below level: the window then ends with the same error as before
  (or the measured best level), plus the stream errors, instead of a 15-min wait. On GPU this saves an arm's cap.
B (EMS, real bug): the reference arm's record never got probe_complete_vs_target, so _gated (target-only oracle) could
  never mark the production reference adoptable even when it passed.
C (harness only): both fake servers get a 256 listen backlog (Python's default 5 drops some of 16-24 simultaneous
  connects on Windows: the timeouts / resets in the rev 2e-d logs).
D (harness only): the negative tests use long strings (Qwen BPE merges a run of '!' into few ids; < 16 ids = not judged)."""
from pathlib import Path

E14 = Path(r"D:/ARC AGI 2/experiments/Experiment 14 - Optimized Engine on 4xL4 (planned)")
B, H = E14 / "Experiment Notebooks" / "Build", E14 / "src" / "harness"


def patch(p, pairs):
    t = p.read_text(encoding="utf-8")
    for a, b in pairs:
        assert t.count(a) == 1, (p.name, t.count(a), a[:90])
        t = t.replace(a, b)
    p.write_text(t, encoding="utf-8", newline="\n")
    print("patched", p.name)


patch(B / "build_vms.py", [
    ('''            best = max(best, run)
            hist.append((time.perf_counter(), run))
            if run >= level:
                got = level
                break''', '''            best = max(best, run)
            hist.append((time.perf_counter(), run))
            if run >= level:
                got = level
                break
            alive = sum(1 for g in gens if g.is_alive())
            if alive < level and run < level:      # rev 2e-e: the level can no longer be reached (streams died / ended)
                out["streams_ended_before_level"] = level - alive
                break'''),
])

patch(B / "build_ems.py", [
    ('''                _ra.update(gate=EMSR["dflash_vs_target_gate"]["verdict"], probe_flips_vs_target=_dvt.get("large_margin_flips"),''',
     '''                _ra.update(gate=EMSR["dflash_vs_target_gate"]["verdict"], probe_flips_vs_target=_dvt.get("large_margin_flips"),
                           probe_complete_vs_target=_cmp_complete(_dvt),        # rev 2e-e: _gated needs it'''),
])

for fn in ("e14_fake_server.py", "fake_vllm_server.py"):
    patch(H / fn, [('''srv = ThreadingHTTPServer(("127.0.0.1", PORT), H)''',
                    '''ThreadingHTTPServer.request_queue_size = 256      # rev 2e-e: default 5 drops simultaneous connects (Windows)
srv = ThreadingHTTPServer(("127.0.0.1", PORT), H)''')])

patch(H / "make_harness_ems.py", [
    ('''_tb(_enc("!" * 120)) and _tb(_enc(", " * 120))''', '''_tb(_enc("!" * 2000)) and _tb(_enc(", " * 400))'''),
])
t = (H / "make_harness_vms.py").read_text(encoding="utf-8")
n = t.count('"!" * 120')
assert n == 3, n
(H / "make_harness_vms.py").write_text(t.replace('"!" * 120', '"!" * 2000'), encoding="utf-8", newline="\n")
print("patched make_harness_vms.py", n)
