"""VMS rev 2: the GPT pre-GPU serving audit (vLLM part), each claim checked in the vLLM 0.32.0 source."""
from pathlib import Path

p = Path(r"D:/ARC AGI 2/experiments/Experiment 14 - Optimized Engine on 4xL4 (planned)/Experiment Notebooks/Build/build_vms.py")
t = p.read_text(encoding="utf-8")


def rep(a, b):
    global t
    assert t.count(a) == 1, (t.count(a), a[:90])
    t = t.replace(a, b)


# ---- docstring
rep('''reserved slot.
usage: python build_vms.py''', '''reserved slot.
rev 2 (GPT pre-GPU serving audit 2026-10-25, every claim checked in the vLLM 0.32.0 source; Experiment 14 "Bug ang fix"):
FP8 target-only with prefix caching OFF = the identity oracle (#53912: hybrid MTP + prefix caching can return empty /
punctuation output), every later arm gated against it, the reference judged from its own rows; a degenerate-output count
in every gate and window; a gate FAIL is recorded, never adopted, but still measured; the Marlin arm uses
--linear-backend (VLLM_TEST_FORCE_FP8_MARLIN is not in v0.32.0 envs.py) plus a Triton arm, with the selected kernels read
from the log; a static INT4 MTP check (config ignore list + safetensors index, #58807) before any INT4 MTP launch.
usage: python build_vms.py''')

# ---- V1 helpers: degenerate output, kernel lines
rep('''def vms_diverge(a, b):''', r'''def vms_degenerate(texts):
    """rev 2 (GPT audit V1, vLLM #53912: silent empty / repeated-punctuation output with a normal finish): empty text, a
    run of 32+ identical characters, or >= 200 characters with < 4 % distinct characters or < 10 % letters / digits."""
    bad = 0
    for x in texts:
        s = (x or "").strip()
        if not s:
            bad += 1
            continue
        if re.search(r"(.)\1{31,}", s):
            bad += 1
            continue
        if len(s) >= 200 and (len(set(s)) / len(s) < 0.04 or sum(ch.isalnum() for ch in s) / len(s) < 0.10):
            bad += 1
    return bad


def vms_kernels(txt):
    """rev 2 (GPT audit V6): the GEMM / attention kernels vLLM says it selected (never assume the default)."""
    seen = []
    for ln in txt.splitlines():
        m = re.search(r"((?:Selected|Using|Chose)\b.{0,60}?(?:Kernel|kernel|backend|Backend).{0,80})", ln)
        if m and m.group(1).strip() not in seen:
            seen.append(m.group(1).strip())
    return seen[:30]


def vms_diverge(a, b):''')
rep('''               preemptions=_met(p1, "vllm:num_preemptions_total") - _met(p0, "vllm:num_preemptions_total"),
               stream_errors=sum(1 for g in gens if g.err))''', '''               preemptions=_met(p1, "vllm:num_preemptions_total") - _met(p0, "vllm:num_preemptions_total"),
               stream_errors=sum(1 for g in gens if g.err),
               degenerate=vms_degenerate(["".join(g.text) for g in gens if g.text]))     # rev 2 (#53912): sampled text''')

# ---- launch: selected kernels from the log
rep('''    rec["max_concurrency_at_max_len"] = float(m[-1]) if m else None
''', '''    rec["max_concurrency_at_max_len"] = float(m[-1]) if m else None
    rec["kernels"] = vms_kernels(txt)
''')

# ---- arm: oracle, judge, degenerate, measure on FAIL
rep('''def vms_arm(name, flags, *, level=16, gate=True, env_extra=None, cap=14 * 60):
    ok, rec = vms_launch(name, flags, env_extra)
    a = {"ok": False, "launch_sec": rec.get("sec"), "kv_tokens": rec.get("kv_tokens"), "skipped": rec.get("skipped"),
         "flags": flags, "env": env_extra or {}, "level_wanted": level}
    if ok:
        t_end = time.perf_counter() + cap
        try:
            if gate == "ref":
                VMS_REF["serial_a"] = vms_greedy(_S[:6])
                VMS_REF["serial_b"] = vms_greedy(_S[:6])
                VMS_REF["conc_a"] = vms_greedy(_S, concurrent=True)
                VMS_REF["conc_b"] = vms_greedy(_S, concurrent=True)
                a["gate"] = "reference"
                a["aa"] = {"serial": vms_diverge(VMS_REF["serial_a"], VMS_REF["serial_b"]),
                           "conc": vms_diverge(VMS_REF["conc_a"], VMS_REF["conc_b"])}
            elif VMS_REF:
                s, c = vms_greedy(_S[:6]), vms_greedy(_S, concurrent=True)
                ds, dc = vms_diverge(VMS_REF["serial_a"], s), vms_diverge(VMS_REF["conc_a"], c)
                aas = vms_diverge(VMS_REF["serial_a"], VMS_REF["serial_b"])["differ"]
                aac = vms_diverge(VMS_REF["conc_a"], VMS_REF["conc_b"])["differ"]
                passed = ds["differ"] <= aas + 1 and dc["differ"] <= aac + 2
                a["gate"] = ("PASS" if passed else "FAIL") if gate else "diagnostic"
                a["gate_detail"] = {"serial": ds, "conc": dc, "aa_serial": aas, "aa_conc": aac}
            if gate is True and a.get("gate") == "FAIL":
                a["windows_skipped"] = "the correctness gate did not pass"
            else:''', '''VMS_ROWS = {}          # rev 2: each A/A arm's own greedy rows (the production reference and the oracle)


def vms_aa():
    rows = {"serial_a": vms_greedy(_S[:6]), "serial_b": vms_greedy(_S[:6]),
            "conc_a": vms_greedy(_S, concurrent=True), "conc_b": vms_greedy(_S, concurrent=True)}
    return rows, {"serial": vms_diverge(rows["serial_a"], rows["serial_b"]), "conc": vms_diverge(rows["conc_a"], rows["conc_b"]),
                  "degenerate": vms_degenerate(rows["serial_a"] + rows["serial_b"] + rows["conc_a"] + rows["conc_b"])}


def vms_judge(s, c, base, gate=True):
    """The rev 1 rule against `base` (the oracle once it exists): text differences may exceed base's own A/A by 1 serial /
    2 all at once; rev 2: and no more degenerate outputs than base's A/A."""
    ds, dc = vms_diverge(base["serial_a"], s), vms_diverge(base["conc_a"], c)
    aas = vms_diverge(base["serial_a"], base["serial_b"])["differ"]
    aac = vms_diverge(base["conc_a"], base["conc_b"])["differ"]
    dg = vms_degenerate(list(s) + list(c))
    dg_aa = vms_degenerate(base["serial_a"] + base["conc_a"])
    passed = ds["differ"] <= aas + 1 and dc["differ"] <= aac + 2 and dg <= dg_aa
    return ("PASS" if passed else "FAIL") if gate else "diagnostic", {"serial": ds, "conc": dc, "aa_serial": aas, "aa_conc": aac,
                                                                       "degenerate": dg, "aa_degenerate": dg_aa}


def vms_arm(name, flags, *, level=16, gate=True, env_extra=None, cap=14 * 60):
    ok, rec = vms_launch(name, flags, env_extra)
    a = {"ok": False, "launch_sec": rec.get("sec"), "kv_tokens": rec.get("kv_tokens"), "skipped": rec.get("skipped"),
         "flags": flags, "env": env_extra or {}, "level_wanted": level, "kernels": rec.get("kernels")}
    if ok:
        t_end = time.perf_counter() + cap
        try:
            if gate in ("ref", "oracle"):
                rows, aa = vms_aa()
                VMS_ROWS[name] = rows
                a["aa"] = aa
                if gate == "ref":
                    VMS_REF.update(rows)
                    a["gate"] = "reference"
                elif aa["degenerate"] == 0 and all(x for v in rows.values() for x in v):
                    # rev 2: the oracle replaces the gate reference; the production reference is judged from its own rows
                    _r = VMS_ROWS.get("ref_fp8_mtp3_s16")
                    VMS_REF.clear()
                    VMS_REF.update(rows)
                    VMS["gate_reference"] = name + " (FP8, no speculation, prefix caching off)"
                    a["gate"] = "oracle"
                    if _r:
                        _v, _d = vms_judge(_r["serial_a"], _r["conc_a"], rows)
                        VMS["ref_vs_oracle"] = {"verdict": _v, "detail": _d}
                        if VMS["arms"].get("ref_fp8_mtp3_s16"):
                            VMS["arms"]["ref_fp8_mtp3_s16"]["gate"] = _v
                else:
                    a["gate"] = "oracle unusable (empty or degenerate A/A)"
            elif VMS_REF:
                s, c = vms_greedy(_S[:6]), vms_greedy(_S, concurrent=True)
                a["gate"], a["gate_detail"] = vms_judge(s, c, VMS_REF, gate=bool(gate))
            if True:          # rev 2: a FAIL is recorded and never adopted, but the speed is still measured''')

# ---- V2: static INT4 MTP check
rep('''VMS_REF = {}
''', '''VMS_REF = {}


def vms_int4_mtp_static(model):
    """rev 2 (GPT audit V3, vLLM #58807: a W4A16 checkpoint with dense BF16 MTP crashed at load because MTP was not in
    quantization_config.ignore, so the predictor was built quantized). vLLM 0.32.0 builds the predictor under prefix
    'mtp' (qwen3_5_mtp.py:233-235) with the target's quant config (:93-105), so every dense mtp.* weight must be
    exempted by the ignore list. CPU only: config.json + the safetensors index, no weights read."""
    out = {"model": str(model)}
    try:
        cfg = json.loads((Path(model) / "config.json").read_text(encoding="utf-8"))
        q = cfg.get("quantization_config") or (cfg.get("text_config") or {}).get("quantization_config") or {}
        ign = [str(x) for x in (q.get("ignore") or [])]

        def ignored(name):
            return any(re.match(x[3:], name) if x.startswith("re:") else (name == x or name.startswith(x + ".")) for x in ign)
        wm = json.loads((Path(model) / "model.safetensors.index.json").read_text(encoding="utf-8"))["weight_map"]
        mtp = [k for k in wm if k.startswith("mtp.")]
        packed = [k for k in mtp if any(s in k for s in ("weight_packed", "weight_scale", "weight_zero_point"))]
        mods = sorted({k.rsplit(".", 1)[0] for k in mtp if k.endswith(".weight") and ("proj" in k or k.startswith("mtp.fc"))})
        not_ign = [m for m in mods if not ignored(m)]
        out.update(format=q.get("format"), method=q.get("quant_method"), mtp_keys=len(mtp), packed=len(packed),
                   dense_linear_modules=len(mods), not_ignored=not_ign[:10],
                   mtp_ignore_entries=[x for x in ign if "mtp" in x])
        out["ok"] = bool(mtp) and (bool(packed) or not not_ign)
        out["why"] = "MTP dense and exempted by the ignore list" if out["ok"] and not packed else (
            "MTP stored quantized" if out["ok"] else "dense MTP linears missing from the ignore list (#58807 crash)")
    except Exception as e:
        out.update(ok=False, why=f"static check failed: {type(e).__name__}: {e}"[:300])
    VMS["int4_mtp_static"] = out
    e14_save()
    print("VMS INT4 MTP static check:", json.dumps(out)[:600], flush=True)
    return out["ok"]
''')

# ---- V2: the plan
rep('''    PLAN = [
        ("fp8_target_only", vms_flags(MODEL_PATH, spec=0), dict(gate=False)),
        ("fp8_mtp2", vms_flags(MODEL_PATH, spec=2), {}),
        ("fp8_mtp4", vms_flags(MODEL_PATH, spec=4), {}),
        ("int4_mtp3_s16", vms_flags(VMS_INT4), dict(gate=False)),
        ("fp8_mtp3_s20", vms_flags(MODEL_PATH, seqs=20), dict(level=20)),
        ("fp8_mtp3_s24", vms_flags(MODEL_PATH, seqs=24), dict(level=24)),
        ("int4_mtp3_s20", vms_flags(VMS_INT4, seqs=20), dict(level=20, gate=False)),
        ("fp8_mtp3_ssm_fp16", vms_flags(MODEL_PATH, extra={"--mamba-ssm-cache-dtype": "float16"}), {}),
        ("fp8_mtp3_noprefix", vms_flags(MODEL_PATH, prefix=False), {}),
        ("fp8_mtp3_marlin", vms_flags(MODEL_PATH), dict(env_extra={"VLLM_TEST_FORCE_FP8_MARLIN": "1"})),
    ]
    for _name, _fl, _kw in PLAN:
        vms_arm(_name, _fl, **_kw)
    # LAST: 2 x TP2 inside one vLLM server (data parallel 2 x tensor parallel 2), 8 seqs per rank = 16 in all
    VMS_RESERVE = 0.0
    vms_arm("tp2x2_fp8_mtp3", vms_flags(MODEL_PATH, tp=2, dp=2, seqs=8), level=16, gate=True, cap=16 * 60)
    vms_arm("tp2x2_int4_mtp3", vms_flags(VMS_INT4, tp=2, dp=2, seqs=8), level=16, gate=False, cap=16 * 60)''', '''    # rev 2: the oracle first (FP8, no speculation, prefix caching off), then the arms gated against it
    vms_arm("fp8_target_only_noprefix", vms_flags(MODEL_PATH, spec=0, prefix=False), gate="oracle")
    VMS.setdefault("gate_reference", "ref_fp8_mtp3_s16 (the oracle A/A was not usable)")
    _INT4_OK = vms_int4_mtp_static(VMS_INT4)
    PLAN = [
        ("fp8_mtp2", vms_flags(MODEL_PATH, spec=2), {}),
        ("fp8_mtp4", vms_flags(MODEL_PATH, spec=4), {}),
        ("int4_mtp3_s16", vms_flags(VMS_INT4), dict(gate=False)),
        ("fp8_mtp3_s20", vms_flags(MODEL_PATH, seqs=20), dict(level=20)),
        ("fp8_mtp3_s24", vms_flags(MODEL_PATH, seqs=24), dict(level=24)),
        ("int4_mtp3_s20", vms_flags(VMS_INT4, seqs=20), dict(level=20, gate=False)),
        ("fp8_mtp3_ssm_fp16", vms_flags(MODEL_PATH, extra={"--mamba-ssm-cache-dtype": "float16"}), {}),
        ("fp8_mtp3_noprefix", vms_flags(MODEL_PATH, prefix=False), {}),
        # rev 2 (GPT audit V6): VLLM_TEST_FORCE_FP8_MARLIN is gone (not in v0.32.0 envs.py); --linear-backend replaces it
        # (arg_utils.py:1808-1810, config/kernel.py:244-266). A layer type without that backend falls back to auto, so
        # the arm records the kernels the log says were selected.
        ("fp8_mtp3_lb_marlin", vms_flags(MODEL_PATH, extra={"--linear-backend": "marlin"}), {}),
        ("fp8_mtp3_lb_triton", vms_flags(MODEL_PATH, extra={"--linear-backend": "triton"}), {}),
    ]
    VMS["dropped"] = {"fp8_mtp3_marlin (VLLM_TEST_FORCE_FP8_MARLIN=1)": "the env var is not in vLLM 0.32.0 envs.py "
                      "(removed by PR #52182): the arm would have run the reference unchanged; replaced by --linear-backend"}
    for _name, _fl, _kw in PLAN:
        if _name.startswith("int4_") and not _INT4_OK:
            VMS["arms"][_name] = {"ok": False, "skipped": "INT4 MTP static check failed: " + VMS["int4_mtp_static"].get("why", "")}
            VMS["order"].append(_name)
            continue
        vms_arm(_name, _fl, **_kw)
    # LAST: 2 x TP2 inside one vLLM server (data parallel 2 x tensor parallel 2), 8 seqs per rank = 16 in all
    # (GPT audit V5: --max-num-seqs is per DP rank)
    VMS_RESERVE = 0.0
    vms_arm("tp2x2_fp8_mtp3", vms_flags(MODEL_PATH, tp=2, dp=2, seqs=8), level=16, gate=True, cap=16 * 60)
    if _INT4_OK:
        vms_arm("tp2x2_int4_mtp3", vms_flags(VMS_INT4, tp=2, dp=2, seqs=8), level=16, gate=False, cap=16 * 60)''')

# ---- report
rep('''         f"prompts {VMS.get('prompts')}", "",
         "| arm | ok | gate | streams (8k / 40k) | 8k tok/s | x ref | 40k tok/s | x ref | accept 8k / 40k | KV tokens | KV max | preemptions | log errors |",
         "|---|---|---|---|---|---|---|---|---|---|---|---|---|"]''', '''         f"prompts {VMS.get('prompts')}",
         # rev 2 (GPT pre-GPU audit): the oracle, the production reference vs it, the INT4 MTP static check, dropped arms
         f"gate reference: {VMS.get('gate_reference')}",
         f"reference (MTP 3 + prefix caching) vs the oracle: {(VMS.get('ref_vs_oracle') or {}).get('verdict')} "
         f"{json.dumps((VMS.get('ref_vs_oracle') or {}).get('detail'))[:400]}",
         f"INT4 MTP static check: {json.dumps(VMS.get('int4_mtp_static'))[:500]}",
         f"dropped arms: {json.dumps(VMS.get('dropped') or {})}", "",
         "| arm | ok | gate | streams (8k / 40k) | 8k tok/s | x ref | 40k tok/s | x ref | accept 8k / 40k | KV tokens | KV max | preemptions | degenerate 8k / 40k | log errors |",
         "|---|---|---|---|---|---|---|---|---|---|---|---|---|---|"]''')
rep('''                 f"{f((a.get('short') or {}).get('preemptions'))} / {f((a.get('long') or {}).get('preemptions'))} | {a.get('log_errors') or ''} |")''',
    '''                 f"{f((a.get('short') or {}).get('preemptions'))} / {f((a.get('long') or {}).get('preemptions'))} | "
                 f"{f((a.get('short') or {}).get('degenerate'))} / {f((a.get('long') or {}).get('degenerate'))} | "
                 f"{a.get('log_errors') or a.get('skipped') or ''} |")
    L += ["", "selected kernels per arm (from the server log):"] + [
        f"- {k}: {(VMS['arms'][k].get('kernels') or [])[:6]}" for k in VMS.get("order") or []]''')

# ---- markdown
rep('''16 seqs. Arms: target-only; MTP 2 / 4; 20 / 24 seqs; SSM state fp16; prefix caching off; FP8 Marlin; INT4 (RedHat
compressed-tensors) + MTP at 16 and 20; last, 2 x TP2 (data parallel 2 x tensor parallel 2) from a reserved slot.
Each arm: a greedy correctness gate vs the reference's own A/A (INT4 arms diagnostic: other weights), then 8k and 40k
steady windows measured from /metrics.''', '''16 seqs. Arms: the oracle (FP8 target-only, prefix caching off); MTP 2 / 4; 20 / 24 seqs; SSM state fp16; prefix
caching off; --linear-backend marlin / triton; INT4 (RedHat compressed-tensors) + MTP at 16 and 20 after a static MTP
check; last, 2 x TP2 (data parallel 2 x tensor parallel 2) from a reserved slot.
Each arm: a greedy correctness gate vs the oracle's own A/A (rev 2; INT4 arms diagnostic: other weights) with a
degenerate-output count, then 8k and 40k steady windows measured from /metrics.''')
p.write_text(t, encoding="utf-8", newline="\n")
print("patched")
