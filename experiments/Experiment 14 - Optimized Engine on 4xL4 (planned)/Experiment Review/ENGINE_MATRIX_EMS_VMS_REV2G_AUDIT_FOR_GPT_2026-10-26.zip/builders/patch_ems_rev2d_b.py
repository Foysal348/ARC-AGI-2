"""EMS rev 2d-b: the two rev 2b edits that never applied (a str.replace whose search text did not match is silent):
the report (reference name, oracle flag, notes, gate vs the DFlash reference) and the try / except around the whole EMS
body (agent 1 F13). Every replacement here is asserted. Plus the rev 2d report columns (XL band, PCIe-IPC engaged)."""
import textwrap
from pathlib import Path

p = Path(r"D:/ARC AGI 2/experiments/Experiment 14 - Optimized Engine on 4xL4 (planned)/Experiment Notebooks/Build/build_ems.py")
t = p.read_text(encoding="utf-8")


def rep(a, b, n=1):
    global t
    assert t.count(a) == n, (t.count(a), a[:100])
    t = t.replace(a, b)


rep('''    _ref = (EMSR.get("arms") or {}).get("ref_dflash_w6_s16") or {}''',
    '''    _ref = (EMSR.get("arms") or {}).get(EMSR.get("ref_name") or "ref_dflash_w6_s16") or {}''')
rep('''         f"gate reference: {EMSR.get('gate_reference')}",''', '''         f"gate reference: {EMSR.get('gate_reference')} | oracle flag: {EMSR.get('oracle')} | reference: {EMSR.get('ref_name')} "
         f"{EMSR.get('base_cfg')}",
         f"EMS cell error: {(EMSR.get('error') or 'none')[-600:]}",
         f"notes: {json.dumps(EMSR.get('notes') or {})}",
         f"FlashInfer 0.7 overlay (PCIe-IPC arms): {json.dumps(EMSR.get('fi07_overlay'))[:400]}",
         f"PR #45151 patch: {EMSR.get('pr45151_patch')}",''')
rep('''         "", "| arm | ok | gate | streams (8k / 40k) | capped | 8k tok/s | x ref | 40k tok/s | x ref | accept 8k / 40k | step ms 8k / 40k | KV tokens | log errors | probe flips vs ref / vs target |",
         "|---|---|---|---|---|---|---|---|---|---|---|---|---|---|"]''', '''         "", "| arm | ok | gate | streams (8k / 40k) | capped | 8k tok/s | x ref | 40k tok/s | x ref | accept 8k / 40k | step ms 8k / 40k | KV tokens | log errors | probe flips vs ref / vs target | gate vs DFlash ref / skip / error | XL tok/s (streams, ctx/req) | x ref | accept / step ms XL | PCIe-IPC workspace built |",
         "|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
    _rx = _ref.get("xl_tok_s") or 0''')
rep('''                 f"{f(a.get('probe_flips'))} / {f(a.get('probe_flips_vs_target'))} |")''', '''                 f"{f(a.get('probe_flips'))} / {f(a.get('probe_flips_vs_target'))} | "
                 f"{a.get('gate_vs_dflash_ref') or a.get('skipped') or a.get('error') or ''} | "
                 f"{f(a.get('xl_tok_s'))} ({f(a.get('level_xl'))}, {f(a.get('ctx_xl'))}){' ' + str(a.get('xl_error')) if a.get('xl_error') else ''} | "
                 f"{xr(a.get('xl_tok_s'), _rx)} | {f(a.get('accept_xl'), 2)} / {f(a.get('step_ms_xl'), 1)} | "
                 f"{(a.get('pcie_ipc') or {}).get('workspace_built', '')} |")''')

# ---- the whole EMS body in try / except (agent 1 F13): the report cell always runs
_s = t.index("ARMS = r'''")
_i0 = t.index("if EMS_ON and ENGINE_READY:\n", _s)
_i1 = t.index("\n'''\n", _i0)
assert t.count("EMS cell error:", _s, _i1) == 0
_body = t[_i0:_i1]
t = t[:_i0] + "try:\n" + textwrap.indent(_body, "    ") + '''
except BaseException:            # rev 2d-b (agent 1 F13): record, never abort the notebook; the report + bundle cell runs
    EMSR["error"] = traceback.format_exc()[-3000:]
    print("EMS cell error:", EMSR["error"][-1500:], flush=True)
    try:
        E14_STATE.enter("EMS_DONE")
        e14_save()
    except Exception:
        pass''' + t[_i1:]
p.write_text(t, encoding="utf-8", newline="\n")
print("patched")
