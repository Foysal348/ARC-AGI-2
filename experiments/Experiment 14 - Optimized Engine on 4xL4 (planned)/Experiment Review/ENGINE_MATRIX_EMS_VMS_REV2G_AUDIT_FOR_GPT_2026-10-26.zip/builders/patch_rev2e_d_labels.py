"""rev 2e-d (both notebooks; user 2026-10-26: research before changing). Labels only, no rule or data change:
(1) the reports said BOUNDARY is "never auto-certified" while adoptable (EMS _gated, VMS correctness_ok) accepts it.
    Requiring exact identity would reject every arm on batch-size numerics with no evidence of a wrong answer, so the
    rule stays (BOUNDARY = adoptable under the documented near-tie tolerance, audit HIGH-10 "document a distinct rule")
    and a separate certified_exact column (adoptable and PASS_EXACT) is added; the text now says what the code does.
(2) the VMS note said the no-prefix arms' 40k tok/s includes the prefix recompute; since rev 2e tok/s is measured
    after the prefill settled, so the recompute shows only in the e2e column."""
from pathlib import Path

B = Path(r"D:/ARC AGI 2/experiments/Experiment 14 - Optimized Engine on 4xL4 (planned)/Experiment Notebooks/Build")


def patch(fn, pairs):
    p = B / fn
    t = p.read_text(encoding="utf-8")
    for a, b in pairs:
        assert t.count(a) == 1, (fn, t.count(a), a[:90])
        t = t.replace(a, b)
    p.write_text(t, encoding="utf-8", newline="\n")
    print("patched", fn)


patch("build_ems.py", [
    ('''            _a["adoptable"] = bool(_gated(_a)) and _a.get("family") in ("mtp", "dflash")''',
     '''            _a["adoptable"] = bool(_gated(_a)) and _a.get("family") in ("mtp", "dflash")
            _a["certified_exact"] = _a["adoptable"] and _a.get("gate_class") == "PASS_EXACT"     # rev 2e-d''' ),
    ('''"target-only oracle (PASS_EXACT, or BOUNDARY = near-tie divergences: a candidate for task-level evaluation, never "
         "auto-certified), complete probe, no stream error, real running share >= 0.80, no canary leak, XL parity PASS",''',
     '''"target-only oracle (PASS_EXACT, or BOUNDARY = only near-tie divergences, accepted under the documented tolerance "
         "but not exact: confirm on ARC tasks before production), complete probe, no stream error, real running share >= "
         "0.80, no canary leak, XL parity PASS; certified_exact = adoptable and PASS_EXACT",'''),
    ('''{a.get('adoptable')} {a.get('gate_class') or ''} | "''',
     '''{a.get('adoptable')} {a.get('gate_class') or ''}{' certified_exact' if a.get('certified_exact') else ''} | "'''),
])

patch("build_vms.py", [
    ('''    a["ok"] = a["measurement_ok"]        # "speed data from clean windows exists"; adoption is a["adoptable"]''',
     '''    a["certified_exact"] = a["adoptable"] and a.get("gate_class") == "PASS_EXACT"     # rev 2e-d
    a["ok"] = a["measurement_ok"]        # "speed data from clean windows exists"; adoption is a["adoptable"]'''),
    ('''         "BOUNDARY = PASS with near-tie divergences (a candidate for task-level evaluation, never auto-certified)",''',
     '''         "BOUNDARY = PASS with only near-tie divergences (adoptable under the documented tolerance, not exact: confirm "
         "on ARC tasks before production); certified_exact = adoptable and PASS_EXACT",'''),
    ('''         "note: the 40k band shares a ~36k system block; prefix-cache arms reuse it, the oracle and fp8_mtp3_noprefix "
         "prefill it again per request, so their 40k tok/s includes that recompute", "",''',
     '''         "note: the 40k band shares a ~36k system block; prefix-cache arms reuse it, the oracle and fp8_mtp3_noprefix "
         "prefill it again per request: tok/s is measured after the prefill settled (decode only), the recompute shows "
         "in the e2e column", "",'''),
    ('''{a.get('measurement_ok')} / {a.get('capacity_ok')} / {a.get('correctness_ok')} | {a.get('adoptable')} |")''',
     '''{a.get('measurement_ok')} / {a.get('capacity_ok')} / {a.get('correctness_ok')} | {a.get('adoptable')}{' certified_exact' if a.get('certified_exact') else ''} |")'''),
])
