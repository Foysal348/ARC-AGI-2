"""EMS rev 2e part 3 (GPT audits MEDIUM-7 / MEDIUM-9): an XL (~85k) greedy parity check against the target-only oracle's
own XL A/A, and a cross-request sentinel canary (SGLang #36548 bleed); both gate adoption. Asserted replacements."""
from pathlib import Path
p = Path(r"D:/ARC AGI 2/experiments/Experiment 14 - Optimized Engine on 4xL4 (planned)/Experiment Notebooks/Build/build_ems.py")
t = p.read_text(encoding="utf-8")
def rep(a, b, n=1):
    global t
    assert t.count(a) == n, (t.count(a), a[:100])
    t = t.replace(a, b)
rep('''        EMS_TGT = None
''', '''        EMS_TGT = None
        EMS_TGT_XL = None       # rev 2e: the target-only oracle's own XL (~85k) greedy A/A

        def _canary(ctx, level, tag):
            """rev 2e (GPT audit MEDIUM-9, SGLang #36548 cross-request bleed): `level` concurrent greedy requests, each asked
            to repeat its own random sentinel (thinking off); a sentinel in ANOTHER request's output is a leak."""
            import random as _rnd
            rng = _rnd.Random(SEED + level)
            sent = ["Z%04d-%s" % (i, "".join(rng.choice("QWXJVK") for _ in range(6))) for i in range(level)]
            ids = [_e14_chat_ids([{"role": "user", "content": f"Repeat this code exactly once and nothing else: {s_}"}], think=False)
                   for s_ in sent]
            rows = E14M.parity_pass(ctx, ids, max_new=32, concurrent=True, tag=tag + "_canary")
            texts = [tokenizer.decode(r_.get("ids") or [], skip_special_tokens=True) for r_ in rows]
            return {"level": level, "own_hits": sum(1 for s_, x in zip(sent, texts) if s_ in x),
                    "foreign_leaks": sum(1 for i, x in enumerate(texts) for j, s_ in enumerate(sent) if j != i and s_ in x),
                    "errors": sum(1 for r_ in rows if r_.get("error")), "server_not_idle": _dirty_rows(rows)}

        def _xl_rows(ctx, tag):
            return E14M.parity_pass(ctx, _X[:4], max_new=256, concurrent=True, tag=tag + "_xl") if _X else None

        def _xl_verdict(x, base_a, base_b):
            """rev 2e (GPT audits MEDIUM-7 / E11): ~85k-context greedy rows vs the oracle's XL A/A (flips and tails decide)."""
            if not x or not base_a or not base_b:
                return None
            cx = E14M.compare_passes(base_a, x[:len(base_a)], "xl vs oracle", n=256)
            aa = E14M.compare_passes(base_a, base_b, "oracle xl A/A", n=256)
            if not (_cmp_complete(cx) and _cmp_complete(aa)):
                return "INCOMPLETE"
            ok = cx["large_margin_flips"] <= aa["large_margin_flips"] and _tail_count(x) <= max(_tail_count(base_a), _tail_count(base_b))
            return "PASS" if ok else "FAIL"
''')
rep('''                ref, summ = _aa_rows("ems_tgt")
                if summ["complete"]:      # rev 2b: no errors, no missing margins, not dirty
                    globals()["EMS_TGT"] = ref
                return summ''', '''                ref, summ = _aa_rows("ems_tgt")
                if summ["complete"]:      # rev 2b: no errors, no missing margins, not dirty
                    globals()["EMS_TGT"] = ref
                if _X:                    # rev 2e: the oracle's own XL A/A
                    xa, xb = _xl_rows(E14_CTX, "ems_tgt_a"), _xl_rows(E14_CTX, "ems_tgt_b")
                    if xa and xb and not _dirty_rows(xa, xb):
                        globals()["EMS_TGT_XL"] = (xa, xb)
                    summ["xl_aa"] = E14M.compare_passes(xa or [], xb or [], "target-only XL A/A", n=256)
                summ["canary"] = EMSR["canary_oracle"] = _canary(E14_CTX, LEVEL, "ems_tgt")
                return summ''')
rep('''            if _DFL is not None and _DFL is not EMS_REF:
                out["vs_dflash_ref"] = _gate_from_rows({"serial_a": s, "conc_a": c}, _DFL, tag + " vs DFlash reference")["verdict"]
            return out''', '''            if _DFL is not None and _DFL is not EMS_REF:
                out["vs_dflash_ref"] = _gate_from_rows({"serial_a": s, "conc_a": c}, _DFL, tag + " vs DFlash reference")["verdict"]
            if EMS_TGT_XL and ctx.left() > ctx.m(240):      # rev 2e: XL parity and the canary (adoption needs both)
                out["xl_gate"] = _xl_verdict(_xl_rows(ctx, tag), *EMS_TGT_XL)
            out["canary"] = _canary(ctx, len(EMS_REF["conc_a"]), tag)
            if out["canary"].get("server_not_idle"):
                out["server_not_idle"] = True
            return out''')
rep('''             "gate_class": ((r or {}).get("gate") or {}).get("gate_class"),''', '''             "gate_class": ((r or {}).get("gate") or {}).get("gate_class"),
             "xl_gate": ((r or {}).get("gate") or {}).get("xl_gate"),
             "canary_leaks": (((r or {}).get("gate") or {}).get("canary") or {}).get("foreign_leaks"),
             "canary_errors": (((r or {}).get("gate") or {}).get("canary") or {}).get("errors"),''')
rep('''            if not (EMSR.get("oracle") == "target_only" and EMS_TGT is not None and _cmp_complete(EMSR.get("probe_tgt_aa"))):
                return False''', '''            if not (EMSR.get("oracle") == "target_only" and EMS_TGT is not None and _cmp_complete(EMSR.get("probe_tgt_aa"))):
                return False
            # rev 2e (GPT audits MEDIUM-7 / MEDIUM-9): no cross-request leak, and the XL parity (when measured) passed
            if a.get("canary_leaks") or a.get("canary_errors") or a.get("canary_leaks") is None:
                return False
            if a.get("xl_gate") not in (None, "PASS"):
                return False
            if (EMSR.get("canary_oracle") or {}).get("foreign_leaks"):
                return False''')
rep('''{a.get('adoptable')} {a.get('gate_class') or ''} |")''', '''{a.get('adoptable')} {a.get('gate_class') or ''} | "
                 f"{a.get('xl_gate') or ''} | {a.get('canary_leaks') if a.get('canary_leaks') is not None else ''} |")''')
rep('''PCIe-IPC workspace built | adoptable |",''', '''PCIe-IPC workspace built | adoptable / gate class | XL gate | canary leaks |",''')
rep('''         "|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|"]''',
    '''         "|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|"]''')
rep('''         f"EMS cell error: {(EMSR.get('error') or 'none')[-600:]}",''', '''         f"EMS cell error: {(EMSR.get('error') or 'none')[-600:]}",
         "tok/s = SGLang decode-line rate in a steady window (decode only, not end-to-end); adoptable = gate PASS vs the "
         "target-only oracle (PASS_EXACT, or BOUNDARY = near-tie divergences: a candidate for task-level evaluation, never "
         "auto-certified), complete probe, no stream error, real running share >= 0.80, no canary leak, XL parity PASS",
         f"oracle canary: {EMSR.get('canary_oracle')}",''')
p.write_text(t, encoding="utf-8", newline="\n")
print("patched 2e part 3")
