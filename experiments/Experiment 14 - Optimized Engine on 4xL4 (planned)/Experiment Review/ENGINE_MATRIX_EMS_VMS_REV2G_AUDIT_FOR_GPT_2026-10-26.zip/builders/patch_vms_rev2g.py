"""VMS rev 2g: one pass over the GPT rev 2f audits (R1-R6 + R2F-01..10) and our agents; every claim was checked in the
code first. Speed data is always kept; only adoption without evidence is stopped.
- vms_classify fail-closed (R1 / R2F-01): XL gate must be PASS whenever XL prompts exist; the arm's canary must exist
  with 0 errors / 0 leaks at the arm's level; DP (2 x TP2) rows are diagnostic_only (no XL / per-rank canary); a
  PCIe-IPC arm whose log lacks the init line is backend_unverified (GPT R-2).
- oracle readiness (R2F-10): its XL A/A complete and its canary clean too.
- vms_window_healthy (R2 / R2F-03): every stream got a first token, threads joined, idle after.
- grid rule structural (R3 / R2F-06), same as EMS: digits / brackets / commas / whitespace only, every row <= 30 cells.
- INT4 MTP static check (R4): packed MTP modules that the ignore list exempts (vLLM would build them dense) fail too.
- vms_judge / vms_aa (R5): the planned row counts (6 serial, all-at-once = every prompt), never fewer.
- canary informative / classification (R2F-07); the half-started server killed on a start crash and the arm record
  stored before post-processing (agent 4 #3 / #5); the wait-loop exit only once the level cannot be reached even at
  level - 1 (agent 4 #4); window streams get max_tokens up to 32k (a stream ending inside the 75-s window lowered
  running_mean = a false reject, GPT note); the e2e label says what it is (R2F-09)."""
from pathlib import Path

p = Path(r"D:/ARC AGI 2/experiments/Experiment 14 - Optimized Engine on 4xL4 (planned)/Experiment Notebooks/Build/build_vms.py")
t = p.read_text(encoding="utf-8")


def rep(a, b, n=1):
    global t
    assert t.count(a) == n, (t.count(a), a[:100])
    t = t.replace(a, b)


rep('''def vms_grid_like(s):
    """rev 2e-c: ARC grids in the reasoning ("0 0 1\\n0 0 0", "[[0, 1], ...]"): >= 30 % digits among non-space chars."""
    core = re.sub(r"\\s", "", s or "")
    return bool(core) and sum(ch.isdigit() for ch in core) / len(core) >= 0.30''', '''def vms_grid_like(s):
    """rev 2g (GPT R2F-06): an ARC grid by structure ("0 0 1\\n0 0 0", "[[0, 1], ...]"): only digits / brackets / commas /
    whitespace and every row <= 30 cells (the ARC maximum). "0" * 250 or "0 0 0 ..." x 200 is not a grid."""
    s = (s or "").strip()
    return bool(re.fullmatch(r"[0-9,\\[\\]\\s]+", s)) and len(re.findall(r"\\d", s)) >= 2 \\
        and all(len(re.findall(r"\\d", r_)) <= 30 for r_ in re.split(r"\\]|\\n", s))''')

# ---- window streams long enough not to finish inside the window
rep('''    gens = [VGen(prompts[i % len(prompts)], 8192) for i in range(level)]''',
    '''    # rev 2g: max_tokens up to 32k inside max-model-len 106,496 (a stream that finished inside the window lowered
    # running_mean: a false reject)
    gens = [VGen(prompts[i % len(prompts)], max(1024, min(32768, 106496 - len(prompts[i % len(prompts)]) - 512)))
            for i in range(level)]''')

# ---- wait-loop exit only when even level - 1 cannot be reached
rep('''            if alive < level and run < level:      # rev 2e-e: the level can no longer be reached (streams died / ended)''',
    '''            if alive < level - 1 or (alive < level and run >= alive):      # rev 2e-e / 2g: level (or level - 1) unreachable''')

# ---- healthy window: first token on every stream, joined, idle
rep('''        and (w.get("measured_level") or 0) >= level and (w.get("running_mean") or 0) >= 0.80 * level''',
    '''        and (w.get("measured_level") or 0) >= level and (w.get("running_mean") or 0) >= 0.80 * level \\
        and w.get("no_first_token", level) == 0 and w.get("threads_not_joined", 1) == 0 and w.get("idle_after") is True''')

# ---- canary informative / classification + missing rows = errors
rep('''    return {"level": level, "own_hits": own, "foreign_leaks": leaks, "errors": sum(1 for r in rows if r.get("error"))}''',
    '''    c_ = {"level": level, "own_hits": own, "foreign_leaks": leaks,
          "errors": sum(1 for r in rows if r.get("error")) + max(0, level - len(rows))}
    # rev 2g (GPT R2F-07): 0 own hits = the detector showed nothing: INCONCLUSIVE, not proof of isolation
    c_["informative"] = own > 0 and c_["errors"] == 0
    c_["classification"] = ("FAIL" if leaks else "INCOMPLETE" if c_["errors"] else
                            "INCONCLUSIVE" if not c_["informative"] else "PASS_NO_OBSERVED_LEAK")
    return c_''')

# ---- planned row counts (R5)
rep('''    complete = all(x["expected"] and x["compared"] == x["expected"] and not x["missing_margins"] for x in (s, c))''',
    '''    complete = all(x["expected"] and x["compared"] == x["expected"] and not x["missing_margins"] for x in (s, c)) \\
        and s["expected"] >= min(6, len(_S)) and c["expected"] >= len(_S)       # rev 2g (GPT R5): the planned rows''')
rep('''    if any(x["errors"] or x["missing_margins"] or not x["compared"] for x in (cs, aa_s, cc, aa_c)):''',
    '''    if any(x["errors"] or x["missing_margins"] or not x["compared"] for x in (cs, aa_s, cc, aa_c)) \\
            or cs["expected"] < min(6, len(_S)) or cc["expected"] < len(_S):       # rev 2g (GPT R5): the planned rows''')

# ---- INT4 MTP static check (R4)
rep('''        out["ok"] = bool(mtp) and not not_ign        # rev 2b: a partly packed MTP with un-ignored dense linears = #58807''',
    '''        # rev 2g (GPT R4): a packed MTP module that the ignore list exempts would be built dense (wrong shapes)
        packed_mods = sorted({k.rsplit(".", 1)[0] for k in packed})
        packed_ign = [m for m in packed_mods if ignored(m)]
        out.update(packed_modules=len(packed_mods), packed_but_ignored=packed_ign[:10])
        out["ok"] = bool(mtp) and not not_ign and not packed_ign        # rev 2b: un-ignored dense linears = #58807''')

# ---- vms_launch: kill a half-started server
rep('''    srv.start()
    ok, why = srv.wait_ready(min(30 * 60, left))''', '''    srv.start()
    try:          # rev 2g: a crash while this server starts never leaves it holding the GPUs
        ok, why = srv.wait_ready(min(30 * 60, left))
    except BaseException:
        try:
            srv.kill()
        except Exception:
            pass
        raise''')

# ---- arm record stored at once; DP diagnostic
rep('''         "flags": flags, "env": env_extra or {}, "level_wanted": level, "kernels": rec.get("kernels")}
    if ok:''', '''         "flags": flags, "env": env_extra or {}, "level_wanted": level, "kernels": rec.get("kernels")}
    VMS["arms"][name] = a          # rev 2g: a crash in the post-processing keeps the measured windows
    if ok:''')
rep('''        _dp = "--data-parallel-size" in [str(x) for x in flags]
        try:''', '''        _dp = "--data-parallel-size" in [str(x) for x in flags]
        a["diagnostic_only"] = bool(_dp)       # rev 2g (GPT R2F-01): no XL / per-rank canary on DP: never adoptable
        try:''')

# ---- oracle readiness (R2F-10)
rep('''                elif aa["degenerate"] == 0 and aa["complete"] and not a["canary"]["foreign_leaks"]:''',
    '''                elif aa["degenerate"] == 0 and aa["complete"] and a["canary"].get("foreign_leaks") == 0 \\
                        and a["canary"].get("errors") == 0 and ((not _X) or (isinstance(aa.get("xl"), dict)
                        and aa["xl"].get("expected", 0) > 0 and aa["xl"].get("compared") == aa["xl"].get("expected")
                        and not aa["xl"].get("missing_margins"))):      # rev 2g (GPT R2F-10): XL A/A + canary clean''')

# ---- classify fail-closed
rep('''    a["correctness_ok"] = a.get("gate") == "PASS" and a.get("xl_gate") in (None, "PASS") \\
        and not ((a.get("canary") or {}).get("foreign_leaks") or (a.get("canary") or {}).get("errors"))
    a["adoptable"] = bool(VMS.get("oracle_ready") and a["measurement_ok"] and a["capacity_ok"] and a["correctness_ok"]
                          and a.get("server_alive_after") and not a.get("log_errors") and not a.get("error"))''',
    '''    # rev 2g (GPT R1 / R2F-01): missing evidence never counts as a pass: XL PASS whenever XL prompts exist; the canary
    # present, at this level, 0 errors / 0 leaks; DP rows diagnostic; a PCIe-IPC arm must show the init line
    _c = a.get("canary")
    _canary_ok = isinstance(_c, dict) and _c.get("level") == level and _c.get("errors") == 0 and _c.get("foreign_leaks") == 0
    _xl_ok = a.get("xl_gate") == "PASS" if _X else a.get("xl_gate") in (None, "PASS")
    a["backend_unverified"] = bool((a.get("env") or {}).get("VLLM_ALLREDUCE_USE_FLASHINFER_PCIE_IPC")
                                   and not (a.get("pcie_ipc") or {}).get("initialized"))
    a["correctness_ok"] = a.get("gate") == "PASS" and _xl_ok and _canary_ok
    a["adoptable"] = bool(VMS.get("oracle_ready") and a["measurement_ok"] and a["capacity_ok"] and a["correctness_ok"]
                          and not a.get("diagnostic_only") and not a["backend_unverified"]
                          and a.get("server_alive_after") and not a.get("log_errors") and not a.get("error"))
    a["candidate_for_arc_validation"] = a["adoptable"]
    a["production_approved"] = False         # rev 2g: needs the 60k+ generation and ARC task gates (not in this matrix)''')

# ---- e2e label
rep('''"tok/s = steady decode after the prefill settled; e2e = output tokens from submission to the window end / wall; "''',
    '''"tok/s = steady decode after the prefill settled; e2e = output tokens from submission to the window end / wall (a "
         "submission-to-window-end rate, not completed-request task throughput); "''')
p.write_text(t, encoding="utf-8", newline="\n")
print("patched")
