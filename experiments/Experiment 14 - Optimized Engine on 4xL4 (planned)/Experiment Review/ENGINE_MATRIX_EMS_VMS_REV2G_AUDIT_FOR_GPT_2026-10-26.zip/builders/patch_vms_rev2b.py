"""VMS rev 2b: the 2026-10-26 agent audit (agent 3 = VMS code paths, agent 4 = VMS flags vs vLLM v0.32.0), every claim
re-checked in the source by me before this patch."""
from pathlib import Path

p = Path(r"D:/ARC AGI 2/experiments/Experiment 14 - Optimized Engine on 4xL4 (planned)/Experiment Notebooks/Build/build_vms.py")
t = p.read_text(encoding="utf-8")


def rep(a, b):
    global t
    assert t.count(a) == 1, (t.count(a), a[:100])
    t = t.replace(a, b)


# ---- docstring
rep('''usage: python build_vms.py''', '''rev 2b (4-agent audit 2026-10-26): logprob-margin gate (large-margin flips, as EMS) instead of whole-text equality;
one deadline per arm (the 2 x TP2 reserve can no longer be eaten after a launch); windows stop on a dead server, accept a
KV plateau, and start only after the prefill settled; DP metrics per engine (KV max, every KV line); stream error events;
socket shutdown on stop; greedy rows saved; the lb_marlin arm dropped (SM 8.9 auto already = Marlin W8A16); the 2 x TP2
arms with one API server and custom all-reduce allowed; the INT4 static check exact-name like vLLM; FP8 prefetch.
usage: python build_vms.py''')

# ---- prefetch the FP8 checkpoint (the reference and most arms), not INT4 + DFlash2 (agent 3, cell 2 / install cell)
c3_old = '''_wdirs = (SGL_MODEL_PATH, SGL_DRAFT_PATH) if ENGINE_BACKEND == "sglang" else (MODEL_PATH,)   # E11-05'''
rep('''cells = [S[0], c1, c1b, S[3], S[4], pre + V1, V2, V3]''',
    '''c3 = rep(S[3], ''' + repr(c3_old) + ''',
         "_wdirs = (MODEL_PATH,)   # VMS rev 2b: the FP8 reference loads first (the SGLang default read INT4 + DFlash2)")
cells = [S[0], c1, c1b, c3, S[4], pre + V1, V2, V3]''')

# ---- V1: imports
rep('''import shlex, statistics, threading
VMS = {''', '''import shlex, socket, statistics, threading
VMS = {''')

# ---- V1: VServer.kill = SIGTERM, wait, then SIGKILL (agent 3 F15)
rep('''    def kill(self):
        if self.proc is None:
            return
        try:
            if hasattr(os, "killpg"):
                os.killpg(self.proc.pid, _signal.SIGKILL if hasattr(_signal, "SIGKILL") else _signal.SIGTERM)
            else:
                self.proc.kill()
        except Exception:
            pass
        try:
            self.proc.wait(timeout=60)
        except Exception:
            pass''', '''    def kill(self):
        if self.proc is None:
            return
        for sig, wait in ((_signal.SIGTERM, 30), (getattr(_signal, "SIGKILL", _signal.SIGTERM), 60)):   # rev 2b: TERM first
            try:
                if hasattr(os, "killpg"):
                    os.killpg(self.proc.pid, sig)
                else:
                    self.proc.kill()
            except Exception:
                pass
            try:
                self.proc.wait(timeout=wait)
                return
            except Exception:
                pass''')

# ---- V1: prometheus: per-name sum and per-name max over label sets (DP = one label set per engine; agent 3 F5, agent 4 F4c)
rep('''        if m:
            try:
                out[m.group(1)] = out.get(m.group(1), 0.0) + float(m.group(3))
            except ValueError:
                pass
    return out''', '''        if m:
            try:
                v = float(m.group(3))
            except ValueError:
                continue
            out[m.group(1)] = out.get(m.group(1), 0.0) + v
            out[m.group(1) + "@max"] = max(out.get(m.group(1) + "@max", v), v)     # rev 2b: per-engine max (DP)
    return out''')

# ---- V1: VGen with logprobs, stream error events, socket shutdown (agent 3 F6, F7, F10)
rep('''    def __init__(self, ids, max_new, temperature=1.0, ignore_eos=True, seed=None):
        super().__init__(daemon=True)
        self.body = {"model": "q27", "prompt": list(ids), "max_tokens": int(max_new), "temperature": temperature,
                     "top_p": 0.95 if temperature else 1.0, "top_k": 20 if temperature else -1, "stream": True,
                     "ignore_eos": ignore_eos}
        if seed is not None:
            self.body["seed"] = seed
        self.text, self.err, self._resp, self._stop = [], None, None, False''', '''    def __init__(self, ids, max_new, temperature=1.0, ignore_eos=True, seed=None, logprobs=0):
        super().__init__(daemon=True)
        self.body = {"model": "q27", "prompt": list(ids), "max_tokens": int(max_new), "temperature": temperature,
                     "top_p": 0.95 if temperature else 1.0, "top_k": 20 if temperature else -1, "stream": True,
                     "ignore_eos": ignore_eos}
        if seed is not None:
            self.body["seed"] = seed
        if logprobs:
            self.body["logprobs"] = int(logprobs)      # rev 2b: the gate compares tokens and top-1 / top-2 margins
        self.text, self.err, self._resp, self._stop = [], None, None, False
        self.tokens, self.margins = [], []''')
rep('''                d = json.loads(line[5:])
                for c in d.get("choices") or []:
                    self.text.append(c.get("text") or "")''', '''                d = json.loads(line[5:])
                if "error" in d or d.get("object") == "error":     # rev 2b: an in-stream error event (serving.py:497-503)
                    self.err = ("stream error: " + json.dumps(d.get("error") or d.get("message") or d))[:200]
                    break
                for c in d.get("choices") or []:
                    self.text.append(c.get("text") or "")
                    lp = c.get("logprobs") or {}
                    self.tokens.extend(lp.get("tokens") or [])
                    for top in lp.get("top_logprobs") or []:
                        vals = sorted((v for v in (top or {}).values() if isinstance(v, (int, float))), reverse=True)
                        self.margins.append(round(vals[0] - vals[1], 4) if len(vals) >= 2 else None)''')
rep('''    def stop(self):
        self._stop = True
        try:
            if self._resp is not None:
                self._resp.close()
        except Exception:
            pass''', '''    def stop(self):
        self._stop = True
        try:      # rev 2b: shut the socket down first, so a reader blocked in recv returns (close() alone can wait on it)
            self._resp.fp.raw._sock.shutdown(socket.SHUT_RDWR)
        except Exception:
            pass
        try:
            if self._resp is not None:
                self._resp.close()
        except Exception:
            pass

    def row(self):
        return {"text": "".join(self.text), "tokens": list(self.tokens), "margins": list(self.margins), "error": self.err}''')

# ---- V1: vms_window with a deadline, dead-server stop, plateau, prefill settle, try/finally, per-engine KV max
rep('''def vms_window(prompts, level, secs, tag):
    """`level` streams; wait until vllm:num_requests_running reaches level (or a stable level - 1); measure the counters."""
    if HARD_STOP - time.perf_counter() < secs + 180:
        return {"skipped": "deadline"}
    gens = [VGen(prompts[i % len(prompts)], 8192) for i in range(level)]
    for g in gens:
        g.start()
    t_w, got, best = time.perf_counter(), None, 0
    while time.perf_counter() - t_w < min(900, HARD_STOP - time.perf_counter() - secs - 120):
        try:
            run = _met(vms_prom(), "vllm:num_requests_running")
        except Exception:
            run = 0
        best = max(best, run)
        if run >= level:
            got = level
            break
        time.sleep(2)
    if got is None and best >= level - 1:
        got = int(best)
    out = {"tag": tag, "level": level, "measured_level": got, "wait_sec": round(time.perf_counter() - t_w, 1)}
    if got is None:
        for g in gens:
            g.stop()
        out["error"] = f"the server never ran {level} requests (max {best})"
        return out
    p0, t0 = vms_prom(), time.perf_counter()
    runs, kvs = [], []
    while time.perf_counter() - t0 < secs:
        time.sleep(2)
        try:
            p = vms_prom()
            runs.append(_met(p, "vllm:num_requests_running"))
            kvs.append(_met(p, "vllm:kv_cache_usage_perc", "vllm:gpu_cache_usage_perc"))
        except Exception:
            pass
    p1, t1 = vms_prom(), time.perf_counter()
    for g in gens:
        g.stop()
    dt = t1 - t0''', '''def _vms_dead():
    return VMS_SERVER is not None and not VMS_SERVER.alive()


def vms_window(prompts, level, secs, tag, deadline=None):
    """`level` streams; wait until vllm:num_requests_running reaches level, a stable level - 1, or a KV plateau (requests
    waiting while running stays flat for 30 s); then wait for the prefill to settle; then measure the counters.
    rev 2b: every wait ends at `deadline` (the arm's own: the 2 x TP2 reserve stays intact) and on a dead server."""
    end = min(HARD_STOP - 120, deadline or HARD_STOP)
    if end - time.perf_counter() < secs + 60:
        return {"skipped": "deadline"}
    gens = [VGen(prompts[i % len(prompts)], 8192) for i in range(level)]
    out = {"tag": tag, "level": level}
    try:
        for g in gens:
            g.start()
        t_w, got, best, hist, plateau = time.perf_counter(), None, 0, [], False
        while time.perf_counter() < min(t_w + 900, end - secs - 30):
            if _vms_dead():
                out["error"] = "the server died while the streams were admitted"
                return out
            try:
                p = vms_prom()
                run, wait = _met(p, "vllm:num_requests_running"), _met(p, "vllm:num_requests_waiting")
            except Exception:
                run, wait = 0, 0
            best = max(best, run)
            hist.append((time.perf_counter(), run))
            if run >= level:
                got = level
                break
            flat = [r for t_, r in hist if t_ >= hist[-1][0] - 30]
            if wait > 0 and run >= 1 and hist[-1][0] - hist[0][0] >= 30 and len(set(flat)) == 1:
                got, plateau = int(run), True        # KV-bound: measure what the server really holds
                break
            time.sleep(2)
        if got is None and best >= level - 1:
            got = int(best)
        out.update(measured_level=got, plateau=plateau, wait_sec=round(time.perf_counter() - t_w, 1))
        if got is None:
            out["error"] = f"the server never ran {level} requests (max {best})"
            return out
        # rev 2b (agent 3 F4): a request counts as running once its first prefill chunk is scheduled; start the window
        # only when nothing waits (or the plateau) and the prompt-token counter stopped moving (<= 120 s)
        t_s, last = time.perf_counter(), None
        while time.perf_counter() - t_s < 120 and time.perf_counter() < end - secs - 15:
            try:
                p = vms_prom()
                pt, wait = _met(p, "vllm:prompt_tokens_total"), _met(p, "vllm:num_requests_waiting")
            except Exception:
                break
            if last is not None and pt == last and (wait == 0 or plateau):
                break
            last = pt
            time.sleep(4)
        out["settle_sec"] = round(time.perf_counter() - t_s, 1)
        p0, t0 = vms_prom(), time.perf_counter()
        runs, kvs = [], []
        while time.perf_counter() - t0 < secs:
            time.sleep(2)
            if _vms_dead():
                out["error"] = "the server died inside the window"
                return out
            try:
                p = vms_prom()
                runs.append(_met(p, "vllm:num_requests_running"))
                kvs.append(p.get("vllm:kv_cache_usage_perc@max", 0.0))      # rev 2b: per engine, never the DP sum
            except Exception:
                pass
        p1, t1 = vms_prom(), time.perf_counter()
    except Exception as e:
        out["error"] = f"{type(e).__name__}: {e}"[:300]
        return out
    finally:
        for g in gens:
            g.stop()
    dt = t1 - t0''')

# ---- V1: vms_greedy with logprobs and a deadline (agent 3 F8)
rep('''def vms_greedy(prompts, n_tok=256, concurrent=False):
    gens = [VGen(p, n_tok, temperature=0.0, ignore_eos=False) for p in prompts]
    if concurrent:
        for g in gens:
            g.start()
        for g in gens:
            g.join(900)
    else:
        for g in gens:
            g.start()
            g.join(900)
    return ["".join(g.text) for g in gens]''', '''def vms_greedy(prompts, n_tok=256, concurrent=False, deadline=None):
    """Greedy rows {text, tokens, top-1 / top-2 margins, error}; rev 2b: one deadline for the whole pass (a stalled server
    cannot cost 12 x 900 s); a row still running at the deadline is stopped and marked."""
    end = min(HARD_STOP - 120, deadline or HARD_STOP)
    gens = [VGen(p, n_tok, temperature=0.0, ignore_eos=False, logprobs=2) for p in prompts]
    if concurrent:
        for g in gens:
            g.start()
        for g in gens:
            g.join(max(0.0, min(900, end - time.perf_counter())))
    else:
        for g in gens:
            if end - time.perf_counter() < 30:
                g.err = "skipped: arm deadline"
                continue
            g.start()
            g.join(max(0.0, min(900, end - time.perf_counter())))
    for g in gens:
        if g.is_alive():
            g.stop()
            g.err = g.err or "stopped: arm deadline"
    return [g.row() for g in gens]''')

# ---- V1: kernel lines, case-insensitive + the --linear-backend fallback lines (agent 4 F2)
rep('''        m = re.search(r"((?:Selected|Using|Chose)\\b.{0,60}?(?:Kernel|kernel|backend|Backend).{0,80})", ln)''',
    '''        m = re.search(r"((?:Selected|Using|Chose)\\b.{0,60}?(?:kernel|backend).{0,80}|--linear-backend=.{0,160})", ln, re.I)''')

# ---- V1: token-level divergence with margins (EMS compare_passes rule)
rep('''def vms_diverge(a, b):
    n = sum(1 for x, y in zip(a, b) if x != y)
    first = [next((i for i, (u, v) in enumerate(zip(x, y)) if u != v), min(len(x), len(y)) if len(x) != len(y) else None)
             for x, y in zip(a, b)]
    return {"differ": n, "compared": min(len(a), len(b)), "first_divergence_chars": first}''', '''def vms_diverge(a, b):
    """rev 2b (agent 3 F10): rows compared by token (EMS compare_passes rule). A large-margin flip = a divergence where
    either run was confident (top-1 minus top-2 > 1 nat); a divergence without both margins is missing evidence, never
    "no flip"; an errored or empty row is an error, never skipped."""
    expected = max(len(a), len(b))
    per = []
    for i in range(expected):
        ra = a[i] if i < len(a) else {"error": "missing row"}
        rb = b[i] if i < len(b) else {"error": "missing row"}
        ia, ib = list(ra.get("tokens") or []), list(rb.get("tokens") or [])
        if ra.get("error") or rb.get("error") or not ia or not ib:
            per.append({"error": ra.get("error") or rb.get("error") or "no tokens"})
            continue
        if ia == ib:
            per.append({"identical": True})
            continue
        k = next((j for j, (u, v) in enumerate(zip(ia, ib)) if u != v), min(len(ia), len(ib)))
        ma = (ra.get("margins") or [None] * (k + 1))[k] if k < len(ra.get("margins") or []) else None
        mb = (rb.get("margins") or [None] * (k + 1))[k] if k < len(rb.get("margins") or []) else None
        per.append({"identical": False, "first_divergence": k, "margin_a": ma, "margin_b": mb,
                    "missing_margin": ma is None or mb is None,
                    "large_margin_flip": ma is not None and mb is not None and max(ma, mb) > 1.0})
    ok = [x for x in per if "identical" in x]
    div = [x for x in ok if not x["identical"]]
    return {"expected": expected, "compared": len(ok), "errors": expected - len(ok),
            "identical": sum(1 for x in ok if x["identical"]), "differ": len(div),
            "large_margin_flips": sum(1 for x in div if x["large_margin_flip"]),
            "missing_margins": sum(1 for x in div if x["missing_margin"]),
            "first_divergence": [x.get("first_divergence") for x in per]}''')

# ---- V2: launch: time left computed after the kill + GPU wait (agent 3 F2); every KV line (agent 4 F4c)
rep('''    left = HARD_STOP - time.perf_counter() - (0 if force else VMS_RESERVE) - 8 * 60
    if left < 12 * 60:
        rec["skipped"] = "reserved 2 x TP2 slot / hard stop"
        VMS["launches"].append(rec)
        return False, rec
    if VMS_SERVER is not None:
        VMS_SERVER.kill()
        VMS_SERVER = None
    if not VMS_FAKE:
        _e11_gpu_free()''', '''    if HARD_STOP - time.perf_counter() - (0 if force else VMS_RESERVE) - 8 * 60 < 12 * 60:
        rec["skipped"] = "reserved 2 x TP2 slot / hard stop"
        VMS["launches"].append(rec)
        return False, rec
    if VMS_SERVER is not None:
        VMS_SERVER.kill()
        VMS_SERVER = None
    if not VMS_FAKE:
        rec["gpu_free"] = _e11_gpu_free()
    left = HARD_STOP - time.perf_counter() - (0 if force else VMS_RESERVE) - 8 * 60     # rev 2b: after the kill + GPU wait
    if left < 10 * 60:
        rec["skipped"] = "reserved 2 x TP2 slot / hard stop (after the GPU wait)"
        VMS["launches"].append(rec)
        return False, rec''')
rep('''    rec["kv_tokens"] = int(m[-1].replace(",", "")) if m else None''', '''    rec["kv_tokens_all"] = [int(x.replace(",", "")) for x in m]          # rev 2b: DP = one line per engine
    rec["kv_tokens"] = min(rec["kv_tokens_all"]) if m else None''')

# ---- V2: static check = vLLM's own matching (exact name or re.match), every dense MTP linear exempted (agent 3 F12, agent 4 F3)
rep('''            return any(re.match(x[3:], name) if x.startswith("re:") else (name == x or name.startswith(x + ".")) for x in ign)''',
    '''            # rev 2b: vLLM 0.32.0 matches the fused name by exact name or re.match (config_utils.py:344-362, 392-412)
            return any(re.match(x[3:], name) if x.startswith("re:") else name == x for x in ign)''')
rep('''        mods = sorted({k.rsplit(".", 1)[0] for k in mtp if k.endswith(".weight") and ("proj" in k or k.startswith("mtp.fc"))})''',
    '''        mods = sorted({k.rsplit(".", 1)[0] for k in mtp if k.endswith(".weight") and ("proj" in k or k.startswith("mtp.fc"))})
        _fuse = {"q_proj": "qkv_proj", "k_proj": "qkv_proj", "v_proj": "qkv_proj", "gate_proj": "gate_up_proj", "up_proj": "gate_up_proj"}
        mods = sorted(set(mods) | {m.rsplit(".", 1)[0] + "." + _fuse[m.rsplit(".", 1)[1]] for m in mods if m.rsplit(".", 1)[1] in _fuse})''')
rep('''        out["ok"] = bool(mtp) and (bool(packed) or not not_ign)''', '''        out["ok"] = bool(mtp) and not not_ign        # rev 2b: a partly packed MTP with un-ignored dense linears = #58807''')

# ---- V2: aa / judge on token rows
rep('''def vms_aa():
    rows = {"serial_a": vms_greedy(_S[:6]), "serial_b": vms_greedy(_S[:6]),
            "conc_a": vms_greedy(_S, concurrent=True), "conc_b": vms_greedy(_S, concurrent=True)}
    return rows, {"serial": vms_diverge(rows["serial_a"], rows["serial_b"]), "conc": vms_diverge(rows["conc_a"], rows["conc_b"]),
                  "degenerate": vms_degenerate(rows["serial_a"] + rows["serial_b"] + rows["conc_a"] + rows["conc_b"])}


def vms_judge(s, c, base, gate=True):
    """The rev 1 rule against `base` (the oracle once it exists): text differences may exceed base's own A/A by 1 serial /
    2 all at once; rev 2: and no more degenerate outputs than base's A/A."""
    ds, dc = vms_diverge(base["serial_a"], s), vms_diverge(base["conc_a"], c)
    aas = vms_diverge(base["serial_a"], base["serial_b"])["differ"]
    aac = vms_diverge(base["conc_a"], base["conc_b"])["differ"]
    dg = vms_degenerate(list(s) + list(c))
    dg_aa = vms_degenerate(base["serial_a"] + base["conc_a"])
    passed = ds["differ"] <= aas + 1 and dc["differ"] <= aac + 2 and dg <= dg_aa
    return ("PASS" if passed else "FAIL") if gate else "diagnostic", {"serial": ds, "conc": dc, "aa_serial": aas, "aa_conc": aac,
                                                                       "degenerate": dg, "aa_degenerate": dg_aa}''', '''def _texts(rows):
    return [r.get("text") or "" for r in rows]


def vms_save_rows(tag, rows):
    """rev 2b (agent 3 F10): every greedy row kept, so any verdict can be re-judged after the run."""
    try:
        with open(VMS_DIR / "vms_greedy_rows.jsonl", "a", encoding="utf-8") as fh:
            fh.write(json.dumps({"tag": tag, "rows": rows}) + "\\n")
    except Exception:
        pass


def vms_aa(name, deadline=None):
    rows = {"serial_a": vms_greedy(_S[:6], deadline=deadline), "serial_b": vms_greedy(_S[:6], deadline=deadline),
            "conc_a": vms_greedy(_S, concurrent=True, deadline=deadline), "conc_b": vms_greedy(_S, concurrent=True, deadline=deadline)}
    vms_save_rows(name + "_aa", rows)
    s, c = vms_diverge(rows["serial_a"], rows["serial_b"]), vms_diverge(rows["conc_a"], rows["conc_b"])
    complete = all(x["expected"] and x["compared"] == x["expected"] and not x["missing_margins"] for x in (s, c))
    return rows, {"serial": s, "conc": c, "complete": complete,
                  "degenerate": vms_degenerate(_texts(rows["serial_a"] + rows["serial_b"] + rows["conc_a"] + rows["conc_b"]))}


def vms_judge(s, c, base, gate=True):
    """rev 2b: the EMS parity rule on token rows against `base` (the oracle once it exists): large-margin flips may not
    exceed base's own A/A flips (serial and all at once), no more degenerate outputs than base's A/A; INCOMPLETE when any
    compared row errored or a divergence has no margins (fail closed). Different speculative paths / TP sizes change
    near-ties, which is why whole-text equality (rev 2) is not used."""
    cs, aa_s = vms_diverge(base["serial_a"], s), vms_diverge(base["serial_a"], base["serial_b"])
    cc, aa_c = vms_diverge(base["conc_a"], c), vms_diverge(base["conc_a"], base["conc_b"])
    dg, dg_aa = vms_degenerate(_texts(list(s) + list(c))), vms_degenerate(_texts(base["serial_a"] + base["conc_a"]))
    d = {"serial": cs, "conc": cc, "aa_serial": aa_s, "aa_conc": aa_c, "degenerate": dg, "aa_degenerate": dg_aa}
    if not gate:
        return "diagnostic", d
    if any(x["errors"] or x["missing_margins"] or not x["compared"] for x in (cs, aa_s, cc, aa_c)):
        return "INCOMPLETE", d
    passed = cs["large_margin_flips"] <= aa_s["large_margin_flips"] and cc["large_margin_flips"] <= aa_c["large_margin_flips"] \\
        and dg <= dg_aa
    return ("PASS" if passed else "FAIL"), d''')

# ---- V2: the arm: one deadline, rows saved, oracle needs a complete A/A
rep('''    if ok:
        t_end = time.perf_counter() + cap
        try:
            if gate in ("ref", "oracle"):
                rows, aa = vms_aa()
                VMS_ROWS[name] = rows
                a["aa"] = aa
                if gate == "ref":
                    VMS_REF.update(rows)
                    a["gate"] = "reference"
                elif aa["degenerate"] == 0 and all(x for v in rows.values() for x in v):''', '''    if ok:
        # rev 2b (agent 3 F1): one deadline for the whole arm: its cap, and never into the 2 x TP2 reserve
        t_end = min(time.perf_counter() + cap, HARD_STOP - VMS_RESERVE - 120)
        a["deadline_in_sec"] = round(t_end - time.perf_counter())
        try:
            if gate in ("ref", "oracle"):
                rows, aa = vms_aa(name, deadline=t_end)
                VMS_ROWS[name] = rows
                a["aa"] = aa
                if gate == "ref":
                    VMS_REF.update(rows)
                    a["gate"] = "reference" if aa["complete"] else "reference (A/A incomplete: every later gate INCOMPLETE)"
                elif aa["degenerate"] == 0 and aa["complete"]:''')
rep('''                else:
                    a["gate"] = "oracle unusable (empty or degenerate A/A)"
            elif VMS_REF:
                s, c = vms_greedy(_S[:6]), vms_greedy(_S, concurrent=True)
                a["gate"], a["gate_detail"] = vms_judge(s, c, VMS_REF, gate=bool(gate))
            if True:          # rev 2: a FAIL is recorded and never adopted, but the speed is still measured
                lv = level if not rec.get("max_concurrency_at_max_len") else level
                a["short"] = vms_window(_S, lv, _ts(75), name + "_short")
                if time.perf_counter() < t_end:
                    a["long"] = vms_window(_L, lv, _ts(75), name + "_long")
            a["ok"] = True''', '''                else:
                    a["gate"] = "oracle unusable (incomplete or degenerate A/A)"
            elif VMS_REF:
                s, c = vms_greedy(_S[:6], deadline=t_end), vms_greedy(_S, concurrent=True, deadline=t_end)
                vms_save_rows(name + "_gate", {"serial": s, "conc": c})
                a["gate"], a["gate_detail"] = vms_judge(s, c, VMS_REF, gate=bool(gate))
            # rev 2: a FAIL is recorded and never adopted, but the speed is still measured
            a["short"] = vms_window(_S, level, _ts(75), name + "_short", deadline=t_end)
            if time.perf_counter() < t_end and not _vms_dead():
                a["long"] = vms_window(_L, level, _ts(75), name + "_long", deadline=t_end)
            a["ok"] = all((a.get(b) or {}).get("tok_s") for b in ("short", "long"))      # rev 2b: both bands measured
            a["server_alive_after"] = not _vms_dead()''')

# ---- V2: the plan: lb_marlin dropped, 2 x TP2 with one API server and custom all-reduce allowed, INT4 TP2 skip recorded
rep('''        ("fp8_mtp3_lb_marlin", vms_flags(MODEL_PATH, extra={"--linear-backend": "marlin"}), {}),
        ("fp8_mtp3_lb_triton", vms_flags(MODEL_PATH, extra={"--linear-backend": "triton"}), {}),
    ]''', '''        # rev 2b (agent 4 F1, checked in kernels/linear/__init__.py:478-489 + cutlass_scaled_mm_entry.cu:161-174): on SM 8.9
        # the automatic FP8 block-128 choice is already MarlinFP8ScaledMM (weight-only W8A16): CUTLASS block FP8 needs
        # SM 90+, DeepGEMM / B12x too. So "marlin" = the reference; "triton" = the only real W8A8 FP8 GEMM on the L4.
        ("fp8_mtp3_lb_triton", vms_flags(MODEL_PATH, extra={"--linear-backend": "triton"}), {}),
    ]''')
rep('''    VMS["dropped"] = {"fp8_mtp3_marlin (VLLM_TEST_FORCE_FP8_MARLIN=1)": "the env var is not in vLLM 0.32.0 envs.py "
                      "(removed by PR #52182): the arm would have run the reference unchanged; replaced by --linear-backend"}''',
    '''    VMS["dropped"] = {"fp8_mtp3_marlin (VLLM_TEST_FORCE_FP8_MARLIN=1)": "the env var is not in vLLM 0.32.0 envs.py "
                      "(removed by PR #52182): the arm would have run the reference unchanged; replaced by --linear-backend",
                      "fp8_mtp3_lb_marlin (--linear-backend marlin)": "on SM 8.9 the automatic FP8 block-128 kernel is "
                      "already MarlinFP8ScaledMM (kernels/linear/__init__.py:478-489; CUTLASS block FP8 needs SM 90+, "
                      "cutlass_scaled_mm_entry.cu:161-174): the arm = the reference"}''')
rep('''    vms_arm("tp2x2_fp8_mtp3", vms_flags(MODEL_PATH, tp=2, dp=2, seqs=8), level=16, gate=True, cap=16 * 60)
    if _INT4_OK:
        vms_arm("tp2x2_int4_mtp3", vms_flags(VMS_INT4, tp=2, dp=2, seqs=8), level=16, gate=False, cap=16 * 60)''',
    '''    # rev 2b (agent 4 F4b/d, cli/serve.py:107-130, custom_all_reduce.py:270-291): one API server (DP defaults to one per
    # rank, each balancing on its own counts); custom all-reduce allowed (TP4 on 4 PCIe GPUs turns it off by itself, a
    # TP2 group uses it when the P2P test passes, so the flag would remove the 2 x TP2 lever)
    _TP2X = {"--api-server-count": 1}
    vms_arm("tp2x2_fp8_mtp3", vms_flags(MODEL_PATH, tp=2, dp=2, seqs=8, car_off=False, extra=_TP2X), level=16, gate=True, cap=16 * 60)
    if _INT4_OK:
        vms_arm("tp2x2_int4_mtp3", vms_flags(VMS_INT4, tp=2, dp=2, seqs=8, car_off=False, extra=_TP2X), level=16, gate=False,
                cap=16 * 60)
    else:
        VMS["arms"]["tp2x2_int4_mtp3"] = {"ok": False, "skipped": "INT4 MTP static check failed: " + VMS["int4_mtp_static"].get("why", "")}
        VMS["order"].append("tp2x2_int4_mtp3")''')

# ---- V1: vms_flags car_off
rep('''def vms_flags(model, *, tp=4, dp=1, seqs=16, spec=3, kv="fp8_e4m3", backend="FLASHINFER", prefix=True, mem=0.90,
              batched=4096, max_len=106496, extra=None):
    f = [str(model), "--tensor-parallel-size", str(tp), "--kv-cache-dtype", kv, "--max-model-len", str(max_len),
         "--max-num-seqs", str(seqs), "--max-num-batched-tokens", str(batched), "--gpu-memory-utilization", str(mem),
         "--disable-custom-all-reduce", "--seed", str(SEED), "--host", "127.0.0.1", "--port", str(VMS_PORT),
         "--served-model-name", "q27", "--attention-backend", backend, "--trust-remote-code"]''', '''def vms_flags(model, *, tp=4, dp=1, seqs=16, spec=3, kv="fp8_e4m3", backend="FLASHINFER", prefix=True, mem=0.90,
              batched=4096, max_len=106496, extra=None, car_off=True):
    f = [str(model), "--tensor-parallel-size", str(tp), "--kv-cache-dtype", kv, "--max-model-len", str(max_len),
         "--max-num-seqs", str(seqs), "--max-num-batched-tokens", str(batched), "--gpu-memory-utilization", str(mem)]
    f += ["--disable-custom-all-reduce"] if car_off else []
    f += ["--seed", str(SEED), "--host", "127.0.0.1", "--port", str(VMS_PORT),
          "--served-model-name", "q27", "--attention-backend", backend, "--trust-remote-code"]''')

# ---- V2: report: why an arm failed (agent 3 F14), the no-prefix long-band caveat (agent 4 F5)
rep('''                 f"{a.get('log_errors') or a.get('skipped') or ''} |")''', '''                 f"{a.get('log_errors') or a.get('skipped') or a.get('error') or (a.get('short') or {}).get('error') or (a.get('long') or {}).get('error') or ''} |")''')
rep('''         f"dropped arms: {json.dumps(VMS.get('dropped') or {})}", "",''', '''         f"dropped arms: {json.dumps(VMS.get('dropped') or {})}",
         "note: the 40k band shares a ~36k system block; prefix-cache arms reuse it, the oracle and fp8_mtp3_noprefix "
         "prefill it again per request, so their 40k tok/s includes that recompute", "",''')
p.write_text(t, encoding="utf-8", newline="\n")
print("patched")
