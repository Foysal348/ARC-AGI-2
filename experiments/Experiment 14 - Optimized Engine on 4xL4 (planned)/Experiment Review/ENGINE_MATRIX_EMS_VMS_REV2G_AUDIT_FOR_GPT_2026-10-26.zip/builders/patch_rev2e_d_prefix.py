"""rev 2e-d EMS (GPT audit E9 for SGLang; additive measurement, no rule change). SGLang 0.5.21 prints every prefill as
'Prefill batch, #new-seq: N, #new-token: X, #cached-token: Y, ...' (verified in the E14A SLIM R2 run1 server log).
steady_window now sums the stream prefills' new / cached tokens (after the warm request) so each EMS band records its
real radix-cache hit rate; the arm record and the report carry it."""
from pathlib import Path

ROOT = Path(r"D:/ARC AGI 2/experiments/Experiment 14 - Optimized Engine on 4xL4 (planned)")


def patch(p, pairs):
    t = p.read_text(encoding="utf-8")
    for a, b in pairs:
        assert t.count(a) == 1, (p.name, t.count(a), a[:90])
        t = t.replace(a, b)
    p.write_text(t, encoding="utf-8", newline="\n")
    print("patched", p.name)


patch(ROOT / "src" / "e14_measure.py", [
    ('''def _q(v, f):''', '''_PF_RE = re.compile(r"#new-token:\\s*(\\d+),\\s*#cached-token:\\s*(\\d+)")


def prefill_tokens(text, start=0, end=None):
    """TP0 'Prefill batch' lines in text[start:end]: prompt tokens computed vs served from the radix cache."""
    n = new = cached = 0
    for line in text[start:end].splitlines():
        if "TP0]" in line and "Prefill batch" in line:
            m = _PF_RE.search(line)
            if m:
                n, new, cached = n + 1, new + int(m.group(1)), cached + int(m.group(2))
    return {"prefill_lines": n, "prefill_new_tokens": new, "prefill_cached_tokens": cached,
            "prefix_hit_rate": round(cached / (new + cached), 3) if new + cached else None}


def _q(v, f):'''),
    ('''    else:
        w = None
    gens = [Gen(ctx, f"e14-{tag}-{i}-{random.randrange(10 ** 9)}", prompts[i % len(prompts)], max_new)''',
     '''    else:
        w = None
    off_pf = len(ctx.log_text())      # the streams' own prefills start here (after the warm request)
    gens = [Gen(ctx, f"e14-{tag}-{i}-{random.randrange(10 ** 9)}", prompts[i % len(prompts)], max_new)'''),
    ('''    out.update(window_stats(lines, level, spec=spec))''',
     '''    out.update(window_stats(lines, level, spec=spec))
    out.update(prefill_tokens(ctx.log_text(), off_pf))       # radix-cache hits of this band's prefills'''),
])

patch(ROOT / "Experiment Notebooks" / "Build" / "build_ems.py", [
    ('''             "gate_class": ((r or {}).get("gate") or {}).get("gate_class"),''',
     '''             "gate_class": ((r or {}).get("gate") or {}).get("gate_class"),
             "prefix_hit_short": _w(r, "short", "prefix_hit_rate"), "prefix_hit_long": _w(r, "long", "prefix_hit_rate"),'''),
    ('''adoptable / gate class | XL gate | canary leaks |",''', '''adoptable / gate class | XL gate | canary leaks | prefix-cache hit 8k / 40k |",'''),
    ('''         "|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|"]''',
     '''         "|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|"]'''),
    ('''{a.get('canary_leaks') if a.get('canary_leaks') is not None else ''} |")''',
     '''{a.get('canary_leaks') if a.get('canary_leaks') is not None else ''} | "
                 f"{f(a.get('prefix_hit_short'), 2)} / {f(a.get('prefix_hit_long'), 2)} |")'''),
])
