"""EMS rev 2e: the independent GPT audit of rev 2c (2026-10-26), every claim checked in the code before the change.
HIGH-2 post-divergence tail check, HIGH-3 fail closed without the target-only oracle, HIGH-4 skip the #45151 arm unless
the patch applied, E8 explicit adoptable column, E12 the FP8 cold launch after the 20 / 24-stream arms."""
from pathlib import Path

p = Path(r"D:/ARC AGI 2/experiments/Experiment 14 - Optimized Engine on 4xL4 (planned)/Experiment Notebooks/Build/build_ems.py")
t = p.read_text(encoding="utf-8")


def rep(a, b, n=1):
    global t
    assert t.count(a) == n, (t.count(a), a[:100])
    t = t.replace(a, b)


rep('''usage: python build_ems.py   -> ../Q27-XHIGH-EMS_ENGINE_MATRIX_SGLANG.ipynb"""''', '''rev 2e (independent GPT audit of rev 2c, 2026-10-26): adoptable only against the target-only oracle (fail closed);
a post-divergence tail check (a near-tie first divergence followed by degenerate / repeated output fails the gate);
the #45151 arm skipped unless the patch really applied; an explicit adoptable column; ntn_fp8 (a cold FP8 load from
/kaggle/input) moved after the 20 / 24-stream arms.
usage: python build_ems.py   -> ../Q27-XHIGH-EMS_ENGINE_MATRIX_SGLANG.ipynb"""''')

# ---- HIGH-2: tail check on the rows after the first divergence
rep('''        def _gate_from_rows(cand, base, name):
            """arm_gate's rule on rows that already exist (no GPU time): cand's serial / all-at-once passes vs base's,
            judged against base's own A/A; flips decide."""''', '''        def _tail_bad(ids):
            """rev 2e (GPT audit HIGH-2): a continuation that degenerated: 16+ identical tokens in a row, or more than
            50 % of its 8-grams repeated (normal reasoning stays far below)."""
            ids = list(ids or [])
            run = best = 0
            for i_ in range(1, len(ids)):
                run = run + 1 if ids[i_] == ids[i_ - 1] else 0
                best = max(best, run)
            grams = [tuple(ids[i_:i_ + 8]) for i_ in range(max(0, len(ids) - 7))]
            rep_ = 1 - len(set(grams)) / len(grams) if len(grams) >= 32 else 0.0
            return best >= 15 or rep_ > 0.5

        def _tail_count(rows):
            return sum(1 for r_ in rows or [] if _tail_bad(r_.get("ids")))

        def _gate_from_rows(cand, base, name):
            """arm_gate's rule on rows that already exist (no GPU time): cand's serial / all-at-once passes vs base's,
            judged against base's own A/A; flips decide. rev 2e: and no more degenerate continuations than base's A/A
            (a near-tie first divergence must not hide corruption after it)."""''')
rep('''            if _dirty_rows(base.get("serial_a"), base.get("serial_b"), base.get("conc_a"), base.get("conc_b")):
                ok, v = False, "INCOMPLETE"       # rev 2b: an A/A taken on a busy server is no reference
            return {"ok": ok, "verdict": v, "serial": ps, "all_at_once": pc}''', '''            if _dirty_rows(base.get("serial_a"), base.get("serial_b"), base.get("conc_a"), base.get("conc_b")):
                ok, v = False, "INCOMPLETE"       # rev 2b: an A/A taken on a busy server is no reference
            tail_c = _tail_count(cand.get("serial_a")) + _tail_count(cand.get("conc_a"))
            tail_b = max(_tail_count(base.get("serial_a")) + _tail_count(base.get("conc_a")),
                         _tail_count(base.get("serial_b")) + _tail_count(base.get("conc_b")))
            if v == "PASS" and tail_c > tail_b:
                ok, v = False, "FAIL"             # rev 2e: degenerate continuations beyond the oracle's own
            return {"ok": ok, "verdict": v, "serial": ps, "all_at_once": pc, "tail_degenerate": tail_c, "tail_degenerate_aa": tail_b}''')

# ---- HIGH-3: fail closed without the independent target-only oracle
rep('''            if (a.get("lines_short") or 0) < (8 if _ts(75) >= 60 else 1) or not a.get("short_tok_s") or not a.get("long_tok_s"):
                return False
            if EMSR.get("oracle") == "target_only":''', '''            if (a.get("lines_short") or 0) < (8 if _ts(75) >= 60 else 1) or not a.get("short_tok_s") or not a.get("long_tok_s"):
                return False
            # rev 2e (GPT audit HIGH-3): no independent target-only oracle = nothing is adoptable (diagnostics still run)
            if not (EMSR.get("oracle") == "target_only" and EMS_TGT is not None and _cmp_complete(EMSR.get("probe_tgt_aa"))):
                return False
            if EMSR.get("oracle") == "target_only":''')

# ---- HIGH-4: the #45151 arm only when the patch applied (the harness has no SGLang: the arm still runs there)
rep('''            if _name.endswith("_pcie") and not (EMSR["fi07_overlay"].get("ok") or E11_HARNESS):''', '''            if _name.endswith("_pr45151") and not (EMSR["pr45151_patch"].get("applied") or E11_HARNESS):
                _why = "PR #45151 patch not applied: " + str(EMSR["pr45151_patch"].get("why"))[:300]     # rev 2e (HIGH-4)
            if _name.endswith("_pcie") and not (EMSR["fi07_overlay"].get("ok") or E11_HARNESS):''')
rep('''            out.update(applied=True, file=fp)''', '''            out.update(applied=True, file=fp, sha256=hashlib.sha256(src.encode("utf-8")).hexdigest())     # rev 2e: proof''')

# ---- E12: ntn_fp8 (cold FP8 load) after the 20 / 24-stream arms
rep('''            ("ntn_fp8", dict(set_=dict(_NTN, **_mtp(path=MODEL_PATH), **{"--model-path": str(MODEL_PATH)}), drop=_ntn_drop,
                             gate=False, probe=False, timeout=30 * 60)),
            ("ntn_int4", dict(set_=dict(_NTN, **_mtp()), drop=_ntn_drop)),
            ("dflash_w6_s20", dict(streams=20)),
            ("dflash_w6_s24", dict(streams=24)),''', '''            ("ntn_int4", dict(set_=dict(_NTN, **_mtp()), drop=_ntn_drop)),
            ("dflash_w6_s20", dict(streams=20)),
            ("dflash_w6_s24", dict(streams=24)),
            # rev 2e (GPT audit E12): the cold FP8 load from /kaggle/input after the admission-critical 20 / 24 arms
            ("ntn_fp8", dict(set_=dict(_NTN, **_mtp(path=MODEL_PATH), **{"--model-path": str(MODEL_PATH)}), drop=_ntn_drop,
                             gate=False, probe=False, timeout=30 * 60)),''')

# ---- E8: the adoptable column (computed at report time from the same rule the picks use)
rep('''PCIe-IPC workspace built |",''', '''PCIe-IPC workspace built | adoptable |",''')
rep('''         "|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|"]''',
    '''         "|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|"]''')
rep('''                 f"{(a.get('pcie_ipc') or {}).get('workspace_built', '')} |")''', '''                 f"{(a.get('pcie_ipc') or {}).get('workspace_built', '')} | {a.get('adoptable')} |")''')
rep('''        E14_STATE.enter("EMS_DONE")
        e14_save()
    else:''', '''        for _k, _a in EMSR["arms"].items():      # rev 2e (GPT audit E8): speed, correctness and adoption kept apart
            _a["adoptable"] = bool(_gated(_a)) and _a.get("family") in ("mtp", "dflash")
        E14_STATE.enter("EMS_DONE")
        e14_save()
    else:''')
p.write_text(t, encoding="utf-8", newline="\n")
print("patched")
