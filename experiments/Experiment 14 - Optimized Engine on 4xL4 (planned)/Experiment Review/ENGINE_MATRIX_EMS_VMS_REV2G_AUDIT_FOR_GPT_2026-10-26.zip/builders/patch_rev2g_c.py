"""rev 2g-c (agent 3 disposition truth check; every item verified in the code first).
EMS:
- A1 (real E14A data: 1 of 12 streams ended early, share 0.881 at only 505 tok/s): window streams (max_new >= 16384)
  ignore EOS through a notebook-local Gen subclass (the E14 module itself is the shared payload, not touched), so the
  fastest arms are not rejected by the >= 0.80 running share; greedy / probe / canary rows keep EOS.
- A4: the 1,024-token probe runs before the optional XL window (a slow XL can no longer cost the probe).
- B5: the gate's tail check judges the continuation AFTER the first divergence from the matching oracle row.
- B6 / A3: the oracle A/A must have no degenerate row; its XL A/A counts only when complete (EMSR['oracle_xl']).
- checklist 9: pip freeze of the SGLang venv and a sha per prompt saved; NOT_TESTED_BUDGET label on the TP2 skip.
VMS:
- A5: 'Preempt' no longer scanned over the whole server log (one preemption in the diagnostic XL window blocked
  adoption); the short / long windows require 0 preemptions (per-window metric delta) instead.
- B2: finished_empty (a stream that ended with [DONE] and zero tokens) recorded.
- checklist 9: pip freeze of the vLLM venv, a sha per prompt; the stale vms_judge docstring."""
from pathlib import Path

B = Path(r"D:/ARC AGI 2/experiments/Experiment 14 - Optimized Engine on 4xL4 (planned)/Experiment Notebooks/Build")


def patch(fn, pairs):
    p = B / fn
    t = p.read_text(encoding="utf-8")
    for a, b in pairs:
        assert t.count(a) == 1, (fn, t.count(a), a[:90])
        t = t.replace(a, b)
    p.write_text(t, encoding="utf-8", newline="\n")
    print("patched", fn)


patch("build_ems.py", [
    ('''EMSR["part"] = EMS_PART''', '''EMSR["part"] = EMS_PART


class _E14GenWindow(E14M.Gen):
    """rev 2g-c (agent 3 A1): window streams (max_new >= 16384) ignore EOS, so a stream that ends early never lowers the
    running share (a false reject of the fastest arms); greedy / probe / canary rows (<= 1,024 tokens) keep EOS."""
    def __init__(self, *a, **k):
        super().__init__(*a, **k)
        if self.max_new >= 16384:
            self.sp["ignore_eos"] = True


if not getattr(E14M.Gen, "_ems_window", False):
    _E14GenWindow._ems_window = True
    E14M.Gen = _E14GenWindow'''),
    # probe before the XL window
    ('''                if xl_level and _X and not _dead():       # rev 2d: the XL band (flush first: the 40k block is not reused)
                    out["flush_before_xl"] = E14M.flush_cache(ctx)
                    out["xl"] = E14M.steady_window(ctx, _X, level=xl_level, secs=_ts(75), tag=tag + "xl", max_new=16384)
                if probe and not _dead():
                    out["flush_before_probe"] = E14M.flush_cache(ctx)
                    _rows = _probe(tag, ctx=ctx)
                    out["probe_dirty"] = _dirty_rows(_rows)
                    if out["probe_dirty"]:
                        out["server_not_idle"] = True
                    out["probe"] = _probe_vs_ref(_rows, f"{tag} probe vs reference")
                    out["probe_vs_target"] = _probe_vs_tgt(_rows, f"{tag} probe vs target-only")''',
     '''                if probe and not _dead():         # rev 2g-c (agent 3 A4): the mandatory probe before the XL window
                    out["flush_before_probe"] = E14M.flush_cache(ctx)
                    _rows = _probe(tag, ctx=ctx)
                    out["probe_dirty"] = _dirty_rows(_rows)
                    if out["probe_dirty"]:
                        out["server_not_idle"] = True
                    out["probe"] = _probe_vs_ref(_rows, f"{tag} probe vs reference")
                    out["probe_vs_target"] = _probe_vs_tgt(_rows, f"{tag} probe vs target-only")
                if xl_level and _X and not _dead():       # rev 2d: the XL band (flush first: the 40k block is not reused)
                    out["flush_before_xl"] = E14M.flush_cache(ctx)
                    out["xl"] = E14M.steady_window(ctx, _X, level=xl_level, secs=_ts(75), tag=tag + "xl", max_new=16384)'''),
    # post-divergence tails
    ('''        def _tail_count(rows):
            return sum(1 for r_ in rows or [] if _tail_bad(r_.get("ids")))''', '''        def _tail_count(rows):
            return sum(1 for r_ in rows or [] if _tail_bad(r_.get("ids")))

        def _post_div_tails(rows_c, rows_b):
            """rev 2g-c (agent 3 B5): degenerate continuations AFTER the first divergence from the matching base row
            (a whole-row check let a clean head mask a degenerate tail)."""
            n_ = 0
            for rc, rb in zip(rows_c or [], rows_b or []):
                ic, ib = list(rc.get("ids") or []), list(rb.get("ids") or [])
                k = next((j for j, (u, v) in enumerate(zip(ic, ib)) if u != v), None)
                if k is not None and _tail_bad(ic[k:]):
                    n_ += 1
            return n_'''),
    ('''            tail_c = _tail_count(cand.get("serial_a")) + _tail_count(cand.get("conc_a"))
            tail_b = max(_tail_count(base.get("serial_a")) + _tail_count(base.get("conc_a")),
                         _tail_count(base.get("serial_b")) + _tail_count(base.get("conc_b")))''',
     '''            tail_c = _post_div_tails(cand.get("serial_a"), base.get("serial_a")) + _post_div_tails(cand.get("conc_a"), base.get("conc_a"))
            tail_b = _post_div_tails(base.get("serial_b"), base.get("serial_a")) + _post_div_tails(base.get("conc_b"), base.get("conc_a"))'''),
    # oracle hygiene
    ('''                ref, summ = _aa_rows("ems_tgt")
                if summ["complete"]:      # rev 2b: no errors, no missing margins, not dirty
                    globals()["EMS_TGT"] = ref
                if _X:                    # rev 2e: the oracle's own XL A/A
                    xa, xb = _xl_rows(E14_CTX, "ems_tgt_a"), _xl_rows(E14_CTX, "ems_tgt_b")
                    if xa and xb and not _dirty_rows(xa, xb):
                        globals()["EMS_TGT_XL"] = (xa, xb)
                    summ["xl_aa"] = E14M.compare_passes(xa or [], xb or [], "target-only XL A/A", n=256)''',
     '''                ref, summ = _aa_rows("ems_tgt")
                # rev 2g-c (agent 3 B6): the oracle's own rows must not be degenerate
                summ["degenerate_rows"] = sum(1 for k_ in ("serial_a", "serial_b", "conc_a", "conc_b") for r_ in (ref.get(k_) or [])
                                              if _text_bad(tokenizer.decode(r_.get("ids") or [], skip_special_tokens=True)))
                if summ["complete"] and not summ["degenerate_rows"]:      # rev 2b: no errors, no missing margins, not dirty
                    globals()["EMS_TGT"] = ref
                if _X:                    # rev 2e: the oracle's own XL A/A (rev 2g-c: only a complete one counts)
                    xa, xb = _xl_rows(E14_CTX, "ems_tgt_a"), _xl_rows(E14_CTX, "ems_tgt_b")
                    summ["xl_aa"] = E14M.compare_passes(xa or [], xb or [], "target-only XL A/A", n=256)
                    if xa and xb and not _dirty_rows(xa, xb) and _cmp_complete(summ["xl_aa"]):
                        globals()["EMS_TGT_XL"] = (xa, xb)
                    EMSR["oracle_xl"] = "complete" if globals().get("EMS_TGT_XL") else "NO_ORACLE_XL (nothing adoptable)"'''),
    ('''                rec["skipped"] = "less than ~17 min before the hard stop"''',
     '''                rec["skipped"] = "NOT_TESTED_BUDGET: less than ~17 min before the hard stop"'''),
    # provenance
    ('''        EMSR["pr45151_patch"] = ems_patch_pr45151() if''', '''        try:          # rev 2g-c (checklist 9): the exact packages and prompts of this run
            EMSR["pip_freeze"] = subprocess.run([E14_VENV["launch"][0], "-m", "pip", "freeze"], capture_output=True, text=True,
                                                timeout=180, env=E14_VENV["env"]).stdout[-20000:]
        except Exception as _e:
            EMSR["pip_freeze"] = repr(_e)[:200]
        EMSR["prompt_sha"] = {k_: [__import__("hashlib").sha256(json.dumps(list(x_)).encode()).hexdigest()[:16] for x_ in v_]
                              for k_, v_ in (globals().get("EMS_PROMPTS") or {}).items() if k_ in ("short", "long", "xl")}
        EMSR["pr45151_patch"] = ems_patch_pr45151() if'''),
])

patch("build_vms.py", [
    ('''        a["log_errors"] = {k: sig.count(k) for k in ("Traceback", "out of memory", "OutOfMemory", "Preempt") if k in sig}''',
     '''        # rev 2g-c (agent 3 A5): no whole-log 'Preempt' scan (the stats line carries it; one preemption in the diagnostic
        # XL window blocked adoption); the short / long windows require 0 preemptions instead (vms_window_healthy)
        a["log_errors"] = {k: sig.count(k) for k in ("Traceback", "out of memory", "OutOfMemory") if k in sig}
        a["preempt_log_lines"] = sig.count("Preempt")'''),
    ('''        and w.get("no_first_token", level) == 0 and w.get("threads_not_joined", 1) == 0 and w.get("idle_after") is True''',
     '''        and w.get("no_first_token", level) == 0 and w.get("threads_not_joined", 1) == 0 and w.get("idle_after") is True \\
        and (w.get("preemptions") or 0) == 0 and w.get("finished_empty", 0) == 0'''),
    ('''        out.update(no_first_token=len(gens) - len(started), empty_outputs=sum(1 for x in texts if not x.strip()),''',
     '''        out.update(finished_empty=sum(1 for g in gens if g.done_seen and not g.tokens),      # rev 2g-c (agent 3 B2)
                   no_first_token=len(gens) - len(started), empty_outputs=sum(1 for x in texts if not x.strip()),'''),
    ('''    BOUNDARY = a PASS with near-tie divergences (a candidate for task-level evaluation, never auto-certified)."""''',
     '''    BOUNDARY = a PASS with only near-tie divergences (adoptable under the documented tolerance, not exact: confirm on ARC
    tasks; certified_exact = adoptable and PASS_EXACT)."""'''),
    ('''    _INT4_OK = vms_int4_mtp_static(VMS_INT4)''', '''    _INT4_OK = vms_int4_mtp_static(VMS_INT4)
    try:          # rev 2g-c (checklist 9): the exact packages and prompts of this run
        VMS["pip_freeze"] = subprocess.run([(VMS.get("install") or {}).get("launch", [sys.executable])[0], "-m", "pip", "freeze"],
                                           capture_output=True, text=True, timeout=180).stdout[-20000:]
    except Exception as _e:
        VMS["pip_freeze"] = repr(_e)[:200]
    VMS["prompt_sha"] = {k_: [__import__("hashlib").sha256(json.dumps(list(x_)).encode()).hexdigest()[:16] for x_ in v_]
                         for k_, v_ in (("short", _S), ("long", _L), ("xl", _X or []))}'''),
])
