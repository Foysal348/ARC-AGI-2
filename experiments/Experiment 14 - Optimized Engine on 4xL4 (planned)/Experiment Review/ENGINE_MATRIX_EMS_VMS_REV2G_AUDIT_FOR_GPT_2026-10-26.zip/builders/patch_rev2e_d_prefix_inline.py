"""rev 2e-d EMS, take 2: the E14 modules come from the Kaggle payload dataset (shared with E15P), so the prefix-hit count
is done in the EMS cell itself, not in e14_measure (reverted). For each band: the server-log offset before
steady_window, then the TP0 'Prefill batch, #new-token: X, #cached-token: Y' lines after it (SGLang 0.5.21 format,
verified in the E14A SLIM R2 log). The count includes the band's warm request (one cold prefill of the shared block),
so it slightly understates the streams' own hit rate; a silent no-op still shows as ~0."""
from pathlib import Path

p = Path(r"D:/ARC AGI 2/experiments/Experiment 14 - Optimized Engine on 4xL4 (planned)/Experiment Notebooks/Build/build_ems.py")
t = p.read_text(encoding="utf-8")


def rep(a, b):
    global t
    assert t.count(a) == 1, (t.count(a), a[:90])
    t = t.replace(a, b)


rep('''        def _xl_rows(ctx, tag):''', '''        def _prefill_hits(text, start):
            """rev 2e-d (GPT audit E9): radix-cache hits of the prefills logged after `start` (incl. the warm request)."""
            n_, new_, cached_ = 0, 0, 0
            for line in text[start:].splitlines():
                if "TP0]" in line and "Prefill batch" in line:
                    m_ = re.search(r"#new-token:\\s*(\\d+),\\s*#cached-token:\\s*(\\d+)", line)
                    if m_:
                        n_, new_, cached_ = n_ + 1, new_ + int(m_.group(1)), cached_ + int(m_.group(2))
            return {"prefill_lines": n_, "prefill_new_tokens": new_, "prefill_cached_tokens": cached_,
                    "prefix_hit_rate": round(cached_ / (new_ + cached_), 3) if new_ + cached_ else None}

        def _xl_rows(ctx, tag):''')
rep('''                    out[band] = E14M.steady_window(ctx, ps, level=level, secs=_ts(75), tag=tag + band)''',
    '''                    _off = len(ctx.log_text())
                    out[band] = E14M.steady_window(ctx, ps, level=level, secs=_ts(75), tag=tag + band)
                    if isinstance(out[band], dict):
                        out[band].update(_prefill_hits(ctx.log_text(), _off))      # rev 2e-d (E9)''')
rep('''adoptable / gate class | XL gate | canary leaks | prefix-cache hit 8k / 40k |",''',
    '''adoptable / gate class | XL gate | canary leaks | prefix-cache hit 8k / 40k (incl. warm) |",''')
p.write_text(t, encoding="utf-8", newline="\n")
print("patched")
