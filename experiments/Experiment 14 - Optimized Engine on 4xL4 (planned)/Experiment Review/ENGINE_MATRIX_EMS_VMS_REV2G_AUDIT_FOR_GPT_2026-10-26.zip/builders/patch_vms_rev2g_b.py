"""VMS rev 2g-b (agent 2, vLLM audit recheck; each claim checked in build_vms.py first):
- a launch counts as ready only when THIS server's log has the 'GPU KV cache size' line (a 200 on /health from an old
  process still on the port would send every measurement to the wrong server);
- greedy requests send no top_k (top_k=-1 acceptance at temperature 0 could not be verified in the 0.32.0 snapshot);
- the reference's warm (prefix-hit) rows are judged against the oracle too; the worse verdict counts (V1-d);
- windows store the per-engine running max (DP routing skew, V5-b);
- `nvidia-smi topo -p2p p` recorded next to `-p2p r` (the audit asked for p);
- stale text: '200 min' -> 260, '--linear-backend marlin / triton' -> triton (the marlin arm was dropped in rev 2b)."""
from pathlib import Path

B = Path(r"D:/ARC AGI 2/experiments/Experiment 14 - Optimized Engine on 4xL4 (planned)/Experiment Notebooks/Build")


def patch(fn, pairs):
    p = B / fn
    t = p.read_text(encoding="utf-8")
    for a, b in pairs:
        assert t.count(a) == 1, (fn, t.count(a), a[:90])
        t = t.replace(a, b)
    p.write_text(t, encoding="utf-8", newline="\n")
    print("patched", fn)


patch("build_vms.py", [
    ('''                     "top_p": 0.95 if temperature else 1.0, "top_k": 20 if temperature else -1, "stream": True,''',
     '''                     "top_p": 0.95 if temperature else 1.0, "stream": True,'''),
    ('''        if seed is not None:
            self.body["seed"] = seed''', '''        if temperature:
            self.body["top_k"] = 20          # rev 2g-b: greedy sends no top_k (temperature 0 = argmax)
        if seed is not None:
            self.body["seed"] = seed'''),
    ('''    rec["kv_tokens"] = min(rec["kv_tokens_all"]) if m else None''', '''    rec["kv_tokens"] = min(rec["kv_tokens_all"]) if m else None
    if ok and not m:      # rev 2g-b: a /health 200 without this server's own KV line = another listener on the port
        ok, why = False, "ready, but no 'GPU KV cache size' line in this server's log (another process on the port?)"'''),
    ('''                        _v, _d = vms_judge(_r["serial_a"], _r["conc_a"], rows)''',
     '''                        _v, _d = vms_judge(_r["serial_a"], _r["conc_a"], rows)
                        # rev 2g-b (agent 2 V1-d): the reference's warm (prefix-hit) A/A rows judged too; the worse counts
                        _v2, _d2 = vms_judge(_r["serial_b"], _r["conc_b"], rows)
                        _rank = {"PASS": 0, "INCOMPLETE": 1, "FAIL": 2}
                        _d["warm_verdict"], _d["warm_gate_class"] = _v2, _d2.get("gate_class")
                        if _rank.get(_v2, 2) > _rank.get(_v, 2):
                            _v, _d = _v2, dict(_d2, cold_verdict=_v, warm_verdict=_v2)
                        elif _v == "PASS" and _d2.get("gate_class") == "BOUNDARY":
                            _d["gate_class"] = "BOUNDARY"'''),
    ('''                runs.append(_met(p, "vllm:num_requests_running"))''',
     '''                runs.append(_met(p, "vllm:num_requests_running"))
                runs_mx.append(p.get("vllm:num_requests_running@max", 0.0))      # rev 2g-b: per engine (DP skew)'''),
    ('''        runs, kvs = [], []''', '''        runs, kvs, runs_mx = [], [], []'''),
    ('''running_mean=round(statistics.mean(runs), 2) if runs else None,''',
     '''running_mean=round(statistics.mean(runs), 2) if runs else None,
               running_engine_max_mean=round(statistics.mean(out.get("_runs_mx") or [0]), 2),'''),
    ('''        out["_runs"], out["_kvs"] = runs, kvs''', '''        out["_runs"], out["_kvs"], out["_runs_mx"] = runs, kvs, runs_mx'''),
    ('''    runs, kvs = out.pop("_runs", []), out.pop("_kvs", [])''', '''    runs, kvs = out.pop("_runs", []), out.pop("_kvs", [])
    out["_runs_mx"] = out.get("_runs_mx") or []'''),
    ('''                           "p2p_read": subprocess.run(["nvidia-smi", "topo", "-p2p", "r"], capture_output=True, text=True, timeout=30).stdout[-2000:]}''',
     '''                           "p2p_read": subprocess.run(["nvidia-smi", "topo", "-p2p", "r"], capture_output=True, text=True, timeout=30).stdout[-2000:],
                           "p2p_prop": subprocess.run(["nvidia-smi", "topo", "-p2p", "p"], capture_output=True, text=True, timeout=30).stdout[-2000:]}'''),
    ('''the 12 G4B tasks only feed real ARC prompts; 200 min''', '''the 12 G4B tasks only feed real ARC prompts; 260 min (rev 2d)'''),
    ('''caching off; --linear-backend marlin / triton;''', '''caching off; --linear-backend triton (Marlin = the auto default on SM 8.9);'''),
])
patch("build_ems.py", [
    ('''                    out["p2p_read"] = subprocess.run(["nvidia-smi", "topo", "-p2p", "r"], capture_output=True, text=True,''',
     '''                    out["p2p_prop"] = subprocess.run(["nvidia-smi", "topo", "-p2p", "p"], capture_output=True, text=True,
                                                     timeout=30).stdout[-2000:]      # rev 2g-b: the audit asked for p
                    out["p2p_read"] = subprocess.run(["nvidia-smi", "topo", "-p2p", "r"], capture_output=True, text=True,'''),
])
