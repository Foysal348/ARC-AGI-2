"""EMS rev 2f (user 2026-10-26: "3 parts", so a crash in one cannot damage the others). build_ems.py now writes TWO
notebooks from the same code:
- Q27-XHIGH-EMS_SAFE_ENGINE_MATRIX_SGLANG.ipynb  : oracle + reference + MTP 3/1/4, DFlash 20 / 24 (+ the best MTP at 20),
  MTP 2/1/3, mem 0.86, DFlash width 4 / 8. No site-packages patch, no FlashInfer overlay, no 2 x TP2 (no reserve).
- Q27-XHIGH-EMS_RISKY_ENGINE_MATRIX_SGLANG.ipynb : oracle + reference + MTP 3/1/4 (the direct A/B partner), #45151,
  DFlash / MTP PCIe-IPC, NTN INT4 / FP8, ReplaySSM fp16 / fp32, then 2 x TP2 from the reserved slot.
The third part is VMS (unchanged layout: its risky INT4 / TP2 arms are already last).
EMS_PART is baked in at build time; the env var EMS_PART=ALL (the CPU harness only) runs every arm in one process.
An arm of the other part is recorded as skipped "OTHER_PART". Every arm call is now inside its own try/except (before,
an exception in _arm's own code would have ended the remaining arms)."""
from pathlib import Path

p = Path(r"D:/ARC AGI 2/experiments/Experiment 14 - Optimized Engine on 4xL4 (planned)/Experiment Notebooks/Build/build_ems.py")
t = p.read_text(encoding="utf-8")


def rep(a, b):
    global t
    assert t.count(a) == 1, (t.count(a), a[:90])
    t = t.replace(a, b)


rep('''usage: python build_ems.py   -> ../Q27-XHIGH-EMS_ENGINE_MATRIX_SGLANG.ipynb"""''',
    '''rev 2f (user 2026-10-26): two notebooks, SAFE and RISKY (a crash in one cannot touch the other); EMS_PART=ALL runs all
(CPU harness); every arm call in its own try/except.
usage: python build_ems.py   -> ../Q27-XHIGH-EMS_SAFE_ENGINE_MATRIX_SGLANG.ipynb + ../Q27-XHIGH-EMS_RISKY_ENGINE_MATRIX_SGLANG.ipynb"""''')

rep('''EMSR = {"arms": {}, "launches": {}, "order": []}
E14_RESULTS["ems"] = EMSR
try:
    if EMS_ON and ENGINE_READY:''', '''EMSR = {"arms": {}, "launches": {}, "order": []}
E14_RESULTS["ems"] = EMSR
# rev 2f: which part of the matrix this notebook runs (baked in at build time; EMS_PART=ALL = every arm, CPU harness)
EMS_PART = os.environ.get("EMS_PART") or "__EMS_PART__"
EMS_PART_ARMS = {"SAFE": ("mtp_3_1_4", "dflash_w6_s20", "dflash_w6_s24", "mtp_2_1_3", "mtp_3_1_4_mem86", "dflash_w4", "dflash_w8"),
                 "RISKY": ("dflash_w6_pcie", "mtp_3_1_4", "mtp_3_1_4_pr45151", "mtp_3_1_4_pcie", "ntn_int4", "ntn_fp8",
                           "mtp_replay_fp16", "mtp_replay_fp32")}
EMS_TP2_ON = EMS_PART in ("ALL", "RISKY")
EMSR["part"] = EMS_PART
try:
    if EMS_ON and ENGINE_READY:''')

# the site-packages patch and the overlay only where their arms run
rep('''        EMSR["pr45151_patch"] = ems_patch_pr45151()''',
    '''        EMSR["pr45151_patch"] = ems_patch_pr45151() if EMS_PART in ("ALL", "RISKY") else {"applied": False, "why": "SAFE part: not needed"}''')
rep('''        EMSR["fi07_overlay"] = ems_fi07_overlay()''',
    '''        EMSR["fi07_overlay"] = ems_fi07_overlay() if EMS_PART in ("ALL", "RISKY") else {"ok": False, "why": "SAFE part: not needed"}''')
rep('''        E14_RESERVE = _ts(30 * 60)''', '''        E14_RESERVE = _ts(30 * 60) if EMS_TP2_ON else 0.0       # rev 2f: the TP2 slot only where TP2 runs''')

rep('''            if _why:
                EMSR["arms"][_name] = {"ok": False, "skipped": _why}
                EMSR["order"].append(_name)
                continue
            _arm(_name, **_kw)''', '''            if EMS_PART != "ALL" and _name not in EMS_PART_ARMS.get(EMS_PART, ()):
                _why = "OTHER_PART: runs in the EMS " + ("SAFE" if EMS_PART == "RISKY" else "RISKY") + " notebook"
            if _why:
                EMSR["arms"][_name] = {"ok": False, "skipped": _why}
                EMSR["order"].append(_name)
                continue
            try:                 # rev 2f: one arm's own crash never ends the remaining arms
                _arm(_name, **_kw)
            except Exception as _e:
                EMSR["arms"][_name] = dict(EMSR["arms"].get(_name) or {}, ok=False,
                                           error=f"arm crashed: {type(_e).__name__}: {_e}"[:500], adoptable=False)
                if _name not in EMSR["order"]:
                    EMSR["order"].append(_name)
                print(f"EMS arm {_name} crashed:", traceback.format_exc()[-1500:], flush=True)
                try:
                    e11_kill_server(wait=True)
                except Exception:
                    pass
                e14_save()
                continue''')

rep('''        ems_tp2("tp2x2_dflash_w6")
        _mt = {k: v for k, v in EMSR["arms"].items() if v.get("family") == "mtp" and not k.endswith("_s20") and _gated(v)
               and v.get("short_tok_s")}
        if _mt:''', '''        if EMS_TP2_ON:
            ems_tp2("tp2x2_dflash_w6")
        else:
            for _k in ("tp2x2_dflash_w6", "tp2x2_mtp"):
                EMSR["arms"][_k] = {"ok": False, "skipped": "OTHER_PART: 2 x TP2 runs in the EMS RISKY notebook"}
                EMSR["order"].append(_k)
        _mt = {k: v for k, v in EMSR["arms"].items() if v.get("family") == "mtp" and not k.endswith("_s20") and _gated(v)
               and v.get("short_tok_s")}
        if _mt and EMS_TP2_ON:''')

rep('''    L = ["# EMS: SGLang engine-config matrix", "",''', '''    L = [f"# EMS {globals().get('EMS_PART', '')}: SGLang engine-config matrix", "",''')

# ---- the builder writes both parts
old_tail = t[t.index('''nb = json.load(open(SRC, encoding="utf-8"))'''):]
new_tail = '''for PART in ("SAFE", "RISKY"):
    cells_p = [c.replace('"__EMS_PART__"', f'"{PART}"') for c in cells]
    assert sum(c.count(f'or "{PART}"') for c in cells_p) == 1
    md_p = md.replace("# EMS — SGLang engine-config matrix", f"# EMS {PART} — SGLang engine-config matrix", 1) + (
        "\\n**rev 2f part " + PART + ":** " + ("oracle + reference + MTP 3/1/4, DFlash 20 / 24 (+ the best MTP at 20), MTP 2/1/3, "
        "mem 0.86, DFlash width 4 / 8; no patch, no overlay, no TP2." if PART == "SAFE" else
        "oracle + reference + MTP 3/1/4 (A/B partner), #45151, PCIe-IPC (DFlash / MTP), NTN INT4 / FP8, ReplaySSM fp16 / "
        "fp32, then 2 x TP2.") + " The other part is its own notebook (a crash in one cannot touch the other).\\n")
    nb = json.load(open(SRC, encoding="utf-8"))
    nb["cells"] = [{"cell_type": "markdown", "metadata": {}, "source": md_p.splitlines(keepends=True)}] + [
        {"cell_type": "code", "execution_count": None, "metadata": {}, "outputs": [], "source": c.splitlines(keepends=True)}
        for c in cells_p]
    for i, c in enumerate(cells_p):
        compile(c, f"<cell{i}>", "exec")
    out = NBDIR / f"Q27-XHIGH-EMS_{PART}_ENGINE_MATRIX_SGLANG.ipynb"
    if out.exists() and sha(out) in PUSHED:
        out = out.with_name(out.stem + "_REBUILD.ipynb")
    data = json.dumps(nb, indent=1, ensure_ascii=False) + "\\n"
    out.write_bytes(data.encode("utf-8"))
    print(out.name, sha(out)[:8], f"{len(data.encode('utf-8')) / 1024:.0f} kB", len(cells_p), "code cells")
'''
t = t.replace(old_tail, new_tail)
p.write_text(t, encoding="utf-8", newline="\n")
print("patched")
