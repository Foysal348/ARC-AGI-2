"""EMS rev 2g: one pass over the GPT rev 2f audits (R1-R6 + R2F-01..10) and our 4 agents (each claim checked in the code
first). Every change below keeps the speed data of an arm; it only stops adoption without evidence.
- _safe(): every arm call (PLAN, the best MTP at 20, both 2 x TP2) records its own crash and the next arm runs
  (R2F-05, agents N1 / N2); the adoption pass also runs from the outer except.
- the best gated MTP at 20 streams runs per part AFTER the plan (agents N3: RISKY candidates #45151 / PCIe / NTN were
  never eligible after the split).
- _gated fail-closed: XL parity must be PASS whenever XL prompts exist (a skipped XL = no evidence; R2F-02 / R6); the
  oracle canary must exist with 0 errors / 0 leaks / idle; a PCIe-IPC arm without 'workspace built' in its log is
  backend-unverified (GPT R-2).
- the canary runs at the arm's own level (agent A1), and records informative / classification (R2F-07).
- grid rule: structural (only digits / brackets / commas / whitespace, every row <= 30 cells = the ARC maximum), not a
  digit share (R2F-06 / R3): "0"*250 and "0 0 0 ..." x 200 are degenerate, a real ARC grid never is.
- the half-started server is killed when its own start raises (agent 4 #3); the #45151 locator runs with the venv env
  (agent N7); bounded TP2 joins (R2F-08); custom_allreduce_disabled read from the flags (N8); topology recorded in
  SAFE too (N5); FP8 prefetch only where FP8 runs (N4); EMS_PART validated (N6); one bundle name per part.
- arm cap 12 -> 14 min and reference / target window phases 11 -> 14 min (the XL band is required for adoption now),
  stream max_new 4096 -> 16384 (a stream that finishes inside a window lowers the running share = a false reject).
- candidate_for_arc_validation / certified_exact / production_approved (always False here: needs the 60k+ generation
  and ARC task gates) kept apart (GPT R-4 policy)."""
from pathlib import Path

p = Path(r"D:/ARC AGI 2/experiments/Experiment 14 - Optimized Engine on 4xL4 (planned)/Experiment Notebooks/Build/build_ems.py")
t = p.read_text(encoding="utf-8")


def rep(a, b, n=1):
    global t
    assert t.count(a) == n, (t.count(a), a[:100])
    t = t.replace(a, b)


# ---- half-started server (e14_launch)
rep('''    srv.start()
    _room = HARD_STOP - time.perf_counter() - (10 * 60 if force else E14_RESERVE + 8 * 60)
    ok, why = srv.wait_ready(min(timeout or SGL_RELAUNCH_TIMEOUT_SEC, max(60.0, _room)))''', '''    srv.start()
    try:          # rev 2g: a crash while this server starts never leaves it holding the GPUs
        _room = HARD_STOP - time.perf_counter() - (10 * 60 if force else E14_RESERVE + 8 * 60)
        ok, why = srv.wait_ready(min(timeout or SGL_RELAUNCH_TIMEOUT_SEC, max(60.0, _room)))
    except BaseException:
        try:
            srv.kill()
        except Exception:
            pass
        raise''')

# ---- EMS_PART validated
rep('''EMS_TP2_ON = EMS_PART in ("ALL", "RISKY")''', '''assert EMS_PART in ("ALL", "SAFE", "RISKY"), EMS_PART      # rev 2g: a typo must not silently skip every arm
EMS_TP2_ON = EMS_PART in ("ALL", "RISKY")''')

# ---- #45151 locator with the venv env
rep('''capture_output=True, text=True, timeout=300).stdout.strip().splitlines()[-1]''',
    '''capture_output=True, text=True, timeout=300, env=E14_VENV["env"]).stdout.strip().splitlines()[-1]''')

# ---- FP8 prefetch only where FP8 runs
rep('''            if _fp8 and not E11_HARNESS:''', '''            if _fp8 and not E11_HARNESS and EMS_PART in ("ALL", "RISKY"):      # rev 2g: SAFE has no FP8 arm''')

# ---- canary: informative / classification
rep('''            return {"level": level, "own_hits": sum(1 for s_, x in zip(sent, texts) if s_ in x),
                    "foreign_leaks": sum(1 for i, x in enumerate(texts) for j, s_ in enumerate(sent) if j != i and s_ in x),
                    "errors": sum(1 for r_ in rows if r_.get("error")), "server_not_idle": _dirty_rows(rows)}''',
    '''            c_ = {"level": level, "own_hits": sum(1 for s_, x in zip(sent, texts) if s_ in x),
                  "foreign_leaks": sum(1 for i, x in enumerate(texts) for j, s_ in enumerate(sent) if j != i and s_ in x),
                  "errors": sum(1 for r_ in rows if r_.get("error")) + max(0, level - len(rows)), "server_not_idle": _dirty_rows(rows)}
            # rev 2g (GPT R2F-07): 0 own hits = the detector showed nothing (a paraphrasing model): INCONCLUSIVE, not proof
            c_["informative"] = c_["own_hits"] > 0 and c_["errors"] == 0
            c_["classification"] = ("FAIL" if c_["foreign_leaks"] else "INCOMPLETE" if c_["errors"] else
                                    "INCONCLUSIVE" if not c_["informative"] else "PASS_NO_OBSERVED_LEAK")
            return c_''')

# ---- canary at the arm's own level
rep('''        def _gate2(ctx, tag):''', '''        def _gate2(ctx, tag, level=None):''')
rep('''            out["canary"] = _canary(ctx, len(EMS_REF["conc_a"]), tag)''',
    '''            out["canary"] = _canary(ctx, max(len(EMS_REF["conc_a"]), level or 0), tag)      # rev 2g: at the arm's level''')
rep('''                    out["gate"] = _gate2(ctx, "gate_" + tag)''', '''                    out["gate"] = _gate2(ctx, "gate_" + tag, level)''')

# ---- longer streams in the windows
rep('''                    out[band] = E14M.steady_window(ctx, ps, level=level, secs=_ts(75), tag=tag + band)''',
    '''                    out[band] = E14M.steady_window(ctx, ps, level=level, secs=_ts(75), tag=tag + band, max_new=16384)''')
rep('''                    out["xl"] = E14M.steady_window(ctx, _X, level=xl_level, secs=_ts(75), tag=tag + "xl")''',
    '''                    out["xl"] = E14M.steady_window(ctx, _X, level=xl_level, secs=_ts(75), tag=tag + "xl", max_new=16384)''')

# ---- caps
rep('''cap=12 * 60, env=None, timeout=None):''', '''cap=14 * 60, env=None, timeout=None):      # rev 2g: 12 -> 14 min''')
rep('''_ts(11 * 60))''', '''_ts(14 * 60))''', n=2)

# ---- _gated fail-closed
rep('''            if (EMSR.get("canary_oracle") or {}).get("foreign_leaks"):
                return False''', '''            # rev 2g (GPT R2F-02 / R6): XL parity required whenever XL prompts exist (skipped / missing = no evidence);
            # the oracle's own canary must exist and be clean; a PCIe-IPC arm must show its workspace was really built
            if _X and a.get("xl_gate") != "PASS":
                return False
            _oc = EMSR.get("canary_oracle")
            if not isinstance(_oc, dict) or _oc.get("foreign_leaks") != 0 or _oc.get("errors") != 0 or _oc.get("server_not_idle"):
                return False
            if (a.get("env") or {}).get("SGLANG_ENABLE_PCIE_IPC_ALLREDUCE") and not (a.get("pcie_ipc") or {}).get("workspace_built"):
                return False''')

# ---- grid rule (structural)
rep('''            core = re.sub(r"\\s", "", s)
            if core and sum(ch.isdigit() for ch in core) / len(core) >= 0.30:
                return False''', '''            # rev 2g (GPT R2F-06): an ARC grid by structure (only digits / brackets / commas / whitespace, every row
            # <= 30 cells, the ARC maximum), not by a digit share: "0" * 250 or "0 0 0 ..." x 200 is degenerate
            if re.fullmatch(r"[0-9,\\[\\]\\s]+", s) and len(re.findall(r"\\d", s)) >= 2 \\
                    and all(len(re.findall(r"\\d", r_)) <= 30 for r_ in re.split(r"\\]|\\n", s)):
                return False''')

# ---- _safe helper + PLAN loop + best MTP at 20 per part
rep('''            try:                 # rev 2f: one arm's own crash never ends the remaining arms
                _arm(_name, **_kw)
            except Exception as _e:
                EMSR["arms"][_name] = dict(EMSR["arms"].get(_name) or {}, ok=False,
                                           error=f"arm crashed: {type(_e).__name__}: {_e}"[:500], adoptable=False)
                if _name not in EMSR["order"]:
                    EMSR["order"].append(_name)
                print(f"EMS arm {_name} crashed:", traceback.format_exc()[-1500:], flush=True)
                try:
                    e11_kill_server(wait=True)
                except Exception:
                    pass
                e14_save()
                continue
            if _name == "dflash_w6_s24":
                # the fastest gated MTP so far at 20 streams (the KV it frees is the reason to run it); rev 2b: by family
                _mt = {k: v for k, v in EMSR["arms"].items() if v.get("family") == "mtp" and _gated(v) and v.get("short_tok_s")}
                if _mt:
                    _best = max(_mt, key=lambda k: _mt[k]["short_tok_s"])
                    _arm(_best + "_s20", set_=EMSR["arms"][_best]["set"], drop=tuple(EMSR["arms"][_best]["drop"]), streams=20,
                         env=EMSR["arms"][_best].get("env"))
''', '''            _safe(_name, _arm, _name, **_kw)      # rev 2f/2g: one arm's own crash never ends the remaining arms

        # rev 2g (agents N3): the fastest gated MTP of THIS part at 20 streams, after the whole plan (in RISKY the #45151 /
        # PCIe / NTN arms are candidates: the KV #45151 frees is the reason to run it); rev 2b: by family
        _mt = {k: v for k, v in EMSR["arms"].items() if v.get("family") == "mtp" and not k.endswith("_s20") and _gated(v)
               and v.get("short_tok_s")}
        if _mt and not E14_VENV["cfg"].get("streams12"):
            _best = max(_mt, key=lambda k: _mt[k]["short_tok_s"])
            _safe(_best + "_s20", _arm, _best + "_s20", set_=EMSR["arms"][_best]["set"], drop=tuple(EMSR["arms"][_best]["drop"]),
                  streams=20, env=EMSR["arms"][_best].get("env"))
''')
rep('''        for _name, _kw in PLAN:
            _why = None''', '''        def _safe(name, fn, *args, **kw):
            """rev 2g: run one arm; its own crash is recorded on it, its server killed, the results saved, the next arm runs."""
            try:
                return fn(*args, **kw)
            except Exception as _e:
                EMSR["arms"][name] = dict(EMSR["arms"].get(name) or {}, ok=False,
                                          error=f"arm crashed: {type(_e).__name__}: {_e}"[:500], adoptable=False)
                if name not in EMSR["order"]:
                    EMSR["order"].append(name)
                print(f"EMS arm {name} crashed:", traceback.format_exc()[-1500:], flush=True)
                try:
                    e11_kill_server(wait=True)
                except Exception:
                    pass
                e14_save()
                return None

        def _ems_adopt_all():
            """rev 2e / 2g: speed, correctness and adoption kept apart; production_approved needs the 60k+ generation and
            ARC task gates this matrix does not run."""
            for _k, _a in EMSR["arms"].items():
                _a["adoptable"] = bool(_gated(_a)) and _a.get("family") in ("mtp", "dflash")
                _a["candidate_for_arc_validation"] = _a["adoptable"]
                _a["certified_exact"] = _a["adoptable"] and _a.get("gate_class") == "PASS_EXACT"
                _a["production_approved"] = False

        for _name, _kw in PLAN:
            _why = None''')

# ---- topology in SAFE too; TP2 calls guarded; placeholder name
rep('''        if EMS_TP2_ON:
            ems_tp2("tp2x2_dflash_w6")
        else:
            for _k in ("tp2x2_dflash_w6", "tp2x2_mtp"):''', '''        if not EMSR.get("topology"):      # rev 2g (agents N5): recorded in every part
            try:
                ems_topo()
            except Exception as _e:
                EMSR["topology"] = {"error": repr(_e)[:200]}
        if EMS_TP2_ON:
            _safe("tp2x2_dflash_w6", ems_tp2, "tp2x2_dflash_w6")
        else:
            for _k in ("tp2x2_dflash_w6", "tp2x2_mtp_best"):''')
rep('''            ems_tp2("tp2x2_" + _best, set_=EMSR["arms"][_best]["set"], drop=tuple(EMSR["arms"][_best]["drop"]),
                    env=EMSR["arms"][_best].get("env"))
        for _k, _a in EMSR["arms"].items():      # rev 2e (GPT audit E8): speed, correctness and adoption kept apart
            _a["adoptable"] = bool(_gated(_a)) and _a.get("family") in ("mtp", "dflash")
            _a["certified_exact"] = _a["adoptable"] and _a.get("gate_class") == "PASS_EXACT"     # rev 2e-d''',
    '''            _safe("tp2x2_" + _best, ems_tp2, "tp2x2_" + _best, set_=EMSR["arms"][_best]["set"],
                  drop=tuple(EMSR["arms"][_best]["drop"]), env=EMSR["arms"][_best].get("env"))
        _ems_adopt_all()''')
rep('''    EMSR["error"] = traceback.format_exc()[-3000:]
    print("EMS cell error:", EMSR["error"][-1500:], flush=True)''', '''    EMSR["error"] = traceback.format_exc()[-3000:]
    print("EMS cell error:", EMSR["error"][-1500:], flush=True)
    try:          # rev 2g: the adoption columns are written even after a cell-level error
        globals().get("_ems_adopt_all", lambda: None)()
    except Exception:
        pass''')

# ---- TP2: bounded joins, custom all-reduce from the flags
rep('''                    for t in ths:
                        t.join()
                    return outs''', '''                    _dl = min(getattr(c, "deadline", HARD_STOP) or HARD_STOP for c in ctxs)
                    for t in ths:          # rev 2g (GPT R2F-08): bounded by the arm's deadline
                        t.join(timeout=max(1.0, _dl - time.perf_counter() + 60))
                    if any(t.is_alive() for t in ths):
                        for srv, _ in servers:
                            try:
                                srv.kill()
                            except Exception:
                                pass
                        return [{"error": "TP2_WORKER_DEADLINE"}, {"error": "TP2_WORKER_DEADLINE"}]
                    return outs''')
rep('''                                        "custom_allreduce_disabled": "CustomAllreduce is disabled" in _lt,''',
    '''                                        # rev 2g (agents N8): the flag disables it before the log line can appear
                                        "custom_allreduce_disabled": "CustomAllreduce is disabled" in _lt
                                        or any("--disable-custom-all-reduce" in f for f in rec.get("replica_flags") or []),''')

# ---- bundle per part
rep('''    _pack = WORKING / "Q27X_EMS_BUNDLE.zip"''', '''    _pack = WORKING / f"Q27X_EMS_{globals().get('EMS_PART', 'ALL')}_BUNDLE.zip"      # rev 2g: one name per part''')
p.write_text(t, encoding="utf-8", newline="\n")
print("patched")
