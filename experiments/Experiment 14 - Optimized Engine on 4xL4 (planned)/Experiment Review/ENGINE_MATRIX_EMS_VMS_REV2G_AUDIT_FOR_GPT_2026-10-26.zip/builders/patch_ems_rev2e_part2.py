
from pathlib import Path
p = Path(r"D:/ARC AGI 2/experiments/Experiment 14 - Optimized Engine on 4xL4 (planned)/Experiment Notebooks/Build/build_ems.py")
t = p.read_text(encoding="utf-8")
def rep(a, b, n=1):
    global t
    assert t.count(a) == n, (t.count(a), a[:100])
    t = t.replace(a, b)
rep("""             "short_error": _w(r, "short", "error"), "long_error": _w(r, "long", "error"),""", """             "short_error": _w(r, "short", "error"), "long_error": _w(r, "long", "error"),
             "window_errors_short": _w(r, "short", "errors") or [], "window_errors_long": _w(r, "long", "errors") or [],
             "running_share_short": _w(r, "short", "real_running_share"), "running_share_long": _w(r, "long", "real_running_share"),
             "gate_class": ((r or {}).get("gate") or {}).get("gate_class"),""")
rep("""            # rev 2e (GPT audit HIGH-3): no independent target-only oracle = nothing is adoptable (diagnostics still run)""",
    """            # rev 2e (2nd audit HIGH-3): a failed stream or a window that did not really hold its level is no evidence
            if a.get("window_errors_short") or a.get("window_errors_long"):
                return False
            if any((a.get(f"running_share_{b_}") is None or a[f"running_share_{b_}"] < 0.80) for b_ in ("short", "long")):
                return False
            # rev 2e (GPT audit HIGH-3): no independent target-only oracle = nothing is adoptable (diagnostics still run)""")
rep("""            return {"ok": ok, "verdict": v, "serial": ps, "all_at_once": pc, "tail_degenerate": tail_c, "tail_degenerate_aa": tail_b}""",
    """            _same = (ps.get("arm_identical") == ps.get("compared")) and (pc.get("arm_identical") == pc.get("compared"))
            gc = ("PASS_EXACT" if _same else "BOUNDARY") if v == "PASS" else v      # rev 2e (2nd audit HIGH-6)
            return {"ok": ok, "verdict": v, "gate_class": gc, "serial": ps, "all_at_once": pc, "tail_degenerate": tail_c,
                    "tail_degenerate_aa": tail_b}""")
rep("""                if "EMS_PR45151" in src:
                    out.update(applied=True, why="already patched", file=fp)
                    return out""", """                _m1 = 'self._ems_shared = _ems_os.environ.get("EMS_PR45151") == "1"'
                _m2 = 'if not getattr(self, "_ems_shared", False):'
                if _m1 in src and _m2 in src:
                    out.update(applied=True, why="already patched (both snippets present)", file=fp,
                               sha256=hashlib.sha256(src.encode("utf-8")).hexdigest())
                    return out
                if "EMS_PR45151" in src:
                    out["why"] = "partial patch found (one snippet only): not used"
                    return out""")
rep("""                compile(src, fp, "exec")
                Path(fp).write_text(src, encoding="utf-8")""", """                compile(src, fp, "exec")
                assert src.count('self._ems_shared = _ems_os.environ.get("EMS_PR45151") == "1"') == 1
                assert src.count('if not getattr(self, "_ems_shared", False):') == 1
                import tempfile as _tf
                shutil.copy2(fp, fp + ".ems_orig")             # the shipped file, kept next to it
                _fd, _tmp = _tf.mkstemp(prefix=Path(fp).name + ".", suffix=".tmp", dir=str(Path(fp).parent))
                with os.fdopen(_fd, "w", encoding="utf-8") as _fh:
                    _fh.write(src)
                    _fh.flush()
                    os.fsync(_fh.fileno())
                os.replace(_tmp, fp)                            # atomic: a killed process never leaves half a module
                assert Path(fp).read_text(encoding="utf-8") == src""")
rep("""        rec["skipped"] = "would eat the 2 x TP2 slot" if (not force and E14_RESERVE) else "less than ~17 min before the hard stop\"""",
    """        rec["skipped"] = "NOT_TESTED_BUDGET: " + ("would eat the 2 x TP2 slot" if (not force and E14_RESERVE) else "less than ~17 min before the hard stop")""")
rep("""                 f"{(a.get('pcie_ipc') or {}).get('workspace_built', '')} | {a.get('adoptable')} |")""",
    """                 f"{(a.get('pcie_ipc') or {}).get('workspace_built', '')} | {a.get('adoptable')} {a.get('gate_class') or ''} |")""")
p.write_text(t, encoding="utf-8", newline="\n")
print("patched 2e part 2")
