"""VMS rev 2e-b (user 2026-10-26: research before changing, never throw valid data away without proof): an unsettled
prefill window is kept as mixed_load data (not healthy), not discarded; the settle budget is 300 s (a no-prefix arm
prefills 16 x 40k tokens); the next band is skipped only after a dirty / dead server, not after any window error."""
from pathlib import Path

p = Path(r"D:/ARC AGI 2/experiments/Experiment 14 - Optimized Engine on 4xL4 (planned)/Experiment Notebooks/Build/build_vms.py")
t = p.read_text(encoding="utf-8")


def rep(a, b):
    global t
    assert t.count(a) == 1, (t.count(a), a[:90])
    t = t.replace(a, b)


rep(r'''        # a request counts as running once its first prefill chunk is scheduled: start only when nothing waits (or the
        # plateau) and 3 consecutive prompt-token readings are equal (<= 120 s)
        t_s, last, stable, settled = time.perf_counter(), None, 0, False
        while time.perf_counter() - t_s < 120 and time.perf_counter() < end - secs - 15:''', r'''        # a request counts as running once its first prefill chunk is scheduled: start only when nothing waits (or the
        # plateau) and 3 consecutive prompt-token readings are equal. Up to 300 s: a no-prefix-cache arm prefills
        # 16 x 40k = 640k tokens (minutes); a window that still did not settle is measured but labelled mixed_load
        # (excluded from measurement_ok), never thrown away
        t_s, last, stable, settled = time.perf_counter(), None, 0, False
        while time.perf_counter() - t_s < 300 and time.perf_counter() < end - secs - 15:''')
rep(r'''        out.update(settle_sec=round(time.perf_counter() - t_s, 1), prefill_settled=settled)
        if not settled:
            out["error"] = "PREFILL_NOT_SETTLED"
            return out''', r'''        out.update(settle_sec=round(time.perf_counter() - t_s, 1), prefill_settled=settled, mixed_load=not settled)''')
rep(r'''    return bool(w) and not w.get("error") and not w.get("skipped") and (w.get("tok_s") or 0) > 0 \
        and w.get("stream_errors", 0) == 0''', r'''    return bool(w) and not w.get("error") and not w.get("skipped") and (w.get("tok_s") or 0) > 0 \
        and w.get("prefill_settled") is True and w.get("stream_errors", 0) == 0''')
rep(r'''            if time.perf_counter() < t_end and not _vms_dead() and not (a["short"] or {}).get("error"):''', r'''            # the next band runs unless the server is dead or dirty (a contaminated window would follow)
            _stop_next = lambda w: (w or {}).get("error") == "DIRTY_SERVER_AFTER_WINDOW" or (w or {}).get("idle_after") is False
            if time.perf_counter() < t_end and not _vms_dead() and not _stop_next(a["short"]):''')
rep(r'''            if _X and not _dp and time.perf_counter() < t_end and not _vms_dead() and not (a.get("long") or {}).get("error"):''',
    r'''            if _X and not _dp and time.perf_counter() < t_end and not _vms_dead() and not _stop_next(a.get("long")):''')
p.write_text(t, encoding="utf-8", newline="\n")
print("patched")
