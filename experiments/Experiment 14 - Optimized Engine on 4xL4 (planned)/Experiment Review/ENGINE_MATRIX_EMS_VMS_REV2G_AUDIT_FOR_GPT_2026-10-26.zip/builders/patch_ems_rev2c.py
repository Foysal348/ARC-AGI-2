"""EMS rev 2c: the deep re-read of the GPT pre-GPU audit (Bug ang fix). Its FINAL priority (1) = #43029 + #45151.
- #45151 (open PR for #44145, reproduced on SGLang v0.5.21): the EAGLE/MTP draft keeps its own BF16 embed_tokens + lm_head
  (248,320 x 5,120 each, ~4.74 GiB, ~1.19 GiB per GPU at TP4) while the target KV pool is sized (scheduler.py:1049-1075:
  init_target_memory_pool before draft alloc_memory_pool -> init_token_map / init_lm_head). Diff read in full
  (_scratch/upstream_prs/pr45151.diff, 2 hunks + a unit test); the same two anchors exist once in our 0.5.21
  eagle_worker_v2.py (class EagleDraftWorker). Added as an env-gated patch (EMS_PR45151=1) + one measured MTP arm.
- #43029 (merged 2026-10-10, after 0.5.21): grammar-truncated speculative runs only; EMS / production use no grammar.
- Gate D: `nvidia-smi topo -p2p p` recorded; NCCL_DEBUG=INFO (INIT) for the TP2 replicas."""
from pathlib import Path

p = Path(r"D:/ARC AGI 2/experiments/Experiment 14 - Optimized Engine on 4xL4 (planned)/Experiment Notebooks/Build/build_ems.py")
t = p.read_text(encoding="utf-8")


def rep(a, b, n=1):
    global t
    assert t.count(a) == n, (t.count(a), a[:100])
    t = t.replace(a, b)


rep('''usage: python build_ems.py   -> ../Q27-XHIGH-EMS_ENGINE_MATRIX_SGLANG.ipynb"""''', '''rev 2c (deep re-read of the GPT audit, its FINAL priority 1): SGLang PR #45151 (issue #44145, reproduced on 0.5.21: the
MTP draft's duplicate BF16 embed / lm_head, ~1.19 GiB per GPU at TP4, is resident when the target KV pool is sized) as an
env-gated patch of the installed eagle_worker_v2.py + the arm mtp_3_1_4_pr45151; #43029 not applicable (grammar only);
`nvidia-smi topo -p2p p` recorded and NCCL_DEBUG=INFO on the TP2 replicas (Gate D).
usage: python build_ems.py   -> ../Q27-XHIGH-EMS_ENGINE_MATRIX_SGLANG.ipynb"""''')

# ---- the env-gated #45151 patch, applied once to the installed SGLang (inert unless EMS_PR45151=1)
rep('''    EMSR["ref_name"], EMSR["base_cfg"] = REF_NAME, dict(E14_VENV["cfg"])''', '''    EMSR["ref_name"], EMSR["base_cfg"] = REF_NAME, dict(E14_VENV["cfg"])

    def ems_patch_pr45151():
        """SGLang PR #45151 (open; fixes #44145, reproduced on v0.5.21), env-gated: with EMS_PR45151=1 the EAGLE/MTP draft
        binds the target's embed_tokens / lm_head in EagleDraftWorker.__init__, before the scheduler sizes the target KV
        pool; alloc_memory_pool then skips the second binding. Without the env var the file behaves as shipped."""
        out = {"applied": False}
        try:
            if E11_HARNESS:
                out["why"] = "harness: no SGLang install"
                return out
            fp = subprocess.run([E14_VENV["launch"][0], "-c", "import sglang.srt.speculative.eagle_worker_v2 as m; print(m.__file__)"],
                                capture_output=True, text=True, timeout=300).stdout.strip().splitlines()[-1]
            src = Path(fp).read_text(encoding="utf-8")
            a = "        self.plan_stream, self.plan_stream_ctx = get_plan_stream(self.device)\\n\\n    def alloc_memory_pool(\\n"
            b = "        self.init_token_map()\\n        self.init_lm_head()\\n\\n        if get_spec().speculative_use_rejection_sampling:"
            if "EMS_PR45151" in src:
                out.update(applied=True, why="already patched", file=fp)
                return out
            if src.count(a) != 1 or src.count(b) != 1:
                out["why"] = f"anchors not unique / missing ({src.count(a)}, {src.count(b)})"
                return out
            src = src.replace(a, "        self.plan_stream, self.plan_stream_ctx = get_plan_stream(self.device)\\n"
                                 "        # EMS: SGLang PR #45151 (issue #44145), env-gated\\n"
                                 "        import os as _ems_os\\n"
                                 "        self._ems_shared = _ems_os.environ.get(\\"EMS_PR45151\\") == \\"1\\"\\n"
                                 "        if self._ems_shared:\\n"
                                 "            self.init_token_map()\\n"
                                 "            self.init_lm_head()\\n"
                                 "            torch.cuda.empty_cache()\\n"
                                 "\\n    def alloc_memory_pool(\\n")
            src = src.replace(b, "        if not getattr(self, \\"_ems_shared\\", False):\\n"
                                 "            self.init_token_map()\\n            self.init_lm_head()\\n\\n"
                                 "        if get_spec().speculative_use_rejection_sampling:")
            compile(src, fp, "exec")
            Path(fp).write_text(src, encoding="utf-8")
            for pyc in Path(fp).parent.glob("__pycache__/eagle_worker_v2*.pyc"):
                pyc.unlink()
            out.update(applied=True, file=fp)
        except Exception as e:
            out["why"] = f"{type(e).__name__}: {e}"[:300]
        return out
    EMSR["pr45151_patch"] = ems_patch_pr45151()
    print("EMS PR #45151 patch:", EMSR["pr45151_patch"], flush=True)''')

# ---- the arm (right after mtp_3_1_4: it is a candidate for the 20-stream MTP pick, where KV binds)
rep('''        ("mtp_3_1_4", dict(set_=_mtp(), drop=_SPEC + ("--min-free-slots-delay",))),''', '''        ("mtp_3_1_4", dict(set_=_mtp(), drop=_SPEC + ("--min-free-slots-delay",))),
        # rev 2c: the same arm with PR #45151 (env-gated patch): compare KV tokens and tok/s with mtp_3_1_4
        ("mtp_3_1_4_pr45151", dict(set_=_mtp(), drop=_SPEC + ("--min-free-slots-delay",), env={"EMS_PR45151": "1"})),''')
rep('''        return _record(name, _ok, _rec, _r, gate, {"set": s, "drop": list(drop), "level_wanted": streams or LEVEL, "family": fam})''',
    '''        return _record(name, _ok, _rec, _r, gate, {"set": s, "drop": list(drop), "level_wanted": streams or LEVEL, "family": fam,
                                                   "env": dict(env or {})})''')
rep('''                _arm(_best + "_s20", set_=EMSR["arms"][_best]["set"], drop=tuple(EMSR["arms"][_best]["drop"]), streams=20)''',
    '''                _arm(_best + "_s20", set_=EMSR["arms"][_best]["set"], drop=tuple(EMSR["arms"][_best]["drop"]), streams=20,
                     env=EMSR["arms"][_best].get("env"))''')
rep('''        ems_tp2("tp2x2_" + _best, set_=EMSR["arms"][_best]["set"], drop=tuple(EMSR["arms"][_best]["drop"]))''',
    '''        ems_tp2("tp2x2_" + _best, set_=EMSR["arms"][_best]["set"], drop=tuple(EMSR["arms"][_best]["drop"]),
                env=EMSR["arms"][_best].get("env"))''')
rep('''    def ems_tp2(name, set_=None, drop=(), per=8):''', '''    def ems_tp2(name, set_=None, drop=(), per=8, env=None):''')
rep('''                env = dict(E14_VENV["env"], CUDA_VISIBLE_DEVICES=devs)
                env.update(ems_replica_env(r))''', '''                env_r = dict(E14_VENV["env"], CUDA_VISIBLE_DEVICES=devs, NCCL_DEBUG="INFO", NCCL_DEBUG_SUBSYS="INIT")   # rev 2c: Gate D
                env_r.update(env or {})
                env_r.update(ems_replica_env(r))''')
rep('''                rec.setdefault("cache_dirs", []).append({k: env[k] for k in E14L.jit_cache_env()})''',
    '''                rec.setdefault("cache_dirs", []).append({k: env_r[k] for k in E14L.jit_cache_env()})''')
rep('''                srv = E11Server(E14_VENV["launch"] + flags, env, f"ems_{name}_r{r}")''',
    '''                srv = E11Server(E14_VENV["launch"] + flags, env_r, f"ems_{name}_r{r}")''')

# ---- topology: also the P2P matrix (Gate D / section 7)
rep('''            txt = subprocess.run(["nvidia-smi", "topo", "-m"], capture_output=True, text=True, timeout=30).stdout
            out["matrix"] = txt[-3000:]''', '''            txt = subprocess.run(["nvidia-smi", "topo", "-m"], capture_output=True, text=True, timeout=30).stdout
            out["matrix"] = txt[-3000:]
            try:      # rev 2c (GPT audit Gate D): the P2P read capability matrix as well
                out["p2p_read"] = subprocess.run(["nvidia-smi", "topo", "-p2p", "r"], capture_output=True, text=True,
                                                 timeout=30).stdout[-2000:]
            except Exception as _e:
                out["p2p_read"] = repr(_e)[:200]''')
p.write_text(t, encoding="utf-8", newline="\n")
print("patched")
