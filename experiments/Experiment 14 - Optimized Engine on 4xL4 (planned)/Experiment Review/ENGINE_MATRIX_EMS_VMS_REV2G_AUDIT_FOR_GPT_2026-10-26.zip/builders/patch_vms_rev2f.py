"""VMS rev 2f (user 2026-10-26, the 3-part split: VMS is part 3): vms_arm is wrapped, so an exception in its own code
(the launch or the post-processing are outside its inner try) is recorded on that arm and the next arm still runs."""
from pathlib import Path
p = Path(r"D:/ARC AGI 2/experiments/Experiment 14 - Optimized Engine on 4xL4 (planned)/Experiment Notebooks/Build/build_vms.py")
t = p.read_text(encoding="utf-8")
a = '''def vms_arm(name, flags, *, level=16, gate=True, env_extra=None, cap=14 * 60):'''
assert t.count(a) == 1
t = t.replace(a, '''def vms_arm(name, flags, **kw):
    """rev 2f: one arm's own crash never ends the remaining arms (recorded, the server killed, the results saved)."""
    try:
        return _vms_arm(name, flags, **kw)
    except Exception as _e:
        a = dict(VMS["arms"].get(name) or {}, ok=False, adoptable=False, certified_exact=False,
                 error=f"arm crashed: {type(_e).__name__}: {_e}"[:500])
        VMS["arms"][name] = a
        if name not in VMS["order"]:
            VMS["order"].append(name)
        print(f"VMS arm {name} crashed:", traceback.format_exc()[-1500:], flush=True)
        try:
            if VMS_SERVER is not None:
                VMS_SERVER.kill()
        except Exception:
            pass
        e14_save()
        return a


def _vms_arm(name, flags, *, level=16, gate=True, env_extra=None, cap=14 * 60):''')
p.write_text(t, encoding="utf-8", newline="\n")
print("patched")
