# Engine-matrix notebooks (EMS = SGLang 0.5.21, VMS = vLLM 0.32.0): audit pack rev 2g, 2026-10-26

Notebook shas: EMS `SAFE 9ed2b035 / RISKY 5b8b91f2`, VMS `6c2a39c5` (rev 2g = the rev 2f split + every fix for your two rev 2f audits and our 4 agents: start with
`notes/EMS_VMS_rev2g_disposition_rev2f_audits_2026-10-26.md`; rev 2f: EMS split into SAFE + RISKY notebooks so a crash in one cannot touch the other; VMS is the third
part; every arm call in its own try/except; `notebooks/rev2c_*` = the old rev 2c notebooks). This pack = the rev 2c pack (everything below the line is the
rev 2c README, kept) + the rev 2e changes. Start with `notes/EMS_VMS_rev2e_independent_audits_disposition_2026-10-26.md`:
every item of your two independent audits of rev 2c (`gpt_audit_input/README_EMS_VMS_REV2C_INDEPENDENT_AUDIT_2026-10-26.md`
HIGH 1-10 + checklist, `gpt_audit_input/ENGINE_MATRIX_REV2C_INDEPENDENT_AUDIT_README_BN.md` E1-E12) with its status
(FIXED / PARTLY / NOT CHANGED / OPEN), where it is in the code, and the evidence.

## What is new since rev 2c
- rev 2d: an XL band (~85k-token prompts, streams = KV // 100k) and PCIe-IPC all-reduce arms (FlashInfer 0.7 overlay
  on SGLang; VLLM_ALLREDUCE_USE_FLASHINFER_PCIE_IPC on vLLM); budget 260 min (`notes/Rev2d_long_context_and_pcie_ipc_2026-10-26.md`).
- rev 2e: your two audits (fail-closed oracle, [DONE] + finish_reason, integer token ids, post-divergence tail check,
  PASS_EXACT / BOUNDARY, healthy-window rule, empty outputs counted, join + idle gate, e2e tok/s, prefix-cache counters,
  measurement / capacity / correctness / adoptable, canary, XL parity, #45151 atomic patch, run order).
- rev 2e-b / 2e-c / 2e-d / 2e-e: our own corrections, found while checking rev 2e. Unsettled windows are kept as
  mixed_load, not dropped. A grid-aware degenerate rule (ARC grids were flagged). The BOUNDARY label now matches the
  code, plus certified_exact. The EMS prefix-hit rate is read from the SGLang log. A VMS 900-s wait-loop hang is fixed.
  The EMS reference got probe_complete_vs_target. See the disposition, section "Self-audit corrections".
- `builders/patch_*rev2d*.py`, `patch_*rev2e*.py`, `patch_grid_aware_rev2e_c.py`: every change, assert-guarded.
- `kaggle_cpu_kit_runs/`: the Kaggle CPU kit v4 on these exact notebooks (same pinned image as the GPU notebooks): EMS
  ALL (every arm, full checks), EMS SAFE and RISKY (part split), VMS, VMS with the bad INT4 ignore list.

## What we ask: the FINAL pre-GPU audit (GO / NO-GO)
This is the last audit before the GPU run. Please answer with one verdict:
- **GO** for the GPU diagnostic run of all three notebooks, unless you find a **critical bug or a blocker**: something that
  would crash the run, waste the GPU budget, silently measure the wrong server / config, adopt an arm without
  correctness evidence, or reject a valid arm without evidence. Cite file:line and a concrete failure scenario for each.
- Minor issues, wording, nice-to-have tests: list them as NON-BLOCKING; they do not change GO.
- Already known and accepted (do not re-raise as blockers): BOUNDARY tolerance (documented; production_approved stays
  False); no 60k+ generation / ARC task gate inside this matrix (open for production); items under "Not changed, with
  the reason" in `notes/EMS_VMS_rev2g_disposition_rev2f_audits_2026-10-26.md`.
Start with that disposition: every item of your two rev 2f audits and our 4 agents, with what changed. The CPU kit on
these exact notebook shas is in `kaggle_cpu_kit_runs/`: ALL PASS. EMS ALL 33/33, EMS SAFE 7/7, EMS RISKY 7/7 (kit v7),
VMS 26/26 and VMS bad-INT4 26/26 (kit v8: a synthetic rev 2e test fixture had used 1-row data, which the R5 fix
correctly marks INCOMPLETE; the fixture now uses the planned 6 / 12 rows; the notebook is unchanged). No GPU run has
been made on rev 2g.

---

# Engine-matrix notebooks (EMS = SGLang 0.5.21, VMS = vLLM 0.32.0): implementation audit pack, 2026-10-26 (rev 2c)

Notebook shas: EMS `c062255e`, VMS `675db353`. Kaggle CPU kit run 3 (same pinned image as the GPU notebooks, Python 3.12.13) ALL OK: EMS 26/26, VMS 19/19 normal + 19/19 with the #58807 bad ignore list (`kaggle_cpu_kit_runs/`). Kit run 1 had caught a Py3.12-only crash (VGen._stop shadowing Thread._stop), fixed.
rev 2c = SGLang PR #45151 (issue #44145, proven in our 0.5.21: duplicate MTP embed/head resident while the KV pool is sized) as an env-gated patch + arm `mtp_3_1_4_pr45151` (`builders/patch_ems_rev2c.py`, `notes/upstream_sglang_pr45151.diff`, `notes/Deep_reread_rev2c_2026-10-26.md`); topology / P2P matrix and NCCL INIT logging. rev 2b = rev 2 (your pre-GPU audit) + a 4-agent implementation audit (`agent_reports/`, disposition `notes/EMS_VMS_rev2b_agent_audit_disposition_2026-10-26.md`).

## Goal
Pick the fastest correct serving configuration for Qwen3.8-27B on Kaggle (4 x L4 24 GB, SM 8.9, PCIe only, offline, 12 h).
The target is 600-800 output tok/s aggregate at 16+ streams. Both notebooks are engine-only and run no solver. Each arm is its own server launch:

1. a greedy correctness gate (serial + all at once, 256 tokens, against an identity oracle's own A/A);
2. two 75-s steady windows (8k-context and 40k-context prompts built from real ARC tasks) at the level the server really runs;
3. a report table and a bundle.

The time budget is 200 min each. 2 x TP2 runs last, from a reserved slot.

Current production for comparison: SGLang INT4 + DFlash2 width 6 at 16 streams, ~389 tok/s. In the last 6-h Poetiq run, 83 % of first answers hit the 60k cap and only 18 / 120 tasks reached iteration 2, so engine speed is the lever.

## What changed in this revision (your earlier pre-GPU audit, our disposition)
- `notes/EMS_rev2_audit_disposition_2026-10-25.md`: SGLang. Each S1-S9 item was checked in the 0.5.21 source; what changed and what did not, with file:line.
- `notes/VMS_rev2_audit_disposition_2026-10-26.md`: vLLM. Each V1-V6 item was checked in the v0.32.0 tag source.
- `notes/EMS_VMS_rev2b_agent_audit_disposition_2026-10-26.md`: every finding of the 4 agents and what was done (rev 2b).
- `gpt_audit_input/`: your two pre-GPU audit READMEs, as received.

## Files
- `notebooks/`: both notebooks, exactly as they would be pushed (sha256 in `MANIFEST.txt`).
- `builders/`: `build_ems.py`, `build_vms.py` (the notebooks are generated from these), `patch_vms_rev2.py`, `build_cpu_kit_engine.py`.
- `harness/`: the CPU harness generators and the fake servers:
  - `make_harness_ems.py` / `make_harness_vms.py` generate `harness_*_nb.py`;
  - `fake_vllm_server.py`;
  - `make_e15p_fake_server.py` / `e15p_fake_server.py` (the fake SGLang server).
- `harness_logs/`: local run logs:
  - `ems_run4.log`: 23/23 checks;
  - `vms_run2.log`: normal mode;
  - `vms_run2_bad.log`: `VMS_BAD_INT4=1`, the #58807 ignore list.
- `source_refs/`: the upstream source files we cited:
  - SGLang 0.5.21: GDN backends, attention hook, KV / mamba configurator excerpts, server_args port allocation, custom all-reduce utils;
  - vLLM v0.32.0: envs.py, config/kernel.py, arg_utils.py, qwen3_5_mtp.py.
- `redhat_int4_mtp_static.txt`: the RedHat INT4 config ignore list (MTP entries) and the mtp.* index keys.

## Please audit
0. **rev 2c patch:** is the env-gated #45151 patch (string replace of 2 anchors in the installed eagle_worker_v2.py, inert without EMS_PR45151=1) correct for 0.5.21 (`source_refs/sglang_0.5.21/srt_speculative_eagle_worker_v2.py`, `srt_managers_scheduler.py`)? Does freeing the duplicates before `init_target_memory_pool` actually raise the KV pool (empty_cache, how free memory is measured)? (be concrete: file + line, the failing scenario, the minimal fix)
1. **Oracle logic.** EMS uses target-only INT4 with no speculation; VMS uses FP8 target-only with prefix caching off. Is replacing the gate reference after the fact (judging the production reference from its own rows) correct? Any path where a missing or partial oracle silently passes an arm?
2. **The gate rule.** Both notebooks now use large-margin flips (top-1 minus top-2 logprob > 1 nat at the first divergence) vs the oracle A/A; VMS adds a degenerate-output count. EMS also records a second verdict vs the DFlash reference rows. Are the thresholds sound for greedy on different speculative paths? Recording FAIL but still measuring speed: any way a FAIL arm can be picked as "best" downstream (`_gated`, the TP2 best-MTP pick, the report)?
3. **VMS `vms_degenerate`.** Is the heuristic able to miss #53912-style output or false-alarm on normal reasoning text?
4. **VMS `vms_int4_mtp_static`.** Is the ignore-list matching (`re:` prefix, exact, prefix + ".") the same as vLLM 0.32.0 compressed-tensors `should_ignore_layer`? Are fused names (qkv_proj, gate_up_proj) handled? Is the draft built under prefix `mtp` in the v0.32.0 spec-decode path?
5. **VMS `--linear-backend marlin / triton`** on FP8 block-128 on SM 8.9: will vLLM accept these values for this layer type, or reject them at startup? Does `vms_kernels` catch the actual selection log lines of v0.32.0?
6. **EMS 2 x TP2.** Are the per-replica cache dirs (seeded copies without the CUDA driver cache), the topology-based GPU pairing, and the two nccl ports enough isolation? Is there anything else two SGLang servers on one box share?
7. **Time.** Is 200 min realistic for the planned arms, given launch + gate + windows + probe at ~10-15 min per arm? Which arms would you cut or reorder so the highest-value ones always run?
8. Any crash path in the new code (KeyError on a skipped arm, a `None` level, a missing metric) that the fake-server harness would not show.

Do not re-audit items already marked "checked and left unchanged" unless you have a concrete counter-example from the cited source.
