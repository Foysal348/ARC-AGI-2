# EVAL120 G4B runs (2026-10-24): contents of this pack

## runs/ (one folder per Kaggle commit run; all 120 eval tasks, hidden-run time share, about 6.5 h)

| Folder | Config | Notebook sha |
|---|---|---|
| `XHIGH_E16` | xhigh effort + E16 adapter (early nudge 12k + raw content) | 234d0919 |
| `XHIGH_noE16` | xhigh, base adapter rev 6g (= the submitted E14S agent/engine; LB 22.78) | 44e11cf6 |
| `LOW_E16` | low effort + E16 | f87c5488 |

Each folder holds:
- `Q27X_E12_DUCK_BUNDLE.zip`
  - `duck/<task>_b<branch>/transcript.txt`: the full agent transcript;
  - `duck/<task>_b<branch>/branch_result.json`;
  - `e12_run_report.json`, `e12_generated_attempts.json`, `submission.json`, `sglang_requests.jsonl`.
- `Q27X_E14A_BUNDLE.zip`
  - `logs/sglang_server_try0.log`: the full SGLang server log;
  - `e14/e14_results.json`, `e12_run_report.json`, `e14_state.json`.
- `e14_heartbeat.log`, `e14_results.json`, `e14_state.json`.

Key fields of `e12_run_report.json`:
- `eval_query_hits`, `eval_pass1_hits`, `eval_pass2_hits`, `eval_task_norm_pct`, `eval_unit_records` (per query);
- `branches[]` (per branch: `generated_tokens`, `status`, `runs`, `rev6_events` incl. `first_transform_tokens`, `first_check_tokens`, nudges and E16 counters);
- `e12_run` (g4b window, workers), `usage_all`, `rev6` metrics.

Note: `generated_tokens` does not count requests cut by the deadline. Use the server log for true totals.

## code/

| File | What it is |
|---|---|
| `arc2_duck.py` | The Duck adapter, rev 6g |
| `arc2_duck_e16.py` | The E16 variant (early nudge + raw content; bug-fixed version 673618ed) |
| `E14S_notebook_cells.py` | All cells of the submitted notebook (engine launch, solver, scheduler, scoring) |
| `build_e14.py` | The builder |

## data/

`arc-agi_evaluation_challenges.json` and `arc-agi_evaluation_solutions.json` (120 tasks / 172 queries).

## reference/

- `poetiq_r5_eval120/`: Poetiq R5 on the same 120 tasks (vLLM FP8, 77.8k thinking; task-norm 48.61 %), from the Experiment 10 GPT pack: README, analysis, ledger, data and per-task results. The raw run outputs are excluded for size.
- `notes/`:
  - E14 Notes 30 (R2 engine run), 31 (E14S build/commit), 34, 36 (Hybrid plan), 37 (4-day review);
  - the "kernel issue" research (mikelou1 quotes, web bugs, our-data hypotheses);
  - the LB history (`lb_history.md`).
