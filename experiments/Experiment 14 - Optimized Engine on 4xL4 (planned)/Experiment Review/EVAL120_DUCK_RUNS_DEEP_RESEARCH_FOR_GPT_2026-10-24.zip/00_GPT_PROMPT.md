# Deep-research request: why does our Qwen3.8-27B Duck agent score only ~23-30 % on ARC-AGI-2, and what is wrong inside?

You are an independent senior researcher. Read EVERY file in this zip (no sampling; the transcripts are the core
evidence). Start with `README.md`. Then do web research (GitHub issues/PRs of sgl-project/sglang and Tufalabs
duck-harness, Kaggle ARC Prize 2026 discussions, Qwen3.8 model card, ARC Prize technical reports, papers on
LLM program synthesis for ARC) where it helps explain what you see. Cite file paths/lines/json keys for our data and
URLs for external claims; mark every estimate as an estimate.

## Facts
- Kaggle ARC Prize 2026 ARC-AGI-2, 4x NVIDIA L4 24 GB, 12 h, offline, 240 hidden tasks. Model Qwen3.8-27B (RedHat
  INT4 W4A16) on SGLang 0.5.21 TP4 with DFlash2 speculative decoding (width 6), 12 agent streams.
- Agent: "Duck" REPL agent (Tufa Labs harness, our ARC-AGI-2 adapter `code/arc2_duck.py` rev 6g; E16 variant
  `code/arc2_duck_e16.py`): the model inspects grids with Python tool calls, defines `transform(grid)`, calls `check()`
  (host-verified on the training pairs), submits; stage 1 gives every task a first exposure (paused at 28k generated
  tokens), stage 2 resumes / starts branch 1 by evidence. attempt_1/attempt_2 come from the verified/harvested programs.
- Results (this zip, `runs/`): three 6.5 h runs on all 120 public eval tasks (172 test queries) with the hidden run's
  per-task time share (≈175 s per task):

| Run | Queries correct | Task-norm | attempt_2 hits |
|---|---|---|---|
| XHIGH + E16 (early nudge + raw content) | 46 / 172 | 30.0 % | 1 |
| XHIGH (= the submitted engine/agent) | 41 / 172 | 25.83 % | 0 |
| LOW effort + E16 | 31 / 172 | 18.89 % | 0 |

- Leaderboard (hidden 240): this submitted Duck (XHIGH, no E16) = **22.78**; earlier Duck rev 5 low = 17.50; our best =
  **34.58** with a different solver (Poetiq program synthesis "S1-60K": one 60k-token thinking request + code answer,
  vLLM FP8 + MTP; 31.94 on a resubmit). Poetiq R5 (77.8k thinking) on the same 120 eval tasks: 48.61 % task-norm
  (`reference/poetiq_r5_eval120/`). Top teams with the same model and hardware report 66-75 LB (methods not public;
  one said "a tiny kernel issue" cost them 40 vs 60 %).

## Questions
1. **Root causes of the low solve rate.** From the transcripts: classify every unsolved task (never wrote a transform,
   wrote but never passed train, passed train but wrong on test, ran out of time/tokens, tool or parser failures,
   loops/repetition, EOS mid-thinking, empty content). Quantify each class per run. Which class costs the most points?
2. **Agent vs model vs engine.** Is the loss mostly the agent loop (prompting, views, nudges, pause/resume, caps,
   context management), the model under INT4/DFlash/fp16-SSM serving (look for numerical-quality symptoms), or
   coverage/time? Why does a single 60k-token Poetiq request beat a multi-turn Duck agent here?
3. **Why attempt_2 ≈ 0**, and what a useful second attempt would be.
4. **E16** (early nudge): real gain or noise? Did it hurt any task?
5. **Duck vs Poetiq per task** (`reference/poetiq_r5_eval120/` has its per-task results): complementarity; what would a
   Duck stage-1 + Poetiq hybrid score on these 120 tasks (estimate)?
6. **Concrete fixes ranked by expected LB gain**, each with the evidence that motivates it and the cheapest test.
   Include fixes outside our current design if the evidence points there (e.g. different agent prompt, no pause at
   28k, larger first request cap, different tool views, image/grid formatting, a different selection rule, a
   different solver entirely).

Output: numbered sections 1-6, tables with counts, quotes from transcripts as evidence, then a ranked action list.
