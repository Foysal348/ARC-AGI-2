# Duck eval run comparison

Generated 2026-10-24 19:09 by compare_eval_runs.py. 'n/a' = field or file missing. Estimates are labelled.

- **XH-E16**: `D:\ARC AGI 2\experiments\Experiment 14 - Optimized Engine on 4xL4 (planned)\Experiment Results\Kaggle Runs\EVAL120G4B XHIGH E16 (hosen42, 2026-10-24)`
- **XH**: `D:\ARC AGI 2\experiments\Experiment 14 - Optimized Engine on 4xL4 (planned)\Experiment Results\Kaggle Runs\EVAL120G4B XHIGH noE16 (hosen42, 2026-10-24)`
- **LOW-E16**: `D:\ARC AGI 2\experiments\Experiment 14 - Optimized Engine on 4xL4 (planned)\Experiment Results\Kaggle Runs\EVAL120G4B LOW E16 (foysal, 2026-10-24)`

## 1. Run setup
|  | XH-E16 | XH | LOW-E16 |
|---|---|---|---|
| profile / run id | E14SEVAL120G4B / 20261023T235916Z | E14SEVAL120G4B / 20261023T235915Z | E14SEVAL120G4B / 20261023T235802Z |
| build variant | E14S | E14S | E14S |
| reasoning effort | xhigh | xhigh | low |
| E16 overlay | yes | no | yes |
| duck sha | 673618ed4cf3 | 758bddb5aeeb | 673618ed4cf3 |
| engine | sglang-0.5.21-int4-dflash2-w1 | sglang-0.5.21-int4-dflash2-w1 | sglang-0.5.21-int4-dflash2-w1 |
| streams / workers | 12 / 12 | 12 / 12 | 12 / 12 |
| KV tokens | 917,816 | 917,816 | 917,816 |
| engine load s | 670.1 | 688 | 717.9 |
| g4b sec/task | 175 | 175 | 174.8 |
| g4b window s | 21,003 | 20,995 | 20,971 |
| solve start s (notebook) | 713 | 730 | 777 |
| deadline in s | 21,004 | 20,995 | 20,972 |
| e14_state terminal | done (REPORT) | done (REPORT) | done (REPORT) |
| e12_run.error | none | none | none |

## 2. Score
|  | XH-E16 | XH | LOW-E16 |
|---|---|---|---|
| query hits | 46/172 | 41/172 | 31/172 |
| pass1 (attempt_1 hits) | 45 | 41 | 31 |
| pass2 (attempt_2 hits) | 1 | 0 | 0 |
| attempt_2-only hits (contribution) | 1 | 0 | 0 |
| task-norm % (report) | 30.00 | 25.83 | 18.89 |
| task-norm % (recomputed) | 30.00 | 25.83 | 18.89 |
| re-scored hits (solutions) | 46/172 | 41/172 | 31/172 |
| tasks with >= 1 hit | 37 | 32 | 25 |
| tasks fully solved | 35 | 30 | 20 |
| hit queries w/o accepted program | 16 | 7 | 5 |

- **XH-E16** solved (37): 135a2760, 136b0064, 16de56c4, 1818057f, 20270e3b*, 221dfab4, 2ba387bc, 31f7f899, 36a08778, 38007db0, 3e6067c3, 409aa875, 45a5af55, 4a21e3da, 58490d8a, 58f5dbd5, 5961cc34, 5dbc8537, 67e490f4, 7491f3cf, 7ed72f31*, 80a900e0, 898e7135, 8b9c3697, 8f215267, 8f3a5a89, 981571dc, 9aaea919, a251c730, a395ee82, aa4ec2a5, bf45cf4b, c4d067a0, cb2d8a2c, db695cfb, dd6b8c4b, eee78d87  (* = partial)
- **XH** solved (32): 135a2760, 16de56c4, 1818057f, 1ae2feb7, 247ef758*, 269e22fb, 2ba387bc, 332f06d7, 38007db0, 3e6067c3, 45a5af55, 4a21e3da, 58f5dbd5, 67e490f4, 6e453dd6, 7c66cb00, 7ed72f31, 8b9c3697, 8f215267, 981571dc, 9aaea919, a395ee82, aa4ec2a5, b0039139*, b5ca7ac4, bf45cf4b, c4d067a0, db0c5428, db695cfb, dd6b8c4b, de809cff, edb79dae  (* = partial)
- **LOW-E16** solved (25): 16de56c4*, 1818057f, 1ae2feb7*, 247ef758*, 269e22fb, 2ba387bc, 36a08778*, 38007db0, 3e6067c3, 45a5af55, 4a21e3da, 58490d8a, 58f5dbd5, 6e453dd6, 7c66cb00, 7ed72f31, 8f215267, 8f3a5a89, 9aaea919, a395ee82, aa4ec2a5, b10624e5, bf45cf4b, c4d067a0, dd6b8c4b*  (* = partial)

## 3. Coverage
|  | XH-E16 | XH | LOW-E16 |
|---|---|---|---|
| tasks | 120 | 120 | 120 |
| b0 started | 120/120 (100.0 %) | 120/120 (100.0 %) | 120/120 (100.0 %) |
| b0 finished (A/C/E) | 30/120 (25.0 %) | 36/120 (30.0 %) | 29/120 (24.2 %) |
| b0 got first exposure budget | 120/120 (100.0 %) | 120/120 (100.0 %) | 120/120 (100.0 %) |
| b1 started | 82/120 (68.3 %) | 79/120 (65.8 %) | 83/120 (69.2 %) |
| b1 started, 0 tokens counted | 3 | 3 | 0 |
| b1 finished (A/C/E) | 0/120 (0.0 %) | 0/120 (0.0 %) | 0/120 (0.0 %) |
| tasks never reached | 0 | 0 | 0 |
| branches started (found / report) | 202 / 202 | 199 / 199 | 203 / 203 |
| tasks with response (report) | 120 | 120 | 120 |
| end classes | b0:A=30, b0:M=4, b0:P=86, b1:M=3, b1:P=79 | b0:A=36, b0:M=3, b0:P=81, b1:M=4, b1:P=75 | b0:A=29, b0:M=3, b0:P=88, b1:M=1, b1:P=82 |
| branches cut by deadline (P+D+M) | 172 | 163 | 174 |
| .. paused never resumed (P) | 165 | 156 | 170 |
| .. in-flight request cut (M) | 7 | 7 | 4 |
| in-flight seconds cut (M) | 13,134.4 | 13,409 | 1,337.2 |
| window start (UTC) | 2026-10-24 00:11:10 | 2026-10-24 00:11:26 | 2026-10-24 00:10:59 |
| window planned / observed s | 21,003 / 20,998.5 | 20,995 / 20,986.2 | 20,971 / 20,939.1 |
| first exposure of last task s | 9,537.5 (e3721c99) | 9,592.6 (e3721c99) | 9,029.8 (e3721c99) |
| .. as share of window | 0.454 | 0.457 | 0.431 |
| exposure p50 / p90 s | 4,498.6 / 8,591.6 | 4,255.2 / 8,469.8 | 4,168.1 / 8,183.2 |
| tokens/task p10/p50/p90 | 26.6k / 66.7k / 87.2k | 24.0k / 68.5k / 85.8k | 22.0k / 59.7k / 81.5k |
| total generated (counted) | 7,144,122 | 7,091,227 | 6,606,525 |
| log-estimated generated (window) | 7,219,975 | 7,161,583 | 6,653,238 |
| counted / log tokens | 0.989 | 0.990 | 0.993 |
| eff tok/s (counted / observed window) | 340.2 | 337.9 | 315.5 |
| eff tok/s (counted / planned window) | 340.1 | 337.8 | 315 |

End classes: A accepted (stopped on an accepted submit), C token cap, E error, P paused never resumed, D deadline cut, M deadline cut mid-request (transcript ends in request_timeout; its tokens are not counted).

- **XH-E16** never reached (0): none
- **XH** never reached (0): none
- **LOW-E16** never reached (0): none

## 4. Behaviour
|  | XH-E16 | XH | LOW-E16 |
|---|---|---|---|
| branches started | 202 | 199 | 203 |
| ever called check() (events) | 56/202 (27.7 %) | 55/199 (27.6 %) | 69/203 (34.0 %) |
| ever called check() (transcripts) | 54/202 (26.7 %) | 56/199 (28.1 %) | 63/203 (31.0 %) |
| defined transform (transcripts) | 57/202 (28.2 %) | 55/199 (27.6 %) | 72/203 (35.5 %) |
| tool calls / branch p50 | 7.0 | 8 | 11 |
| branches with a verified program | 47/202 (23.3 %) | 46/199 (23.1 %) | 41/203 (20.2 %) |
| first transform tokens (all) | obs 30,658 (n=56/202) · naive-cens 28,681 · KM 56,412 · <=20k 14 | obs 28,469 (n=55/199) · naive-cens 24,576 · KM 71,523 · <=20k 17 | obs 24,951 (n=65/203) · naive-cens 24,820 · KM 59,456 · <=20k 26 |
| first transform tokens (b0) | obs 30,682 (n=55/120) · naive-cens 42,159 · KM 55,126 · <=20k 13 | obs 29,278 (n=52/120) · naive-cens 45,699 · KM 71,523 · <=20k 16 | obs 26,398 (n=57/120) · naive-cens 43,574.5 · KM 59,456 · <=20k 19 |
| first transform tokens (b1) | obs 11,036 (n=1/82) · naive-cens 24,576 · KM >39,559 · <=20k 1 | obs 21,241 (n=3/79) · naive-cens 24,576 · KM >24,576 · <=20k 1 | obs 8,859.5 (n=8/83) · naive-cens 16,147 · KM >36,698 · <=20k 7 |
| first check tokens (all) | obs 30,658 (n=56/202) · naive-cens 28,681 · KM 56,412 · <=20k 14 | obs 28,469 (n=55/199) · naive-cens 24,576 · KM 71,523 · <=20k 17 | obs 24,951 (n=69/203) · naive-cens 24,632 · KM 59,456 · <=20k 27 |
| first check tokens (b0) | obs 30,682 (n=55/120) · naive-cens 42,159 · KM 54,157 · <=20k 13 | obs 29,278 (n=52/120) · naive-cens 45,511.5 · KM 71,523 · <=20k 16 | obs 26,630.5 (n=60/120) · naive-cens 43,149.5 · KM 50,877 · <=20k 19 |
| nudged branches | 111 | 92 | 177 |
| nudge 24k | 21 (tok p50 26,701, seen 17, via tool:21) -> transform 10 (+8,310 tok p50), check 10, accepted 4, verified 7, task solved 7 | 92 (tok p50 27,486, seen 78, via tool:90/opener:2) -> transform 25 (+8,084 tok p50), check 25, accepted 15, verified 22, task solved 15 | 9 (tok p50 25,059, seen 6, via tool:9) -> transform 3 (+7,742 tok p50), check 3, accepted 1, verified 2, task solved 1 |
| nudge E16 early | 90 (tok p50 15,442, seen 82, via tool:89/opener:1) -> transform 36 (+16,366.5 tok p50), check 36, accepted 19, verified 31, task solved 24 | 0 | 168 (tok p50 14,159.5, seen 117, via tool:167/opener:1) -> transform 41 (+13,214 tok p50), check 44, accepted 18, verified 28, task solved 20 |
| nudge early (no reason field) | 0 | 0 | 0 |
| >= 24k, no transform, no nudge | 61 | 55 | 1 |
| e16 inspection calls hist | {"0": 63, "1": 19, "2": 3, "3": 3, "4": 6, "5": 8, "6": 11, "7": 13, "8": 16, "9": 8, "10": 5, "11": 3, "12": 5, "13": 6, "14": 5, "15": 4, "16": 5, "17": 5, "18": 1, "19": 5, "20": 1, "21": 1, "22": 3, "23": 2, "29": 1} | n/a | {"1": 4, "2": 10, "3": 10, "4": 9, "5": 28, "6": 14, "7": 15, "8": 15, "9": 6, "10": 10, "11": 5, "12": 10, "13": 12, "14": 6, "15": 6, "16": 6, "17": 10, "18": 2, "19": 4, "20": 3, "21": 4, "22": 4, "23": 3, "24": 1, "25": 1, "27": 2, "29": 1, "32": 1, "44": 1} |
| e16 raw content kept/same/mism/markup | 0/0/0/298 | n/a | 7/0/0/250 |
| raw reasoning kept/same/mism/markup | 1590/0/0/0 | 1569/0/0/0 | 2544/0/0/0 |
| length cut, no call | 98 | 82 | 10 |
| infra errors | 2 | 4 | 3 |

## 5. Engine (server log lines inside the solve window)
|  | XH-E16 | XH | LOW-E16 |
|---|---|---|---|
| log used | `Q27X_E14A_BUNDLE.zip:logs/sglang_server_try0.log` | `Q27X_E14A_BUNDLE.zip:logs/sglang_server_try0.log` | `Q27X_E14A_BUNDLE.zip:logs/sglang_server_try0.log` |
| decode / prefill lines | 4,228 / 2,534 | 4,192 / 2,589 | 3,764 / 3,915 |
| running-req histogram | 7:10 8:38 9:10 10:35 11:3571 12:564 | 7:8 8:3 9:6 10:62 11:3503 12:610 | 4:4 5:14 6:5 7:13 9:1 10:72 11:3236 12:419 |
| accept len p50 (all) | 3.85 | 3.84 | 4.00 |
| accept len p50 (running >= full-1) | 3.85 | 3.84 | 4.00 |
| gen tok/s p50 at full (= streams) | 423.2 (n=564, level 12) | 424.8 (n=610, level 12) | 389.7 (n=419, level 12) |
| gen tok/s p50 at full, clean | 434.5 | 434.9 | 445.2 |
| gen tok/s p50 at running >= full-1 | 415.3 (n=4,135) | 415.9 (n=4,113) | 416.6 (n=3,655) |
| gen tok/s p50 (all lines) | 414.5 | 415.0 | 415.5 |
| decode lines right after a prefill | 0.255 | 0.246 | 0.420 |
| prefill share (uncached prefill / (prefill + gen)) | 0.470 | 0.479 | 0.576 |
| prefill uncached / cached tokens (log) | 6,409,981 / 22,908,009 | 6,584,401 / 21,645,761 | 9,036,943 / 42,088,072 |
| cached % (log prefill) | 78.1 | 76.7 | 82.3 |
| cached % (report usage_all) | 78.2 | 76.8 | 82.4 |
| cached % branch p50 | 65.6 | 65.3 | 84.0 |
| queue max / KV usage max / mamba max | 1 / 0.47 / 0.70 | 1 / 0.49 / 0.70 | 1 / 0.52 / 0.70 |
| OOM lines (all logs / in window) | 0 | 0 | 0 |
| Traceback lines | 0 | 0 | 0 |
| Retract lines | 0 | 0 | 0 |
| CUDA/NCCL error lines | 0 | 0 | 0 |
| other *Error:/*Exception: lines | 0 | 0 | 0 |
| kernel log Tracebacks | 0 | 0 | 0 |

## 6. Per-task table
Cell = query hits/queries · b0 class/k tokens · b1 class/k tokens. '-' = not started, blank = no branch.

| task | XH-E16 | XH | LOW-E16 | solved by |
|---|---|---|---|---|
| 0934a4d8 | 0/1 · P/34k ·   | 0/1 · P/51k · P/17k | 0/1 · P/30k ·   |  |
| 135a2760 | **1/1** · P/55k · P/25k | **1/1** · P/51k ·   | 0/1 · P/47k · P/13k | XH-E16, XH |
| 136b0064 | **1/1** · A/36k · P/25k | 0/1 · P/50k · P/25k | 0/1 · P/60k · P/25k | XH-E16 |
| 13e47133 | 0/2 · P/61k · P/29k | 0/2 · P/48k · P/25k | 0/2 · P/50k · P/15k |  |
| 142ca369 | 0/2 · P/54k · P/25k | 0/2 · P/45k · P/25k | 0/2 · P/49k · P/22k |  |
| 16b78196 | 0/1 · P/52k · P/25k | 0/1 · P/44k · M/0k | 0/1 · P/53k · P/18k |  |
| 16de56c4 | **2/2** · A/43k · P/25k | **2/2** · A/28k ·   | **1/2** · A/43k ·   | XH-E16, XH, LOW-E16 |
| 1818057f | **1/1** · A/17k ·   | **1/1** · A/6k ·   | **1/1** · A/3k ·   | XH-E16, XH, LOW-E16 |
| 195c6913 | 0/2 · M/41k · M/0k | 0/2 · M/50k · M/0k | 0/2 · P/47k · P/12k |  |
| 1ae2feb7 | 0/3 · P/43k · P/12k | **3/3** · P/28k ·   | **2/3** · A/26k ·   | XH, LOW-E16 |
| 20270e3b | **1/2** · P/30k ·   | 0/2 · P/61k · P/25k | 0/2 · P/57k · P/14k | XH-E16 |
| 20a9e565 | 0/2 · P/45k · P/25k | 0/2 · P/55k · P/25k | 0/2 · P/61k · P/16k |  |
| 21897d95 | 0/2 · P/56k · P/15k | 0/2 · P/67k · P/16k | 0/2 · P/46k · P/13k |  |
| 221dfab4 | **2/2** · A/27k ·   | 0/2 · A/21k ·   | 0/2 · A/23k ·   | XH-E16 |
| 247ef758 | 0/2 · P/42k · P/25k | **1/2** · A/38k · P/25k | **1/2** · A/33k ·   | XH, LOW-E16 |
| 269e22fb | 0/2 · P/46k · P/16k | **2/2** · A/35k · P/16k | **2/2** · A/36k · P/13k | XH, LOW-E16 |
| 271d71e2 | 0/1 · P/49k · P/25k | 0/1 · P/46k · P/25k | 0/1 · P/66k · P/26k |  |
| 28a6681f | 0/1 · P/71k · P/32k | 0/1 · P/53k · P/25k | 0/1 · P/53k · P/22k |  |
| 291dc1e1 | 0/1 · P/44k · P/25k | 0/1 · P/47k · P/25k | 0/1 · P/59k · P/20k |  |
| 2b83f449 | 0/1 · P/59k · P/25k | 0/1 · P/72k · P/15k | 0/1 · P/57k · P/22k |  |
| 2ba387bc | **1/1** · A/4k ·   | **1/1** · A/13k ·   | **1/1** · A/5k ·   | XH-E16, XH, LOW-E16 |
| 2c181942 | 0/1 · P/48k · P/24k | 0/1 · P/59k · P/25k | 0/1 · P/52k · P/14k |  |
| 2d0172a1 | 0/2 · P/57k · P/13k | 0/2 · P/49k · P/25k | 0/2 · P/48k · P/13k |  |
| 31f7f899 | **1/1** · A/17k ·   | 0/1 · A/24k ·   | 0/1 · A/12k ·   | XH-E16 |
| 332f06d7 | 0/1 · P/59k · P/25k | **1/1** · A/43k ·   | 0/1 · P/52k · P/22k | XH |
| 35ab12c3 | 0/1 · P/75k · P/25k | 0/1 · P/53k · P/25k | 0/1 · P/59k · P/22k |  |
| 36a08778 | **2/2** · P/43k ·   | 0/2 · P/53k · P/25k | **1/2** · A/42k ·   | XH-E16, LOW-E16 |
| 38007db0 | **2/2** · A/20k ·   | **2/2** · A/21k ·   | **2/2** · A/16k ·   | XH-E16, XH, LOW-E16 |
| 3a25b0d8 | 0/2 · P/37k ·   | 0/2 · P/32k ·   | 0/2 · P/44k · P/19k |  |
| 3dc255db | 0/1 · P/62k · P/40k | 0/1 · P/63k · P/25k | 0/1 · A/55k ·   |  |
| 3e6067c3 | **2/2** · A/42k · P/24k | **2/2** · M/44k · M/0k | **2/2** · A/32k ·   | XH-E16, XH, LOW-E16 |
| 409aa875 | **1/1** · P/57k · P/25k | 0/1 · P/59k · P/24k | 0/1 · P/63k · P/20k | XH-E16 |
| 446ef5d2 | 0/2 · M/41k · M/0k | 0/2 · P/50k ·   | 0/2 · P/45k · P/19k |  |
| 45a5af55 | **1/1** · A/19k ·   | **1/1** · A/28k ·   | **1/1** · A/7k ·   | XH-E16, XH, LOW-E16 |
| 4a21e3da | **2/2** · A/38k ·   | **2/2** · A/42k ·   | **2/2** · A/31k · P/18k | XH-E16, XH, LOW-E16 |
| 4c3d4a41 | 0/2 · P/30k ·   | 0/2 · P/29k ·   | 0/2 · P/30k ·   |  |
| 4c416de3 | 0/1 · P/63k · P/15k | 0/1 · P/46k · P/18k | 0/1 · P/44k · P/13k |  |
| 4c7dc4dd | 0/2 · P/29k ·   | 0/2 · P/29k ·   | 0/2 · P/30k · M/7k |  |
| 4e34c42c | 0/2 · P/33k ·   | 0/2 · P/34k ·   | 0/2 · M/48k · P/19k |  |
| 53fb4810 | 0/1 · A/27k ·   | 0/1 · P/43k · P/21k | 0/1 · A/35k ·   |  |
| 5545f144 | 0/1 · P/58k · P/21k | 0/1 · P/64k · P/17k | 0/1 · P/62k · P/20k |  |
| 581f7754 | 0/2 · P/53k · P/20k | 0/2 · P/58k · P/24k | 0/2 · P/47k · P/17k |  |
| 58490d8a | **1/1** · A/13k ·   | 0/1 · A/51k · P/16k | **1/1** · A/27k ·   | XH-E16, LOW-E16 |
| 58f5dbd5 | **1/1** · A/36k · P/15k | **1/1** · A/34k ·   | **1/1** · A/22k ·   | XH-E16, XH, LOW-E16 |
| 5961cc34 | **1/1** · A/53k ·   | 0/1 · A/43k ·   | 0/1 · P/54k · P/20k | XH-E16 |
| 5dbc8537 | **2/2** · M/37k · M/0k | 0/2 · P/45k ·   | 0/2 · P/42k · P/15k | XH-E16 |
| 62593bfd | 0/2 · P/33k ·   | 0/2 · P/52k · P/25k | 0/2 · P/30k ·   |  |
| 64efde09 | 0/1 · P/58k · P/25k | 0/1 · P/75k · P/25k | 0/1 · P/42k · P/24k |  |
| 65b59efc | 0/2 · P/60k · P/25k | 0/2 · P/61k · P/25k | 0/2 · P/46k · P/13k |  |
| 67e490f4 | **1/1** · A/37k · P/25k | **1/1** · A/25k ·   | 0/1 · P/44k · P/12k | XH-E16, XH |
| 6e453dd6 | 0/1 · A/19k ·   | **1/1** · A/48k · P/25k | **1/1** · A/20k ·   | XH, LOW-E16 |
| 6e4f6532 | 0/2 · P/32k ·   | 0/2 · P/36k ·   | 0/2 · P/43k · P/13k |  |
| 6ffbe589 | 0/1 · P/50k · P/25k | 0/1 · P/51k · P/25k | 0/1 · P/46k · P/18k |  |
| 71e489b6 | 0/2 · P/59k · P/23k | 0/2 · P/43k ·   | 0/2 · P/45k · P/13k |  |
| 7491f3cf | **1/1** · A/34k · P/25k | 0/1 · P/46k · P/25k | 0/1 · P/31k ·   | XH-E16 |
| 7666fa5d | 0/1 · P/45k · P/25k | 0/1 · P/55k · P/22k | 0/1 · P/46k · P/26k |  |
| 78332cb0 | 0/2 · P/64k · P/25k | 0/2 · P/46k · P/25k | 0/2 · P/58k · P/15k |  |
| 7b0280bc | 0/1 · P/52k · P/19k | 0/1 · P/72k · P/25k | 0/1 · P/63k · P/21k |  |
| 7b3084d4 | 0/1 · P/56k · P/25k | 0/1 · P/43k · P/25k | 0/1 · P/71k · P/18k |  |
| 7b5033c1 | 0/1 · A/5k ·   | 0/1 · A/12k ·   | 0/1 · A/5k ·   |  |
| 7b80bb43 | 0/1 · P/53k · P/18k | 0/1 · P/29k ·   | 0/1 · P/46k · P/13k |  |
| 7c66cb00 | 0/1 · P/49k · P/25k | **1/1** · A/36k · P/13k | **1/1** · P/33k ·   | XH, LOW-E16 |
| 7ed72f31 | **1/2** · A/24k ·   | **2/2** · A/52k ·   | **2/2** · A/14k ·   | XH-E16, XH, LOW-E16 |
| 800d221b | 0/1 · P/41k · P/18k | 0/1 · P/46k · P/25k | 0/1 · P/42k · P/18k |  |
| 80a900e0 | **1/1** · A/40k ·   | 0/1 · P/43k ·   | 0/1 · A/27k ·   | XH-E16 |
| 8698868d | 0/1 · P/45k · P/25k | 0/1 · P/62k · P/25k | 0/1 · P/46k · P/18k |  |
| 88bcf3b4 | 0/2 · P/48k · P/25k | 0/2 · P/61k · P/25k | 0/2 · P/57k · P/34k |  |
| 88e364bc | 0/2 · P/46k · P/25k | 0/2 · P/54k · P/14k | 0/2 · P/43k · P/16k |  |
| 89565ca0 | 0/1 · A/59k ·   | 0/1 · P/48k · P/17k | 0/1 · P/56k · P/14k |  |
| 898e7135 | **1/1** · P/59k ·   | 0/1 · P/47k · P/25k | 0/1 · P/44k · P/14k | XH-E16 |
| 8b7bacbf | 0/2 · P/45k · P/15k | 0/2 · P/46k · P/25k | 0/2 · P/61k · P/13k |  |
| 8b9c3697 | **1/1** · A/39k · P/25k | **1/1** · A/49k · P/22k | 0/1 · P/49k · P/23k | XH-E16, XH |
| 8e5c0c38 | 0/2 · P/34k ·   | 0/2 · P/30k ·   | 0/2 · M/40k · P/13k |  |
| 8f215267 | **1/1** · P/29k ·   | **1/1** · A/12k ·   | **1/1** · A/15k ·   | XH-E16, XH, LOW-E16 |
| 8f3a5a89 | **1/1** · A/34k · P/20k | 0/1 · P/48k · P/25k | **1/1** · A/49k ·   | XH-E16, LOW-E16 |
| 9385bd28 | 0/2 · P/50k · P/25k | 0/2 · P/62k · P/25k | 0/2 · P/43k · P/20k |  |
| 97d7923e | 0/1 · P/50k · P/25k | 0/1 · P/52k · P/22k | 0/1 · A/35k ·   |  |
| 981571dc | **1/1** · A/27k ·   | **1/1** · A/11k ·   | 0/1 · P/56k · P/18k | XH-E16, XH |
| 9aaea919 | **1/1** · A/12k ·   | **1/1** · A/18k ·   | **1/1** · A/24k ·   | XH-E16, XH, LOW-E16 |
| 9bbf930d | 0/1 · P/41k · P/25k | 0/1 · P/58k · P/25k | 0/1 · P/45k · P/16k |  |
| a251c730 | **1/1** · A/38k · P/25k | 0/1 · P/45k · P/21k | 0/1 · P/54k · P/19k | XH-E16 |
| a25697e4 | 0/2 · P/61k · P/25k | 0/2 · P/54k · P/25k | 0/2 · P/48k · P/16k |  |
| a32d8b75 | 0/2 · P/43k · P/25k | 0/2 · M/31k · M/11k | 0/2 · P/47k · P/13k |  |
| a395ee82 | **1/1** · P/54k · P/25k | **1/1** · A/23k ·   | **1/1** · P/28k ·   | XH-E16, XH, LOW-E16 |
| a47bf94d | 0/1 · P/53k · P/25k | 0/1 · P/58k · P/25k | 0/1 · P/56k · P/13k |  |
| a6f40cea | 0/1 · P/57k · P/25k | 0/1 · P/54k · P/25k | 0/1 · P/56k ·   |  |
| aa4ec2a5 | **1/1** · A/30k ·   | **1/1** · A/15k ·   | **1/1** · A/14k ·   | XH-E16, XH, LOW-E16 |
| abc82100 | 0/2 · P/55k · P/25k | 0/2 · P/50k · P/24k | 0/2 · P/51k · P/13k |  |
| b0039139 | 0/2 · P/48k · P/25k | **1/2** · P/47k · P/25k | 0/2 · P/46k · P/18k | XH |
| b10624e5 | 0/1 · P/71k · P/25k | 0/1 · P/47k · P/25k | **1/1** · P/43k ·   | LOW-E16 |
| b5ca7ac4 | 0/1 · P/65k · P/24k | **1/1** · A/55k · P/25k | 0/1 · P/46k · P/13k | XH |
| b6f77b65 | 0/3 · P/46k · P/15k | 0/3 · P/57k · P/17k | 0/3 · P/52k · P/15k |  |
| b99e7126 | 0/1 · P/64k · P/25k | 0/1 · P/47k · P/24k | 0/1 · P/66k · P/17k |  |
| b9e38dc0 | 0/1 · P/46k · P/25k | 0/1 · P/68k · P/25k | 0/1 · P/45k · P/20k |  |
| bf45cf4b | **1/1** · A/9k ·   | **1/1** · A/13k ·   | **1/1** · A/13k ·   | XH-E16, XH, LOW-E16 |
| c4d067a0 | **1/1** · A/31k · P/25k | **1/1** · A/32k · P/25k | **1/1** · P/61k · P/17k | XH-E16, XH, LOW-E16 |
| c7f57c3e | 0/1 · P/77k · P/25k | 0/1 · P/76k · P/25k | 0/1 · P/52k · P/21k |  |
| cb2d8a2c | **2/2** · P/32k ·   | 0/2 · P/60k · P/25k | 0/2 · P/65k · P/25k | XH-E16 |
| cbebaa4b | 0/2 · P/42k ·   | 0/2 · P/28k ·   | 0/2 · M/40k · P/18k |  |
| d35bdbdc | 0/3 · P/66k · P/25k | 0/3 · P/61k · P/25k | 0/3 · A/19k ·   |  |
| d59b0160 | 0/1 · P/46k · P/25k | 0/1 · P/48k · P/25k | 0/1 · P/44k · P/19k |  |
| d8e07eb2 | 0/2 · M/38k · P/13k | 0/2 · P/38k ·   | 0/2 · P/43k · P/14k |  |
| da515329 | 0/1 · P/46k · P/19k | 0/1 · P/44k · P/20k | 0/1 · P/44k · P/16k |  |
| db0c5428 | 0/1 · P/49k · P/25k | **1/1** · A/42k · P/25k | 0/1 · P/69k · P/14k | XH |
| db695cfb | **1/1** · P/29k ·   | **1/1** · A/24k ·   | 0/1 · A/26k ·   | XH-E16, XH |
| dbff022c | 0/1 · P/61k · P/25k | 0/1 · A/46k · P/25k | 0/1 · P/67k · P/28k |  |
| dd6b8c4b | **2/2** · P/51k · P/25k | **2/2** · A/55k · P/19k | **1/2** · P/46k · P/13k | XH-E16, XH, LOW-E16 |
| de809cff | 0/1 · P/42k · P/25k | **1/1** · A/43k ·   | 0/1 · P/43k · P/14k | XH |
| dfadab01 | 0/1 · P/29k ·   | 0/1 · A/51k ·   | 0/1 · P/56k · P/20k |  |
| e12f9a14 | 0/2 · P/62k · P/25k | 0/2 · P/62k · P/25k | 0/2 · P/46k · P/17k |  |
| e3721c99 | 0/2 · P/32k ·   | 0/2 · P/29k ·   | 0/2 · P/30k ·   |  |
| e376de54 | 0/1 · A/22k ·   | 0/1 · A/17k ·   | 0/1 · P/29k ·   |  |
| e8686506 | 0/1 · P/51k · P/25k | 0/1 · P/47k · P/22k | 0/1 · P/47k · P/37k |  |
| e87109e9 | 0/1 · P/65k · P/25k | 0/1 · P/67k · P/25k | 0/1 · P/47k · P/12k |  |
| edb79dae | 0/1 · P/42k · P/25k | **1/1** · A/33k · P/25k | 0/1 · P/48k · P/16k | XH |
| eee78d87 | **1/1** · P/50k · P/25k | 0/1 · P/70k · P/25k | 0/1 · P/54k · P/24k | XH-E16 |
| f560132c | 0/2 · P/34k ·   | 0/2 · P/28k ·   | 0/2 · P/45k · P/23k |  |
| f931b4a8 | 0/2 · P/48k · P/36k | 0/2 · P/59k · P/25k | 0/2 · P/49k · P/18k |  |
| faa9f03d | 0/2 · P/77k · P/25k | 0/2 · P/57k · P/25k | 0/2 · P/48k · P/17k |  |
| fc7cae8d | 0/1 · P/46k · P/25k | 0/1 · P/51k · P/25k | 0/1 · P/43k · P/13k |  |

## 7. Union and complementarity
- union (query OR across runs): 62/172 queries, task-norm 39.58 %
- tasks with a hit in any run (49): 135a2760, 136b0064, 16de56c4, 1818057f, 1ae2feb7, 20270e3b, 221dfab4, 247ef758, 269e22fb, 2ba387bc, 31f7f899, 332f06d7, 36a08778, 38007db0, 3e6067c3, 409aa875, 45a5af55, 4a21e3da, 58490d8a, 58f5dbd5, 5961cc34, 5dbc8537, 67e490f4, 6e453dd6, 7491f3cf, 7c66cb00, 7ed72f31, 80a900e0, 898e7135, 8b9c3697, 8f215267, 8f3a5a89, 981571dc, 9aaea919, a251c730, a395ee82, aa4ec2a5, b0039139, b10624e5, b5ca7ac4, bf45cf4b, c4d067a0, cb2d8a2c, db0c5428, db695cfb, dd6b8c4b, de809cff, edb79dae, eee78d87
- tasks with a hit in every run (16): 16de56c4, 1818057f, 2ba387bc, 38007db0, 3e6067c3, 45a5af55, 4a21e3da, 58f5dbd5, 7ed72f31, 8f215267, 9aaea919, a395ee82, aa4ec2a5, bf45cf4b, c4d067a0, dd6b8c4b
- only XH-E16 (13): 136b0064, 20270e3b, 221dfab4, 31f7f899, 409aa875, 5961cc34, 5dbc8537, 7491f3cf, 80a900e0, 898e7135, a251c730, cb2d8a2c, eee78d87
- only XH (6): 332f06d7, b0039139, b5ca7ac4, db0c5428, de809cff, edb79dae
- only LOW-E16 (1): b10624e5

| pair | both | only A | only B | union | Jaccard |
|---|---|---|---|---|---|
| XH-E16 vs XH | 21 | 16: 136b0064, 20270e3b, 221dfab4, 31f7f899, 36a08778, 409aa875, 58490d8a, 5961cc34, 5dbc8537, 7491f3cf, 80a900e0, 898e7135, 8f3a5a89, a251c730, cb2d8a2c, eee78d87 | 11: 1ae2feb7, 247ef758, 269e22fb, 332f06d7, 6e453dd6, 7c66cb00, b0039139, b5ca7ac4, db0c5428, de809cff, edb79dae | 48 | 0.438 |
| XH-E16 vs LOW-E16 | 19 | 18: 135a2760, 136b0064, 20270e3b, 221dfab4, 31f7f899, 409aa875, 5961cc34, 5dbc8537, 67e490f4, 7491f3cf, 80a900e0, 898e7135, 8b9c3697, 981571dc, a251c730, cb2d8a2c, db695cfb, eee78d87 | 6: 1ae2feb7, 247ef758, 269e22fb, 6e453dd6, 7c66cb00, b10624e5 | 43 | 0.442 |
| XH vs LOW-E16 | 21 | 11: 135a2760, 332f06d7, 67e490f4, 8b9c3697, 981571dc, b0039139, b5ca7ac4, db0c5428, db695cfb, de809cff, edb79dae | 4: 36a08778, 58490d8a, 8f3a5a89, b10624e5 | 36 | 0.583 |

## 8. Projection to the hidden test (ESTIMATE)
|  | XH-E16 | XH | LOW-E16 |
|---|---|---|---|
| gate 4b window | yes | yes | yes |
| eval s/task (planned window / tasks) | 175 | 175 | 174.8 |
| hidden s/task (window / 240) | 175 | 175 | 174.8 |
| task-norm over reached tasks % | 30.00 | 25.83 | 18.89 |
| coverage (b0 started) | 1.000 | 1.000 | 1.000 |
| coverage (b0 got first-exposure budget) | 1.000 | 1.000 | 1.000 |
| hidden coverage estimate | 1.000 | 1.000 | 1.000 |
| LB proxy % (estimate) | 30.00 | 25.83 | 18.89 |

- XH-E16: gate 4b: the eval run had the hidden run's seconds per task, so its coverage is the hidden estimate; LB proxy = task-norm(reached) x coverage (= the all-task task-norm)
- XH: gate 4b: the eval run had the hidden run's seconds per task, so its coverage is the hidden estimate; LB proxy = task-norm(reached) x coverage (= the all-task task-norm)
- LOW-E16: gate 4b: the eval run had the hidden run's seconds per task, so its coverage is the hidden estimate; LB proxy = task-norm(reached) x coverage (= the all-task task-norm)
- LB is scored on 120 of the 240 hidden tasks (noise sd ~1.5 points); past LB/eval ratios were coverage-driven. The proxy is an estimate, not a prediction.

## 9. Data checks (anything that looks wrong)
**XH-E16**
- 3 branch-1 runs were started but count 0 generated tokens (their only request was cut at the deadline: in-flight tokens are not counted)
- check() callers: events 56 vs transcripts 54
- report e11.decode_summary.retract_lines = 1 but the log has no real retract line (the counter matches 'retraction_policy' in server_args)

**XH**
- 3 branch-1 runs were started but count 0 generated tokens (their only request was cut at the deadline: in-flight tokens are not counted)
- check() callers: events 55 vs transcripts 56
- report e11.decode_summary.retract_lines = 1 but the log has no real retract line (the counter matches 'retraction_policy' in server_args)

**LOW-E16**
- check() callers: events 69 vs transcripts 63
- report e11.decode_summary.retract_lines = 1 but the log has no real retract line (the counter matches 'retraction_policy' in server_args)

