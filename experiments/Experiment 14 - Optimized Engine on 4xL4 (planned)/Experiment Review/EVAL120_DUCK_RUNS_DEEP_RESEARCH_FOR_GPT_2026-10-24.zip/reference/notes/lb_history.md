# Our ARC-AGI-2 leaderboard history (public LB, hidden 240 tasks; noise sd about 1.5)

| Date | Submission | LB |
|---|---|---|
| 10-12 | v1.4.4 vLLM FP8+MTP plain reasoning (49k) | 26.94 |
| 10-14 | E7 ORDERING_ONLY v2 | 27.92 |
| 10-15 | E9 86k plain reasoning | 22.92 |
| 10-16 | E10 Poetiq R5 (77.8k) | 21.39 |
| 10-17 | **E10 S1-60K Poetiq (vLLM FP8+MTP3, 60k)** | **34.58** |
| 10-17 | S49 (S1 with 49,152 thinking) | 32.08 |
| 10-18 | E11-06 P1-60K (SGLang INT4+DFlash2, P1 prompts) | 29.17 |
| 10-19 | S1-55K | 31.81 |
| 10-20 | E12 Duck rev 5, low effort, 6 streams | 17.50 |
| 10-22 | S1-60K resubmit (version 3) | 31.94 |
| 10-23 | **E14S Duck rev 6g, xhigh, SGLang INT4 + DFlash2 W6 + graphs 1..13, 12 streams (11 really running)** | **22.78** |

Baseline NVARC (ensemble, non-LLM): 32.64. Top teams with Qwen3.8-27B on 4xL4 report 66-75.
