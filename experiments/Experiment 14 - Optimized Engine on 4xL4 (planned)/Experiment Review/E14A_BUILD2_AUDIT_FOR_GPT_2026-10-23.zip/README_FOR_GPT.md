# E14-A audit bundle, build 2: corrections after GPT audits 17-19 (2026-10-23)

**Please audit before any GPU run.** Nothing has been pushed to Kaggle. This is a CPU-tested build.

- **This is build 2 of E14-A.** Build 1 (`a9dad9fcbe0003867d34f205732a23106dbfed30380535ef4531ba78806de494`) got three independent audits: `notes/17`, `notes/18` and `notes/19` (verbatim). All three said NO-GO for that sha.
- We checked every claim against our code and the SGLang 0.5.21 source (`notes/20`). Every finding was true; none was false. Audit 2's staging collision was a real P0: it would have broken the GPU run at launch.
- **Notebook sha256:** `a5318ddab1ee692535a7417c9452f9e758c4fb3c290b668cd8c1b0ca0a54c6ea`
- **Tests:** unit tests 165/165 in three consecutive runs (logs/unit_tests_run1..3.txt); notebook harness 31/31 in both scenarios, default and corrupt (logs/harness_default.log, logs/harness_corrupt.log)
- **Scope the user approved:**
  - category A = the must-fix set (A-M1 to A-M6 below);
  - category B = the NCCL arm in the gate, a fresh relaunch of the kept arm before the Duck run (with a flush fallback and reply classification), graphs13 fail-closed;
  - category C = deferred (listed with reasons in §6.2).
- **Label warning:** "A-M1 … A-M6" are our plan items (Notes/20 §5). Audit 18 has its own "M1 … M6" with a different order (its M5 = the per-arm gate, its M6 = matched A2 controls). In §3, audit labels are always the audit's own.

## 0. What this is

- **Competition:** Kaggle ARC Prize 2026 / ARC-AGI-2. Hardware: 4× NVIDIA L4 (24 GB, PCIe, no NVLink), offline, a 12 h limit, 240 hidden tasks.
- **Model / engine:** Qwen3.8-27B RedHat INT4 W4A16 + BF16 DFlash2 drafter (block 8) on SGLang 0.5.21, TP4. Called "W1":
  - KV fp8_e4m3, SSM fp16;
  - mamba radix strategy `extra_buffer_lazy`, mamba cache 56;
  - mem fraction 0.83, chunked prefill 4096;
  - server `--max-running-requests 13`, client 12 streams;
  - CUDA-graph decode bs [1..8, 10, 12].
- **Goal of E14-A:** one commit-mode notebook that measures engine levers and adopts only those that pass a correctness gate and a speed rule. A 25-minute Duck-agent run (rev 6g solver, 12 G4B eval tasks) then runs on the adopted ("kept") arm. More arms run after it (A2); they never change the submission.
- **Base:** `build_e14.py` executes the E12 rev 6g G4B builder (`build_e12_duck.py`) in memory and patches cells. Nothing in the E12 folders is written.

**Notebook:** `notebook/Q27-XHIGH-E14A_OPTIMIZED_ENGINE_SGLANG.ipynb`, sha256 `a5318ddab1ee692535a7417c9452f9e758c4fb3c290b668cd8c1b0ca0a54c6ea`.

Embedded modules (sha256 prefix; CELL 1b asserts the full sha at run time):

| Module | sha | Build 2 |
|---|---|---|
| `e14_loadpath.py` | 7c66c179 | changed (A-M1) |
| `e14_measure.py` | 68eb69e3 | changed (A-M2, A-M3, A-M5, A-M6, speed validity, round-2 review) |
| `e14_sglang_patches.py` | 98da9521 | unchanged |
| `e14_nccl_bench.py` | 355adda0 | changed (A-M4, round-2 R10) |
| `e14_trace_summary.py` | 8d89ca10 | unchanged |
| Duck adapter `arc2_duck.py` | 758bddb5 | unchanged (rev 6g + E14-P switch) |

- The other 22 Duck package files are embedded by the E12 builder with their own manifest check.
- The notebook is self-contained. The builders are included for reading, but they also need the E11 source notebook and the Duck vendor package (not in this zip, large and unchanged). **Audit the notebook cells directly.**
- Bundle layout (as in build 1): `notebook/`, `build/`, `src/` (modules + tests; new: `src/test_e14_measure.py`), `src/harness/`, `duck_arc2/`, `notes/` (new: 17-20), `logs/`, `sglang_0_5_21_excerpts/`.

## 1. Cell map (E14A profile)

| Cell | What |
|---|---|
| CELL 0 | Mode + fallback `submission.json` (unchanged). |
| CELL 1 | Config. Profile **E14A**: 12 tasks, `time_budget_sec` 200 min (hard stop ≈ 198 min), `solve_window_sec` 25 min, `e14: True` (unchanged). |
| CELL 1b | Module extraction + sha check, phase record (`e14_state.json`), heartbeat, first-line facts, model staging to `/dev/shm` (fallback `/tmp`) with ranged parallel readers. **Build 2:** each model gets its own staged dir (A-M1). |
| CELL 2 | Single-stream `cat` prefetch only when staging is off (unchanged). |
| CELL 4 | Package / tokenizer checks (unchanged). |
| CELL 5 | Engine launch, stall watchdog, NCCL bench while the copy runs (unchanged). |
| CELL 5b A1 | **Rewritten.** Duck reserve set first (A-M2). W1 baseline phase (8k / ~40k windows, profiler window, latch test) → E14-P token replay → greedy parity (serial ×2, 12-at-once ×2 = the gate reference) → **#44401/#41872 arm** → **nodelay arm** (`--min-free-slots-delay 1`) → **CUDA graphs 1..13 arm**. Each arm: launch on top of the kept arm → **correctness gate first** → windows + latch only if the gate passed → a decision with every condition recorded. Then a **fresh forced launch of the kept arm** for the Duck run (flush only as a fallback). |
| CELL 6 | Duck rev 6g run, 25 min, 12 workers, KV-only admission gate 0.95 (unchanged; its window starts when CELL 6 starts). |
| CELL 7 | E12 report (unchanged). |
| CELL 6b A2 | **Rewritten.** Launch of the Duck arm → **A2-0 matched reference** (greedy rows on this launch) → agent-like replay + cache-hit parity → int8 Mamba checkpoints (cross-arm gate + replay + cache-hit parity) → target-only (gate + window) → width 6 and 4 (gate first, then window) → NCCL env arm if the bench found one (gate first, then window). |
| CELL 7b | JIT manifest + cache tar (save only), `e14_report.md` (now with the A1 reserve, the clean-start record, the Duck window and the Duck arm), bundle zip. |

- Each phase has its own cap. In A1 the cap is also cut so the phase ends before the Duck reserve (A-M2). Whatever does not fit is skipped and recorded, never squeezed.
- Phase caps (minutes): A1-2 baseline 15, A1-3 replay 8, A1-4 parity 12, A1-5 #44401 14, A1-5b nodelay 14, A1-6 graphs13 12 (A1 total 75; build 1: 69). A2-0 reference 8, A2-1 replay 14, A2-2 int8 16, A2-3 target-only 14, A2-4/5 width 12 each, A2-6 NCCL 12 (A2 total 88; build 1: 66).

## 2. Fix list (build 2)

### 2.1 Category A (must-fix, approved)

| # | Fix | Where |
|---|---|---|
| A-M1 | **Staging collision.** Staged dir name = `m<i>-<parent dir>-<basename>-<sha1(source path)[:10]>`, e.g. `m0-w4a16-g128-1-…` and `m1-bf16-1-…` (build 1 used the basename, `1` for both). `stage_models` refuses equal names or the same source twice (then warms in place and launches from the sources), and raises if a published dir already appears in the path map. | `e14_loadpath.staged_name`, `parallel_copy(name=)`, `stage_models` |
| A-M2 | **Duck reserve.** `E14_RESERVE` = solve window 1,500 + solver stop margin 180 + preflight 300 + final artifacts 600 + one cold relaunch 400 = **2,980 s**, recorded as `a1_reserve`. An A1 phase runs only if `HARD_STOP − now − 480 − reserve ≥ 120 s`, and its cap is cut to that (`phase_budget`). An A1 relaunch starts only if `HARD_STOP − now ≥ reserve + 400 + 480 + 120 = 3,980 s` (`launch_allowed`). Forced launches (kept-arm restores, the Duck launch) keep only the 15-min floor. The Duck record `duck_window` = {planned_sec, available_sec, status `full` / `solver_window_unavailable`}. | `e14_measure.phase_budget`, `launch_allowed`; CELL 5b `_rs`, `e14_phase`, `e14_launch` |
| A-M3 | **Deadlines and cleanup.** `post_json` raises `TimeoutError` when the phase deadline has passed and never sends; timeout = min(given, left), no 5 s floor. `/abort_request` calls use `cleanup=True` (own ≤ 10 s bound). `cleanup()` = parallel aborts (8 s) + one shared join budget + a `/metrics` idle check, all inside `CLEANUP_SEC` = 20 s; used by `steady_window`, `parity_pass`, `latch_test`. `agent_replay` joins within left + 20 s, then checks idle. Serial `parity_pass` keeps skipped prompts in place as error rows (index-aligned). A not-idle server marks the phase (`server_not_idle_after`) and sets `E14_DIRTY`; the next phase that has budget first relaunches the current arm (not forced, R4) and is skipped if that fails. | `e14_measure.post_json`, `abort`, `join_all`, `server_idle`, `cleanup`, `parity_pass`, `agent_replay`; CELL 5b `_e14_dirty`, `e14_phase` |
| A-M4 | **NCCL bench.** An arm is a candidate only with `status == "ok"`, eager `correct is True`, `graph_correct is True` and a per-call time. | `e14_nccl_bench.build_summary` |
| A-M5 | **Correctness gate, fail closed, revert path.** `compare_passes`: per prompt, index-aligned (a missing row is an error), optional truncation to n tokens, both runs' top-1/top-2 margins at the first divergence, `missing_margin`, large-margin flip = max(margin_a, margin_b) > 1 nat. `parity_ok`: INCOMPLETE unless every planned prompt was compared in both arm and control with equal counts and no missing margin; arm flips ≤ A/A flips; identity mode `require` / `if_known` / `ignore` (D1). `arm_gate`: serial 6 prompts × 256 tokens + all 12 at once × 256, compared with the reference rows and judged against the reference's own A/A; a dirty server, a missing reference or < 120 s left = no adoption. Every A1 arm (#44401, nodelay, graphs13) runs it **first** (identity not required across a restart, R1); A2 arms run it against the A2 reference. A rejected arm leaves `E14_KEPT` unchanged; a rejected #44401 is reverted on disk (`E14P.revert`). | `e14_measure.compare_passes`, `parity_ok`, `gate_reference`, `arm_gate`; CELL 5b `_arm_windows`, `e14_decide`; CELL 6b `_gate`, `_gated` |
| A-M6 | **Latch at the client level 12.** `latch_test(level=12)` returns `share_running_ge_level` (running ≥ 12), `share_stuck_below_queued` (running = 11 with queue ≥ 1), `running_max`, `queue_drain_sec`, `retracted_delta` (from `sglang:num_retracted_requests_total`); `share_at_target` / `share_stuck_one_below` (13-based) stay as diagnostics. `latch_gain`: one share improves by ≥ 0.10 and the other does not get worse, retractions do not rise; equal numbers are never a gain. #44401 and nodelay need `latch_gain` + `adopt_speed(occupancy=True)`. | `e14_measure.latch_test`, `Sampler`, `latch_gain`; CELL 5b |

### 2.2 Category B (approved)

| # | Fix | Where |
|---|---|---|
| B1 | **NCCL env arm gated.** Launched only if the bench's `adopt_candidate` (≥ 20 % faster per call at 983,040 B, eager and graph results correct); adopted only with the gate (identity ignored), ≥ +5 % in the 12-stream window and no blocking log signs. Gate first, window only after a pass. | CELL 6b A2-6 |
| B2 | **Clean Duck start.** The Duck run starts on a fresh forced launch `duck_<kept arm>`. Only if that launch fails: `server_idle(wait=30)`, then `/flush_cache`, reply classified (`Cache flushed` prefix = ok; 0.5.21 answers HTTP 400 on failure, `urlopen` raises, recorded as `error: …`, ok false). Record `duck_clean_start` = {method, ok, idle_before, reply, arm, cold_start_unverified = not ok, kept_arm_running}. The Duck run always runs. | CELL 5b end |
| B3 | **graphs13 fails closed.** Adopted only if the server log's captured verify-graph list was parsed and holds 12 and 13 (build 1 let speed decide on an unparsed list). | CELL 5b |

### 2.3 Also in this build

| # | Change | Where |
|---|---|---|
| X1 | **Speed rule validity.** `adopt_speed` is INCONCLUSIVE (no adoption) on a missing / errored / skipped window, < 8 decode lines, a server not idle after the window, a different measured running level (unless `occupancy=True`, labelled "occupancy gain 11 -> 12 running"), or per-request context off by > 25 %. | `e14_measure.adopt_speed` |
| X2 | **Window metadata + profiler label.** Each window record carries `measured_level`, `real_running_reached`, `ctx_per_req_p50`, `window_sec`, `real_running_share`, `lines`, `cleanup`. The profiler window carries `diagnostic_only` (its timed loop starts after `profile_steps` returns) and is never a speed reference. | `e14_measure.steady_window` |
| X3 | **A2 matched reference.** A2-0 on the A2 base launch (the arm the Duck ran): serial 6 × 256 twice + 12 × 256 at once twice. int8 (cross-arm), target-only, width 6 / 4 and NCCL gates compare with it. Width decisions add `accept_p50 ≤ width`. | CELL 6b `_a2_reference` |
| X4 | **Kept arm.** `E14_KEPT` (+ `E14_KEPT_WIN`, its windows) replaces `E14_GOOD`. Every arm launch builds on it; a failed forced launch relaunches `kept_<name>` (R5); the Duck launches it. Bug fix, D5. | CELL 5b/6b helpers (`c_meas_common`) |
| X5 | **Fewer relaunches.** `W1_back`, `nodelay_back`, `duck_cfg` removed (D6). | CELL 5b |
| X6 | **Gate first.** In every A1 arm phase and in the A2 width / NCCL phases the gate runs first and the windows only after a pass; `e14_decide` lists the gate right after the launch condition (D7). | CELL 5b `_arm_windows`, CELL 6b `_gated` |
| X7 | **Blocking log signs.** Six substrings are counted per phase; four block an adoption: "runs out of memory", "Not enough space", "out of memory", "Traceback" (D12). Labelled as a substring diagnostic, not a classifier. | `e14_measure.log_errors`; CELL 5b `e14_phase` |
| X8 | **Fake server + harness.** The fake models the 0.5.21 DFlash min-free-slots delayer (W1 runs 11 of 12), a real waiting queue, the retraction counter (always 0), a `corrupt` mode, and a busy-refusing `/flush_cache`. Harness fixtures copy the real Kaggle path shape; two scenarios (`default`, `corrupt`). | `src/harness/e14_fake_server.py`, `harness_e14_nb.py` |

### 2.5 Round 2: an independent code review before zipping (24 findings) — what changed

A separate reviewer read the build-2 code before this bundle was made. Every finding was checked; the table gives
the action for each one.

| # | Finding (severity) | Action in this build |
|---|---|---|
| R1 | **A1 gate demanded bs-1 identity across a server restart** (wrong decision, high). DFlash2 greedy output is byte-identical within one process but can differ across restarts, accept length swings per boot (SGLang #38009, our research notes). Every A1 arm is a new process, so honest arms (nodelay, #44401, graphs13) would likely fail; with gate-first their windows would not even run. The fake server is deterministic across launches, so the harness could not show it. | **Fixed:** A1 gates use `identity=False` — large-margin flips vs the W1 A/A decide (a corrupt arm still fails: 2.4-nat flips); identity is recorded only. D1 updated. |
| R2 | `dflash_contamination` used identity `if_known` although serial vs 12-at-once differs by batching alone (diagnostic only) | **Fixed:** `identity="ignore"`. |
| R3 | A non-forced arm launch could wait up to 20 min, into the Duck reserve | **Fixed:** the wait is capped at `HARD_STOP − now − reserve − 8 min` for non-forced launches. §9.4 updated. |
| R4 | The dirty-server relaunch ran before the budget check, forced (could eat the reserve, and was wasted when the phase was then skipped) | **Fixed:** budget first; relaunch only if the phase will run, never forced. |
| R5 | A failed arm launch triggered an immediate forced kept-arm relaunch although the next step is another launch | **Fixed:** the kept-arm restore runs only after a failed forced launch (the Duck launch or a `_clean`). §9.9 removed. |
| R6 | The Duck could run on a rejected arm in failure paths, and A2 built on whatever the Duck ran on | **Fixed in part:** A2 builds on `E14_KEPT`; the clean-start record says what really ran (`kept_arm_running`, method incl. "kept arm after a failed Duck launch", `server_reachable_and_idle`). With < 15 min left no relaunch is possible; that case is recorded, not prevented. |
| R7 | #41872 could stay patched without being measured (when #44401 was refused), and the revert result was never checked | **Fixed:** every applied hunk that is not adopted is reverted; `patch_state` records an unconfirmed revert; the harness requires `patches_reverted.ok`. |
| R8 | Speed rule compared tok/s across boots although accept length swings per boot; graphs13 could still adopt on noise | **Fixed in part:** `adopt_speed(per_step=True)` compares steps/s (tok/s ÷ accept) for arms that do not touch the drafter (#44401, nodelay, graphs13, NCCL); widths keep tok/s (accept is their cost). graphs13 keeps the 2 % no-loss tolerance (no gain required). |
| R9 | int8 "cold" pass was not cold (prompts already cached on that launch) | **Fixed:** `flush_cache()` before every `_cold` pass. |
| R10 | NCCL: a timed-out or graph-wrong baseline could still be the reference | **Fixed:** the baseline comes from the valid candidates only; new unit test. |
| R11 | `latch_gain` ignored latch validity | **Fixed:** no gain unless both latches reached their decodes, have samples and a clean server; new unit test. |
| R12 | A dirty A1-4 reference was invisible and would feed every gate | **Fixed:** A1-4 records `server_not_idle`; a dirty reference is set to None (every A1 gate INCOMPLETE, the Duck runs on W1). |
| R13 | `e14_prompts()` and the sglang path probe could raise at module level | **Fixed:** both wrapped; an error is recorded and the arms fail closed; the Duck still runs. |
| R14 | Gate-first made the arm's windows start with a warm cache vs W1's cold windows (context / speed bias) | **Fixed:** `flush_cache()` between the gate and the windows (`flush_after_gate` recorded). |
| R15 | Profiler summary parses traces with no deadline (pre-existing) | **Not changed:** the trace is 20 steps; noted. |
| R16 | `duck_window.status` ignored the CELL 6 preflight | **Fixed:** "full" needs window + 300 s. |
| R17 | int8 decision listed the gate third | **Fixed:** gate second; int8 and target-only now also run through `_gated` (windows / replay only after a pass). |
| R18 | "launched and measured" was true for a phase that raised | **Fixed:** an error dict is not "measured". |
| R19 | `queue_drain_sec` took the first empty-queue sample, often before the arrivals queued | **Fixed:** first empty-queue sample after the queue was > 0. |
| R20 | The warm request of a window was never cleaned up | **Fixed:** included in the window's cleanup. |
| R21 | Leftovers (`E14_PAR_D`, `_clean_clean` names, the flush record when the kept restore succeeded) | **Fixed.** |
| R22 | The hung-request unit test was timing-fragile (unlocked counters, backlog 5, fixed sleep) | **Fixed:** lock, `request_queue_size` 64, poll until all 14 hang. |
| R23 | Harness coverage gaps (deterministic fake hides R1; flush fallback, late start, dirty relaunch, failed launch not exercised; weak revert / gate checks) | **Fixed in part:** fake flush now answers 400 like 0.5.21; unit tests for a refused flush and for a flush after the deadline; harness requires the revert `ok` and a real gate verdict for every arm. Not exercised in the harness: flush fallback, late start, dirty relaunch, failed launch (§9). |
| R24 | #44401 is a near-certain reject under the delayer (costs a launch + up to 14 min) | **Kept** as an arm (user decision); with gate-first + R5 a reject costs the gate and windows only. §11 Q4. |

### 2.4 Unchanged in build 2

- `e14_sglang_patches.py`, `e14_trace_summary.py`, the rev 6g solver and the Duck package.
- Already in the E12 rev 6g solver (grep markers in `duck_arc2/arc2_duck.py`): per-request deadline clamp; verify budget clamp; one join cutoff (`join_until`); deep-copied records; three-state isolation (`isolation_state`); KV-only admission (`kv_admit_limit`) on exact `sglang:full_token_usage`; regex length guard (`_GRID_ROW_MAX`); nudge in the tool result (`harness_note`); raw-reasoning switch (E14-P).

## 3. Item-by-item response to audits 17, 18 and 19

**Status values:** FIXED = in this build; FIXED partly = what remains is named; DEFERRED (C) = category C, reason given (more in §6.2); NOT TAKEN = deliberately not done, reason given; NOT DONE = planned in Notes/20 but not in this build; NO ACTION = informational or agreed.

**Where:** `M.` = `src/e14_measure.py`, `L.` = `src/e14_loadpath.py`, `B.` = `src/e14_nccl_bench.py`, 5b / 6b / 7b = CELL 5b / 6b / 7b (builder strings `c_meas1` / `c_meas2` / `c_rep2`; shared helpers in `c_meas_common`), tests in `src/test_e14_*.py`, harness in `src/harness/`.

### 3.1 Audit 17 (Notes/17)

| ID | Item | Status | Where |
|---|---|---|---|
| 17 §1 | Zip / notebook sha verified; recorded logs | NO ACTION (informational) | — |
| 17 §1 | Linux rerun: `test_mounts_longest_prefix` fails (patches `os.name = "nt"`); 125/125 not independently reproduced | DEFERRED (C, portable tests): not a runtime path; the test still patches `os.name` | `test_e14_loadpath.py`: `test_mounts_longest_prefix`, `test_meminfo_and_env_report` |
| 17 HIGH-1 | Counterexample A: arm 0/12 and A/A 0/12 identical, no flips → PASS | NOT TAKEN as asked (round 2, R1): every gate compares across a server restart, where DFlash2 identity is not stable (#38009), so flips vs the A/A decide; completeness and both margins are required. INCONCLUSIVE on 0 identical exists only in `require` mode (unit-tested, unused) (D1) | `M.parity_ok`, `M.arm_gate`; `test_gate_unstable_aa_zero_identical_is_inconclusive_when_identity_required`, `test_gate_counterexamples_from_the_audits_no_longer_pass` |
| 17 HIGH-1 | Counterexample B: compared = 1 → PASS | FIXED: every planned prompt must be compared in arm and control, equal counts, else INCOMPLETE | `M.compare_passes`, `M.parity_ok`; `test_gate_missing_requests_fail_closed` |
| 17 HIGH-1 | A missing margin counts as "no flip" | FIXED: a divergence without both margins = `missing_margin`; any → INCOMPLETE | `M.compare_passes`, `M.parity_ok`; `test_gate_missing_margins_fail_closed` |
| 17 HIGH-1 fix | Inspect baseline and candidate margins | FIXED: `margin_a`, `margin_b`; flip = max > 1 nat | `M.compare_passes` |
| 17 HIGH-1 fix | Unstable A/A → INCONCLUSIVE, not PASS | NOT TAKEN for the notebook gates (R1, D1); implemented in `require` mode only | `M.parity_ok` |
| 17 HIGH-1 fix | Use the top-logprob evidence at the first significant disagreement | FIXED: margins at the first divergence position | `M.compare_passes` |
| 17 HIGH-1 fix | No adoption on an incomplete sample (12/12 required) | FIXED: INCOMPLETE → no adoption; skipped serial prompts stay as error rows | `M.parity_pass`, `M.parity_ok` |
| 17 HIGH-1 tests | Stable A/A; unstable A/A 0/12; missing margins; missing requests; large-margin flip; low-margin benign divergence; not only successful fake replies | FIXED: one unit test each (§8.1) + the faster-but-wrong fake arm (harness `corrupt`) | `test_e14_measure.py`; harness |
| 17 HIGH-1 | #44401 / nodelay / graphs13 adopted on speed + latch only; the README's "correctness gate" claim was not true | FIXED: `arm_gate` runs first in each arm phase; decisions list it right after the launch condition. Reference = W1's A1-4 rows, not the last kept arm (D3) | 5b `_arm_windows`, `e14_decide` |
| 17 HIGH-2 | A1 does not reserve the 25-min Duck run | FIXED partly: A1 phases and A1 relaunch admission keep 2,980 s. Remains: an admitted relaunch waits up to `SGL_RELAUNCH_TIMEOUT_SEC` (20 min), not capped by the reserve; forced restore relaunches ignore the reserve (§9.4) | 5b `_rs`, `e14_phase`, `e14_launch`; `M.phase_budget`, `M.launch_allowed` |
| 17 HIGH-2 | Skip A1 relaunches near the end of A1, not only at HARD_STOP − 15 min | FIXED: needs 3,980 s before HARD_STOP | `M.launch_allowed` |
| 17 HIGH-2 | No reserve in A2 | FIXED: `E14_RESERVE = 0` for the Duck launch and in CELL 6b | 5b end, 6b |
| 17 HIGH-2 test | Fake monotonic clock: early / medium / late startup | FIXED as unit tests (4 clock cases + the launch rule); no notebook-level late start (§9.5) | `test_phase_budget_keeps_the_duck_reserve`, `test_launch_allowed_respects_reserve_unless_forced` |
| 17 HIGH-3 | `post_json` sends after the deadline (5 s floor) | FIXED | `M.post_json`; `test_post_json_past_deadline_sends_nothing`, `test_post_json_timeout_never_exceeds_the_deadline` |
| 17 HIGH-3 | A separate bounded grace for cleanup requests | FIXED: `cleanup=True` (only `/abort_request`), ≤ 10 s | `M.post_json`, `M._abort_one` |
| 17 HIGH-3 | Concurrent bounded aborts → active-request check → controlled server termination; one global cleanup deadline | FIXED: parallel aborts, one join budget, idle check, 20 s total; not idle → forced relaunch before the next phase | `M.abort`, `M.join_all`, `M.server_idle`, `M.cleanup`; 5b `e14_phase` |
| 17 HIGH-3 tests | Deadline before the call; during the response; 12 outstanding; abort error; server shutdown fallback; final hard-stop boundary | FIXED partly: the first four as unit tests (14 hung requests, aborts that time out). Hard-stop boundary only via `launch_allowed` (never in the last 15 min) and `phase_budget` (too late → None). The notebook's dirty → relaunch path has no test (§9.6) | `test_e14_measure.py` |
| 17 HIGH-4 | `/flush_cache` failure not told from success | FIXED: fresh forced relaunch of the kept arm first; `/flush_cache` only if that fails, reply classified (B2) | 5b end `duck_clean_start` |
| 17 HIGH-4 | Bounded wait for running = queued = 0 before the flush | FIXED (fallback path): `server_idle(wait=30)` → `idle_before` | 5b end |
| 17 HIGH-4 | On failure relaunch the adopted arm once if time allows; else run the Duck and mark the cold-cache comparison invalid; never fail the notebook | FIXED in a different order: relaunch first, flush as fallback (D4); `cold_start_unverified`; the Duck always runs | 5b end |
| 17 HIGH-4 | A successful flush clearing all Mamba state under `extra_buffer_lazy` is unproven | NO ACTION in code: the normal path is a new server process (empty radix and Mamba state by construction); the flush path is GPU-only (§7) | — |
| 17 MEDIUM, §5 | Latch targets 13, misses 11 + queue; a good nodelay arm could be rejected | FIXED: primary metrics at level 12; 13-based shares kept as diagnostics | `M.latch_test` |
| 17 §5 | Adopt when the 12-share rises, 11 + queue falls, errors / retractions do not rise, matched-context throughput is not lost | FIXED with one difference (D8): one share must improve by ≥ 0.10 and the other must not get worse; plus `log_errors` and `adopt_speed` (context ±25 %, occupancy label) | `M.latch_gain`, `M.log_errors`, `M.adopt_speed`; 5b |
| 17 §5 | "running ≥ 12 and queue ≥ 1" as the only metric | NOT TAKEN (the audit advised against using it alone; not used) | — |
| 17 MEDIUM, §6.2 | int8: only cold vs cached within each arm | FIXED: cross-arm gate (int8 vs the A2 reference, same ids); cache-hit parity kept. int8's own A/A: DEFERRED (C) | 6b `A2-2_int8_mamba` |
| 17 MEDIUM, §6.1 | Speed rule ignores running level and context | FIXED (X1) | `M.adopt_speed`; 5 negative tests |
| 17 §6.1 | Mandatory per-window metadata | FIXED (X2); full records in `e14_windows.jsonl` / `e14_results.json` (`e14_report.md` truncates long lines) | `M.steady_window` |
| 17 §6.1 | Treat the nodelay 11 → 12 transition separately | FIXED: `occupancy=True` for #44401 and nodelay, labelled | `M.adopt_speed`; 5b |
| 17 LOW, §12 | Staging keeps reading after the launch falls back | DEFERRED (C): no stop event | `L.Staging`; CELL 1b `e14_after_install` |
| 17 §8 | A restored JIT cache still needs a known-answer check | DEFERRED (C): this run only saves the cache; `restore_jit_cache` + `known_answer_ok` exist and are unit-tested, no cell calls them | `L.restore_jit_cache`, `L.known_answer_ok`; 7b |
| 17 §8 | Duck window start shift present, 25-min reservation missing | FIXED partly (= HIGH-2) | 5b |
| 17 §8 | Delayer latch interpretation needs repair | FIXED (= §5) | `M.latch_test`, `M.latch_gain` |
| 17 §8 | Relaunch skip near HARD_STOP present, Duck reserve not protected | FIXED partly (= HIGH-2) | `M.launch_allowed` |
| 17 §8 | Token-id fields; null `cached_tokens`; KV pool per relaunch; two KV gates; no vLLM fallback; stale `.pyc`; no penalties / ReplaySSM / PCIe-IPC | NO ACTION (agreed) | — |
| 17 §9 | Build-1 omissions 1-3 and 5 (long parity probes, 60k band, cosmetic DIRECT fields, mamba 64 / mrr 14) | NO ACTION (accepted) | — |
| 17 §9 | Frozen rev 6g: keep a final record-integrity regression and a sha check | FIXED partly: sha checks run (CELL 1b asserts each E14 module; the E12 cells check the Duck package manifest; `arc2_duck.py` unchanged). Record-integrity regression: DEFERRED (C) | CELL 1b; E12 package cell |
| 17 Q1 | Phase invalid / budget overrun: `post_json`, Duck reserve, incomplete parity, unclassified flush | see HIGH-1 to HIGH-4 | — |
| 17 Q2 | Latch rule: primary 12, separate 11 + queue, time at 12 under a queue | see §5 rows | — |
| 17 Q3 | Log the flush reply + zero running/queued + a later cold-prefix cache observation | FIXED partly: relaunch record, or `idle_before` + `reply` + `ok` on the fallback. Cold-prefix observation of the first Duck requests: NOT DONE (§9.14) | 5b end |
| 17 Q4 | Allowance 2 + 0 large-margin flips is not sound as built | see HIGH-1, D1, D2 | — |
| 17 Q5 | Width: check the effective resolved width at server start | DEFERRED (C): flags, caps (`kv_tokens`, `mamba_cache_size`, `verify_graph_bs`, `avail_mem_gb_last`) and the server log are recorded; no resolved-width parse | `e11_caps` (CELL 5) |
| 17 Q5 | Width: first draft-position behaviour and acceptance distribution | DEFERRED (C): `accept_p50` per window only | `M.window_stats` |
| 17 Q5 | Width: target-only and width-8 comparison | FIXED: A2-0 matched width-8 reference; target-only and widths gated against it | 6b |
| 17 Q5 | Width: tool-call / correctness parity | FIXED partly: greedy-token gate (serial + all at once); no tool-call comparison (build-1 omission 1) | 6b `_gated` |
| 17 Q5 | Width: memory and step time at 40k | DEFERRED (C): width arms run the 8k band only | 6b |
| 17 Q6 | Drop graphs13 first, then int8, then NCCL; keep #44401 short | graphs13: NOT TAKEN (D13). Drop order: DEFERRED (C, quota order) | — |
| 17 §11 | Eight GPU-only unknowns | NO ACTION (§7) | — |
| 17 §12 | Quota reading is from 10-22; re-check before the push | FIXED as a written precondition (§10) | — |
| 17 §12 | The external 215-min stop rule is not a substitute for internal deadlines | NO ACTION (agreed; internal deadlines = A-M2, A-M3) | — |
| 17 §13 | Validation: sha, patch / revert, compile, fake-server failure injections | FIXED partly: sha asserts; compile + CR check in the builder; the revert path runs in both harness scenarios; injected faster-but-wrong arm. Not injected: flush failure, dirty server, late start (§9) | builder, harness |
| 17 §13 | Do not change: SGLang 0.5.21, TP4, RedHat INT4, DFlash2, rev 6g, host verifier, raw-reasoning switch, sandbox, loading strategy, output caps, guarded backports | NO ACTION (unchanged; the staging fix keeps the strategy) | — |

### 3.2 Build-1 fix list: audit 17 §7 and audit 18 §5 verdicts

| Build-1 fix | Audit 17 | Audit 18 | Build 2 |
|---|---|---|---|
| 1 HTTP timeout clamp | partial (HIGH-3) | expired-call gap | FIXED (A-M3), negative tests |
| 2 late parity requests aborted | global cleanup deadline incomplete | cumulative cleanup gap | FIXED (A-M3), negative test |
| 3 `wait_level` plateau | no level check in comparative adoption | level comparability matters | FIXED (X1) |
| 4 A/A noise-floor parity | partial (HIGH-1) | gate incomplete | FIXED (A-M5; D1), negative tests |
| 5 cell compile / CR check | verified | verified | unchanged |
| 6 profiler flags | verified | present | unchanged |
| 7 NCCL arm ≥ 20 % | code present; workload gain to be measured | `graph_correct` missing | FIXED (A-M4, B1), negative tests |
| 8 nodelay arm | latch metric needs repair | no-benefit adoption possible | FIXED (A-M6), negative test + harness |
| 9 plain-text `/start_profile` | fixed | fixed | unchanged |
| 10 server-log sign counts | substring diagnostic, not a classifier | implemented | labelled as a diagnostic; 4 of 6 signs block (D12) |
| 11 pre-Duck `/flush_cache` | failure detection incomplete | clean state conditional | FIXED (B2); no negative test (§9.13) |
| 12 graphs13 capture list | permissive on an unparsed list | fail-open | FIXED (B3); no negative test (§9.13) |
| 13 builder CR guard | documented | fixed | unchanged |
| 14 watchdog peaks | no bug | implemented | unchanged |
| 15 fake `/flush_cache` | a failure-semantics test is needed | present | the fake now refuses while busy, but the harness never reaches the flush: NOT DONE as a test (§9.1) |
| 16 timing-test robustness | Linux portability caveat | five × 125 recorded | DEFERRED (C, portable tests) |

### 3.3 Audit 18 (Notes/18)

| ID | Item | Status | Where |
|---|---|---|---|
| 18 §1 P0 | Staging collision: both model dirs end in `/1`; the draft copy deleted the target copy and both paths pointed at it | FIXED (A-M1) | `L.staged_name`, `L.parallel_copy`, `L.stage_models` |
| 18 §1 test | Two sources named `1`: distinct dirs, correct checksums, the second copy leaves the first intact | FIXED: `test_stage_models_same_basename_never_collide` (real Kaggle path shapes; sha256 and a role marker checked in each copy), `test_stage_models_refuses_one_source_twice`; harness fixtures `…/pytorch/w4a16-g128/1`, `…/pytorch/bf16/1` + a distinct-copies check | `test_e14_loadpath.py`; harness |
| 18 §2 P0 | A1 cutoff ≤ HARD_STOP − stop margin − 1,500 s − preflight | FIXED partly (= 17 HIGH-2) | 5b |
| 18 §2 test | Slow start + relaunch: the Duck gets 1,500 s, else `solver_window_unavailable`, never reported as a 25-min run | FIXED partly: `duck_window` recorded and in `e14_report.md`; fake-clock unit tests; no notebook-level slow-start run (§9.5) | 5b end; tests |
| 18 §2 P0 | NCCL `build_summary` ignores `graph_correct` | FIXED (A-M4) | `B.build_summary` |
| 18 §2 test | Eager right + graph wrong + 90 % faster → rejected; missing rank, timeout, missing graph flag → rejected | FIXED: `test_summary_rejects_unsafe_fast_arm`, 5 cases | `test_e14_nccl_bench_and_trace.py` |
| 18 §2 P0 | A parity or known-answer gate for every adopted arm; no gate time → baseline | FIXED: per-arm gate; deadline or missing reference → INCOMPLETE → no adoption. Known-answer: DEFERRED (C) | `M.arm_gate`; 5b, 6b |
| 18 §2 test | Faster but wrong output → rejected | FIXED: harness `corrupt` | harness, fake server |
| 18 E14-4 | `post_json` past the deadline | FIXED (= 17 HIGH-3) | `M.post_json` |
| 18 E14-5 | Abort + per-thread `join(60)`: up to 720 / 840 s | FIXED: one shared 20 s bound | `M.cleanup`, `M.join_all`, `M.abort` |
| 18 E14-5 | Requests alive after the deadline must not carry over into the next phase | FIXED: not idle → forced relaunch before the next phase; a window or gate with a not-idle cleanup is INCONCLUSIVE / fails. Inside one phase the next step still runs on the same server (§9.7) | 5b `e14_phase`; `M.adopt_speed`, `M.arm_gate` |
| 18 E14-5 test | 12 stuck requests | FIXED: 14 hung requests, aborts that time out | `test_cleanup_of_14_hung_requests_with_failing_aborts_is_bounded` |
| 18 E14-6 | Partial samples pass `parity_ok` | FIXED | `M.parity_ok` |
| 18 E14-6 | Same prompt indices, same count, all responses valid, no unresolved errors | FIXED | `M.parity_pass`, `M.compare_passes`, `M.parity_ok` |
| 18 E14-6 | A large-margin divergence also seen in the A/A is numeric variation, not corruption | FIXED: arm flips ≤ A/A flips (D2) | `M.parity_ok` |
| 18 E14-7 | int8: same-input cross-arm parity and an A/A control | FIXED partly: cross-arm gate vs the A2 reference, judged against that reference's A/A; int8's own A/A: DEFERRED (C) | 6b |
| 18 E14-8 | Width / target-only controls come from old W1 rows | FIXED: A2-0 reference on the A2 base launch; all A2 gates use it. The A2 speed reference is still the kept arm's A1 window (§9.12) | 6b `_a2_reference` |
| 18 E14-9 | nodelay adopted without a gain; graphs13 speed-only on a missing list | FIXED (A-M6, B3) | 5b |
| 18 E14-10 | Record the idle check, the flush result and the cache state separately | FIXED partly: relaunch result or `idle_before` / `reply` / `ok`; a cache-state check after the clean start: NOT DONE (§9.14) | 5b end |
| 18 E14-11 | `full_reply_text_match` true at a last-token divergence | DEFERRED (C): unchanged (`k >= len(exp) - 1`); reported only, no decision reads it | `M.replay_conversation` |
| 18 E14-12 | The patches test uses a Windows absolute source path | DEFERRED (C) | `test_e14_sglang_patches.py:25` |
| 18 Q1 | Four defects (staging, reserve, deadlines, gate) | see rows above | — |
| 18 Q2 | Ties adopt nodelay; need a real admission gain | FIXED (`latch_gain`, ≥ 0.10) | `M.latch_gain` |
| 18 Q2 | "≥ 12 and queue ≥ 1" alone is not enough | NOT TAKEN as a metric (agreed) | — |
| 18 Q2 | Time at ≥ 12 at the same offered load; max running; queue-drain latency; retractions; committed tok/s | FIXED partly: `share_running_ge_level` and `retracted_delta` decide; `running_max` and `queue_drain_sec` are recorded only (definition caveat §9.10); committed tok/s via the 12-stream window speed rule | `M.latch_test`, `M.latch_gain`, `M.adopt_speed` |
| 18 Q2 | A separate held-row correctness test for #44401 | NOT DONE: not possible on CPU (§9.2) | `test_e14_sglang_patches.py` |
| 18 Q2 | No nodelay adoption without a real admission gain | FIXED | 5b |
| 18 Q3 | 1 idle check; 2 ack and errors recorded; 3 a bounded cache-state check; 4 `cold_start_unverified`; no automatic costly restart | 1, 2, 4 FIXED (fallback path); 3 NOT DONE; the restart advice NOT TAKEN: we always relaunch (D4) | 5b end |
| 18 Q4 | Full valid count; matched A/A; no unexplained large-margin regression; known-answer test; error-free serving; small sample = INCONCLUSIVE | FIXED except the known-answer test (DEFERRED C). Error-free serving = error rows fail the gate + `log_errors` | `M.parity_ok`, `M.arm_gate`, `M.log_errors` |
| 18 Q5 | Per width: config-mismatch warning; acceptance distribution; target-only parity; KV / graph capacity; errors; committed tok/s; matched width-8 control | FIXED: target-only parity, errors, tok/s (+5 %), matched control, `accept_p50 ≤ width`. DEFERRED (C): mismatch warning, distribution. Capacity: recorded per launch, not a condition | 6b |
| 18 Q6 | Drop width 4, width 6, int8, extra NCCL first; keep startup, NCCL baseline, a small profile, parity, the Duck run | DEFERRED (C, quota order): the A2 order is unchanged; when time runs out the last phases are skipped first | 6b |
| 18 Q6 | No 200-min run without a fresh quota reading | FIXED as a precondition (§10) | — |
| 18 §5 | Fixes 1, 2, 4, 7, 8, 11, 12 lacked their acceptance invariants | FIXED partly: 1, 2, 4, 7, 8 have negative tests; 11 and 12 do not (§9.13) | §8 |
| 18 §5 | Independent run: the mount fixture fails; the patches tests need the local 0.5.21 tree | DEFERRED (C) | — |
| 18 M1-M6 | M1 staging; M2 reserve; M3 shared deadline; M4 NCCL; M5 gate for adopted arms; M6 matched W8 / int8 / target-only controls | M1, M3, M4, M5 FIXED; M2 FIXED partly; M6 FIXED except int8's own A/A (C) | above |
| 18 nice | A more discriminating nodelay rule | FIXED (`latch_gain`) | `M.latch_gain` |
| 18 nice | A `/flush_cache` cold-state diagnostic | NOT DONE (§9.14) | — |
| 18 nice | graphs13 list parse fail-closed | FIXED (B3) | 5b |
| 18 nice | `full_reply_text_match` off-by-one | DEFERRED (C) | — |
| 18 nice | Portable test fixtures | DEFERRED (C) | — |
| 18 nice | Profiler-window duration semantics | FIXED: `diagnostic_only` label; never a speed reference | `M.steady_window` |
| 18 final | Re-audit the new sha, the integrated test logs and the launch / quota plan before any GPU run | this bundle | — |

### 3.4 Audit 19 (Notes/19)

| ID | Item | Status | Where |
|---|---|---|---|
| 19 §1 | Zip and notebook sha, 13 cells, module bytes, recorded logs | NO ACTION | — |
| 19 P0-A | #44401 / nodelay / graphs13 adopted without a correctness gate | FIXED (A-M5) | 5b |
| 19 P0-A | A concurrent-12 A/A baseline; every planned prompt usable; missing output, timeout or missing margin never counted as safe | FIXED | `M.arm_gate`, `M.parity_ok` |
| 19 P0-A | Gate fail → back to the previous verified arm | FIXED: the next arm builds on `E14_KEPT`; a rejected #44401 is reverted on disk; the Duck launches `E14_KEPT` (D5) | 5b |
| 19 P0-A | One small shared probe suite, not 512 × 12 × repeats per arm | FIXED: serial 6 × 256 + 12 × 256 at once | `M.arm_gate` |
| 19 P0-A test | +10 % speed with a large-margin output change → adopt false | FIXED: harness `corrupt` | harness |
| 19 P0-A | Public report of DFlash2 state corruption at high concurrency | NO ACTION (context, not checked by us; the all-at-once pass is the guard) | — |
| 19 P0-B | Joins after abort pass the deadline in `steady_window`, `latch_test`, `parity_pass`, `agent_replay`; `abort()` is serial | FIXED: `cleanup()` / `join_all` everywhere; `agent_replay` joins within left + 20 s, then checks idle (chat requests carry no rid; each ends by its deadline-capped timeout) | `M.*` |
| 19 P0-B | Bounded aborts; a total join budget of 10-20 s | FIXED: 20 s (aborts 8 s, joins until 15 s, idle check in the rest) | `M.cleanup` |
| 19 P0-B | Requests still running after the aborts → no next arm on that server; relaunch or invalidate | FIXED: `E14_DIRTY` → forced relaunch; the phase is skipped if still dirty | 5b `e14_phase` |
| 19 P0-B test | 14 generators never return, aborts fail, cleanup ≤ 20 s, the next arm never starts with live requests | FIXED partly: unit test (bound 3 s, asserted < 4.5 s, `server_idle` false); the "next arm not started" part is code, not tested (§9.6) | `test_e14_measure.py` |
| 19 P0-C | The latch misses 11 + queue | FIXED (A-M6) | `M.latch_test` |
| 19 P0-C | Keep `share_at_target` (13) as a diagnostic | FIXED | `M.latch_test` |
| 19 P0-C | Decide on 11 → 12, queue pressure and total tok/s | FIXED: `latch_gain` + `adopt_speed(occupancy=True)` | 5b |
| 19 P0-C test | Synthetic 11 + queue baseline vs a 12-running candidate = a gain; identical = no gain | FIXED: `test_latch_gain_11_queued_to_12_is_a_gain_and_a_tie_is_not`; harness default (the fake models the delayer) | tests, harness |
| 19 P0-C | Build-1 harness run 5 adopted every arm at speed ratio 1.000 | FIXED: #44401 is now rejected for no occupancy gain in the harness | harness |
| 19 HIGH-D | Repro 1: one response passes | FIXED | `M.parity_ok` |
| 19 HIGH-D | Repro 2: 0/6 identical with an A/A of 0/6 passes | By design PASS if flips ≤ A/A flips and every divergence has both margins (identity is not used by any notebook gate after R1, D1) | `M.parity_ok` |
| 19 HIGH-D | Repro 3: speed adopted across a different context / level | FIXED | `M.adopt_speed` |
| 19 HIGH-D | Expected count, missing margins, timeout / error count, completeness; speed: minimum samples, measured concurrency, context band | FIXED | `M.parity_ok`, `M.adopt_speed` |
| 19 HIGH-D | Label the deliberate 11 → 12 comparison as an occupancy experiment | FIXED | `M.adopt_speed` |
| 19 HIGH-D tests | Empty, incomplete, no-margin, 1/12, 0/6 identical, mismatched context → fail closed; a valid noisy A/A must not fail | FIXED: empty = `adopt_speed` missing window (`parity_ok` with no input returns INCOMPLETE; no separate test); 0/6 tested as INCONCLUSIVE under `require`; noisy A/A = `test_gate_low_margin_benign_divergence_passes_with_identity_ignored` | `test_e14_measure.py` |
| 19 HIGH-E | Reserve = window + stop margin + ~10 min; a conservative relaunch cost, not the warm median | FIXED partly: 2,980 s incl. 600 s artifacts and 400 s cold relaunch; the relaunch wait itself is not capped (§9.4) | 5b |
| 19 HIGH-E test | Slow-loading notebook: optional A1 phases skipped, the Duck window kept | FIXED partly: fake-clock unit tests only (§9.5) | tests |
| 19 §3 | Detect a successful flush; on failure record "cache not cleared"; then never present the Duck run as clean-cache | FIXED: `cold_start_unverified`, in `e14_report.md` | 5b end |
| 19 §3 | Server-side cache state and a cold-prefix probe | NOT DONE (§9.14) | — |
| 19 §4 | Acceptance distribution per width | DEFERRED (C) | — |
| 19 §4 | Baseline and candidate at the same concurrency | FIXED: 12-stream windows, same measured level required for widths / NCCL | 6b, `M.adopt_speed` |
| 19 §4 | A small concurrent parity as well as the serial one | FIXED: the gate has both | `M.arm_gate` |
| 19 §4 | Any output error or missing margin → adopt false | FIXED | `M.parity_ok` |
| 19 §4 | Width 4 with max acceptance > 4 = an instrumentation fault | FIXED partly: condition `accept_p50 ≤ width` (median, not max) | 6b |
| 19 §4 | int8: a direct cross-arm comparison | FIXED | 6b |
| 19 §5 | #44401, nodelay and graphs13 are different interventions; record each contribution and adoption reason | FIXED: `decisions[arm]` = adopt, first failing condition, every condition, speed, latch gain, gate, log errors | 5b `e14_decide` |
| 19 §5 | Weigh occupancy, tok/s, cache cost and correctness together | FIXED partly: cache cost is not a decision input (`mamba_p50` recorded per window) | 5b |
| 19 §6 | Target-only highest; a small pre-Duck target-only gate if possible | target-only kept (A2-3); pre-Duck gate DEFERRED (C) | 6b |
| 19 §6 | Agent replay high; NCCL only with a large gain and transport-safety evidence; width 6 medium; width 4 lower; int8 lowest | replay kept; NCCL = bench ≥ 20 % graph-correct + window ≥ 5 % + gate (B1); drop order DEFERRED (C) | 6b |
| 19 §7 | Tests need `PYTHONPATH=src`; fixtures at Windows paths | DEFERRED (C); the command is in §8.3 | — |
| 19 §8 | P0 gate, P0 deadline, P0 latch, HIGH parity + speed, HIGH reserve, MEDIUM flush, MEDIUM int8, LOW portable tests, LOW 60k band, LOW scheduler / HiCache / TP2 / kernels | gate, deadline, latch, parity + speed, flush, int8: FIXED; reserve: FIXED partly; portable tests: DEFERRED (C); 60k band and scheduler / HiCache / TP2 / kernels: NOT TAKEN (agreed "not now") | — |
| 19 §9 | Three fake-server scenarios: faster-but-wrong candidate; hung abort with 14 active requests; 11 + queue baseline → 12-running nodelay | 1 and 3 in the notebook harness; 2 as a unit test with a stub HTTP server (D11) | §8 |
| 19 §9 | Rerun the old tests + new failure-injection tests + the harness | unit tests 165/165 in three consecutive runs (logs/unit_tests_run1..3.txt); notebook harness 31/31 in both scenarios, default and corrupt (logs/harness_default.log, logs/harness_corrupt.log) | §8 |

## 4. Design decisions where we deviated from an audit

**D1. Parity identity rule (changed in round 2, R1).**
- No gate requires identity across a server restart: DFlash2 greedy output is deterministic within one process but can differ across restarts (#38009), and every arm runs in a new process. The A1 gates (#44401, nodelay, graphs13) therefore use `identity=False` like the A2 gates; identity is recorded.
- `identity="require"` stays in the code (unit-tested) for a same-process comparison; no notebook gate uses it now.
- Arms that change the arithmetic or the drafter (width 6 / 4, NCCL transport, target-only, int8 checkpoints) use `identity="ignore"` in both passes: an exact token match is not expected there, so flips decide.
- The all-at-once pass never uses identity. Batching alone changes greedy tokens (E11-03: an A/A shared only 152-166 of 512 tokens), so an all-at-once A/A with 0 identical sequences means identity is unusable, not that the arm failed.
- What protects these passes: every planned prompt compared in both runs, both margins present at every divergence, and arm large-margin flips ≤ A/A large-margin flips.
- Consequence: audit 17's counterexample A and audit 19's repro 2 still PASS whenever no divergence is confident (both margins present, flips ≤ A/A flips). Audit 17 HIGH-1 asked for INCONCLUSIVE whenever the A/A has 0 identical; with cross-restart divergence expected, that rule would reject every honest arm. See §11 Q2.

**D2. Flips are judged against the A/A, not against zero.** Audit 17 Q4 and audit 19 P0-A speak of "0 large-margin flips"; audit 18 E14-6 says an A/A flip is numeric variation. We follow audit 18. With a deterministic A/A (0 flips) both rules are the same.

**D3. One gate reference per stage.**
- A1 arms compare with W1's A1-4 rows (serial twice, 12 at once twice, 512 tokens, compared on the first 256), not with the last kept arm. This saves four parity passes per arm; the A1 arms are not expected to change bs-1 output.
- A2 has its own reference on the A2 base launch (A2-0).
- If A1-4 did not run, every A1 gate is INCOMPLETE and the Duck runs on W1 (fail closed).

**D4. Clean Duck start: fresh relaunch, flush only as a fallback.**
- Conflict: audit 17 HIGH-4 (flush; relaunch once on failure) vs audit 18 Q3 (no automatic costly restart, a flag only).
- Resolution: always start the Duck on a fresh forced launch of the kept arm.
- Reasons: a relaunch in the same session takes about 75 s once the JIT cache exists (E11-04; the reserve holds 400 s for it); it gives an empty radix and Mamba state by construction; and it restores the kept arm after a rejected last arm (build 1 needed a `duck_cfg` relaunch for that anyway).
- `/flush_cache` runs only if that launch fails.

**D5. `E14_KEPT` replaces `E14_GOOD` (a bug we found ourselves).**
- Build 1 set `E14_GOOD` on every successful launch, so it tracked the last *launched* arm, not the last *adopted* one. A failed launch then restored that arm, which could be a rejected one.
- Example: nodelay launches and is rejected; `nodelay_back` fails; its fallback relaunches `E14_GOOD` = nodelay; graphs13 is then built on the rejected nodelay.
- Build 2: `E14_KEPT` changes only in `e14_keep()` after an adoption. Every arm launch builds on it; a failed FORCED launch (the Duck launch, a `_clean`) relaunches `kept_<name>` (R5); the Duck launches it.

**D6. `W1_back`, `nodelay_back` and `duck_cfg` relaunches removed.** The next arm's launch already starts from `E14_KEPT`, and the Duck has its own fresh launch. This saves up to three relaunches.

**D7. Gate first, windows only after a pass (changed after the first build-2 harness runs).**
- In every A1 arm phase (`_arm_windows`) and in the A2 width and NCCL phases (`_gated`), the gate runs first; the throughput windows (and the latch test in A1) run only if it passed. `e14_decide` lists the gate right after the launch condition.
- Reason: with the gate after the windows, one harness run starved the gate of phase time, and a good arm was rejected as INCOMPLETE.
- Consequences: a rejected arm has no speed or latch numbers; a gated arm can still be rejected when its windows then run out of time (`adopt_speed` INCONCLUSIVE).
- int8 (A2-2) and target-only (A2-3) also go through `_gated` now (R17).
- Cache-state caveat: §9.8 and §11 Q3.

**D8. `latch_gain` needs one share to improve, not both.** Audit 17 §5 asked for the ≥ 12 share up *and* the 11 + queue share down. We adopt when one improves by ≥ 0.10 and the other does not get worse, and retractions do not rise. Equal numbers never count.

**D9. #44401 must show its own occupancy gain.** Following audits 18 E14-9 and 19 P0-C, it is no longer kept on a tie. It is tested first, on W1, where the delayer still holds 11. Without a gain it is reverted, and nodelay is then measured without it (this is what the harness shows). No combined nodelay + #44401 arm exists. See §11 Q4.

**D10. A larger Duck reserve than audits 17 and 18 asked.** 1,500 + 180 + 300 + 600 + 400 = 2,980 s. The 600 s artifact margin and the 400 s cold relaunch follow audit 19 HIGH-E.

**D11. The 14-hung-request case is a unit test, not a notebook-harness scenario.** A stub HTTP server hangs `/generate` and answers `/abort_request` with 500 after 30 s; the test drives `cleanup()` directly.

**D12. Log signs: six counted, four blocking.** "Retract" and "Exception" are counted and reported but do not block an adoption. Retractions are judged by the retraction counter in the latch test. The counts are substring diagnostics, not a structured classifier.

**D13. graphs13 stays in A1** although audit 17 Q6 would drop it first. It is one launch flag on the kept arm with a short check; audits 18 and 19 drop width 4 and int8 first.

**D14. Staged dir names.** Notes/20 planned `target-<hash>` / `draft-<hash>`. `stage_models` takes a plain list of dirs without role names, so the name is `m<i>-<parent>-<basename>-<sha1[:10]>`. Uniqueness is the same.

## 5. Checked against code / 0.5.21 source, no change made

| Item | Finding |
|---|---|
| Token-id fields for the E14-P replay | `return_token_ids` (protocol.py:893); the choice carries `prompt_token_ids` / `response_token_ids` (protocol.py:1228-1229); non-streaming only (serving_chat.py:1196-1200). |
| Null `cached_tokens` | Means 0 under `--enable-cache-report` (usage_processor.py). |
| KV pool | Re-read from each relaunch's server log (`e14_launch` → `ENGINE_INFO["kv_tokens"]`). |
| JIT cache | Separate `SGLANG_JIT_CACHE_DIR`; `_NEVER_SHIP = ("sglang/nv", "cuda")`; this run saves only. |
| Two KV gates | E11's 0.85 gate feeds only the DIRECT solver; Duck uses 0.95 on `sglang:full_token_usage`. |
| Duck window start | Computed when CELL 6 starts, after A1; A1 now ends before the reserve (A-M2). |
| vLLM fallback | The Duck notebook has no vLLM engine path; a tokenizer-check failure fails closed (CELL 0 fallback). |
| Stale `.pyc` after the backport | Deleted by `e14_sglang_patches`. |
| `/flush_cache` replies (new) | `http_server.py:987-1002`: success = 200 + "Cache flushed.\nPlease check backend logs …"; failure = **400** + `ret.message` or "Flush cache failed.\n". On 400 `urlopen` raises, so the fallback records `error: HTTPError …`, ok false. (The build-1 excerpt file stops at line 1000; the status line is 1001.) |
| Retraction counter (new) | `sglang:num_retracted_requests_total` is a Counter in 0.5.21 (`observability/metrics_collector.py:474-476`). `Sampler` reads it; `retracted_delta` = max − min over the latch samples. |
| Top-2 margins under DFlash (new) | Present in 0.5.21 (`compute_spec_logprobs` with top-k; `meta_info["output_top_logprobs"]`, tokenizer_manager.py:2787; Notes/20), so a missing margin is an error case → fail closed. |
| Delayer model in the fake (new) | Same rule as `min_free_slots_delayer.resolve_min_free_slots` (excerpts): explicit value wins, ≤ 1 disables; unset + DFlash + cap ≥ 8 → min(4, max(2, (cap + 5) // 6)) = 3 at cap 13. |
| Relaunch wait `max(60, …)` | Cannot pass HARD_STOP (launches are skipped in the last 15 min). It can pass the Duck reserve (§9.4). |
| Penalties, `tool_choice`, `--enable-mixed-chunk`, ReplaySSM, PCIe-IPC | None used (penalties are a no-op under DFlash in 0.5.21, #28180; ReplaySSM raises for DFLASH on non-KDA; the PCIe-IPC kernel is missing from FlashInfer 0.6.18). |

## 6. Not built on purpose

### 6.1 From build 1 (accepted by audit 17 §9 and audit 19 §8)

1. Long (12,288) thinking-on parity probes and a tool-name comparison: the greedy `/generate` gate is stricter; long probes do not fit 200 min.
2. A 60k context band per arm: A1 arms have the 8k and ~40k bands, with `ctx_per_req_p50` recorded.
3. Cosmetic legacy DIRECT config fields in the E12 report: not the Duck settings; rev 6g is frozen.
4. rev 6g metric defects F1 / F2 / H7-11 partial / `publish_seq`: measurement-only; rev 6g is frozen.
5. `--max-mamba-cache-size 64` or mrr 14: only if nodelay does not reach 12, and only after a memory check.

### 6.2 Category C (deferred by the user's decision)

| # | Item | What the code does now / why it waits |
|---|---|---|
| C1 | int8's own A/A | int8 runs in A2, after the Duck run, and never changes the submission. Its cross-arm gate is judged against the A2 reference's own A/A. An int8 A/A costs two more parity passes on that launch. |
| C2 | Width checks beyond `accept_p50 ≤ width` and the gate (resolved width from the log, mismatch warning, acceptance distribution, max accept, KV / graph capacity as a condition, 40k step time) | Launch flags, parsed caps and the server log are recorded and bundled; the decision uses the gate, +5 % speed, `accept_p50 ≤ width`, log signs. |
| C3 | Known-answer test | For A1 arms the serial bs-1 identity check against W1's recorded greedy rows (6 × 256 tokens) plays this role. For arithmetic-changing arms no fixed expected output exists. |
| C4 | Pre-Duck target-only gate | It costs one extra relaunch (target-only graphs differ) + 6 serial prompts inside A1, against the Duck reserve. Target-only runs in A2-3; its verdict is recorded as `dflash_vs_target`. |
| C5 | Staging stop event | Audit 17 rated it "plausible, not confirmed". The fallback happens only when staging is still running at the join timeout (give-up − 20 min). |
| C6 | `full_reply_text_match` off-by-one | Reported in the E14-P replay summary only; no decision reads it. |
| C7 | Portable tests | Not a runtime path; §8.3 gives the command and the local dependencies. |
| C8 | JIT known-answer before a restore | This run only saves the cache; nothing restores it. |
| C9 | Record-integrity regression for the frozen rev 6g records | rev 6g is unchanged (same `arc2_duck.py` sha; the E12 manifest check runs). |
| C10 | Quota-driven A2 drop order (int8 → width 4 → width 6 → NCCL) | The A2 order is unchanged: reference, replay, int8, target-only, width 6, width 4, NCCL. When time runs out, the last phases are skipped first, so int8 still runs early (opposite to audits 18 and 19). |

Profiler-window labelling and the extra latch metrics (`running_max`, `queue_drain_sec`, `retracted_delta`) were on the deferred list but are already in this build (X2, A-M6).

## 7. Only the GPU run answers

1. Real running 12 / 13 with nodelay; over-admission errors; retractions.
2. Whether the #44401/#41872 hunks match the x86_64 wheel (a mismatch is refused, the run continues unpatched), and whether #44401 alone changes occupancy under the delayer.
3. Whether W1's serial bs-1 greedy A/A (6 × 256 tokens) is reproducible. If it shows 0 identical sequences, every A1 gate is INCONCLUSIVE and the Duck runs on W1.
4. Whether a prefix-cache hit changes bs-1 greedy tokens (A2-1's cache-hit parity measures it; it matters for the gate, §9.8).
5. Token-level confirmation of the raw-reasoning fix (A1-3 `first_divergence`; Duck cached fraction vs G4B 75.0 %).
6. The step split and the NCCL transport.
7. Acceptance at width 6 and 4.
8. Mamba eviction with and without int8 checkpoints.
9. `/dev/shm` size, cgroup limit, copy MB/s, ready seconds (G4B on 10-21: 1,197 s); the real relaunch time vs the 400 s allowance.
10. `/flush_cache` on the hybrid radix cache (now only reached if the Duck relaunch fails).

## 8. Tests

### 8.1 Unit tests (165 items)

| File | Items | Build 2 |
|---|---|---|
| `src/test_e14_measure.py` | 32 | new (26 + 6 in round 2) |
| `src/test_e14_loadpath.py` | 58 | +2 new, 1 updated |
| `src/test_e14_sglang_patches.py` | 36 | unchanged |
| `src/test_e14_nccl_bench_and_trace.py` | 39 | +6 (a parametrized unsafe-arm test + the invalid-baseline test) |

Result on the final build: **165/165 in three consecutive runs** (`logs/unit_tests_run1..3.txt`).

Round-2 additions: `test_flush_cache_classifies_a_refused_flush` (HTTP 400 → ok false, then ok true), `test_flush_cache_works_after_the_phase_deadline`, `test_latch_gain_rejects_an_invalid_latch` (3 cases), `test_adopt_speed_per_step_removes_accept_noise`, `test_summary_invalid_baseline_is_no_reference`; the hung-request test now waits until all 14 hang (lock, backlog 64).

**New in `test_e14_measure.py`** (a stub HTTP server: `/generate` hangs 120 s and ignores aborts, `/abort_request` answers 500 after 30 s, `/metrics` reports the hung requests as running):
- `test_post_json_past_deadline_sends_nothing`: deadline −2 s → `TimeoutError`, the server saw 0 requests.
- `test_post_json_timeout_never_exceeds_the_deadline`: 1 s left, timeout 600 requested → returns in < 4 s.
- `test_cleanup_of_14_hung_requests_with_failing_aborts_is_bounded`: 14 hung generators, budget 3 s → done in < 4.5 s; 14 aborts sent at once; `alive_threads` 14; `server_idle` false.
- `test_join_all_shares_one_deadline`: 14 threads sleeping 30 s, budget 1 s → < 1.5 s.
- `test_join_all_skips_threads_never_started`.
- `test_gate_stable_aa_identical_arm_passes` (identity `require`).
- `test_gate_large_margin_flip_fails`: one 2.4-nat flip vs an A/A with none → FAIL.
- `test_gate_low_margin_benign_divergence_passes_with_identity_ignored`: four divergences at 0.2-nat margins → PASS.
- `test_gate_unstable_aa_zero_identical_is_inconclusive_when_identity_required`.
- `test_gate_missing_margins_fail_closed` → INCOMPLETE.
- `test_gate_missing_requests_fail_closed`: 1 of 12 compared; one errored request → INCOMPLETE.
- `test_gate_counterexamples_from_the_audits_no_longer_pass`: audit 17 A (under `require`) and audits 18/19 compared = 1.
- `test_compare_passes_truncates_to_n_tokens`.
- `test_adopt_speed_invalid_windows_are_inconclusive` (5 cases): 2 decode lines; context 40k vs 8k; level 11 vs 12; server not idle; missing base window.
- `test_adopt_speed_occupancy_comparison_is_labelled`.
- `test_latch_gain_11_queued_to_12_is_a_gain_and_a_tie_is_not`: also more retractions → no gain; missing result → no gain.
- `test_phase_budget_keeps_the_duck_reserve` (4 fake-clock cases: early, medium, late = cut, too late = skipped).
- `test_launch_allowed_respects_reserve_unless_forced`: a forced launch still respects the 15-min floor.
- `test_log_errors_ignores_benign_signs`.

**New in `test_e14_loadpath.py`:**
- `test_stage_models_same_basename_never_collide`: `…/qwen3-8-27b-int4-redhat/pytorch/w4a16-g128/1` and `…/qwen3-8-27b-dflash2/pytorch/bf16/1` → two different staged dirs, sha256 of each copy = its source, each `config.json` keeps its own role marker.
- `test_stage_models_refuses_one_source_twice` → error "share a destination", launch path = the source.
- Updated: `test_copied_model_is_not_read_again_after_a_later_failure` expects the `staged_name` path.

**New in `test_e14_nccl_bench_and_trace.py`:** `test_summary_rejects_unsafe_fast_arm`, 5 cases of a 10× faster arm: graph wrong; graph correctness never measured; status timeout; a rank missing (aggregate not correct); no rank reported → never `adopt_candidate`, best arm = baseline.

### 8.2 Fake-server notebook harness

`src/harness/harness_e14_nb.py <notebook> <scale>` runs every code cell of the real notebook in order against `e14_fake_server.py`, then checks the outputs (31 checks per run).

**Fake server changes:**
- models the 0.5.21 DFlash min-free-slots delayer, so W1 really runs 11 of 12 with one queued, and `--min-free-slots-delay 1` runs 12;
- a real FIFO waiting queue (`#queue-req`, `sglang:num_queue_reqs`);
- `sglang:num_retracted_requests_total` (always 0);
- `FAKE_CORRUPT_IF_FLAG`: when that flag is on the command line, greedy token 5 changes with a 2.4-nat margin and throughput rises 10 %;
- `/flush_cache` answers "Flush cache failed." with HTTP 400 while requests run or wait (as 0.5.21).

**Harness changes:** model fixtures copy the real Kaggle path shape (both end in `/1`); scenario switch `E14_HARNESS_SCENARIO=default|corrupt` (`corrupt` puts the faster-but-wrong flag on nodelay).

**What the checks require** (beyond build 1's plumbing checks):
- staging: two copies in different dirs, contents intact, launch from the copies;
- W1 windows measured at level 11 (the delayer), latch test: W1 stuck at 11 + queue in ≥ 50 % of samples, never ≥ 12;
- #44401: gate PASS, rejected for "occupancy gain", files reverted (the revert path ran);
- `default`: nodelay adopted with a latch gain, speed labelled occupancy, gate PASS;
- `corrupt`: nodelay rejected with reason "correctness gate", gate FAIL, windows skipped; graphs13 (no corrupt flag) gated PASS and adopted;
- graphs13 decision read the captured list (12 and 13 present);
- every A1 phase ended at least reserve + 8 min before the hard stop; Duck window "full";
- the Duck starts on a fresh forced launch of the kept arm, `cold_start_unverified` false; the Duck arm has nodelay in `default` and not in `corrupt`;
- every A1 and A2 candidate carries a gate verdict; A2-0 reference ran; target-only gate PASS;
- no phase left requests running.

**Final build a5318dda (31/31 in both scenarios):**
- `default`: dflash_contamination PASS; #44401 rejected (reason "occupancy gain", gate PASS, patch reverted, revert ok); nodelay adopted (11 -> 12 latch gain, gate PASS, speed labelled occupancy, steps/s basis); graphs13 adopted (captured 1..13, gate PASS); the Duck ran on a fresh forced launch `duck_graphs13` of the kept arm (clean start ok, server reachable and idle, window full); every A2 arm carries a gate verdict; no phase left requests running.
- `corrupt`: nodelay gate FAIL (serial 6/6 and all-at-once 12/12 large-margin flips vs 0 in the A/A), windows skipped, reason "correctness gate"; graphs13 (no corrupt flag) gate PASS and adopted; the Duck ran on graphs13 without nodelay.
- Earlier build-2 run (before D7): the gate placed after the windows was starved of phase time and rejected graphs13 as INCOMPLETE in the corrupt scenario — the reason for gate-first.

### 8.3 Reproduce

- Unit tests: `PYTHONPATH=src python -m pytest -q -p no:cacheprovider --noconftest --rootdir=. --confcutdir=. --import-mode=importlib src/test_e14_*.py` (or run from `src/`). `test_e14_sglang_patches.py` needs a local SGLang 0.5.21 source tree at the path in line 25.
- Harness: `E14_HARNESS_SCENARIO=default|corrupt python src/harness/harness_e14_nb.py notebook/Q27-XHIGH-E14A_OPTIMIZED_ENGINE_SGLANG.ipynb <scale>`. Needs `transformers`, the E12 fixture package and a Qwen tokenizer fixture (local `D:/` paths in the harness header).
- `logs/test_raw_reasoning.txt` (15/15) is from build 1; `arc2_duck.py` is unchanged.

## 9. Known limits

1. **Flush fallback (Duck start) not exercised in the harness** (the fresh relaunch always succeeds there). `flush_cache()` itself runs in every A1 arm (after the gate) and before int8's cold pass, and has unit tests for both outcomes.
2. **#44401 held-row semantics** cannot be tested on CPU (it needs the scheduler and a GPU model runner). What exists: the source-hash guard and CPU tests that run the patched statements, cut out with `ast`, on fake objects.
3. **Tests are portable only in part:** `test_e14_sglang_patches.py` hard-codes the SGLang source path (line 25); `test_mounts_longest_prefix` and `test_meminfo_and_env_report` patch `os.name = "nt"`; the harness needs local fixtures; the tests import modules by name (run from `src/` or set `PYTHONPATH=src`).
4. **Duck reserve.** Non-forced relaunch waits are capped by the reserve (R3); the dirty relaunch is not forced (R4); the kept-arm restore runs only after a failed forced launch (R5). Remaining: a forced restore after a failed Duck launch can use up to 20 min of the Duck window.
5. **Late start is unit-tested only.** The harness runs far from HARD_STOP, so every `phase_budget` / `launch_allowed` call passes there. Their fixed constants (400 / 480 / 900 / 120 s) and the 480 s phase margin are not time-scaled in the harness.
6. **Dirty-server path not exercised.** No harness scenario leaves requests running, so `E14_DIRTY` → relaunch → phase skip never runs. The unit test covers `cleanup()` reporting `server_idle` false.
7. **Carry-over inside one phase** is caught, not prevented: the next step of the same phase runs on the same server, and its own cleanup idle check marks it (window INCONCLUSIVE, gate failed).
8. **Gate cache state (from D7).** The arm's gate runs first on a fresh launch (cold radix cache) while W1's reference rows (A1-4) ran on a warm server. With identity no longer required (R1) a cache-induced near-tie divergence does not fail the gate; a confident one would. The windows now start uncached on both sides (R14).
9. (Removed in round 2: R5.)
10. **`queue_drain_sec`** = first empty-queue sample after the queue was > 0 (R19). Recorded only, not a decision input.
11. **Retraction rule:** the fake's counter is always 0, so the rule is unit-tested only.
12. **A2 speed reference** for width / NCCL is the kept arm's A1 short window (same flags, earlier launch), not a window on the A2 base launch.
13. Flush classification has unit tests now (a refused flush = 400 → ok false; a flush after the deadline works). graphs13 on an unparsed list still has no negative test.
14. **No cold-prefix observation** of the first Duck requests and no cache-state check after the clean start. The relaunch makes the cache empty by construction; the E12 report's `usage_all` is copied into `e14_results.duck_run`.
15. (Fixed in round 2: R10.)
16. **Width acceptance** uses the median (`accept_p50 ≤ width`), not the maximum.

## 10. Run plan to judge

- **Account:** hosen42, 8.63 h quota at the last reading (10-22). **A fresh quota reading before the push is a precondition** (audits 17 §12, 18 Q6). 4×L4 bills 2× wall time.
- **Time:**
  - code budget 200 min (hard stop ≈ 198 min); worst case with Kaggle start / save ≈ 210 min (≈ 7.0 quota-h);
  - A1 phases must end ≥ 3,460 s (57.7 min) before the hard stop, A1 relaunches start only ≥ 3,980 s (66.3 min) before it, so A1 work stops by ≈ 132-140 min into the run;
  - the build-1 "normal ≈ 145–165 min" estimate was not re-derived for build 2 (phase caps rose from 69 to 75 min in A1 and from 66 to 88 min in A2; three `_back` relaunches were removed and one Duck relaunch was added);
  - the first launch can take up to 75 min on slow GCSFUSE days; A1 arms are then skipped by the reserve rule.
- **External stop rule:** still RUNNING 215 min after the push = a platform stall.
- **Risk no notebook guard covers:** on 10-22 a run ended in ERROR after ~114 min with an empty log (Kaggle never started our code).

## 11. Questions for you (GPT)

1. Check every FIXED / FIXED partly row in §3 against the code. Report any wrong status with file + line.
2. **D1:** in all-at-once passes and for arithmetic-changing arms, an arm with 0 identical sequences passes when no divergence is confident (flips ≤ A/A flips, both margins present). Is that adequate? Would you add a second criterion, e.g. the median first-divergence position must not be earlier than the A/A's?
3. **§9.8:** on 0.5.21 with `extra_buffer_lazy` and Mamba checkpoints, can a prefix-cache hit produce a CONFIDENT (> 1 nat) divergence at bs 1? If yes, should the reference be taken on a cold launch?
4. **D9:** #44401 is judged alone on W1, where the delayer still holds 11, and is reverted without a gain. Keep this, test it on top of nodelay instead, or add a combined arm?
5. Are the `latch_gain` thresholds right (≥ 0.10 on one share, the other not worse, retractions not up)? Should `queue_drain_sec` be redefined (§9.10)?
6. **R3-R5:** are the reserve-capped relaunch wait, the non-forced dirty relaunch and the forced-only kept restore enough, or is another path able to eat the Duck window?
7. **R1:** with identity no longer required across restarts, is "flips ≤ A/A flips, complete samples, both margins present" a strong enough gate, or would you add a cross-restart A/A (one extra W1 relaunch) to calibrate it?
8. Is it right that "Retract" and "Exception" are counted but do not block (D12)?
9. Is any category C item (§6.2) a must-fix for this run?
10. With int8 running early in A2 (C10), would you change the A2 order before the run if quota is below 7 h?
11. Give a GO / NO-GO for `a5318ddab1ee692535a7417c9452f9e758c4fb3c290b668cd8c1b0ca0a54c6ea`, with must-fix items separated from nice-to-haves.
