# SGLang 0.5.21 source excerpts used to verify the E14-A notebook

Source: the sglang-0.5.21 aarch64 wheel (`sglang-0.5.21-cp310-cp310-manylinux_2_34_aarch64.whl`), unpacked. Python files are identical across arches except compiled parts; the backport hunks are checked by hash on the Kaggle x86_64 wheel at run time.

## /start_profile and /stop_profile answer plain text — `entrypoints/http_server.py` lines 1164-1185

```python
 1164  @app.api_route("/start_profile", methods=["GET", "POST"])
 1165  @auth_level(AuthLevel.ADMIN_OPTIONAL)
 1166  async def start_profile_async(obj: Annotated[Optional[ProfileReq], Body()] = None):
 1167      """Start profiling."""
 1168      await _global_state.tokenizer_manager.start_profile(obj or ProfileReq())
 1169      return Response(
 1170          content="Start profiling.\n",
 1171          status_code=200,
 1172      )
 1173  
 1174  
 1175  @app.api_route("/stop_profile", methods=["GET", "POST"])
 1176  @auth_level(AuthLevel.ADMIN_OPTIONAL)
 1177  async def stop_profile_async():
 1178      """Stop profiling."""
 1179      await _global_state.tokenizer_manager.stop_profile()
 1180      return Response(
 1181          content="Stop profiling. This will take some time.\n",
 1182          status_code=200,
 1183      )
 1184  
 1185  
```

## /flush_cache answers plain text — `entrypoints/http_server.py` lines 985-1000

```python
  985  
  986  
  987  @app.api_route("/flush_cache", methods=["GET", "POST"])
  988  @auth_level(AuthLevel.ADMIN_OPTIONAL)
  989  async def flush_cache(timeout: float = Query(0.0, ge=0.0)):
  990      """Flush the radix cache."""
  991      ret = await _global_state.tokenizer_manager.flush_cache(timeout_s=timeout)
  992      if ret.success:
  993          content = (
  994              "Cache flushed.\nPlease check backend logs for more details. "
  995              "(When there are running or waiting requests, the operation will not be performed.)\n"
  996          )
  997      else:
  998          content = ret.message or "Flush cache failed.\n"
  999      return Response(
 1000          content=content,
```

## ProfileReq fields — `managers/io_struct.py` lines 2257-2285

```python
 2257  class ProfileReq(BaseReq, kw_only=True):
 2258      req_type: ProfileReqType = ProfileReqType.START_PROFILE
 2259      # The output directory
 2260      output_dir: Optional[str] = None
 2261      # Specify the steps to start the profiling
 2262      start_step: Optional[int] = None
 2263      # If set, it profile as many as this number of steps.
 2264      # If it is set, profiling is automatically stopped after this step, and
 2265      # the caller doesn't need to run stop_profile.
 2266      num_steps: Optional[int] = None
 2267      # The activities to record. The choices are ["CPU", "GPU", "MEM", "RPD"]
 2268      activities: Optional[List[str]] = None
 2269      # Whether profile by stages (e.g., prefill and decode) separately
 2270      profile_by_stage: bool = False
 2271      # Whether to record source information (file and line number) for the ops.
 2272      with_stack: Optional[bool] = None
 2273      # Whether to save information about operator’s input shapes.
 2274      record_shapes: Optional[bool] = None
 2275      profile_id: Optional[str] = None
 2276      # Merge profiles from all ranks into a single trace
 2277      merge_profiles: bool = False
 2278      # The prefix of the profile filenames
 2279      profile_prefix: Optional[str] = None
 2280      # Only profile these stages and ignore others
 2281      profile_stages: Optional[List[str]] = None
 2282      # Add iteration-level annotations (KV / request aggregates) for roofline-style analysis
 2283      detailed_annotations: bool = False
 2284  
 2285  
```

## with_stack / record_shapes default to true — `managers/tokenizer_control_mixin.py` lines 397-412

```python
  397      async def start_profile(
  398          self: TokenizerManager,
  399          req: Optional[ProfileReq] = None,
  400      ):
  401          self.auto_create_handle_loop()
  402          req = req or ProfileReq()
  403          req.req_type = ProfileReqType.START_PROFILE
  404          env_with_stack: bool = get_bool_env_var("SGLANG_PROFILE_WITH_STACK", "true")
  405          req.with_stack = (
  406              False if req.with_stack is False or env_with_stack is False else True
  407          )
  408          env_record_shapes: bool = get_bool_env_var(
  409              "SGLANG_PROFILE_RECORD_SHAPES", "true"
  410          )
  411          req.record_shapes = (req.record_shapes is not False) and env_record_shapes
  412          req.profile_id = req.profile_id or str(time.time())
```

## min-free-slots delayer (the 11-of-12 cause) — `managers/min_free_slots_delayer.py` lines 1-40

```python
    1  from typing import Optional
    2  
    3  
    4  def resolve_min_free_slots(
    5      user_value: Optional[int],
    6      max_running_requests: int,
    7      is_dflash_family: bool = False,
    8  ) -> Optional[int]:
    9      """Resolve the min-free-slots threshold (None = disabled).
   10  
   11      An explicit user value always wins, capped by max_running_requests
   12      (<= 1 disables). When unset, DFlash workloads fall back to the legacy
   13      formula (preserving the always-on behavior, disabled when
   14      max_running_requests < 8); other workloads stay disabled.
   15      """
   16      max_running_requests = max(0, int(max_running_requests))
   17      if user_value is not None:
   18          threshold = min(user_value, max_running_requests)
   19          return threshold if threshold > 1 else None
   20      if is_dflash_family and max_running_requests >= 8:
   21          return min(4, max(2, (max_running_requests + 5) // 6))
   22      return None
   23  
   24  
   25  class MinFreeSlotsDelayer:
   26      """Delay fresh prefill admissions until at least ``min_free_slots`` running-
   27      request slots free up, batching them into one admission instead of one at a
   28      time. Useful when each admission is expensive (e.g. DFlash's draft prefill).
   29  
   30      Per-rank local: running-batch slots are private to each DP rank, so a rank
   31      with free slots does not wait for a congested peer.
   32      """
   33  
   34      def __init__(self, min_free_slots: int):
   35          self._min_free_slots = min_free_slots
   36  
   37      def should_delay(self, *, running_bs: int, num_allocatable_reqs: int) -> bool:
   38          return running_bs > 0 and num_allocatable_reqs < self._min_free_slots
```

## delayer construction — `managers/scheduler.py` lines 1180-1195

```python
 1180              _,
 1181          ) = self.tp_worker.get_worker_info()
 1182          # DFlash auto-enables the legacy formula; other workloads opt in via
 1183          # --min-free-slots-delay. Built independently of the prefill delayer.
 1184          self.min_free_slots_delayer: Optional[MinFreeSlotsDelayer] = None
 1185          min_free_slots = resolve_min_free_slots(
 1186              get_schedule().min_free_slots_delay,
 1187              self.max_running_requests,
 1188              is_dflash_family=self.spec_algorithm.is_dflash_family(),
 1189          )
 1190          if min_free_slots is not None:
 1191              self.min_free_slots_delayer = MinFreeSlotsDelayer(
 1192                  min_free_slots=min_free_slots
 1193              )
 1194          if not get_parallel().pp_max_micro_batch_size:
 1195              get_context().override(
```

## delayer call site (skipped during a chunked prefill) — `managers/scheduler.py` lines 3845-3862

```python
 3845  
 3846          if (
 3847              running_batch.batch_is_full or len(self.waiting_queue) == 0
 3848          ) and self.chunked_req is None:
 3849              return None, running_batch
 3850  
 3851          running_bs = len(running_batch.reqs)
 3852          # Skipped during a chunked prefill: that pass must proceed regardless.
 3853          if (
 3854              self.min_free_slots_delayer is not None
 3855              and self.chunked_req is None
 3856              and self.min_free_slots_delayer.should_delay(
 3857                  running_bs=running_bs,
 3858                  num_allocatable_reqs=self.get_num_allocatable_reqs(
 3859                      running_bs, running_batch=running_batch
 3860                  ),
 3861              )
 3862          ):
```

## --min-free-slots-delay flag ('1 disables') — `arg_groups/fields/schedule.py` lines 264-280

```python
  264      # -------------------------------------------------------------------------
  265      # Min free slots delay (prefill refill batching)
  266      # -------------------------------------------------------------------------
  267      min_free_slots_delay: A[
  268          Optional[int],
  269          (
  270              "Hold new prefills until at least N running-request slots have freed "
  271              "up, so they are admitted in one batch instead of one at a time. "
  272              "Useful when each admission is disproportionately expensive, e.g. "
  273              "speculative decoding with a separate draft prefill pass. An "
  274              "explicit value always wins, capped by max-running-requests "
  275              "(1 disables). When unset, DFlash workloads auto-enable the "
  276              "formula; other workloads stay disabled. Not supported with "
  277              "pipeline parallelism."
  278          ),
  279      ] = None
```

## return_token_ids (completion request) — `entrypoints/openai/protocol.py` lines 360-365

```python
  360      routed_experts_start_len: int = 0
  361      return_cached_tokens_details: bool = False
  362      return_spec_tokens_details: bool = False
  363      return_token_ids: bool = False
  364  
  365      # Extra parameters for SRT backend only and will be ignored by OpenAI models.
```

## return_prompt_token_ids / return_token_ids (chat request) — `entrypoints/openai/protocol.py` lines 888-895

```python
  888      return_routed_experts: bool = False
  889      routed_experts_start_len: int = 0
  890      return_cached_tokens_details: bool = False
  891      return_spec_tokens_details: bool = False
  892      return_prompt_token_ids: bool = False
  893      return_token_ids: bool = False
  894      return_meta_info: bool = False
  895      return_input_ids_in_sglext: bool = False
```

## choice prompt_token_ids / response_token_ids — `entrypoints/openai/protocol.py` lines 1222-1232

```python
 1222          Literal[
 1223              "stop", "length", "tool_calls", "content_filter", "function_call", "abort"
 1224          ]
 1225      ] = None
 1226      matched_stop: Union[None, int, str] = None
 1227      hidden_states: Optional[object] = None
 1228      prompt_token_ids: Optional[List[int]] = None
 1229      response_token_ids: Optional[List[int]] = None
 1230      meta_info: Optional[Dict[str, Any]] = None
 1231  
 1232      @model_serializer(mode="wrap")
```

## token ids only without streaming — `entrypoints/openai/serving_chat.py` lines 1188-1202

```python
 1188              request.reasoning_effort = reasoning_effort
 1189  
 1190          if request.stream:
 1191              if request.return_prompt_token_ids:
 1192                  raise ValueError(
 1193                      "return_prompt_token_ids is not supported with streaming. "
 1194                      "Please set stream=false when using return_prompt_token_ids=true."
 1195                  )
 1196              if request.return_token_ids:
 1197                  raise ValueError(
 1198                      "return_token_ids is not supported with streaming on "
 1199                      "/v1/chat/completions. Please set stream=false when using "
 1200                      "return_token_ids=true."
 1201                  )
 1202              if request.return_meta_info:
```

## token ids filled into the choice — `entrypoints/openai/serving_chat.py` lines 2380-2420

```python
 2380                      history_tool_calls_cnt,
 2381                  )
 2382  
 2383              # Extract prompt_token_ids if requested
 2384              choice_prompt_token_ids = (
 2385                  ret_item.get("prompt_token_ids")
 2386                  if request.return_prompt_token_ids or request.return_token_ids
 2387                  else None
 2388              )
 2389              choice_token_ids = (
 2390                  ret_item["output_ids"] if request.return_token_ids else None
 2391              )
 2392  
 2393              choice_meta_info = (
 2394                  ret_item["meta_info"] if request.return_meta_info else None
 2395              )
 2396              # NOTE: content should not be None but empty string to make sure retokenize consistency.
 2397              reasoning_text, tool_calls = self._get_parsed_response_fields(
 2398                  reasoning_text, tool_calls
 2399              )
 2400  
 2401              choice_data = ChatCompletionResponseChoice(
 2402                  index=idx,
 2403                  message=ChatMessage(
 2404                      role="assistant",
 2405                      content=text if text else "",
 2406                      tool_calls=tool_calls,
 2407                      reasoning_content=reasoning_text if reasoning_text else None,
 2408                  ),
 2409                  logprobs=choice_logprobs,
 2410                  finish_reason=finish_reason["type"] if finish_reason else None,
 2411                  matched_stop=(
 2412                      finish_reason["matched"]
 2413                      if finish_reason and "matched" in finish_reason
 2414                      else None
 2415                  ),
 2416                  hidden_states=hidden_states,
 2417                  prompt_token_ids=choice_prompt_token_ids,
 2418                  response_token_ids=choice_token_ids,
 2419                  meta_info=choice_meta_info,
 2420              )
```

## null prompt_tokens_details = 0 cached — `entrypoints/openai/usage_processor.py` lines 9-18

```python
    9  class UsageProcessor:
   10      """Stateless helpers that turn raw token counts into a UsageInfo."""
   11  
   12      @staticmethod
   13      def _details_if_cached(count: int) -> Optional[PromptTokensDetails]:
   14          """Return PromptTokensDetails only when count > 0 (keeps JSON slim)."""
   15          return PromptTokensDetails(cached_tokens=count) if count > 0 else None
   16  
   17      @staticmethod
   18      def calculate_response_usage(
```

## token_usage = max of pools; full_token_usage = KV pool — `observability/metrics_collector.py` lines 84-96

```python
   84  
   85      # Memory pool usage ratios (0.0–1.0).
   86      # Each pool tracks: used = total - available - evictable, usage = used / total.
   87      #
   88      # token_usage:      max(full, swa, mamba) — the bottleneck across all pools.
   89      #                   FIXME: misleadingly named "token_usage"; rename requires API deprecation.
   90      # full_token_usage: full-attention KV cache pool usage (always active).
   91      # swa_token_usage:  sliding-window attention KV cache pool usage (hybrid SWA models only, e.g. Gemma2).
   92      # mamba_usage:      Mamba SSM state pool usage (hybrid SSM models only, e.g. Jamba).
   93      token_usage: float = 0.0
   94      full_token_usage: float = 0.0
   95      swa_token_usage: float = 0.0
   96      mamba_usage: float = 0.0
```

## /flush_cache: 200 on success, 400 on failure (build 2) — `entrypoints/http_server.py` lines 987-1002

```python
  987  @app.api_route("/flush_cache", methods=["GET", "POST"])
  988  @auth_level(AuthLevel.ADMIN_OPTIONAL)
  989  async def flush_cache(timeout: float = Query(0.0, ge=0.0)):
  990      """Flush the radix cache."""
  991      ret = await _global_state.tokenizer_manager.flush_cache(timeout_s=timeout)
  992      if ret.success:
  993          content = (
  994              "Cache flushed.\nPlease check backend logs for more details. "
  995              "(When there are running or waiting requests, the operation will not be performed.)\n"
  996          )
  997      else:
  998          content = ret.message or "Flush cache failed.\n"
  999      return Response(
 1000          content=content,
 1001          status_code=200 if ret.success else HTTPStatus.BAD_REQUEST,
 1002      )
```

## retraction counter (build 2) — `observability/metrics_collector.py` lines 470-478

```python
  470              name="sglang:num_retracted_reqs",
  471              documentation="The number of retracted requests.",
  472              labelnames=labels.keys(),
  473          )
  474          self.num_retracted_reqs_total = Counter(
  475              # The name is `requests` instead of `reqs` to avoid dup name error
  476              name="sglang:num_retracted_requests_total",
  477              documentation="Total number of retracted requests.",
  478              labelnames=labels.keys(),
```

## compute_spec_logprobs: top-k logprobs under speculative decoding (build 2) — `layers/logprob_processor.py` lines 386-446

```python
  386  def compute_spec_logprobs(
  387      batch: ScheduleBatch,
  388      logits_output: LogitsProcessorOutput,
  389      predict: torch.Tensor,
  390      *,
  391      accept_index: Optional[torch.Tensor] = None,
  392      chain_stride: Optional[int] = None,
  393  ):
  394      assert (accept_index is None) != (chain_stride is None), (
  395          "pass exactly one of accept_index / chain_stride"
  396      )
  397  
  398      bs = len(batch.seq_lens)
  399      next_token_logits = logits_output.next_token_logits
  400  
  401      if accept_index is not None:
  402          max_accept = accept_index.shape[1]
  403          flat_accept_idx = accept_index.long().reshape(-1)
  404          gathered_logits = next_token_logits[flat_accept_idx]
  405          accepted_token_ids = predict[flat_accept_idx]
  406      else:
  407          max_accept = chain_stride
  408          # Guards the layout contract the identity gather rests on: out token
  409          # (b, j) must come from logits row b * stride + j.
  410          assert next_token_logits.shape[0] == bs * max_accept, (
  411              f"chain layout expects {bs * max_accept} logits rows, got "
  412              f"{next_token_logits.shape[0]}"
  413          )
  414          gathered_logits = next_token_logits
  415          accepted_token_ids = predict
  416  
  417      if batch.sampling_info.is_all_greedy or envs.SGLANG_RETURN_ORIGINAL_LOGPROB.get():
  418          gathered_logprobs = torch.nn.functional.log_softmax(gathered_logits, dim=-1)
  419      else:
  420          temperatures = torch.repeat_interleave(
  421              batch.sampling_info.temperatures,
  422              max_accept,
  423              dim=0,
  424          )
  425          gathered_logprobs = torch.nn.functional.log_softmax(
  426              gathered_logits / temperatures, dim=-1
  427          )
  428      gathered_logprobs.clamp_(min=torch.finfo(gathered_logprobs.dtype).min)
  429  
  430      logits_output.next_token_logprobs = gathered_logprobs.gather(
  431          1, accepted_token_ids.long().view(-1, 1)
  432      ).view(bs, max_accept)
  433  
  434      if batch.top_logprobs_nums and any(x > 0 for x in batch.top_logprobs_nums):
  435          top_logprobs_nums_expanded = [
  436              num for num in batch.top_logprobs_nums for _ in range(max_accept)
  437          ]
  438          (
  439              logits_output.next_token_top_logprobs_val,
  440              logits_output.next_token_top_logprobs_idx,
  441          ) = get_top_logprobs(
  442              gathered_logprobs, top_logprobs_nums_expanded, no_copy_to_cpu=True
  443          )
  444  
  445      if batch.token_ids_logprobs and any(
  446          x is not None for x in batch.token_ids_logprobs
```
