# E14-A audit bundle: optimized engine measurement notebook (2026-10-23)

**Please audit before any GPU run.** Nothing has been pushed to Kaggle yet. This is a CPU-tested build.

## 0. What this is

- **Competition:** Kaggle ARC Prize 2026 / ARC-AGI-2. Hardware is 4× NVIDIA L4 (24 GB, PCIe, no NVLink), offline, a 12 h limit and 240 hidden tasks.
- **Model / engine:** Qwen3.8-27B RedHat INT4 W4A16 + BF16 DFlash2 drafter (block 8) on SGLang 0.5.21, TP4. Called "W1":
  - KV fp8_e4m3, SSM fp16;
  - mamba radix strategy `extra_buffer_lazy`, mamba cache 56;
  - mem fraction 0.83, chunked prefill 4096;
  - server `--max-running-requests 13`, client 12 streams;
  - CUDA-graph decode bs [1..8, 10, 12].
- **Goal of E14-A:** one commit-mode notebook that measures engine levers and adopts only those that pass a speed rule and a correctness gate. A 25-minute Duck-agent run (rev 6g solver, 12 G4B eval tasks) then runs on the adopted arm.
- **Base:** `build_e14.py` executes the E12 rev 6g G4B builder (`build_e12_duck.py`) in memory and patches cells. Nothing in the E12 folders is written. The base notebooks keep their shas, listed in `notes/16 …` §6.

**Notebook:** `notebook/Q27-XHIGH-E14A_OPTIMIZED_ENGINE_SGLANG.ipynb`
- sha256 `a9dad9fcbe0003867d34f205732a23106dbfed30380535ef4531ba78806de494`, 713 kB.
- Embedded modules (sha256 prefix, also asserted at run time in CELL 1b):

| Module | sha |
|---|---|
| `e14_loadpath.py` | 48908f52 |
| `e14_measure.py` | cf7c21de |
| `e14_sglang_patches.py` | 98da9521 |
| `e14_nccl_bench.py` | e820a514 |
| `e14_trace_summary.py` | 8d89ca10 |
| Duck adapter `arc2_duck.py` | 758bddb5 |

- The other 22 Duck package files are embedded by the E12 builder with their own manifest check.
- The notebook is self-contained. The builders are included for reading, but they also read the E11 source notebook and the Duck vendor package (not in this zip, large and unchanged). **Audit the notebook cells directly.**

## 1. Cell map (E14A profile)

| Cell | What |
|---|---|
| CELL 0 | Mode + fallback `submission.json` (unchanged). |
| CELL 1 | Config. Profile **E14A**: 12 tasks, `time_budget_sec` 200 min, `solve_window_sec` 25 min, `e14: True`. |
| CELL 1b (new) | (1) Extracts the modules and checks their sha. (2) Writes the phase record (`e14_state.json`) and a heartbeat. (3) Takes the first-line facts: mounts/GCSFUSE, df, RAM, cgroup, a timed 64 MiB read. (4) Copies the models to `/dev/shm` (fallback `/tmp`) with ranged parallel readers: worker ramp 4→8→16→24, `.partial` + atomic rename, per-64 MiB-range blake2b + sha256 verify, safetensors layout check, cgroup/MemAvailable guard, fail open to `/kaggle/input`. (5) Sets `E12_RAW_REASONING_HISTORY=1`. |
| CELL 2 | Single-stream `cat` prefetch only when staging is off. |
| CELL 4 | Package/tokenizer checks (unchanged). |
| CELL 5 | Engine launch. `SGLANG_JIT_CACHE_DIR` etc. set explicitly. Stall watchdog: progress = log growth + rchar + 4096 × page faults of the server tree (mmap loads are silent). Load-phase stall 900 s, compile-phase stall 720 s (> the ~362 s silent first bs=12 capture). The first launch may run until the 75-min give-up. NCCL bench while the copy runs. |
| CELL 5b (new) A1 | W1 baseline windows (8k "short" and ~40k "long" bands at 12 streams; profiler window; latch test) → E14-P token replay → greedy parity → **+#44401/#41872 backport arm** → **+nodelay arm** (`--min-free-slots-delay 1`) → **+CUDA graphs 1..13 arm** → `/flush_cache` → Duck arm chosen. |
| CELL 6 | Duck rev 6g run, 25 min, 12 workers, KV-only admission gate 0.95. |
| CELL 7 | E12 report. |
| CELL 6b (new) A2 | Agent-like multi-turn replay (Mamba eviction classes) + cache-hit parity → int8 mamba checkpoint arm → target-only arm (DFlash correctness) → DFlash width 6 and 4 → NCCL env arm if the bench found one ≥ 20 % faster. |
| CELL 7b (new) | JIT manifest + cache tar (never ships `sglang/nv` or `cuda`), `e14_report.md`, bundle zip. |

- Each phase has its own cap. Whatever does not fit before HARD_STOP (− 8 min) is skipped and recorded, never squeezed.
- Every relaunch is skipped with < 15 min left. A failed relaunch brings the last good arm back.

## 2. Fix list (everything applied in this build)

| # | Fix | Where | Why |
|---|---|---|---|
| 1 | Every HTTP request's timeout is capped by the phase deadline | `e14_measure.post_json` | E12 T8 (a per-turn timeout ran 679 s past the deadline); E12 PARITY `urlopen(timeout=900)` × 24 probes = up to 6 h |
| 2 | Parity requests still alive at the deadline are aborted | `parity_pass` | Same class |
| 3 | `wait_level` plateau: a window measures at the level the server really runs; `measured_level` / `real_running_reached` recorded | `steady_window` | The DFlash delayer holds W1 at 11 of 12 (see #8); otherwise every W1 window is invalid |
| 4 | Contamination decision against a concurrency-12 A/A noise floor; large-margin flips (top-1 − top-2 > 1 nat) decide | CELL 5b | Under batching even A/A shared only 152–166 of 512 greedy tokens (E11-03) |
| 5 | Every generated cell is compiled and CR-checked before the .ipynb is written | builder | Docstring/quoting traps broke builds before |
| 6 | Profiler with `with_stack: false`, `record_shapes: false` | `profile_steps` | 0.5.21 defaults are true (tokenizer_control_mixin.py:403-410) |
| 7 | NCCL arm only if the bench's `adopt_candidate` (≥ 20 % faster per call at 983,040 B in CUDA graphs) | CELL 6b | Bench API |
| 8 | **nodelay arm** `--min-free-slots-delay 1`, kept only if latch + speed rules pass | CELL 5b | 0.5.21 DFlash min-free-slots delayer: unset → threshold min(4, max(2, (mrr+5)//6)) = 3 at mrr 13, so at 11 running (2 allocatable) the 12th waits = the "11 running + 1 queued" seen in every 12-stream log (−8–9 %). `resolve_min_free_slots`: explicit value, threshold > 1 else None, so 1 disables it. Excerpts in `sglang_0_5_21_excerpts/` |
| 9 | **`post_json` accepts plain-text replies** (`{"text": …}`) | `post_json` | **Real bug:** `/start_profile` answers "Start profiling.\n" (http_server.py:1164-1172). The profiler phase would have died with JSONDecodeError on GPU. Caught by harness run 2 |
| 10 | Per-phase server-log sign counts: "runs out of memory", "Not enough space", "Retract", "out of memory", "Traceback", "Exception" | `e14_phase` | Over-admission / mamba-space check for the nodelay arm; KV thrash visibility |
| 11 | `/flush_cache` before the Duck run (result recorded) | CELL 5b end | The Duck run should start from an empty radix like the hidden run (A1-3 already sent the Duck system prompt + tools). The endpoint exists (http_server.py:987); it refuses while requests run |
| 12 | graphs13 is adopted only if the server's captured verify-graph list holds 12 and 13 (when parsed) | CELL 5b | The resolved list was [1..8, 10, 12] with mrr 13 |
| 13 | A literal CR inside the builder's CR guard line (it broke the build) | builder | — |
| 14 | Watchdog stats report peaks (`rchar_mb`, `faults`); the stall decision is unchanged | `StallMonitor.wait` | One unreadable `/proc/<pid>` sample shrank the reported totals |
| 15 | Fake server `/flush_cache`; 2 new harness checks | `src/harness` | Exercise #10–#12 |
| 16 | Test robustness (no module behaviour change): atomic fake-`/proc` writes; event-based monitor tests (ready = writer done ≥ 3 s > stall 2 s, so they still fail if progress is ignored); slow-copy stall 5 s; parallel test compares `copy_sec`; ramp-saturation window 40 MiB | `src/test_e14_loadpath.py` | On this Windows host file writes take tens of ms; fixed-sleep pacing drifted (122/125 in some runs, with different tests each time) |

**Already in the E12 rev 6g solver** (grep markers present in `duck_arc2/arc2_duck.py`):
- per-request deadline clamp;
- verify budget clamp;
- one join cutoff (`join_until`);
- deep-copied records;
- three-state isolation (`isolation_state`);
- KV-only admission (`kv_admit_limit`) on exact `sglang:full_token_usage` (no `token_usage` fallback);
- regex length guard (`_GRID_ROW_MAX`);
- nudge in the tool result (`harness_note`);
- raw-reasoning switch (E14-P; `duck_arc2/E14-P arc2_duck raw reasoning switch.diff`).

## 3. Checked against code / 0.5.21 source, no change made

| Item | Finding |
|---|---|
| Token-id fields for the E14-P replay | `return_token_ids` (protocol.py:893); the choice carries `prompt_token_ids` / `response_token_ids` (protocol.py:1228-1229); non-streaming only (serving_chat.py:1196-1200). `replay_conversation` reads exactly these. |
| Null `cached_tokens` | Means 0 under `--enable-cache-report` (usage_processor.py). The code uses `int(det.get("cached_tokens") or 0)`; reports Σcached/Σprompt. |
| KV pool | Re-read from each relaunch's server log (`e14_launch` → `ENGINE_INFO["kv_tokens"]`), so the Duck window follows the last arm. |
| JIT cache | Separate `SGLANG_JIT_CACHE_DIR`; `_NEVER_SHIP = ("sglang/nv", "cuda")` (#42917 stale driver cache); restore only on a 13-field fingerprint + known-answer check. |
| Two KV gates | E11's 0.85 gate feeds only the DIRECT solver; Duck uses 0.95 on `sglang:full_token_usage`. |
| Duck window start | Computed when CELL 6 starts, after all A1 phases. |
| vLLM fallback | The Duck notebook has no vLLM engine path. A tokenizer-check failure skips SGLang and the solver fails closed (CELL 0 fallback), so no FP8 load can burn quota. |
| Stale `.pyc` after the backport | Deleted by `e14_sglang_patches`. |
| Latch decision under the real delayer | W1 / #44401 stay at 11 (share_at_target 0, stuck_one_below 0); nodelay can reach 13. The `>=` / `<=` rule keeps a no-change #44401 and lets nodelay pass. **Note:** the fake server does not model the delayer, so harness latch numbers test plumbing only. |
| Relaunch wait `max(60, …)` | Cannot pass HARD_STOP, because launches are skipped with < 15 min left. |
| Penalties, `tool_choice`, `--enable-mixed-chunk`, ReplaySSM, PCIe-IPC | None used. Penalties are a no-op under DFlash in 0.5.21 (#28180); ReplaySSM raises for DFLASH on non-KDA; the PCIe-IPC kernel is missing from FlashInfer 0.6.18. |

## 4. Not built on purpose

1. Long (12,288) thinking-on parity probes and tool-name comparison. Parity is greedy `/generate` token ids + top-2 margins, which is stricter; long probes do not fit 200 min.
2. A 60k context band per arm. Each arm has the 8k and ~40k bands, with `ctx_per_req_p50` recorded.
3. Cosmetic legacy DIRECT config fields in the E12 report (`temperature 0.6`, `MAX_MODEL_LEN 106496`, `THINK_BUDGET 60000`). These are not the Duck settings; rev 6g is frozen.
4. rev 6g metric defects F1 / F2 / H7-11 partial / `publish_seq`: measurement-only; rev 6g is frozen.
5. `--max-mamba-cache-size 64` or mrr 14: only if nodelay does not reach 12, and only after a memory check.

## 5. Only the GPU run answers

1. Real running 12/13 with nodelay; over-admission errors.
2. Whether the #44401/#41872 hunks match the x86_64 wheel (the reference is aarch64; a mismatch is refused, the run continues unpatched).
3. Token-level confirmation of the raw-reasoning fix (A1-3 `first_divergence`; Duck cached fraction vs G4B 75.0 %).
4. The step split and the NCCL transport.
5. Acceptance at width 6 and 4.
6. Mamba eviction with and without int8 checkpoints.
7. `/dev/shm` size, cgroup limit, copy MB/s, ready seconds (G4B on 10-21: 1,197 s).
8. Whether `/flush_cache` succeeds with the hybrid radix cache.

## 6. Tests (logs in `logs/`)

- **Fake-server notebook harness** (`src/harness/harness_e14_nb.py <nb> 0.1`, fake SGLang + fake package, time scale 0.1):
  - run 2: 23/24 (FAIL = fix #9; `logs/e14_harness_run2.log`);
  - **final build: 26/26** (`logs/e14_harness_run5.log`).
- **Unit tests:**
  - `logs/unit_tests_run1..5.txt` = **125/125 five times in a row** (loadpath 56, patches 36, NCCL bench + trace 33);
  - `logs/unit_tests_before_timing_fixes_122of125.txt` is the run that led to fix #16.
- `logs/test_raw_reasoning.txt`: 15/15.
- **Reproduce:**
  - unit tests: `python -m pytest -q -p no:cacheprovider --noconftest --rootdir=. --confcutdir=. --import-mode=importlib src/test_e14_*.py`;
  - harness: needs `transformers` + a Qwen tokenizer fixture.

## 7. Run plan to judge

- **Account:** hosen42, 8.63 h quota at the last reading on 10-22; re-check before the push. 4×L4 bills 2× wall time.
- **Time:**
  - normal ≈ 145–165 min wall (≈ 4.9–5.5 quota-h);
  - worst = the 200-min budget + Kaggle start/save ≈ 210 min (≈ 7.0 quota-h).
  - The first launch can take up to 75 min on slow GCSFUSE days; later phases are then skipped.
- **External stop rule:** still RUNNING 215 min after the push = a platform stall.
- **Risk that no notebook guard covers:** on 10-22 a run ended in ERROR after ~114 min with an empty log (Kaggle never started our code).

## 8. Questions for you (GPT)

1. Find any defect that would make a phase invalid or the run exceed the budget. File + line, and a reproduction if possible.
2. Is the latch-test adopt rule for nodelay / #44401 (§3) right under the real delayer? Is a better single metric "share of samples with running ≥ 12 and queue ≥ 1"?
3. Is `/flush_cache` before the Duck run safe on 0.5.21 with `extra_buffer_lazy` hybrid radix + mamba? Any known issue?
4. Is a greedy-parity allowance of 2 identical prompts below the c12 A/A, plus 0 large-margin flips (> 1 nat), a sound correctness gate for the nodelay / graphs / width / int8 arms?
5. Do the width 6 / 4 arms need anything beyond `--speculative-num-draft-tokens` with this drafter (block_size 8, `is_causal` false)?
6. Is anything in the A2 order wasteful for quota? What would you drop first if hosen42's quota is lower than 7 h?

Please give a GO / NO-GO for this exact sha, plus a list of must-fix items (if any), separated from nice-to-haves.
