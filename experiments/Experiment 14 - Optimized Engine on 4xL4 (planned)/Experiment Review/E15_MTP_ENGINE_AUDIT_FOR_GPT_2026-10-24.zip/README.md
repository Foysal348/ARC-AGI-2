# E15: Engine experiment (MTP, more streams, the 11-of-12 fix) — README

**Notebook:** `Q27-XHIGH-E15_MTP_ENGINE_DUCK_SGLANG.ipynb`
- sha256 `2007cba65cf058091d4c13eb216853957cdbfa58e1b05ea36cc53a98dfeb4177`, 246 kB (under the 400 kB commit limit)
- Built with `build_e14.py --e15`

**Validation before GPU:**
- local harness: e15 mode 22/22, rerun mode 14/14 (Python 3.12);
- Kaggle CPU kit (same pinned image, Py 3.12.13, foysal v7): pytest 167/167, e15 22/22, rerun 14/14.

**Payload:**
- `q27x_e14_modules_78029e146cd3.bin` (E14 modules; without the #43567 patch);
- `q27x_e12_duck_6f48b81af59a.bin` (Duck rev 6g).

**Plan:** account esfersami50 (quota 30 h); budget 180 min (hard stop 178 min); quota about 4-7 h.

## Why this experiment

- **The 12-hour run is coverage-bound.** At the hidden time share each task gets about 49k tokens, and 89-110 of the 240 tasks stay below 60k.
- **What the submitted engine has now:**
  - SGLang 0.5.21, RedHat INT4 + DFlash2 width 6, graphs 1..13;
  - 12 streams, but **only 11 really run** (DFlash min-free-slots delayer, about 8-9 % lost);
  - **KV usage only 18-41 %** (memory is left unused).
- **Questions:**
  1. How many streams can really run?
  2. Is MTP better than DFlash2?
  3. Does accuracy drop as concurrency rises?

## Test by test: what each gives us

The first launch is the submission arm (the reference). After that every arm is a new launch, in this order:
1. correctness gate (6 serial + 12 concurrent × 256 greedy tokens, compared with the reference A/A; large-margin flips decide);
2. 8k-context window (75 s) and 41k-context window (75 s), at the measured running level;
3. latch test and long probe where listed.

| # | Arm | Flags (change from the reference) | What we learn | Decision use |
|---|---|---|---|---|
| 0 | `ref_w6g13` (reference) | DFlash2 width 6, graphs 1..13, mrr 13, mamba 56, fp16 SSM, FP8 KV | Current speed (tok/s, step ms, accept), KV, latch (11 or 12 under churn) | The reference for every comparison |
| 1 | `E15_probe_ref` | — | c12 × 1,024-token greedy probe, run twice (A/A) | Noise floor for the long probe |
| 2 | `target_only` | no `--speculative-*` | The same long probe without speculation | Does DFlash change the output? (#36548 / #38009 class) |
| 3 | `w8` | `--speculative-num-draft-tokens 8` | Width 6 vs 8, including 41k context (never measured for W6) | Whether W6 stays in the submission |
| 4 | `w6_mrr14` | mrr 14, graphs 1..14 (delayer kept) | Whether the 11-of-12 latch goes away (at 11 running, 3 slots are free) | Fix 1 for the 11-of-12 loss |
| 5 | `w6_nodelay_mrr12` | `--min-free-slots-delay 1`, mrr 12 | The same, with the delayer off (13 running is impossible, so no crash) | Fix 2 |
| 6 | `w6_at14` | mrr 17, mamba 68, graphs 1..17; level 14 | Do 14 streams really run? Total tok/s, KV, long probe at c14 | More streams for coverage |
| 7 | `w6_at16` | mrr 20, mamba 80, graphs 1..20; level 16 | The same at 16 | |
| 8 | `w6_at20` | mrr 24, mamba 96, graphs 1..24; level 20 | The same at 20 (KV ~740k → ~37k per stream) | Upper limit |
| 9 | `mtp_3_1_4` | EAGLE (built-in MTP), steps 3, topk 1, draft tokens 4, draft path = INT4 dir | MTP speed, accept, KV (predicted ~1.2 M), long probe | MTP vs DFlash2 |
| 10 | `mtp_3_1_4_mem86` | + `--mem-fraction-static 0.86` | Extra KV from memory | |
| 11 | `mtp_2_1_3` | steps 2, draft tokens 3 | Cheaper verify: faster? | |
| 12 | `mtp_replay_fp32` | + `--enable-linear-replayssm-spec`, SSM fp32 | ReplaySSM memory/speed, fp32 accuracy | |
| 13 | `mtp_replay_fp16` | + ReplaySSM, SSM fp16 | The same at fp16 | |
| 14-15 | `<best MTP>_at14`, `_at16` | mrr 15/17, mamba 60/68, graphs 1..mrr | Does MTP run more streams? | |
| end | Duck run (15 min, 12 G4B tasks) | The fastest 12-stream arm that passed the gate and probe, with long tok/s ≥ 0.98 × reference; a passing latch fix replaces the reference | Real agent work: tok/s, cache, solves | The engine for the next submission |

**Adoption rules (in the code):**
- gate PASS;
- no server error signs;
- probe large-margin flips ≤ reference A/A + 1;
- a latch fix needs latch ≥ 12 in ≥ 50 % of samples and short tok/s ≥ 0.98 × reference.

**When time runs short:** arms are skipped from the end (the MTP 14/16 arms first). The Duck reserve is never touched.

## What we will know at the end

1. **The 11-of-12 fix:** which flag really runs 12 under churn.
2. **More streams:** total tok/s and KV at 12 / 14 / 16 / 20 streams. This is the main coverage lever.
3. **Correctness:** DFlash vs target-only, and whether it gets worse with more streams (long probe).
4. **MTP vs DFlash2:** speed, accept and KV.
5. **Width 6 at long context.**
6. **A real Duck run** on the chosen arm.

## Known limits (from the review agents; the accuracy tests will be in a separate E17)

- **The greedy probe is weak:**
  - logits are bf16, so margins come in 0.125-nat steps, about 1 % of tokens are exact ties, and runs diverge after a median of 30-75 tokens;
  - only the first divergence is compared, so each prompt really checks about 50 tokens.
  - It catches large corruption only. Fine accuracy loss goes to E17 (teacher-forced score packs, nucleus audit, cache-restore parity).
- **The #43567 stale lazy mamba checkpoint bug is not patched here.** The patch is built and tested (`e14_sglang_patches` "43567", 171/171 unit tests) and will be tested in E17.
- **14/16/20 streams are measured on the server only.** The Duck run uses 12 streams. Running Duck at N streams needs a builder option (next step).
- **Untested side effects:**
  - chunked prefill 2048, mixed chunk and torch compile are not in E15;
  - more mamba slots shrink the KV pool (the measured KV value is recorded).

## Files in this zip

| File | What it is |
|---|---|
| `00_GPT_PROMPT.md` | Audit request |
| `README.md` | This file |
| `notebook/Q27-XHIGH-E15_MTP_ENGINE_DUCK_SGLANG.ipynb` | The notebook to run |
| `notebook/notebook_cells.py`, `notebook/E15_cell_5c.py` | Readable code: all cells, and the E15 cell |
| `code/build_e14.py` | The builder |
| `code/src/` | E14 modules (`e14_measure.py`, `e14_loadpath.py`, `e14_sglang_patches.py`, …) — current workspace version, which includes the 43567 hunk; the notebook's payload uses the older 78029e146cd3 zip |
| `code/payload/q27x_e14_modules_78029e146cd3.bin` | The exact module zip the notebook uses |
| `code/harness/` | CPU harness + fake server |
| `evidence/` | R2 results (Notes/30), E14S commit (Notes/31), the GPT R2 validation answer (Notes/34), MTP preflight (Notes/35), 4-day review (Notes/37), CPU harness reports, harness logs |
