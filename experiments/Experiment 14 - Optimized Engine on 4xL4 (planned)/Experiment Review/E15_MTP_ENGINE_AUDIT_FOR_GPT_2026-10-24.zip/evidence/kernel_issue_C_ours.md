# C — Does our serving stack lose accuracy silently? Evidence from our own data (2026-10-24)

Scope: read-only. Nothing in the project was changed and nothing was run on Kaggle. I wrote one scratch helper: the 5 unfenced E11-05 answers, run on CPU in `_scratch/kernel_issue/bare_code/`.
Tags: **[V]** = I verified it in files, logs or source in this session. **[I]** = inferred. **[P]** = from an earlier project note that I did not re-derive.

Abbreviations:
- vLLM = vLLM 0.19, FP8 checkpoint, MTP-3, fp8 KV, TP4.
- SGL = SGLang 0.5.21, RedHat INT4, DFlash2 W8, fp16 SSM, extra_buffer_lazy, fp8 KV, TP4. This is "W1".
- R5 / D66 / L66 / W3H = vLLM Poetiq runs. E11-05 / E11-06 = SGL Poetiq runs.

Run folders:
- `EXP10 = experiments/Experiment 10 - Q27-XHIGH Poetiq Code-Verify attempt_2 (planned)/Experiment Results/Kaggle Runs`
- `EXP11 = experiments/Experiment 11 - SGLang 0.5.21 + RedHat INT4 + DFlash2 (planned)/Experiment Results/Kaggle Runs`
- `R2 = experiments/Experiment 14 - Optimized Engine on 4xL4 (planned)/Experiment Results/Kaggle Runs/E14A SLIM R2 run1 (hosen42, 2026-10-23)`

---

## 0. Headline (short)

1. **NEW, [V]: E11-06 (P1-60K on SGL) had the model emit EOS in the middle of its thinking in 10 of 44 iterations.**
   - All 10 are at iteration ≥ 2 (10 of 30). 8 of 10 stop mid-line inside code, for example `-> np`<EOS> twice and `0 <= nx <`<EOS>.
   - vLLM xhigh with the S1 prompt never does this: 0 of 432 phase-1 requests (R5, D66, L66).
   - SGL with the S1 prompt (E11-05, 49k cap): 0 of 88.
   - So the E11-06 analysis line "39/44 forced at the 60k cap" is wrong. The real split is 21 cap hits, 10 EOS mid-thinking and 8 drain aborts.
   - The events cluster by task (20a9e565: 3 of 3 later iterations, 6e4f6532: 4 of 4). The signature matches vLLM low-effort W3H (93 of 125 EOS mid-thinking). Both point to prompt/context-triggered model behaviour, not random kernel corruption **[I]**. It is not proven, because P1 never ran on vLLM.
2. **NEW, [V]: SGL produced unfenced code (no ```python fence) in 5 of 88 E11-05 iterations; vLLM did so in 0 of 432 with the same S1 prompt (Fisher p = 1.3e-4).**
   - Those iterations are lost to the parser: no program, no feedback.
   - This is the only statistically solid behavioural difference between the stacks in our data. It shows the SGL/INT4 output distribution is shifted, but it does not tell which component causes it.
3. **On eval, iteration-1 accuracy is the same once the thinking cap is matched [V]** (counts are small).
   - Cap-forced train-pass: SGL 4/39 (10 %) vs vLLM 19/124 (15 %), p = 0.60.
   - On the same tasks, the 2 natural train-passes R5 had under 49k (136b0064, bf45cf4b) are exactly SGL's 2 natural passes.
   - No eval number we have shows a per-request accuracy loss. None of them could detect a 2–5-point loss either.
4. **FP8 KV scales, from the source [V] (runtime not verified):** the target very likely uses the calibrated checkpoint scales (0.0214–0.254), not 1.0.
   - The "no scaling factors → 1.0" warning is generic. It checks only `--quantization-param-path`.
   - The calibrated path saturates at ±448 × scale (torch 2.14 CPU test: 449–1e4 → 448). It never produces NaN.
5. **Our DFlash correctness gates are much weaker than they look [V].**
   - Logits are bf16. The top-1/top-2 margins come in 0.125-nat steps; 1.0 % of greedy tokens are exact ties and 2.1 % are one step apart.
   - So greedy runs diverge after a median of 30–75 tokens.
   - The gate looks only at the first divergence. A "c12 × 1,024" probe therefore checks about 50 tokens per prompt.
6. **The LB gap is real but confounded [V/P]:**
   - vLLM S1 cap series: 34.58 (60k), 31.81 (55k), 32.08 (49k); mean 32.8.
   - E11-06 (SGL + P1 prompt): 29.17, i.e. −3.7 vs the mean, about 2 sd (LB sd ≈ 1.5).
   - SGL ran 35 % faster on eval (379.9 vs 280.9 tok/s), so coverage should have favoured SGL.

---

## 1. Every measured comparison bearing on accuracy

### 1.1 Leaderboard
| Run | Engine | Prompt / cap | LB | Source |
|---|---|---|---|---|
| S1-60K | vLLM FP8 MTP-3 | S1 (R5 donor + fixes), 60k, T 1.0 | **34.58** | memory/project; E10 README §S1 |
| S1-55K | vLLM | S1, 55k | 31.81 | memory (10-21 correction) |
| S49 | vLLM | S1, 49,152 + cells tie-break | 32.08 | memory 10-18 |
| R5 | vLLM | R5, 77.8k | 21.39 (coverage-bound) | memory |
| **E11-06 P1-60K** | **SGL W1** (INT4 + DFlash2 W8 + fp16 SSM) | **P1 prompts**, 2-program feedback, stable order, 60k, drain 8 min | **29.17** | memory 10-20 |

- **Confounds in 29.17 vs 34.58 [V]:** the prompts changed (P1 vs S1), the feedback went from 5 programs to 2, and the example order is stable instead of shuffled. The only engine-flag difference between E11-05 and E11-06 is server `max_running_requests` 12 → 13 (server_args diff, 520 keys).
- **LB/eval:** E11-06 eval task-norm on EVAL14 was 35.7 %, against LB 29.17.

### 1.2 Eval accuracy (same tasks)
| Comparison | Numbers | Verdict |
|---|---|---|
| E11-05 EVAL30, SGL S1 49k vs R5 vLLM 77.8k | 11/48 (task-norm 23.3 %) vs 16/48 (33.3 %) | Confounded by the cap and by ≤ 5 vs ≤ 2 iterations (`EXP11/../E11-05 run1 analysis`) |
| Iteration-1 train-pass, same 30 tasks [V] | SGL 4/30; R5 11/30. HARD-22 subset: SGL 1, R5 4, D66 2, L66 9. R5-solved-8 subset: SGL 3, R5 7 | The cap explains it: within vLLM, the same 22 tasks give 2 (77.8k) vs 9 (122.9k) |
| Cap-matched view [V] | R5 tasks that closed naturally ≤ 49,152 and train-passed = {136b0064, bf45cf4b}. SGL's natural train-passes = the same two; SGL added 2 more from forced closes | No visible deficit |
| Cap-forced train-pass at iteration 1 [V] | SGL: E11-05 2/28 + E11-06 2/11 = 4/39 (10 %). vLLM: R5 13/67, D66 5/49, L66 1/8 = 19/124 (15 %) | p = 0.60 |
| E11-06 P1 vs E11-05 S1 on SGL, same 14 tasks | 7/22 (5/14) vs 5/22 (4/14) | +1 task, noise |
| Sanity 8 easy puzzles (DIRECT, T 0.6) | E11-03 C (fp32 SSM) 7/8; E11-04 W1 (fp16) **8/8**; W2 (bf16) 7/8; FP8 expectation 6.74 | Easy tasks only, no long contexts (`EXP11/E11-03…/e11_03/report.md`, `E11-04…/e11_04/report.md`) |
| E11-05 S1COMMIT4 | 4/4 | Easy |

### 1.3 Thinking length (the INT4 "thinking inflation" question)
- **Sanity 8 puzzles, all natural closes [V]:**
  - SGL totals: C 216,448, W1 219,915, W2 233,488.
  - Against the single FP8 ORDER2 run the builder uses (180,598, `build_e11_03_gpu_validation.py:85-89`), that is 1.20 / 1.22 / 1.29×. That reference is biased: the puzzles were picked as cheap from that run.
  - Against the mean over **all** vLLM DIRECT natural closes in our records (n = 1–6 per puzzle, 202,025): **1.07 / 1.09 / 1.16×**.
  - 136b0064 alone ranges 23.2–37.6k on vLLM, against 44.7k / 20.0k / 21.8k on SGL. Not significant.
- **Poetiq iteration 1, natural close ≤ 49,152 on the same tasks [V]:** SGL 2/30 vs vLLM (R5 + D66 + L66 pooled) 5/74 (p = 1.0).
- **Paired natural lengths [V]:**
  - 136b0064: 40.4k SGL vs 48.5k R5.
  - bf45cf4b: 38.7k vs 33.7k.
  - 1818057f: 20.0k vs 26.4k.
  - 2ba387bc: 29.0k vs 28.0k.
  - 58490d8a: SGL cap at 49k vs R5 natural 38k.
  - bf45cf4b in S1COMMIT4: SGL cap at 49k vs 33.7k.
- **Verdict:** no measurable inflation. +10–15 % cannot be excluded (the literature reports +3.7–14 %).

### 1.4 How phase 1 ended (EOS, cap and drain)
| Run | Engine / prompt | Phase-1 requests | Natural `</think>` | Cap hit | **EOS mid-thinking** | Drain/hard stop |
|---|---|---|---|---|---|---|
| R5 | vLLM / R5 | 172 | 64 | 89 | **0** | 15 (all finished at 701–703 min = drain; scheduler aborted 0) |
| D66 | vLLM / S1 | 151 | 34 | 101 | **0** | 15 drained + 14 hard stop (`p1_finish` field) |
| L66 | vLLM / S1, 122.9k | 123 | 100 | 10 | **0** | 12 drained |
| W3H | vLLM / S1 **low** | 125 | 19 | 0 | **93** | 13 |
| E11-05 | SGL / S1, 49k | 88 | 4 | 75 | **0** | 8 drain aborts |
| E11-06 | SGL / **P1**, 60k | 44 | 5 | 21 | **10** | 8 drain aborts |

Details of the 10 E11-06 events [V] (`EXP11/E11-06…/q27x/poetiq_thinking/*.txt`, `sglang_requests.jsonl` finish = `stop` with no `</think>`):

| Task | Iteration | Phase-1 tokens | Absolute position | Accept |
|---|---|---|---|---|
| 20a9e565 | 2 | 41,734 | 54.3k | 5.03 |
| 64efde09 | 2 | 52,495 | 65.0k | 5.33 |
| 6e4f6532 | 2 | 56,924 | 69.6k | 5.59 |
| 21897d95 | 2 | 49,624 | 60.6k | 5.31 |
| 20a9e565 | 3 | 52,253 | 66.4k | 5.19 |
| 6e4f6532 | 3 | 41,036 | 57.0k | 5.34 |
| 135a2760 | 3 | 50,420 | 58.9k | 5.57 |
| 6e4f6532 | 4 | 43,459 | 59.6k | 4.93 |
| 20a9e565 | 4 | 49,914 | 64.3k | 5.10 |
| 6e4f6532 | 5 | 25,760 | 41.1k | 5.06 |

- **Where the model stopped [V]:** the tails end inside code in 8 of 10, e.g. `row_ext_m = r_max_m - r_min_m + 1`, `if 0 <= ny < h and 0 <= nx <`, `if t`, `def transform(grid: np.ndarray) -> np` (2 tasks). Two end inside a bullet list (`-`).
- **Clustering [V]:**
  - 20a9e565: iterations 2, 3 and 4 all stopped (3 of 3).
  - 6e4f6532: iterations 2–5 all stopped (4 of 4).
  - 4c416de3, 2b83f449, 4c7dc4dd and 62593bfd: 0 of their 7 later iterations stopped.
- **Outcome [V]:** EOS iterations averaged train score 0.504 (1 of 10 passed), against 0.53 (2 of 21) for cap hits.
- **Statistics [V]:**
  - Below 49,152 tokens, the only range E11-05 could see: E11-06 4/30 vs E11-05 0/58 at iteration ≥ 2 (p = 0.012).
  - E11-06 vs vLLM xhigh: 10/44 vs 0/432 (p < 1e-6).
- **Phase 2 (answer) [V]:** vLLM 1 answer cut at 8,192 tokens (D66 f560132c i2; fenced but unclosed, so unparsable). SGL 0 of 123 answers hit the cap. Prefix-cache reuse in phase 2: median 99.7 %, minimum 9.3 % (E11-05) / 99.4 % (E11-06).

### 1.5 Answer-parse failures [V]
| Run | Iterations without a program | Cause |
|---|---|---|
| R5 / L66 | 0 / 172, 0 / 123 | — |
| D66 | 15 / 151 | 14 hard stops + 1 answer cut at 8,192 |
| **E11-05 (SGL, S1)** | **5 / 88** | **Valid code without the ```python fence** after `</think>` (898e7135 i1, de809cff i2, b6f77b65 i2, 4c3d4a41 i2, 21897d95 i4); 4 were cap forced closes, 1 a drain |
| E11-06 (SGL, P1 asks for the fence explicitly) | 0 / 44 | — |

- **Fisher test:** unfenced answers with the same S1 prompt, SGL 5/88 vs vLLM 0/432, p = 1.3e-4.
- **Recovery check:** I ran the 5 recovered programs on CPU (`_scratch/kernel_issue/bare_code/`). None passes train. b6f77b65 gets 1 of 3 test inputs right, so a lenient parser could have given at most a partial attempt.
- **Syntax errors:** R5 0/172; D66 2/136; L66 1/123; E11-05 1/83; E11-06 2/44 (one is `-> np.ndarray):`, right after an EOS-mid-thinking).

### 1.6 Speculation acceptance [V]
- **vLLM R5 MTP-3** (`EXP10/…R5…/q27x/poetiq_vllm_metrics.json`, last row): 4,360,939 drafts and 7,287,217 accepted, i.e. 1.67 accepted per step (2.67 tokens per step). Per position: 73.4 / 53.7 / 40.0 %.
- **SGL DFlash W8, per-request accept:**
  - E11-05: median 3.71, range 3.19–5.70 over 88 requests > 5k tokens.
  - E11-06: median 4.63, range 3.40–5.95.
  - **No request collapsed toward 1**, which a corrupted target state would cause.
- **SGL INT4 MTP** (E11-03 B, short prompts): accept length 3.05 (of 4).
- **R2 short band:** W8 4.86, W6 4.24, W4 3.27. W8 long band 4.62.

### 1.7 Parity, contamination and cache tests [V]
- **E11-03 greedy common prefix (of 512 tokens):** B (MTP) vs A 152; C (DFlash) vs A 155; D (fp16 SSM) vs C (fp32) 166.
- **E11-03 contamination:** 0/4 identical, prefix 12–22 tokens, outputs stayed on task.
- **E11-04 greedy:** W2 (bf16) vs W1 41.5; W3 (fp32) vs W1 44.0. Marker test W1: 8/8 own codes, no leak. Solo repeat 4/4 identical. Solo vs batch prefix 27.5.
- **R2 (`R2/e14_results.json`):**
  - D (W1) serial A/A: 12/12 identical.
  - c12 A/A: 1/12 identical, divergence median 65 tokens.
  - Serial vs c12: 1/12, median 74.
  - Target-only gate: serial 3/6 identical vs A/A 2/6; concurrent 4/12 vs A/A 5/12.
  - W6 and W4 gates PASS.
  - **0 large-margin flips anywhere. Every first divergence is at a margin ≤ 0.25 nat.**
- **Margin resolution (`R2/bundle/e14/e14_parity_outputs.jsonl`, 67,584 greedy tokens):** margins come in 0.125 steps, which means bf16 logits (`enable_fp32_lm_head False`). 1.0 % of tokens are exact ties and 2.1 % are at 0.125. So greedy parity cannot get past about 50 tokens, and `compare_passes` (`src/e14_measure.py:512-542`) checks only the first divergence.
- **Cache parity (R2 A2-1):** fresh vs cached prefix 1/6 identical, median 31, 0 large flips. Serial A/A on the A2 arm is 2/6, against 12/12 in A1-4. This suggests cached and fresh prefill take different numeric paths **[I]**.
- **E11-04 long-prefix continuation:** 0 cached. Those samples were aborted requests, which is a test artifact.

### 1.8 Source facts (SGLang 0.5.21, `_scratch/session_1c6db7aa/sgl_src/src/sglang/srt`) [V]
- **DFlash sampling verify** (`speculative/dflash_utils.py:985-1127`):
  - `tree_speculative_sampling_target_only`, draft probs = 0 (one-hot draft), target probs after top-k → top-p renormalisation.
  - Acceptance thresholds `speculative_accept_threshold_single/acc` default 1.0 (`arg_groups/fields/spec.py:108-115`); both E11-05 and E11-06 logs show 1.0. So the scheme is exact in theory.
  - Logprobs for DFlash come from the target verify logits (`speculative/dflash_worker_v2.py:2839`, `layers/logprob_processor.py:386-443`). This makes the "nucleus audit" in §3 possible.
- **SSM dtype:**
  - The checkpoint says `text_config.mamba_ssm_dtype: float32`; we override with `--mamba-ssm-dtype float16`.
  - SGLang warns only for ReplaySSM with non-fp32 (`arg_groups/attention_hook.py:417-434`).
  - NguyenThanhNhan (LB 65.97) runs SGLang FP8 + MTP with **float32** SSM, extra_buffer and chunk 2048 (E14 Notes/24).
- **FP8 KV scales:**
  - The warning comes from `load_kv_cache_scales()` (`model_executor/model_runner_components/load_model_utils.py:114-136`), which checks only `quantization_param_path`.
  - Independently, `CompressedTensorsConfig.get_quant_method` attaches `CompressedTensorsKVCacheMethod` to every `RadixAttention` when the scheme is a static, symmetric, per-tensor float8 (`layers/quantization/compressed_tensors/compressed_tensors.py:207-221, 1179-1196`).
  - RedHat's scheme is `{type float, num_bits 8, strategy tensor, symmetric true, dynamic false}`, so it is supported (`_scratch/session_1c6db7aa/e11_03_harness/run_main/input/.../w4a16-g128/1/config.json`).
  - `QWEN3_5_KV_SCALE_MAPPER` maps `.self_attn.k_scale` → `.attn.k_scale` (`models/qwen3_5.py:1575-1583`), applied in `Qwen3_5ForConditionalGeneration.load_weights` (`:2312`).
  - The E11-06 log has 0 "not found in params_dict" lines.
  - `BaseKVCacheMethod` turns the scales into `k_scale_float` (`layers/quantization/kv_cache.py`). FlashInfer writes with `layer.k_scale` and reads with `k_scale_float` (`layers/attention/flashinfer_backend.py:950-953, 1388, 1520`).
  - ⇒ **[I]** The target uses calibrated scales of 0.0214–0.254 (E11-04 read 32 tensors). The BF16 draft has no scheme and uses 1.0, which explains the second warning at 19:09:17.
  - vLLM FP8 ran with 1.0 [P: E11-03 analysis].
  - The write is `div_(scale).to(fp8)` (`mem_cache/memory_pool.py:2620-2626`). Torch 2.14 CPU saturates out-of-range values to 448 (no NaN), so clipping starts at |k| > 448 × scale (≈ 9.6 for the smallest scale).
  - `get_weights_by_name` is not implemented for Qwen3.5, so the scales cannot be read back at runtime without a patch.
- **Strict thinking:** `--enable-strict-thinking` (off in our runs) masks `<|im_end|>`, `<|endoftext|>`, `<tool_call>` and `</tool_call>` during thinking for the qwen3 parser (`parser/reasoning_parser.py:455-470`, `constrained/reasoner_grammar_backend.py`). It needs a grammar backend; it is untested with DFLASH and with `/generate` input_ids.
- **Sampling defaults:**
  - `sampling_defaults='model'`. The INT4 `generation_config.json` = T 1.0, top_p 0.95, top_k 20, EOS [248046, 248044], no penalties.
  - Our requests send T 1.0, 0.95, 20 on both engines (E11-06 `poetiq_run_report.json`; R5 config).
  - Chunked prefill is 4,096 on both engines.

---

## 2. Ranked hypotheses for a silent accuracy loss

Ranking = prior plausibility × how weakly our data excludes it.

| # | Hypothesis | For (our data) | Against (our data) | Status |
|---|---|---|---|---|
| 1 | **INT4 weights shift the distribution** (RedHat W4A16 g128) | Unfenced code 5/88 vs 0/432, same prompt, p = 1e-4: the clearest proof that the SGL stack's outputs differ from FP8. Sanity thinking +7–16 % (ns). Literature −1.3 pts on AIME/GPQA, larger on hard tasks [P] | Cap-matched iteration-1 eval shows the same natural passes and forced pass 10 vs 15 % (ns). Sanity 7–8/8 ≥ 6.74. MTP accept on INT4 is healthy (3.05) | Open. Most likely source of a real 1–3 pt loss [I] |
| 2 | **fp16 SSM state vs fp32** (config says fp32) at 40–70k-token decode | Mechanism: the state is rounded to fp16 once per verify step, and long-memory heads amplify the error. Never measured past ~45k. The 65.97 competitor uses fp32 | Short-context drift fp16 ≈ fp32 ≈ bf16 (166 / 44 / 41.5 prefixes). Sanity 8/8 | Open, untested where it matters |
| 3 | **Mid-thinking EOS** (prompt-triggered model behaviour, maybe amplified by the stack) | 10/44 on SGL P1; 0/432 on vLLM S1 | Clustered by task, mid-line stop = the W3H-low signature on vLLM. EOS iterations score like cap hits (0.50 vs 0.53) | Probably the P1 prompt, not a kernel **[I]**. P1 never ran on vLLM |
| 4 | **DFlash verify / concurrency corruption** (#36548 class) | The public report: 111/304 wrong at c8, and 37/304 even with width 4 or fp32 SSM. Our gate effectively checks ~50 tokens per prompt | Source: exact rejection sampling, thresholds 1.0. Marker PASS. Contamination stays on task. 0 large flips. No accept collapse | Weakly excluded |
| 5 | **Radix / Mamba lazy-checkpoint restore** (every Poetiq answer reuses 98–99.7 % of a long prefix) | Restore at 60k never parity-tested. Cached vs fresh numerics differ (1/6 identical) | Divergences only at near-ties (short prompts). Forced-answer pass rates comparable | Open at long length |
| 6 | **FP8 KV scales** | The source says the target runs calibrated scales (clipping risk above 448 × scale); vLLM ran 1.0 | Coherent outputs; no NaN path (saturating cast) | Low as a *differential* cause; verify the runtime scale |
| 7 | **Parser loss** | Measured: 5.7 % of S1 iterations lost on SGL; 1 answer cut on vLLM | Recovered value ≈ 0–1 hits per 30 tasks | Certain but small; trivial fix |
| 8 | **Prompt P1 vs S1** (not a kernel, but the main confound of 29.17) | P1 changed the prompts, the feedback size and the order; it produced the EOS behaviour | EVAL14 P1 +1 task vs S1 on SGL | A confound to remove before blaming the engine |
| 9 | Chunked prefill | — | 4,096 on both engines | Lowest |
| 10 | Temperature / sampling | — | Identical T 1.0 / 0.95 / 20 on both; generation_config the same | Not a candidate |
| 11 | Hidden-pool-only failure (mikelou1's class: CV 60 → LB 40; submissions run on a different pool) | Unobservable offline | — | Only the LB can show it |

---

## 3. Cheapest decisive test per hypothesis

All GPU items are arms in the E15 notebook. It already has a target-only launch and a c12 × 1,024 greedy probe.
- **Reference arm "R":** target-only, `--mamba-ssm-dtype float32`, `--kv-cache-dtype auto` (bf16), small mrr, cache flushed.
- **Memory:** bf16 KV is 16 KB per token per GPU, i.e. about 1.6 GB per GPU at 100k tokens [I].
- **Throughput assumption:** cold prefill ≈ 1.4k tok/s (E11-03 longctx), so ~4 min per 360k tokens.

| Test | What exactly | Decides | Cost |
|---|---|---|---|
| **Q0 (CPU, today)** | (a) Lenient parser: accept bare code after `</think>`; replay every saved answer. (b) Build token packs: 6 vLLM traces (R5/D66 iteration 1, prompt + thinking, 50–65k) + 6 SGL traces + the 10 E11-06 EOS contexts. Rebuild the P1 prompts with the notebook's own functions; the recorded `prompt_tokens` is the checksum. (c) Add `EOS-without-</think>` and `unfenced` counters to every future run report | #7, and prepares Q1/Q5 | ~1–2 h CPU, 0 GPU |
| **Q1 Score pack (teacher forcing, prefill)** | `/generate` with input_ids, max_new 1, `return_logprob`, `logprob_start_len`=prompt length, `token_ids_logprob`=[248046, 248044, `</think>`]. Arms: R, R with relaunch (A/A), production W6 (fp16 SSM, fp8 calibrated), production + fp32 SSM, production + bf16 SSM, production + fp8 forced 1.0 (sitecustomize patch of `BaseKVCacheMethod.process_weights_after_loading`), chunk 2048. Metric: mean NLL per token by 8k bucket, mean \|Δlogp\| vs R, top-1 disagreement rate; pass = within R A/A noise | #2 (prefill-side storage only), #6, #9 | ~4–5 min per arm + ~75 s per relaunch; ≈ 35 min for 6 arms |
| **Q2 Nucleus audit (decode path, real concurrency)** | Production arm: 12 (and 16/20) sampled ARC streams × 16k tokens, T 1.0 / 0.95 / 20, `return_logprob` + `top_logprobs_num` 20 + EOS ids. **Check A (must be exactly 0):** an emitted token outside the reported top-20 or outside the 0.95 nucleus of the verify distribution = a verify or sampler bug. **Check B:** re-score the same sequences in R → rate of emitted tokens with reference rank > 20, and \|Δlogp\| by position, against an R-generated A/A set. Repeat with the fp32 SSM arm and the MTP arm | #4 decisively, #2 on the decode path, MTP vs DFlash | ≈ 12–15 min per arm (generation ~7 min + re-score ~3 min + relaunch) |
| **Q3 Cache-restore parity** | Production arm: 4 sequences of 55–60k. Score cold; then warm the cache with prefix[:L−2,000] (max_new 1); score again; compare logprobs of the last 2,000 tokens against cold-vs-cold A/A. Also the Poetiq pattern: 512 answer tokens after STOP_THINKING_TEXT, cached vs flushed | #5 | ~5 min |
| **Q4 KV-scale runtime check** | A sitecustomize hook that logs `k_scale_float`/`v_scale_float` per attention layer on TP0 after load, plus optionally a counter of \|k\|/scale > 448 in `set_kv_buffer` | #6 (whether the 1.0 warning is real) | ~0 extra (rides on any launch) |
| **Q5 EOS-site scoring** | Inside Q1: p(EOS) and its rank at the 10 E11-06 EOS positions under R and production. If R gives p ≥ 1e-3 and EOS lies in the top-20 nucleus, it is model behaviour → fix with the prompt, or resume thinking on an EOS without `</think>`, or `--enable-strict-thinking` (test that first with DFLASH). If p ≪ 1e-4 under R but not under production → engine bug | #3 | Included in Q1 (+~2 min) |
| **Q6 INT4 vs FP8 weights** | Score the same token packs with vLLM FP8 (prompt_logprobs; the E10 vLLM engine cell; the FP8 model is already mounted in the R2 env) and with SGL INT4 R. The cross-entropy matrix (FP8 traces under INT4 and under FP8, and the reverse) estimates KL in both directions by position. A cheaper but riskier variant: SGLang `--model-path` on the FP8 checkpoint, target-only | #1 | ~30–45 min (vLLM load ~600 s + scoring); separate commit or second venv |
| **Q7 LB isolation (if the user accepts one ablation)** | Submit the built E11-05 S60 (S1 prompt, 60k, SGLang) with the current engine. ≥ ~33 → the engine is fine and P1 lost the points; ~29 → engine. It conflicts with the user's "bundle changes, no one-change ablations" rule, so it is offered only as an option | #8 vs #1–#6 | 1 submission (~12–16 h), ~1 h commit |

**Recommended order** (fits one ~90–100 min E15 session): Q4 (free) → Q2 on the production arm, then on fp32 SSM → Q1 arms incl. Q5 → Q3. Q0 runs on CPU in parallel; Q6 is a separate short commit.

Decision rules:
- **Q2 Check A > 0** → DFlash/sampler bug → switch to MTP or target-only.
- **Q1/Q2 \|Δ\| for fp16 > fp32**, growing with position → set `--mamba-ssm-dtype float32`. That costs KV capacity: 599k vs 881k tokens at 12 running (E11-04 W3), or use ReplaySSM fp32 with MTP (Notes/35 table).
- **Q6 INT4 shows a clear NLL/KL gap** that grows on the hard tasks → weigh speed against accuracy. A paired LB is needed.
