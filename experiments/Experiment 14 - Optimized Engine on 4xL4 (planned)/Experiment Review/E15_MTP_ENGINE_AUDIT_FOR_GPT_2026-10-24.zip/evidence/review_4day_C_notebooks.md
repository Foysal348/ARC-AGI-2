# C — Notebook audit: hidden rerun path of E14S SUBMIT + the E16 / E15 variants (2026-10-24)

Read-only audit. Nothing in the project or on Kaggle was changed.

## Scope and method

**Notebooks.** All five were extracted cell by cell to `D:/ARC AGI 2/_scratch/review_4day/nbx/*.py`. Every code cell was read.

| Notebook | sha256 (checked) |
|---|---|
| Q27-XHIGH-E14S_SUBMIT_W6G13_DUCK_SGLANG (submitted) | 3dde5cbd… |
| Q27-XHIGH-E14S_E16_EVAL120G4B_W6G13_DUCK_SGLANG | 234d0919… |
| Q27-XHIGH-E14S_EVAL120G4B_W6G13_DUCK_SGLANG | 44e11cf6… |
| Q27-LOW-E14S_E16_EVAL120G4B_W6G13_DUCK_SGLANG | f87c5488… |
| Q27-XHIGH-E15_MTP_ENGINE_DUCK_SGLANG | fda86a6b… |

**How the variants differ from SUBMIT:**
- EVAL120G4B: only the default commit profile.
- E16: the profile, plus `E16_FLAGS` in CELL 1 and the adapter overlay in CELL 3.
- LOW: E16 plus `E12_REASONING_EFFORT` default `"low"`.
- E15: the profile row `"E15"` plus the new CELL 5c (cell 9).

**Other code read:**
- `duck_arc2/arc2_duck.py` (sha 758bddb5, the payload build), in particular `run_branch`, `BranchSession`, `solve_all_r6`, `build_submission` and the selection code.
- The E16 overlay `src/e16/arc2_duck_e16.py`. Its sha 673618ed matches the sha pinned in the E16 notebooks. A full diff against the base was reviewed.
- `e14_loadpath.py`: staging, StallMonitor, env_report.
- `e14_measure.py`: the keys E15 reads, `steady_window`, `launch_allowed`, `phase_budget`.
- Vendor `tool_agent.py`: the priority gate, `_post_with_retries`, the timeout and error paths, token accounting.
- The builder header.

**Evidence used:**
- The R2 run: `e12_run_report.json` and its gauges.
- E14S commit1: the kernel log, run report, duck directory sizes and server log size.
- The CPU harness run3: its report and the notebook packed in its kit.

Line numbers `nbx L…` refer to `D:/ARC AGI 2/_scratch/review_4day/nbx/Q27-XHIGH-E14S_SUBMIT_W6G13_DUCK_SGLANG.py`. "Cell k" is the notebook cell index; the CELL n names in the source comments are given too.

---

## Findings ranked by severity

### H1 — No recovery if the SGLang server dies or hangs mid-run: the rest of the 12 h is lost (VERIFIED code path; probability unmeasured)

**Where:**
- Cell 9 (CELL 6) only starts `solve_all_r6` (nbx L2303-2312). No thread watches `E11_SERVER`.
- `arc2_duck.py` `BranchSession.run` L2517-2528 and `solve_all_r6.worker` L2863-2953.
- `tool_agent.py` `_post_with_retries` L557-640 and the request-error path L7137-7164.

**What happens after a death.** Engine crash, NCCL hang, or SGLang's own `--watchdog-timeout 1800` killing a hung forward:
1. Every request gets 3 in-place retries × 5 s (connection refused is retried, `ARC3_HTTP_RETRIES` default 3).
2. Then a `RequestException` is raised, which becomes `retryable_failure`. The branch backs off 10 s; after 10 consecutive failures it is `done` ("analyzer failed 10 times consecutively"). That takes ~4-5 min per branch.
3. Each finished item queues its stage-2 items, so the heap drains through the dead server.
4. New sessions get the 900 s first-request grace (`ARC3_HTTP_RETRY_INITIAL_SECONDS`), which only slows the drain.
5. `capacity_probe` fails open (`kv None` admits).
6. Nothing ever relaunches the server, so every remaining task/branch is burned. `submission.json` keeps what was found before the death.

**Evidence on stability:**
- The submitted arm (DFlash width 6 + `--cuda-graph-bs-decode 1..13`) has about 8 min of Duck runtime (commit1) plus R2's 75-s windows.
- R2's 25-min Duck run used width 8.
- The only full 12-h SGLang hidden run (E11-06, LB 29.17) used the W1 arm, not this one.
- The 6.5-h E14S EVAL120G4B commits running now are the first long test of this arm.

**Fix (small, keeps everything else):**
1. A watchdog thread in CELL 6. Every 30 s it checks `E11_SERVER.alive()` and `/health`. If either fails, it relaunches `E11Server(E11_SERVER.cmd, E11_SERVER.env, f"relaunch{k}")`: same flags, JIT caches already warm in `/tmp/e11-cache`, R2 relaunches took 61-76 s.
2. Set `os.environ["ARC3_HTTP_RETRIES"] = "180"` (180 × 5 s = 15 min) before CELL 3's `duck_env` import. A refused connection during the relaunch is then retried in place, and the turn's history and tool work are kept (`_post_with_retries` keeps them; only a read timeout is not retried).
3. Optionally, a `server_down` flag that `kv_blocked()` honours, so no new items are admitted while the relaunch runs.
4. Before relying on the arm for 12 h, read the 6.5-h commit's server log for `Traceback`, `rc=` and `watchdog`.

### H2 — Any SGLang bring-up failure gives the identity submission, LB ≈ 0 (VERIFIED)

**Where:**
- Cell 7 (CELL 5) `e11_bring_up` (nbx L1389-1446) and its `except` (L1478-1483).
- `E11_ALLOW_VLLM_FALLBACK` (L235) is a dead flag: no cell builds a vLLM engine (grep: no `from vllm` / `LLMEngine` anywhere).
- `e11_next` (L1000-1011) relaunches only for OOM, lazy or prefill-graph causes.

**Failure modes that leave only the CELL 0 identity file** (valid, but scores ~0):
- A non-diagnosed launch failure ("no diagnosed fallback").
- The first launch still progressing at the give-up time T0+75 min (L269).
- Capacity gate failure (`avail_mem_gb_last` < 1.0 GB; commit1 had 2.09 GB).
- Smoke failure.
- The tokenizer check flipping `ENGINE_BACKEND` to `"vllm"` (L654-656), which has no engine behind it.

**Mitigation already in place:** staging to /dev/shm (commit1: copy 101 s, READY at 522 s; R2: 502 s).

**Fix:** on any launch or capacity failure, try one more launch with the proven W1 flags. That is `_e11_flags_w1(cfg)`, i.e. without `E14_SUBMIT_ARM`: width 8, `--cuda-graph-max-bs-decode 12` (the E11-06 hidden-run arm). For example, add `return dict(cfg, w1_plain=True), "w1"` as the last `e11_next` rule, and have the wrapper skip the arm when `cfg.get("w1_plain")`. Even better: restore a small vLLM/S1 fallback cell (the Note 36 hybrid idea).

### M1 — An isolation preflight that is not PASS twice fixes 6 workers for the whole hidden run, roughly halving throughput (VERIFIED code; low probability)

**Where:** cell 9, nbx L2271-2284, calling `E12A.workers_for_isolation` (`arc2_duck.py` L2644-2646).

**Behaviour:** any FAIL, or INCONCLUSIVE after one retry (a missing marker or one 180-s timeout among the 12 probes), gives 6 workers for 11.6 h.

**Impact:**
- Decode is communication-bound: the R2 profiler showed NCCL at 51 % of a ~114-ms step, nearly independent of batch size. So aggregate tok/s scales with the number running.
- At 6 workers, stage 1 for 240 tasks needs about 11-12 h. The ORDER2 tail would never start, and stage 2 would get nothing.
- All observed runs passed 12/12 (R2, commit1, harness).

**Fix:**
- Retry INCONCLUSIVE up to 3 times; only a FAIL (a foreign marker = real contamination) drops to 6.
- Or re-probe after 10 min of solving and restore 12 workers. `state["allowed"]` is fixed now; it would have to become adjustable.
- This is a user-approved fail-safe (C6-2), so changing it needs approval.

### M2 — The 11-of-12 latch costs about 8-10 % of throughput for the whole run (VERIFIED in gauges; fix unmeasured)

**Evidence:**
- R2 and commit1 gauges show `server_running` 10-11 with `server_queue` 1 while `workers_running` = 12, in nearly every 30-s sample.
- Decode histograms: commit1 `{11: 105, 12: 2}`; R2 Duck `{11: 216, 12: 26}`.
- The cause is the DFlash min-free-slots delayer at mrr 13 (Notes 14, 16, 30). The 12th request always waits for one of the others to finish.

**Status in the submission:** the delayer stays on, and correctly so: nodelay crashed at 13 running in R2.

**Fix candidate (Note 14, source-verified: "14/11 not delayed"):** `--max-running-requests 14` with `--cuda-graph-bs-decode 1..14`, keeping the delayer. It needs:
- mamba 56 / 4 slots = 14, which just fits;
- a check that `mamba_spec_state_size` grows with mrr and that the free-memory headroom stays ≥ 1.0 GB.

It is not tested anywhere: E15's `_at14` / `_at16` arms cover MTP only, not DFlash W6. Add a DFlash W6 + mrr 14 arm to the next engine commit.

### M3 — Coverage of 240 first exposures is expected but not guaranteed; unstarted tasks get the identity fallback (VERIFIED arithmetic; data from R2 and commit1)

**Clock (RERUN_ALL, nbx L162-165, L218-227, L2248):**
- TOTAL = 43,020 s; HARD_STOP = T0 + 42,900 s.
- The solver deadline is HARD_STOP − 180 s = T0 + 42,720 s (11 h 52 min), with no window and no shift.
- Solving starts at about T0 + 805 s (commit1: READY 799 s, preflight 3 s). The solve window is therefore about **41,900 s (11.64 h)**.

**Stage-1 cost (R2, 12 workers):**
- Mean stage-1 run: 31.5k generated tokens (28k pause + overshoot: p50 909, mean ~3.5k, max 14,688). Mean duration ~1,057 s per run, excluding the run cut by the deadline.
- 240 tasks / 12 workers × 1,057 s ≈ **21,100 s (5.9 h)**.
- From tokens: 240 × 31.5k = 7.56 M tokens. At the counted R2 rate (287 tok/s) that is 7.3 h. At the actual R2 rate including cut in-flight tokens (~350 tok/s) it is 6.0 h.
- Commit1's W6 arm decoded faster (11-running median 476 tok/s vs 404 for R2's W8 arm), so 5.5-7.3 h is the realistic range.
- Stage 2 is left with ~4.3-6.1 h, about 21-31k tokens per task.
- G4B equivalence holds: (42,720 − start) / 240 ≈ 174.7 s per task; EVAL120 gets a 20,960-s window, of which stage 1 ≈ 10,600 s.

**Guarantee:**
- The heap pops every `start1` stage-1 item (priority 0) before any stage-2 item, so all 240 are started first.
- But there is no reservation. With slower decode or bigger overshoot — the worst case is every task overshooting by a full 24,576/32,768-token request, about 60k tokens per task, i.e. 43,600 s — the ORDER2 tail is never started.
- `build_submission` / `e12_write_submission` (nbx L1946-1955) leave never-started tasks as the identity (attempt_1 = attempt_2 = the test input). A started task with no accepted program gets the best partial program's output, else the identity (`select_attempts_r5`, L2301-2345).
- `min_admit_sec` = 240 s still admits a stage-1 start whose first request (12,288 cap at ~35 tok/s per stream ≈ 350 s) cannot finish before the deadline.

**Fix:**
1. A stage-1 ETA guard in `solve_all_r6`: if `stage1_left × mean stage-1 run seconds / workers > deadline − now − margin`, lower the pause for the remaining stage-1 starts. This is a token-budget change, so it needs the user's approval (no-token-cuts rule).
2. Raise the stage-1 admission floor to about 420 s, so the last starts can finish one request.
3. Read the coverage line of the running EVAL120G4B commits (`stage-1 starts left`, `tasks_with_response`).

### M4 — The self-tests run on hidden data; if they fail, the solver is disabled or the engine is dropped (VERIFIED code; very low probability)

**Where:**
- Cell 5 (CELL 3) sandbox self-test on `test_challenges[sorted(test_challenges)[0]]` (nbx L719-727). If it fails, `E10_SANDBOX_SELFTEST.ok` is false, the engine is skipped, and the identity file stays.
- Cell 4 (CELL 2) tokenizer probe built from the same hidden task (L635-640). A mismatch sets `ENGINE_BACKEND="vllm"`, which has no implementation, so again the identity file.
- Commit and harness used the public placeholder test file. The rerun is the first time hidden content reaches these checks.

**Fix:** run both probes on an embedded fixed task, e.g. a small literal task dict in the cell, never on the competition file.

### M5 — Worker-thread bookkeeping outside try/except: an unexpected exception silently kills a worker (SUSPECTED; no trigger reproduced)

**Where:** `arc2_duck.py` `worker()` L2863-2953. Only `s.run(...)` is inside try. These run unprotected:
- `rank()` / `stage2_class()` / `g412_defer_b1()` at pop time;
- the `new_for_task` block;
- `publish(s.write())` (a file write: disk error, or a JSON `default=str` edge);
- `stage2_items()` after the run.

**Effect:** an exception ends that thread. `state["running"]` / `active` may be left incremented, so fewer workers run for the rest of the run, with no log beyond the thread traceback.

**Fix:** wrap the body of the `while True` in try/except. On error: log it, decrement `running`, discard from `active`, `notify_all`, continue.

### M6 — Uncaught raises before the solver turn into a notebook ERROR; external dependencies to keep fixed while the submission is pending (VERIFIED code)

**Raise points with no try:**
- Cell 1: the test file.
- Cell 3 (CELL 1b): `q27x_payload` FileNotFoundError and the zip sha asserts (nbx L428-449).
- Cell 4 (CELL 2): `offline_pip_install` / parity RuntimeError / FP8 tokenizer and config asserts (L561-621).
- Cell 5 (CELL 3): the duck payload and manifest assert (L668-699).

None depends on hidden data; all passed in commit1 and the CPU harness.

**Caution — payload dataset:** the local payload directory `Build/payload/` was rewritten at 06:32 today. The shas are unchanged (verified: `q27x_e12_duck_6f48b81af59a.bin` and `q27x_e14_modules_78029e146cd3.bin` both match). Never publish a version of `foysalemonshanto/q27-e14a-payload` without these two files until the hidden run is scored.

**Hang risk:** the `venv` / `pip install` subprocess calls (L565, L884-888) have no timeout. A stalled /kaggle/input mount would hang until Kaggle's 12-h limit, which is a submission error rather than a 0.

**Fix:** `timeout=1500` on those `subprocess.run` / `check_call` calls, raising `E11Fail`.

### L1 — Deadline-cut requests are not counted in `generated_tokens` (VERIFIED): no rerun scheduling impact, but biased metrics and lost end work

**Accounting:**
- A read timeout keeps the history but adds no usage (`tool_agent.py` L7106-7135).
- A request error rolls the session counter back to `tokens_at_turn_start` (L7145, L7164). That drops the tokens of every earlier request in the same turn, so pause and cap checks under-count.

**Effect on `share_tokens()`** (`arc2_duck.py` L2758-2769): it uses completed tokens / elapsed time. The bias is in-flight work only, at most ~12 × 12-24k tokens against millions by the time stage 2 starts (~6 h), i.e. < 2 %. The fair share is effectively unaffected in the rerun.

**Real costs:**
1. The final ~12 in-flight requests (up to ~600 s each) are cut at 11:52, about 1 % of total compute. Any `check()` / `submit()` they would have made is lost.
2. Eval and G4B reports under-count cost. R2 counted 430,062 tokens over 1,500 s (287 tok/s); the true figure is about 350 tok/s. Commit1 shows branches at 84-256 counted tokens after 480 s.

**Fix:**
- Report server-side `generation_tokens_total` (`/metrics`) next to the counted tokens.
- Optionally cap `max_tokens` by `remaining × per-stream rate` in the last ~15 min (a token change, needs approval).

### L2 — The end-of-run timeline fits, with about 5 min of margin (VERIFIED arithmetic)

| Step | Time / size |
|---|---|
| Solver stop | 11:52:00 (T0 + 42,720) |
| Workers' requests | clamped to the deadline (`_chat_completion` L1653-1662) |
| Join grace | ≤ 60 s |
| Final freeze + publish of up to 480 sessions | each calls `e12_write_submission` (a full 240-task build + ~400 kB atomic JSON); R2 records are 2-16 kB, so about 30-60 s |
| CELL 7 report + bundle | commit1 took < 1 s for 12 tasks; ~20× for 240 |
| Data zipped | transcripts ≈ 7.2 B per generated token → ~110 MB; prompt snapshots ≤ 480 × ~300 kB; server log ~6 MB per 12 h (R2: 200 kB per 25 min) |
| Server kill | ≤ 30 s |
| Notebook end | ~11:54-11:55 |

- `/kaggle/working` use stays under ~0.5 GB, far below 20 GB.
- **Fix (cheap):** in `publish(final=True)` skip the per-record submission write and write once after the loop. Cell 9 already writes once at L2338.

### L3 — The KV window is set to the full pool (`E12_R6_KV_FRACTION` 1.0 → 76,484 per stream × 12 = 917,808 ≈ KV 917,816) (VERIFIED config; impact unmeasured)

- Late in stage 2, 12 long histories can fill the pool, which causes SGLang retractions (re-prefill). R2 and commit1 had `retract_lines` 1 each.
- **Fix/check:** count "retract" in the 6.5-h G4B server log. If it is above a handful, use a 0.95 fraction.

### L4 — E15-specific (VERIFIED code; commit-only, `E15_ON` is false in the rerun)

**`e14_edit_flags` with lists and None is correct:**
- Names in `drop ∪ set_` are removed with their values. A list becomes its str() items; None gives a bare flag.
- `--speculative-num-draft-tokens` appears exactly once: the E14_SUBMIT_ARM value 6 is dropped through `_SPEC`.
- The CPU harness checks for this are in `harness_e14s_nb.py`. No E15 harness result was found in `Experiment Results/`.

**No variable shadowing that matters:**
- `E15R`, `E15_ON`, `E15_REF` are new names.
- `_r0`, `_rs`, `_S`, `_L` are reused, but the A2 cell is gated by `E14_DO_MEASURE`, which is False.
- `E14_KEPT` (top level of cell 8, name "W1" = the submission arm here) is the correct fallback for a failed forced Duck launch.

**Bugs and gaps:**
- (a) `E15_REF` is created only inside `_ref_gate` via `globals()`. If the `E15_ref_aa` phase is skipped or raises, every arm's `_windows` raises NameError: recorded, but all arms are rejected. Fix: `E15_REF = None` before the phases.
- (b) The Duck launch on the chosen arm (`e14_launch(..., force=True)`) does not re-run `e11_capacity_gate` or `e11_smoke`. An MTP arm with a smaller mamba cap or KV would run the Duck at 12 workers anyway. Fix: parse caps on that launch and run `e11_smoke`.
- (c) The `_at14` / `_at16` windows cycle 12 prompts, so 2-4 duplicates hit the prefix cache and inflate the result slightly.
- (d) CELL 7b records `duck_run` only under `E14_DO_MEASURE`, so the E15 Duck result is not in `e14_results.json`; it is in `e12_run_report.json`.

### L5 — E16-specific (VERIFIED)

**Overlay order is correct:**
1. The payload zip is extracted and the manifest checked against the base sha 758bdd.
2. `arc2_duck.py` is overwritten from zlib+base64 bytes; the sha 673618ed is asserted before and after the write.
3. `_E12_MANIFEST` and `E14_RESULTS.build` are updated.
4. Then `import arc2_duck`.

`E16_FLAGS` are set with `setdefault` in CELL 1, before the import. `duck_env()` does not touch them, and the adapter reads them per agent (`_env_int` in `__init__`).

**Diff review:** the early nudge is blocked only by a check/submit attempt; the 24k nudge keeps the base logic; raw content is kept only when normalize(raw) equals the stored text and there is no tool-call markup. No new raise paths outside the agent's per-branch try.

**Stale labels:**
- `CONFIG["e14"]["arc2_duck_sha"]` still says 758bdd (nbx-E16 L554) while 673618ed runs.
- `E14_RESULTS.build.variant` = "E14S".
- The builder docstring says "≥ 4k tokens"; the notebook value is 12,000; the adapter default when the environment variable is missing is 4000.

**LOW variant:** `E12_REASONING_EFFORT` defaults to "low" in **every** profile, including RERUN_ALL. That is intentional, but if that notebook were ever submitted, the hidden run would use low effort.

### L6 — The CPU-harness-tested notebook is not byte-identical to the submitted one; the rerun code is the same (VERIFIED)

- The kit `q27x_e14_cpu_kit_59f5c6ffc927.bin` packs `Q27-XHIGH-E14S_SUBMIT…` with sha prefix fc53adbf, not 3dde5cbd.
- Full cell diff: the only change is in CELL 1 PROFILE_TABLE. The E14S commit row changed (55 → 36 min budget, 25 → 8 min window), and the `E14SEVAL120G4B` row was added. RERUN_ALL and every other cell are identical.
- The rerun-mode harness run (13/13 OK, Python 3.12.13 on Kaggle CPU) therefore covers the submitted rerun code path, including the RERUN branch of `e12_write_submission`.
- Process note: rerun the harness on the exact sha that is pushed.

### L7 — Other stale labels and minor items (VERIFIED)

**Stale labels:**
- `ENGINE_INFO.backend` = "sglang-0.5.21-int4-dflash2-w1" (L1474), though the arm is W6 + graphs 1..13. `CONFIG.e14.submit_arm` records it correctly.
- The CELL 0 markdown title is "E14-A … measurements" on the submission notebook.
- The "E10 Poetiq: … experts … iterations" print (L780).
- The CONFIG vLLM fields (MAX_MODEL_LEN 106496, MTP spec config).
- Comments still say "10 workers".
- The E14 report header is "# E14-A results".

**Staging:** if staging is still running at the join timeout (T0 + 55 min), the copy keeps reading the same files while SGLang launches from /kaggle/input, and later holds 23 GB of /dev/shm that is never used. There is no cancel. Low: commit1 finished staging in 101 s.

---

## Checked and found correct (VERIFIED)

**Submission file:**
- CELL 0 writes the identity file before any heavy work.
- `e12_write_submission` takes a lock and writes atomically with a unique temp file.
- RERUN merges per task only when the row count matches.
- `valid_grid` filters every candidate grid (ints 0-9, rectangular, 1-30).
- Stale callbacks are dropped by `publish_seq`.
- Records are frozen after the final snapshot, so stragglers cannot rewrite them.
- Every solver and report cell is wrapped in `except BaseException`.

**RERUN path:**
- Profile RERUN_ALL: no solve window, no G4B, no window shift, no cache diagnostic, no E14/E15 measurement (`E14_DO_MEASURE` and `E15_ON` both require `not RERUN`).
- `TASK_IDS` = all hidden test ids; `SOLUTIONS` is None and scoring is skipped.
- The commit and the hidden run use the same test file name and the same input paths.

**Deadlines:** `ADMIT < DRAIN < HARD_STOP < VERIFY` asserted. SGLang give-up at T0 + 75 min. Staging deadline T0 + 45 min. Stall watchdog 900 s while loading, 720 s while compiling.

**Scheduler:**
- The KV gate cannot deadlock: idle override, and fail-open on stale or missing metrics.
- No stage-2 item is admitted while stage-1 starts remain.
- A deferred branch-1 start is dropped and re-queued later through `stage2_items`.
- Join is bounded at deadline + 60 s; stragglers are daemon threads.

**Sizes:**
- Commit1: transcripts 12-85 kB per branch; one overwritten prompt snapshot per branch (≤ ~300 kB).
- Server log ~6 MB per 12 h; zips of a few hundred MB at most.

**Throughput and timeouts:**
- The DFlash 13-running crash cannot happen in the submission: the delayer is on and the graph list covers 13.
- The per-request read timeout of 1,800 s is above the longest capped request (32,768 tokens at ~30-35 tok/s ≈ 1,000-1,100 s).

**Payload:** both shas referenced by every notebook exist locally with matching content.

## Suggested order of action

1. **H1 watchdog + `ARC3_HTTP_RETRIES`.** Small and the biggest single risk. It needs a new notebook version, so it applies to the next submission, not the pending one.
2. **H2 W1-flags fallback launch.**
3. **M2 mrr-14 DFlash arm, as a measured commit arm** (about 8-10 % more throughput if it works).
4. **M1 isolation retry policy, M4 fixed-task self-tests, M5 worker try/except.**
5. **From the running 6.5-h commits, read:**
   - the coverage line: `stage-1 starts left` = 0? `tasks_with_response` = 120?
   - the server log: Traceback, retract, watchdog;
   - the real-running histogram;
   - the time at which stage 1 ended (gauges `heap` / `workers_running`, `runs[].stage`).

   These give the evidence behind M3 and H1 for the pending hidden run.
