# D — Resources review: unused levers, memory-rule conflicts, ranked missed opportunities (2026-10-24)

Read-only review. No project file was changed and Kaggle was not touched. The only files written are this report and plain-text PDF extracts in `D:/ARC AGI 2/_scratch/review_4day/tmp/`.

**Baseline used to decide "used / not used":**
- **E14S** (submitted 2026-10-24, ref 57574781): Duck rev 6g (adapter 758bddb5, `E12_RAW_REASONING_HISTORY=1`) on SGLang 0.5.21, RedHat INT4 + DFlash2 at **width 6**, graphs 1..13, TP4, fp8 KV, mem 0.83, fp16 SSM, extra_buffer_lazy, mamba 56, chunk 4096, lpm. Client: 12 workers, **T 1.0**, xhigh, `E12_BRANCHES=2`, 28k first-exposure pause, KV gate 0.95, ORDER2 + cells order, `select_attempts_r5`, E14-0 load path, identity CELL 0 fallback.
- **E16** (built): early inspection-only nudge plus raw-content preservation.
- **E15** (built, not run): MTP 3/1/4 and 2/1/3, ReplaySSM, 14/16 running, mem 0.86, chunk 2048, NCCL sweep, 2×TP2 + MTP.
- **Hybrid** (design, Notes/36): Duck stage 1 + one S1-60K Poetiq "plain" request per unverified task in stage 2.

---

## 0. What was read, and coverage

The four parallel reader agents I tried to launch were refused ("concurrent subagent limit reached, do not retry"). Everything below was therefore read by me directly.

**Read in full:**
- **Memory:** all 37 memory files, including the 94 kB project file.
- **resources/Analysis and Journals:**
  - Improvement ideas (10-16), Coverage levers (10-17), D66/L66 (10-17), LB and run deep analysis (10-16), Weakness analysis (10-19), public resources sweep (10-17), delongyang analysis (10-17);
  - both LB snapshot txt files;
  - the `00_SUMMARY` files for 10-21 and 10-22, and `thread_qwen38_or_something_else.md`.
- **resources/Puzzle Capability Ledger/README.md**, and the head of `resources/NVARC family/README.md` (LB table and full-120 runs).
- **NVARC vs Q27:** the EVAL120 comparison and the tick table.
- **Smaller resources:** `resources/Eval Subset (EDA mirror)/README.md`; `Planning and Prompts/GPT_DEEP_RESEARCH_PROMPT…` (first 60 lines).
- **Experiment READMEs:** 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 (34 kB), 11 (18 kB), 12-FP8 and 14.
  - E12 PLAN, the E12 "Duck milestone-2 exact settings" note, and the E12 analyses for rev 5, rev 6d G4B, weakness and EVAL30.
  - E13 PLAN and VALIDATION.
  - E1 "v1.4.4 vs all experiments".
- **E14 Notes:** 23, 24, 25, 29, 30, 31, 34, 35 (MTP preflight), 36 (Hybrid) and 16 §4d-6.
- **Other E14 material:** the E16 README (`_scratch/e16_review/zip/README_E16.md`), and the E14S submit notebook source, grepped for every setting cited here.
- **Kaggle dumps `_scratch/qwen38_search/disc_2026-10-23/`:** threads 750546, 746520, 687095, 748082, 745787, 747515, 746149, 749756, 750575, 746307; 751344 and 750577 from the 10-22 dump.
- **Kaggle sweep files:** `summary.txt` and `kernels.txt` (head).
- **PDFs:** "High-Score Systems SOURCE_FIRST" (full) and "ARC_REPL_Strategy" (sections 1-17).
  - The two Canonical Journal PDFs are byte-identical (`cmp` SAME).

**Read partly (named sections, or by targeted grep):**
- `E12 next fix list` (2,079 lines): lines 1-72, 321-380, 736-990, 1110-1125, 1363-1470, 1559-1590, 1685-1707 and 1988-2079.
- `reports/Qwen 27B দ্রুততম সার্ভিং সেটআপ.md`: ranking, parallelism/mamba/graphs/chunk, A/B order and unknowns.
- `reports/৪xL4 ইঞ্জিন বটলনেক যাচাই.md`: the 600-800 lever table, logits/GDN, 2×TP2, load path, compile cache, stall timeout, G4B error, versions.
- Land paper (arXiv 2606.31543): abstract, §4.3 and grep.
- Noemon dossier: the first ~250 lines.
- Portability Notes, Master Plan, Handoff and Deep Audit PDFs: by grep.
- khoinguyennguyen notebook (`khoi_full.txt`): by grep.
- ARC-AGI-3 top-10 notebooks: flags and env extracted by script, and the dfranzen CFG values.

**Not read individually:**
- `research_notes/*` (the two reports above are their final syntheses).
- The older 10-22 thread dumps (covered through the 10-22 summary).
- The russcore `.py` dumps and the LB_compare notebooks (except the hosen42 rule-engine header).
- NVARC `index.json` and the rest of the NVARC README.
- The other E12/E13 review docs; `Notes/Speed review`; GPT Notes 26-28 (used through Notes/29); the docx files (their PDF twins were read); the P1_SPARSE zip.

I flag these gaps so nothing below claims more coverage than I had.

---

## 1. Levers and findings NOT used in E14S or the E15 / E16 / Hybrid plans

Format for each item:
- **Evidence** (file + quote or number);
- **Expected impact**;
- **Status**;
- **< 1 day?**

### A. Method, attempts and selection (accuracy per token)

**A1. A second, different method for attempt_2 on tasks the first method did not verify.**
- **Evidence:**
  - Exp10 README / memory: "Poetiq if verified, otherwise attempt_2 = DIRECT" = **55.14 %** vs Poetiq alone 48.61 % (EVAL120).
  - ORDER2 ∪ R5 = 92 vs 78 units, task-norm 56.81 %.
  - Notes/36: on the 8 G4B tasks Duck left unverified, R5 got 8 of 13 inputs.
- **Status:**
  - The Hybrid uses this idea, but only as a design.
  - E14S has none of it: its branch 1 is the same method. Notes/34 #12: "Attempt 2 / branch 1 added 0 … 12/17 branches never called check()".
- **Expected impact:** +2 to +6 LB, but only if coverage holds. Notes/36 §3: plain reaches only 38-57 % of the unverified tasks.
- **< 1 day?** No. The S1 sandbox port plus harness is about 1-2 days.

**A2. A fresh, independent attempt on tasks that passed train (the overfit rescue).**
- **Evidence:**
  - D66/L66 §7: after a train pass, "fresh 5/23 (22 %)" right; feedback never runs.
  - Overfit is 31 % on all R5 tasks and 58-65 % on hard ones.
  - Duck: 4/11 accepts were wrong (weakness W5); rev 5: "4c3d4a41 overfit in both runs".
- **Status:** not used.
  - Duck's `submit()` ends the branch.
  - The Hybrid explicitly excludes verified tasks: `HY_PLAIN_FOR_VERIFIED=0`, class 2/3 = resume0 only.
- **Expected impact:** small to moderate. It costs coverage, so it is worth it only if time is left.
- **< 1 day?** Yes, as a flag inside the Hybrid (the option already exists).

**A3. Iteration 2 with feedback, near misses first (Poetiq).**
- **Evidence:**
  - D66/L66 §3.4: "Iteration 2 … about as productive as iteration 1 per slot-hour" (0.22 vs 0.14 correct per slot-hour in D66).
  - Near miss with feedback 27 % vs fresh 17 %.
  - R5 U-shape: score 0.75-1 → 8/29 solved.
- **Status:** the Hybrid default is `HY_PLAIN_MAX_ITER=1` (iteration 2 off). Not in E14S.
- **Expected impact:** + a few inputs, only with spare time.
- **< 1 day?** Yes: a flag in the Hybrid.

**A4. Label-free anti-overfit ranking when there are 2 or more distinct verified candidates.**
- **Evidence:**
  - D66 §3.3: train-perfect but test-wrong programs are longer (median 11,096 vs 6,545 characters in L66).
  - Natural-close train-pass programs are right 75 %, forced ones 57 %.
  - When two first answers agreed, 12 of 18 were right.
  - G4B: `fixed_offset` × 2 on both accepted candidates.
  - ARC_REPL_Strategy §15: penalise unexplained literals and size, reward test-shape plausibility.
  - Imbue: 90 % correctness + 7 % transfer + 3 % simplicity.
- **Status:** the rev 6 report computes the flags (R6-M1), but `select_attempts_r5` does not use them for ranking.
- **Expected impact:** +0 to +1 LB. It matters only on tasks with two or more candidates, which are rare today.
- **< 1 day?** Yes (CPU only, a replay test on recorded branches).

**A5. Out-of-sample (leave-one-out) train validation of an accepted program.**
- **Evidence:**
  - Noemon dossier §6.2: of 72 demo-fitted simple rules, only **28.6 %** were correct.
  - The ledger's "train verification is a weak selector on 2-5 pairs" (Exp2, R6: 3 of 4 train-verified wrong).
- **Status:** not used.
- **Expected impact:** helps ranking only. It cannot re-run the model, so it serves as a tie-breaker.
- **< 1 day?** Partly. LOO needs the program to accept a reduced train set, which is generally not possible for transform-only code.

**A6. Image (vision) modality as a separate candidate channel.**
- **Evidence:**
  - Land 2606.31543 §4.3: image prompts gave **uniquely correct** candidates on 20a9e565:1, 2d0172a1:1, 4e34c42c:1, b6f77b65:1/2 and d35bdbdc:1. Of these, 20a9e565 was solved by ARC Prize xhigh but never by us; 2d0172a1 only by NVARC.
  - "Pixel-perfect renderings underperformed".
  - Duck milestone: "MULTIMODAL_CONTEXT current_grid … phase 3: grid images (Qwen3.8 is a VLM; Tufa credits multimodality)" (E12 settings doc).
  - E14 README: in the INT4 checkpoint "vision stay BF16".
- **Status:** explicitly "not in rev 6" (fix list §5: "Inputs: images").
- **Expected impact:** unknown, but it is the only diversity channel with external evidence of unique solves.
- **< 1 day?** No.

**A7. A CPU rule library or rule fallback for slots that would otherwise be the test input.**
- **Evidence:**
  - Fix list §5: "the CPU rule library (hosen42: about 30 ms per task, 5.3–5.7 % on real held-out, false-fire bugs; if revived, **train-exact only, host-verified, for slots that would otherwise be the test input**)".
  - delongyang: a rule fallback (all train outputs identical → that grid; otherwise the most common train output).
  - E14S CELL 0 is `identity_submission` (attempt_1 = attempt_2 = the test input). Duck's fallback is the test input too.
  - V3 S12: "identity answers score almost nothing".
- **Status:** not used.
- **Expected impact:** +0.5 to +1.5 LB is my estimate. 5.3 % of 240 tasks ≈ 12 tasks, partly overlapping Duck's easy solves. **No downside** if it only fills test-input slots.
- **< 1 day?** Yes, if hosen42's `arc-reasoning-engine` code is reused (local copy in `resources/Reference Notebooks/LB_compare/hosen42__arc-reasoning-engine/`).

**A8. Holistic trace judge, multi-expert voting, and evolutionary recombination.**
- **Evidence:**
  - Land: judges reliably "recover correct minority hypotheses".
  - Confluence: 12 agents per input + voting, 97.92 % (API).
  - Squeeze-Evolve / Imbue / Athanor (High-Score Systems PDF).
  - The Portability Notes designed SQE-Q27 / ATH-Q27; never built.
- **Status:** not used. Fix list F9: "later"; F12: no 29-candidate ensemble.
- **Expected impact:** these are compute-heavy, which conflicts with the coverage limit. Low priority now.
- **< 1 day?** No.

**A9. Low effort as a complementary branch.**
- **Evidence:**
  - Rev 5: low solved 898e7135, which xhigh did not; the union on 6 shared tasks was 5/6 vs 4/6.
  - ARC Prize: low solves 8 tasks that xhigh misses.
  - Caution: W3H Poetiq low had 0 complementary solves, and **78 % of low requests emitted EOS mid-thinking**.
- **Status:** separate LOW notebooks only. E16 LOW EVAL120 is running on foysal. No per-branch effort mix (R6-E: "not in the first build").
- **< 1 day?** Yes, as a flag, but only after the E16 LOW numbers arrive.

**A10. The khoinguyennguyen verification round, presence penalty 1.5, and context compression.**
- **Evidence:** the khoi notebook: "before its answer is accepted, the solver is nudged to check its own reasoning … one from the initial investigation, one from the verification round", T 0.9, `presence_penalty` 1.5, compression at 80 % into ≤ 32k.
- **Status:**
  - The penalty is **inactive under DFlash** in 0.5.21 (#28180, fix list F3); it would work under MTP (E15).
  - Compression is rejected ("Franzen: removing reasoning was a large regression").
  - The verification nudge resembles R6-P3 (in rev 6).
- **Expected impact:** low. Loops are now 0-8 %.

### B. Coverage: throughput, KV and engine correctness

**B1. The engine-vs-prompt A/B: S1-60K prompts on SGLang W1 (built, never submitted).**
- **Evidence:**
  - Serving report, "প্রথমে কী A/B" row 2: "29.17 বনাম 34.58-এর কারণ engine/quant নাকি P1 prompt, তা কেউ জানে না" (whether the 29.17-vs-34.58 gap comes from the engine/quant or from the P1 prompt, nobody knows) … "চালানো হয়নি" (never run).
  - Memory: E11-05 S60 notebooks built (S60 S1COMMIT4 `df36ece7`, S60_EVAL120 `05cd1d19`), "not pushed".
- **Status:** never run. E14S and the Hybrid both assume SGLang INT4 + DFlash costs no accuracy.
- **Expected impact:** two outcomes.
  - **(a) No accuracy loss:** S1 at +17-29 % speed. The time model (Deep analysis §3) suggests roughly 34.6 → 37-40.
  - **(b) A real engine loss:** it also explains part of Duck's gap, and argues for MTP / vLLM.
- **< 1 day?** Yes for an EVAL30 or LB run, but the old notebook needs the E14-0 load path first. Without it, it risks a 0.00 under GCSFUSE.

**B2. DFlash2 correctness at real concurrency (target-only parity at length).**
- **Evidence:**
  - Notes/29 §2: #36548 reproduction, "**111/304** wrong outputs at concurrency 8", target-only 0/304; "Our A1-4 gate (12 prompts × 256 tokens, c12) … too small a probe".
  - mikelou1: "a tiny kernel issue … made my program score only 40 % (instead of the 60 % projected)".
- **Status:**
  - E15 adds a c12 × 1,024 probe (planned).
  - E14S has only the short gate.
  - PARITY notebooks (rev 6) never ran.
- **Expected impact:** potentially the largest hidden loss: an unknown share of E14S's answers. Engine bugs "move the score by 20 points" (Notes/24 §C2).
- **< 1 day?** Yes: one GPU arm.

**B3. MTP instead of DFlash2.**
- **Evidence:** Notes/35 §3: KV **~1,198k vs 917k** at 12 running, and MTP + ReplaySSM ~1,310k. Ollman: C16 MTP 610 vs DFlash2 402 (+52 %); Mr_Moonsilver: MTP −10 to −17 % at C12-32.
- **Status:** E15 built, not run. Not in E14S.
- **Expected impact:** −10 % to +50 % throughput (must be measured). It is also lower-risk on correctness.
- **< 1 day?** Yes: the E15 run is about 75 min, then a flag change in the E14S builder.

**B4. A real 12-of-12 running (the delayer).**
- **Evidence:**
  - Notes/30: the latch shows "W1 … stuck at 11 in 100 % of samples"; #44401 does not fix it.
  - nodelay crashed at 13 "because the buffer was sized by `--cuda-graph-max-bs-decode 12`". Fix candidates "nodelay **together with graphs13**" or nodelay + `--max-running-requests 12`, **"Neither is tested"**.
  - The cost is about 8-9 % (memory, 11-of-12 root cause).
- **Status:** E14S has graphs13 but keeps the delayer on.
- **Expected impact:** +3-9 % throughput under Duck churn, ≈ +0.5-1.5 LB.
- **< 1 day?** Yes: a 30-min GPU smoke.

**B5. Mamba end-of-prefill checkpoint protection (Franzen patch #4).**
- **Evidence:**
  - R2 replay: of 120 follow-ups, "reply_reused 67, lost_at_prefill_end 26, partial_reply 27".
  - Prefill 13-55 % of the solve window; prefill ~1,500 tok/s blocks decode.
  - E14 README: "Up to ~+14 % (G4B S3 → S4)".
- **Status:** E14-M deferred.
- **Expected impact:** up to +14 % effective.
- **< 1 day?** No (a server patch port).

**B6. Compile / JIT cache restore across sessions.**
- **Evidence:**
  - Notes/23 §3: "First launch 502 s: about 7 min is compile. A relaunch takes 71 s."
  - Bottleneck report: "প্রায় 360 s বাঁচে" (saves about 360 s).
  - The R2 tar failed with an IndexError (Notes/30 bug 1).
- **Status:** deferred. E14S skips the tar.
- **Expected impact:** about 6-7 min more solving (~1 % ≈ +0.3 LB), and less risk at the 19-min give-up.
- **< 1 day?** Mostly: the rc/stderr fix, known-answer gate and dataset upload. The hidden-pool driver match is untested.

**B7. Wheelhouse as a Kaggle Model (NFS) instead of a dataset (GCSFUSE).**
- **Evidence:**
  - Dustin, 10-23 (Notes/24 §B): "put Models in Kaggle Models instead of datasets".
  - The venv install took 181 s; the E14S payload is a dataset too.
- **Status:** deferred (Notes/25 §4).
- **Expected impact:** reduces 0.00 risk (NguyenThanhNhan and amn scored 0.00 ×2 on storage) and saves about 1-3 min.
- **< 1 day?** Yes, but it needs an editor run with Secrets.

**B8. Spec acceptance vs temperature.**
- **Evidence:**
  - Deep analysis §5: "T = 1.0 lowers MTP acceptance to 0.557 (2.67 tokens per step instead of 3.0), which costs about 11 %".
  - E11-03: the temp test was inconclusive (capped at 6).
  - Duck milestone T 0.7; rev 5 moved Duck to T 1.0 (model card).
- **Status:** never measured on DFlash at 12 running. E14S runs T 1.0.
- **Expected impact:** 0 to +11 % speed. The accuracy effect is unknown (rev 4 at T 0.7 had 29 % loops, but with a 60k cap, so it is confounded).
- **< 1 day?** The speed arm, yes. Accuracy, no.

**B9. `--mamba-track-interval 64 --page-size 64` (Duck milestone flags).**
- **Evidence:** E12 settings doc: "Open: do they help multi-turn prefix reuse on 0.5.21 + DFLASH? Measure". E14S has `E12_MAMBA_TRACK_64 = 0` (default off).
- **Status:** never measured.
- **< 1 day?** Yes (smoke).

**B10. Logits vocab-parallel verify sampling.**
- **Evidence:** the profiler shows all-gather 8.1 ms/step; the report estimates "−6–14 ms → +5–12 %".
- **Status:** deferred. A code patch plus an exactness test.
- **< 1 day?** No.

**B11. SGLang 0.5.22 correctness fixes.**
- **Evidence:** bottleneck report: #43029 (spec + wrong mamba state on resume), #41736/#41737 (NaN cross-request leak), #42709 (wrong tokens in the compact-verify graph).
- **Status:** E14-U deferred. Memory `prefer-latest-stack` favours it.
- **< 1 day?** No: the wheelhouse rebuild is about 220 wheels.

**B12. Memory ideas from Merlin: INT4 lm_head, embedding table in host RAM, calibrated FP8 KV scales.**
- **Evidence:** Notes/29: KV pool 1.95 M tokens on 4×3090 vs our 867k. The FP8 KV scale warning ("defaulting to 1.0") is in every log.
- **Status:** deferred (an SGLang port is needed).
- **< 1 day?** No.

**B13. FP8 block-GEMM tuning on L4 (only if returning to vLLM FP8 / S1).**
- **Evidence:** E12-FP8 README: all 5 block-FP8 shapes run "the DEFAULT config (no L4 config files)"; Marlin FP8 is off on sm89.
- **Status:** the E12-K1 notebook was built and never run.
- **< 1 day?** Yes (1.5-2 h GPU), but it is relevant only to the vLLM path.

**B14. Flash-Next in the Duck harness.**
- **Evidence:**
  - E13 SMOKE1 was built (`Q27-XHIGH-E13_DUCK_FLASHNEXT_SMOKE1.ipynb`); its GPT audit was "pending; no go yet" (insights_00). It never ran.
  - amn: "FN with an acceleration … might reach a better score … as an agent".
  - **My inference [E]:** NguyenThanhNhan's 65.97 notebook "reads ~180 GB". That matches Franzen's Flash-Next precache of **185.4 GB** (model + drafter, E13 VALIDATION #3). A 27B FP8 is about 28 GB and our INT4 + DFlash2 is 23.3 GB. So the 65.97 run is plausibly Flash-Next; the thread does not state the model.
  - Against it: E3 gave garbage output and 6 tok/s single-stream on 4×L4. The licence (Qwen Community License) prize-eligibility question is unanswered (750575, 746307).
- **< 1 day?** No.

**B15. More streams (14/16), mem 0.86, chunk 2048.**
- **Status:** these are in E15 (M3, M1-mem, E15-C), not in E14S. Listed so they are not forgotten. They depend on B3's KV gain.

**B16. 2×TP2.**
- **Evidence:** the bottleneck report: with DFlash2 about 170k KV per replica, "প্রায় 0.7–1.0×" (about 0.7-1.0× of TP4). The MTP variant is E15-T1.
- **Status:** not a missed lever beyond E15.

### C. Platform and robustness (a run that does not start scores 0)

**C1. The 12 h clock relative to container start.**
- **Evidence:** E14S `RERUN_ALL` budget 43,020 s, HARD_STOP T0 + 42,900 s; T0 = kernel start. Staff: "runtime limits only count running time", but "container start → attach" is billed (bottleneck report). CPMP: "lost one sub with Kaggle error after 12 hours".
- **Status:** the margin to 43,200 s is about 300 s from kernel start. A long GCSFUSE attach before the kernel starts is not covered.
- **Expected impact:** risk only (a 0 or a Kaggle Error).
- **< 1 day?** Yes (measure container-start → T0 in the commit log; widen the margin if it is large).

**C2. A fallback that is not identity.** See A7. E14S CELL 0 writes the test input for both attempts.

### D. Ordering and per-task difficulty (Puzzle Capability Ledger)

**D1. A capability-based order beyond ORDER2.**
- **Evidence:**
  - Ledger: honest AUC for ORDER2's 2 rules 0.570; 3 rules (+easy_static) 0.588; the greedy search overfits (0.521).
  - Coverage-levers: the LOO model does not beat ORDER2; the cells tie-break gives +0.7 to +2.4 (in E14S already).
  - Oracle order needs the labels, which the hidden set does not have.
- **Status:** ORDER2 + cells is used, and that is the best label-free order the data supports.
- **Expected impact:** ≤ +1 LB, inside the noise.
- **Not a missed opportunity.**

**D2. Per-task difficulty from in-run signals.**
- **Evidence:** "a natural close at ≤ 49k hits 72 %, forced 8 %"; "code written by 30k → 77 % vs 30 % solved"; Duck's first `check()` median 27.7k.
- **Status:** Duck's stage-2 class uses partial progress. No "code-by-30k" signal is used for allocation.
- **Expected impact:** small.
- **< 1 day?** No (the scheduler is frozen by the rev 6g rule).

### E. What the top Qwen3.8 teams say (disc_2026-10-23 and 10-22), and which ideas we do not use

| Who / LB | Statement (verbatim) | Used by us? |
|---|---|---|
| mikelou1, 66.39 → 69.72 | "Not a NVARC ensemble"; "a tiny **kernel issue** … made my program score only 40 % (instead of the 60 % projected by CV)"; "I don't use distillation"; "With time constraints at around 4xL4 speed I got Qwen to 87 % (and from reasoning traces it got the rule to almost every problem)"; his "CV run used LB-ish environment" and "cv → lb is usually within noise" | No engine-correctness proof at length (B2). No 240-task / 12 h-equivalent CV except the gate-4b EVAL120 runs that are running now |
| NguyenThanhNhan, 65.97 | 23.33 run: "custom intervention logic to force the model to stop reasoning and commit … after 49k"; "you could solve many more tasks … by implementing a simple harness". The 65.97 notebook "need[s] to read ~180 GB" | The 49k forced commit is below our 60k floor. 180 GB fits a Flash-Next stack (B14, inference) |
| shiiin9, 65.56 | parallel reads of the inputs | Done (E14-0) |
| amn, 72.50 pipeline | "FN with an acceleration (eg. quant?) might reach a better score … by letting it work as an agent" | B14 not run |
| Kris Dreemurr | "median 70k tokens for pass@2 (so 35k per slot) gets 45 % … The issue is I cant fit it in the box"; NVARC on all 240 tasks in about 4 h | NVARC union not used (F1) |
| TheDivine Aurora | "40 % is possible with 600-800 tps, 1 attempt per task … many times attempts dont end up with a answer. but when done, theyre mostly right … 128k - 256k context" | Throughput gap (B3-B5); our Duck window is 131k |
| Adarsh | "python repl should do almost all of the thinking for qwen and reduce the token usage" | That is Duck. Rev 6 first check median 27.7k |
| Anil Thomas | NVARC + Qwen ensemble 35 → 45 | F1 |
| Darren / Bushi Liu | CV > 75 % does not transfer; Darren's team uses "120 problems and time limit of 6 hours" | Our gate 4b is closer to mikelou1's LB-ish environment |
| Dustin (staff) | "put Models in Kaggle Models instead of datasets" | B7 not done |
| Hiểu Vy | "the other teams … found ways to make their models run faster" | — |

### F. NVARC ensembling

**F1. The NVARC union.**
- **Evidence:**
  - NVARC vs Q27 md: "Poetiq attempt_1 + NVARC attempt_1 as attempt_2 = 89 units, **54.72 %** (vs 48.61 %: +6.1 points)"; the union of all three is 61.81 %.
  - "On hidden, NVARC's value is larger than +6 … it delivers its solves on tasks Qwen does not reach".
  - Anil: +10 LB.
  - Cost: NVARC needs "about 4.6-4.75 h wall for 120 tasks, about 17 GB per L4". It cannot co-reside with the 27B TP4.
  - Kris claims 240 tasks in about 4 h. `johntaylorai/swarm-arc2-budget-curve` shows NVARC with a 705 s/task anytime budget.
- **Status:** not used. User decision since 09-18 ("NVARC as the path" rejected; "a union is a separate question"). The fix list lists "NVARC as the attempt_2 filler (+6.1 eval, but about 9.5 h per 240 tasks)" as "not in rev 6".
- **Expected impact:** up to +6 to +10 LB if a time split works. It costs Qwen hours one-for-one, so the net is uncertain.
- **< 1 day?** No.

### G. Not levers (checked, and why they are excluded)

- **Medium effort:** ARC Prize medium 13.2 % < low 22.8 %.
- **Early stop of hopeless thinking:** AUC 0.63, saves 3-4 %.
- **Shorter thinking below 60k:** user floor (S49 49k LB 32.08 < 60k 34.58).
- **E8 NLL mining:** truth in 0/31.
- **Tail resample of the same method:** 0 gain in E9.
- **P2P / PCIe-IPC:** P2P is 5.5× slower; PHB topology.
- **PP:** DFlash PP unsupported.
- **HiCache.**
- **Swift / ThinkingCap token-efficient variants:** licence, "probably not prize-eligible".
- **Distillation / LoRA SFT:** suggested by Anil, Arcnights and ARC Raiders. It needs out-of-run training; mikelou1 says he does not use it.

---

## 2. Evidence summary with expected impact (the numbers behind the ranking)

| Lever | Key number | Source |
|---|---|---|
| Coverage binds | LB / eval = 1.06 (49k) / 0.62 (86k) / 0.44 (Poetiq). Rev 5 Duck reached about 31 % of 240 tasks | Deep analysis §3; Notes/23 |
| Throughput → LB (time model) | 1.54× → ~37 (86k DIRECT); 2.04× → ~49 (Poetiq R5); 2.55× → ~52 (Poetiq + DIRECT on unverified tasks); 3.57× → ~57 (both methods) | Deep analysis §3 |
| E14S Duck at the hidden share | R2: 287 tok/s → **~49k tokens per task** (Notes/34 #11); 240-task sim at 371 tok/s: 63k per task, 89-110 of 240 tasks under 60k | Notes/34; fix list (240-task sim) |
| Second method | +6.5 eval points (55.1 vs 48.6) | Exp10 R5 |
| Independent attempts | D66 ∪ L66 = 50 vs 28 / 34 | D66/L66 |
| NVARC union | +6.1 eval points (two-slot), +10 LB (Anil) | NVARC md; 750546 |
| Engine correctness | #36548: 111/304 wrong at c8; mikelou1's kernel fix 40 → 66 | Notes/29; 748082 |
| MTP KV | 1,198k vs 917k (+31 %) | Notes/35 |
| Delayer | 11/12 real running, 8-9 % lost | Notes/30; memory |
| Compile cache | ~360-430 s per cold start | Notes/23/25 |
| Re-prefill | 53/120 follow-ups lose all or part of the reply prefix | Notes/30 |

---

## 3. What the memory files say that the current notebooks or plans conflict with

| # | Memory rule | Conflict found | Severity |
|---|---|---|---|
| M1 | `no-token-cuts-below-base`: the Duck exception (10-19) was granted "because thinking is preserved and accumulates … **total thinking per task stays far above 60k**" | At the hidden share E14S gives about **49k per task** (Notes/34 #11, R2 rate), and the 240-task sim shows 89-110 of 240 tasks under 60k in total. The premise of the approved exception does not hold for the submitted run. Gate 4b was approved only as a diagnostic eval profile | **High. Needs the user's explicit acknowledgement** |
| M2 | `kaggle-cpu-validation-before-gpu`: push the GPU notebook only after the Kaggle CPU kit reports `all_ok` | No evidence that the **E16** notebooks (EVAL120G4B 234d0919 / LOW f87c5488 / E16 SUBMIT), which committed on GPU on 10-24, went through the Kaggle CPU kit. `build_cpu_kit.py` has no E16 reference, and the only kit run is "CPU harness run3 E14S". The E16 README says "NO GPU run … not a verified improvement" | Medium (process) |
| M3 | `d66-l66-hard-task-findings`: "train pass should be a ranking signal, not a gate … a fresh independent attempt for attempt_2 when time allows" | Duck `submit()` ends the branch. The Hybrid excludes verified tasks from plain (`HY_PLAIN_FOR_VERIFIED=0`) and keeps 1 iteration (`HY_PLAIN_MAX_ITER=1`) | Low-medium (the design chose coverage; state it explicitly) |
| M4 | `coverage-levers-early-stop-ordering`: "Do not build early-stop or pause-resume" | Rev 6g stage 1 pauses every branch at 28k and resumes in stage 2. The user approved it (R6-Q2) and `past-negatives-not-verdicts` applies, so this is a tension, not a breach | Note only |
| M5 | `arcprize-qwen38-effort-scores`: "Do not swap xhigh for medium to buy coverage"; "keep xhigh" | `Q27-MEDIUM-E14S_SUBMIT_W6G13_DUCK_SGLANG.ipynb` and LOW variants exist. Only a breach if the MEDIUM one is submitted. The LOW EVAL120 run should check the W3H "78 % EOS mid-thinking" failure inside Duck | Low (watch) |
| M6 | `verify-real-concurrency-in-benchmarks` | E14S: server 13 / client 12, but under churn the real running count is **11 in 100 % of latch samples** (Notes/30). Known, not fixed (B4) | Low (known cost 0-10 %) |
| M7 | `prefer-latest-stack` | SGLang 0.5.22 (10-19) with hybrid / spec correctness fixes is not adopted (E14-U deferred) | Low |
| M8 | `kaggle-arc2-platform-limits` (Dustin: Models over datasets; GCSFUSE) | The SGLang wheelhouse and the E14 payload are datasets (GCSFUSE). The weights are Models | Medium (0.00 risk) |
| M9 | `always-save-thinking-traces` | Compliant: Duck `transcript.txt` per branch holds the full thinking; Hybrid saves `OUT/hybrid_plain/thinking/*`. `E12_REQUEST_LOGS` is off outside SMOKE1, so per-request snapshots are not kept; usage is in `branch_result.json` | OK |
| M10 | `notebooks-dual-mode-eval-and-submit` / full-schema `submission.json` | Compliant: CELL 0 writes a full identity submission for every task and input; RERUN_ALL = hidden. Note: the identity fallback is the score floor (A7) | OK |
| M11 | `kaggle-arc2-platform-limits`: notebook < 400 kB | E14S 227 kB, E16 299 kB, Hybrid ≈ 360 kB (estimate, Notes/36 §5 risk 7). Close to the limit | Watch |
| M12 | `kaggle-arc2-platform-limits`: "do not leave over 4 min unused" vs the 12 h limit | E14S HARD_STOP is T0 + 42,900 s. If the container-start → T0 gap is large (GCSFUSE attach), the run can cross 12 h (C1) | Medium (risk) |
| M13 | `pre-run-capacity-check` | Hybrid §5 risk 2 itself flags 12 plain streams × 68-80k vs 866,744 KV (the 0.85 gate is the guard). The E16 EVAL120 commits used the R2-rate quota estimate (Notes/31: ~15 h needed vs hosen42 4.47 h left). `kaggle-quota-midrun` says this is information, not a blocker | OK / note |
| M14 | `never-rebuild-run-notebooks` | The builder pins the shas of the E16 commits (`build_e14.py` L60-66). Compliant | OK |

---

## 4. Ranked missed opportunities (biggest expected LB lever first)

| Rank | Opportunity | Why (evidence) | Expected LB | < 1 day? |
|---|---|---|---|---|
| 1 | **Prove or disprove engine correctness at length** (B2), together with **the S1-on-SGLang vs S1-on-vLLM A/B** (B1, built as E11-05 S60) | 29.17 vs 34.58 is unexplained; #36548 gave 111/304 wrong; mikelou1's kernel fix was worth 40 → 66. Every Duck and Hybrid number rests on this engine | From −5 to +5: it decides which engine the remaining submissions use | **Yes:** one parity arm plus the built S60 notebook (port E14-0 first) |
| 2 | **A different second method on unverified tasks** (A1 = Hybrid; or S1 + DIRECT-on-unverified) | +6.5 eval points; Duck branch 1 yields 0 | +2 to +6 if coverage holds | No (~1-2 days) |
| 3 | **MTP engine (E15)** + ReplaySSM → +31-43 % KV → 14-16 streams (B3, B15) | KV 1.2-1.31M; lower correctness risk; external +52 % at C16 (or −10-17 %) | 0 to +4 (from coverage) | **Yes** (run E15, flip flags) |
| 4 | **NVARC union** with a time split (F1) | +6.1 eval points (two-slot); +10 LB (Anil); NVARC finishes on hidden | +3 to +8, minus the Qwen hours lost | No |
| 5 | **Real 12/12 running** (B4: nodelay + graphs13) | 8-9 % throughput lost | +0.5 to +1.5 | **Yes** (30-min smoke) |
| 6 | **Mamba checkpoint protection** (B5) | 53/120 follow-ups lose the prefix; up to +14 % | +1 to +2 | No |
| 7 | **Free fallback: CPU rule library / rule fallback** in test-input slots (A7) | 5.3-5.7 % held-out at 30 ms/task; zero downside in identity slots | +0.5 to +1.5 | **Yes** |
| 8 | **Flash-Next Duck** (B14; E13 SMOKE1 built) | 180 GB read by the 65.97 team ≈ Flash-Next stack (inference); amn's hint | Unknown, possibly large; licence risk | No |
| 9 | **Fresh attempt after a train pass / iteration 2 near-miss** (A2, A3) | 22 % overfit rescue; feedback 27 % vs fresh 17 % | +0.5 to +2 with spare time | **Yes** (Hybrid flags) |
| 10 | **Storage / startup hardening:** wheelhouse as a Kaggle Model (B7), compile cache (B6), container-start margin (C1) | Avoid a 0.00; save about 7-10 min | Risk removal; about +0.3 | **Yes** (B6 needs the tar fix) |
| 11 | **Speed arms:** temperature vs acceptance (B8), track-interval 64 (B9) | −11 % acceptance at T 1.0 (vLLM) | 0 to +1 | Speed arm yes; accuracy no |
| 12 | **Anti-overfit ranking** (A4) | flags already computed; 4/11 accepts wrong | 0 to +1 | **Yes** |
| 13 | **Image channel** (A6) | Land: unique image solves on 5 tasks | Unknown | No |
| 14 | **Logits vocab-parallel, 0.5.22 fixes, Merlin memory ideas** (B10-B12) | +5-12 % (logits); correctness fixes | +0.5 to +2 | No |
| 15 | **FP8 block-GEMM tuning** (B13) | default Triton config on L4 | Only if returning to vLLM | Yes (if relevant) |

**Gate for this list:** the three EVAL120 gate-4b commits running now (E16 xhigh, no-E16 xhigh, E16 low) will give Duck's task-normalised score at the hidden time share. If it lands well below S1-60K's level (LB 34.58; eval × coverage), ranks 1-3 should be applied to the S1 Poetiq family first, not to Duck.

**The items that can be done in under 1 day:** rank 1 (parity arm + S60 A/B), 3 (E15), 5 (nodelay + graphs13), 7 (rule fallback), 9 (Hybrid flags), 10 (wheelhouse / compile cache / margin), 11 (speed arms) and 12 (anti-overfit ranking), plus 15 if the vLLM path is chosen.
