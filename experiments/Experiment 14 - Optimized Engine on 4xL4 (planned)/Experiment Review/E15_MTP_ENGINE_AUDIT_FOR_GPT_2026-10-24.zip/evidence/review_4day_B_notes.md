# B — Review of every E14 note (00 … 36, subfolders, README): levers, fixes, bugs, open items, status, contradictions, ranking

Written 2026-10-24. Read-only review: no project file was changed and Kaggle was not touched.

## 0. How this was done, and where the full detail is

**Read in full by me (every line):**
- the E14 README;
- Notes 00, 05, 06, 07, 10, 11, 12, 13, 16, 20, 21, 22, 23, 24, 25, 29, 30, 31, 34, 35, 36;
- `Kaggle discussions 2026-10-22 summary.md`;
- the whole builder `build_e14.py` (1,166 lines).

**Read in full by 17 reader agents, one per chunk.** Each agent wrote every item with its file:line, the note's own verdict and a status checked against the builder, the notebooks, the E12/E16 adapters and the R2/E14S raw outputs. The chunks were:
- GPT notes 01/03/04/08/09, 02 (= `Research - 4xL4/00_FINAL_REPORT.md`, a byte-identical copy, md5 259f59c1), 14/15/17/18/19, 26/27, 28/32/33;
- the 10 files of `Research - 4xL4 engine bottleneck validation`;
- the 6 files of `Research - Qwen 27B fastest serving setup`;
- the 4 parts of `Speed review 2026-10-24`;
- `insights_00` … `insights_11`.

**Full item-level list (about 3,800 rows):** `D:/ARC AGI 2/_scratch/review_4day/B_notes_appendix_full_extraction.md`.
- It is the exhaustive answer to "every item with its note and line".
- This file is the consolidated, de-duplicated version, with status, contradictions and ranking.

**What I re-checked myself in code or raw outputs:**
- the JIT tar bug at `build_e14.py:1067`;
- the E15 gate length (`max_new=256`, `build_e14.py:428-431`);
- the E15 arm list (`build_e14.py:488-505`);
- the `full_reply_text_match` off-by-one at `e14_measure.py:448`;
- the stall-monitor give-up at `e14_loadpath.py:800`;
- the NCCL regex at `e14_nccl_bench.py:160`;
- that no notebook calls `restore_jit_cache` / `known_answer_ok`;
- the R2 long-band prompt size (`e14_results.json`);
- `ctx_per_req_p50` at `e14_measure.py:179`;
- the effort and profile defaults in each generated notebook;
- the KV gates.

---

## 1. What is in which notebook today (the reference for every status below)

| Notebook | sha | State | Engine / solver content |
|---|---|---|---|
| E14A embedded | a5318dda | pushed; never started (INT4 mount error ×3 = commit size limit, N21) | measurement profile |
| E14A SLIM run1 | 3c67794e | ran about 25 min, crashed (`Sampler._stop`, N22) | measurement profile |
| **E14A SLIM R2** | 2298d827 | **COMPLETE**: 100 min, 3.95 quota-h (N30) | Measurements:<br>• NCCL bench (3 arms)<br>• W1 baseline + profiler + latch<br>• #44401, nodelay, graphs13<br>• 25-min Duck<br>• replay, int8, target-only, W6, W4<br>JIT tar crashed |
| **E14S SUBMIT** (xhigh) | 3dde5cbd | commit done (1/19 in an 8-min smoke); **SUBMITTED 2026-10-24, ref 57574781, LB pending** | W1 flags + `--speculative-num-draft-tokens 6` + `--cuda-graph-bs-decode 1..13`, with `--cuda-graph-max-bs-decode` dropped (`build_e14.py:365-389`).<br>Also: load path, StallMonitor, raw reasoning, payload dataset.<br>No measurements, no JIT tar |
| E14S EVAL120G4B (xhigh) | 44e11cf6 | pushed as a hosen42 commit (result not yet in the notes) | same engine; 120 eval tasks at the hidden per-task share, 6.5 h |
| E14S E16 EVAL120G4B (xhigh) | 234d0919 | pushed as a hosen42 commit | + E16 adapter (early nudge after 2 inspection calls and 12k tokens; raw content) |
| E14S E16 LOW EVAL120G4B | f87c5488 | pushed as a foysal commit | + E16, `E12_REASONING_EFFORT=low` |
| E14S E16 SUBMIT (xhigh) | ac6ce0a8 | built, not pushed | E14S + E16 |
| E14S MEDIUM / LOW SUBMIT | 8213359f / e5276a77 | built, not pushed | E14S with effort medium / low |
| **E15 MTP** | fda86a6b | built, not pushed | Profile E15, 130 min. Arms:<br>• ref W6+g13 (A/A gate)<br>• W8<br>• MTP 3/1/4 (explicit draft path)<br>• MTP + mem 0.86<br>• MTP 2/1/3<br>• MTP + ReplaySSM fp32 / fp16<br>• best MTP at 14 and 16 running<br>Then a 15-min Duck run on the best gated arm |
| Hybrid Duck + S1 (N36) | — | **design only**; no `--hybrid` in the builder | — |

**Common to every E14 notebook:**
- the rev 6g G4B Duck solver (12 workers);
- THINK_BUDGET = floor = 60,000;
- Duck KV admission at `E12_R6_KV_ADMIT` 0.95. The 0.85 `SGL_KV_ADMIT_MAX` feeds only the Poetiq/DIRECT path (N16:190);
- `--chunked-prefill-size 4096`, fp16 SSM, `extra_buffer_lazy`, mamba 56, mem 0.83, lpm, cache report.

---

## 2. Consolidated list of every lever / fix / bug / open question / recommendation / "do later", with status

**Status codes:**
- **IMPL** = implemented (notebooks named);
- **MEAS** = measured (result given);
- **REJ** = rejected, with the evidence;
- **SUP** = superseded;
- **OPEN** = still open.

Sources are given as note:line. "N" is a numbered note; "4xL4/…" and "Q27B/…" are the research folders; "SR-A1/A2/B/C" are the speed-review parts; "I0x" are the insight files. The appendix holds the per-file rows.

### 2A. Communication (TP4 collectives)

| # | Item | Sources | Status today |
|---|---|---|---|
| A1 | Measure the step split with the profiler | N13:21,90; README E14-A | **MEAS** R2 (N30:47-63):<br>• all-reduce 140 calls = 50.9 ms<br>• all-gather 8.1 ms<br>• Marlin 25.3 ms<br>• other GEMM 14.5 ms<br>• GDN 8.0 ms<br>• attention 2.7 ms<br>• sampling 2.4 ms<br>• kernel sum 116.1 ms<br>So communication = 59 of 116 ms (51 %). NCCL time includes sync waits (N34#9) |
| A2 | NCCL bench at 983,040 B in CUDA graphs (3 arms) | N13:55-61; N15; N10 B23 | **MEAS**: baseline 345 µs per call is best (N22:46-54; R2 343.9 µs, N30:27) |
| A3 | `NCCL_P2P_LEVEL=SYS` (P2P/IPC) | README E14-N; N10 B23 | **REJ**: 1,887 µs per call, 5.5× slower; topology PHB on every pair (N22:51) |
| A4 | `NCCL_SHM_USE_CUDA_MEMCPY=1` | N10 B23 | **REJ**: graph part timed out, eager 500 µs (N22:52) |
| A5 | Other NCCL knobs:<br>• PROTO LL / LL128 / Simple<br>• ALGO Ring / Tree<br>• MIN/MAX NCHANNELS, CTAS, NTHREADS, BUFFSIZE<br>• P2P_DISABLE<br>• TOPO_FILE | N25:41 (E15-N); N29:49; N34#16; N15:50; 4xL4/nccl_p2p_l4 L104-123; 4xL4/profiling L300,348 | **OPEN**. Planned for E15, but **not in the E15 builder**. Bench-only arms, cheap (≤ 30 GPU-min). Expected 0-10 % |
| A6 | NCCL transport parser broken on NCCL 2.29.7: `RE_CONN` expects `Channel 00/0`, the real line is `Channel 00 : 0[0] -> 1[1] via SHM/direct/direct`, so `connections_n` = 0 | G03 (from R2 raw); `e14_nccl_bench.py:160` | **OPEN BUG** (diagnostic only). Fix before any new NCCL arm |
| A7 | PCIe-IPC custom all-reduce (FlashInfer ≥ 0.7, i.e. SGLang 0.5.22 / vLLM 0.32) | README E14-I (P3); N02 §3.3; 4xL4/newer_engine L39,178-194; N23:64 | **OPEN, strong negative prior**: NCCL P2P over PHB is 5.5× slower. Needs a microbench first; days of work |
| A8 | Patched custom all-reduce at TP4 (remove the world_size > 2 gate) | SR-A2 L653; N02 L278 (forced custom all-reduce broke greedy parity in 4 of 5 prompts) | **OPEN**, low prior, correctness risk |
| A9 | **2×TP2 replicas** + sticky routing + per-replica KV gate | N00:33-60; N01:242-260; N04:97, 295-301; N23:30, 64, 86-89; N25:18, 40 (E15-T1); N29:48; 4xL4/tp2_replicas; Q27B/engines L207-214 | **OPEN, not in any notebook** (E15 dropped it). Estimates disagree: 1.3-1.6× (N00, N23) vs 0.7-1.0× (N02, N25). The memory gate is unmeasured (~170k vs 0.35-0.4M KV per replica). A <10-min boot of one replica decides it. Any build needs:<br>• `--disable-custom-all-reduce` or `--enable-p2p-check`<br>• a pinned `--nccl-port`<br>• router retries off<br>(tp2_replicas C40-45) |
| A10 | Quantized / FP8 all-reduce, communication compression, MSCCL++ (`--enable-mscclpp`), host-staged all-reduce #39605 | N27:339; N28:250-251; 4xL4/profiling C43; 4xL4/nccl D36 | **OPEN**, low prior |
| A11 | Pipeline parallel | N29:18-19 | **REJ for now** (PP2 slowest; PP + DFlash unsupported, #43885) |

### 2B. Step compute, logits, kernels

| # | Item | Sources | Status |
|---|---|---|---|
| B1 | **Vocab-parallel verify sampling**: local top-20 per shard, removing the 48 MB logits all-gather and the dense FP32 passes | README E14-L (P3); N02 L115, 152, 423; N25:56; N09:146; 4xL4/per_step L115-117 | **OPEN**. R2 measured all-gather 8.1 + sampling 2.4 ms, so the gate the note set is met. Expected +5-12 % (N25: +9-11 %). Code patch + exactness test, 1-2 days |
| B2 | GDN verify-kernel config sweep | README E14-K; N25:57 | **REJ / deprioritised**: GDN is 8.0 ms, below the 15 ms trigger (N30:63) |
| B3 | Attention backend A/B (flashinfer vs triton, fp8 KV) at long context | 4xL4/profiling C47, L354-356 | **OPEN** (attention is 2.7 ms at short context; unmeasured at 40k) |
| B4 | "Other GEMM" 14.5 ms (drafter + lm_head?) unattributed; DRAFT/VERIFY `step_spans` missing from the R2 summary | G03 (N15:272); G11 | **OPEN diagnostic** (~1 h from the saved R2 trace) |
| B5 | FR-Spec hot-token map: `--speculative-token-map` for MTP; for DFlash2 it saves ~1.5 % | N05:41; N35:121; 4xL4/per_step L130-169 | **OPEN**; not in E15 |
| B6 | Merlin memory ideas: INT4 lm_head + MTP head, embedding table in host RAM, calibrated FP8 KV scales | N29:15, 53; N28:57-62 | **OPEN, deferred** (an SGLang port is needed) |
| B7 | Drafter TP sharding / conv `kernel_projection` (~1 %); replicated sampling (< 1 ms) | 4xL4/per_step B13, B37 | **OPEN**, small |
| B8 | Free counters in every run: `SGLANG_ENABLE_METRICS_DEVICE_TIMER`, `SGLANG_RECORD_STEP_TIME` | 4xL4/profiling L32-34, 101-104 | **OPEN** (< 1 h); in no builder |
| B9 | GPU clocks / 72 W power cap via `nvidia-smi dmon` during windows; PCIe link is Gen3 x16 (R2 bench, new fact) | N02 L66, 416; 4xL4/profiling C27; I11:245 | **OPEN diagnostic** (< 1 h) |

### 2C. Speculative decoding

| # | Item | Sources | Status |
|---|---|---|---|
| C1 | DFlash2-8 vs target-only | N13 D6; README | **MEAS**: 1.49× (505 vs 339.6), parity PASS (N30:23) |
| C2 | **DFlash2 width 6** | README E14-W; N13 D7; N00:27-31 | **MEAS + IMPL**: 531.4 tok/s = **+5.2 % vs W1 505** (N34#2), accept 4.24, gate PASS. In:<br>• E14S SUBMIT (submitted)<br>• E14S EVAL120<br>• E16 ×3<br>• MEDIUM/LOW<br>• E15 reference |
| C3 | Width 6 at long context | N30:31; N31:86; N34#4, #32; N17:340; N19:198-202 | **OPEN**. W6 never ran the long band in R2. E15's reference arm (W6 + g13) runs the long band; E15 is not pushed. The only width-6 long-ish agent data is the 8-min E14S commit (accept p50 4.07, 483 tok/s at 12; N31:96) |
| C4 | Width 4 | as C2 | **MEAS**: 526.8 (+4.3 % vs W1), accept 3.27; not chosen (N30:25, 88) |
| C5 | MTP (EAGLE/NEXTN 3/1/4) instead of DFlash2. E11-03 ran it at an unfair cap of 10 (fp32 SSM): accept 3.05 | N25:37; N29:9-16, 44; N35 §0-4 | **IMPL E15** (not run). Explicit `--speculative-draft-model-path` = the INT4 dir (N35:35). Predicted KV ~1.198M vs 0.917M (N35:74) |
| C6 | MTP 2/1/3; MTP + mem 0.86; MTP + ReplaySSM fp32 / fp16; best MTP at 14 / 16 running | N29:45-46; N35:117-120 | **IMPL E15** (not run) |
| C7 | ReplaySSM with DFlash | 4xL4/per_step L328-330, 357 | **REJ**: blocked in 0.5.21 source (`kv_cache_configurator.py` L1124-1136; README; N35:56); MTP only |
| C8 | `--speculative-adaptive` | N35:49, 121 | **REJ** (#23330 crash with MTP on hybrid GDN) |
| C9 | DSpark drafter (vendor recommends 7 draft tokens; accept 3.62 vs 4.80) | N05:31 | **OPEN**, untested |
| C10 | Dynamic / confidence verification width (#36127, PR #36136); block verification (#43012 / #42297, ~+1.8 %) | N01:228, 235; 4xL4/dflash_width B24, B26; N02 L148 | **OPEN** (upstream / 0.5.22) |
| C11 | EAGLE-3 vs DFlash2; n-gram / suffix decoding | N28:168; Q27B/spec SD10 | **OPEN**, low prior |
| C12 | Acceptance per output position / per 10k-context bucket (width choice at 40-60k) | N04:45; 4xL4/dflash_width B21; SR-B Q2; I09:579-581 | **OPEN** (~1-2 h CPU from saved logs; E12 bins only by running count) |
| C13 | Runtime accept-collapse alarm (#43514: accept 0, "!" output to max_tokens) | Q27B/00 L266, 282; Q27B/engines L351-356; SR-B B64 | **OPEN** (~1 h). Mitigated today: no mixed chunk, no grammar / `tool_choice` required |
| C14 | #37475 `target_layer_ids` preflight on the drafter config ([5,19,33,47,61]) | N27:164-174 | **OPEN** (0.5 h CPU assert) |
| C15 | Accept len includes the bonus token | N05:12-15; N16:72; README | **SETTLED** |

### 2D. Concurrency, admission, Mamba / KV memory

| # | Item | Sources | Status |
|---|---|---|---|
| D1 | Cause of "11 running + 1 queued" | N16:102-107; N14 | **MEAS**: the DFlash min-free-slots delayer. W1 latch at 11 in 100 % of samples (N30:33-37) |
| D2 | #44401 + #41872 backport | README E14-S; N13 D3; N14 | **REJ**: 508.1 vs 505, still at 11 (95.6 %); reverted (N30:20, 35) |
| D3 | nodelay `--min-free-slots-delay 1` alone | N16 4a#8 | **REJ as is**: reached 12 in 36 % of samples, then crashed at 13 running (`dflash_worker_v2.py:273/278`, a buffer sized by `--cuda-graph-max-bs-decode 12`; N30:39-45, N34#7) |
| D4 | **nodelay + graphs 1..13** (buffers sized 13), or nodelay + `--max-running-requests 12` | N30:42-45; N34#8; N32:90-93 | **OPEN, not in any notebook (not in E15).** E14S already carries graphs 1..13 and has no max-bs-12 flag, so this is one extra flag on the submission engine plus a gated arm. Worth ≈ +8-9 % under Duck churn (N16:103); R2's nodelay long band was 481 vs 449.8 before the crash |
| D5 | `--max-running-requests 14` (client 12) to remove the delayer state; `--max-mamba-cache-size 64` | N14:91, 452; N16:221 | **OPEN** for DFlash (E15 tests 15/17 only for MTP) |
| D6 | CUDA graphs 1..13 | README E14-S; N13 D4 | **MEAS + IMPL** (all E14S-family, E15 reference): neutral (short −1 %, long −2.9 %); 13 running not reachable (N30:22; N34#3); ~0.1-0.2 GiB less headroom (N34#5) |
| D7 | int8 Mamba checkpoints | N13 D8; README E14-M | **REJ**: OOM at mem 0.83 (allocate 200 MiB, free 89 MiB; N30:26) |
| D8 | **Mamba end-of-prefill checkpoint protection**: Franzen refresh-on-unlock, bigger mamba pool 56 → 96 (≈ 72k KV cost), trim hysteresis, cache-aware admission | README E14-M (P3); N12:80, 89; N25:58; N02 L93, 426; N27:281-296 | **OPEN, not in any notebook.** R2 agent replay: reply_reused 67, lost_at_prefill_end 26, partial 27, deeper_miss 0 of 120 (N30:77). Up to +14 % (G4B S3 → S4) |
| D9 | `SGLANG_OPT_MAMBA_SKIP_DECODE_LOCK=1` (lazy 4 → 3 slots per request) | N05:32; Q27B/engines L233 | **OPEN**, in no builder; one env arm |
| D10 | Mamba cap computed for 5 slots while 4 are held (~20 % of the pool unreachable, jpezzulli) | Q27B/00 L323; Q27B/spec SD43 | **OPEN** (source read, ~1-2 h) |
| D11 | Post-capture KV sizing (`SGLANG_ENABLE_POST_CAPTURE_KV_SIZING`, #42651) | 4xL4/newer_engine A24; SR-A2 A35 | **OPEN** (one env arm) |
| D12 | `--mamba-track-interval 64 --page-size 64` | N05:29; Q27B/00 L323 | **OPEN** (`E12_MAMBA_TRACK_64` switch exists, off) |
| D13 | HiCache | README "later"; N05:30; N02 L99 | **DEFERRED**: ~0 at KV max 0.44 |
| D14 | Streaming sessions / session-radix cache / token-level continuation | N06:52-55; N11:125; SR-A2 A6-A7 | **OPEN**, high effort (append-only, 300 s idle reaper) |
| D15 | #43204 engine kill when every cached Mamba state is locked (matters at 14-16 running) | N27:262-263 | **OPEN** (1-2 h source audit) |
| D16 | Which KV gate governs Duck | I08; N16:190 | **RESOLVED**: 0.95 `E12_R6_KV_ADMIT`. Hidden-run KV fraction (1.0 vs 0.95) never decided from data (I06/I07) — minor OPEN |
| D17 | LPM cold-request starvation #31954; eviction policies; priority scheduling | 4xL4/agent A46, A53, A56; I01:269 | **OPEN**, unchecked (lpm is in every launch) |

### 2E. Prefill and scheduling

| # | Item | Sources | Status |
|---|---|---|---|
| E1 | Prefill ≈ 1,500 tok/s blocks decode; 13-55 % of the window | README; N16:86 | Fact (drives E2-E5) |
| E2 | **Chunked prefill 2048** (+ `--max-prefill-tokens 4096`) | N29:50 (E15-C); N34#16 ("Adopt"); N26:663-673; N24:20 (attribution corrected in N25:25) | **OPEN: planned for E15, not in the builder.** One arm. Expected +0-15 % (N27) |
| E3 | `--prefill-decode-interval`, `--enable-mixed-chunk` (keep mixed chunk off: #43514 at width 6) | N27; 4xL4/agent L30, 272; 4xL4/dflash_width L135-139 | **OPEN** (risk) |
| E4 | `SGLANG_ENABLE_OVERLAP_PLAN_STREAM=1` | Q27B/00 L288 | **OPEN** (one env arm) |
| E5 | Prefill CUDA graph (now `--disable-prefill-cuda-graph`) | SR-A2 A11 | **OPEN** |

### 2F. Startup, load path, platform

| # | Item | Sources | Status |
|---|---|---|---|
| F1 | E14-0 load path. Specifics:<br>• ranged 64 MiB copy to /dev/shm or /tmp<br>• adaptive workers<br>• `.partial` + atomic rename<br>• per-range blake2b + re-read<br>• safetensors no-hole check<br>• write loop<br>• cgroup check<br>• fail open + off switch<br>• E14_STATE record | README E14-0; N07; N10 B1-B12; N11 §A | **IMPL** all E14. MEAS: 518 MB/s; INT4 37.6 s copy / 103 s with verify; plateau 786 MB/s at 16 workers; single stream 34.6 MB/s (N22:36-44) |
| F2 | Stall-based launch watchdog (rchar + page faults; 900 / 720 s); first launch up to the give-up | N07:30-35; N16:196 | **IMPL** all (`build_e14.py:342-354`) |
| F3 | Staging collision (both model dirs end in `/1`) | N20:20, 45 | **FIXED** (build 2) |
| F4 | Staging stop event when the launch falls back to the original paths | N17 LOW; N20:34, 81, 232 | **OPEN** (category C, deferred). The only open audit item that runs in submission notebooks |
| F5 | Soft release at give-up: StallMonitor returns False "give-up time reached while still progressing" | 4xL4/startup A82; `e14_loadpath.py:800` | **OPEN** (1-2 h) |
| F6 | First launch ≈ 502 s, about 7 min of it compile; relaunch 61-76 s; E14S READY 783 s (give-up 1,140 s) | N22:57-64; N30:13; N31:93 | Fact |
| F7 | **Ship the JIT / compile cache as an input**:<br>• fingerprinted manifest<br>• no `nv/` or `cuda/`<br>• known-answer gate<br>• `LD_PRELOAD` real libcuda guard (I01:164) | N07:37-41, 77; N10 B14; N13:14; N22:64; N23:90; N25:59; 4xL4/startup L152-190 | **OPEN, three problems:**<br>(1) the tar save crashes: `_q.stdout.strip().splitlines()[-1]` on empty stdout, `build_e14.py:1067` (N30:81). N34#6 and its "Later" list say "the rc/stderr fix goes into E15"; **it is not in the builder**, and E15 never runs the tar (`E14_DO_MEASURE` is False);<br>(2) the save runs only in measurement runs;<br>(3) `restore_jit_cache` / `known_answer_ok` are never called.<br>Worth ≈ 6-7 min per run ≈ +0.6-1 % coverage, plus less launch-timeout risk; #42917 stale-cache risk |
| F8 | Which component takes the ~7-min compile; prebuilt `flashinfer-jit-cache` (cu130); Franzen's build-job knobs | 4xL4/startup A44, A48, A53 | **OPEN** |
| F9 | /dev/shm weight load 65 s vs an expected ~13 s | N22:58; SR-A2 L1153-1157 | **OPEN**, minor |
| F10 | Wheelhouse as a Kaggle Model (NFS) instead of a dataset (GCSFUSE); install 181 s | N24:35, 54; N25:60 | **OPEN** (small; "bundle with the next build") |
| F11 | Commit notebook size limit (407 kB ran / 444 kB never ran) | N21:62-80 | **IMPL** (payload dataset, `NB_LIMIT` 400 kB assert at `build_e14.py:1149`). Risk for Hybrid: ≈ 360 kB (N36:217) |
| F12 | Python 3.12 `Thread._stop` crash; Kaggle CPU harness on the pinned image | N22:21-32 | **FIXED** in R2 + rule |
| F13 | CELL 0 reads the competition JSON before its first print, with no timeout | 4xL4/startup A68, A70 | **OPEN** (0.3 h) |
| F14 | Zero-score failure paths: `ENGINE_READY=False` → identity fallback ≈ 0 LB; no fallback if the challenge JSON fails; 240-task synthetic failure harness | N32:276-290; N33:287-293; N16:192; Kaggle summary L45 | **OPEN** (N34#14: "useful, not a blocker"; ~1 day for a competitive fallback) |
| F15 | "A late launch goes to the vLLM fallback" | N31:65 | **SUP / wrong**: the Duck notebooks have no vLLM path (N16:192) |
| F16 | Mount failures show only on the web page; a retry can work | N21:23; N23:56 | Fact / rule |
| F17 | Pinned old image vs latest stack | SR-A2 A50; memory `prefer-latest-stack` | **OPEN** |

### 2G. Engine versions

| # | Item | Sources | Status |
|---|---|---|---|
| G1 | SGLang 0.5.22 (released 10-19). It would bring:<br>• PCIe-IPC<br>• block verification<br>• #41736 / #41737 NaN leak<br>• #42709 compact-verify<br>• #43029 Mamba resume<br>• #36266 COW<br>• scheduler fixes | README E14-U (P3); N29:21; N05:42-45; 4xL4/newer_engine A4, A12, A21, A62 (an offline install is feasible) | **OPEN**: ~220 wheels / 5 GB, ≥ 1 day. Note: GPT N27:763 "NOT GO on 0.5.22" conflicts with the user rule `prefer-latest-stack` |
| G2 | SGLang nightly ≥ 10-16 (for #44401) | README; N02 | **SUP** (the backport showed no gain) |
| G3 | vLLM 0.32 / an engine-only vLLM INT4 + DFlash2 A/B | README E14-U; Q27B/engines B16 | **OPEN** (days) |

### 2H. Agent / Duck cache and effective rate

| # | Item | Sources | Status |
|---|---|---|---|
| H1 | **E14-P raw reasoning in history** (Duck's `_normalize_message_content` deleted blank lines) | N11 §B; N12; README E14-P | **IMPL** all E14 (forced on, `build_e14.py:243`). MEAS R2: 115 kept / 0 mismatch; cached share 82.0 % vs 75.0 % (G4B rev 6d); E14S 83.5 % (N30:72-73; N31:97) |
| H2 | E16 raw assistant content (kept when normalize(raw) == stored) | Notes/36 §4a; builder `--e16` | **IMPL** in the 3 E16 notebooks; no GPU result yet |
| H3 | Residual reply re-prefill after E14-P:<br>• template `reasoning_content\|trim`<br>• tool-call XML re-render<br>• non-canonical ids (`198 198` vs `271`) | N06:39-47; N10:27-38; N22:69-71; N30:77; I11 (row 49) | **OPEN**: 26 lost + 27 partial of 120 in the R2 replay. The A1-3 short probes had no blank lines, so they could not show E14-P (N22:71) |
| H4 | After-trim re-prefill | N10:47; N11:157-158 | By design (1 trim in G4B) |
| H5 | 18 deeper misses (66.8k tokens) → Mamba eviction, not a client edit | N11:109-113; N12:78-80 | Fake-server proof of 0 client edits. R2 replay deeper_miss 0 → folded into D8 |
| H6 | **Agent-effective rate vs decode**: 287 tok/s in R2 (430,062 tok / 1,500 s) → ≈ 49k tokens per task in a hidden run; 60k for 240 tasks needs ≈ 351 tok/s | N34#11; N16:76-86; N05:25-29 | **OPEN, the key coverage number.** It is measured on the full hidden scale only by the pending EVAL120 commits |
| H7 | Runtime zero-throughput / KV-thrash stall flag (EVAL30: gen 0.0 with 11 running + 8 queued) | N16:241; I02:120, 307; I03:333-335 | **OPEN** (~1 h) |
| H8 | Orphan generation after a Duck read timeout | I00:272, 329-331 | **OPEN** (~1 h GPU inside a measurement run) |
| H9 | Soft-pause overshoot (p50 5.1k / max 15.8k past the 28k pause); hard per-attempt clamp (cap overshoot 100k → 159k) | SR-C (rows 118, 157); I04-I07 | **OPEN** (a clamp needs approval under the 60k rule) |
| H10 | Fair share is inert at 240 tasks (12,288 minimum chunk) | I08:81, 154, 318 | **OPEN** |
| H11 | Per-phase wall-time breakdown (prefill / decode / tool / idle) | N26:674-688 | **OPEN** (2-3 h in the report cell) |

### 2I. Solver and accuracy

| # | Item | Sources | Status |
|---|---|---|---|
| I1 | **Earlier first `check()`** (12 of 17 R2 branches never called it; 3 of 6 correct outputs came only from check-only harvesting; b0's first check at a median 27.7k) | N34#12 ("the largest accuracy lever"); N32:304-312; N26:569 (H1); N27:653; N36:124 | **PARTLY**: the E16 early nudge (after ≥ 2 inspection calls and ≥ 12k tokens) is built and pushed in two EVAL120 commits, **untested**. It reverses the G4-6 rule (token-triggered, never before the solved branches' transform at 18.4k / 26.2k; I04-I07, G16 X10) |
| I2 | **Branch-1 / attempt-2 diversity**: pass2 = 0; b1 used 21.6 % of tokens for 0 verified; 4 of 5 b1 starts made 0 tokens | N34#12; N27:512-522, 661; I08:80; N36:40 | **OPEN** (Hybrid turns b1 off) |
| I3 | **Hybrid: Duck rev 6g stage 1 + S1-60K plain Poetiq request in stage 2.** Specifics:<br>• class-0/1 tasks only<br>• one plain request per task<br>• KV < 0.85 and live-cap gates<br>• no plain planned below 60k<br>• pass@2 merge with a regression property<br>• S1 sandbox port with `HY_SANDBOX_SELFTEST` rename | N36 (whole); N28:368; N33:299 | **DESIGN ONLY.** Evidence on the 12 G4B tasks:<br>• Duck 6/19; R5 13/19<br>• on the 8 tasks Duck left unverified, R5 got 8 of 13<br>• "Poetiq + DIRECT" 55.1 % vs 48.6 % on EVAL120<br>Plain reaches only ≈ 38-57 % of unverified tasks at 340-380 tok/s |
| I4 | Reasoning effort medium / low | memory (official 42.4 / 13.2 / 22.8 %); 4xL4/token_efficient L188-189 | Built (MEDIUM / LOW SUBMIT, LOW E16 EVAL120 pushed). The evidence predicts medium is the weakest. A measurement arm, not a recommendation |
| I5 | Rev 5 LOW 10/19 vs rev 6g 6/19 | N34#13 | Not comparable (150-min vs 25-min window) |
| I6 | Token-efficient models:<br>• Swift-1.5 INT4 drop-in (−10-25 % tokens → 1.18-1.33×)<br>• ThinkingCap<br>• Qwen Pi (Apache-2.0)<br>• training-free overthinking logit penalty (−12-23 %, may conflict with spec decoding) | README E14-V; N05:35-37; N24:30; 4xL4/token_efficient | **OPEN, user decision** (licence / prize eligibility) |
| I7 | INT4 thinking-length inflation (+3.7-14 % in papers) | Q27B/weight_quant L248-260; Q27B/00 L161 | **OPEN** (~2 h CPU on saved FP8 vs INT4 traces) |
| I8 | Accuracy confound behind SGLang 29.17 vs vLLM 34.58. Proposed tests:<br>• SGLang W1 + old S1 prompt vs vLLM S1<br>• INT4 vs FP8 paired eval | Q27B/00 L427-428, 475; Q27B/weight_quant L485, 492; SR-B Q10 / Q11 | **OPEN.** The pending E14S LB (57574781) is the first Duck-on-W6 datapoint, not this A/B |
| I9 | FP8 KV calibrated scales: the RedHat config declares a static fp8 `kv_cache_scheme` (N35:62), yet every log prints "defaulting to 1.0" | N05:34; N33:149; N34#17; Q27B/weight_quant L404-418 | **OPEN** (1-2 h loader check) |
| I10 | fp16 vs fp32 SSM state accuracy at long thinking; FP8 KV quality above 32k | Q27B/engines B39; Q27B/00 L185 | **OPEN** (E15's ReplaySSM fp32 arm gives a speed-side datapoint only) |
| I11 | Other solver ideas:<br>• judge ensemble<br>• CPU rule library<br>• `ARC3_PERSISTENT_FUNCTIONS_REPAIR_HINTS`<br>• LOOPSTOP<br>• hard-coded-offset overfit detection<br>• task-local variants<br>• alternative representation for b1<br>• LLM-seeded GA<br>• progress-aware continuation<br>• cheap-first portfolio (NVARC / TRM / rules) | N26:533-571; N27:522-559, 653-662; I01:234, 287; I03:218, 255 | **OPEN**, mostly unsized |
| I12 | Smaller Duck defects:<br>• R3 multi-call rollback<br>• R4 print guard hides 4-number tuples<br>• narrow labelled rows pass the guard<br>• `write()` I/O error kills a worker<br>• R1 / R2 nudge bookkeeping | I09:143-147, 437-439; I08:269 | **OPEN**, small (rev 6g freeze) |

### 2J. Correctness gates

| # | Item | Sources | Status |
|---|---|---|---|
| J1 | Per-arm gate first: serial 6 × 256 + c12 × 256; large-margin flips vs the A/A; `identity=False` (DFlash differs across restarts, #38009) | N20:23, 202-211, 268-271 | **IMPL** (measurement profile + E15) |
| J2 | **Longer c12 × 1,024-token reasoning-on probe vs target-only** (#36548 class: 111/304 wrong at C8) | N29:25-31, 51 | **OPEN: not in E15** (the gate stays 256 tokens: `build_e14.py:428-431`, `e14_measure.py:726`) |
| J3 | Answer-level checks:<br>• paired known-answer scoring with a 90 % CI and a preset δ<br>• #36548 150-trial probe<br>• batch-invariance control | N10 §C:84-97; README E14-G; 4xL4/dflash_width B42-B44 | **OPEN** (~1-5 quota-h) |
| J4 | Known-answer prefix as an admission condition; int8 own A/A; pre-Duck target-only gate; cold-prefix observation after a clean start; per-width resolved-width / acceptance-distribution checks | N20:123, 154, 160, 163-171, 233 | **OPEN** (category C). int8 is moot. Only `accept_p50 <= width` exists |
| J5 | `full_reply_text_match` off-by-one (`k >= len(exp) - 1`) | N20:35, 84 | **OPEN BUG** (`e14_measure.py:448`; diagnostic only) |
| J6 | One launch per arm; no A/B/A repeat; no interval on the adopted arms | N34#4; N32 | **OPEN** |
| J7 | PARITYR6 defects (C6-1 deadline bypass, C6-3 tool name not compared, 2,048-token probes) | I04-I07 | **OPEN** but PARITYR6 is unused by E14 (N16:217) |

### 2K. Process, rules, admin

| # | Item | Sources | Status |
|---|---|---|---|
| K1 | **Kaggle entry / team-merger deadline 2026-10-26: check that every member accepted the rules** | N29:35 | **OPEN, user action, due in 2 days** |
| K2 | Accounts are three people on one team | N10 B25; N11:4 | Resolved |
| K3 | Quota for the EVAL120 commits: ≈ 15 h each at R2's rate vs hosen42 4.47 h (N31:75), and two EVAL120 commits are on hosen42 | N31:75; builder PUSHED list | **OPEN risk.** Memory says low-quota runs still finish; read the results before planning on them |
| K4 | Weekly quota reset time unknown; a forum post for a quota refund | N16:240; I09:427, 453 | **OPEN** |
| K5 | `smoke_rev6` stale (1 FAIL + `min_workers` TypeError, old code too) | N12:47; N16:239 | **OPEN** (test hygiene) |
| K6 | Standing rules:<br>• 60k floor<br>• bundle changes<br>• no push without a go<br>• a pre-run sheet with worst-case wall and 2× quota<br>• short GPU smoke over audits<br>• Kaggle CPU harness first<br>• submit daily<br>• full reports | N16:37-55; N23:31, 77 | In force |

---

## 3. Contradictions between notes, and which value is current

| # | Topic | Older / other value (where) | Current value (where) |
|---|---|---|---|
| 1 | Cause of 11-of-12 | mamba-slot gate (Q27B/engines L244) → #44401 chunked-prefill double count, "nearly settled", +3-8 % (N02 L3, 138; README; N08/N09 accepted it) | **DFlash min-free-slots delayer** (N16:104-107, source); #44401 gives no gain (N30:20, 33-37) |
| 2 | Is #44401 in 0.5.22? | "only in nightly ≥ 10-16" (README; N02:214, 363) | "v0.5.22 onward" (N14:93). Moot: the backport changed nothing |
| 3 | Communication per step | 40-50 ms naive (N00:24); 35-55 ms (README); 128 all-reduces (N01:169; Q27B/engines L205); ≈ 56 ms bench (N22:50; N23:63; N25:16; N29:17) | **59.0 of 116 ms** profiler: 140 all-reduce = 50.9 ms + all-gather 8.1 ms, including sync waits (N30:51-62; N34#9) |
| 4 | Width-6 / width-4 gain | +6.3 % / +5.3 % (N30:24-25; build comment "531 vs 505") | **+5.2 % / +4.3 % vs W1 505**; +6.3 % is vs graphs13's 500.1 (N34#2) |
| 5 | **"Long band is really ~8.7k context"** (N30:15; N33:39; N34#4; repeated by several agents) | ctx_per_req_p50 = 8,761 | **New in this review: misread.** R2 long prompts have a p50 of **40,877 tokens** (`e14_results.json` "prompts"). `ctx_per_req_p50` is `full_token / running` (`e14_measure.py:179`), i.e. KV-pool occupancy, de-duplicated over the shared 36k prefix. So W1 / nodelay / graphs13 *were* measured at ≈ 41k tokens per request (449.8 / 481 / 436.9 tok/s). The shared prefix understates KV-capacity pressure, not attention length. Width 6 / 4 still never ran the long band (C3 stays open) |
| 6 | DFlash2 over no-spec | +39 % (E11-03; N25:15; N29:12; Q27B/00 L222) | **1.49×** (505 vs 339.6, N30:23) |
| 7 | 2×TP2 gain | 2.4× (3090, short answers); ≈ 1.38× / 1.3-1.6× "main lever", 5-6 long requests per replica (N00:38-55; N23:18, 30, 64) | 0.7-1.0×, ≈ 170k KV per replica, "nearly ruled out" with DFlash2 (README; N02; N25:18). **Unmeasured either way** |
| 8 | P2P / custom all-reduce levers | +5-15 % (tp2_replicas L335, 381, 400); P2P ≈ 2× better (nccl_p2p_l4) | **5.5× slower**, PHB (N22:51). P2P levers rejected |
| 9 | Load and copy times | weights 13-60 s from /dev/shm; copy ≈ 3.6 min at 107 MB/s (N07:88; N13:126; README) | Copy 37.6 s (103 s with verify) at 518 MB/s; weights 65 s; READY 502 s, compile-dominated (N22:40-60) |
| 10 | E14-A run shape and cost | two runs, 61 + 80-93 min, ≈ 2.0 + 2.7-3.1 quota-h (N13:143-161) → one 200-min run, ≈ 6.7 h (N16:226-228) | R2 actual: 100 min, **3.95 quota-h** (N30:9-10) |
| 11 | Quota multiplier | 2× (N13:145; N16:113) | 1.95× (N23:58); **2.37-2.38×** of wall in R2 including container time (N31:75) |
| 12 | E14S commit length / sha | 55 min (N31:26); sha fc53adbf (N31:11, 82) | **36 min** (`build_e14.py:130`; N31:63-66); **3dde5cbd** (fc53adbf and 5fb3fddd superseded, N31:71) |
| 13 | First READY | 1,074 s (N33:276) | R2 1,058 s, including the 301-s NCCL bench; **E14S 783 s** (N34#10; N31:93) |
| 14 | vLLM fallback after a late SGLang launch | N31:65 | **No vLLM path** in the Duck notebooks: identity fallback ≈ 0 LB (N16:192) |
| 15 | "The gate caught the nodelay crash" | N30:41 | The parity gate **passed**. The arm was rejected on occupancy + server-log signs (G03, from R2 `e14_results.json`). Lesson: a crash after the gate is caught only by the log signs |
| 16 | Latch adoption rule | "fine" (N16:194) | Wrong for nodelay; rewritten (N20:25, 62-65) |
| 17 | E15 contents | N25: no Duck, 75 min, M1/M2/M3 + **2×TP2 T1 + NCCL E15-N** → N29: M1 with **no draft model**, + **chunked 2048**, + **1,024-token probe** → N34#16 order → N35: explicit draft path | **Builder:** 130 min, + W8 arm, + a 15-min Duck run; **no TP2, no NCCL arms, no chunked 2048, no 1,024 probe** |
| 18 | JIT rc/stderr fix | "goes into E15" (N34:21, 47) | **Not in the builder** (`build_e14.py:1062-1067` unchanged) |
| 19 | NguyenThanhNhan's SGLang flags | attributed to his 65.97 run (N24:20, 48; Kaggle summary L62) | They were posted for his 23.33 pure-reasoning runs; the 65.97 config is unknown (N25:24-26) |
| 20 | Rev 5 cached share | 85.4 / 91.0 % (request-level means; I01:173, I02:71, I03:66) | **84.3 / 88.7 % aggregate** (N16:89-92); R2 82.0 %, E14S 83.5 % |
| 21 | KV pool | 881,336 (E11-04; planning window 73,444) | **866,744 at mrr 13 (W8)**; 917,816 with W6 (N35:72-73) |
| 22 | Warm relaunch | 12-14 s (N16:112; N20:153) | **61-76 s** measured (N30:13) |
| 23 | Token-efficient gain | 1.6-2.4× (N05:35) | 1.18-1.33× at ≈ 60k traces (token_efficient_variants L131-133) |
| 24 | 10-22 G4B ERROR cause | mount stall likeliest (README; N02 L193-202; N10 B13) | **Commit size limit** (407 vs 444 kB, N21:62-80), very likely |
| 25 | Width predictions | W4 550-650 (N00:29); L4 2.8-3.1, L6 3.7-3.95, W4 ≥ W6 (dflash_width) | W4 526.8 / accept 3.27; W6 531.4 / accept 4.24 (N30) |
| 26 | "4.3 of 8 accepted, 46 % wasted" | N00:27 | Bonus token included: 3.3 correct drafts, ~47 % draft accept (N05:12-15) |
| 27 | Mamba verify-state sizing | D = 8 per request ≈ 48 slots (N26:291-303) | Intermediate SSM = (min(mrr, K // 4) + 1) × D × ssm, a separate buffer (N35:68, source) |
| 28 | ReplaySSM with DFlash | permitted, "top lever" (per_step_overheads L328-330, 357, 404, 416) | **Blocked** in 0.5.21 (README; N35:56) |
| 29 | PCIe generation | Gen4 assumed (per_step L51; weight_quant L104) | **Gen3 x16** (R2 `nccl_bench.json`, G07 / G11) |
| 30 | Speed baseline | "W1 ≈ 355 tok/s" (N00:40) is a Poetiq whole-run number | Duck effective 277-279 (rev 6d), **287 (R2)**; engine 505 short / 449.8 long (R2), 483 at 12 (E14S) |
| 31 | Build-2 completeness | README build-2 bullets read as "all audit findings fixed"; N20:13 "every finding is true" | Only categories A + B were built; **category C deferred** (N20:247). Still missing: staging stop event, reply-match off-by-one, known-answer, cold-prefix observation, per-width checks |
| 32 | E16 nudge vs rule G4-6 | G4-6: token-triggered, never before the solved branches' transform; the call-count nudge was rejected (I04-I07) | E16: 2 calls + 12k tokens. An untested reversal; the EVAL120 E16 commit decides |
| 33 | Effort levels | "rejected" (SR-A2 L680; token_efficient L188-189) | MEDIUM / LOW notebooks built, LOW E16 EVAL120 pushed: a user-ordered measurement, not a contradiction of the evidence |
| 34 | E15 "no Duck" (N25:32) and "75 min, 2.5 quota-h" (N25:32) | — | Builder: a 15-min Duck run, 130 min (`build_e14.py:138-142`) |
| 35 | MTP head present? "UNSURE" (N33:347) | — | Present, BF16, loaded in E11-03 with accept 3.05 (N35:11-16, 60-64) |

---

## 4. STILL OPEN items ranked by expected leaderboard impact

**Ranking basis:**
- coverage binds: 240 tasks in about 11.6 h; R2 agent rate 287 tok/s gives ≈ 49k tokens per task, against the 60k floor;
- best LB 34.58 (S1 Poetiq); Duck rev 5 LB 17.50; E14S LB pending.

**How to read impact:**
- "+x % rate" ≈ +x % tokens per task;
- solver items act on accuracy per covered task.

**Effort** = build + CPU harness; GPU time is given separately.

**Decision inputs already running** (read them first, no build needed):
- E14S LB (57574781);
- the three EVAL120 G4B commits: xhigh, E16 xhigh, E16 low.

They give:
- the real agent rate at 240-task scale;
- stage-1 verify rate and coverage;
- whether the E16 nudge helps;
- width-6 behaviour in a long Duck run.

| Rank | Open item | Why (evidence) | Expected impact | Effort |
|---|---|---|---|---|
| 1 | **Hybrid Duck stage 1 + S1 plain request in stage 2, with Duck b1 off** (I3, I2) | S1 alone = LB 34.58. On G4B: R5 13/19 vs Duck 6/19; R5 solved 8 of 13 inputs Duck left unverified; method complementarity 55.1 vs 48.6 %. b1 burned 21.6 % of tokens for 0 verified | **Large accuracy + coverage** (the only lever with a direct LB precedent). Bounded by coverage: plain reaches 38-57 % of unverified tasks | 1-2 days. Builder `--hybrid` + overlay + S1 sandbox port + harness (N36 §4, §6); 45-min smoke ≈ 1.5 quota-h; optional EVAL120 6.5 h |
| 2 | **Solver yield: earlier first check() / harvest** (I1) | 12/17 branches never checked; 3 of 6 correct outputs came from check-only harvest (N34#12) | Large accuracy (N34: "largest accuracy lever") | Measure E16 vs E14S EVAL120 first (~2 h analysis); a Duck revision ≈ 0.5 day |
| 3 | **nodelay + graphs 1..13 on the submission engine** (D4) | Delayer proven (100 % at 11 under churn). The crash came from a buffer sized by max-bs 12, which E14S already drops | **+8-9 % decode slots** under Duck churn → ≈ +4-5k tokens per task | ~1 h build (one flag + an E15-style gated arm with the log-sign check); ~30 GPU-min |
| 4 | **Chunked prefill 2048** (+ `--max-prefill-tokens 4096`) (E2) | Prefill blocks decode, 13-55 % of the window; planned for E15, dropped | +0-15 % agent rate | ~0.5 h (one arm in E15); ~15 GPU-min |
| 5 | **Mamba checkpoint protection / bigger mamba pool / SKIP_DECODE_LOCK** (D8, D9, D10, D11) | R2 replay: 53 of 120 follow-ups lost or partial; cached 82 % vs Franzen 93 % | Up to +14 % agent rate (+10-35 % hypothesised in N27) | Pool size / env flags: 1 arm each (≈ 1 h); refresh-on-unlock port 1-2 days |
| 6 | **Run E15 (MTP family)** (C5, C6) | MTP frees ≈ 280k KV (1.198M vs 0.917M) and may allow 14-16 running; the evidence is mixed (Ollman +52 % vs Mr_Moonsilver −10 %); lower #36548 risk | Unknown sign; potentially +10-30 % rate or concurrency | Built: push + run 130 min ≈ 4-5 quota-h. **Add before running:** J2 (1,024 probe), E2 (chunked 2048), the D4 arm, and the JIT fix (F7-1) — all small |
| 7 | **Correctness at long context**: c12 × 1,024 probe, then answer-level paired eval (J2, J3, I8) | DFlash #36548 / #38009 are public; our gate is 256 tokens; LB 29.17 vs 34.58 is unexplained; mikelou1's "tiny kernel issue" cost 20 points | Accuracy risk, up to ≈ 5 LB points | Probe ~1 h build + ~15 GPU-min; paired eval 2-6 quota-h |
| 8 | **Communication: 2×TP2 boot test → build if KV fits** (A9) | Communication is 51 % of the step; the only large structural lever left | Unknown: 0.7-1.6× | Boot test < 10 min GPU + 1 h build; the full two-server Duck client ≈ 1-2 days |
| 9 | **Vocab-parallel verify sampling** (B1) | all-gather 8.1 + sampling 2.4 ms of 116 ms | +5-12 % rate | 1-2 days + exactness test |
| 10 | **Width 6 at long context + acceptance per 10k bucket** (C3, C12) | W6 ships untested beyond short context; accept falls 4.43 → 3.77 with context | Risk control: a possible few % loss if W6 < W8 at 40-60k | ~2 h CPU on E14S / EVAL120 logs; the E15 reference long window |
| 11 | **Zero-score protection** (F14, F13, F4, F5) | A failed launch scores ≈ 0; a hung JSON read gives an empty log | Avoids a 0 (tail risk on the whole score) | Cell-0 timeout 0.3 h; staging stop 0.5 h; soft release 1-2 h; competitive fallback ≈ 1 day |
| 12 | **Ship the JIT cache** (F7, F8) | ≈ 6-7 min per run; lowers launch-timeout risk | +0.6-1 % coverage | Fix the tar 0.3 h; restore + known-answer + dataset 2-3 h; one commit to save it |
| 13 | NCCL PROTO / ALGO / CTAS bench arms + parser fix (A5, A6) | all-reduce 50.9 ms; bench-only arms are cheap | 0-10 % | ~1 h + ≤ 30 GPU-min |
| 14 | FP8 KV calibrated scales (I9) | The config declares scales, the runtime uses 1.0 | Small accuracy | 1-2 h check + 1 relaunch |
| 15 | Token-efficient model (I6) | −10-25 % tokens → 1.18-1.33× requests | Coverage, if accuracy holds; **licence decision** | User decision; 1 paired EVAL (6.5 h) |
| 16 | SGLang 0.5.22 (G1) | correctness fixes (NaN leak, Mamba resume), block verify +1.8 % | Robustness + small speed | ≥ 1 day wheelhouse + A/B |
| 17 | INT4 thinking-length inflation (I7) | +3.7-14 % tokens in the literature | Coverage, informational | ~2 h CPU |
| 18 | Diagnostics and alarms (each < 1-2 h):<br>• accept-collapse alarm (C13)<br>• stall / KV-thrash flag (H7)<br>• free device counters (B8)<br>• dmon / clocks (B9)<br>• drafter span split (B4)<br>• #37475 preflight (C14)<br>• #43204 audit (D15)<br>• LPM starvation (D17)<br>• orphan generation (H8)<br>• `full_reply_text_match` fix (J5) | — | Robustness, visibility | each < 1-2 h |
| 19 | Smaller solver / scheduler items:<br>• soft-pause overshoot<br>• fair share at 240<br>• per-phase wall breakdown<br>• I11 ideas<br>• I12 defects | — | Small to unknown | 0.5 h to 1 day each |
| — | **Admin: rules acceptance by 2026-10-26** (K1) | Missing it can disqualify the team | Eligibility | User action, minutes |
| — | **Quota for the EVAL120 commits** (K3) | ≈ 15 h each vs hosen42's 4.47 h | Run completion | Check the status pages |

**Suggested bundle for the next submission** (per the bundle rule; each item gated in a short smoke):
- E14S engine + nodelay with graphs 1..13 (rank 3);
- + chunked 2048 (rank 4);
- + the mamba pool / SKIP_DECODE_LOCK arm that passes (rank 5);
- + the Hybrid solver (rank 1), once the EVAL120 numbers set its stage-2 budget;
- + the Cell-0 timeout and the JIT fix (ranks 11-12, cheap).

E15's MTP result decides whether DFlash2 W6 stays.

---

## 5. New findings from this review (not stated in any note)

1. **The "long band ≈ 8.7k" claim is a metric misread** (contradiction 5): long prompts were 40,877 tokens at the median.
2. **E15 does not contain four items the notes say it does:** the c12 × 1,024 probe, chunked 2048, the NCCL arms and 2×TP2. It also lacks the JIT rc/stderr fix that Notes/34 assigned to it.
3. **The nodelay crash passed the parity gate.** Only the substring log signs (`Traceback` ×4) stopped it. Any future arm that crashes under load late needs the log-sign condition, which E15's `_gated` does check (`build_e14.py:476`).
4. **Category-C audit items are still missing** (staging stop event, reply-match off-by-one, known-answer gate, cold-prefix observation). The staging stop event is the only one on the submission path.
5. **The NCCL transport parser never matched on NCCL 2.29.7** (`connections_n` = 0). The "almost surely SHM" transport is inferred, not parsed.
6. **R2 bench facts not in the notes:** PCIe Gen3 x16, a 72 W power limit, 8 KiB eager all-reduce at 90 µs.
7. The README "Notes" table stops at Note 20. Notes 21-36 and the `Speed review 2026-10-24` folder are not indexed there (documentation gap only).
