# B cross-check: proposed engine / Duck tests NOT covered by E15 (2026-10-24, read-only)

## 0. Method and where the full evidence is

- **Agents:** 19 extraction agents. Each read its assigned files in full, every line:
  - E14 Notes 00-37 and the README;
  - all four Notes subfolders;
  - `_scratch/review_4day` A-D;
  - every E11, E12 and E13 README, PLAN, Notes, Review and Results doc.
- **Per-source tables:** one table per source group, with every proposing line, in `D:/ARC AGI 2/_scratch/missed_tests/parts/`:

| File | Source |
|---|---|
| p01 | Notes 00, 01, 03-13 |
| p02 | Notes 02 (= the 4xL4 research 00_FINAL_REPORT; md5-identical) |
| p03 | Notes 14-25 |
| p04 | Notes 26-29 |
| p05 | Notes 30-37 + Kaggle discussions + README |
| p06 / p07 | Research 4xL4 bottleneck files |
| p08 / p09 | Research Qwen 27B fastest serving |
| p10 / p11 / p12 / p13 | Speed review A1, A2, B and C |
| p14 / p15 | Conversation insights 00-05 / 06-11 |
| p16 | review_4day A-D |
| p17 | E11 + E13 |
| p18 | E12 next fix list |
| p19 | E12 other docs |

- **Size:** about 1,100 rows in total. This file merges them into one de-duplicated list and gives the key source lines per item. The full line lists are in the part rows cited.
- **What I checked myself (read-only):**
  - the E15 notebook cells, extracted to `_scratch/missed_tests/nb/cellNN.py`;
  - `build_e14.py` L40-60, L120-160 and L394-595 (CELL 5c);
  - `src/e14_measure.py` (steady_window, Gen, latch_test);
  - `src/e14_nccl_bench.py`;
  - R2 `e14_results.json` (NCCL arms).

**Source keys used below:**

| Key | File |
|---|---|
| N## | `experiments/Experiment 14 .../Notes/## ...md` |
| KD | Kaggle discussions summary |
| RM | E14 README.md |
| R4x | `Notes/Research - 4xL4 engine bottleneck validation/`: AET = agent_effective_throughput, DWC = dflash_width_correctness, LV = local_validation, NEV = newer_engine_versions, NCC = nccl_p2p_l4, PSO = per_step_overheads, PL = profiling_and_levers, SLE = startup_load_environment, TEV = token_efficient_variants, TP2 = tp2_replicas |
| RQ | `Notes/Research - Qwen 27B fastest serving setup/`: F = 00_FINAL_REPORT, CE, EC, OM, SD, WQ |
| SA1 / SA2 / SB / SC | `Notes/Speed review 2026-10-24/` part_A1 / part_A2 / part_B / part_C |
| I00-I11 | `Notes/Conversation insights 2026-10-20 to 23/insights_NN.md` |
| RV-A / B / C / D | `_scratch/review_4day/` A_conversation / B_notes / C_notebooks / D_resources |
| E11R, A03, A04, A05, R04, AUD, GV05, ADM, TL | E11 README and Results/Review docs (see p17 header) |
| E13P | E13 PLAN |
| E12 FL | E12 next fix list |
| E12 PLAN, MS, G4B, R5, WA, RL, RX, DR, AV4, AR35, AV35, AVV, SM | E12 docs (see p19 header) |

## 1. What E15 really runs (confirmed in code)

**Arms.** CELL 5c (`build_e14.py` L394-595; notebook cell 9) runs these arms. Each is its own launch, with the gate first and then the 75-s short (~8k) and long (~40k shared-prefix) windows:

1. `ref_w6g13`: A/A gate (serial 6 + concurrent 12 × 256), windows and the churn latch.
2. Reference c12 × 1024 greedy probe, A/A.
3. `target_only` c12 × 1024 probe vs the reference. Probe only, no steady window.
4. `w8`.
5. `w6_mrr14` (graphs 1..14) + latch.
6. `w6_nodelay_mrr12` + latch.
7. `w6_at14 / at16 / at20` (mrr 17/20/24, mamba 4 × mrr, graphs 1..mrr) + latch + cN probe.
8. `mtp_3_1_4` + c12 probe.
9. `mtp_3_1_4_mem86`.
10. `mtp_2_1_3`.
11. `mtp_replay_fp32` and `mtp_replay_fp16`.
12. Best MTP at 14 and 16 (mrr 15/17, mamba 60/68).
13. Fresh relaunch of the fastest gated 12-stream arm (latch fix preferred), then the 15-min Duck run (CELL 6).

**Not run in E15** (`E14_DO_MEASURE` is False, cell03:40):
- the NCCL bench (cell03:88);
- the E14-A1/A2 suites (CELL 5b/6b);
- the JIT tar save (cell13:10).

**Facts that change some agents' verdicts (checked in code):**

- **F-1. Windows already use Duck sampling and real ARC prompts.**
  - Sampling: T 1.0 / top_p 0.95 / top_k 20 (`e14_measure.py:189-193`).
  - Prompts: real ARC task prompts (`e14_prompts`, cell08:185-206).
  - Each window starts with a 1-token warm request that prefills the shared 36k block (`e14_measure.py:321-334`).
  - So "real prompts", "long-prefill warm-up / GDN JIT absorb" and "sampling-matched" are COVERED (p07 r8-9, p10 r55, p14 r15).
- **F-2. The first-launch 30-min wall timeout is gone in E14-based notebooks** (E15, E14S, all EVAL120 commits).
  - The first launch waits until `SGL_GIVE_UP_AT` (T0 + 75 min) under `E14L.StallMonitor` (cell07:621-629, wait_ready cell07:292-301).
  - `SGL_LAUNCH_TIMEOUT_SEC = 30*60` (cell02:207) is not used for the first launch there.
  - The "raise 30 → 75 min" item (p13 r39, p12 r32, p08 r27, p14 r29, p05 r44) is therefore CLOSED for E14 builds. It still applies to the pre-E14 E12 builders.
- **F-3. R2 (E14A SLIM R2, Notes/30) already measured items that several part files list as never run:**
  - the profiler split (W8, short context: comm 59 of 116 ms);
  - the NCCL microbench, including the **eager all-reduce curve**: 8 KiB 90 µs, 80 KiB 107, 256 KiB 184, 983,040 B 382, 2 MiB 722, 64 MiB 20.5 ms (R2 `e14_results.json` nccl.arms.baseline.eager);
  - the graph per-call 343.9 µs;
  - the P2P_SYS and SHM_MEMCPY arms;
  - topology: all pairs PHB;
  - the #44401 backport (no gain);
  - target-only parity PASS;
  - the A2-1 agent replay (67/26/27/0);
  - W4/W6 at ~6k.
  - These claims in p02 r1, p06 r3-6/r20, p07 r2/r5/r6, p08 r13-15, p09 r2-4, p13 r8/r10 are corrected here. What stays open is listed below.
- **F-4. No vLLM fallback exists** (N37:14), and the Duck KV gate is 0.95 (N37:15). This closes p14 r24's "silent vLLM fallback voids arms" and p13 r28 / p15 r4's "0.85 vs 0.95 gate".
- **F-5. Gaps in E15's own logic** (from the code):
  - (a) Only `mtp_3_1_4` and the `w6_atN` arms get the 1,024 probe. `w8`, `w6_mrr14`, `w6_nodelay_mrr12`, `mtp_mem86`, `mtp_2_1_3` and both replay arms can become the Duck arm after only the 256-token gate (cell09 `_arm` probe_n, `_gated`).
  - (b) The Duck relaunch uses `force=True` with no capacity gate and no smoke (cell09:189).
  - (c) The at-N windows and probes cycle the 12 prompts (`_S[i % len(_S)]`; `e14_measure.py:334`), and `_probe_vs_ref` compares only the first 12 rows.
  - (d) `_cand` has no `level == 12` check.
  - (e) The ref_w6g13 record lacks `step_ms_*`, `level_*` and `log_errors` (cell09 ref dict vs `_arm` dict).
  - (f) The JIT parse is still `json.loads(_q.stdout.strip().splitlines()[-1])` (cell13).
- **F-6. Budget.** E15 has `time_budget_sec` 180 min. My estimate of the current plan is about 150-160 min wall:
  - startup about 13-19 min (E14S READY 783 s);
  - ref about 10 min;
  - target-only about 3;
  - w8 about 6;
  - mrr14 / nodelay about 7 each;
  - at14/16/20 about 24;
  - MTP ×5 about 30-36 (the first EAGLE launch may need a new capture);
  - MTP 14/16 about 14;
  - Duck 15 + relaunch + reserve;
  - report about 10.
  - **Adding about 60 GPU-min needs the budget raised to about 240 min** (quota about 2× wall, i.e. about 8 h). Otherwise `E14M.launch_allowed` skips the tail arms. Order the new arms accordingly (see §5).

## 2. Master list of proposed items NOT covered (or only PARTIAL)

Columns: what it measures · why it matters / impact · cost · coverage · verdict for E15.
Arm = one E15-style arm, about 5-8 GPU-min (relaunch 61-76 s warm).

### A. Engine speed arms

| ID | Item | Key sources (full: part rows) | Measures | Why / impact | Cost | Coverage | Verdict |
|---|---|---|---|---|---|---|---|
| A1 | **DFlash2 width 4 at long context** (+ latch, probe, 65k band) | N30:25,31; N29:16; N26:250-260,634; N27:614; N28:153-155,418; N01:92-96; N13:156; DWC:191,259-263; PL:210; SA1:535,778,838; SA2:644,778-837; SB L878,1223; SC:355,401,446,571; I09:530-536; I10:241-243; RQ F:246,254; SD:113,124-126; RM:88 (p01 r19, p03 r14, p04 r4, p06 r8, p07 r14, p09 r15, p10 r12, p11 r18, p12 r4, p13 r6, p15 r8) | tok/s, accept, step ms of W4 at 8k / 40k / 65k, real 12 | R2: W4 526.8 vs W6 531.4 at ~6k only. Accept falls with context (4.43 → 3.77), which favours a narrow width. The W4 verify AR payload is 491,520 B: from R2's eager curve, about −120 µs/call × 140 ≈ −17 ms/step. #36548 wrong answers: 37/304 at W4 vs 111/304 at W8. Fewer spec states mean more room. Estimate −10 to +12 % | arm about 8-9 min (R2 W4 relaunch was 76 s) | NOT | **ADD (#1)** |
| A2 | **Chunked prefill 2048 + `--max-prefill-tokens 4096`** under churn arrivals | N29:50 (planned for E15, then dropped); N26:635,663-673; N27:613; N32:330; N33:332,388,409; N37:43; RM:66; N02:L156,432; N24:20,48-49; SB L908,1247,1301-1302; RQ F:353,465; EC:283; SA1:518; PL:330; RV-B:151,313; E12 G4B:55-58; E12 FL:1361,1396 (p04 r1, p05 r22, p12 r23, p16 r50, p19 r5) | Decode tok/s and step ms **during** prefill arrivals, TTFT of arrivals, steady tok/s | Prefill takes 13-55 % of the Duck window. Each 4096 chunk stalls the other 11 streams. G4B 12-running lines swing between 42-250 and 382-497 tok/s. +0-15 % agent rate (N37:43). The 8192 chunk stalls decode about 600 ms (cookbook) | arm about 8 min. Needs the arrival-window metric (B10) | NOT | **ADD (#2)** |
| A3 | **NCCL knob microbench** at 983,040 B in a CUDA graph: PROTO LL/LL128/Simple, ALGO Ring/Tree, MIN/MAX_NCHANNELS, MIN/MAX_CTAS 1/4/8, NTHREADS 256, BUFFSIZE 1/8 MiB (PHB optional). Uses the existing `e14_nccl_bench.py --arm-env` (src L722-740) | N09:160-169; N10:79; N13:24; N15:50,119-122; N25:41,50; N26:392-411,643-662; N27:336; N28:247-248; N29:49; N02:L124-126,402,416,420; NCC:101-129,276-285; SA1:465-469,601,772,836; SC:402,447; RV-B:82,264,322 (p01 r5, p03 r9, p04 r2-3, p06 r6, p10 r7, p16 r24) | µs per all-reduce per env, with the sum check | Comm is 59 of 116 ms (51 %). A 20 % faster all-reduce ≈ −10 ms/step ≈ +8-9 % tok/s on every token of 12 h, as an env var only. R2 tried only P2P_SYS (5.5× slower) and SHM_MEMCPY (timeout). The "choose the rest after the first result" step (N09:160) was never done | bench only, about 5-7 min wall during the copy (the R2 3-arm bench took 301 s). Fix the transport parser `RE_CONN` first (RV-B:83) | NOT | **ADD (#4)**, bench only. Promote a ≥ 20 % winner to a server arm (N13 D2) |
| A4 | **2×TP2: one-replica boot / KV / 6-stream test** (`--tp-size 2`, CUDA_VISIBLE_DEVICES 0,1, `--enable-p2p-check`, pinned nccl-port); the full 2×TP2 run later | N00:33-60; N01:242-262,337-339; N03:256-306; N04:85-97,295-301; N23:18,30,64,86-89; N25:18,40; N26:158-166,714; N27:109,618; N28:107,124-125; N29:48 ("E15-T1 stays"); N32:331,385; N33:334,387,410; N37:47; RM:76,97; N02:L158-160,428; RQ F:3,24,300-315,431,477; EC:145-218,395; TP2:238-245; SA2:655,689-776; SB L917,1252,1281; RV-A:86-87,154 (the user pressed 3 times); RV-B:86,317; A03:42,89 (p01 r2-4, p03 r26, p04 r12, p08 r12, p09 r1, p12 r28, p16 r26, p17 r4) | KV tokens per replica ("KV Cache is allocated"), weights per GPU, graph memory, whether custom AR is enabled, short-window tok/s at 6 streams | The only structural comm lever. Comm at 51 % meets the docs' own condition. Estimates run from 0.7× (about 170k KV/replica with DFlash2) to 1.3-1.6×. MTP frees draft memory. Nothing is measured. Caveat: P2P over PHB was 5.5× slower, so custom AR may not help | 1 launch with new TP2 shapes (cold capture about 8 min) + a window ≈ 12 min. `e14_launch` already takes `env=` | NOT | **ADD (#6)**, boot test only |
| A5 | #44401 backport **with** nodelay at mrr 12 (conditional) | N14:80-84,93,451; N30:20 | Latch share with chunked-prefill arrivals | At mrr 12 with the delayer off, the double count still holds the 12th request during every chunked prefill (10 running + 1 chunk + 1 waiting reads full, N14:84). Arm 6 may look fine with only 3 arrivals | arm about 7 min (the patch apply/revert exists in cell08) | PARTIAL | Conditional extra: only if arm 6 `latch_ge12` < about 0.9 |
| A6 | nodelay + graphs 1..13 at mrr 13 | N30:42-45; N32:90-93; N33:78-87; N34:15; RV-B:131 (p05 r1, p16 r2) | The 13-running buffer fix | Same lever as arm 6 | arm | PARTIAL (arm 6 runs at mrr 12; arms 5/7 keep the delayer) | No, unless arm 6 fails |
| A7 | W6 at mem 0.86 | A03:85; R04:11 (p17 r7) | +about 83k KV | KV use is 0.18-0.41, so low value | arm | PARTIAL (MTP only) | Later / no |
| A8 | `SGLANG_OPT_MAMBA_SKIP_DECODE_LOCK=1` (lazy 4 → 3 slots) | N05:32; N02:L358,432; RQ F:323; SD:185,268; EC:233; SA1:552,736; SB L900; I11:171; A03:105; ADM:62; RV-B:136,314,335; SC:453 | Slots per request, caps, parity | More mamba room for at-N. Mamba use is ≤ 0.70, so not binding | CPU source read, then an env arm | NOT | Later (CPU first) |
| A9 | `SGLANG_ENABLE_OVERLAP_PLAN_STREAM=1` | RQ F:288; SD:147-148,170; SB L907,1247; RV-B:153 | tok/s with plan-stream overlap | Vendor +33 % on B200; unknown on sm89 with the FlashInfer plan sync | CPU check, then an env arm | NOT | Optional / later |
| A10 | `SGLANG_ENABLE_POST_CAPTURE_KV_SIZING` (#42651) | SA2:663; RV-B:138 | kv_tokens after capture | Possibly nil on 0.5.21 | launch readout about 2 min | NOT | Optional |
| A11 | Prefill CUDA graph on (drop `--disable-prefill-cuda-graph`) | RV-B:154; AET:25-41 | Prefill speed / memory | The 2.60 GB/GPU cost was needed for 881k KV; KV no longer binds | arm | NOT | Later |
| A12 | Chunk 8192 / prefill-burst rate | AET:25-41,109-110,271; SA2:639; I06:263; I11:60; E12 FL:1359-1480 | Prefill tok/s (now 1,474-1,578) | The opposite direction to A2 | arm | NOT | Later (A2 first) |
| A13 | `--prefill-decode-interval`; `--enable-mixed-chunk` | N27:613; SA2:640; RV-B:152; AUD:95 | Interleave | Mixed chunk is a #43514 trigger | arm | NOT | interval: later. mixed chunk: no |
| A14 | "65.97-team" set on INT4: EAGLE 3/1/4 + extra_buffer + fp32 SSM (no ReplaySSM) + `--mamba-full-memory-ratio 0.5` + chunk 2048 / max-prefill 4096 | SB L1295-1319; N24:20,48-49; N25:24-26 (correction: this set was posted for the 23.33 submission); N26:280-303 (p12 r8, p03 r32) | Caps, tok/s, accept | Untested as a set on L4 | arm about 8 min | NOT | Optional / later (A2 + the MTP arms cover the parts) |
| A15 | SGLang FP8 weights + MTP on L4 | SB L886,1237,1297; WQ:195,491 | FP8 path speed / KV | No SGLang FP8 L4 run exists | cold arm about 15 min + dataset | NOT | Later |
| A16 | Target-only **steady windows** at 12 (and 16/20) | SB L1220,1225; RQ F:22; SD:102,256 (p12 r1, r5-6; p08 r17; p09 r13) | The spec gain on the current base; whether spec still pays at 16-20 | Arm 3 is a probe only. The fallback is unquantified | +about 3 min on the arm-3 launch (16/20 need another launch) | PARTIAL | Optional cheap add (at 12) |
| A17 | Acceptance vs temperature (T 0.7 vs 1.0), speed only | RV-D:229-236,402; E11R:153; A03:72; R03:125; OM:260,281; RQ F:215; SB L222,923 (p16 r18, p17 r8, p09 r31) | accept, tok/s by T at 12 | T 1.0 cost MTP about 11 % acceptance (vLLM). Never measured on DFlash at 12. An accuracy change needs an EVAL | about 2-3 min, no relaunch (a window with temperature 0.7) | NOT | Optional cheap add |
| A18 | Duck at 14-20 real streams (needs a `--streams N` build option; KV gate 0.95; per-stream window = KV / streams) | N37:26-30,37; user "KV 0.18-0.41 used" | Whether Duck turns more slots into effective tok/s | +8-25 % throughput claimed. The E15 at-N arms are report-only by design | build + 15-25-min Duck | NOT | **Separate run right after E15** |
| A19 | Vocab-parallel verify sampling (E14-L) | N02:L115,152,362,423; N25:56; N27:340,617; N28:423; PSO:115-117,405-407; SA1:490,837; RV-A:177,225; RV-B:94,318; RV-D:243-246 | ms/step, exactness | AG 8.0-8.1 ms measured → +9-11 % est. The largest code-side engine lever | patch + CPU exactness + arm | NOT | Separate |
| A20 | SGLang 0.5.22 / nightly (#44401) / vLLM 0.32 | N05:42-45; N02:L210-218,421; NEV:33-39,60-62,422-441; N26:725; N27:385-386; N28:259-275; SA1:560-562; SA2:660-662; RV-B:182-184,325; RV-D:248-251 | Version deltas | Robustness fixes; no published L4 delta | wheelhouse build + run | NOT | Separate |
| A21 | Profile-gated or rejected levers: attention backend A/B; GDN sweep (GDN 8 ms < 15 ms trigger); FP8 W8A8 (Marlin 25 ms < 35); stream_interval; PCIe-IPC / forced custom AR / MSCCL++ (P2P 5.5× slower); HiCache; DSpark; EAGLE-3; n-gram; PP / DP4; torch.compile; block / dynamic verification; FR-Spec on DFlash; quantized drafter | p01 r25,38-39; p02 r6,17-18,20-21,34; p07 r15-19,22,27-29; p10 r18-19,22-30,32,57; p12 r42-47 | — | Measured or source-closed reasons | — | — | No |
| A22 | FR-Spec token map for MTP | N35:121; RV-B:98 | MTP draft cost | Only if MTP wins | map + arm | NOT | Later |

### B. Measurements to add inside existing arms (mostly 0 GPU-min)

| ID | Item | Key sources | Measures / why | Cost | Coverage | Verdict |
|---|---|---|---|---|---|---|
| B1 | **Profiler window on ref W6 at the ~40k band** (+ optionally the chosen MTP arm); keep raw traces of 4 ranks; split "other GEMM" 14.5 ms (drafter vs lm_head); call count 140 vs 162 | N13:21 (D1 at 8k **and** 40k); N03:116,336; N32:161-165; N33:41,121; SA2:204,1113; SB L1254,1276-1284; RV-B:97; SA1:594-600 (p01 r16, p05 r25, p12 r27) | R2 profiled W8 at short context only. This tells whether comm still dominates at 40k and with W6 or MTP, and directs vocab-parallel / TP2 / FP8 | about 4 min (`steady_window(during=...)` hook exists) | PARTIAL | **ADD (#7)** |
| B2 | **Repeat the reference windows at the end** (A/B/A, boot-to-boot noise) | N03:371; N04:313; N13:23,27; N32:66-73; N33:51; DWC:177; NEV:86 (#38009 accept 2.5-3.5 vs 4.4-6.2 per boot); SA2:383-384,1180; RV-B:228 (p01 r6, p06 r12, p16 r80) | Noise band for every adopt rule. W6 was adopted on +5-6 % from one window and graphs13 on 1.005 | about 5 min (relaunch + 2 windows) | NOT | **ADD (#8)** |
| B3 | **~65k context band** (shared 64k block, `E14_LONG_TOKENS`) on ref, the best MTP arm and W4 | N16:218; N17:309; N19:261; I00:337-343; I01:332-334,374-376; I02:96-98,291,311; I03:57,304-306; I05:118,307,334-336; SC:36,400,420,568; SD:94-96,103,252; SB L1224; E11R:151; A03:69-71,88; A04:20-21,39; R04:36-43; E13P:115 (Duck p50 47.9k / p90 97.7k) (p03 r33, p13 r43, p14 r14, p17 r6, p09 r12) | tok/s, accept, step at Duck context. The MTP vs DFlash order could flip above 40k. Decode falls 429 → 323 tok/s at 40-60k | about 2-3 min per arm (12 × 65k shared prefix fits 866k KV) | PARTIAL (40k only) | **ADD (#5)** |
| B4 | Spec-health rules per window: accept 0.00 in any 40-step window; mean floors 3.5 / 3.2 / 2.5 (W8 / W6 / W4); > 50 identical ids; width-mismatch warning; max accept ≤ W | N02:L418,436; DWC:179-198,222; SA2:387,826; SC:377; PL:219-230; I09:530-536; I10:380; N20:162-170 | #43514 (accept 0, "!" batch) was seen at **W6**, which is now the base | 0 (log parse) | PARTIAL | Zero-GPU add-on |
| B5 | Free counters `SGLANG_ENABLE_METRICS_DEVICE_TIMER=1`, `SGLANG_RECORD_STEP_TIME=1` | PL:33-34,59-63,101-104,204; SA1:515,593,765; I10:65,335,378-379; I11:36; RV-B:101,327 | fwd occupancy; decode-only step by batch size (the log "step" includes prefill) | 0 after a CPU check that 0.5.21 has them | NOT | Zero-GPU add-on |
| B6 | `nvidia-smi dmon -s pucvmet` background log | N02:L66,416; PL:202,229,378-380; SA1:602,765; I11:245; RV-B:102,327,350 | 72 W power-cap throttle, which confounds few-% deltas | 0 | NOT | Zero-GPU add-on |
| B7 | `NCCL_DEBUG=INFO` (INIT, GRAPH, P2P, SHM, TUNING) on one launch; `nvidia-smi -q` PCIe gen/width; lscpu / ACS / nsys | LV:96,106,614,681; NCC:82,94,208,232-238; SA1:81,601,774,790-791; SA2:1062-1084,1120,1168; RQ F:311,431,464; EC:204-219 | The real engine transport (no NCCL INFO line in any log), link state | 0 | PARTIAL (R2 topology only) | Zero-GPU add-on |
| B8 | Extra window fields: retraction delta, KV peak, `available_gpu_mem` after capture, peak GPU mem, request failures, step p90, real-running histogram, prefill tok/s, a "queue > 0 and running 0" hang flag, the "reused row must carry allocated KV" and invariant-checker strings | N01:343-358; N03:331-341; N04:305-313; N14:453-460; I00:335-336; I01:349-351; I03:300-303; I04:59,125,241-242; I09:576-577; N35:27,89,133 | MTP at 0.86 and at16/at20 are memory-bound; a speed winner that retracts loses | 0 | PARTIAL | Zero-GPU add-on |
| B9 | **Arrival-window decode tok/s + TTFT in latch_test** (prefill/decode interference) | E12 G4B:55-58; E12 FL:1361,1396,1486; I06:337-344; I11:199-204 (p18 r3, p19 r5) | Needed to score A2; also explains the G4B 42-250 tok/s lines | 0 (parse decode lines inside the latch window) | PARTIAL (shares only) | **Prerequisite of #2** |
| B10 | Resolved delayer threshold per arm; co-admission count with a continuing chunk; 12 vs 11 decode-line split | N14:451-452 | Proof that a latch fix works in real traffic | CPU | PARTIAL | Report add-on |
| B11 | Captured graph-bs readback assert (at-N arms ask for 1..17/20/24) | N16:176; N17:284; N18:112; N20:33,81,231; I00:344; I01:355-357; I03:291-296; I05:315-321 | An ungraphed top batch | CPU (in `_gated`) | PARTIAL | CPU fix |
| B12 | Duck-arm pick: require `level_short/long == 12` and matched context (F-5d) | N17:248-258; N19:134-146; N20:27,69,142-143,220 (p03 r22) | An MTP arm capped at 10 compared at another level | CPU | PARTIAL | CPU fix |
| B13 | ref_w6g13 record missing `step_ms_*`, `level_*`, `log_errors` (F-5e) | cell09 (my read) | Like-for-like decision table | CPU | NOT | CPU fix |
| B14 | **1,024 probe on the arm that will run the Duck** + capacity gate + smoke on the Duck relaunch (F-5a/b) | RV-B:315; RV-C:232; RV-D:191 (p16 r10, r67) | Correctness of whatever runs the Duck; MTP mamba caps | about 1.5-3 min | NOT | **Must-fix before push** |
| B15 | Distinct prompts for the at-N windows / probes; compare all N probe rows (F-5c) | RV-C:233; bld L461; `e14_measure.py:334` | Duplicates hit the prefix cache and bias 14/16/20 | CPU | NOT | CPU fix |
| B16 | c12 × 1024 probe on both ReplaySSM arms | N35:55,58 (fp16 warning "validate long-sequence accuracy"; #42209 not bit-exact) (p05 r19) | State-replay error grows with length | about 1.5 min each | PARTIAL | Cheap add-on |
| B17 | MTP log greps (N35 §5): head on 4 ranks; ABSENT `not found in params_dict, skip loading` and `max_running_requests is capped to`; mamba line; accept ≈ 3.0 (red flag 1.0-1.3) | N32:365; N33:364; N35:25,125-136 (p05 r14-15) | A silently missing head → wrong MTP verdict | 0 | PARTIAL | Zero-GPU add-on |
| B18 | Error-sign list: false positives ("Error in sitecustomize", Triton "Pre-load … avoid CUDA OOM") and missing strings | N14:453-460; N33:151,170; N31:95; N34:17; I00:143,305-310 (p05 r35, p14 r23) | E15 rejects arms on these signs (nodelay was caught only by them) | CPU on R2 logs | PARTIAL | CPU check before push |
| B19 | `/flush_cache` effectiveness: read cached_tokens of the first post-flush window requests | N16:175,211; N17:166-204; N18:113,174-184; N19:175-191; N20:30,70-74,150-154 (p03 r19) | Whether "uncached" windows are uncached | CPU post-run | PARTIAL | Post-run CPU |
| B20 | Accept-length definition for MTP (bonus token), so the MTP vs DFlash accept columns compare | OM:288; SB L970,1222; RQ F:246,447 | Read the E15 table correctly | CPU source | NOT | CPU |
| B21 | Per-position acceptance histogram | DWC:35,72-73; LV:142,522,591,676; SA1:357,535,778; SA2:835,1049 | Width from data | patch | NOT | No (the means decide) |

### C. Correctness / accuracy

| ID | Item | Key sources | Measures / why | Cost | Coverage | Verdict |
|---|---|---|---|---|---|---|
| C1 | **Answer-level #36548 probe (reduced):** short single-answer greedy prompts with known answers, c12 × about 150 trials + 20-50 serial, on ref and target-only (and W4 inside its arm); McNemar | N02:L246,266,418,436; DWC:176,204-208,219-222,263; SA1:359,427,586,589,779; SA2:374-378,396-397,813,828,1052,1177,1198; SC:325,423; I09:261,443; I10:177,321; I11:163; RV-B:225,316; N24:44 (mikelou1: a "tiny kernel issue" = 40 vs 60 LB) (p02 r8, p06 r2, p11 r1, p13 r44, p15 r10) | Wrong-answer rate under concurrency. #36548: 111/304 wrong at c8 vs 0/304 with no spec, on a similar stack. E15 checks tokens only | about 4 min per launch (short outputs) → about 8-10 min | NOT | **ADD (#3)** |
| C2 | Batch-invariance control: target-only serial vs target-only c12 (arm-3 launch) | N02:L418; DWC:157,160,214; LV:549-550,656; SA2:239,830,1053,1179 (p02 r10, p06 r14, p11 r25) | Makes arm 3's flip count interpretable | about 2 min | PARTIAL | Cheap add-on |
| C3 | Long-context (40-60k) cross-request marker test, c12 | RQ F:280-282,427; I01:338; I02:320; E13P:212 (p08 r2, p14 r3, p17 r18) | #36548 leak mode at length; MTP / ReplaySSM state paths | about 3-5 min (can share the B3 band) | PARTIAL | Optional |
| C4 | Parity at tool-call depth: ≥ 12,288-token thinking-on probe, tool name + args, a tool-result continuation (ref vs chosen arm / target-only) | N16:217; N17:308; I04:117,185,231-235; I05:263,275,327-332; I06:357-362; I07:329-333; I08:368-371; I09:538-547; I10:271-274,381; E12 FL:1177-1181,1283-1286 (PARITYR6 C6-1/C6-3 bugs) (p14 r6, p15 r9, p18 r4) | The first tool calls come at 12-34k; the 1,024 probe never reaches one | 2 min (continuation + name) to 15 min (long probes) | PARTIAL | Separate (or the short version only) |
| C5 | Task-level DFlash vs target-only parity at ≥ 60k (PARITY f3876b40 / 85da1be3 / bc9e2bc2 built, never run; 32-prompt workload equivalence) | N02:L418; DWC:209-213; RQ F:3,19,265,282,427,434,475; SB L440,837-838,1230; SD:169,273; OM:554-555; N08:91; N09:107-122; N10:84-97; N13:26 | Solve-rate equivalence | 1-6 GPU-h | NOT | Separate |
| C6 | **Engine/quant vs prompt attribution of LB 29.17 vs 34.58:** SGLang INT4 + S1 prompt vs vLLM FP8 (S60 df36ece7 / 05cd1d19 built), or an LB submission of SGLang + S1 | N37:36; RM:87-88; RQ F:3,110,292,428,442; OM:533,545-556; SB L188,366,1231; RV-B:213,316; RV-D:167-175,392 | −5.4 LB (3-5 sd), unexplained. Every Duck number rests on this engine | EVAL30 / 120 or 1 LB slot | NOT | Separate (high priority) |
| C7 | INT4 vs FP8 paired eval; INT4 thinking inflation (CPU log compare first: 136b0064 44.7k vs 23.2k) | WQ:248-260,286,293; OM:509; RQ F:161,163,428,460; SB L1190,1232; A05:73; RV-B:212,326 | Coverage tax of INT4 | CPU, then separate | NOT | CPU now; run later |
| C8 | **Calibrated FP8 KV scales** (32 tensors 0.021-0.254; every log says "defaulting to 1.0") | N05:34; N02:L360,432; N28:57-63,173,179; N33:149; N34:25; N37:47; EC:287-288; OM:377; WQ:405-418; SA1:738,786; SB L389,661,896,1042,1234; I06:150,324,378; I07:107,342; I08:104,382; I09:274,444,583-585; I11:170; A03:43,123; R04:5,91; A04:26; RV-A:183,228; RV-B:99,214,323 | A silent precision loss on 60k thinking | CPU loader check of 0.5.21 first; then a gated arm + accuracy run | NOT | CPU now, then separate |
| C9 | fp16 vs fp32 SSM accuracy / verbosity at 60k; FP8 vs BF16 KV above 32k | I09:273,543,547; RQ F:185,343,456,458; SB L673,898,1233; N26:304-319; N29:27; WQ:377,411-417; CE:439; RV-B:215 | Accuracy drift | Separate | NOT | Separate |
| C10 | Raw vs normalized reasoning accuracy | N11:153; I10:318 | The accuracy side of E14-P | Separate | NOT | Separate |
| C11 | #37475 `target_layer_ids` assert ([5,19,33,47,61]); request-payload guard (penalties default, no required tool_choice, top_k 20 sent, no grammar); #43518 fix status in 0.5.21 | N01:275; N03:44; N04:99-103; N27:164-174; N28:159; I00:142,311-313; I02:294,319; CE:441; SB L698,839,935,1263; RQ F:266,282,355,467; EC:322-325,356; RV-A:182,228; RV-B:121,327 | Silent accept loss / batch poisoning | CPU seconds | PARTIAL (the windows send top_k 20, F-1) | Zero-GPU add-on (asserts) |
| C12 | Known-answer prefix per arm; deterministic inference; a synthetic "gate must FAIL a worse arm" test | N14:461; N18:192; N20:123,208; N09:122; N10:97 | Gate quality | CPU / small | PARTIAL (harness "corrupt" scenario 31/31, N20) | No / CPU |

### D. Prefix cache, Mamba and agent-side engine

| ID | Item | Key sources | Measures / why | Cost | Coverage | Verdict |
|---|---|---|---|---|---|---|
| D1 | **Arm-13 prefix-reuse telemetry + token-id divergence.** Fields: `return_output_ids` / `return_input_ids` (check the 0.5.21 field names); per-request cached / prompt; first divergent index; classes reused / lost_at_prefill_end / partial / zero-hit; MTP malformed / recovered tool-call counts | N06:39-50; N08:72-78; N09:51-55; N10:21-26; N11:127-129; N12:82-83; N13:25,91-96; N16:94,206; N22:69-71; N27:609,621; N28:203-215; AET:115,223,228,266; SA1:203-209; SA2:631,887-889,1040; SC:242,257,391,497,583; I06:292,316,345-351; I07:264,289,318-328; I08:301,316,355-359; I10:202-206,311,382; I11:164,185,209-218; E12 PLAN:344-346; R5:60-61,83; G4B:22; E12 FL:792,1395,1447; AVV:18-19; RV-A:194,224; RV-B:192 | R2 with raw reasoning still lost 26 + 27 partial of 120 follow-ups. Reply re-prefill is 37-76 % of uncached tokens (+about 10 % effective, est.). It also tells whether E16 raw content helps (RV-A:194: it regained 0 in R2) | 0 GPU (request flag + logging) | PARTIAL | **Zero-GPU add-on (top)** |
| D2 | G4-8 controlled cache replay (warm → exact replay → divergent → 12-prompt churn → replay; #36935 ratio) on ref and on any adopted at-N / MTP arm. The code exists: `E14M.agent_replay` (cell12) | E12 FL:1359-1480,1552,1620,1720,1822,1884,2000,2051; I06:263,292,352-355; I07:242,264,322-325; I08:301,373-377; I10:279; I11:165; SC:243,257,392,470,606 (p18 r1-2, p15 r3) | An arm that wins on speed but changes mamba slots could lose prefix hits | ≤ 4 min per arm (bounded 240 s) | PARTIAL (R2 default arm only) | Optional #9: conditional on adopting an at-N / MTP arm |
| D3 | Mamba end-of-prefill checkpoint protection (Franzen refresh-on-unlock / PREFILL_FINAL_ONLY port; mamba 96 at 12; int8 checkpoints at a lower mem; trim hysteresis; cache-aware admission) + agent replay | N06:46; N11:107-113,141; N12:79-81,89; N13:28,153,227; N25:58; N27:281-298; N02:L93,101,358,426; AET:168-183,202,267; SA1:551,785; SA2:632,895-896,1041,1045; RV-A:195,224; RV-B:135,314,335; RV-D:203-210,397; E12 PLAN:346; E12 FL:871 | Up to +14 % (317k zero / partial tokens in G4B). R2 replay deeper_miss 0 on the default arm | Patch port + replay | NOT | Separate (attribute misses on the EVAL120 logs first) |
| D4 | `--page-size 64` + `--mamba-track-interval 64` (`E12_MAMBA_TRACK_64`) | N05:29; RQ F:323,353; CE:195-197,266; SB L783,925; SC:221,469; E12 MS:46-47,52; E12 FL:573; AET:174,178; SA2:641-642; RV-B:139; RV-D:238-241,403 | Hit granularity in multi-turn work. Sources disagree on the value (AET low; MS "measure") | Arm + replay | NOT | Later (with D2) |
| D5 | Streaming sessions / session-radix / eviction policy / token-level continuation | N02:L101; AET:193-206,223,229,269; SA1:549-550; SA2:631,634-636; SC:498; RV-B:141 | Removes re-tokenization | Duck change, needs approval | NOT | Separate |
| D6 | Orphan generation after a client timeout or disconnect | I00:272,329-331; SC:408; E12 AV4:36; RV-B:197,327 (p13 r35, p14 r2, p19 r8) | A dead request holding a slot (EVAL30: 40 timeouts; the 1,800-s non-streaming reads) | about 1-2 min in any arm | NOT | Optional cheap add |
| D7 | LPM vs FCFS (#31954 cold-request starvation) | AET:174; E12 FL:480,558,573; I01:269,278; SC:468,576; RV-B:144 | First-exposure delays | CPU first (first-request queue waits in EVAL120); an arm only with Duck load | NOT | Later |
| D8 | #43204 engine kill when every cached mamba state is locked (14-20 running) | N27:263,273; RV-B:142,327 | Crash risk before adopting at-N | CPU source audit | PARTIAL | CPU before adopting at-N |
| D9 | KV fraction 1.0 vs 0.95 for the hidden run | I03:189-194,265; I04:51-54; I07:245,270; E12 FL:931,1166-1168,1267; RV-B:143; RV-C:213-216 | Retractions late in stage 2 | CPU from EVAL120 | PARTIAL | CPU |

### E. Startup, load, failure paths, watchdog (submission pipeline)

| ID | Item | Key sources | Measures / why | Cost | Coverage | Verdict |
|---|---|---|---|---|---|---|
| E1 | **JIT / compile cache.** Steps: fix the IndexError (keep rc/stderr, guard empty stdout, cell13); exclude `nv/` and `cuda/` (#42917: PPL 9.98 vs 6.05); manifest; **save at the end of E15**; attribute the 361 s with `SGLANG_JIT_CACHE_DEBUG=1`; restore + known-answer greedy (64 tok + 16 logprobs) in the next cold commit | N05:46; N07:28-41,77,91; N08:45,51; N09:28-35; N10:70-71; N11:34; N13:14,77,142; N16:189; N17:296; N20:182,235; N22:63-65; N23:66,90; N25:59; N26:462-473,639; N27:409; N28:297,317,417; N30:81; N31:27-29; N32:166-187,403,438; N33:124-143,404; N34:14,47; N37:44; N02:L173-175,364,414,442; SLE:152-195; SA1:570,789,840; SA2:543,673,1061,1077,1158; SB L841,927,1258,1278; SC:245,404,423,483,579; I09:523-528; I10:266-269,314-315,359-361; I11:168,188,229-233; RV-A:140,156,184,223; RV-B:166,265,321,337; RV-D:212-219,401; E12 FL:872; OM:425-431 | Cold 502 s vs warm 71 s: about 6-7 min more solving per run (about 1 %) and less launch-timeout risk | Save about 1-2 min wall at the end (CPU) after a CPU fix; restore = next commit | NOT | **Zero-GPU add-on** (save) + separate (restore) |
| E2 | Mid-run engine watchdog + relaunch (H1) + a GPU kill test at about minute 8 of the Duck run | N37:40; N32:280-284; RV-C:42-67,312; AUD:102; GV05:15,20; HL log_serverdeath; E12 AR35:62; AV35:11 (p05 r40, p16 r61, p17 r13, p19 r9) | Today a dead server = the rest of 12 h lost. The W6 + g13 arm has never run 12 h; nodelay showed real crash modes | Build 1-2 h + CPU harness; GPU test about 3 min | NOT | Separate (high value) |
| E3 | Launch fallback with the W1 flags / a no-spec ladder (H2) | N37:14,40; N32:286-288; N31:65; N33:291; RV-C:69-85,148,313; SB L707,736 | Any bring-up failure today = identity file, LB about 0 | CPU harness; forced-failure launch about 9 min | NOT | Separate (CPU first) |
| E4 | Hidden-mode failure-path harness: 240 synthetic tasks; missing model / draft, wrong sha, launch timeout, zero output, unreadable JSON, an error before the CELL 0 write; CELL 0 JSON read with a timeout | N32:276-290,402,424; N33:287-293,401; N34:22; RV-A:101,203,227; RV-B:172-173,320,337 | Each 0.00 path | CPU (Kaggle CPU kernel) | NOT | CPU |
| E5 | Runtime zero-throughput stall flag (running > 0, gen_throughput 0 for N reads). EVAL30 at 14,247 s: 11 running / 8 queued / 0.0, unexplained | I02:120,193,259,307; I03:104,248,333-335; I04:67,188; I05:152,280,338; I06:296; I07:265,342; I08:133,302; N16:241; SC:98,390; RV-B:196,327 | A silent mid-run stall | 0 GPU (heartbeat) | NOT | Zero-GPU add-on (log) + production later |
| E6 | Production accept-collapse / token-0 "!" watchdog; a real-running guard in the 12-h run | RQ F:266,282,339; EC:351-355; OM:484; PL:500-502; SA1:392,588; SB L839,1263; RV-B:120,327 | #43514 = silent full-run loss | CPU build + replay on recorded logs | NOT | Separate (pipeline) |
| E7 | First-line facts (hostname, uname, image digest, driver; a timed 64 MiB read per input; competition JSON in a thread with a timeout; early heartbeat) | N02:L189-202,384,414,442; SLE:262-267; SA1:572,697,789; I09:498-504; I10:191,369; I11:234-239 | The 10-22 empty-log ERROR class | CPU seconds | PARTIAL (env_report / read_probe / heartbeat exist) | Zero-GPU add-on |
| E8 | Slow-storage launch path on real Linux /proc: rchar / majflt count FUSE reads; StallMonitor soft release; Kaggle CPU kernel test. (First-launch 30-min timer: CLOSED in E14 builds, F-2) | SLE:303-355; PL:222-223; SA1:569,818,840; SA2:228,674,1078; I06:367-369; I07:343; I08:383; I09:346-348,391,516-521; I10:214-215,317,362-365; I11:71,187,220; RV-B:164,320 | A watchdog that kills a slow healthy load = 0 LB | CPU kernel | PARTIAL | CPU |
| E9 | Staging stop event on fallback; copy-failure branches (slow / truncated source, /dev/shm → /tmp) | N17:386; N20:34,83,232; N26:471; N27:409; N28:317; SA1:568-569; N07:52-57,84-86; N09:84-94; RV-B:163,278,348; RV-C:272 | The only open audit item on the submission path | CPU | PARTIAL | CPU |
| E10 | Wheelhouse as a Kaggle Model (181-s install from GCSFUSE); container start → T0 margin (about 300 s); subprocess timeouts on install; cancel API; MTP cold load; server-side token counts in the Duck report (54-82 % counted) | N24:35,53-55; N25:60; N37:44,51; N23:60; N35:26,94; KD:24; RV-A:67,150-151,185,199,206,221,223,226; RV-B:169; RV-C:177-195; RV-D:221-227,280-284,318,378,382,401 | Startup and analysis correctness | CPU / editor | NOT | CPU / separate |
| E11 | Kaggle CPU kit on the exact E15 sha (the E16 notebooks never went through it) | N37:16,54; RV-A:161; RV-C:255-260; RV-D:372 | The pinned Py3.12 behaviour (Thread._stop class) | CPU | Unknown for the final E15 sha (CPU harness run5 "E15 final" folder exists) | Do before push |

### F. Duck agent (separate runs; E15 is an engine experiment)

| ID | Item | Key sources | Why / impact | Verdict |
|---|---|---|---|---|
| F1 | Duck at 14-20 streams | = A18 | +8-25 % | Separate, right after E15 |
| F2 | Hybrid: Duck stage 1 + S1-60K plain stage 2, b1 off; CPU suite (N36:223-255); E14HYS 45-min smoke; E14HYEVAL120G4B | N36:24-65,184,223-259; N37:38; RV-A:163,191,220; RV-B:207-208,310,336; RV-D:68-77,393 | +2 to +6 LB est.; R5 got 8/13 on the tasks Duck left unverified | Separate |
| F3 | Earlier first check(): rev 6h; the harness auto-runs check() when transform is defined; a "next call must define transform + check" prompt; a code-intent stop (needs approval under the 60k floor) | N32:304-312,437; N33:186,194-210,405; N34:20,46; N37:41; RL:57-60; RX:56-57; WA:106-109; E12 FL:374,449,531; RV-A:190,220 | 12/17 R2 branches never called check(); 37 % of xhigh pre-check tokens come after "I'll code it". E16 (234d0919) covers only one nudge | Separate |
| F4 | Overfit: a generalization reminder after the first train-exact; anti-overfit ranking; a fresh attempt after a train pass; a hard-coded-offset detector | DR:412-430; WA:75-81; R5:84; N27:550-559,659; RV-D:79-117 | 36 % of accepted programs were test-wrong; 4c3d4a41 was lost twice | Separate / CPU replay |
| F5 | Selection-order replay (attempt_1 vs attempt_2) on the EVAL120 candidates | R5:84-86; E12 PLAN:86-91 | Free hits | CPU |
| F6 | Temperature 0.7 vs 1.0 accuracy A/B; presence penalty (works only under MTP) | E12 FL:40,169-203; WA:59,105; RV-D:157-163 | T 1.0 was adopted with no A/B | Separate (≥ 120 tasks) |
| F7 | Rev 6 knobs never A/B'd. Allocation: stage-2 chunk 12,288 vs 24,576; cap ladder; pause 25-40k; facts size; low effort on b1. Views and prompts: b0 facts vs raw grids; whole-grid `show()`; the `print(r,row)` guard gap; G4-6 24k nudge; "lookup table is acceptable"; the dict-unpack trap; the "Unknown tool: submit" count | E12 FL L1441-1583, 374, 585-596, 700-935, 403, 842, 496-1483; G4B:67,84-85; WA:73,85,108-110; SM:34; I06-I09 (p15 r33-34) | Coverage vs depth; accuracy | Separate / CPU |
| F8 | Branch-1 diversity / distinct pass@2 (b1 and attempt 2 gave 0 in R2) | N32:418,422; N33:299; N34:20,46 | pass2 = 0 | Separate |
| F9 | CPU rule library in the identity slots | N37:42; RV-D:129-137,286,398 | +0.5-1.5 LB, no downside | CPU (< 1 day) |
| F10 | NVARC union; Flash-Next Duck (E13 rows 19-35 in p17); token-efficient models (licence) | N37:46-47; RV-D:263-269,321-331,395,399; E13P | +3 to +8 (NVARC) | Separate / user decision |
| F11 | M1 isolation INCONCLUSIVE → 6 workers (needs approval); M4 self-tests on the first hidden task; M5 worker loop outside try/except; stage-1 ETA guard / admission floor 240 → 420 s | N37:45; RV-C:87-163,315,317 | Tail risks | CPU |
| F12 | **Arm-13 settings for a 15-min window:** the admit gate 240 s + the 180-s stop margin ≈ 47 % of 900 s; assert the 1,800-s request timeout and count timeouts; assert workers == 12 (no step-down); derive the Duck window from the arm's KV; log server gauges at start | I00:98,213,325-328; I02:102,315-316; I03:272,275,315-321; I04:239; I08:340-343 (p14 r9-11,25,38; p15 r25) | Arm 13 may otherwise measure mostly a wind-down | **Zero-GPU config check before push** |

### G. CPU analyses to run on the EVAL120 (44e11cf6 / 234d0919 / f87c5488) and E15 logs

None of these needs GPU time:
- decode tok/s by context bin (40-60k, 60-100k);
- acceptance per 10k context bucket and per output position;
- KV peak and retractions at 12 × 60-70k;
- real-running histogram;
- Traceback / rc / watchdog lines;
- stage-1 end time;
- LPM first-request queue waits;
- zero-hit attribution (trim vs eviction vs track boundary);
- E16 vs no-E16 cache classes;
- b1 first-call positions;
- stage-2 resume re-prefill;
- `resumes["first"]` == branch starts;
- first-check tokens (one definition);
- effective vs decode rate;
- LOW ∪ XHIGH union (a mixed-effort estimate);
- Poetiq R5 ∪ Duck unique solves;
- selection-order replay;
- serializer tamper grep;
- verify_sec / verify timeouts;
- a `gen_throughput 0` scan;
- F1/F2 metric recompute (gpu_hours inflated 11-15 %);
- server-side token counts;
- the 89-110 tasks under the 60k floor (N37:50 needs the user's view).

Sources: p05 r59-61; p06 r34,48-49; p09 r11,40; p12 r2,37,50; p13 r25,27,30-31,35,37; p14 r13,20,45,51-53; p15 r15,25; p16 r16,39,48-49,54,71,102; p18 r12,20; p19 r4,19,23,35-37.

## 3. Already measured / closed (do not re-propose)

| Item | Result |
|---|---|
| Topology | All pairs PHB; `p2p r` OK |
| NCCL baseline | 343.9 µs per 983,040-B call in a graph ≈ 56 ms comm/step. Eager curve 8 KiB-64 MiB measured (F-3) |
| `NCCL_P2P_LEVEL=SYS` | 5.5× slower |
| `SHM_USE_CUDA_MEMCPY` | Graph run timed out; eager slower |
| Profiler (W8, short) | Comm 59 of 116 ms; Marlin 25.3; other GEMM 14.5; GDN 8.0 (GDN sweep rejected); attention 2.7; sampling 2.4 |
| #44401 backport | No gain; the latch is the DFlash min-free-slots delayer |
| nodelay at mrr 13 | Crash at 13 running (`dflash_worker_v2.py:273`) |
| graphs 1..13 | Neutral, adopted |
| W6 / W4 at ~6k | +6.3 % / +5.3 % (gates PASS) |
| Target-only | 339.6 tok/s; DFlash2 = 1.49×; parity PASS |
| int8 mamba | OOM at mem 0.83 |
| Raw reasoning | 115 kept / 0 mismatch; cached 82 % |
| A2-1 replay | 67 / 26 / 27 / 0 |
| JIT tar | IndexError (the fix is open, E1) |
| Load path | 518 MB/s staging; /dev/shm 91.8 GB; cold 502 s / warm 61-76 s |
| `Thread._stop` crash | Fixed |
| Commit size limit | Fixed (< 400 kB) |
| Long band | p50 40,877 tokens (not 8.7k) |
| Removed / rejected (source or measurement) | vLLM fallback (does not exist); PCIe-IPC on 0.5.21; ReplaySSM + DFlash; forced custom AR; mixed chunk; `num_continuous_decode_steps`; torch.compile; `--dtype float16`; FR-Spec with DFlash; PP + DFlash; DP-attention; HiCache at KV 0.44; `--speculative-adaptive` |
| Effort | Effort and the 49k cap measured (S49 32.08 < 34.58 → 60k floor) |
| Already in E15 / EVAL120 | first-launch 75-min stall rule (F-2); Duck sampling and real prompts in the windows (F-1); latch fixes, more streams, MTP family, c12 × 1024 probes and target-only probe (E15); coverage at the hidden share, E16 nudge, LOW vs XHIGH (EVAL120) |

The full closed tables, with source lines, are in each part file (p01-p19, section "Already measured / closed").

## 4. Conflicts between sources, resolved

- **Width 4.** p05 r5 and p01 r19 say "no" (W6 is adopted). Twelve other part files say "yes". Long context is unmeasured and acceptance falls with context, so the yes side holds → ADD.
- **Chunked 2048.** Some say "needs Duck load only" (p02 r19, p07 r26, p09 r17, p10 r20). It is measurable in E15 if the latch arrivals record decode tok/s (B9) → ADD with B9.
- **2×TP2.** "Nearly rejected on memory" (N02, N25, I09-I11) vs "the largest untested lever" (RQ, SB, the user three times). The boot test settles it with a number for about 12 min → ADD (boot only).
- **NCCL.** "Closed by R2" (p05 r23, p15) vs "open" (p01, p04, p10). R2 closed only P2P / SHM-memcpy; PROTO / ALGO / channels / CTAS / BUFFSIZE were never measured → ADD bench-only.
- **Profiler.** p02 says it was never run; that is wrong (R2 ran it). What is open is W6 at 40k and the drafter / lm_head split → ADD a short window.
- **page-size / track-interval 64.** p08 and p18 say "yes, an arm". p06, p11, p13 and p19 say "only with a multi-turn replay". E15's steady windows show only the speed cost → later, with D2.

## 5. Ranked "add to E15 now" (max 8, about 60 GPU-min)

Prerequisites, all CPU, before the push:
- B9: the arrival-window tok/s in latch_test;
- B14: probe the chosen Duck arm + capacity gate / smoke on the Duck relaunch;
- E1: the JIT parse fix;
- raise `time_budget_sec` from 180 to about 240 min;
- re-run the Kaggle CPU kit on the new sha (E11).

| Rank | Item | GPU-min | Placement | Expected value |
|---|---|---|---|---|
| 1 | **A1: DFlash W4 arm** (`--speculative-num-draft-tokens 4`, latch, probe_n 12, plus a B3 65k window) | about 9 | Right after w8 (a Duck candidate) | −10 to +12 % tok/s on the submission engine; fewer #36548 errors; settles the width at Duck contexts |
| 2 | **A2: chunked prefill 2048 + max-prefill 4096 arm**, with the B9 arrival metric (also recorded on ref for a baseline) | about 8 | After W4 (a Duck candidate) | +0-15 % agent rate (prefill stalls 13-55 % of the window). The only cheap GPT-ordered arm that E15 dropped (N29:50) |
| 3 | **C1: answer-level #36548 probe**, c12 × about 150 + serial 20-50 on the ref and target-only launches (W4 inside its arm) | about 8-10 | Inside the existing ref / target-only phases | The only answer-level DFlash check. A silent error rate would cap the LB whatever the speed (−5 to +5 LB class, N37:36) |
| 4 | **A3: NCCL PROTO / ALGO / NCHANNELS / CTAS / NTHREADS / BUFFSIZE microbench** (bench-only, `--arm-env`, 3 repeats) | about 5-7 (during the copy) | Before the first launch | Comm is 51 % of the step; a ≥ 20 % per-call win ≈ +8-9 % tok/s as an env var for every later run |
| 5 | **B3: ~65k context band** on ref and the best MTP arm (W4 inside rank 1) | about 5 | Inside those arms | Duck p50 48-58k / p90 75-98k; DFlash vs MTP and the width ranking could flip above 40k |
| 6 | **A4: 2×TP2 single-replica boot** (KV caps, the custom-AR line, a 6-stream short window) | about 12 | Last before the Duck relaunch (report-only) | Settles the largest structural lever (0.7× to 1.6× estimates) with a measured KV number. The user has asked for it repeatedly |
| 7 | **B1: profiler window on ref W6 at the 40k band** (raw traces kept) | about 4 | Ref phase, after its windows | Confirms comm share at Duck-like context and with W6; splits drafter vs lm_head; directs vocab-parallel / TP2 / FP8 |
| 8 | **B2: reference windows repeated at the end** (A/B/A, boot noise) | about 5 | Just before rank 6 | Gives the noise band for every adopt decision (adopted margins of +2-6 % are near the noise) |
| | **Total** | **about 56-60** | | |

**If one more slot is free** (or swap for rank 6 or 7):
- D2 cache-replay on the adopted arm, about 4 min, only if an at-N or MTP arm wins;
- D6 orphan-generation check, about 2 min;
- A17 T 0.7 acceptance window, about 2-3 min, speed only;
- A16 target-only windows at 12, about 3 min;
- C2 batch-invariance, about 2 min;
- B16 probes on the ReplaySSM arms, about 3 min;
- A5 backport + nodelay, about 7 min, only if arm 6's latch is below about 0.9.

**Zero-GPU add-ons to put in the same E15 build:**
- D1: arm-13 cached / prompt per request, return ids, reuse classes, MTP tool-call counts;
- E1: JIT tar save with the parse fix, `nv/` and `cuda/` excluded, compile attribution;
- B4: spec-health rules;
- B5: device-timer / step-time env, after a CPU check;
- B6: dmon logger;
- B7: `NCCL_DEBUG=INFO` on one launch + PCIe / lscpu facts;
- B8: extra window fields;
- B11-B13 and B15: decision-logic fixes;
- B17: MTP log greps;
- B18: error-sign list check;
- C11: config and payload asserts;
- E5: stall flag in the heartbeat;
- E7: first-line facts;
- F12: the arm-13 15-min-window config check.

## 6. Separate run / later (ranked)

1. **A18 / F1: a Duck run at 14-20 real streams** on the E15 winner. It needs the `--streams N` build option. +8-25 % claimed.
2. **C6: engine/quant vs prompt attribution of 29.17 vs 34.58** (S60 notebooks are built; or an LB slot), plus C7 INT4 inflation (CPU log compare first).
3. **E2 + E3 + E4: mid-run watchdog / relaunch, W1-flag launch fallback, and the 240-task failure-path harness.** CPU harness first, then a GPU kill test in a Duck run. These remove the LB-0 tails.
4. **F2: Hybrid Duck + S1** (+2 to +6 LB est.): CPU suite → 45-min smoke → EVAL120.
5. **E1 restore + known-answer gate** in the next cold commit. It consumes the tar saved by E15.
6. **A19: vocab-parallel verify sampling** (+9-11 % est.): patch + CPU exactness test.
7. **D3 (+ D4): Mamba end-of-prefill checkpoint protection** with an agent replay (up to +14 %). Attribute the zero / partial misses on the EVAL120 logs first (G).
8. **C8: calibrated FP8 KV scales.** CPU loader check now; then a gated arm + accuracy run.
9. **C5 / C4: task-level DFlash vs target-only parity at ≥ 60k; tool-call-depth parity.** The PARITY notebooks need the C6-1 / C6-3 fixes.
10. **F3 / F4 / F5: earlier check() (rev 6h, auto-check), overfit levers, selection-order replay.** The CPU replay goes first.
11. **A4 full 2×TP2** (two servers, client split by port), only if the E15 boot test shows enough KV per replica.
12. **A20: SGLang 0.5.22 / nightly; A8 / A9 / A10 / A11 / A14 / A15** env and flag arms, after CPU source checks.
13. **F6 / F7 / F8:** Duck knob A/Bs (temperature, chunk 12k vs 24k, views, nudges, b1 diversity).
14. **E10:** wheelhouse as a Kaggle Model, T0 margin, cancel API, server-side token counts; **F9:** CPU rule library (< 1 day, no downside); **F10:** NVARC union.
15. **D7 / D9 / D8:** LPM vs FCFS, KV fraction and the #43204 audit (CPU first).
