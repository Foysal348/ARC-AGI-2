# B_web — known silent-accuracy bugs for our Qwen3.8-27B hybrid-GDN stack (web research, 2026-10-24)

Scope: bugs that silently lower accuracy (wrong state, drift, truncation), not crashes. Stack under review:
SGLang 0.5.21, RedHatAI/Qwen3.8-27B-INT4 (compressed-tensors W4A16, Marlin), 4x L4 sm_89, TP4, FP8 e4m3 KV,
`--mamba-ssm-dtype float16`, `--mamba-radix-cache-strategy extra_buffer_lazy`, `--max-mamba-cache-size 56`,
12 running, chunked prefill 4096, CUDA graphs (prefill graph off), overlap scheduler on (default), DFLASH +
BF16 DFlash2 drafter (`unquant`, 8 draft tokens), triton GDN, flashinfer attention, temperature 1.0, ~60k thinking,
tool calls (`qwen3` reasoning parser, `qwen3_coder` tool parser, `tool_choice: auto`, `preserve_thinking`).
Second stack (best LB 34.58): vLLM 0.19 + FP8 checkpoint + MTP-3 + prefix caching.

Method: every GitHub item below was read in full (body plus all comments) through the GitHub API (`gh`), not
from search snippets. "VERIFIED-SRC" means I checked the code in our local 0.5.21 source
(`D:\ARC AGI 2\_scratch\session_1c6db7aa\sgl_src\src\sglang`). "VERIFIED-PROJ" means I checked our own build
scripts, logs or the checkpoint files. "INFERRED" means it is my reasoning and has not been measured.
Raw issue dumps are in `D:\ARC AGI 2\_scratch\kernel_issue\sg\` and `...\vl\`. Release notes are in
`rel_v0.5.21.md` and `rel_v0.5.22.md`. SGLang releases: 0.5.21 = 2026-10-02, 0.5.22 = 2026-10-19
(952 commits ahead).

Facts about our own config that the ranking below depends on:
- VERIFIED-PROJ, from the RedHat `config.json`: `lm_head` is NOT quantized. It is on the ignore list together with
  `linear_attn.in_proj_a/in_proj_b/norm`, `mtp.*` and the vision tower. The checkpoint is symmetric int4, group 128,
  `actorder: static`. The config says `mamba_ssm_dtype: float32` and `tie_word_embeddings: false`.
- VERIFIED-PROJ + VERIFIED-SRC on FP8 KV scales: the checkpoint ships 32 `self_attn.k_scale` / `v_scale` tensors
  (values 0.021–0.254; our E11 preflight already logged this). SGLang 0.5.21 loads them:
  `QWEN3_5_KV_SCALE_MAPPER` maps `.self_attn.k_scale` to `.attn.k_scale` (`models/qwen3_5.py:1575`), and
  `CompressedTensorsKVCacheMethod` accepts static per-tensor fp8 (`compressed_tensors.py:1179`).
  `process_weights_after_loading` copies the values into `k_scale_float` (`kv_cache.py:51-83`). The flashinfer
  backend passes them on write and on read (`flashinfer_backend.py:950-953, 1388, 1450, 1520`). The startup line
  "Using FP8 KV cache but no scaling factors provided. Defaulting to 1.0" comes from `load_model_utils.py:113-136`.
  It prints whenever `--quantization-param-path` is unset, so it does not show that the checkpoint scales were
  ignored. Not yet verified: the runtime value of `k_scale_float` on a live server (one log line would settle it).
  The DFlash2 drafter's KV is fp8 with no scales, so it runs at 1.0; that affects acceptance only.
- VERIFIED-PROJ: `e11_flags()` (`build_e11_05_s49_sglang.py`) does NOT pass `--enable-mixed-chunk`,
  `--disable-overlap-schedule`, `--enable-hierarchical-cache` or any grammar or strict-tool option. E12 adds
  `--schedule-policy lpm`, the qwen3/qwen3_coder parsers, `preserve_thinking: true` and
  `--incremental-streaming-output --stream-interval 1`. E12 requests use `tool_choice: "auto"`.
- VERIFIED-SRC: DFlash non-greedy verify uses SGLang's target-only speculative sampling. The defaults are
  `speculative_accept_threshold_single = 1.0` and `speculative_accept_threshold_acc = 1.0` (`arg_groups/fields/spec.py:108-115`),
  so by design it is lossless at temperature 1.0 when the numerics are exact.
- VERIFIED-SRC: on sm_89 every GDN path is Triton. The FlashInfer/CuTe GDN fast paths gate on sm 9/10
  (`gdn_backend.py:195-224`). FP16 stochastic rounding for the SSM cache needs SM100 with the triton backend
  (`arg_groups/fields/exec_.py:377-383`), so our fp16 state uses plain round-to-nearest.

---------------------------------------------------------------------------------------------------------------

## Ranked list (likelihood that it hits us × impact)

| # | Finding | Status in our 0.5.21 | Fixed in | Applies to us? |
|---|---|---|---|---|
| 1 | Lazy mamba checkpoint donated with a stale length when the lazy slot alloc fails → wrong GDN state restored on a later prefix hit (SGLang PR #43567) | Present (VERIFIED-SRC) | 0.5.22 | **Very likely**: extra_buffer_lazy, overlap on, a tight mamba pool, multi-turn prefix hits |
| 2 | DFlash/DSpark TARGET_VERIFY vs plain decode GDN state drift, amplified by concurrency and low-precision state (#36548, #35150, #38009, #36014, #42209) | Present, unfixed on main | not fixed (PRs open) | **Likely**: DFlash2 + 12 concurrent + fp16 state. Our BF16 lm_head is a partial mitigation |
| 3 | `--mamba-ssm-dtype float16`: not in SGLang's validated matrix; fp16 SSM-cache rounding raises verbosity in a Mamba hybrid (NVIDIA paper); fp16-overflow family in vLLM | Our choice | n/a | **Plausible**, impact unknown; cheap to A/B |
| 4 | vLLM MTP + prefix caching on hybrid GDN: accuracy −20…−50 %, "runaway reasoning to max_tokens" (#43559, #47194, #50188, #48375 …) | Affects 0.21–0.25 clearly, partial fix in 0.26 | 0.26/0.28 (partly) | **Uncertain** for our 0.19 best-LB stack; not reproduced on 0.19 in one test, but MTP parsers were buggy before 0.23 |
| 5 | SGLang streaming reasoning parser ends `<think>` early when `<tool_call>` is quoted inside reasoning and tools are declared (#42030) | Present since 0.5.10 | not merged | **Possible**, if Duck uses `stream: true` with tools |
| 6 | Stale CUDA driver compute cache in `$SGLANG_CACHE_DIR/nv` → corrupt, nondeterministic W4A16 outputs (PPL 6.28 → 10.8) (#42917) | Environment | n/a (clear the cache) | Low on fresh Kaggle containers; **high impact** if we ship or persist `~/.cache/sglang` |
| 7 | Spec decode + structured output resume from a wrong mamba state (#43029); DFlash batch "!" poisoning with grammar traffic (#43514) | #43029 present; #43514 unfixed | #43029 in 0.5.22 | Low: needs grammar or strict tools (we use `tool_choice: auto`) |
| 8 | sigmoid(beta) rounded through bf16 in GDN packed decode (#38975) and in the prefill gating kernel (#40362) | Both present (VERIFIED-SRC) | vLLM fixed (#53877); SGLang PRs unmerged | Low: small drift; the DFlash verify path keeps beta in fp32 |
| 9 | FP8 KV at long context: premature `<|im_end|>` (vLLM #63000, unresolved); drafter KV fp8 with no scales | Present | n/a | Low |
| 10 | Batch-shape and cache-hit logprob non-invariance (#43956, #41351, #45481, vLLM #59764) | Present | n/a | Noise level at T=1, not a bias |
| — | Ruled out or already fixed in 0.5.21: #39342 (mixed chunk), #20791 (flashinfer GDN no_buffer), #43331 (CuTe DSL), #22311 (split views), #37817 (DFlash boundary), #31720 (AWQ loader), #30178/#31719 (conv dtype), #40959 (Anthropic endpoint), #60174/#61738 (other vLLM versions) | see below | | |

---------------------------------------------------------------------------------------------------------------

## 1. Lazy Mamba checkpoint stale donation → corrupted prefix-cache state — HIGHEST for us

- Link: https://github.com/sgl-project/sglang/pull/43567 ("[Unified Radix] Invalidate lazy Mamba checkpoints before
  in-place tracking"), opened 2026-10-10, merged 2026-10-11, listed in the v0.5.22 notes.
- Affected config: `--mamba-radix-cache-strategy extra_buffer_lazy` with the overlap scheduler, on both the normal
  decode path and the speculative path (`mamba_lazy_prealloc_at_boundary`, `mamba_lazy_spec_prepare`).
- Mechanism (from the PR): when lazy tracking cannot allocate its optional pending slot, decode or verify
  overwrites the keep slot in place. The keep slot's old `mamba_last_track_seqlen` stays valid, so overlapped
  prefill result processing can donate that buffer to the radix tree under the old prefix length. Later cache hits
  on that prefix restore a state that belongs to a later position.
- Symptom and magnitude: HTTP 200 with silently changed tokens. On Qwen3.5-0.8B the next-token KL vs a cold
  compute was 0.649 with the bug and 0 with the fix (registered test `test_mamba_cache_kl.py`). Max logprob
  difference was 1.04.
- VERIFIED-SRC: our 0.5.21 has both allocation sites with no invalidation
  (`managers/schedule_batch.py:3464-3530`). The comment there says "No evict-retry: a transient slot is not worth
  evicting a cached checkpoint for; on failure tracking degrades in place". So allocation fails whenever free mamba
  slots run out. Freeing a slot from the cache is never tried.
- Why it plausibly hits us (INFERRED): the E11/E12 config is `max_mamba_cache_size 56` with 12 running ×
  4 slots = 48 live. That leaves about 8 slots for cached checkpoints and transient ping-pong slots, and cached
  checkpoints fill them quickly. Every Duck/agent turn re-sends the conversation and hits the previous turn's
  prefix, so a stale state lands mid-conversation. The model then "forgets" or confabulates context with no error
  anywhere. That would show up as lower solve rates and longer, confused reasoning.
- Fix or workaround: upgrade to 0.5.22, or backport the two-line patch (in both functions, add an
  `else: req.kv.mamba_last_track_seqlen = None` when `new_slot is None` / no pending slot). Alternatives are
  non-lazy `extra_buffer` (5 slots per request, which does not use this path) or more mamba slots. Related
  0.5.22 fix: #43029 (see item 7).
- Detection: send the same prompt cold and then warm after other traffic, and compare the next-token
  distribution (the PR's test). Our logs can also count `#cached-token` > 0 on turns ≥ 2.

## 2. DFlash2 verify-path GDN state drift, worse under concurrency — likely, unfixed

- Links:
  - https://github.com/sgl-project/sglang/issues/36548 "[Bug] DFlash2 state corruption with concurrent requests"
    (2026-08-26, open)
  - https://github.com/sgl-project/sglang/issues/35150 "Qwen3.8 DSpark forced-reject is not lossless: accumulated
    GDN state drift vs Base decode" (2026-08-17, open)
  - https://github.com/sgl-project/sglang/issues/38009 "[DFlash2] Greedy output diverges from target-only
    Qwen3.8-27B when thinking is enabled" (2026-09-04, open; 4x RTX 3090 TP4, BF16, block 8)
  - fix attempts, all OPEN and unmerged: #36014 (align verify beta semantics, partial), #35725 (route DFlash/DSpark
    commits through the ReplaySSM fold), #42209 (exact snapshot-free GDN verify `SGLANG_ENABLE_GDN_REPLAYSSM_FOLD`,
    80/80 bit-identical vs stock in their test)
- Symptom and magnitude, as reported (#36548, Qwen3.8-27B NVFP4 + DFlash2 8 draft tokens, bf16 state, fp8 KV):
  - Greedy 4-item ordering task: DFlash serial 0/100 wrong; DFlash at concurrency 8 7/100 wrong (111/304 = 36.5 %
    on the expanded affected subset); no speculation at concurrency 8 0/304.
  - The wrong answers look normal: the reasoning states the correct constraints and then answers wrong.
  - One user reported GPQA around 50 % vs about 90 % public, and fixed it by moving to 0.5.18 + MTP/EAGLE. The same
    user said "the last user message is sometimes appended to the wrong context" (anecdotal, not localized).
- Ablations, each run as a single change against 111/304: fp32 mamba state → 37/304; `--disable-decode-cuda-graph`
  → 37/304; draft depth 4 → 37/304; beta hunk of #36014 → 37/304. A dense BF16 lm_head → 1/304. The authors read
  the head result as "the drift is unchanged; the dense head keeps enough logit margin".
- Root-cause localization (#35150 and #36548 comments): with frozen inputs, batch 1 and every draft force-rejected,
  TARGET_VERIFY still diverges from plain decode in 19/32 cases. Operands are bitwise equal, and the first
  difference is in the SSM transition arithmetic of the verify kernel. A BF16 persistent state amplifies it
  (first divergence at token 23 with bf16 state vs 38 with fp32), but fp32 does not remove it. z-lab/dflash#159
  reproduces greedy divergence in MLX, so part of it is in the verify contract itself.
- #38009 (closest to our setup: TP4, BF16 target, DFlash2 block 8): thinking-on greedy diverges at token 30,
  thinking-off matches. A comment shows DFlash2 output also changes across server restarts, with accept length
  swinging from 2.5–3.5 to 4.4–6.2 between boots.
- How it applies to us (INFERRED): we run DFlash2 with 8 draft tokens at 12 concurrent. The fp16 state has more
  mantissa than bf16 but less than fp32. Our BF16 lm_head is the mitigation that took them from 111 to 1 of 304.
  At temperature 1.0, small logit drift changes the sampling distribution slightly rather than flipping argmaxes,
  so the expected damage is smaller than in their greedy tests, but it is not zero. Long 60k thinking traces
  accumulate drift.
- Workaround options: A/B DFlash vs no-spec at the same concurrency on a fixed eval subset; fp32 SSM state;
  shorter draft depth; or 0.5.22+ with the #42209 fold if it merges.

## 3. `--mamba-ssm-dtype float16` (config says float32) — unvalidated precision choice

- SGLang's Qwen3.8-27B cookbook (https://docs.sglang.io/cookbook/autoregressive/Qwen/Qwen3.8-27B) validates
  only `float32` and `bfloat16` (202 SM12x cells, GSM8K 93.18–95.15 %) and says "Treat `bfloat16` as an accuracy
  gate and validate it for your workload". float16 is not in the matrix. The Qwen3-Next doc page lists only
  bf16/fp32 (https://docs.sglang.ai/basic_usage/qwen3.html). VERIFIED-SRC: float16 is an accepted choice
  (`exec_.py:367`), and SR rounding is unavailable to us (SM100 only on triton).
- Indirect evidence:
  - NVIDIA Nemotron 3 Super paper (https://arxiv.org/pdf/2604.12374; Mamba2 hybrid, not GDN): casting the SSM
    cache to FP16 gives up to +37 % verbosity even with BF16 weights and activations, and up to +40 % with W8A8.
    FP16 + stochastic rounding restores fp32-like accuracy and verbosity. A verbosity increase is exactly the
    failure mode that eats our 60k budget and coverage (cap hits).
  - vLLM fp16-overflow family: https://github.com/vllm-project/vllm/pull/54146 (GDN readout overflow with fp16
    activations → NaN → endless "!!!!"), https://github.com/vllm-project/vllm/pull/62119 (chunk path), and
    https://github.com/vllm-project/vllm/issues/62781 (2026-10-21, Qwen3.8-27B-based AutoRound W4A16 with
    `--mamba-ssm-cache-dtype float16`: long-context needle 0/9 at 4.7k–37k tokens, "multilingual token soup").
    The 62781 reporter argues the unnormalized GDN state can saturate fp16's 65504 "inside the state". That is
    their hypothesis, on XPU, on a stack with other known gaps.
- SGLang bf16-vs-fp32 GSM8K (no thinking, short): #41938 / #42024 (H200 FP8) show fp32 90.45–90.98 vs bf16
  90.30–90.67. That is about 0.3 pt, and it says nothing about 60k-token traces.
- My assessment (INFERRED): our activations are BF16, so the vLLM fp16-activation readout overflow does not apply.
  The delta rule with L2-normalized keys keeps the state roughly bounded by |v|, so state overflow is unlikely, but
  not proven. The real risk is accumulated rounding over 60k tokens (fp16 RTN) plus the DFlash verify drift
  amplification from item 2. Our best LB stack (vLLM, auto SSM dtype) almost certainly ran fp32 state: a vLLM 0.28
  comment in #55291 says "Auto SSM dtype resolves to FP32" for Qwen3.6. I did not verify this for 0.19.
- Cheap test: the same 12 tasks at fp32 vs fp16 (and optionally bf16), comparing output length, cap-hit rate and
  solves, or a teacher-forced logprob comparison on a saved 60k trace.

## 4. vLLM path (best LB 34.58): MTP + prefix caching on hybrid GDN

- https://github.com/vllm-project/vllm/issues/43559 (2026-05-25, closed 2026-08-06): Qwen3.6-35B-A3B,
  MTP + `--enable-prefix-caching`. Accuracy fell from about 94 % to about 75 %, and other users saw about 90 → 50 %
  on tool-calling. One said "~50 % drop on qwen3p6-27b". With either feature alone accuracy was unchanged. A
  0.26.0 run showed "runaway generation: reasoning grows ~40 % and hits max_tokens without the answer" on
  long-shared-prefix prompts. A deterministic A→B→A probe failed on 0.21–0.25.1 and passed on 0.26, but 0.26 still
  showed temp-0 divergence and CUDA crashes. One 0.19.1 run of the probe was clean (Qwen3.5-9B). Maintainers'
  caution: MTP on Qwen was broken by parser bugs before about 0.23.
- Related: https://github.com/vllm-project/vllm/issues/47194 (Qwen3.6-27B GPTQ, MTP3 + APC: tool-call leakage
  and needle-recall failure; one reporter clean on 0.28.0); https://github.com/vllm-project/vllm/issues/50188
  (0.23, repeated identical tool prompts corrupt; root cause `MambaManager.find_longest_cache_hit`, fix #48375);
  https://github.com/vllm-project/vllm/issues/55291 (Qwen3.6-27B-FP8 on 0.21 collapses into "!!!!" for all later
  requests; not reproduced on 0.28).
- https://github.com/vllm-project/vllm/issues/39056: on vLLM ≤ 0.19, a tool call emitted inside `<think>` is lost
  (it lands in `reasoning`, `tool_calls` is empty). Fixed for that pattern in ≥ 0.24.
- Applies to us? The S1-60K vLLM 0.19 stack is direct reasoning (no tools) with MTP-3 and APC. Prefix hits there
  are only on the shared ARC prompt prefix, not multi-turn, so the A→B→A pattern is weaker. E12-V (Duck on vLLM
  0.19) is multi-turn with tools and would be exposed to both. If we return to vLLM, use ≥ 0.28. INFERRED, not
  measured on our tasks.

## 5. SGLang streaming: `<tool_call>` quoted inside reasoning ends the think block

- https://github.com/sgl-project/sglang/pull/42030 (OPEN). Cause: in
  `BaseReasoningFormatDetector._parse_streaming_increment_impl`, a `tool_start_token` seen while reasoning ends the
  block immediately. This has been in every release since v0.5.10 (#17714). A 2026-10-04 comment on
  https://github.com/sgl-project/sglang/issues/31118 confirms that `Qwen3Detector` sets `tool_start_token` too, so
  Qwen is affected.
- Symptom: in streaming with tools declared, `reasoning_content` stops at the quote. The rest of the reasoning plus
  `</think>` becomes content or a bogus tool call. Non-streaming is correct. On GLM: 19/20 broken with tools under
  sampling.
- Applies to us if the Duck client calls `/v1/chat/completions` with `stream: true` and tools. Our server runs
  `--incremental-streaming-output`, which suggests streaming. Qwen3.8 reasoning about tools may literally write
  `<tool_call>`. Check saved traces for reasoning cut at `<tool_call>`, or use non-streaming for tool turns.
- Neighbours: https://github.com/sgl-project/sglang/issues/43150 (streaming `qwen3_coder` emits unterminated JSON
  when the model omits `</function>`; fix #43467 closed unmerged) and #42260 (Anthropic endpoint only).

## 6. Stale CUDA driver compute cache → silently wrong W4A16 results

- https://github.com/sgl-project/sglang/issues/42917 (2026-10-07). Qwen3.8-27B compressed-tensors W4A16
  (symmetric, group 128), the same quant family as ours.
  - Reported: PPL 9.6–10.9 and top-1 agreement about 70 % vs vLLM's PPL 6.05 and 93 %, on 0.5.19–0.5.21.
  - Root cause (reporter, confirmed): SGLang sets `CUDA_CACHE_PATH=$SGLANG_CACHE_DIR/nv` (default
    `~/.cache/sglang/nv`). A bad entry that persisted across containers made the results wrong and
    nondeterministic.
  - Emptying only `nv/` restored PPL 6.278 / top-1 93.6 %, bit-identical across boots and hosts. Clearing `jit/`,
    `triton/` or `inductor/` did not help. A clean SGLang matches vLLM (median |Δlogprob| 0.004).
- It also confirms that the 0.5.21 compressed-tensors WNA16 path itself is correct (TP1, sm_120).
- Applies to us only if a Kaggle dataset or wheelhouse ships a pre-populated `~/.cache/sglang` (or
  `CUDA_CACHE_PATH`), or reuses one across versions. Fresh containers are clean. Worth a one-line check in the
  notebook, e.g. assert the `nv/` dir is empty or local at start.

## 7. Speculative decoding + structured output (grammar) mamba bugs

- https://github.com/sgl-project/sglang/pull/43029 (merged 2026-10-10, 0.5.22 "Important fix"): hybrid models
  could resume from wrong mamba states when spec decoding and structured output were used together.
  `_mamba_check_track_boundary` used the drafted length instead of the grammar-committed length. Present in our
  0.5.21.
- https://github.com/sgl-project/sglang/issues/43514 (2026-10-10, open). DFlash + Qwen3.8-27B with
  `tool_choice: required` grammar traffic: the whole running batch emits token 0 ("!") until `max_tokens`, accept
  rate 0, no error. Seen on 0.5.19 and 0.5.20, about 30 % per round on a warm instance. Their config (TP4,
  flashinfer, extra_buffer, mixed chunk, hicache) overlaps with ours. It needs grammar requests in the batch.
- Applies to us only if a request uses `tool_choice: required`, json_schema/regex, strict tools or
  `SGLANG_TOOL_STRICT_LEVEL`. We use `tool_choice: auto` (VERIFIED-PROJ for E12). Cheap detector: flag outputs
  with long runs of "!".

## 8. sigmoid(beta) rounded through bf16 (GDN state drift)

- https://github.com/sgl-project/sglang/issues/38975 (packed decode `fused_recurrent.py:255`, KDA replay
  `fused_recurrent_linear_replayssm.py:138`); fix PR #38977 OPEN.
- https://github.com/sgl-project/sglang/pull/40362 (prefill/extend `fused_gdn_gating.py:41`); closed unmerged.
- The vLLM equivalent was fixed in https://github.com/vllm-project/vllm/pull/53877 (merged 2026-08-30, so vLLM 0.19
  still had it).
- Magnitude: up to 0.39 % per-value beta error. Over 1000 decode steps the state rel-L2 is 1.41e-3 vs 1.05e-7
  fixed (kernel test). There is no model-level eval.
- VERIFIED-SRC: all three lines are present in our 0.5.21.
- Applies to us partly: plain decode packed kernel is barely used under DFlash, because the verify keeps beta in
  fp32 (#35150). The prefill gating kernel runs for every prompt and tool-result extend. Low impact; one-line
  patches.

## 9. FP8 KV specifics

- Checkpoint scales are loaded (see the facts section). The drafter KV is fp8 with scale 1.0, which affects
  acceptance only.
- https://github.com/vllm-project/vllm/issues/63000 (2026-10-21, open): Qwen3.8-27B AWQ + fp8 KV + MTP, rare
  premature `<|im_end|>` mid-sentence at 39k–198k-token contexts (1/19 real, 2/13 synthetic). A controlled
  fp8-vs-fp16 KV A/B at 102k showed 0/8 vs 0/8, so it is unproven. Same issue: vLLM adds 248044
  `<|endoftext|>` from `generation_config` as an extra stop token (benign).
- https://github.com/vllm-project/vllm/issues/60174 (vLLM 0.30/0.31 only): DFlash2 + prefix caching produced
  garbage after a cache hit. First blamed on the drafter's fp8 KV (no scales), the real cause was the drafter's
  sliding-window block size (fix #60252). Not our versions.

## 10. Numerical non-invariance (noise, not bias)

- https://github.com/sgl-project/sglang/issues/43956: Qwen3.8-27B scores depend on batch shape. P goes from 0.50
  to 0.62 on a BF16 logit grid; mostly lm_head output precision, so `--enable-fp32-lm-head` is suggested for
  scoring.
- https://github.com/sgl-project/sglang/issues/41351: first radix-hit pass differs from repeats. Traced to
  FlashInfer `bmm_fp8` batch shape (ModelOpt FP8) — not GDN state.
- https://github.com/sgl-project/sglang/issues/45481 (PP + NEXTN) and #43413 (deterministic mode does not cover
  hybrid Mamba2).
- vLLM https://github.com/vllm-project/vllm/issues/59764 (Qwen3.6 logprobs move by up to 0.2 when another sequence
  shares the step) and https://github.com/vllm-project/vllm/issues/61738 (wide verify EOS at prompt_len+8; judged a
  bf16 near-tie, still seen on 0.32 MTP).
- At temperature 1.0 these are noise. They matter only for greedy or argmax decisions.

---------------------------------------------------------------------------------------------------------------

## Not applicable or already fixed for our exact config (checked)

- #39342 `--enable-mixed-chunk` corrupts mamba radix checkpoints (EM 0.91 → 0.84, about 10 % answers changed;
  open): https://github.com/sgl-project/sglang/issues/39342. We do NOT pass mixed chunk (VERIFIED-PROJ). Keep it
  off with extra_buffer(_lazy).
- #20791 FlashInfer GDN decode + no_buffer (GSM8K 0.99 → 0.89–0.94): https://github.com/sgl-project/sglang/issues/20791.
  Fixed in flashinfer #2810, and we use triton + extra_buffer_lazy anyway.
- #43331 CuTe DSL GDN decode reads the state transposed (GSM8K 0.87 → 0.01): https://github.com/sgl-project/sglang/issues/43331.
  Only with `--linear-attn-decode-backend cutedsl`; fixed in 0.5.22 (#43332).
- #22311 Qwen3.5-27B non-contiguous GDN split views (3/50 vs 49/50): https://github.com/sgl-project/sglang/issues/22311.
  v0.5.10 era, fixed in April.
- #37817 DFlash misses mamba checkpoints when accepted tokens cross a track boundary:
  https://github.com/sgl-project/sglang/issues/37817. Fixed by #37818 (merged 2026-09-12). VERIFIED-SRC:
  `dflash_worker_v2.py:2041-2055` uses `seq_lens_post_verify`.
- #31720 Qwen3.6-27B AWQ degenerate on SGLang (GDN packed-loader split for AWQ `PackedvLLMParameter`):
  https://github.com/sgl-project/sglang/issues/31720. AWQ-specific; #42917 shows compressed-tensors W4A16 correct
  at TP1. Not publicly verified at TP4 (INFERRED fine).
- #30178 / #31719 conv-state dtype vs `--dtype float16` (crash, not silent). We serve bf16.
- #40959 Anthropic `/v1/messages` splices prior thinking into content. The Qwen3.8 template dropped the inline
  `</think>` fallback, and the model then emits `</think>` as text. We use `/v1/chat/completions` with
  `reasoning_content` (SGLang) or `reasoning` (vLLM), so it does not apply. Any harness that puts prior thinking
  inline in `content` would hit this degradation on Qwen3.8.
- #39826 spec decode counts reasoning tokens past EOS (accounting only; fix #37450 open). The report notes
  `finish_reason: stop` with empty answer content on Qwen3.8-27B + DFlash.
- #41736 / #41737 DFlash NaN/Inf leaking across requests in draft grouped-conv or selector. Merged after 0.5.21
  (VERIFIED-SRC: the old multiply-mask and argmax code is present). Draft-only and only when NaNs exist, so low.
- #38485 ReplaySSM CPU retraction loses pending updates: dev branch after #35544; not in our path unless
  ReplaySSM is enabled.
- HiCache wrong-output bugs (#39830, #44735, #45400): we do not use `--enable-hierarchical-cache`.
- vLLM #55894 (Mamba2 + MTP decode rows through prefill kernels) and #59933 (RecoverSSM align boundary): other
  model families or versions.

## Model card / settings notes (Qwen3.8-27B, https://huggingface.co/Qwen/Qwen3.8-27B)

- Thinking mode recommended sampling: `temperature=1.0, top_p=0.95, top_k=20, min_p=0, presence_penalty=0,
  repetition_penalty=1.0`. It says presence_penalty 0–2 can reduce endless repetition at a small quality cost.
  Worth confirming our requests send top_p 0.95 / top_k 20, since SGLang defaults are top_p 1 / top_k -1 unless
  `generation_config` is applied. Not a bug, but a deviation from the recommended settings.
- Recommended output budget for agentic tasks is very large (reasoning up to 262k).
- Static YaRN is advised only for long contexts. We do not use it.

## Suggested minimal checks (for the caller to schedule; nothing was run)

1. Apply the #43567 two-line patch, or move to 0.5.22, or switch to `extra_buffer` — the top candidate.
2. A/B `--mamba-ssm-dtype float32` vs `float16` on the same 12 tasks, comparing solves, mean output tokens and cap
   hits.
3. A/B DFlash on vs off at the same concurrency on the same subset (#36548 pattern).
4. Grep saved traces for reasoning cut at `<tool_call>` (#42030), long "!" runs (#43514/#55291) and empty content
   after a long reasoning.
5. Log `layer.k_scale_float` once at startup to confirm the checkpoint KV scales are live, and assert that
   `$SGLANG_CACHE_DIR/nv` is fresh.

Sources (web): GitHub issues/PRs linked inline; SGLang Qwen3.8-27B cookbook; SGLang Qwen3-Next doc
(https://docs.sglang.ai/basic_usage/qwen3.html); Qwen3.8-27B model card; RedHatAI/Qwen3.8-27B-INT4
config.json and model.safetensors.index.json (https://huggingface.co/RedHatAI/Qwen3.8-27B-INT4); Nemotron 3 Super
paper (https://arxiv.org/pdf/2604.12374); Kaggle ARC-AGI-3 discussion (https://www.kaggle.com/competitions/arc-prize-2026-arc-agi-3/discussion/743952),
where a commenter attributes LB gains to a correct vLLM install. No Kaggle ARC-AGI-2 thread on SGLang/vLLM accuracy
bugs was found.
