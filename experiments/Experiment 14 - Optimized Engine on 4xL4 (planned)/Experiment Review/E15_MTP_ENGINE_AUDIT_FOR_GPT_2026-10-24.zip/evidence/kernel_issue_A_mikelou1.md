# A. mikelou1 and his "tiny kernel issue" (research notes, 2026-10-24)

Read-only research. Nothing was posted. No project files were changed.

## 0. Sources and how they were read

- Local dumps, read in full: `_scratch/qwen38_search/disc_2026-10-23/topic_748082.md`, `topic_750546.md`, `topic_747515.md`, `topic_745846.md`, `topic_751344.md`, `topic_746149.md`, `topic_745787.md`, `topic_749756.md`, `topic_750575.md`, `topic_746307.md`. Also `_scratch/webresearch/topteam_comments.md`, `d_747515.md`, `d_745846.md`, `hist.json`, `lb.json`, `a3topics*.json`, `kernels.txt`, and the Exp14 Notes `24 Claude - Kaggle discussions re-read ... (2026-10-23).md` and `Kaggle discussions 2026-10-22 summary.md`.
- Fresh pull on 2026-10-24 through the read-only Kaggle API (`kagglesdk` get_topic / list_comments, the same method as `dump_threads3.py`). Output is in `_scratch/kernel_issue/fresh/`:
  - Topics pulled: 748082, 750546, 748193 (ARC-AGI-3), 745692 (ARC-AGI-3), 732854 (ARC-AGI-3), 704408, 751344, 747515, 751598 (ARC-AGI-3), 751631 (ARC-AGI-3), 750173 (ARC-AGI-3), 742796.
  - A site-wide search over 59 queries found 56 ARC Prize 2026 topics. All 46 topics active since 2026-08-01 were scanned comment by comment for the author "mikelou1", for the text "mikelou", and for the text "kernel issue". The result is in `fresh/hits.json` (16 hits) and `fresh/scan2.log`.
  - Topic listing by forum returns 403. Search is the only way to list topics, so a mikelou1 comment in a topic the search never returned could still be missing.
- Public web:
  - WebFetch of `kaggle.com/competitions/arc-prize-2026-arc-agi-2/discussion/748082` returned only the page title, because the page is rendered by JavaScript. **The discussion pages could not be read through WebFetch.**
  - WebSearch for `mikelou1 "kernel issue" ARC Prize 2026 Kaggle` found nothing relevant: only arcprize.org pages.
  - The API pull is the authoritative copy.
- **Thread 748082 had no new replies as of 2026-10-24.** Nobody ever asked mikelou1 what the "kernel issue" was. He never explained it anywhere I could reach.

## 1. Every mikelou1 post, verbatim (ARC-AGI-2 forum, plus the ARC-AGI-3 posts that show his vocabulary)

### Thread 748082 "Qwen3.8-27B / Flash-Next: ARC-AGI-2 results within Kaggle's compute limits?" (Atelier Zoe, 10-10)

All of these sit under his own top-level comment, as one reply chain.

| Date (UTC) | Who | Text (verbatim) |
|---|---|---|
| 2026-10-10 15:30 | **mikelou1** (top level) | "I would test it except the fact that it's a bit hard to submit when submissions get queued for so long they disappear from Active Events tab" |
| 2026-10-11 13:11 | **mikelou1** | "OK It finally graded. Qwen scored ~25%. After some minor optimizations I hope it can get to 40%. I still have a lot of ideas and I believe it has the intelligence to get to 50%, even 85% might be possible." |
| 2026-10-13 00:31 | **mikelou1** | "OK It got 36%. I have a submission with projected ~50% ± 10% running right now." |
| 2026-10-13 02:14 | TheDivine Aurora | "possible to opensource it ? on your terms" |
| 2026-10-13 02:52 | **mikelou1** | "No plans to opensource as I believe I have a good shot at 85%" |
| 2026-10-15 20:08 | Adarsh | Quotes the 10-11 post, then: "I can get qwen 3.8 to 25 too but its crazy u can get it to 40, surely its nvarc ensemble. im milking the life out of the inference speed and there's no way qwen 3.8 itself is enough for 40, has to be a nvarc ensemble or an ensemble with some other solution" |
| **2026-10-16 00:04** | **mikelou1** | "**Not a NVARC ensemble, as my program don't have time to do that. However there is a tiny kernel issue I found that made my program score only 40% (instead of the 60% projected by CV).**" |
| 2026-10-18 07:31 | **mikelou1** | "UPDATE: It scored 66% (~60% on CV)" |

A side branch of the same chain:

| Date (UTC) | Who | Text (verbatim) |
|---|---|---|
| 2026-10-13 09:47 | Akagha Chimgozirim | "Qwne3.8 27B or Qwen3.8 Flash Next?" |
| 2026-10-13 23:54 | TheDivine Aurora | "i also do want to hear if its qwen3.8FN or 27B" |
| 2026-10-14 01:20 | (deleted or empty) | (no text) |

**No reply to the kernel-issue post. Whether he uses 27B or Flash-Next was asked twice and never answered.**

### Thread 750546 "Qwen3.8 or something else?" (Anil Thomas, 10-18)

Branch A, under Kris Dreemurr's top-level comment of 10-18 22:33. Kris: CV 45 %, "~52 out of 120", xhigh, "median 70k tokens for pass@2 (so 35k per slot)", and "Did you have a significant kernel or inference improvement for L4 x 4 setup?"

| Date (UTC) | Who | Text (verbatim) |
|---|---|---|
| 10-19 04:23 | Darren Amadeus Martin | "Honestly getting 52/120 from 70k tokens per task is impressive though, makes me wonder what kind of harness you used." |
| 10-19 04:33 | **mikelou1** | "With some tricks and stuff I currently get around 79% ± 5% in CV runs." |
| 10-19 04:39 | Darren Amadeus Martin | "our cv also got scores easily above 75% but it doesn't translate that well to LB though. Makes me wonder why." |
| 10-19 05:06 | **mikelou1** | "The CV run used LB-ish environment (as my 66% submission got 70% on CV, I expected better on this run but it appears something regressed, likely some technical problems I'll fix later today)" |
| 10-19 05:19 | Darren Amadeus Martin | "you mean like simulating 240 problems in 12 hours ? my team uses the public CV 120 problems and time limit of 6 hours but it seems that the correlation didn't stand up well" |
| 10-19 12:38 | Bushi Liu | "LB seems to be a bit harder than CV, or the harness may be a little bit overfit to eval set. I also cannot translate the local cv score to lb well." |
| 10-19 14:03 | **mikelou1** | "appears to be overfit as lb is slightly easier than cv (despite it scoring a ~10% lower for me too). my cv -> lb is usually within noise and pretty consistant" |

Branch B, under Adarsh's top-level comment of 10-18 20:17. Adarsh: xhigh too slow to reach most tasks, he has heard of "~80% accuracy with no time constraints", and "python repl should do almost all of the thinking".

| Date (UTC) | Who | Text (verbatim) |
|---|---|---|
| 10-20 03:00 | **mikelou1** | "With time constraints at around 4xL4 speed I got Qwen to 87% (and from reasoning traces it got the rule to almost every problem) so Qwen certainly has the intelligence to do so." |
| 10-20 06:17 | TheDivine Aurora | "what is your approaches throughput ? at around 300-500 tps i had ~19-20 % score. only attempted half the dataset. so practically 40 % is possible with 600-800 tps, 1 attempt per task. ..." |
| 10-20 06:26 | **mikelou1** | "The 87% will likely not transfer. I would be surprised if it scores even 80%. I do hope this run gets me to 75%-ish though as I have a few other ideas I am testing." |
| 10-20 06:36 | TheDivine Aurora | "there is other half of private leaderboard that you gotta handle as well" |
| 10-20 08:54 | **mikelou1** | "Not too worried about overfit as I only get a few runs and its pretty hard to overfit" |

**He did not answer the throughput question.**

Branch C, under Anil Thomas's comment of 10-23 03:49. Anil: "I'm almost convinced that the recipe involves distilling ... a student that can fit into a single L4".

| Date (UTC) | Who | Text (verbatim) |
|---|---|---|
| 10-23 04:33 | **mikelou1** | "I'm no where near the top but I don't use distillation." |
| 10-23 04:42 | Anil Thomas | "hm… the plot thickens. thanks for answering. I'm glad I didn't chase after teacher rollouts yet. ..." |
| 10-23 04:59 | TheDivine Aurora | "idk if im gonna reach 60-70 % but how yall lowkey start at 40-45 %" |

### Thread 747515 "Update on 'Kaggle Error' Submissions & Queue Delays" (Dustin, staff)

| Date (UTC) | Who | Text (verbatim) |
|---|---|---|
| **2026-10-09 09:53** | **mikelou1** | "Is it possible to display if its current in queue or running **like when running a kernel**, and what queue position it is on? This might make it easier to make decisions." |
| 2026-10-10 09:43 | **mikelou1** (reply to Kevin E R MILLE's 18-h pending) | "Mine has been stuck for over two days so its unlikely your submission will be graded tomorrow either if this happens.." |

**Key vocabulary point:** one week before the "kernel issue" post, mikelou1 used "kernel" in the Kaggle sense: a notebook run or session ("like when running a kernel"). This is the only other place he uses the word.

### ARC-AGI-3 forum (he competes there too)

- 748193 "Score deviations don't seem that big?" (his own topic, 2026-10-11 03:44): "I've been resubmitting my code a few times and the scores don't change that much (usually ±1 only). This seems very different from what others are seeing. [screenshot] Anyone have any idea how this works? Since I've seen people reporting ±5 or more points." There are 0 replies.
- 745692 (2026-10-04 12:42), replying to a question about NVARC local validation: "I think you have the wrong competition".
- 732854 (2026-08-26 11:03): "Got 2.8 on 25 games and 2.4 on lb".
- 732854 (2026-10-18 03:33), replying to UnSeenGaps: "I'm really sorry to break this to you but you literally used only 5 public games ... The private games are not varients of this ..."

### Background facts about mikelou1 (not quotes from him)

- He is the author of the public notebook `mikelou1/arc-agi2-lb33-89-minimal-perfpatch` ("ARC AGI2 LB33.89 Minimal Perfpatch", 2026-07-14, 167 votes). It is the NVARC fork many teams copied: adam99 in 745846 says "i forked mikelou1's notebook without changing anything ... 28.06".
- The credits in mayankraaz's notebook say: "Mike Lou (`mikelou1`): For isolating the CPU-GPU PCIe bandwidth bottleneck in Turbo DFS, demonstrating that keeping normalized 12-token logits resident on GPU yields a massive speedup without token degradation."
  - **He is a GPU and performance engineer. Profiling and patching inference code is his known strength.**
- Leaderboard:
  - huikang monitor (hist.json): rank 13, 18 entries, 66.39, last submission 2026-10-17 19:36 UTC.
  - LB_top40 (10-21): rank 13, 19 entries, 66.39.
  - Exp14 Notes 24 (screenshot of 10-23): 69.72, around rank 12.
  - He is a solo team ("EXPERT" tier).

### Score timeline reconstructed from his posts

| When | LB | CV / projection | Note |
|---|---|---|---|
| graded 10-11 | ~25 % | — | first Qwen run |
| graded ~10-12/13 | 36 % | — | "minor optimizations" |
| running 10-13, graded by 10-16 | **40 %** | "projected ~50 % ± 10 %"; later "60 % projected by CV" | **"tiny kernel issue"** |
| submitted ~10-17 19:36, graded 10-18 | **66 %** | "~60 % on CV". On 10-19 he says this 66 % submission "got 70 % on CV" | issue fixed: **+26 pts** |
| CV around 10-19 | — | "79 % ± 5 %"; a run that "regressed ... technical problems" | |
| 10-20 | — | "87 %" under 4×L4-speed time limits (he expects it not to transfer; hopes for ~75) | |
| ~10-21/23 | 69.72 | — | |

## 2. Hints about his method (everything he disclosed)

- **Model:** "Qwen". The thread is about 27B, but **27B vs Flash-Next was asked twice and never answered.**
- **No NVARC ensemble:** "my program don't have time to do that". The pipeline uses the whole 12 h, so it is coverage-bound.
- **No distillation** (10-23).
- **Closed source:** "No plans to opensource as I believe I have a good shot at 85%".
- **CV method:**
  - "The CV run used LB-ish environment".
  - "With time constraints at around 4xL4 speed". This implies he simulates the 4×L4 time budget, possibly on other or faster hardware, throttled to L4 speed.
  - He quotes ± ranges ("50 % ± 10 %", "79 % ± 5 %"), so he runs several CV runs or estimates variance.
  - He says CV→LB is "usually within noise and pretty consistant". His 40 % LB against 60 % CV was the outlier he blamed on the kernel issue.
- **Reasoning traces exist:** "from reasoning traces it got the rule to almost every problem". So it is a thinking-mode Qwen, and the traces are inspected. The gap between "gets the rule" and solving is the execution or coverage part.
- **"With some tricks and stuff"** took CV from 60-70 to 79 ± 5.
- **Resubmit noise:** ±1 in ARC-AGI-3 (748193), "pretty consistant" in ARC-AGI-2.
- **Not disclosed:** engine (SGLang or vLLM), quantization, speculative decoding, harness (REPL or not), attempt count, token budget, throughput.

## 3. What was the "kernel issue"? Ranked interpretations

Constraints any answer must satisfy:

- (a) The issue was **"tiny"**.
- (b) It cost about **⅓ of the score**: 40 against 60 projected. It did not cause a 0.00 or a "Kaggle Error".
- (c) His **CV ("LB-ish environment", "around 4xL4 speed") did not show it**. It appeared only in the scored rerun.
- (d) Once fixed, the next submission scored **66 (CV ~60)**. The fix was quick: graded 10-16, fixed submission in by 10-17 19:36.
- (e) It happened **10-13 to 10-15**. That is **before** the GCSFUSE storage incident (10-19 to 10-23), but around an "ARC-AGI-3 site update around Oct 14-15" that Ishan Karnick reported in 750173. The Kaggle docker image change of 10-01/02 (CPMP in 751344; Vitalii in ARC3 745654) is also before it.

### Rank 1 (about 45 %): a Kaggle "kernel" (notebook / scored-run environment) issue

**For:**
- His only other use of the word is the Kaggle sense, a week earlier: "like when running a kernel".
- Kaggle's own API calls notebooks "kernels".
- (c) fits naturally: the scored rerun differs from the Save/CV run in ways a CV cannot show:
  - 240 hidden tasks instead of 120;
  - a different machine pool: Dustin said submissions run on a separate, much larger pool from save runs;
  - a different wall-clock start (queue time);
  - whether the hidden test file holds 240 tasks;
  - CPU count and throttling;
  - env vars such as `KAGGLE_IS_COMPETITION_RERUN`.
- A "tiny" bug there loses part of the run, not all of it. A ⅓ loss fits a time-budget mistake, for example:
  - a deadline computed from the wrong start, or one that ignores load time;
  - a per-task budget sized for 120 tasks but applied to 240;
  - a schedule that leaves the tail of the queue unattempted;
  - a wrong process or GPU count on the scored machine.
- "Tiny" also suggests one constant or one line.

**Against:** he says CV used an "LB-ish environment". If that meant a real Kaggle commit, rerun-only branches would be the only gap left. That is still consistent with this rank.

### Rank 2 (about 40 %): a GPU / inference kernel issue that showed up only on real L4s (or only on the scored machines)

**For:**
- His background is GPU performance patching (the PCIe-logits work in Turbo DFS).
- "With time constraints **at around 4xL4 speed**" suggests his CV ran on non-L4 hardware, throttled or time-scaled. In that case an L4- or sm_89-specific kernel problem stays invisible in CV. It costs throughput or correctness only on Kaggle.
- On a coverage-bound pipeline, a ~33 % throughput loss gives about 33 % fewer solves: 60 → 40. That matches (b) closely.
- Typical "tiny" causes:
  - an attention or linear-attention backend falling back to a slow path on sm_89;
  - CUDA graphs not captured or disabled;
  - the speculative / MTP draft path silently off or rejecting;
  - custom all-reduce disabled on PCIe L4 without P2P, falling back to NCCL. That is a large tax at TP4 on decode.
  - a Triton kernel autotuned or JIT-compiled at run time (compile time eats the budget);
  - an FP8 or INT4 GEMM kernel choice that is slow or wrong on Ada;
  - a numerics issue (for example the SSM-state dtype) that lowers answer quality without crashing.

**Against:**
- He wrote "my program", not "the engine".
- In this community "kernel" is ambiguous. Kris asked in 750546 about "kernel or inference improvement for L4 x 4", in the GPU sense, and mikelou1 did not take up the word there.

### Rank 3 (about 15 %): an OS / container kernel issue (Linux kernel features or limits)

**For:**
- A harness that runs model-written Python (a REPL or code-verify harness) needs a sandbox: seccomp, namespaces / unshare, rlimits, setuid, /dev/shm, pid or fd limits.
- Our own memory notes say the Kaggle container blocks unshare/mount.
- If his sandbox degraded on the scored machine (for example, code execution failing for part of the tasks, or timeouts from blocked syscalls), the score drops partly, not to zero. That fits (b).

**Against:**
- He never mentions a REPL or code execution.
- The Python 3.13 image change (10-01/02) and the "Thread._stop crash" class we hit ourselves are Python-level, not kernel-level.

**Not supported:** the storage slowdown (GCSFUSE). It began around 10-19 to 10-21, after his 40 % run and after his fix. However, his 10-19 "something regressed, likely some technical problems" CV run, and any later sub-par runs, could fall in that window.

## 4. Other teams' reports in the same class of problem

The common class: **"the save/CV run is fine, the scored rerun loses a fraction of the score or all of it, with no error"**.

- **NguyenThanhNhan** (751344)
  - 10-21: 57475856 scored **0.00**, finishing in under 2 h, against 57422625 = 65.97 using about 17.5 h.
  - 10-22 07:26, cause found: "My notebook has a 45-minute timeout for the inference server startup ... I need to read ~180 GB from /kaggle/input ... FUSE.GCSFUSE is much slower than NFS ... the server startup never finished in time, so no inference ran and placeholder submission jsons were returned."
  - 10-23: he re-uploaded the weights as Kaggle Models, which mount over NFS.
  - He also cites 704408: Darragh's "0.00 in ~15 minutes, then normal on resubmit", 2026-06. In that thread Giba blamed a dataset version that "changed a bit the path".
  - Class: environment I/O → engine never up → **total loss**. Not mikelou1's case, which was a partial loss.
- **shiiin9** (751344, 10-23 08:10)
  - 57448046 = **65.56**; then identical-output notebooks 57496708 = **59.31** and 57533377 = **58.61**.
  - "Resubmitting an identical notebook earlier moved our score by only ±0.4."
  - Workaround: "reading the inputs with more parallelism ... can only help when each read stream is slow, not when the storage itself is slow."
  - Class: **partial loss from lost run time.** This is the closest analogue in magnitude (−6 to −7 pts) to a "tiny" environment issue.
- **amn** (751344)
  - Pipeline 72.50; three 0.00s (57443192, 57507547, 57541539) plus one far-below run (57468531).
  - NFS throughput probes fell from ~0.95 GiB/s (10-20) to ~0.026 GiB/s (10-21 05:37).
  - "In my intentionally limited 3 hours, the inference engine has never managed to get started ... reading of ~110 GiB."
  - "My notebooks' design is to let it silently write placeholders instead of make it explode as an error."
- **Jeroen Cottaar** (751344; ARC-AGI-3 notebook, but the same storage)
  - "Filesystem type for checkpoints: FUSE.GCSFUSE" compared with NFS on 10-17: 88 s against 1.8-2.8 h per shard.
  - "Reads through the mount don't fill the page cache."
  - The same notebook as weeks earlier now "usually scoring 0.00, and when it doesn't it scores 5-10% lower".
- **mp** (751344): "~10 points lower than the highest". Plan: detect a FUSE mount and copy the files to local disk once. "My submissions lately have been focusing solely on inference performance ... a faster run with more tokens generated should not lead to a ~10-point regression."
- **Trian** (751344)
  - 57453862: "10-15 points less than expected".
  - 57495522: Kaggle Error after ~13 h. 57535054: Kaggle Error after ~4 h.
  - "Each submission was tested multiple times on a 4xL4 machine and showed no problems."
- **Kha Vo** (751344): two subs "worse than expected by 10 points", then a Kaggle Error.
- **xz** (751344, 10-22): "5-10% lower score could be a **CPU throttling** issue. I found the throughput to be affected significantly by CPU despite my efforts to overlap CPU work with GPU." This is the scored-machine-differs class, and it would also produce mikelou1-type partial losses.
- **CPMP** (751344)
  - "We updated our code to work with the new image. But we lost a sub because of that ... Image changes should be announced."
  - Also a "Kaggle error after 12 hours. Same code that ran fine the day before."
- **cm391** (751344): the 02/10 image update. With the old image "it would take ages for anything to work".
- **Dustin** (staff)
  - 747515:
    - queue waits over 15 h were marked "Kaggle Error";
    - submissions now run on "their own, much larger pool" separate from interactive / save versions. **So the scored machine is not the save-run machine.**
    - a 4×L4 quota accounting fix.
  - 751344:
    - 10-23 01:35: "instability with the dataset cache the past few days in some regions ... finally in a stable state now", with possible reruns;
    - 10-23 02:11: "putting Models in Kaggle Models instead of datasets ... Fuse isn't necessarily a ton slower than NFS, there's a ton of variables (ex. regionality, read patterns, contention)".
- **"Kaggle Error"** (747515 10-22/23: Yuhua Ke twice, Muhammad daily; 751344): platform-side failures that waste the daily slot.
- **ARC-AGI-3 side, the same period**
  - 750173, Ishan Karnick, 10-17: two 0.00s "since the site update around Oct 14–15". Runs ended in about 4.5 h, and Save & Run still finished normally.
    - Jeroen: no move for 15 min ends the run.
    - CPMP: slow dataset loading causes it.
  - 751598 / 751631: 0.00 in 27-60 min; model loads of 35-63 min; "connection refused :8001".
    - Shehab Anwer: "the scored rerun happens on a different machine, so an OK result makes a 0.00 less likely but doesn't rule it out".
    - AquaUrsa: per-worker NFS speed varies (119 against 291 MiB/s).
    - María Cruz, 10-23 23:51: engineering is looking into runs that "completed early with a 0.00".
    - 暗黑AGI, 10-24 01:38: slow again (~40 min) even from a Kaggle Model.
- **Our own instances of the class** (memory notes):
  - SGLang ready at 1,197 s against a 30-min launch timeout (timeout = 0 LB);
  - the COMMIT notebook size limit of 407-444 kB, which explains the 10-22 G4B loss;
  - the container blocks unshare/mount (sandbox design);
  - the Py3.12 / Py3.14 Thread._stop crash found only on the Kaggle image.

**Takeaway for us:** whichever meaning of "kernel" he intended, mikelou1's 40 → 66 jump shows that a small defect present only in the scored run can cost about 20-26 points with no error shown. Reports from the other top teams in 10-19 to 10-23 add the same pattern: 6-15 point partial losses and 0.00s from load-time and environment drift.

Concrete guards follow from this:
- log and assert, inside the scored run, the filesystem type, read MB/s, engine-ready time, CUDA graph capture, spec-decode accept rate, the custom all-reduce path, decode tok/s, CPU count, and the number of hidden tasks;
- adapt the deadline to the actual start and ready times;
- never let a slow path pass silently;
- validate on real 4×L4 Kaggle hardware, not throttled other hardware.
