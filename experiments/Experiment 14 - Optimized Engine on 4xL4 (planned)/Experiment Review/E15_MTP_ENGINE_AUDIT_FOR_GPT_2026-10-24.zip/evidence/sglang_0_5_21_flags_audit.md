# A — SGLang 0.5.21 flags and env vars not set or tested by E15 (source audit, 2026-10-24)

Scope: read-only audit of `D:/ARC AGI 2/_scratch/session_1c6db7aa/sgl_src/src/sglang` (0.5.21; its wheel METADATA pins `flashinfer_python[cu13]==0.6.18`, `sglang-kernel==0.4.7`). I compared it with the E15 launch: `e11_flags` + the E14S wrapper + CELL 5c of `Q27-XHIGH-E15_MTP_ENGINE_DUCK_SGLANG.ipynb`. I did not change any project file and did not touch Kaggle.

Tags: **[S]** = verified in the source (file:line). **[I]** = inferred, not proven. **[M]** = measured in our runs (Notes/30 R2 profile).
Paths are relative to `srt/` unless noted.

## 0. What E15 already sets or tests (excluded below)

- **Base flags (`e11_flags` + the E14S wrapper):**
  - Model and parallelism: `--tp-size 4`, `--context-length 155648`.
  - Memory and cache: `--kv-cache-dtype fp8_e4m3`, `--mamba-ssm-dtype float16`, `--mamba-radix-cache-strategy extra_buffer_lazy`, `--max-mamba-cache-size 56`, `--mem-fraction-static 0.83`.
  - Scheduling: `--max-running-requests 13`, `--chunked-prefill-size 4096`, `--schedule-policy lpm`.
  - Graphs and kernels: `--disable-prefill-cuda-graph`, `--cuda-graph-bs-decode 1..13`, `--disable-flashinfer-autotune`.
  - Speculative decoding: DFLASH, drafter `unquant`, width 6.
  - Serving and logging: `--incremental-streaming-output --stream-interval 1`, `--reasoning-parser qwen3`, `--tool-call-parser qwen3_coder`, `preserve_thinking`, `--enable-cache-report`, `--enable-metrics`, `--decode-log-interval 40`, `--watchdog-timeout 1800`, `--random-seed`.
  - Optional: `--mamba-track-interval 64 --page-size 64`, behind the env var `E12_MAMBA_TRACK_64` (off by default; not an E15 arm).
- **E15 arms:**
  - DFLASH width: W8.
  - Admission: mrr 14 + graphs 1..14; `--min-free-slots-delay 1` with mrr 12.
  - Concurrency: W6 at 14 / 16 / 20 streams (mrr 17 / 20 / 24, mamba 4×mrr, graphs 1..mrr).
  - MTP: EAGLE 3/1/4; 3/1/4 + mem 0.86; 2/1/3.
  - MTP + `--enable-linear-replayssm-spec`, with fp32 and with fp16 SSM.
  - The best MTP arm at 14 / 16 streams.
  - A target-only probe.
- **Measured in E14 (not E15):**
  - Not adopted: the #44401 patch, nodelay (crashed at 13), and int8 Mamba checkpoints (OOM).
  - Adopted: graphs13 (neutral) and width 4 / 6.
  - NCCL env bench (`NCCL_P2P_LEVEL=SYS`, `NCCL_SHM_USE_CUDA_MEMCPY=1`): no arm reached the 20 % bar; the baseline repeated at 343.9 µs/call [M].

## 1. Framing from the R2 profile [M] that bounds every flag below

Decode step at 12 running: 116.1 ms of kernels, with the GPU busy 113.0 of 116.7 ms of wall time.
- **CPU-side levers can win at most about 3 %.** These are the scheduler polling, stream interval, tokenizer workers, plan stream, delay-sample and metadata-glue knobs.
- **Real gains must cut GPU kernel time.** The per-step budget is:
  - all-reduce 50.9 ms;
  - all-gather 8.1 ms, almost certainly the full-vocabulary target-verify logits gather: 72 rows × 248,320 / 4 per rank in BF16. The DFlash draft already uses a local top-k gather (`models/dflash.py:107-150`) [S/I];
  - Marlin 25.3 ms;
  - other GEMM 14.5 ms (BF16 drafter + lm_head);
  - GDN 8.0 ms;
  - attention 2.7 ms at about 6k context. Attention grows linearly with context: the step is 133–140 ms at 50–80k in E11 / E12 [M].

**Prefill is all-reduce-bound.**
- Per token, a prefill does 128 all-reduces × 10 KB = 1.31 MB per rank. At the measured 2.86 GB/s algbw (983 KB in 344 µs), that is about 0.46 ms/token.
- The measured cost is 0.67 ms/token (1,500 tok/s). So about 70 % of prefill time is NCCL [I, arithmetic].
- No flag in 0.5.21 changes prefill all-reduce volume on this box (see C7–C9).

## 2. Findings that change existing plans

1. **`SGLANG_ENABLE_PCIE_IPC_ALLREDUCE` is dead code in our install.** This was already known in Notes/29–34; I re-verified it.
   - `distributed/device_communicators/pcie_ipc_ar.py:223-231` imports `flashinfer.comm.PcieIpcAllReduceWorkspace`.
   - The local FlashInfer 0.6.18 wheel (`_scratch/e13_validate/flashinfer_src/fi.whl`) has no pcie module under `flashinfer/comm/` [S].
   - Setting the env only logs "falling back to NCCL". It needs FlashInfer ≥ 0.7 (SGLang 0.5.22).
   - It is still the largest decode lever (it attacks the 50.9 ms), but it is not an arm on 0.5.21.
2. **DFLASH + `--enable-linear-replayssm-spec` is not wired for GDN.** Do not add a "DFLASH + ReplaySSM" arm.
   - `speculative/dflash_worker_v2.py:2030-2069` commits Mamba state by calling `attn_backend.update_mamba_state_after_mtp_verify` directly. It never goes through `speculative/spec_utils.py:921 commit_mamba_states_after_verify`, which holds the GDN ReplaySSM fold and commit (L943-1030).
   - The direct-caller branch in `layers/attention/hybrid_linear_attn_backend.py:1452-1460` handles only **KDA** ReplaySSM ("dspark/dflash call this method directly … this branch is only hit by the direct callers").
   - For GDN it falls through to `scatter_mamba_states_after_mtp_verify`, which reads `intermediate_ssm` buffers that ReplaySSM does not allocate [S].
   - Expected outcome: a crash or a stale state [I]. E15 correctly uses ReplaySSM only with MTP (EAGLE → `eagle_worker_common.py:617`).
3. **`--num-continuous-decode-steps` and `--triton-attention-reduce-in-fp32` are no-ops.** Both are declared but have 0 uses outside `fields/` and `field_order.py` [S, grep over the whole package].
4. **`--sampling-backend` cannot be set from the CLI.** It is declared `Arg(no_cli=True)` (`arg_groups/fields/exec_.py:169-176`) [S].
5. **The INT4 checkpoint carries calibrated FP8 KV scales.**
   - `config.json → quantization_config.kv_cache_scheme` is `{type: float, num_bits: 8, strategy: tensor, symmetric, dynamic: false}`. I read it from `_scratch/g4b_bundle_verify/tests/fixtures/tok_int4/config.json` [S].
   - SGLang loads such scales through `CompressedTensorsKVCacheMethod` (`layers/quantization/compressed_tensors/compressed_tensors.py:207-221, 1179-1197`), with name remaps `.self_attn.k_scale → .attn.k_scale` (`models/qwen3_5.py:1577-1580`) [S].
   - So `--quantization-param-path` is not needed. Whether the tensors really load is [I]: check that the server log has no "kv_cache_scheme ignored" or scale-1.0 warning (the E11-04 table already has a "FP8 scale warning" column).
6. **The model's native SSM dtype is float32.** `text_config.mamba_ssm_dtype = "float32"` in the same config [S].
   - We override it to float16.
   - The LB-65.97 Qwen3.8-27B notebook (NguyenThanhNhan, Notes table) used `--mamba-ssm-dtype float32`, `--mamba-full-memory-ratio 0.5`, chunk 2048, `--max-prefill-tokens 4096`, `extra_buffer`, and MTP 3/1/4.
   - E15 tests fp32 SSM only together with ReplaySSM on MTP. There is no "plain fp32 SSM" arm on DFLASH or MTP.
7. **`--mamba-full-memory-ratio` is ignored in our launch,** because `--max-mamba-cache-size` is set explicitly (`mem_cache/kv_cache_configurator.py:2462-2468`) [S].

## 3. Full flag / env inventory (not set or tested by E15)

Columns: exists / default / ours · mechanism · expected effect for us · risk · cheap E15 arm?
Each item is one launch + gate + 8k/40k windows unless noted.

### A. Scheduling and prefill/decode interference

**A1. `--prefill-decode-interval N`** (`fields/schedule.py:56`): default None, resolved to 0; ours 0.
- Mechanism [S]:
  - `managers/scheduler.py:1352-1371`: after any extend batch, `_should_defer_prefill()` makes the next N scheduler rounds skip `get_new_batch_prefill`.
  - L3724-3725, L3770: this also defers the next chunk of a chunked request.
  - Without it, a pending prefill always runs first ("Run prefill first if possible", L3746-3748). A multi-chunk re-prefill therefore runs all its chunks back to back while 11 streams stall.
- Effect [I]:
  - Aggregate throughput is about neutral. The total prefill work is unchanged, and a stream waiting for its prefill decodes nothing, so a slight loss is possible.
  - It caps the decode stall per chunk: one 4096 chunk is about 2.7 s, after which N decode steps of about 100 ms run.
  - It helps tail latency and fairness, not tokens/s.
- Risk: low. Arm: cheap, but steady windows cannot show it; it needs the latch / agent replay. Pair it with chunk 2048 (A2).

**A2. `--chunked-prefill-size 2048` and `--max-prefill-tokens 4096`** (`schedule.py:51, 67`): default None / 16384; ours 4096 / default.
- Mechanism [S]: the chunk is the per-batch prefill token budget (PrefillAdder, `scheduler.py:~3905-3925`). The help text says the real `max_prefill_tokens` bound is max(value, context length).
- Effect [I]:
  - Alone, a smaller chunk does not reduce the total stall, because chunks run back to back (A1).
  - Prefill tok/s is about flat, because prefill is all-reduce bandwidth-bound at 4096 already.
  - It matters only with A1 (shorter, more frequent stalls). It matches the 65.97 config.
  - `mamba_hook.py:128-140` warns if the chunk is smaller than `mamba_cache_chunk_size`, because unfinished chunk handoffs then skip Mamba checkpoints. Check the log.
- Risk: low. Arm: cheap, together with A1.

**A3. `--enable-mixed-chunk`** (`schedule.py:202`): default False.
- Mechanism [S]:
  - DFLASH, DSPARK, EAGLE and EAGLE3 are allowed (`speculative/spec_info.py:146-157`).
  - "Mixed steps degrade running requests to a plain 1-token decode" (`arg_groups/speculative_hook.py:992-1006`).
  - The scheduler merges the running batch into the prefill batch (`scheduler.py:4128-4160`), and the chunk budget shrinks by running_bs.
- Effect [I]: during a 4096 chunk (about 2.7 s), each stream gets 1 token instead of 0, against roughly 3-4 tokens per 100 ms normally. That is about +12 tokens per chunk, which is negligible. It also loses spec acceptance on those steps.
- Notes already list "do not use" (#43514).
- Risk: medium. Arm: cheap but low EV.

**A4. `--schedule-policy`** (fcfs / dfs-weight / lof / hrrn / shortest-prefill-first / routing-key / priority) (`schedule.py:84-99`): ours lpm.
- Effect: none while queue ≤ 1 (client 12 vs server 13). It only matters in the E15 at-N arms with churn. Low.

**A5. `--schedule-conservativeness`, `SGLANG_INIT_NEW_TOKEN_RATIO`, `SGLANG_MIN_NEW_TOKEN_RATIO_FACTOR`, `SGLANG_NEW_TOKEN_RATIO_DECAY_STEPS`, `SGLANG_CLIP_MAX_NEW_TOKENS_ESTIMATION`, `--retraction-policy`** (`schedule.py:122-135`; `environ.py:595-599`).
- Mechanism [S]: KV-reservation admission and retraction (`managers/scheduler_components/new_token_ratio_tracker.py`).
- Effect: none while KV usage is 0.18-0.41. It becomes relevant only for the 16-20-stream arms at 80-100k contexts. Low.

**A6. `--enable-prefill-delayer` (+ `--prefill-delayer-*`), `SGLANG_SCHEDULER_DECREASE_PREFILL_IDLE`** (`schedule.py:226-260`; `arg_groups/serving_hook.py:676-687`).
- Works without DP attention (`managers/prefill_delayer.py:240`) [S].
- Effect [I]: it delays prefills to batch them. That is the same family as the DFlash min-free-slots delayer that causes the 11-of-12 latch, so it is likely negative. Low.

**A7. `--scheduler-recv-interval`, `SGLANG_SCHEDULER_MAX_RECV_PER_POLL`, `SGLANG_SCHEDULER_RECV_SKIPPER_WEIGHT_*`.** CPU polling only, capped by the 3 % CPU bound. Low.

**A8. `--max-queued-requests`, `--prefill-max-requests`, `--enable-priority-scheduling` (+ preemption).**
- Priority needs a priority field from the client, and preemption retracts work. No queue exists at 12/13. Low.

**A9. `--disable-overlap-schedule`.** Must stay off.
- `extra_buffer_lazy` asserts overlap (`mem_cache/kv_cache_configurator.py:2253-2255`) [S].
- Our slot count of 4 assumes overlap (2239-2251).

### B. Memory: KV, Mamba state, cache retention

**B1. `--mamba-ssm-dtype float32`, without ReplaySSM, on the DFLASH W6 arm** (`fields/exec_.py:363`): ours float16; the model config says float32 (finding 6).
- Mechanism [S]: persistent slots plus the spec-verify intermediate states `(min(mrr, K//4)+1) × D × ssm`, from `kv_cache_configurator.py:2462-2482` and the Notes formula.
- Memory per rank at mrr 13, K 56, D 6 [I, arithmetic]:
  - ssm/slot is 36 MiB in fp32 against 18 MiB in fp16;
  - persistent 57 × 36.7 MiB = 2.09 GiB (fp16: 1.04 GiB);
  - intermediate 14 × 6 × 36 MiB = 2.95 GiB (fp16: 1.48 GiB);
  - total about +2.5 GiB/rank, so KV falls from about 866k to about 615k tokens (10,752 B/token target + draft at fp8). That is still about 3× the observed peak use.
- Effect:
  - Speed [I]: GDN state traffic doubles, from 8 ms to roughly 12-14 ms (-4 to -5 %).
  - Accuracy: unknown sign. fp32 is the native dtype, and the 65.97 reference used it. fp16 state rounding compounds over 30-100k recurrent steps.
- Risk: this changes the user's 2026-10-15 "fp16 SSM" choice and needs approval. The greedy gate will show small-margin flips, but large-margin flips should stay at A/A level.
- Arm: cheap (a set-only arm, maybe + `--mem-fraction-static 0.86` or B6). The accuracy can be judged only by an eval run, not by windows.

**B2. `SGLANG_OPT_MAMBA_SKIP_DECODE_LOCK=1`** (env, `environ.py:1448`): default 0.
- Mechanism [S]:
  - `mem_cache/unified_radix_cache.py:1270-1285` skips the Mamba lock on the matched prefix during decode. That node was already copied-on-write into the request's own slot.
  - `kv_cache_configurator.py:175-187, 2235-2256`: the base ratio drops by 1, so lazy goes from 4 to 3 slots per request.
  - Applies to us: the hybrid SSM cache is `UnifiedRadixCache` (`mem_cache/registry.py:79-148`) [S].
- Effect [I]:
  - Mamba 56 then supports 18 running, against 14 now.
  - Or, at 12 running, 12 more evictable slots hold agent tail states.
  - A slot costs only about 19 MiB/rank, so the memory value is small (<0.4 GiB). The value is mostly fewer forced evictions under churn at 14-20 streams.
- Risk: medium. It is an opt-in lock-skip path, and its "safe only because…" comment assumes match-then-lock ordering.
- Notebook change needed: `e11_slots` and the capacity gate assume 4 slots for lazy, and must use 3.
- Arm: cheap env arm (`env=` in `e14_launch`). Measure it with the agent replay (A2-1) and the latch, not with steady windows.

**B3. `--mamba-max-states-per-path N`** (`fields/exec_.py:370`): default -1 (unlimited).
- Mechanism [S]: `mem_cache/unified_cache/components/mamba.py:251-300` evicts shallow interior Mamba checkpoints beyond N per root-to-tail path. Forks, tails and locked nodes are kept.
- Effect [I]:
  - Each agent turn leaves a checkpoint along its path. LRU can then evict another agent's tail while it keeps shallow, useless states.
  - N = 2 keeps retention for all 12 agents and their branches.
  - But the R2 agent replay showed `deeper_miss 0` of 120 follow-ups [M]. So eviction was not the loss there; the losses were granularity: `lost_at_prefill_end 26`, `partial_reply 27`.
- Expected value: low-medium, mainly for the 14-20-stream arms. Risk: low. Arm: cheap, measure with the agent replay.

**B4. `--radix-eviction-policy` lru / lfu / slru / priority / tlru (+ `--radix-eviction-policy-config`)** (`fields/memory.py:25-58`).
- Used by the unified tree (`mem_cache/unified_cache/unified_tree_core.py:438-442`) [S].
- Effect: the same caveat as B3; it matters only when Mamba slots or KV are evicted. Low.

**B5. `--mamba-track-interval 64` alone (page_size stays 1)** (`exec_.py:403`): default 256.
- Constraints [S]:
  - interval ≥ draft tokens (`arg_groups/mamba_hook.py:123`);
  - interval ≥ `mamba_chunk_size` 64 (`layers/attention/hybrid_linear_attn_backend.py:1052`);
  - interval % page == 0;
  - track grid = lcm(checkpoint grid, interval) (`runtime_context.py:1919-1924`).
- Effect [I]:
  - The reused part of a reply ends at the last 64-token checkpoint instead of the last 256-token one. That saves about 96 re-prefill tokens per partial reply (27 of 120 follow-ups), so it is small.
  - The extra state copies are about 19 MiB per crossing, which is negligible.
- `E12_MAMBA_TRACK_64` also sets `--page-size 64`. That makes radix matching page-granular (up to 63 tokens lost per reuse) and changes the attention paging, so test the interval alone first.
- Risk: low. Arm: cheap, measure with the agent replay.

**B6. `--max-total-tokens N`** (`schedule.py:39`).
- Mechanism [S]: `token_capacity = min(profiled, N)` (`kv_cache_configurator.py:2268-2285`).
- Effect: it caps KV so that GPU memory is left free for fp32 SSM (B1) or extra Mamba slots without raising `--mem-fraction-static`. KV is 0.18-0.41 used now.
- Risk: retraction if many agents reach 80-100k at once. Use it as a funding knob inside B1 / B2 / B7, not as an arm of its own.

**B7. `--max-mamba-cache-size > 4 × mrr` at 12 streams (e.g. 96).**
- Mechanism [S]: persistent slots grow, while the intermediate states stay at (min(mrr, K//4)+1) × D. Extra slots cost about 19 MiB/rank each (fp16).
- Effect [I]: about +40 cached tail states for +0.75 GiB/rank. E15 raises the Mamba cache only together with mrr. Same caveat as B3 (R2 showed no deep misses).
- Risk: low. Arm: cheap.

**B8. `--kv-cache-dtype bf16`.** An accuracy check only.
- Calibrated FP8 scales already exist (finding 5).
- It halves KV (about 866k to 430k tokens) and doubles attention bytes. That is slower at 40-100k context (attention is about 20 ms there).
- Run it only if the log shows that the scales were not loaded. Risk: capacity.

**B9. `--speculative-draft-kv-cache-dtype bf16|fp8_e4m3`** (`fields/spec.py:145`).
- The draft KV already inherits fp8_e4m3 (`mem_cache/kv_cache_dtype.py:31-37`) [S].
- The draft pool has one slot per target token (about 2,560 B/token/rank in fp8, about 2.2 GiB at 866k), even though the draft attends only its native 2048 window (B10).
- BF16 draft KV might help acceptance slightly but costs +2.2 GiB/rank. Low.

**B10. `--speculative-draft-window-size W`** (`spec.py:158`).
- Honoured by DFLASH (`speculative/dflash_worker_v2.py:391-392, 602-619`) [S].
- It only builds a compact req→token view over the same global KV index space, so it saves no memory.
- The DFlash2 draft already applies its native `sliding_window: 2048` in attention (`models/dflash.py:167-184, 311-317`; `dflash2_config.json`) [S].
- Effect: about none. Not an arm.

**B11. `--enable-hierarchical-cache` (+ `--hicache-ratio`/`--hicache-size`/`--hicache-io-backend`/`--hicache-mem-layout`/`--hicache-write-policy`).**
- A host-RAM tier for KV and Mamba (`mem_cache/unified_cache/components/mamba.py:80-81` host Mamba pool; draft sidecars in `mem_cache/kv_cache_builder.py:110-135`) [S].
- DFLASH plus hybrid GDN is not explicitly blocked, but it is not validated [I]. It is incompatible with int8 Mamba checkpoints (`arg_groups/mamba_hook.py:72-80`) [S].
- Effect: it only helps when evicted prefixes come back. R2 showed `deeper_miss 0`. Risk: high. Not cheap.

**B12. `--enable-unified-memory` / `--enable-page-major-kv-layout`.**
- Both require Triton attention, linear-attention and Mamba backends (`fields/memory.py:71-85`). Unified memory blocks TBO and some spec combinations (`arg_groups/kv_cache_hook.py:560-575`).
- Effect: dynamic KV / Mamba split, which would let Mamba slots grow into the idle KV.
- Risk: high (a new path plus the Triton backend). Not cheap.

**B13. `--enable-session-radix-cache`.**
- Needs session ids on the requests (client change) and UnifiedRadixCache (`mem_cache/registry.py:250-270`). Not flag-only. Low.

**B14. Never use these:**
- `--disable-radix-cache` (82 % cached prompt share [M]);
- `--strip-thinking-cache` (drops the thinking from the cache, which breaks `preserve_thinking` reuse; `mem_cache/common.py`, `managers/schedule_batch.py`) [S];
- `--enable-mamba-cache-stochastic-rounding` (Triton needs SM100: `arg_groups/mamba_hook.py:43-50`) [S];
- `--enable-int8-mamba-checkpoint` (OOM in E14 [M]).

### C. Kernels, graphs, communication

**C1. `--attention-backend triton` (or `--decode-attention-backend triton`), with Lean attention.**
- Default on sm_89 is flashinfer (`arg_groups/model_override_base.py:299-303`) [S]. fa3 needs SM90 and fa4 needs SM100, so triton is the only alternative.
- `--enable-lean-attention` (None = auto-gate for long contexts) is used only in `layers/attention/triton_backend.py` [S]. `--triton-attention-num-kv-splits` (default 8; "larger is better in longer context").
- Effect [I]:
  - At 6k context attention is 2.7 ms, which is nothing.
  - At 50-80k the step grows by about 20-25 ms [M, E11/E12], mostly from 16 full-attention layers reading about 512 B/token/layer of fp8 KV.
  - If triton + Lean is 20-30 % faster at long context, that is -4 to -6 ms (3-5 %) at 60k.
- Risk: medium (fp8 KV + DFLASH verify on triton; the draft backend is re-resolved in `arg_groups/speculative_hook.py:788+`).
- Arm: cheap. Judge it on the 40k window only.
- `--speculative-attention-mode decode` matters only with mixed prefill / decode backends. It is consumed only by `layers/attention/hybrid_attn_backend.py:40-75`, built when prefill ≠ decode (`model_executor/model_runner_components/attention_backend_setup.py:213`) [S].

**C2. Linear-attention (GDN) backends: `--linear-attn-backend`, `--linear-attn-decode-backend`, `--linear-attn-prefill-backend`, `--linear-attn-verify-backend`.**
- Only triton works on sm_89 [S]:
  - FlashInfer GDN needs SM90+ (`layers/attention/linear/kernels/gdn_flashinfer.py:136, 185-197`);
  - CuTe DSL decode needs SM90+, prefill SM100 (`gdn_cutedsl.py:26-64`);
  - the FlashInfer auto-default applies only to SM 9/10 (`linear/gdn_backend.py:188-234`).
- `--mamba-backend flashinfer` concerns the Mamba2 SSU, not GDN. Not applicable.

**C3. Prefill CUDA graph: drop `--disable-prefill-cuda-graph`.**
- That brings back the default prefill backend `breakable` (BCG) on CUDA (`model_executor/cuda_graph_config.py:122-131`). Add `--cuda-graph-max-bs-prefill 512|1024` (token buckets).
- `--cuda-graph-backend-prefill tc_piecewise` + `--cuda-graph-tc-compiler` are the other options.
- The auto-disable rules (`arg_groups/cuda_graph_hook.py:280-352`) include "multimodal model" unless allow-listed. Our architecture is `Qwen3_5ForConditionalGeneration`, so it may be force-disabled anyway [I].
- Effect [I]: it saves launch overhead on short tool-result prefills only. The GPU is already busy, so maybe 1-3 % of prefill time. It costs capture memory and startup time.
- Risk: medium. Arm: cheap, but low EV.

**C4. `--enable-torch-compile` / `--torch-compile-max-bs`.**
- It would fuse elementwise and norm ops (2.9 + 1.1 ms [M]), so ≤ 3 %.
- Compile time at startup adds to the GCSFUSE startup risk. Notes say "do not use". Low.

**C5. `--speculative-draft-model-quantization fp8`** (online W8A8 FP8 drafter) instead of `unquant`.
- Mechanism [S]:
  - Online FP8 linear (`QUANTIZATION_CHOICES` "fp8", `arg_groups/choices.py:33`);
  - sm_89 has CUTLASS FP8 with CUDA ≥ 12.4 (`layers/quantization/fp8_utils.py:298-307`);
  - the DFlash draft layers receive `quant_config` (`models/dflash.py:194-244, 427-447, 547-565`).
- Effect [I]:
  - It halves the drafter's weight bytes (about 0.85 GiB/rank BF16, read every step). That is part of the 14.5 ms "other GEMM", so about -2 to -4 ms/step (2-3 %), plus +0.4 GiB/rank free.
  - The output stays lossless (only acceptance can move).
  - `unquant` was needed so that the drafter does not inherit the target's INT4 compressed-tensors config (acceptance was about 1.0 otherwise). FP8 is a different, online path.
- Risk: medium (a loader failure on DFlash-specific modules; an acceptance dip).
- Arm: cheap. Gate on accept_short / accept_long.

**C6. `--bf16-gemm-backend gemv|cutedsl`.** Not available: gemv needs SM90, cutedsl SM100 (`layers/quantization/unquant.py:215-247`) [S]. `--fp8-gemm-backend` matters only together with C5 (auto). `--fp4-gemm-backend` does not apply.

**C7. Communication flags. None of them change TP4 decode on this box:**
- `--enable-nccl-nvls`: NVLS needs NVSwitch.
- `--enable-symm-mem`: NCCL symmetric-memory windows. The benefit is for NVLink; on SHM transport expect none [I].
- `--enable-torch-symm-mem`: help says SM90+.
- `--enable-mscclpp`: not in the cu130 lock [S: `sglwh/lock_cuda130.txt`].
- `--enable-quant-communications`: NPU only (`arg_groups/validation_hook.py:259-262`) [S].
- `--flashinfer-allreduce-fusion-backend`: SM90/SM10x.
- `--enable-aiter-allreduce-fusion`: ROCm.
- `--enable-layernorm-sp`: only `Qwen3ForCausalLM` (`layers/layernorm_sp.py:53`) [S]; prefill only, NVLink, same volume.
- `--enable-attn-tp-input-scattered` / `--boundary-reduction`: reduce-scatter + all-gather replace all-reduce at the same volume with more calls, which is no gain on PCIe [I]. Qwen3.5 defaults to rs+rsv (`arg_groups/boundary_reduction.py:38-50`).
- `--enable-two-batch-overlap` / `--enable-single-batch-overlap`: MoE + EP / DP-attention only (`arg_groups/validation_hook.py:520-540`; `models/qwen3_5.py` has no TBO) [S].
- `--enable-dp-lm-head` / `--enable-tp-lm-head-all-to-all`: DP-attention only (`layers/logits_processor.py:451-467`; `arg_groups/fields/parallel.py:181-195`).
- `SGLANG_USE_1STAGE_ALLREDUCE`: AMD only.
- `SGLANG_OPT_USE_CUSTOM_ALL_REDUCE_V2` and custom all-reduce in general: disabled at world size > 2 without full NVLink (`distributed/device_communicators/custom_all_reduce_utils.py:487-498`; `custom_all_reduce.py:272-281`) [S].
- `--pre-warm-nccl`: startup only.

**C8. NCCL environment for prefill-sized messages.**
- E14 benched only 983 KB. A prefill chunk issues 128 all-reduces of 4096 × 5120 × 2 B = 42 MB each.
- No 42 MB bench exists. `NCCL_ALGO=Tree` was +14.5 % at large sizes on a T4 SHM box but slower at ≤ 1 MB (Notes/26-28). NCCL picks per size by itself, so forcing it would hurt decode.
- Low. If anything: a bench-only check at 42 MB.

**C9. Logits all-gather (8.1 ms/step, 7 %).**
- No flag avoids the full-vocabulary verify gather in 0.5.21 (`layers/logits_processor.py:905-935`). `--enable-fp32-lm-head` would double it.
- A local-top-k gather like `models/dflash.py:107-150` would need a code patch. It is listed here because it is the only large in-process communication item besides all-reduce.

**C10. Other CUDA-graph and runtime knobs:**
- `--disable-cuda-graph-padding`: no-op, since all batch sizes are captured.
- `SGLANG_ENABLE_CUDA_GRAPH_DEDUP`, `SGLANG_ENABLE_GRAPH_POOL_BORROW`, `SGLANG_ENABLE_GRAPH_POOL_PRECARVE`: capture memory only.
- `SGLANG_ENABLE_METADATA_GLUE_GRAPH`: force-disabled for DFlash (`model_executor/runner/decode_cuda_graph_runner.py:466-479`) [S]. It would be usable with MTP, but CPU-bound gains only.
- `SGLANG_ENABLE_OVERLAP_PLAN_STREAM`: a separate stream for DFlash prep kernels (`speculative/dflash_info_v2.py:20-32`; `speculative/spec_utils.py:1168-1176`) [S]. ≤ 1 %, cheap env arm.
- `SGLANG_ENABLE_DELAY_SAMPLE`: not used with speculative decoding (`managers/tp_worker.py:663-671`) [S].
- `SGLANG_DISABLE_CONSECUTIVE_PREFILL_OVERLAP`: would remove overlap, which is negative.
- `SGLANG_DFLASH_EAGER_DRAFT_SAMPLER`: an A/B diagnostic only.
- `SGLANG_SPEC_TP_SYNC`: narrows rank-0 broadcasts of speculative decisions. The risk of rank divergence and hangs outweighs a sub-ms gain.
- `SGLANG_ROPE_CACHE_FP32`: no-op on CUDA, where the cache is already fp32 (`layers/rotary_embedding/base.py:113-115`) [S].
- `--enable-fused-qk-norm-rope`: used only by mellum / qwen3_moe [S].
- `SGLANG_MAMBA_CONV_DTYPE`: bf16 default; the conv window does not accumulate. Low.

### D. Speculative decoding

**D1. `--speculative-accept-threshold-acc` and `--speculative-accept-threshold-single`** (`fields/spec.py:108-115`): default 1.0 / 1.0.
- Mechanism [S]: they are read by the DFlash sampled verify (`speculative/dflash_utils.py:992-1037, 1113-1118`). The accept probability rises from p to min(1, p / threshold_acc); `threshold_single` auto-accepts when the target p exceeds it.
- Effect [I]: the accepted length rises at temperature sampling (W6 accept 4.24 [M]), so maybe +5-15 % tok/s.
- Output becomes **lossy**: it is biased toward the drafter's (greedy) choices, so the effective temperature drops.
- The greedy gate cannot see this (greedy verify does not use the thresholds). Only an eval can judge it.
- Risk: accuracy. Cheap for speed, expensive for validation.

**D2. `--speculative-adaptive` (+ `--speculative-adaptive-config`).**
- EAGLE / EAGLE3 with topk 1 only. It is disabled for DFLASH (`speculative/adaptive_spec_params.py:54-89`) [S].
- Arm: MTP 3/1/4 + adaptive, worth trying only if MTP wins in E15.
- `SGLANG_SPEC_SKIP_ZERO_STEP_DRAFT_EXTEND` goes with it. Low-medium.

**D3. `--speculative-use-rejection-sampling`.** EAGLE topk 1 only (`speculative/eagle_worker_v2.py`). Default target-only verify is lossless; this changes which tokens are accepted. Low.

**D4. These do not apply to us:**
- `--speculative-draft-attention-backend`: the draft attention is small (window 2048);
- `--speculative-token-map`: refused for MTP (`arg_groups/speculative_hook.py:934-935`), and DFlash already uses a top-k gather;
- `--enable-multi-layer-eagle`: our MTP has 1 layer;
- `--speculative-dflash-block-size`: an alias of the width;
- `--speculative-moe-*`: MoE;
- `SGLANG_ENABLE_SPLITKV_VERIFY`: ROCm triton;
- `SGLANG_RAGGED_VERIFY_MODE`: DSPARK.

### E. Serving, tokenizer, observability (CPU, ≤ 3 % bound)

**E1. `--stream-interval > 1`.** Must stay 1: with N > 1 DFLASH can skip the `len % N == 1` residue (E11-05 note in `e11_flags`).
- `--batch-notify-size` (default 16) and `SGLANG_FORCE_STREAM_INTERVAL` (non-streaming only) do not matter.

**E2. Tokenizer: `--tokenizer-worker-num`, `--detokenizer-worker-num`, `--enable-dynamic-batch-tokenizer`, `--enable-tokenizer-batch-encode`.**
- Each Duck turn re-renders and re-tokenizes the full 30-100k conversation (about 0.1-0.3 s CPU [I]) while that stream sits idle. That is about 0.5 % of a turn.
- Multi-process tokenizer with reasoning / tool parsers has risk. Low.

**E3. Logging and reports cost nothing measurable:** `--decode-log-interval`, `--enable-cache-report`, `--enable-metrics`, `SGLANG_LOG_SCHEDULER_STATUS_*`.

**E4. `--enable-strict-thinking`.**
- Grammar-based filtering of tool-call markers inside thinking. DFLASH supports grammar overlap (`speculative/spec_info.py:166-171`) [S].
- It is a behaviour / format lever, not speed. It adds per-step mask cost. Evaluate only against Duck turn-error rates.

**E5. `SGLANG_MAX_THINK_TOKENS`.** A thinking cap through the reasoner grammar (`constrained/reasoner_grammar_backend.py`). Do not use: the 60k thinking-floor rule.

**E6. Startup only, not throughput, but relevant to the 30-min launch timeout risk:**
- `--startup-weight-load-mode overlap` stages the checkpoint while graphs are captured, then commits the weights (`model_executor/model_runner_components/load_model_utils.py:325-337`; `managers/scheduler.py:1093, 1140`) [S]. Untested with INT4 Marlin repacking and DFLASH [I].
- `--weight-loader-prefetch-checkpoints` / `--weight-loader-prefetch-num-threads` / `--weight-loader-drop-cache-after-load` are already in the E14 load-path plans.

### F. Structural (not a one-flag E15 arm, listed for completeness)

**F1. 2×TP2 through `--dp-size 2 --tp-size 2`.**
- Custom all-reduce is allowed at world size 2 over PCIe (`custom_all_reduce.py:272-273`) [S], but it uses the 5.5× slower P2P.
- The DP controller has no prefix-affinity load balance (`fields/parallel.py:80-92`: round_robin / total_requests / total_tokens). However, OpenAI chat requests accept `routed_dp_rank` (`entrypoints/openai/protocol.py:974-978`) [S], so the Duck could pin each agent to a replica.
- Covered by E14 Notes/00.

**F2. FlashInfer ≥ 0.7 / SGLang 0.5.22 for the PCIe-IPC all-reduce (finding 1).** The only lever against the 50.9 ms.

## 4. Top 10 untested arms, ranked by expected value

EV = expected effect on coverage / LB per unit of cost. "Cheap" = one `e14_launch` + gate + windows in the existing `_arm()` harness.

| # | Arm (flags / env) | Class | Expected effect | Risk | Cheap? | Measured by | Basis |
|---|---|---|---|---|---|---|---|
| 1 | DFLASH W6 + `--mamba-ssm-dtype float32` (no ReplaySSM), + `--mem-fraction-static 0.86` or `--max-total-tokens ~600k` | accuracy | Native dtype; the 65.97 config used it. -4 to -5 % speed; +2.5 GiB/rank | needs user OK (reverses the fp16 choice); capacity gate | yes | gate + windows for speed; **eval for accuracy** | finding 6, B1 [S/I] |
| 2 | `--speculative-draft-model-quantization fp8` (online W8A8 FP8 drafter) | speed, lossless | -2 to -4 ms/step (2-3 %), +0.4 GiB/rank | loader / accept dip | yes | windows + accept_short / long | C5 [S/I] |
| 3 | `--attention-backend triton` (Lean auto; try `--triton-attention-num-kv-splits 16`) | speed at long context | 0 at 8k; maybe 3-5 % at 40-80k | fp8 KV + DFLASH verify on triton | yes | **40k window only** + gate | C1 [S/I] |
| 4 | `SGLANG_OPT_MAMBA_SKIP_DECODE_LOCK=1` (+ `e11_slots` lazy = 3) | concurrency / retention | Mamba 56 then supports 18 running; or +12 evictable tail slots | opt-in lock path | yes (env arm) | latch + agent replay; combine with the at14 / 16 arms | B2 [S] |
| 5 | `--speculative-accept-threshold-acc 0.8` (or `-single 0.6`) on DFLASH | speed, **lossy** | maybe +5-15 % tok/s | output distribution shifts; greedy gate blind | speed-cheap | **eval only** | D1 [S/I] |
| 6 | `--prefill-decode-interval 4..8` + `--chunked-prefill-size 2048` | interference | aggregate tok/s about 0 (±); decode stall per chunk bounded | low | yes | latch + agent replay (not steady windows) | A1 / A2 [S] |
| 7 | `--mamba-max-states-per-path 2` (+ B7 `--max-mamba-cache-size 96` at mrr 13) | retention | small at 12 streams (R2 `deeper_miss 0`); more at 14-20 | low | yes | agent replay | B3 / B7 [S/M] |
| 8 | `--mamba-track-interval 64` (page_size 1) | prefill share | about -96 re-prefill tokens per partial reply; <1 % | low | yes | agent replay | B5 [S/M] |
| 9 | MTP 3/1/4 + `--speculative-adaptive` (only if MTP beats DFLASH in E15) | speed | adapts steps to acceptance along long reasoning | extra captures | yes | windows | D2 [S] |
| 10 | Breakable prefill CUDA graph (drop `--disable-prefill-cuda-graph`, `--cuda-graph-max-bs-prefill 512`) | prefill | 1-3 % of prefill time on short tool results | capture memory; may auto-disable (multimodal arch) | yes | prefill tok/s on short prompts | C3 [S/I] |

Below the cut: `SGLANG_ENABLE_OVERLAP_PLAN_STREAM` (≤ 1 %), `--enable-mixed-chunk` (negligible, #43514), bf16 KV (only if the scale load fails), HiCache (high risk, no evidence of evictions), `--speculative-draft-kv-cache-dtype bf16` (+2.2 GiB/rank for maybe a small accept gain).

**Not arms on 0.5.21:** the PCIe-IPC all-reduce (FlashInfer 0.6.18, finding 1); DFLASH + ReplaySSM (finding 2); the GDN FlashInfer / CuTe DSL backends (SM90+); TBO, DP lm-head, NVLS, torch-symm-mem, mscclpp, quant-communications, layernorm-SP; `--num-continuous-decode-steps`, `--triton-attention-reduce-in-fp32`, `--sampling-backend` (no-op or no CLI).

## 5. Harness notes for adding these arms

- Arms 1, 5 and partly 3 change numerics or sampling. The E15 `arm_gate` (greedy large-margin flips vs the A/A) is necessary but not sufficient. Arm 5's thresholds are not exercised by greedy at all.
- Arm 4 changes the slot math: `e11_slots()` returns 4 for lazy, and `e11_capacity_gate` would under-report concurrency. Pass the env through `e14_launch(env=...)`; `_arm()` currently passes no env.
- Arms 6-8 need the E14 agent replay (A2-1: reply_reused / lost_at_prefill_end / partial_reply / deeper_miss) or the latch test. The 8k / 40k steady windows cannot see them.
- Arm 1 memory: check `avail_mem_gb_last ≥ SGL_MIN_FREE_GB` and `kv_tokens // SGL_KV_PER_REQUEST ≥ 12` in the gate before the windows.
- Arm 2: compare `accept_short` / `accept_long` with the ref (W6 4.24 [M]). An accept drop of more than about 3 % cancels the GEMM gain.
