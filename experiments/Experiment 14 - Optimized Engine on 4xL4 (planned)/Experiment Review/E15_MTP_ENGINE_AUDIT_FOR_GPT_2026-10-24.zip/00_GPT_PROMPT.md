# Pre-GPU audit request: E15 engine experiment (one 180-min Kaggle commit, 4x L4)

You are an independent reviewer. Read EVERY file in this zip (no skimming). Start with `README.md`, then
`notebook/E15_cell_5c.py` (the new E15 cell), then `notebook/notebook_cells.py` (all cells; the E15 cell runs after
CELL 5b, before the Duck run in CELL 6), `code/build_e14.py`, and `code/src/e14_measure.py`.

Context: Kaggle ARC Prize 2026 ARC-AGI-2. 4x NVIDIA L4 24 GB (sm_89, PCIe PHB, no NVLink), Qwen3.8-27B RedHat INT4
W4A16, SGLang 0.5.21, TP4. The submitted engine = DFlash2 width 6 + CUDA graphs 1..13, 12 client streams but the DFlash
min-free-slots delayer keeps 11 running under churn; KV usage 18-41 %. E15 measures, in ONE commit run: the 11-of-12
fixes, DFlash width 6 at 14/16/20 really-running streams, built-in MTP (EAGLE 3/1/4 with an explicit draft path) and
variants, a long greedy probe vs target-only, then a 15-min Duck run on the adopted 12-stream arm. Evidence of the last
GPU run is in `evidence/` (R2: Notes/30, measured numbers; MTP source preflight: Notes/35).

Answer each question with GO / NO-GO / UNSURE + evidence (file:line) + the exact fix if any:

1. **Will it run to the end?** Startup → reference → ~16 launches → Duck → report within the 180-min budget (hard stop
   178 min, Kaggle 12 h far away). Check every launch/phase deadline (`e14_launch`, `e14_phase`, `launch_allowed`,
   `E14_RESERVE`), what happens if an arm's server fails to launch or crashes mid-window (relaunch of the kept arm?), and
   that the Duck run always gets its reserved window. Any path to a notebook ERROR, a hang, or a missing report/bundle?
2. **Flags:** for every arm, are the SGLang 0.5.21 flags exactly right (`e14_edit_flags` drop/set with lists and None)?
   Especially: MTP = `--speculative-algorithm EAGLE --speculative-draft-model-path <INT4 dir> --speculative-num-steps 3
   --speculative-eagle-topk 1 --speculative-num-draft-tokens 4` with DFlash flags removed; ReplaySSM
   `--enable-linear-replayssm-spec` (+ `--mamba-ssm-dtype float32`); `--min-free-slots-delay 1` with mrr 12;
   mrr / mamba cache / `--cuda-graph-bs-decode` lists for 14/16/20 (delayer threshold min(4, max(2, (mrr+5)//6))).
   Could any arm OOM at mem 0.83 (mamba 96 slots at mrr 24; MTP mem 0.86)? Will the 1..24 graph capture time blow the
   relaunch budget?
3. **Measurement validity:** `steady_window` at level 14/16/20 cycles the 12 prompts (duplicate prompts share radix
   cache) — does this bias tok/s? `latch_test` server_cap per arm; `_probe` (c12/c14/c16/c20 × 1,024 greedy) vs the
   reference probe — is the comparison index-aligned and meaningful given bf16 logits (0.125-nat margin steps, ties)?
   Is the adoption rule (`_gated`, `_cand`, `latch_fix`) sound? Any arm whose result could be misread?
4. **Correctness risk to the Duck run:** the Duck runs on the chosen arm with a fresh forced launch — does it skip the
   capacity gate / smoke? Could a probe-failing arm still be chosen?
5. **What is missing** that should be in THIS run (cheap, ≤ 10 GPU-min each), e.g. chunked prefill 2048, SSM fp32 for
   DFlash width 6 at 12, `--enable-mixed-chunk` (note: SGLang #39342 mixed-chunk corrupts mamba checkpoints), a
   cache-restore parity check? Keep the list short and ranked.
6. **Any bug** in `notebook/E15_cell_5c.py` (variable scope `E15_REF` / `E15_PROBE_REF` / `globals()`, NameError
   paths, results not saved, wrong keys like `tok_s_p50`, `share_running_ge_level`).

Output: sections 1-6, every item numbered, verdict + evidence + fix; then one ranked list "fix before the GPU run" and
"optional". Say clearly what is your estimate vs what is in the files. Do not rewrite the experiment.
