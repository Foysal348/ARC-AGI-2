# ==================================================================== CELL 5c — E15: MTP and engine arms (Notes/35)
# Reference = the submission arm (W6 + graphs13, the first launch). Arms, each its own launch, gate first (large-margin
# flips vs the reference A/A), then 8k / 40k windows at the measured level: W8; MTP EAGLE 3/1/4 (explicit draft path =
# the INT4 dir: without it 0.5.21 sizes KV without the draft layer); MTP + mem 0.86; MTP 2/1/3; MTP + ReplaySSM fp32 / fp16;
# the best MTP at 14 and 16 really running (mrr 15 / 17, mamba 60 / 68, graphs 1..15 / 1..17). The Duck run (CELL 6)
# starts on a fresh launch of the fastest gated arm whose long window is not worse than the reference's.
E15_ON = bool(P.get("e15")) and ENGINE_READY and not RERUN
if E15_ON:
    import statistics
    E14_CTX = E14M.Ctx(SGL_URL, lambda: E11_SERVER.log_text() if E11_SERVER is not None else "", E14_OUT,
                       model_id=_e14_model_id(), deadline=HARD_STOP - 8 * 60, log=print, encode=None,
                       normalize=_E12_TA._normalize_message_content)
    E14_CTX.scale = E14_TS
    _rs = {"solve_window": float(E12_SOLVE_WINDOW_SEC or 900), "stop_before_hard": float(E12_STOP_BEFORE_HARD_SEC),
           "preflight": _ts(300), "artifacts": _ts(600), "duck_relaunch": _ts(400)}
    E14_RESERVE = round(sum(_rs.values()), 1)
    E15R = {"reserve": dict(_rs, total=E14_RESERVE), "arms": {}, "launches": {}}
    E14_RESULTS["e15"] = E15R
    E15_REF = None
    try:
        E14_PROMPTS = e14_prompts()
    except Exception as _e:
        E14_PROMPTS = {"short": [], "long": [], "duck": [], "tool_text": "", "tokens": {"error": repr(_e)[:300]}}
    E15R["prompts"] = E14_PROMPTS["tokens"]
    _S, _L = E14_PROMPTS["short"], E14_PROMPTS["long"]
    _SPEC = ("--speculative-algorithm", "--speculative-draft-model-path", "--speculative-draft-model-quantization",
             "--speculative-num-draft-tokens", "--speculative-num-steps", "--speculative-eagle-topk")

    def _mtp(steps=3, draft=4, extra=None):
        d = {"--speculative-algorithm": "EAGLE", "--speculative-draft-model-path": str(SGL_MODEL_PATH),
             "--speculative-num-steps": steps, "--speculative-eagle-topk": 1, "--speculative-num-draft-tokens": draft}
        d.update(extra or {})
        return d

    def _ref_gate():
        a = E14M.parity_pass(E14_CTX, _S[:6], max_new=256, tag="e15ref_serial_a")
        b = E14M.parity_pass(E14_CTX, _S[:6], max_new=256, tag="e15ref_serial_b")
        c = E14M.parity_pass(E14_CTX, _S, max_new=256, concurrent=True, tag="e15ref_conc_a")
        c2 = E14M.parity_pass(E14_CTX, _S, max_new=256, concurrent=True, tag="e15ref_conc_b")
        globals()["E15_REF"] = E14M.gate_reference(a, b, c, c2)
        return {"serial_aa": E14M.compare_passes(a, b, "E15 ref serial A/A"),
                "conc_aa": E14M.compare_passes(c, c2, "E15 ref all-at-once A/A")}

    def _windows(tag, level, gate=True, latch_cap=None, probe_n=None):
        def run():
            out = {}
            if gate:
                out["gate"] = E14M.arm_gate(E14_CTX, _S, E15_REF, tag="gate_" + tag, identity=False)
                if not out["gate"].get("ok"):
                    out["windows_skipped"] = "the correctness gate did not pass"
                    return out
                out["flush_after_gate"] = E14M.flush_cache(E14_CTX)
            out["short"] = E14M.steady_window(E14_CTX, _S, level=level, secs=_ts(75), tag=tag + "short")
            out["long"] = E14M.steady_window(E14_CTX, _L, level=level, secs=_ts(75), tag=tag + "long")
            if latch_cap:
                out["latch"] = E14M.latch_test(E14_CTX, _S, _L, decodes=SGL_MAX_RUNNING - 1, arrivals=3, secs=_ts(60),
                                               server_cap=latch_cap, level=SGL_MAX_RUNNING)
            if probe_n:
                out["flush_before_probe"] = E14M.flush_cache(E14_CTX)
                out["probe"] = _probe_vs_ref(_probe(tag, probe_n), f"{tag} c{probe_n} x 1024 vs reference c12")
            return out
        return run

    E15_PROBE_REF = None

    def _probe(tag, n=None):
        # 1,024 greedy tokens, thinking on, every prompt at once (n prompts: cycles the 12 tasks for 14 / 16 / 20)
        _ps = [_S[i % len(_S)] for i in range(n or len(_S))] if _S else []
        return E14M.parity_pass(E14_CTX, _ps, max_new=1024, concurrent=True, tag="probe_" + tag)

    def _probe_vs_ref(rows, name):
        if not E15_PROBE_REF:
            return {"skipped": "no reference probe"}
        return E14M.compare_passes(E15_PROBE_REF[0], rows[:len(E15_PROBE_REF[0])], name)

    def _tok(r, band):
        return ((r or {}).get(band) or {}).get("tok_s_p50")      # e14_measure.window_stats key

    def _arm(name, set_=None, drop=(), level=None, gate=True, cap=12 * 60, latch_cap=None, probe_n=None):
        _ok, _rec = e14_launch(name, set_=set_ or {}, drop=drop)
        E15R["launches"][name] = {k: _rec.get(k) for k in ("ok", "why", "sec", "caps", "skipped")}
        _r = e14_phase("E15_" + name, _windows(name, level or SGL_MAX_RUNNING, gate=gate, latch_cap=latch_cap,
                                               probe_n=probe_n),
                       _ts(cap + (3 * 60 if latch_cap else 0) + (3 * 60 if probe_n else 0))) if _ok else None
        _er = E14M.log_errors((_r or {}).get("server_log_signs"))
        E15R["arms"][name] = {"ok": bool(_ok and _r and not _r.get("error")),
                             "gate": ((_r or {}).get("gate") or {}).get("verdict", "reference" if not gate else None),
                             "short_tok_s": _tok(_r, "short"), "long_tok_s": _tok(_r, "long"),
                             "accept_short": ((_r or {}).get("short") or {}).get("accept_p50"),
                             "step_ms_short": ((_r or {}).get("short") or {}).get("step_ms_p50"),
                             "step_ms_long": ((_r or {}).get("long") or {}).get("step_ms_p50"),
                             "accept_long": ((_r or {}).get("long") or {}).get("accept_p50"),
                             "level_short": ((_r or {}).get("short") or {}).get("measured_level"),
                             "level_long": ((_r or {}).get("long") or {}).get("measured_level"),
                             "kv_tokens": ((_rec or {}).get("caps") or {}).get("kv_tokens"),
                             "mamba_cache": ((_rec or {}).get("caps") or {}).get("mamba_cache_size"),
                             "capped_to": ((_rec or {}).get("caps") or {}).get("capped_to"),
                             "log_errors": _er, "set": set_ or {}, "drop": list(drop),
                             "latch_ge12": ((_r or {}).get("latch") or {}).get("share_running_ge_level"),
                             "latch_stuck11": ((_r or {}).get("latch") or {}).get("share_stuck_below_queued"),
                             "probe_flips": ((_r or {}).get("probe") or {}).get("large_margin_flips"),
                             "probe_identical": ((_r or {}).get("probe") or {}).get("identical")}
        e14_save()
        print("E15 arm", name, json.dumps(E15R["arms"][name], default=str)[:600], flush=True)
        return E15R["arms"][name]

    def _gated(a):
        _aa = (E15R.get("probe_ref_aa") or {}).get("large_margin_flips") or 0
        _pf = (a or {}).get("probe_flips")
        return bool(a and a.get("ok") and a.get("gate") in ("PASS", "reference") and not a.get("log_errors")
                    and (_pf is None or _pf <= _aa + 1))

    # reference = the running submission arm (first launch); its A/A builds the gate reference
    E14_STATE.enter("E15_REF")
    e14_phase("E15_ref_aa", _ref_gate, _ts(8 * 60))
    _r0 = e14_phase("E15_ref_windows", _windows("ref", SGL_MAX_RUNNING, gate=False, latch_cap=SGL_SERVER_MAX_RUNNING),
                    _ts(11 * 60))
    E15R["arms"]["ref_w6g13"] = {"ok": bool(_r0 and not _r0.get("error")), "gate": "reference",
                                "short_tok_s": _tok(_r0, "short"), "long_tok_s": _tok(_r0, "long"),
                                "accept_short": ((_r0 or {}).get("short") or {}).get("accept_p50"),
                                "accept_long": ((_r0 or {}).get("long") or {}).get("accept_p50"),
                                "kv_tokens": ENGINE_INFO.get("kv_tokens"), "set": {}, "drop": [],
                                "latch_ge12": ((_r0 or {}).get("latch") or {}).get("share_running_ge_level"),
                                "latch_stuck11": ((_r0 or {}).get("latch") or {}).get("share_stuck_below_queued")}
    e14_save()

    def _ref_probe():
        a = _probe("ref_a")
        b = _probe("ref_b")
        globals()["E15_PROBE_REF"] = (a, b)
        E15R["probe_ref_aa"] = E14M.compare_passes(a, b, "reference c12 x 1024 A/A")
        return {"aa": E15R["probe_ref_aa"]}
    e14_phase("E15_probe_ref", _ref_probe, _ts(8 * 60))
    _okt, _rt = e14_launch("target_only", spec=False)
    E15R["launches"]["target_only"] = {k: _rt.get(k) for k in ("ok", "why", "sec", "caps", "skipped")}
    _pt = e14_phase("E15_probe_target_only", lambda: {"probe": _probe_vs_ref(_probe("target"),
                                                                             "target-only c12 x 1024 vs reference DFlash")},
                    _ts(8 * 60)) if _okt else None
    E15R["probe_target_only"] = ((_pt or {}).get("probe") or {})
    E15R["arms"]["target_only"] = {"ok": bool(_okt and _pt), "gate": "diagnostic",
                                   "probe_flips": E15R["probe_target_only"].get("large_margin_flips"),
                                   "probe_identical": E15R["probe_target_only"].get("identical"), "set": {}, "drop": []}
    e14_save()
    _arm("w8", set_={"--speculative-num-draft-tokens": 8})
    # 11-of-12 (DFlash min-free-slots delayer, threshold 3 at mrr 13): (a) keep the delayer, mrr 14 + graphs 1..14 (at 11
    # running 3 slots are free, so the 12th is admitted; buffers sized 14, the client never sends > 12); (b) delayer off
    # with mrr 12 (the R2 crash needed 13 running). Both with the churn latch test.
    _arm("w6_mrr14", set_={"--max-running-requests": 14, "--cuda-graph-bs-decode": list(range(1, 15))}, latch_cap=14)
    _arm("w6_nodelay_mrr12", set_={"--min-free-slots-delay": 1, "--max-running-requests": 12}, latch_cap=12)
    # more streams on the submission engine (user 2026-10-24: "KV 0.18-0.41 used"): DFlash W6 really running 14 and 16.
    # The DFlash delayer keeps min(4, max(2, (mrr + 5) // 6)) slots free under churn: mrr 17 -> 14, mrr 20 -> 16,
    # mrr 24 -> 20; mamba cache = 4 slots x mrr; graphs cover every batch up to mrr
    for _lvl, _mrr in ((14, 17), (16, 20), (20, 24)):
        _arm(f"w6_at{_lvl}", set_={"--max-running-requests": _mrr, "--max-mamba-cache-size": 4 * _mrr,
                                   "--cuda-graph-bs-decode": list(range(1, _mrr + 1))}, level=_lvl, latch_cap=_mrr,
             probe_n=_lvl)
    _mtp_drop = _SPEC
    _arm("mtp_3_1_4", set_=_mtp(), drop=_mtp_drop, probe_n=SGL_MAX_RUNNING)
    _arm("mtp_3_1_4_mem86", set_=_mtp(extra={"--mem-fraction-static": "0.86"}), drop=_mtp_drop)
    _arm("mtp_2_1_3", set_=_mtp(steps=2, draft=3), drop=_mtp_drop)
    _arm("mtp_replay_fp32", set_=_mtp(extra={"--enable-linear-replayssm-spec": None, "--mamba-ssm-dtype": "float32"}),
         drop=_mtp_drop)
    _arm("mtp_replay_fp16", set_=_mtp(extra={"--enable-linear-replayssm-spec": None}), drop=_mtp_drop)
    # the best gated MTP arm at 12 (short tok/s) -> 14 and 16 really running
    _mtps = {k: v for k, v in E15R["arms"].items() if k.startswith("mtp_") and _gated(v) and v.get("short_tok_s")}
    _best_mtp = max(_mtps, key=lambda k: _mtps[k]["short_tok_s"]) if _mtps else None
    E15R["best_mtp_at_12"] = _best_mtp
    if _best_mtp:
        _bs = dict(E15R["arms"][_best_mtp]["set"])
        for _lvl, _mrr, _mc in ((14, 15, 60), (16, 17, 68)):
            _arm(f"{_best_mtp}_at{_lvl}", set_=dict(_bs, **{"--max-running-requests": _mrr, "--max-mamba-cache-size": _mc,
                                                          "--cuda-graph-bs-decode": list(range(1, _mrr + 1))}),
                 drop=_mtp_drop, level=_lvl)
    # the Duck arm: the fastest gated arm at 12 (the 14 / 16 arms change the Duck's admission, so they are reported only)
    _ref = E15R["arms"]["ref_w6g13"]
    # the Duck runs 12 client streams: only 12-stream arms qualify (the _atN arms and the target-only diagnostic are reported)
    _cand = {k: v for k, v in E15R["arms"].items() if "_at" not in k and k != "target_only" and (_gated(v) or k == "ref_w6g13")
             and v.get("short_tok_s") and (v.get("long_tok_s") or 0) >= 0.98 * (_ref.get("long_tok_s") or 0)}
    _duck = max(_cand, key=lambda k: _cand[k]["short_tok_s"]) if _cand else "ref_w6g13"
    _fix = [k for k in ("w6_mrr14", "w6_nodelay_mrr12") if _gated(E15R["arms"].get(k))
            and (E15R["arms"][k].get("latch_ge12") or 0) >= 0.5 > (_ref.get("latch_ge12") or 0)
            and (E15R["arms"][k].get("short_tok_s") or 0) >= 0.98 * (_ref.get("short_tok_s") or 0)]
    E15R["latch_fix"] = _fix[0] if _fix else None
    if _fix and _duck in ("ref_w6g13", "w6_mrr14", "w6_nodelay_mrr12"):
        _duck = _fix[0]
    E15R["duck_arm"] = _duck
    E14_RESERVE = 0.0
    _da = E15R["arms"].get(_duck) or {}
    e14_launch("duck_" + _duck, set_=_da.get("set") or {}, drop=tuple(_da.get("drop") or ()), force=True)
    E14_RESULTS["decisions"]["e15"] = {"duck_arm": _duck, "best_mtp_at_12": _best_mtp,
                                       "probe_ref_aa_flips": (E15R.get("probe_ref_aa") or {}).get("large_margin_flips"),
                                       "probe_target_only_flips": E15R["probe_target_only"].get("large_margin_flips"),
                                       "latch_fix": E15R.get("latch_fix"),
                                       "table": {k: {f: v.get(f) for f in ("gate", "short_tok_s", "long_tok_s", "accept_short",
                                                                          "accept_long", "kv_tokens", "level_short",
                                                                          "latch_ge12", "latch_stuck11", "probe_flips",
                                                                          "probe_identical")}
                                                 for k, v in E15R["arms"].items()}}
    E14_STATE.enter("DUCK", arm=_duck)
    e14_save()
    print("E15 decisions:", json.dumps(E14_RESULTS["decisions"]["e15"], default=str)[:2500], flush=True)
# ==================================================================== CELL 6 — E12: Duck REPL agen