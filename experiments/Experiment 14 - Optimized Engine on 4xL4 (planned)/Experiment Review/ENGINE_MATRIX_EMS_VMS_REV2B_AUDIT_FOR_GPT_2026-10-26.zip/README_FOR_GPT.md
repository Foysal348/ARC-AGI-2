# Engine-matrix notebooks (EMS = SGLang 0.5.21, VMS = vLLM 0.32.0): implementation audit pack, 2026-10-26 (rev 2b)

Notebook shas: EMS `f9201b43` (local fake-server harness 25/25), VMS `94c3cc05` (18/18 normal + 18/18 with the #58807 bad ignore list). rev 2b = rev 2 (your pre-GPU audit) + a 4-agent implementation audit (`agent_reports/`, disposition `notes/EMS_VMS_rev2b_agent_audit_disposition_2026-10-26.md`).

## Goal
Pick the fastest correct serving configuration for Qwen3.8-27B on Kaggle (4 x L4 24 GB, SM 8.9, PCIe only, offline, 12 h).
The target is 600-800 output tok/s aggregate at 16+ streams. Both notebooks are engine-only and run no solver. Each arm is its own server launch:

1. a greedy correctness gate (serial + all at once, 256 tokens, against an identity oracle's own A/A);
2. two 75-s steady windows (8k-context and 40k-context prompts built from real ARC tasks) at the level the server really runs;
3. a report table and a bundle.

The time budget is 200 min each. 2 x TP2 runs last, from a reserved slot.

Current production for comparison: SGLang INT4 + DFlash2 width 6 at 16 streams, ~389 tok/s. In the last 6-h Poetiq run, 83 % of first answers hit the 60k cap and only 18 / 120 tasks reached iteration 2, so engine speed is the lever.

## What changed in this revision (your earlier pre-GPU audit, our disposition)
- `notes/EMS_rev2_audit_disposition_2026-10-25.md`: SGLang. Each S1-S9 item was checked in the 0.5.21 source; what changed and what did not, with file:line.
- `notes/VMS_rev2_audit_disposition_2026-10-26.md`: vLLM. Each V1-V6 item was checked in the v0.32.0 tag source.
- `notes/EMS_VMS_rev2b_agent_audit_disposition_2026-10-26.md`: every finding of the 4 agents and what was done (rev 2b).
- `gpt_audit_input/`: your two pre-GPU audit READMEs, as received.

## Files
- `notebooks/`: both notebooks, exactly as they would be pushed (sha256 in `MANIFEST.txt`).
- `builders/`: `build_ems.py`, `build_vms.py` (the notebooks are generated from these), `patch_vms_rev2.py`, `build_cpu_kit_engine.py`.
- `harness/`: the CPU harness generators and the fake servers:
  - `make_harness_ems.py` / `make_harness_vms.py` generate `harness_*_nb.py`;
  - `fake_vllm_server.py`;
  - `make_e15p_fake_server.py` / `e15p_fake_server.py` (the fake SGLang server).
- `harness_logs/`: local run logs:
  - `ems_run4.log`: 23/23 checks;
  - `vms_run2.log`: normal mode;
  - `vms_run2_bad.log`: `VMS_BAD_INT4=1`, the #58807 ignore list.
- `source_refs/`: the upstream source files we cited:
  - SGLang 0.5.21: GDN backends, attention hook, KV / mamba configurator excerpts, server_args port allocation, custom all-reduce utils;
  - vLLM v0.32.0: envs.py, config/kernel.py, arg_utils.py, qwen3_5_mtp.py.
- `redhat_int4_mtp_static.txt`: the RedHat INT4 config ignore list (MTP entries) and the mtp.* index keys.

## Please audit (be concrete: file + line, the failing scenario, the minimal fix)
1. **Oracle logic.** EMS uses target-only INT4 with no speculation; VMS uses FP8 target-only with prefix caching off. Is replacing the gate reference after the fact (judging the production reference from its own rows) correct? Any path where a missing or partial oracle silently passes an arm?
2. **The gate rule.** Both notebooks now use large-margin flips (top-1 minus top-2 logprob > 1 nat at the first divergence) vs the oracle A/A; VMS adds a degenerate-output count. EMS also records a second verdict vs the DFlash reference rows. Are the thresholds sound for greedy on different speculative paths? Recording FAIL but still measuring speed: any way a FAIL arm can be picked as "best" downstream (`_gated`, the TP2 best-MTP pick, the report)?
3. **VMS `vms_degenerate`.** Is the heuristic able to miss #53912-style output or false-alarm on normal reasoning text?
4. **VMS `vms_int4_mtp_static`.** Is the ignore-list matching (`re:` prefix, exact, prefix + ".") the same as vLLM 0.32.0 compressed-tensors `should_ignore_layer`? Are fused names (qkv_proj, gate_up_proj) handled? Is the draft built under prefix `mtp` in the v0.32.0 spec-decode path?
5. **VMS `--linear-backend marlin / triton`** on FP8 block-128 on SM 8.9: will vLLM accept these values for this layer type, or reject them at startup? Does `vms_kernels` catch the actual selection log lines of v0.32.0?
6. **EMS 2 x TP2.** Are the per-replica cache dirs (seeded copies without the CUDA driver cache), the topology-based GPU pairing, and the two nccl ports enough isolation? Is there anything else two SGLang servers on one box share?
7. **Time.** Is 200 min realistic for the planned arms, given launch + gate + windows + probe at ~10-15 min per arm? Which arms would you cut or reorder so the highest-value ones always run?
8. Any crash path in the new code (KeyError on a skipped arm, a `None` level, a missing metric) that the fake-server harness would not show.

Do not re-audit items already marked "checked and left unchanged" unless you have a concrete counter-example from the cited source.
