# Research question: what "tiny kernel issue" can cost a third of the ARC-AGI-2 score, and do we have one?

Date: 2026-10-26. Competition: Kaggle ARC Prize 2026, ARC-AGI-2. Hardware: 4x NVIDIA L4 24 GB (Ada, sm_89), PCIe only, no
NVLink, no internet, 12 h, hidden test of 240 tasks (scored rerun on a separate machine pool). Model: Qwen3.8-27B
(hybrid: Gated DeltaNet linear attention + full attention every 4th layer, built-in MTP head).

## 1. The competitor (all evidence in `01_competitor/`, start with `A_mikelou1_all_posts_and_interpretations.md`)

Kaggle user **mikelou1**, thread 748082 ("Qwen3.8-27B / Flash-Next: ARC-AGI-2 results within Kaggle's compute limits?"),
verbatim:
- 2026-10-11: "Qwen scored ~25%. After some minor optimizations I hope it can get to 40%."
- 2026-10-13: "It got 36%. I have a submission with projected ~50% ± 10% running right now."
- **2026-10-16: "Not a NVARC ensemble, as my program don't have time to do that. However there is a tiny kernel issue I found
  that made my program score only 40% (instead of the 60% projected by CV)."**
- **2026-10-18: "UPDATE: It scored 66% (~60% on CV)"**
- He never explained the issue. His CV was an "LB-ish environment ... at around 4xL4 speed". His background is GPU
  performance patching. He also competes in ARC-AGI-3. He uses Qwen3.8 (27B or Flash-Next, unconfirmed).

Constraints any explanation must satisfy:
- the fix was "tiny" and quick (graded 10-16, fixed submission in by 10-17);
- it cost about a third of the score without an error or 0.00;
- his CV did not show it, only the scored rerun did.

Our earlier ranking (in A_mikelou1.md section 3):
1. a Kaggle "kernel" (notebook / scored-rerun environment) issue, about 45 %;
2. a GPU / inference kernel issue visible only on real L4s or the scored machines, about 40 %;
3. an OS / container kernel issue (sandbox), about 15 %.

## 2. Why this matters to us: we see the same CV-high / LB-low pattern

| Run | Eval (task-normalised, EVAL120) | LB | LB / eval |
|---|---|---|---|
| Direct reasoning 49k (v1.4.4) | about 25 | 26.94 | 1.06 |
| Direct 86k (E9 / E10 ORDER2) | 36.94 | 22.92 | 0.62 |
| Poetiq R5, vLLM FP8 + MTP-3, 12 h | 48.61 | 21.39 | **0.44** |
| Poetiq S1-60K, vLLM | - | **34.58 (our best)** | - |
| Poetiq S49 49k, vLLM | - | 32.08 | - |
| Poetiq P1-60K on SGLang INT4 + DFlash2 | - | 29.17 | - |
| Duck agent E15B 40K35K, SGLang | about 39 | 22.92 | about 0.59 |
| Poetiq E15P, SGLang, 6 h | 39.31 | pending | - |

Our current explanation is coverage: 240 hidden tasks, and too little throughput in 12 h. But mikelou1's story suggests that
a "tiny" fix can recover a large share. We want an independent search for such causes in our stack.
- Our LB noise sd is about 1.5.
- The public LB uses part of the hidden set, per our notes.

## 3. Our stack (details in `03_our_data/`, `04_code/`, and the live engine logs of 2026-10-26)

**SGLang production engine.**
- SGLang 0.5.21; RedHatAI Qwen3.8-27B-INT4 (W4A16 g128, Marlin); BF16 DFlash2 drafter, width 6; TP4; FP8 e4m3 KV.
- `--mamba-ssm-dtype float16` (the model config says float32); `--mamba-radix-cache-strategy extra_buffer_lazy`; `--max-mamba-cache-size 68` (16 running x 4 slots = 64 live).
- Chunked prefill 4096; CUDA graphs 1..17 (prefill graph off); `--min-free-slots-delay 1`.
- Custom all-reduce disabled (PCIe-only TP4), NCCL SHM (P2P/IPC 5.5x slower on Kaggle).
- `qwen3` reasoning parser, `qwen3_coder` tool parser, `preserve_thinking`, `--schedule-policy lpm`, radix cache on.
- The exact launch flags are in `03_our_data/engine_matrix_live_logs_2026-10-26/live_foysal_v1.log` (the `engine:` line).

**vLLM path (best LB).** vLLM 0.19 / 0.32 + FP8 checkpoint + MTP-3 + prefix caching.

**Measured today (engine matrix, 16 streams).**
- DFlash W6 reference: 572 / 544 / 403 tok/s (8k / 40k / ~90k context).
- Target-only: 400 / 348 / 274.
- "DFlash vs target-only: PASS" on a 256-token greedy gate plus a 1,024-token probe.

**Known open suspects from our own research (`02_known_bugs/B_web_silent_accuracy_bugs_ranked.md`, `03_our_data/C_ours_silent_accuracy_evidence.md`).**
- **SGLang PR #43567** (merged in 0.5.22). With `extra_buffer_lazy`, when no pending mamba slot is free, a stale mamba checkpoint is donated to the radix cache. Later prefix hits restore the wrong state: silent wrong tokens, KL 0.649 in the PR's test. A backport is in `04_code/e14_sglang_patches.py` but has **never been applied in production**. Our config leaves only 4 spare mamba slots, and every Poetiq / Duck turn re-hits a long prefix.
- fp16 vs fp32 SSM state at 40-70k-token decode (never measured beyond ~45k).
- DFlash verify / sampler issues under concurrency (SGLang #36548 class).
- FP8 KV calibrated scales: are they live at runtime?
- Mid-thinking EOS (10 of 44 iterations on one SGLang run) and unfenced code (5 of 88 on SGLang vs 0 of 432 on vLLM).
- Scored-rerun-only differences: 240 vs 120 tasks, a different machine pool, queue time, `KAGGLE_IS_COMPETITION_RERUN` branches, CPU count, `/kaggle/input` GCSFUSE slowness (SGLang ready took 1,197 s on 10-21+, and a 30-min launch timeout means LB 0).

## 4. What we ask

1. **Hypotheses for mikelou1's jump.** Find the most likely concrete "tiny kernel issue" that turns 40 into 66 on Qwen3.8 + Kaggle 4x L4. Rank the hypotheses with evidence. Cover GPU-kernel, Kaggle-kernel (scored rerun) and OS-kernel readings. Use the discussion dumps and any public source you can reach; keep every URL literal (`https://...`).
2. **Map each hypothesis onto our stack.** Does it apply to SGLang 0.5.21 or vLLM 0.19 / 0.32 with our flags? Cite file:line in the upstream sources where possible. What is the cheapest decisive test: CPU, a short GPU smoke, or a log grep of the existing runs in this pack?
3. **Explain our CV-to-LB gap.** Does anything in our data point to a non-coverage cause (e.g. LB/eval 0.44 for Poetiq R5)?
4. **Deliverable.** A ranked list with, for each item:
   - the expected LB impact;
   - the evidence (verified / inferred);
   - the exact test;
   - the exact fix.

   Mark anything you cannot verify as UNVERIFIED. No GPU was run for this pack.

## 5. Layout

- `01_competitor/`: all mikelou1 posts, the Kaggle API pulls and discussion dumps, LB snapshots, public notebooks and resources.
- `02_known_bugs/`:
  - silent-accuracy bug research;
  - SGLang / vLLM issue dumps;
  - release notes 0.5.21 / 0.5.22;
  - model card and RedHat INT4 config;
  - our deep-research notes 26-29 and 43;
  - the 4x L4 bottleneck research.
- `03_our_data/`:
  - our accuracy evidence (C_ours);
  - LB / run analyses, coverage and D66 / L66 findings, EVAL120 analysis;
  - engine findings;
  - experts-vs-iterations and thinking-cap analysis;
  - today's live GPU logs.
- `04_code/`: the SGLang patch module (incl. the #43567 backport), the production E15P notebook (SGLang) and the S1-60K notebook (best LB, vLLM).
