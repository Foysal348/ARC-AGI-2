import numpy as np

def transform(grid: np.ndarray) -> np.ndarray:
    """
    Transformation rule:
    1. Find the main template: the largest solid/complex shape whose interior
       contains empty cells. Its color becomes the output background.
    2. Extract the template pattern inside its bounding box:
         template color -> 1
         other pixels   -> 0
    3. For every other non-background color, extract that object's bounding box,
       downsample it by factor 2, and find the matching empty region in the
       template under one of the 8 dihedral symmetries.
    4. Fill the matching template hole with that object's color.
    5. Return the filled template pattern scaled up by factor 2.
    """

    def bbox_mask(mask):
        rows = np.any(mask, axis=1)
        cols = np.any(mask, axis=0)
        if not np.any(rows) or not np.any(cols):
            return None
        r0 = np.argmax(rows)
        r1 = len(rows) - np.argmax(rows[::-1])
        c0 = np.argmax(cols)
        c1 = len(cols) - np.argmax(cols[::-1])
        return r0, r1, c0, c1

    def downsample_half(mask):
        h, w = mask.shape
        # The examples use clean 2x2 blocks. If the object has an odd border
        # pixel due to parsing, trim it only from right/bottom.
        if h % 2 == 1:
            mask = mask[:-1, :]
            h -= 1
        if w % 2 == 1:
            mask = mask[:, :-1]
            w -= 1
        if h == 0 or w == 0:
            return np.zeros((0, 0), dtype=bool)
        blocks = mask.reshape(h // 2, 2, w // 2, 2)
        return blocks.all(axis=(1, 3))

    def symmetries(pattern):
        res = set()
        p = pattern
        for _ in range(4):
            res.add(tuple(map(tuple, p)))
            res.add(tuple(map(tuple, p.T)))
            p = p[::-1, :]
        return res

    def holes_components(template_pattern):
        # template_pattern: True means empty hole, False means template color.
        h, w = template_pattern.shape
        label = -np.ones((h, w), dtype=int)
        comps = []
        cid = 0
        for i in range(h):
            for j in range(w):
                if template_pattern[i, j] and label[i, j] == -1:
                    stack = [(i, j)]
                    label[i, j] = cid
                    cells = []
                    while stack:
                        r, c = stack.pop()
                        cells.append((r, c))
                        for dr, dc in ((1,0),(-1,0),(0,1),(0,-1)):
                            nr, nc = r + dr, c + dc
                            if 0 <= nr < h and 0 <= nc < w:
                                if template_pattern[nr, nc] and label[nr, nc] == -1:
                                    label[nr, nc] = cid
                                    stack.append((nr, nc))
                    comps.append(cells)
                    cid += 1
        return comps

    def component_pattern(cells):
        if not cells:
            return None
        r0 = min(r for r, _ in cells)
        r1 = max(r for r, _ in cells) + 1
        c0 = min(c for _, c in cells)
        c1 = max(c for _, c in cells) + 1
        pat = np.zeros((r1 - r0, c1 - c0), dtype=bool)
        for r, c in cells:
            pat[r - r0, c - c0] = True
        return pat

    # 1. Find all non-zero colors and their connected components.
    h, w = grid.shape
    colors = set(int(x) for x in grid.flatten() if x != 0)

    components = []
    for color in colors:
        mask = (grid == color)
        visited = np.zeros_like(mask, dtype=bool)
        for i in range(h):
            for j in range(w):
                if mask[i, j] and not visited[i, j]:
                    stack = [(i, j)]
                    visited[i, j] = True
                    cells = []
                    while stack:
                        r, c = stack.pop()
                        cells.append((r, c))
                        for dr, dc in ((1,0),(-1,0),(0,1),(0,-1)):
                            nr, nc = r + dr, c + dc
                            if 0 <= nr < h and 0 <= nc < w:
                                if mask[nr, nc] and not visited[nr, nc]:
                                    visited[nr, nc] = True
                                    stack.append((nr, nc))
                    bb = bbox_mask(np.zeros_like(mask, dtype=bool))
                    # local bbox for this component
                    rr = [r for r, _ in cells]
                    cc = [c for _, c in cells]
                    r0, r1 = min(rr), max(rr)
                    c0, c1 = min(cc), max(cc)
                    area = len(cells)
                    size = (r1 - r0 + 1) * (c1 - c0 + 1)
                    components.append({
                        "color": color,
                        "cells": cells,
                        "bbox": (r0, r1 + 1, c0, c1 + 1),
                        "area": area,
                        "size": size,
                        "mask": np.zeros_like(mask, dtype=bool)
                    })
                    for r, c in cells:
                        components[-1]["mask"][r, c] = True

    # 2. Choose template component: largest by filled area, then bbox size.
    if not components:
        return np.zeros_like(grid)

    comp_sorted = sorted(components, key=lambda x: (x["area"], x["size"]), reverse=True)
    template = None
    for comp in comp_sorted:
        r0, r1, c0, c1 = comp["bbox"]
        box = np.zeros((r1 - r0, c1 - c0), dtype=bool)
        for r, c in comp["cells"]:
            box[r - r0, c - c0] = True
        # A template must have interior holes.
        if np.any(~box):
            template = comp
            break

    if template is None:
        # Fallback: largest component, no holes.
        template = comp_sorted[0]

    tcolor = template["color"]
    r0, r1, c0, c1 = template["bbox"]
    th, tw = r1 - r0, c1 - c0

    template_pattern = np.zeros((th, tw), dtype=bool)
    for r, c in template["cells"]:
        template_pattern[r - r0, c - c0] = True

    hole_mask = ~template_pattern
    hole_comps = holes_components(hole_mask)

    # 3. Match other colors to hole components.
    fill = np.zeros((th, tw), dtype=int)
    used_holes = set()

    # Build candidate object patterns, ignoring the template color.
    object_candidates = []
    for comp in components:
        if comp["color"] == tcolor:
            continue
        # Ignore single-cell noise/distractors that cannot match any multi-cell hole.
        # Keep them only if a 1x1 hole is available and unmatched later.
        r0o, r1o, c0o, c1o = comp["bbox"]
        obj_mask = np.zeros((r1o - r0o, c1o - c0o), dtype=bool)
        for r, c in comp["cells"]:
            obj_mask[r - r0o, c - c0o] = True
        ds = downsample_half(obj_mask)
        if ds.size == 0:
            continue
        object_candidates.append({
            "color": comp["color"],
            "pattern": ds,
            "area": comp["area"],
            "size": comp["size"]
        })

    # Prefer larger objects first to avoid small objects stealing larger holes.
    object_candidates.sort(key=lambda x: (x["area"], x["size"]), reverse=True)

    for obj in object_candidates:
        sym_set = symmetries(obj["pattern"])
        if not sym_set:
            continue
        best = None
        for idx, cells in enumerate(hole_comps):
            if idx in used_holes:
                continue
            pat = component_pattern(cells)
            if pat is None or pat.shape != obj["pattern"].shape:
                continue
            # Check if any symmetry of object pattern equals this hole component.
            if any(np.array_equal(np.array(s, dtype=bool), pat) for s in sym_set):
                score = len(cells) * 10 + obj["area"]
                if best is None or score > best[0]:
                    best = (score, idx, cells)
        if best is not None:
            _, idx, cells = best
            used_holes.add(idx)
            for r, c in cells:
                fill[r, c] = obj["color"]

    # If 1x1 holes remain and singleton candidates exist, match them by color count.
    # This is mostly defensive; examples already have exact shape matches.
    if len(object_candidates) > 0:
        single_objects = [o for o in object_candidates if o["pattern"].shape == (1, 1)]
        single_objects.sort(key=lambda x: (x["area"], x["size"]), reverse=True)
        for idx, cells in enumerate(hole_comps):
            if idx in used_holes or len(cells) != 1:
                continue
            if single_objects:
                r, c = cells[0]
                fill[r, c] = single_objects[0]["color"]
                used_holes.add(idx)
                single_objects.pop(0)

    # 4. Build output: template holes filled, template cells keep template color.
    out = np.full((th * 2, tw * 2), int(tcolor), dtype=int)
    for i in range(th):
        for j in range(tw):
            if fill[i, j] != 0:
                out[2*i:2*i+2, 2*j:2*j+2] = fill[i, j]
            else:
                out[2*i:2*i+2, 2*j:2*j+2] = tcolor

    return out