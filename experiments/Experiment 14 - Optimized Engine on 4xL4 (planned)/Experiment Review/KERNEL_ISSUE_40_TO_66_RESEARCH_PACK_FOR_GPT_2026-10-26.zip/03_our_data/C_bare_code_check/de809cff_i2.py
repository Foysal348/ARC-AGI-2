import numpy as np
from collections import deque

def transform(grid: np.ndarray) -> np.ndarray:
    """
    Transform the grid by converting small, locally enclosed zero holes into
    3x3 blocks of the opposite color, with the hole center(s) marked 8.

    The rule inferred from the examples:
    - There are two object colors (non-zero) and background 0.
    - A zero pixel is a valid hole center when its local 3x3 neighborhood is
      dominated by exactly one object color, while the other object color, if
      present, appears only in the direction where the other global region lies
      (generically encoded by local dominance and bounded zero noise).
    - For each valid center:
        * mark the center as 8;
        * overwrite its 3x3 neighborhood with the opposite object color.
    - Overwrites are applied with priority: 8 > opposite color > original.

    This reproduces the provided examples, including:
      - isolated holes inside a region,
      - small diagonal/horizontal zero clusters,
      - holes near the boundary where the opposite color already appears locally,
      - leaving large background zero regions unchanged.
    """
    grid = np.array(grid, copy=True)
    if grid.size == 0:
        return grid

    h, w = grid.shape

    # Identify the two object colors.
    colors = [int(c) for c in np.unique(grid) if int(c) != 0]
    if len(colors) < 2:
        return grid
    c1, c2 = colors[0], colors[1]
    opposite = {c1: c2, c2: c1}

    # Local condition for a zero cell to be a hole center.
    def is_center(r, c):
        # Must be background.
        if grid[r, c] != 0:
            return False

        counts = {c1: 0, c2: 0}
        zeros = 1  # includes center

        # 3x3 neighborhood, clipped at boundaries.
        for dr in (-1, 0, 1):
            for dc in (-1, 0, 1):
                rr, cc = r + dr, c + dc
                if dr == 0 and dc == 0:
                    continue
                if 0 <= rr < h and 0 <= cc < w:
                    v = int(grid[rr, cc])
                    if v == 0:
                        zeros += 1
                    elif v in counts:
                        counts[v] += 1

        # Need a dominant object color locally.
        if counts[c1] == 0 and counts[c2] == 0:
            return False

        # Large zero neighborhoods are background, not holes.
        # The examples allow small zero clusters but not large open zero areas.
        if zeros > 4:
            return False

        # If one object color dominates, accept.
        # If both appear, require one clear local majority.
        if counts[c1] == counts[c2]:
            return False
        return True

    new_grid = grid.copy()

    # Mark centers first so 8 has priority over color fills.
    centers = []
    for r in range(h):
        for c in range(w):
            if grid[r, c] == 0 and is_center(r, c):
                centers.append((r, c))
                new_grid[r, c] = 8

    # Fill the 3x3 neighborhood of each center with the opposite color.
    # Determine fill color from the local dominant color, falling back to the
    # globally opposite color if the local dominant is ambiguous.
    for r, c in centers:
        counts = {c1: 0, c2: 0}
        for dr in (-1, 0, 1):
            for dc in (-1, 0, 1):
                rr, cc = r + dr, c + dc
                if 0 <= rr < h and 0 <= cc < w:
                    v = int(grid[rr, cc])
                    if v in counts:
                        counts[v] += 1

        if counts[c1] > counts[c2]:
            fill = opposite[c1]
        elif counts[c2] > counts[c1]:
            fill = opposite[c2]
        else:
            # Fallback: use the color that is less common globally near the cell,
            # but this rarely triggers on valid examples.
            fill = c2 if counts[c1] > 0 else c1

        for dr in (-1, 0, 1):
            for dc in (-1, 0, 1):
                rr, cc = r + dr, c + dc
                if 0 <= rr < h and 0 <= cc < w:
                    if new_grid[rr, cc] != 8:
                        new_grid[rr, cc] = fill

    return new_grid