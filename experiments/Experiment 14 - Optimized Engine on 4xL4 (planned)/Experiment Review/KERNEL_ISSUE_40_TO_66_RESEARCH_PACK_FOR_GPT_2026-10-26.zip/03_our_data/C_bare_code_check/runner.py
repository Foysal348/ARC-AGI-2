
import json,sys,numpy as np
src=open(sys.argv[1],encoding="utf-8").read(); task=json.load(open(sys.argv[2])); sol=json.load(open(sys.argv[3]))
ns={}; exec(src,ns); f=ns["transform"]
tr=[ (np.array(f(np.array(p["input"]))).tolist()==p["output"]) for p in task["train"]]
te=[ (np.array(f(np.array(p["input"]))).tolist()==s) for p,s in zip(task["test"],sol)]
print(json.dumps({"train":tr,"test":te}))
