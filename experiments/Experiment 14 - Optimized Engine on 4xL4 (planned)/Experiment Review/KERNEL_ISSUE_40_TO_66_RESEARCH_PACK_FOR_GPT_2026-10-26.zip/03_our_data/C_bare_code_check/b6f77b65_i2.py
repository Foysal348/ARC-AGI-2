import numpy as np
from collections import deque

def transform(grid: np.ndarray) -> np.ndarray:
    """
    Transformation rule:
      1. The first cell (0,0) contains a command color.
      2. Remove every other cell of that command color, keeping (0,0).
      3. The remaining colored objects fall downward as rigid connected
         components.  A component falls as far as possible until some cell
         would leave the grid or collide with a cell that is already fixed.
      4. Components are processed from bottom to top, so lower components
         become fixed first and act as obstacles for higher components.

    This matches the provided examples: the command-colored pieces disappear,
    and the connected structures above/beside them slide downward into the
    vacated space.
    """
    if grid.size == 0:
        return grid.copy()

    out = grid.copy()
    cmd = int(out[0, 0])

    # Keep only the top-left command marker.
    if cmd != 0:
        out[out == cmd] = 0
        out[0, 0] = cmd

    h, w = out.shape

    # Build occupied map for remaining non-background cells.
    occupied = np.zeros((h, w), dtype=bool)
    for r in range(h):
        for c in range(w):
            if out[r, c] != 0:
                occupied[r, c] = True

    # Label connected components of remaining cells (4-connectivity).
    seen = np.zeros((h, w), dtype=bool)
    comps = []

    for r in range(h):
        for c in range(w):
            if occupied[r, c] and not seen[r, c]:
                q = deque([(r, c)])
                seen[r, c] = True
                cells = [(r, c)]
                while q:
                    cr, cc = q.popleft()
                    for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        nr, nc = cr + dr, cc + dc
                        if 0 <= nr < h and 0 <= nc < w:
                            if occupied[nr, nc] and not seen[nr, nc]:
                                seen[nr, nc] = True
                                q.append((nr, nc))
                                cells.append((nr, nc))
                comps.append(cells)

    # Process components from bottom to top.
    comps.sort(key=lambda cells: max(r for r, c in cells), reverse=True)

    result = np.zeros_like(out)
    result[0, 0] = cmd

    for cells in comps:
        min_r = min(r for r, _ in cells)
        max_r = max(r for r, _ in cells)
        height = max_r - min_r + 1

        # Maximum downward shift keeping all cells inside the grid.
        max_shift = h - 1 - max_r

        # Find the farthest shift that does not collide with already fixed cells.
        best = 0
        for s in range(0, max_shift + 1):
            ok = True
            for r, c in cells:
                nr = r + s
                if result[nr, c] != 0:
                    ok = False
                    break
            if ok:
                best = s
            else:
                # Once collision occurs at a smaller shift, larger shifts
                # cannot be valid for rigid movement.
                break

        # Place the component at its new position.
        for r, c in cells:
            nr = r + best
            result[nr, c] = out[r, c]

    return result