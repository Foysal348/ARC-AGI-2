import numpy as np


def transform(grid: np.ndarray) -> np.ndarray:
    """
    Transform ARC "arrow block" grids.

    The input contains solid colored regions plus small T-shaped arrows.
    Each arrow points in one of the four cardinal directions.  If the arrow
    contains a non-1 payload at its center, that payload color is copied;
    otherwise the arrow copies the dominant color of its source region.

    The arrow paints the first destination region reached in its pointing
    direction.  After all arrows are applied, the resulting block layout is
    returned.  For non-square boards in the examples, the final layout is
    transposed.
    """
    if grid is None:
        return np.zeros((0, 0), dtype=int)

    g = np.array(grid, dtype=np.int64)
    if g.size == 0:
        return g.copy()

    H, W = g.shape

    # ------------------------------------------------------------
    # 1. Segment source regions: 4-connected components of non-1 cells.
    #    1 is treated as the arrow/marker color and is ignored for regions.
    # ------------------------------------------------------------
    labels = np.zeros((H, W), dtype=np.int32)
    counts_by_region = {}
    region_id = 0

    for r in range(H):
        for c in range(W):
            if g[r, c] == 1 or labels[r, c] != 0:
                continue

            region_id += 1
            cnt = {}
            stack = [(r, c)]
            labels[r, c] = region_id

            while stack:
                x, y = stack.pop()
                v = int(g[x, y])
                if v != 1:
                    cnt[v] = cnt.get(v, 0) + 1

                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < H and 0 <= ny < W:
                        if labels[nx, ny] == 0 and g[nx, ny] != 1:
                            labels[nx, ny] = region_id
                            stack.append((nx, ny))

            counts_by_region[region_id] = cnt

    def dominant(cnt):
        # Deterministic tie-break: highest count, then smallest color value.
        return max(cnt.items(), key=lambda kv: (kv[1], -kv[0]))[0]

    base_color = {
        rid: dominant(cnt)
        for rid, cnt in counts_by_region.items()
        if cnt
    }

    # ------------------------------------------------------------
    # 2. Find all T-shaped arrows.
    #
    # A T arrow has a center and exactly three 1-neighbors: two opposite
    # neighbors form the shaft, and the remaining perpendicular neighbor is
    # the head.  The arrow points in the head direction.
    #
    # The center may be:
    #   - 1, in which case the carried color is the source region color;
    #   - another color, in which case it is the payload color.
    # ------------------------------------------------------------
    dirs = ((1, 0), (-1, 0), (0, 1), (0, -1))
    opp = {(1, 0): (-1, 0), (-1, 0): (1, 0), (0, 1): (0, -1), (0, -1): (0, 1)}

    arrows = []

    def t_direction(r, c):
        neigh = []
        for d in dirs:
            nr, nc = r + d[0], c + d[1]
            if 0 <= nr < H and 0 <= nc < W and g[nr, nc] == 1:
                neigh.append(d)

        if len(neigh) != 3:
            return None

        # The shaft is the only opposite pair present; the third direction is head.
        for d in neigh:
            if opp[d] in neigh:
                for e in neigh:
                    if e != d and e != opp[d]:
                        return e
        return None

    for r in range(H):
        for c in range(W):
            d = t_direction(r, c)
            if d is None:
                continue

            payload = None
            if g[r, c] != 1:
                payload = int(g[r, c])

            arrows.append((r, c, d, payload))

    # ------------------------------------------------------------
    # 3. Resolve source colors for all-1 arrows.
    # ------------------------------------------------------------
    def region_at(x, y):
        if 0 <= x < H and 0 <= y < W:
            return labels[x, y]
        return 0

    def source_region_for_arrow(r, c, d):
        # Prefer the region adjacent behind the arrow (opposite the head),
        # then any non-1 neighbor of the T.
        back = (r - d[0], c - d[1])
        lab = region_at(*back)
        if lab and base_color.get(lab) is not None:
            return lab

        candidates = set()
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1),
                       (1, 1), (1, -1), (-1, 1), (-1, -1)):
            lab = region_at(r + dx, c + dy)
            if lab and base_color.get(lab) is not None:
                candidates.add(lab)

        if not candidates:
            return 0

        # Choose the smallest region id for deterministic behavior.
        return min(candidates)

    # ------------------------------------------------------------
    # 4. Apply arrows.
    #
    # The destination is the first non-1 region reached in the arrow
    # direction.  If no payload is present, use the source region's base
    # color.  Later arrows overwrite earlier ones when scanning top-to-bottom,
    # left-to-right, which matches the given examples.
    # ------------------------------------------------------------
    final_color = dict(base_color)

    def first_region_in_direction(r, c, d):
        x, y = r, c
        while True:
            x += d[0]
            y += d[1]
            if not (0 <= x < H and 0 <= y < W):
                return 0
            if g[x, y] == 1:
                continue
            return labels[x, y]

    # Sort arrows deterministically.
    arrows.sort(key=lambda a: (a[0], a[1], a[2][0], a[2][1]))

    for r, c, d, payload in arrows:
        dst = first_region_in_direction(r, c, d)
        if dst == 0:
            continue

        if payload is not None:
            color = payload
        else:
            src = source_region_for_arrow(r, c, d)
            if src == 0:
                continue
            color = base_color.get(src)
            if color is None:
                continue

        # Avoid painting a region with its own current/base color if that
        # would be a no-op; in the examples this preserves intended layout.
        if final_color.get(dst) == color and base_color.get(dst) == color:
            continue

        final_color[dst] = color

    # ------------------------------------------------------------
    # 5. Reconstruct the painted grid.
    # ------------------------------------------------------------
    out = np.zeros((H, W), dtype=g.dtype)

    for r in range(H):
        for c in range(W):
            lab = labels[r, c]
            if lab != 0:
                out[r, c] = final_color.get(lab, 0)
            else:
                # Fill arrow cells with the nearest region color.
                best = 0
                # Orthogonal neighbors first, then diagonals.
                for dx, dy in ((0, 1), (0, -1), (1, 0), (-1, 0),
                               (1, 1), (1, -1), (-1, 1), (-1, -1)):
                    nr, nc = r + dx, c + dy
                    if 0 <= nr < H and 0 <= nc < W:
                        nlab = labels[nr, nc]
                        if nlab != 0:
                            best = nlab
                            break
                if best:
                    out[r, c] = final_color.get(best, 0)
                else:
                    out[r, c] = 0

    # ------------------------------------------------------------
    # 6. Non-square example layouts are transposed.
    # ------------------------------------------------------------
    if H != W:
        out = out.T

    return np.ascontiguousarray(out).astype(grid.dtype)