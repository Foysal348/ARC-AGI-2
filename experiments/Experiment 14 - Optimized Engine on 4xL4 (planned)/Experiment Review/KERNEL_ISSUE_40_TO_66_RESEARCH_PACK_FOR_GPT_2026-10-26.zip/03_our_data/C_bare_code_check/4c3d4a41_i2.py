import numpy as np

def transform(grid: np.ndarray) -> np.ndarray:
    """
    Transform the grid as follows:

    1. There is a right-hand panel whose top border is a horizontal run of 5s.
    2. There is a movable 5-colored shape on the left side.
    3. The left shape is erased and moved horizontally into the right panel.
       Its vertical position is preserved.
    4. In the right panel, each column that contains a vertical colored bar
       (colors other than 0 and 5) is rebuilt so that:
       - the bar sits directly above the moved 5-shape in that column;
       - if the bar is taller than the available space above the shape,
         it is truncated;
       - empty cells above the bar are filled with 5;
       - the moved 5-shape cells are drawn as 5.
    5. The fixed frame of the right panel is preserved.
    """
    if grid.ndim != 2:
        return grid

    H, W = grid.shape
    if H < 3 or W < 3:
        return grid

    # Find the right panel from the top border of 5s.
    top_5 = np.where(grid[0] == 5)[0]
    if len(top_5) == 0:
        return grid

    right_start = int(top_5[0])
    right_end = int(top_5[-1])
    if right_end <= right_start:
        return grid

    out = grid.copy()

    # Erase the whole left area.
    out[:, :right_start] = 0

    # Find the movable 5-mask on the left.
    mask_ys, mask_xs = np.where(grid[1:H - 1, :right_start] == 5)
    if len(mask_ys) == 0:
        return out

    mask_top = int(mask_ys.min())
    mask_bottom = int(mask_ys.max())
    mask_left = int(mask_xs.min())
    mask_right = int(mask_xs.max())
    mask_width = mask_right - mask_left + 1

    # Place the mask in the right panel.
    # For the standard 7-wide mask in an 11-wide panel, this puts it at
    # columns right_start+2 through right_start+8.
    panel_width = right_end - right_start + 1
    if mask_width <= panel_width:
        target_left = right_start + (panel_width - mask_width) // 2
    else:
        target_left = right_start

    # Keep the mask inside the panel if possible.
    if target_left < right_start + 1:
        target_left = right_start + 1
    if target_left + mask_width > right_end:
        target_left = max(right_start, right_end - mask_width)

    # Preserve vertical position, but keep it inside the panel if necessary.
    target_ys = mask_ys
    if mask_top < 1:
        target_ys = mask_ys + (1 - mask_top)
    if mask_bottom > H - 2:
        target_ys = mask_ys - (mask_bottom - (H - 2))

    target_xs = mask_xs - mask_left + target_left

    # Active vertical span: from the first interior row to the bottom of the
    # moved mask.  Rows below the mask are left empty.
    top_row = 1
    bottom_row = int(np.max(target_ys))
    if bottom_row > H - 2:
        bottom_row = H - 2

    # Build a map of which rows are occupied by the moved mask in each column.
    mask_cells_by_col = {}
    for y, x in zip(target_ys, target_xs):
        if 1 <= y < H - 1 and right_start < x < right_end:
            mask_cells_by_col.setdefault(int(x), set()).add(int(y))

    # Columns to rebuild are all columns touched by the moved mask.
    track_cols = sorted(mask_cells_by_col.keys())

    for c in track_cols:
        # Clear the interior of this track column.
        out[top_row:H - 1, c] = 0

        # Find the best colored bar in this column from the original grid.
        col = grid[top_row:bottom_row + 1, c]
        n = len(col)

        best_run = None  # (height, lowest_start, color)
        i = 0
        while i < n:
            v = col[i]
            if v == 0 or v == 5:
                i += 1
                continue

            j = i
            while j + 1 < n and col[j + 1] == v:
                j += 1

            height = j - i + 1
            # Prefer the longer run; if tied, prefer the lower run.
            if best_run is None or height > best_run[0] or (height == best_run[0] and i > best_run[1]):
                best_run = (height, i, int(v))

            i = j + 1

        # Determine where the mask starts in this column.
        mask_rows = sorted(mask_cells_by_col[c])
        mask_top_row = mask_rows[0] if mask_rows else bottom_row + 1

        # Space above the mask.
        available = max(0, mask_top_row - top_row)
        bar_height = best_run[0] if best_run is not None else 0
        color = best_run[2] if best_run is not None else 0

        used_height = min(bar_height, available)
        bar_start = mask_top_row - used_height

        # Fill empty space above the bar with 5.
        if bar_start > top_row:
            out[top_row:bar_start, c] = 5

        # Draw the colored bar immediately above the mask.
        if used_height > 0:
            out[bar_start:mask_top_row, c] = color

        # Draw the exact moved mask cells.
        for y in mask_rows:
            if top_row <= y < H - 1:
                out[y, c] = 5

    return out