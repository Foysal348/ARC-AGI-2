# Q27-AGENT v1.9.0 validation → v1.9.1 (2026-10-12)

GPT built v1.9.0: `Q27_AGENT_v1_9_0_SYNTH_MICROPROBE.ipynb`, sha256 5853667f…. Claude validated it against the v1.9 plan and the Experiment 4 gates, then fixed what it found in v1.9.1. The v1.9.0 notebook itself is unchanged.

**v1.9.1:** `Experiment Notebooks/Q27_AGENT_v1_9_1_SYNTH_EVAL12.ipynb`, sha256 cd5c69da….
- Builder: `Experiment Notebooks/Build/Q27A_v19_build/build_notebook.py`, which is GPT's builder plus a v1.9.1 section.

## 1. What v1.9.0 got right (checked in code)

**Request design**
- No tools and no named `tool_choice`. One plain chat request per task: xhigh, `thinking_token_budget` 49,152, `max_tokens` 57,344.
- No effort ladder and no forced submit. `strict_payload` raises on any other budget.

**Fail-closed behaviour**
- If the prompt + 57,344 tokens would not fit the context, the task gets `context_too_large`. The budget is never silently reduced.
  - All EVAL12 prompts are only 2.9–9.9 kB, so none comes close.
- If the server rejects the thinking budget, the task gets `budget_rejected`. It never falls back to a request without a budget.

**Program handling**
- Extraction is strict: the last ```python block with a top-level `transform`. A source guard covers `os`, `sys`, `subprocess`, `ctypes`, `open`, `eval`, `exec` and more.
- If no program comes back, there is at most one no-thinking "commit" request. It does not cut thinking: it runs after the full 49k.

**Evaluation and merge**
- Solutions are loaded only after every program has run.
- The merge uses recorded DIRECT run 7 (LB 26.94): attempt_1 = DIRECT, attempt_2 = the verified program.

**Server and hidden run**
- The server ladder keeps rung 0 (MTP ×3, fp8 KV) and drops the rung without `--reasoning-config`.
- The hidden-test path is DIRECT-only.

**Results on our side**
- GPT's 12 unit tests: OK.
- A rebuild from GPT's builder gives cell-for-cell identical code. Only the serialization differs.

## 2. Findings and fixes

| # | Finding in v1.9.0 | Effect | v1.9.1 fix |
|---|---|---|---|
| F1 | `official_score_pct` and `agent_only_official_pct` / `direct_only_official_pct` are the **task average** (`agent.score`). Kaggle's metric, used in v1.7–v1.8.3, is correct outputs ÷ all outputs. | On EVAL12 (12 tasks, 22 outputs) recorded DIRECT shows **16.67 %** where the real value is **13.64 %** (3/22). Agent numbers would not be comparable with run 4. | Official = micro (`query_hits / test_outputs`). The task averages are kept as `*_task_macro_pct`. |
| F2 | `_request` retries transient errors **including timeouts** (`code None`) with the same timeout, which equals the remaining time. | A hung request can run up to 2× past the deadline. | A timeout is never retried (new status `request_timeout`). A 5xx/429 retry gets only the time left before the deadline and is skipped if under 60 s. |
| F3 | The hidden-run DIRECT path (v1.8.3 rescue) keeps `rescue_min_think: 4096`. `time_budget()` can start DIRECT requests with **4,096–49,151 thinking** near the deadline, and `check_config` does not cover `rescue_*`. | Breaks the rule: no thinking budget below 49,152 anywhere without approval. | `rescue_min_think = 49152`: a request gets the full 49,152 or is not started. `check_config` rejects `rescue_think` ≠ 49152, `rescue_answer` ≠ 8192, `rescue_min_think` < 49152 and `rescue_effort` ≠ xhigh. |
| F4 | Thinking tokens were not measured. `usage.completion_tokens_details.reasoning_tokens` is usually empty on vLLM 0.19, so `think_tokens` = None. | We cannot tell whether a program came from thinking that ended naturally or from thinking cut at the 49,152 cap, which is the key question for Phase 3. | `think_tokens` = completion − tokens(content), counted exactly via `/tokenize`. Also records `think_source`, `think_hit_budget`, `reasoning_chars`, `request_wall_s`, and a per-task `think` table in `eval_report.json`. |
| F5 | The default was the 3-task probe with a 1.5 h eval deadline. The user chose EVAL12 directly. | Three tasks give too little evidence for about the same GPU setup cost. | Default = **EVAL12**, eval deadline 2.0 h. The 3-task probe is still available through `Q27A_EVAL_TASKS`. |
| F6 | The v1.8.3 DRYCHECK cell (`dryrun_report.json`) was dropped. | The Kaggle CPU DRYRUN gate had nothing to assert, and our notebook harness failed on it. | New v1.9.1 DRYCHECK cell with **17 checks** (listed below). |
| F7 | Launcher left-overs: `min_agent_s` set twice (3600, then 1200), stale v1.8.3 comments, unused `agent_frac`, report keys that no longer exist. | Cosmetic, but misleading. | Cleaned. |
| F8 | pyflakes: unused `Path` in `submit_main_v19.py` and unused `e` in `synth.py`. | The static gate failed. | Fixed. |

The 17 DRYCHECK checks:
- budget contract 49,152 / 57,344 / xhigh / no tools;
- official score is micro;
- one attempt record per task;
- known statuses only;
- thinking accounting recorded;
- schema of the eval submission and of `submission.json`;
- the launched cfg passes `check_config`;
- negative controls: `rescue_min_think` 4096, `synth_think` 6144, `repair_turns` 1 and forced submit are all rejected;
- EVAL12 is the default.

## 3. Gates run on v1.9.1 (local, CPU)

| Gate | Result |
|---|---|
| `check_static.py` (ast + pyflakes, every cell) | **PASS** (v1.9.0 FAILED on F8) |
| Unit tests `tests/test_v19.py` | **17/17 OK**: GPT's 12 plus 5 new (F1, F2 ×2, F3, F4) |
| Whole-notebook execution, `run_notebook_dryrun_local.py` (every cell in order, fake server, real EVAL12 IDs) | **PASS**, DRYCHECK **17/17** |

In that run, recorded DIRECT on EVAL12 gives 3/22 = 13.64 % official, which matches the recorded run 7.

## 4. Not covered (needs a real GPU run)

- How well Qwen writes programs.
- Real thinking lengths and the real `/tokenize` response.
- vLLM behaviour at 12 concurrent 57k-token requests.

Expected KV use: about 12 × 65k ≈ 0.8M of about 1.0M effective, which fits. Run 4 peaked at 31 % with up to 16 agent streams.

## 5. Kaggle CPU DRYRUN (2026-10-12)

**Run:** `foysalemonshanto/q27-agent-dryrun` v4 (no GPU, so the DRYRUN path ran). Pinned docker image; competition data only. Status COMPLETE.

**Results:**
- **DRYCHECK 17/17 PASS.**
- `agent_server_report.json`:
  - `budget_contract_pass` true, no error;
  - request contract: `thinking_token_budget` 49,152, `max_tokens_full` 57,344, `effort` xhigh, `tool_choice` null.
- EVAL12 path, 12 tasks / 22 outputs:
  - 12 attempt records;
  - the fake server returns a program that fails training, so every task is `train_mismatch` (expected);
  - recorded DIRECT **3/22 = 13.64 % official (micro)**, task macro 16.67 %, the same as the local run.
- `submission.json`: 240 hidden-file tasks, valid full schema.
- The log shows the synthesis lines twice. That is Kaggle's log capture of the subprocess output; `attempts.jsonl` has exactly 12 records.

**Outputs:** `Experiment Results/Kaggle Runs/DRYRUN v1.9.1 (foysal v4)/`. The zip contains the reports and the log.
