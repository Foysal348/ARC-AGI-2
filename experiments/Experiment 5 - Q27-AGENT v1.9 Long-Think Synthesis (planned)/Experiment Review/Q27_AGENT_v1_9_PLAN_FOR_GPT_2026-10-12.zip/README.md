# Q27-AGENT v1.9 — full implementation plan for review (2026-10-12)

Please validate this plan **before we write code**. It implements the architecture you proposed in your root-cause audit of the v1.8.3 GPU EVAL12 run: **Long-Think → Program → Verify → Repair**. The user has chosen that architecture.

We need, for each section: *agree / change / drop*, plus anything missing that would waste the next GPU run. Every number here was measured, unless it is marked **TBD** or **estimate**.

Reference files in this zip:
- `reference/AGENT_Q27-AGENT-v1_8_3_as_run.ipynb`: the code being changed.
- `reference/make_q27_agent.py`: the builder.
- `reference/eval12_v1_8_3_summary.json` and `reference/eval12_per_attempt_table.md`: the failed run.
- `reference/source_madarshbb_agent.ipynb`: the public notebook the agent package came from.

## 0. Why v1.9 — the evidence (GPU EVAL12, v1.8.3, 2026-10-12)

**Result:** the agent scored 0/22 against DIRECT's 3/22 (the recorded LB-26.94 pipeline). The infrastructure was healthy:
- server ready in 510 s;
- MTP×3 acceptance 0.736;
- KV peak 31%, 0 preemptions;
- 256 tok/s.

**Failure chain**, verified against the code and `attempts.jsonl`:
1. **The model never submitted on its own.** Every one of the 82 submits came from a forced (named `tool_choice`) turn.
2. **Forced submits carried no program.** 59 had empty `code`. The empty-code path does not update `python_at_submit`, so the next turn is forced again: an infinite loop, up to 10 empty submits in a row.
3. **The rest were not programs either.** 22 forced submits carried exploration code (uses `train`); they were rejected as nonportable. Only 1 program reached verification, and it scored 0/2.
4. **HTTP 500 killed 5 of 24 attempts.** vLLM 0.19.0 `assert content is not None` in `_parse_tool_calls_from_content`. All 5 happened on forced (named tool-choice) turns.
5. **Thinking was too short and too shallow.** Each turn was capped at 6,144 thinking tokens, and the effort ladder stepped down in 22 of 24 attempts (13 of them down to low).
   - DIRECT's correct answers needed 25.9k, 36.8k and 49.2k (forced) continuous thinking.
   - In 191 python snippets, 63 define functions; none defines `transform`.

**The source notebook told the same story.** `madarshbb/arc-qwen-3-8-27b-agent`:
- its own submitted config is `mode: "direct"` (40,960 thinking, temperature 1.0);
- its code comments record "probe24: every failed attempt … never submitted";
- "mini2arm: the text nudge was read and ignored" (which is why forced submit was added as an experiment).

## 1. Goals, non-goals, constraints

**Goal:** produce real, train-verified `transform(grid)` programs with Qwen3.8-27B, and measure whether they add correct test outputs on top of DIRECT, the LB-26.94 method.

**Non-goals for v1.9:**
- No change to the DIRECT method.
- No hidden-run split decision. That comes after measurement.

**Hard constraints:**
- **Model, stack and hardware:** Qwen3.8-27B-FP8, vLLM 0.19.0 (offline wheelhouse + transformers overlay), 4×L4. The server is proven: rung 0 is MTP×3, fp8 KV, prefix cache, `--reasoning-config`. Effective KV is about 1.0M tokens (12.63× at 81,920).
- **Effort and budget:** `reasoning_effort` ∈ {xhigh, medium, low}. `thinking_token_budget` works server-side.
- **User rule:** no thinking budget below the LB base (49,152 continuous thinking tokens) without explicit user approval of that specific value. A static gate enforces this (§6.2).
- **Notebook shape:** dual mode. A commit run is a measurement; a competition rerun writes the full-schema `submission.json`.
  - Agent stops at 11:35; the process is cut at 11:50; the validator runs last.
- **Submissions:** one pending submission at a time; scoring takes about 1.5–2 days; deadline 2026-11-02.

**Context budget (measured):**
- Prompt sizes with the v1.4 rendering: EVAL12 median 4,072 tokens and max 7,464 (real tokenizer, run 7 records). The whole evaluation set reaches about 15k at most; the test placeholder about 13k at most.
- Phase 1 maximum output is 49,152 + 8,192 = 57,344. 15k + 57,344 = 72.3k, below `max_model_len` 81,920.
- A prompt above 24k tokens would not fit. The rule for that case is in §2.1.

## 2. Architecture

```
per task:
  Phase 1  LONG-THINK SYNTHESIS   (1 request, no tools, xhigh, 49,152 think + 8,192 answer)
     |      reply = reasoning + ONE ```python block with transform(grid)
     v
  Phase 2  VERIFY                 (deterministic sandbox, every train pair, no LLM tokens)
     |-- verified (all pairs exact) ----------------> candidate(s) saved, task done
     |-- rejected / no program / nonportable -------> Phase 3 (if budget + time allow)
     v
  Phase 3  REPAIR                 (budget TBD by the user, see §2.3)
           previous program + exact cell diff + REPL (python tool, auto-verify, no forced submit)
           -> corrected program -> Phase 2 again
```

### 2.1 Phase 1: long-think synthesis (new: `synth.py` or `repl_agent.long_code_synthesis`)

**Request:** one plain chat request with **no tools, no `tool_choice`**. This removes both the forced-submit loop and the vLLM 500 path.

**Prompt:**
- The DIRECT v1.4 task rendering (space-separated grids, all train pairs, all test inputs). This is proven on this model.
- Plus the program instruction:

  > "Work out the rule, check it mentally on every example, then output exactly one ```python fenced block containing a complete program that defines `transform(grid) -> grid` (a list of lists of ints). It must compute the output from `grid` alone; no access to the examples, no printing, no files. Constants and helper functions inside the block are fine."

- **No system prompt.** DIRECT v1.4 used none; keep parity. Open question for you.

**Sampling and limits:**
- `chat_template_kwargs={"reasoning_effort": "xhigh"}`.
- `thinking_token_budget=49152`, `max_tokens=57344`.
- temperature 0.6, top_p 0.95, top_k 20 (DIRECT's sampling).

**Granularity:** one request per **task**, since a program covers all test inputs. Its test outputs come from running the program.

**Parsing:** the last ```python block (DIRECT's fence regex), then an AST check:
- a top-level `def transform` exists;
- `repl.tool_only_globals()` is empty;
- otherwise the result is `no_program` or `nonportable`.

**If thinking is cut without an answer** (finish = length, no code): one no-thinking commit call with the reasoning tail. This is the same mechanism as the DIRECT rescue, with commit tokens of 8,192.

**Context guard:**
- If `prompt_tokens + 57,344 > 81,920 − 512`, then `max_tokens` shrinks and the thinking budget is reduced to fit.
- **This is a cut below base.** It only happens for prompts above about 24k tokens (none in EVAL12) and is listed for the user's approval.

**HTTP 500 on this path:**
- Not expected, because there are no tools.
- If it happens: classify it, retry once after a 10 s backoff, then mark the request `request_error`. Usage is recorded as unknown; there is no fake success.

### 2.2 Phase 2: verify (reuse)

- `repl_agent.verify(code, task)`: run in the sandbox on all train inputs plus the test inputs, with the existing guard (audit hook, fail-closed) and the nonportable check.
- Records: `n_ok / n_train`, the cell diff per failed pair (existing feedback), test outputs.
- Verified means all train pairs are exact; that program's test outputs are the agent candidates.

### 2.3 Phase 3: repair — **budget TBD (user decision; we ask your recommendation)**

**Input:**
- the previous program;
- the verification feedback (exact cell diff per failed pair, existing format);
- the task rendering;
- *no* earlier reasoning, which avoids context blow-up. Option: `preserve_thinking` / `keep_reasoning`, which exists in the source code, defaults off, and is untested on the server.

**Tools:**
- `python` (REPL, preloaded arrays, retained functions).
- **Auto-verify:** any python snippet that defines a top-level, portable `def transform` is verified automatically. A `submit` tool remains available, but it is **never forced**.
- No named `tool_choice` anywhere.

**Effort:** xhigh, with **no effort ladder** (you advised dropping automatic xhigh → low).

**Turn and budget options for you to rank:**
- (a) up to 2 repair turns × 49,152 thinking each. This is base-compliant but expensive: a task could reach about 170k tokens.
- (b) up to 2 turns × 16,384 thinking. Below base, needs user approval.
- (c) 1 turn × 49,152.
- (d) no repair in v1.9 (Phase 1 + 2 only) for the first measurement.

**Our current preference:** (d) for the GPU microprobe, so the measurement is clean, then (c).

**Loop safety:**
- every repair turn must yield a program or a python call;
- two consecutive turns without either end the attempt;
- empty `code` is never counted as progress;
- there is no force counter at all.

### 2.4 Candidates and merge with DIRECT

- **Commit run (EVAL12):** DIRECT comes from the recorded run-7 answers, as in v1.8.3. Report:
  - agent-only;
  - DIRECT-only;
  - merged (deployed policy);
  - complementarity;
  - verified-but-wrong.
- **Merge policy** (your "safe" proposal): **attempt_1 = DIRECT's answer** when one exists, **attempt_2 = the verified program's output**. A verified program that is not covered by a DIRECT answer becomes attempt_1. Unverified programs are not used when a DIRECT answer exists. Please confirm, or prefer verified-first.
- **Hidden rerun:** not part of v1.9. It stays DIRECT-only (`agent_disabled`) until a measurement shows a net gain.

### 2.5 Scheduling and time (estimates from measured speeds)

- Phase 1 per task is about 57k tokens at worst. EVAL12 = 12 tasks ≈ 690k tokens. At about 260 tok/s aggregate (16 concurrent, measured) that is **≈ 45 min**, plus about 13 min setup.
- Phase 3 (if enabled): option (c) adds up to about 590k tokens on EVAL12, ≈ 38 min.
- Concurrency 16. `max_num_seqs` 16 is unchanged; KV peak was 31% for the agent and 59.5% for DIRECT at 16.

## 3. What is removed or changed vs v1.8.3

| Item | v1.8.3 | v1.9 |
|---|---|---|
| Forced submit (`force_submit_after`, named `tool_choice`) | on (5) | **removed** (code path deleted, config key rejected by the gate) |
| Per-turn thinking | 6,144 | Phase 1: **49,152**; Phase 3: TBD |
| Effort ladder | medium → low | **removed** |
| Attempt caps 24k / 36k, two attempts | yes | replaced by Phase 1 (+ optional Phase 3) |
| Primary output channel | `submit` tool call | plain-text fenced program |
| HTTP error handling | any error ends the attempt | classified; one retry for transient errors; parser-assert path removed by design |
| Repeated empty-code loop | possible | impossible (no force counter; empty code ≠ progress) |
| Smoke / e2e | tool roundtrip | **plus a synthesis probe**: an xhigh plain-text program on a tiny task must parse and verify, with the request carrying 49,152 / 57,344 |
| DIRECT rescue, guard, DRYRUN, metrics sampler, static gate, GPU-path test | — | kept unchanged |

## 4. Module-level changes

1. **`synth.py` (new):**
   - `build_synthesis_prompt(task)` (reuses `rescue.build_user_message` rendering, extended to all test inputs);
   - `extract_program(text)`;
   - `synthesize(client, task, deadline, budgets)`, returning `{status, code, gen_tokens, finish, think_tokens}`;
   - `repair(...)` (if enabled).
2. **`repl_agent.py`:**
   - delete the force logic and the effort ladder from the run loop (or keep them unreachable behind a hard `False`);
   - add an auto-verify hook for python snippets defining `transform`.
3. **`run_eval.py`:**
   - stage = synthesis (+ repair) instead of `solve_repl`;
   - same report schema, plus:
     - `synthesis_status_counts` (verified / rejected / no_program / nonportable / request_error / cut);
     - `think_tokens` distribution;
     - `natural_close` rate;
     - per-task program and diff.
4. **`submit_main.py`:**
   - smoke gains the synthesis probe;
   - e2e = synthesis probe (no tools);
   - the existing tool smoke stays only if repair uses tools.
5. **`client.py`:** HTTP-error classification (`transient` / `parser_assert` / `bad_request`); a single bounded retry for transient errors.
6. **Launcher cfg (v1.9 keys):**
   - `agent_mode: "synth"`;
   - `synth_think: 49152`, `synth_answer: 8192`, `synth_commit_tokens: 8192`;
   - `repair_turns: 0` (TBD), `repair_think: TBD`;
   - `merge: "direct_first"`;
   - forced-submit keys absent.
7. **`check_config.py` (new static gate):** parses the launcher's real cfg.
   - **Fails** if any thinking budget is below 49,152 unless it is listed in `approved_below_base: {key: value}`. That list comes from the user and is printed in the push summary.
   - Fails if `force_submit_after` or a named `tool_choice` appears.

## 5. Tests (CPU, before any push)

**Your T1–T10:**

| Test | What it checks |
|---|---|
| T1 | Five python calls never trigger a named submit; no request contains `tool_choice` as an object |
| T2 | An empty program response creates no loop; the attempt ends cleanly |
| T3 | A known parser-500 is not re-sent in the same mode |
| T4 | The Phase 1 request carries 49,152 / 57,344 and xhigh |
| T5 | A valid `transform` verifies all pairs |
| T6 | Exploration code with `train` is rejected; no false verified |
| T7 | Verification failure → repair prompt contains the program and diff (if repair is enabled) |
| T8 | Merge keeps DIRECT's correct attempt_1 |
| T9 | Context guard: a prompt of 30k tokens is handled (shrink + flagged); no overshoot |
| T10 | Interruption keeps completed outputs (atomic records) |

**Additional tests:**

| Test | What it checks |
|---|---|
| T11 | `check_config` fails on 6,144, on `force_submit_after`, and on a named `tool_choice`, and passes with an approved list |
| T12 | Synthesis probe in smoke: a fake-server plain-text program parses and verifies; a reply without a fence → `no_program` |
| T13 | `test_gpu_path_local`: the real `submit_main.main()` path in synth mode |
| T14 | Notebook local dryrun (all cells) and Kaggle CPU DRYRUN |
| T15 | Replay of v1.8.3's failing transcripts through the new harness shows none of the three failure modes |

## 6. GPU validation sequence (each step needs the user's approval)

1. **Kaggle CPU DRYRUN** (free).
2. **GPU EVAL12 directly (Phase 1 only), no separate 3-task probe** (the user's point, accepted). All tasks run concurrently (16 slots), so 12 tasks cost only about 18 min more than 3. Estimates from measured speeds: about 40–44 tok/s single-stream (e2e probe), about 17 tok/s per stream at 16 concurrent (run 7).
   - 3 tasks: about 25 min Phase 1 + 13 min setup, about 40 min in total.
   - 12 tasks: about 45 min + 13 min, about 58 min in total.
   - EVAL12 gives 4× the data and a direct comparison with DIRECT's 3/22.
   - **Early-abort gate in code:** if each of the first 4 finished tasks ends `no_program`, `nonportable` or `request_error`, the stage stops and writes the report (`SYNTH_NO_GO`). So a fundamentally broken run costs about 25–30 min, not the full run.
   - Report: agent-only and merged hits, verified-but-wrong, agent-only unique hits vs DIRECT, tokens per verified program, `natural_close` rate, synthesis status counts.
3. **Phase 3 (repair)** in a second EVAL12 run, only after Phase 1 shows real programs, with the budget the user approves.
4. **Hidden-rerun design:** only after step 3, and with your review again.

## 7. Track A (DIRECT, in parallel, separate notebook; for your opinion)

v1.4.4 already has MTP×3, prefix cache and admission until 11:34 with a drain. A candidate lever: **concurrency above 16**.
- KV is 1.35M on the offline engine; peak usage was 59.5% at 16.
- L4 decoding is memory-bound, so a larger batch may raise aggregate tok/s, which means more queries finished in 12 h.
- Needs a throughput measurement (16 vs 20 vs 24) before any submission. Is this the right next DIRECT experiment?

## 8. Questions for you

1. Phase 3 budget: which of (a)–(d), and the turn limit?
2. Phase 1: one request per task (program) or per test input? Should the prompt include all test inputs?
3. System prompt: none (DIRECT parity) or a short program-writing system message?
4. `preserve_thinking` / `keep_reasoning` in repair: worth testing on vLLM 0.19 with `qwen3`?
5. Merge: direct-first (§2.4) or verified-first?
6. Samples: one Phase 1 sample per task, or two with temperature diversity (doubles the cost)?
7. Anything in §4–§6 that would still let the GPU run end without a measurement?
