"""Deterministic, source-controlled builder. Base notebook is provided reference.
Run: python build_notebook.py
"""
from pathlib import Path
import json
import hashlib
import nbformat

ROOT = Path(__file__).resolve().parent
BASE = ROOT/'reference'/'AGENT_Q27-AGENT-v1_8_3_as_run.ipynb'
OUT = ROOT/'Q27_AGENT_v1_9_0_SYNTH_MICROPROBE.ipynb'
base = nbformat.read(BASE,as_version=4)

base.cells[0].source = '''# Q27-AGENT v1.9.0 — Long-Think → Program → Verify (Phase 1+2 only)

**Purpose:** real-GPU microprobe of Qwen3.8-27B-FP8 synthesizing standalone ARC `transform(grid)` programs.

- Inherits v1.8.3 Kaggle offline wheelhouse, 4× L4, MTP3, FP8 KV, prefix-cache, startup ladder and full-schema fallback submission.
- Phase 1: one no-tools chat completion / task, **xhigh / thinking_token_budget = 49,152 / max_tokens = 57,344**. No effort ladder, no forced named tool.
- Phase 2: standalone Python AST check + sandbox verify on every train/test input. **0 repair turns.**
- EVAL uses **recorded DIRECT v1.4.4 Run 7** (LB 26.94), not live DIRECT. Only EVAL challenge files are inputs to the model; solutions are read for reporting after inference.
- Competition rerun remains **DIRECT-only** until results demonstrate the new AGENT has incremental value. Notebook writes a valid fallback immediately.
- `Q27A_EVAL_TASKS=136b0064,247ef758,2b83f449` (default) for the first 3-task probe; `Q27A_EVAL_TASKS=eval12` for the full evaluation.
- `Q27A_DRYRUN=1` activates fake-server CPU plumbing checks; fake-server verification DOES NOT imply Qwen accuracy.
- Never lower the synthesis thinking budget silently. If 49,152+8,192 won't fit context, skip with an explicit `context_too_large` status.

**Safety and validity:** executing model-generated Python involves security risks. The inherited Python audit hook is not a full OS security boundary; keep solution labels isolated from inference where possible. No guarantee of bug-free GPU behavior until the Kaggle real-server probe is run.

**Expected outputs:** `/kaggle/working/agent_eval/eval_report.json`, `attempts.jsonl`, `progress.json`, `eval_submission.json`, `server_metrics.json` and `/kaggle/working/agent_server_report.json`.

**Research reference:** [gutfeeling/arc-agi-2-submission](https://github.com/gutfeeling/arc-agi-2-submission) (architecture inspiration, different model/backend). vLLM documentation: [reasoning budget](https://docs.vllm.ai/en/v0.19.1/features/reasoning_outputs/).
'''

# Replace the inherited fake-server emulator and telemetry parser with their
# v1.9 fixes; otherwise the whole-notebook CPU run would test stale files.
base.cells[14].source = '%%writefile /kaggle/working/agent/fake_vllm.py\n' + (ROOT/'modules'/'fake_vllm.py').read_text()
base.cells[12].source = '%%writefile /kaggle/working/agent/rescue.py\n' + (ROOT/'modules'/'rescue.py').read_text()
base.cells[10].source = '%%writefile /kaggle/working/agent/run_submit.py\n' + (ROOT/'modules'/'run_submit.py').read_text()
sources = ['synth.py','run_eval_v19.py','check_config.py','submit_main_v19.py']
extra=[]
for name in sources:
    contents=(ROOT/'modules'/name).read_text()
    cell=nbformat.v4.new_code_cell(f'%%writefile /kaggle/working/agent/{name}\n'+contents)
    extra.append(cell)

launch = base.cells[16].source
start = launch.index('AGENT = json.loads(r"""')
end = launch.index('\ncfg = dict(SERVER, **AGENT)', start)
conf = {
 'agent_mode':'synth', 'concurrency':16, 'temperature':0.6, 'top_p':0.95,
 'top_k':20, 'template_kwargs':{'reasoning_effort':'xhigh'},'thinking':True,
 'synth_think':49152, 'synth_answer':8192,'repair_turns':0,'synth_commit':True,
 'max_model_len':81920, 'max_num_batched_tokens':4096,
 'request_margin_s':10,'commit_min_remaining_s':120,
 'sandbox_timeout_s':10,'metrics_every_s':30,
 'eval_direct':'ref','eval_direct_run':'run7','rescue':True,
 'rescue_all':True,'rescue_effort':'xhigh','rescue_think':49152,
 'rescue_answer':8192,'rescue_commit_tokens':8192,'rescue_temperature':0.6,
 'rescue_min_start_s':300,'rescue_concurrency':16,'rescue_stream_tok_s':15.0,
 'rescue_answer_reserve_tokens':4096,'rescue_overhead_s':120,
 'rescue_min_think':4096,'rescue_kv_throttle':0.95,
 'rescue_finish_extra_s':480,
}
launch = launch[:start] + 'AGENT = json.loads(r"""'+json.dumps(conf)+'""")' + launch[end:]
launch = launch.replace('"eval12").strip()', '"136b0064,247ef758,2b83f449").strip()')
# Replace old agent-specific smoke/timeout defaults with v1.9 budget-safe gates.
launch = launch.replace('cfg["e2e_max_s"] = 300', 'cfg["request_timeout_s"] = 7200')
launch = launch.replace('cfg["e2e_extend_s"] = 600', 'cfg["min_agent_s"] = 1200')
launch = launch.replace('cfg.update(eval=True, deadline_epoch=START + EVAL_HOURS * 3600, min_agent_s=1800,',
                        'cfg.update(eval=True, deadline_epoch=START + EVAL_HOURS * 3600, min_agent_s=600,')
launch = launch.replace('cfg.update(dryrun=True, deadline_epoch=time.time() + 20 * 60, min_agent_s=60, e2e_reserve_s=60, e2e_max_s=120,\n               e2e_min_s=10, eval_direct="live", rescue_all=True, rescue_min_start_s=5, install_timeout_s=60)',
                        'cfg.update(dryrun=True, deadline_epoch=time.time() + 12 * 60, min_agent_s=30,\n               eval_direct="ref", rescue_all=True, install_timeout_s=60)')
launch = launch.replace('"/kaggle/working/agent/submit_main.py"','"/kaggle/working/agent/submit_main_v19.py"')
# Remove the second CPU dryrun which would spend another 15 mins loading a server.
pos=launch.find('if DRYRUN:                                   # v1.8: the hidden-test path too')
end2=launch.find('for _p in ("/kaggle/working/agent_server_report.json"',pos)
if pos!=-1 and end2!=-1:
    launch=launch[:pos]+'# v1.9: no second dryrun; DIRECT-only hidden path tested separately.\n'+launch[end2:]
# replace old report keys with new concise ones
launch=launch.replace('"official_score_pct", "query_hits", "queries", "task_macro_score_pct",',
                      '"official_score_pct", "query_hits", "test_outputs", "task_macro_score_pct",')
base.cells[16].source = launch
base.cells = base.cells[:16] + extra + base.cells[16:18]
# Avoid inheriting the old DRYRUN post-flight assertions tied to forced submit.
for cell in base.cells:
    if cell.cell_type=='code':
        cell.outputs=[]
        cell.execution_count=None
for i,cell in enumerate(base.cells):
    cell.id = f'q27-v19-{i:02d}'
nbformat.validate(base)
nbformat.write(base,OUT)
print('FILE',OUT,'BYTES',OUT.stat().st_size,'SHA256',hashlib.sha256(OUT.read_bytes()).hexdigest())
