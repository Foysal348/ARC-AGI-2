import json,ast,hashlib,tempfile,os,sys,types,importlib.util,time,pathlib,traceback,random
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
BASE=ROOT/'source'/'Q27-XHIGH-v1_4_4.ipynb'
NEW=ROOT/'Q27_XHIGH_v1_4_4_E7_CODEX_ORDERING_KV.ipynb'
raw=json.loads(NEW.read_text()); base=json.loads(BASE.read_text())
checks=[]
def check(name,fn):
 try:
  fn();checks.append({'name':name,'status':'PASS'});print('PASS',name)
 except Exception as e:
  checks.append({'name':name,'status':'FAIL','error':repr(e)});print('FAIL',name,repr(e));traceback.print_exc()
def assert_equal(x,y):assert x==y,(x,y)

def syntax():
 import nbformat
 nb=nbformat.read(str(NEW),as_version=4); nbformat.validate(nb)
 for c in nb.cells:
  if c.cell_type=='code': ast.parse(c.source)
check('notebook-valid-and-all-code-parse',syntax)

def base_bytes():
 assert hashlib.sha256(BASE.read_bytes()).hexdigest()=='959959806170960c665249362fe74bfb5678708b0183976ea58e05535d5fd56e'
 assert ''.join(base['cells'][4]['source']).count('UNIT_INDEX = {u: i for i, u in enumerate(UNITS)}')==1
check('base-immutable-and-seeds-frozen',base_bytes)

def parity():
 s=(ROOT/'donor_get_puzzle_priority.py').read_text().split('import numpy as np\n\n',1)[1]
 donor=''.join(json.loads((ROOT/'source'/'arc-2026d-with-codex (24)(1).ipynb').read_text())['cells'][6]['source']).removeprefix('%%writefile starter.py\n')
 a=ast.parse(donor);f=next(n for n in a.body if isinstance(n,ast.FunctionDef) and n.name=='get_puzzle_priority')
 donor_func='\n'.join(donor.splitlines()[f.lineno-1:f.end_lineno])+'\n'
 assert donor_func==s
 new_source=''.join(raw['cells'][4]['source'])
 assert donor_func in new_source
 assert hashlib.sha256(donor_func.encode()).hexdigest()=='3f6536e80d445389da50ed61b3c4b80edc05ff25989aa1ecf7fdef0626196230'
check('codex-function-source-exact-parity',parity)

def priority_ties():
 import numpy as np
 g=globals()
 exec((ROOT/'donor_get_puzzle_priority.py').read_text(),g)
 pri=g['get_puzzle_priority']
 a={'train':[{'input':[[0,0],[0,0]],'output':[[0,0],[0,0]]}], 'test':[{'input':[[0]]}]}
 b={'train':[{'input':[[1,1],[1,1]],'output':[[1,1],[1,1]]}], 'test':[{'input':[[1]]}]}
 c={'train':[{'input':[[2]*25 for _ in range(25)],'output':[[2]*25 for _ in range(25)]}], 'test':[{'input':[[2]]}]}
 full={'z':a,'a':b,'c':c}
 order=sorted(full, key=lambda k:pri(k,full))
 assert order[:2]==['z','a']
 selected={'a','c'}
 assert [k for k in order if k in selected]==['a','c']
 assert priority_tie_from_snippet(raw)
def priority_tie_from_snippet(nb):
 s=''.join(nb['cells'][4]['source']);return '_E7_FULL_SORTED = sorted(' in s and '_E7_SELECTED_IDS = set(TASK_IDS)' in s
check('stable-tie-and-sort-before-eval-filter',priority_ties)

module=types.ModuleType('kvmod');exec((ROOT/'kv_controller_source.py').read_text(),module.__dict__)

def sample(kv=.30,run=16,wait=0,pre=0):
 vals={'vllm:kv_cache_usage_perc':kv,'vllm:num_requests_running':run,'vllm:num_requests_waiting':wait,'vllm:num_preemptions':pre}
 return [{'name':name,'value':value,'labels':{'engine':'0','model_name':'abc'}} for name,value in vals.items()]

def actual_metrics():
 f=str(ROOT/'tests'/'dual_v2_metrics_fixture.json')
 d=json.load(open(f)); a=module.e7_parse_metrics(d[0]['metrics']); assert a is not None,a
 assert abs(a['kv']-.3005917159763314)<1e-8
 assert a['running']==16 and a['preempt']==0
 for x in ([{'name':'vllm:kv_cache_usage_perc','value':.3}]*2, sample(kv=float('nan')), sample(run=3.14)):
  assert module.e7_parse_metrics(x) is None
 dup=sample();dup.append(dup[0]);assert module.e7_parse_metrics(dup) is None
 wrong=sample();wrong[0]['labels']['engine']='1';assert module.e7_parse_metrics(wrong) is None
check('actual-vllm-metrics-replay-and-strict-parsing',actual_metrics)

def controller():
 K=module.E7KVAdmission
 f=lambda **kw:K(mode=kw.pop('mode','adaptive'),engine_cap=kw.pop('engine_cap',20),base_cap=16,extra_cap=kw.pop('extra_cap',18),kv_tokens=1353600,poll_sec=15,soft=.62,projected=.78,hard=.90,**kw)
 c=f(mode='baseline');assert c.decide(100,15,5000)==(True,'baseline')
 assert c.decide(100,16,5000)[0] is False
 c=f(mode='fixed');assert c.decide(100,17,5000)[0] is True
 assert c.decide(100,18,5000)[0] is False
 c=f();assert c.decide(100,15,5000)[0];assert not c.decide(100,16,5000)[0]
 c.observe(sample(kv=.30),100);c.observe(sample(kv=.30),115)
 assert c.decide(116,16,5000)==(True,'adaptive_extra'),c.decide(116,16,5000)
 c.record(116,'z#0','adaptive_extra',True)
 assert not c.decide(116,17,5000)[0]
 c.observe(sample(kv=.34,run=17),130)
 assert c.decide(131,17,5000)[1] in ('kv_projected','kv_soft','adaptive_extra')
 c=f();c.observe(sample(.30),100);c.observe(sample(.32,pre=1),115)
 assert c.decide(116,16,5000)[1]=='preemption_cooldown'
 c=f();c.observe(sample(.30),100);c.observe(sample(.30),115);c.mark_phase_transition(116)
 assert c.decide(116,16,5000)[1]=='phase_transition'
 c.observe(sample(.30),131)
 assert c.decide(132,16,5000)[1]=='phase_transition' or c.decide(132,16,5000)[1]=='adaptive_extra'
 c=f(engine_cap=16);assert not c.decide(116,16,4000)[0]
 c=f();c.observe(sample(.30),100);c.observe(sample(.93),115)
 assert not c.decide(116,1,4000)[0]
 c=f();c.observe(sample(.30),100);c.observe(sample(.30),115);assert not c.decide(200,16,4000)[0]
 c=f();c.observe(sample(.30),100);c.observe(sample(.30),115);assert not c.decide(116,18,4000)[0]
check('controller-admission-safety-scenarios',controller)


def phase2_transaction():
    nb=json.loads(NEW.read_text())
    src=''.join(nb['cells'][7]['source'])
    fn=next(n for n in ast.parse(src).body if isinstance(n,ast.FunctionDef) and n.name=='start_phase2')
    method='\n'.join(src.splitlines()[fn.lineno-1:fn.end_lineno])+'\n'
    class Engine:
        def __init__(self):self.bad=True;self.aborted=[];self.requests=[]
        def add_request(self,rid,prompt,p):
            if self.bad: raise RuntimeError('injected Phase2 failure')
            self.requests.append((rid,prompt,p))
        def abort_request(self,rid):self.aborted.extend(rid)
    eng=Engine()
    ns={'engine':eng,'THINK_CLOSE_ID':99,'EOS_IDS':{7},'STOP_IDS':[11,12],
        'MAX_MODEL_LEN':81920,'_req':lambda uid,phase:f'{uid}|{phase}',
        'UNIT_INDEX':{'t#0':0},'SEED':5,'make_params':lambda cap,seed:(cap,seed),
        'SCHED':{'phase2_continue':0,'phase2_forced':0},
        'KV_GATE':types.SimpleNamespace(mark_phase_transition=lambda now:None),
        'time':time}
    exec(method,ns)
    st={'uid':'t#0','phase':1,'prompt_ids':[1,2], 'p1_ids':[3,7],
        'p2_ids':[], 'p2_prefix':[], 'mode':None}
    assert_failed=False
    try: ns['start_phase2'](st,8192)
    except RuntimeError: assert_failed=True
    assert assert_failed
    assert st['phase']==1 and st['mode'] is None and st['p1_ids']==[3,7]
    assert ns['SCHED']['phase2_forced']==0
    assert eng.aborted==['t#0|2']
    eng.bad=False
    assert ns['start_phase2'](st,8192)
    assert st['phase']==2 and st['p1_ids']==[3]
    assert st['p2_cap']==8192
    assert eng.requests[-1][0]=='t#0|2'
    assert eng.requests[-1][1]['prompt_token_ids']==[1,2,3,11,12]
check('phase2-failure-transactionality-and-eos',phase2_transaction)

def strict_budget_code():
    cfg=''.join(raw['cells'][2]['source']);task=''.join(raw['cells'][4]['source'])
    assert 'E7_STRICT_FULL_BUDGET' in cfg
    assert 'if E7_STRICT_FULL_BUDGET and cap != THINK_BUDGET:' in task
    assert 'SKIPPED[uid]' in task
    assert 'experiment7_full_thinking_budget_required' in task
check('strict-budget-oversized-prompt-preflight',strict_budget_code)

# execute notebook's scheduler cell against a deterministic stub runtime.
class Comp:
 def __init__(self,ids):self.token_ids=ids;self.finish_reason='stop'
class Out:
 def __init__(self,rid,ids):self.request_id=rid;self.outputs=[Comp(ids)];self.finished=True
class FakeEngine:
 def __init__(self):self.pending={};self.admissions=[];self.aborted=[];self.fail_add=False
 def add_request(self,rid,prompt,params):
  if self.fail_add: raise RuntimeError('injected add failure')
  self.pending[rid]=prompt;self.admissions.append(rid)
 def step(self):
  if not self.pending:return []
  out=[]
  for rid in list(self.pending):
   phase=int(rid.rsplit('|',1)[1]);out.append(Out(rid,[99,1] if phase==1 else [1]));self.pending.pop(rid)
  return out
 def abort_request(self,rids):
  self.aborted.extend(rids)
  for rid in rids:self.pending.pop(rid,None)

def scheduler_run(ordering='original',mode='baseline',fault=False):
 src=''.join(raw['cells'][7]['source'])
 g={'__name__':'__main__','os':os,'time':time,'json':json,'traceback':traceback,'math':__import__('math'),'NOTEBOOK_T0':time.perf_counter(),
    'OUT':Path(tempfile.mkdtemp(prefix='e7-sim-')),'RECORDS':[],'RERUN':False,
    'test_challenges':{'a':{'test':[{'input':[[1]]}]},'b':{'test':[{'input':[[1]]}]},'c':{'test':[{'input':[[1]]}]}},
    'identity_submission':lambda d:{x:[{'attempt_1':[[1]],'attempt_2':[[1]]}] for x in d},
    'SUBMISSION_PATH':Path(tempfile.mkdtemp())/'submission.json',
    'write_json_atomic':lambda p,obj: Path(p).write_text(json.dumps(obj)),
    'UNITS':['a#0','b#0','c#0'],'UNIT_INDEX':{'a#0':0,'b#0':1,'c#0':2},
    'UNIT_TASK':{'a#0':'a','b#0':'b','c#0':'c'},'UNIT_Q':{'a#0':0,'b#0':0,'c#0':0},
    'e7_schedule_units':lambda: (['c#0','a#0','b#0'] if ordering=='codex' else ['a#0','b#0','c#0']),
    'PROMPT_IDS':{x:[100,101] for x in ['a#0','b#0','c#0']},
    'ENGINE_INFO':{'selected_max_num_seqs':20,'kv_tokens':1353600,'kv_cache_dtype':'fp8_e4m3','speculative':{'method':'mtp','num_speculative_tokens':3},'prefix_caching':True,'attention_backend':'FLASHINFER','attention_backend_resolved':'FLASHINFER'},
    'ENGINE_READY':True,'KV_CACHE_DTYPE':'fp8_e4m3','SPECULATIVE_CONFIG':{'method':'mtp','num_speculative_tokens':3},'ENABLE_PREFIX_CACHING':True,
    'E7_ADMISSION':mode,'E7_ORDERING':ordering,'E7_EXTRA_CAP':18,'E7_POLL_SEC':15.,'E7_KV_SOFT':.62,'E7_KV_PROJECTED_MAX':.78,'E7_KV_HARD':.90,'E7_COOLDOWN_SEC':120.,
    'CONCURRENCY':16,'P1_CAPS':{'a#0':10,'b#0':10,'c#0':10},'MAX_MODEL_LEN':81920,'SEED':20,
    'THINK_CLOSE_ID':99,'EOS_IDS':set(),'STOP_IDS':[200],
    'ANSWER_MAX_TOKENS':8192,'DRAIN_ANSWER_MAX_TOKENS':8192,
    'ADMIT_DEADLINE':time.perf_counter()+200,'DRAIN_DEADLINE':time.perf_counter()+300,'HARD_STOP':time.perf_counter()+400,
    'tokenizer':types.SimpleNamespace(decode=lambda ids,skip_special_tokens=True:'1'),
    'parse_grid':lambda txt:[[1]],'make_attempts':lambda uid,grid:{'attempt_1':grid,'attempt_2':grid,'src_1':'model','src_2':'input'},
    'score_unit':lambda uid,att:{'hit':False,'pass1':False},
    'LOG_EVERY_SEC':1e6,
    'metrics_snapshot':lambda:[], 'make_params':lambda cap,seed: {'max_tokens':cap,'seed':seed},
    'write_submission':lambda:None,
    'E7_ORDERING_REPORT':{'selected':ordering},
 }
 g['engine']=FakeEngine();g['engine'].fail_add=fault
 exec(src,g)
 return g

def mock_run():
 a=scheduler_run('original');b=scheduler_run('codex')
 assert list(a['FINAL'])==['a#0','b#0','c#0']
 assert list(b['FINAL'])==['c#0','a#0','b#0']
 assert {k:v['attempt_1'] for k,v in a['FINAL'].items()}=={k:v['attempt_1'] for k,v in b['FINAL'].items()}
 assert a['SCHED']['error'] is None and b['SCHED']['error'] is None
 assert a['SCHED']['admitted']==3 and b['SCHED']['admitted']==3
 c=scheduler_run('original',fault=True)
 assert c['SCHED']['error'] is not None
 assert c['STATE']=={}
 assert c['SCHED']['admitted']==0
 assert c['SCHED']['not_admitted']==3  # failed admission cannot silently lose queued units
check('end-to-end-deterministic-fake-engine-and-failure',mock_run)

# scan source diff whitelist and no accidental changes to frozen non-target source sections

def source_diff():
 changes=[]
 for i in range(1,9):
  old=''.join(base['cells'][i]['source']);new=''.join(raw['cells'][i]['source']);
  if old!=new:changes.append(i-1)
 assert changes==[1,3,5,6],changes
 for i in [0,2,4,7]: assert ''.join(base['cells'][i+1]['source'])==''.join(raw['cells'][i+1]['source'])
check('allowed-code-cells-only-changed',source_diff)
(ROOT/'CPU_VALIDATION_REPORT.json').write_text(json.dumps({'checked_at':'2026-10-12','gpu_executed':False,'checks':checks,'pass_count':sum(t['status']=='PASS' for t in checks),'fail_count':sum(t['status']=='FAIL' for t in checks)},indent=2))
print('RESULT',sum(t['status']=='PASS' for t in checks),'/',len(checks))
if any(t['status']=='FAIL' for t in checks):sys.exit(1)
