# Experiment 7 KVAdmission controller — stdlib only, embedded verbatim in notebook.
import math
from collections import deque

KV_METRIC_NAMES = {
    "kv": "vllm:kv_cache_usage_perc",
    "running": "vllm:num_requests_running",
    "waiting": "vllm:num_requests_waiting",
    "preempt": "vllm:num_preemptions",
}

def e7_parse_metrics(rows):
    """One-engine numeric metrics; reject duplicate/malformed/other-engine values."""
    values = {}
    try:
        for row in rows:
            name = row.get("name")
            if name not in KV_METRIC_NAMES.values():
                continue
            labels = row.get("labels") or {}
            if str(labels.get("engine", "0")) != "0":
                return None
            if name in values:
                return None
            val = float(row["value"])
            if not math.isfinite(val):
                return None
            values[name] = val
        if set(values) != set(KV_METRIC_NAMES.values()):
            return None
        kv, run, waiting, pre = (values[KV_METRIC_NAMES[k]] for k in ("kv", "running", "waiting", "preempt"))
        if not (0 <= kv <= 1 and 0 <= run and run.is_integer() and
                0 <= waiting and waiting.is_integer() and 0 <= pre and pre.is_integer()):
            return None
        return {"kv": kv, "running": int(run), "waiting": int(waiting), "preempt": int(pre)}
    except (TypeError, ValueError, KeyError, AttributeError):
        return None

class E7KVAdmission:
    """Decides admissions only; never modifies engine requests or their token limits."""
    def __init__(self, *, mode, engine_cap, base_cap, extra_cap, kv_tokens,
                 poll_sec=15., soft=0.62, projected=0.78, hard=0.90, cooldown_sec=120.):
        self.mode = str(mode)
        self.engine_cap = int(engine_cap)
        self.base_cap = int(base_cap)
        self.extra_cap = min(int(extra_cap), self.engine_cap)
        self.kv_tokens = int(kv_tokens or 0)
        self.poll_sec = float(poll_sec)
        self.soft = float(soft)
        self.projected = float(projected)
        self.hard = float(hard)
        self.cooldown_sec = float(cooldown_sec)
        self.prev_sample = None
        self.sample = None
        self.sample_id = 0
        self.extra_on_sample_id = -1
        self.next_poll = 0.0
        self.cooldown_until = 0.0
        self.transition_sample_id = -1
        self.transition_at = -float("inf")
        self.growth = deque(maxlen=5)
        self.events = []
        self.counters = {"baseline":0,"fixed":0,"adaptive_extra":0,"blocked":0,"metric_invalid":0,"preempt_alerts":0}

    def due(self, now):
        return self.mode == "adaptive" and now >= self.next_poll

    def observe(self, rows, now):
        self.next_poll = now + self.poll_sec
        val = e7_parse_metrics(rows)
        if val is None:
            self.sample = None
            self.growth.clear()
            self.counters["metric_invalid"] += 1
            self.log(now,"metric_invalid")
            return
        val["t"] = float(now)
        if self.sample is not None:
            prev = self.sample
            if val["preempt"] != prev["preempt"]:
                self.cooldown_until = max(self.cooldown_until, now + self.cooldown_sec)
                self.counters["preempt_alerts"] += 1
                self.growth.clear()
                self.log(now, "preemption_or_counter_reset", old=prev["preempt"], new=val["preempt"])
            dt = now - prev["t"]
            if 0 < dt <= max(3*self.poll_sec, 60.):
                self.growth.append(max(0.0,(val["kv"]-prev["kv"])/dt))
        self.prev_sample = self.sample
        self.sample = val
        self.sample_id += 1
        self.log(now,"metric",**{k:val[k] for k in ("kv","running","waiting","preempt")})

    def mark_phase_transition(self, now):
        # One fresh completed snapshot, plus a short hold, needed before extra admission.
        self.transition_at = float(now)
        self.transition_sample_id = self.sample_id

    def decide(self, now, host_active, next_prompt_tokens):
        if host_active >= self.engine_cap:
            return False,"engine_cap"
        # The normal v1.4.4 scheduler fills to baseline. Only a genuine emergency
        # snapshot can override it; when all requests are idle, eviction may be needed.
        fresh = self.sample is not None and 0 <= now-self.sample["t"] <= max(2*self.poll_sec,30.0)
        if host_active < self.base_cap:
            if fresh and self.sample["kv"] >= self.hard and host_active > 0:
                return False,"emergency_kv"
            return True,"baseline"
        if self.mode == "baseline":
            return False,"baseline_cap"
        if host_active >= self.extra_cap:
            return False,"extra_cap"
        if self.mode == "fixed":
            return True,"fixed"
        # Adaptive extra requests require valid, fresh, settled engine telemetry.
        if not fresh:
            return False,"stale_metrics"
        m = self.sample
        if m["running"] != host_active or m["waiting"] != 0:
            return False,"engine_mismatch_or_waiting"
        if now < self.cooldown_until:
            return False,"preemption_cooldown"
        if self.sample_id <= self.transition_sample_id or now-self.transition_at < self.poll_sec:
            return False,"phase_transition"
        if self.sample_id == self.extra_on_sample_id:
            return False,"one_extra_per_snapshot"
        if self.prev_sample is None or not self.growth:
            return False,"growth_not_ready"
        if self.kv_tokens <= 0:
            return False,"kv_pool_unknown"
        if m["kv"] >= self.soft:
            return False,"kv_soft"
        # PROVISIONAL pressure guard, not a physical-memory guarantee.
        # 60s max recent growth plus prompt block reserve and 8%-pt margin.
        slope=max(self.growth)
        prompt_reserve=max(0.05, 1.5*int(next_prompt_tokens)/self.kv_tokens + 0.015)
        estimate=m["kv"] + 60*slope + prompt_reserve + 0.08
        if estimate > self.projected:
            return False,"kv_projected"
        return True,"adaptive_extra"

    def record(self, now, uid, reason, accepted):
        if accepted:
            self.counters[reason] = self.counters.get(reason,0)+1
            if reason == "adaptive_extra":
                self.extra_on_sample_id = self.sample_id
        else:
            self.counters["blocked"] += 1
        self.log(now,"admission" if accepted else "blocked",uid=uid,reason=reason)

    def log(self, now, kind, **kw):
        # Keep bounded event memory; report has aggregate counters too.
        self.events.append({"t":round(float(now),3),"kind":kind,**kw})
        if len(self.events)>10000:
            self.events=self.events[-9000:]

    def report(self):
        return {"mode":self.mode,"engine_cap":self.engine_cap,"baseline_cap":self.base_cap,
                "extra_cap":self.extra_cap,"kv_pool":self.kv_tokens,"last_sample":self.sample,
                "counters":self.counters,"events":self.events,
                "note":"Experimental KV guard, not a proof of memory safety"}
