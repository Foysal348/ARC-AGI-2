#!/usr/bin/env python3
"""Build Q27 Experiment 7 from immutable v1.4.4 notebook, using exact Codex donor ordering."""
import ast, hashlib, json, pathlib, textwrap, copy, difflib
BASE=pathlib.Path(__file__).resolve().parent/'source'/'Q27-XHIGH-v1_4_4.ipynb'
DONOR=pathlib.Path(__file__).resolve().parent/'source'/'arc-2026d-with-codex (24)(1).ipynb'
OUT=pathlib.Path(__file__).resolve().parent
OUT.mkdir(exist_ok=True)
nb=json.loads(BASE.read_text()); donor=json.loads(DONOR.read_text()); ds=''.join(donor['cells'][6]['source']); ds=ds.removeprefix('%%writefile starter.py\n')
node=next(n for n in ast.parse(ds).body if isinstance(n,ast.FunctionDef) and n.name=='get_puzzle_priority')
func='\n'.join(ds.splitlines()[node.lineno-1:node.end_lineno])+'\n'
sha=hashlib.sha256(func.encode()).hexdigest()
assert sha=='3f6536e80d445389da50ed61b3c4b80edc05ff25989aa1ecf7fdef0626196230',sha
(OUT/'donor_get_puzzle_priority.py').write_text('import numpy as np\n\n'+func)

def update(cellno, find, repl):
    cell=nb['cells'][cellno+1];src=''.join(cell['source']);assert src.count(find)==1, (cellno,find[:100],src.count(find));cell['source']=(src.replace(find,repl)).splitlines(keepends=True)

# Cell 1: explicit OFF-safe modes
marker='MAX_NUM_SEQS = int(os.environ.get("Q27X_MAX_NUM_SEQS", 16))'
extra='''# === EXPERIMENT 7: all experimental paths default OFF ===
E7_ORDERING = os.environ.get("Q27X_E7_ORDERING", "original").strip().lower()  # original/codex
E7_ADMISSION = os.environ.get("Q27X_E7_ADMISSION", "baseline").strip().lower()  # baseline/fixed/adaptive
E7_EXTRA_CAP = int(os.environ.get("Q27X_E7_EXTRA_CAP", "16"))
# Hard user rule: never silently downgrade 49,152-token thinking allowance.
# A prompt that cannot fit full budget uses the existing valid input fallback.
E7_STRICT_FULL_BUDGET = os.environ.get("Q27X_E7_STRICT_FULL_BUDGET", "1") == "1"
E7_POLL_SEC = float(os.environ.get("Q27X_E7_POLL_SEC", "15"))
E7_KV_SOFT = float(os.environ.get("Q27X_E7_KV_SOFT", "0.62"))  # provisional, not calibrated
E7_KV_PROJECTED_MAX = float(os.environ.get("Q27X_E7_KV_PROJECTED_MAX", "0.78"))
E7_KV_HARD = float(os.environ.get("Q27X_E7_KV_HARD", "0.90"))
E7_COOLDOWN_SEC = float(os.environ.get("Q27X_E7_COOLDOWN_SEC", "120"))
assert E7_ORDERING in ("original", "codex")
assert E7_ADMISSION in ("baseline", "fixed", "adaptive")
assert 16 <= E7_EXTRA_CAP <= 20
assert 1 <= E7_POLL_SEC <= 60
assert 0.20 < E7_KV_SOFT < E7_KV_PROJECTED_MAX < E7_KV_HARD < 1.0
if E7_ADMISSION != "baseline":
    assert E7_EXTRA_CAP > 16, "Experiment admission requires Q27X_E7_EXTRA_CAP=18 (or 20 after GPU gate)"
# Frozen baseline is always reproducible by choosing original/baseline/max_num_seqs=16.
'''
update(1,marker,extra+marker)
# Config must reflect flags
marker='CONFIG["VLLM_MEMORY_PROFILER_ESTIMATE_CUDAGRAPHS"] = '
update(1,marker,'CONFIG["experiment7"] = {k: globals()[k] for k in ("E7_ORDERING", "E7_ADMISSION", "E7_EXTRA_CAP", "E7_STRICT_FULL_BUDGET", "E7_POLL_SEC", "E7_KV_SOFT", "E7_KV_PROJECTED_MAX", "E7_KV_HARD", "E7_COOLDOWN_SEC")}\n'+marker)

# Cell 3: exact donor function inserted before unit mapping. Uses full source dictionary and stable ordering.
find='# a unit = one test input of one task; request ids, seeds, records and the scheduler all work on units\n'
addition='''# === EXPERIMENT 7A: EXACT CODEX PRIORITY FUNCTION (source preserved verbatim) ===
import numpy as np
'''+func+'''
# Sort on the ORIGINAL full JSON dictionary, then filter EVAL subset.
# Python sort is stable: equal (tier, fine) preserves original file order.
_E7_FULL_CHALLENGES = _ch if P["source"] == "eval" else test_challenges
# OFF mode should not even calculate donor priority (historical baseline isolation).
if E7_ORDERING == "codex":
    _E7_FULL_SORTED = sorted(
        _E7_FULL_CHALLENGES.keys(),
        key=lambda k: get_puzzle_priority(k, _E7_FULL_CHALLENGES)
    )
    _E7_SELECTED_IDS = set(TASK_IDS)
    E7_ORDERED_TASKS = [t for t in _E7_FULL_SORTED if t in _E7_SELECTED_IDS]
    E7_PRIORITY = {t: get_puzzle_priority(t, _E7_FULL_CHALLENGES) for t in E7_ORDERED_TASKS}
else:
    E7_ORDERED_TASKS = list(TASK_IDS)
    E7_PRIORITY = {}
E7_ORDERED_UNITS = [
    f"{tid}#{qi}"
    for tid in E7_ORDERED_TASKS
    for qi in range(len(CHALLENGES[tid]["test"]))
]

def e7_schedule_units():
    return E7_ORDERED_UNITS if E7_ORDERING == "codex" else UNITS

'''
# must define ORDERED_UNITS after UNIT declarations (we place function ahead but E7_ORDERED_UNITS uses prebuilt TASK_IDS only; UNITS in function resolved later)
update(3,find,find+'\n'+addition)
# extra validation after UNITS index built
find='UNIT_INDEX = {u: i for i, u in enumerate(UNITS)}             # v1.1 (F13): seeds do not depend on timing\n'
update(3,find,find+'''from collections import Counter as _E7Counter
assert _E7Counter(E7_ORDERED_UNITS) == _E7Counter(UNITS), "Codex ordering must permute units"
E7_ORDERING_REPORT = {
    "selected": E7_ORDERING, "donor_function_sha256": "'''+sha+'''",
    "n_tasks": len(E7_ORDERED_TASKS), "n_units": len(E7_ORDERED_UNITS),
    "tiers": {str(i): sum(p[0] == i for p in E7_PRIORITY.values()) for i in (1, 2, 3)},
    "first_5": E7_ORDERED_TASKS[:5], "last_5": E7_ORDERED_TASKS[-5:],
    "ordered_task_ids": E7_ORDERED_TASKS,
}
print("Experiment7 ordering:", E7_ORDERING_REPORT["selected"], E7_ORDERING_REPORT["tiers"])
''')

# Cell 3: preflight for full xhigh 49k thinking allowance; no shortened inference.
update(3, '''    cap = phase1_cap(len(ids))
    if cap < min(MIN_THINK_BUDGET, THINK_BUDGET):''',
           '''    cap = phase1_cap(len(ids))
    if E7_STRICT_FULL_BUDGET and cap != THINK_BUDGET:
        SKIPPED[uid] = {"prompt_tokens": len(ids), "reason": "experiment7_full_thinking_budget_required",
                        "would_have_been_cap": int(cap)}
        continue
    if cap < min(MIN_THINK_BUDGET, THINK_BUDGET):''')
# Cell 5: safe engine cap trials first, same recipe fallback to 16.
find='''_seen = []
llm = None
for _kv, _spec, _backend, _pc in _LADDER:
    if (_kv, json.dumps(_spec), _backend, _pc) in _seen:
        continue
    _seen.append((_kv, json.dumps(_spec), _backend, _pc))
    _t0 = time.perf_counter()
    _kw = dict(ENGINE_CONFIG, attention_config={"backend": _backend}, enable_prefix_caching=bool(_pc))
'''
repl='''# === EXPERIMENT 7B: engine capacity is independent of application admission ===
# Try preferred recipe at requested capacity, then SAME recipe at proven cap 16,
# before trying degraded cache/backend/speculative recipes.
_E7_TRIALS = []
for _idx, _recipe in enumerate(_LADDER):
    _caps = [MAX_NUM_SEQS, 16] if _idx == 0 and MAX_NUM_SEQS > 16 else [min(16, MAX_NUM_SEQS)]
    for _cap in _caps:
        _E7_TRIALS.append((_cap, *_recipe))
_seen = []
llm = None
for _cap, _kv, _spec, _backend, _pc in _E7_TRIALS:
    _key = (_cap, _kv, json.dumps(_spec), _backend, _pc)
    if _key in _seen:
        continue
    _seen.append(_key)
    _t0 = time.perf_counter()
    _kw = dict(ENGINE_CONFIG, max_num_seqs=int(_cap), attention_config={"backend": _backend}, enable_prefix_caching=bool(_pc))
'''
update(5,find,repl)
update(5,'_att = {"kv_cache_dtype": _kv,','_att = {"requested_engine_cap": int(_cap), "kv_cache_dtype": _kv,')
update(5,'ENGINE_INFO.update(speculative=_spec, kv_cache_dtype=_kv, attention_backend=_backend, prefix_caching=bool(_pc))','ENGINE_INFO.update(selected_max_num_seqs=int(_cap), speculative=_spec, kv_cache_dtype=_kv, attention_backend=_backend, prefix_caching=bool(_pc))')
update(5,'''    CONCURRENCY = MAX_NUM_SEQS
    if ENGINE_INFO["kv_tokens"]:
        CONCURRENCY = max(4, min(MAX_NUM_SEQS, ENGINE_INFO["kv_tokens"] // EXPECTED_LIVE_TOKENS_PER_SEQ))
''','''    # In baseline mode this is identical to v1.4.4 when max_num_seqs=16.
    _e7_real_cap = int(ENGINE_INFO["selected_max_num_seqs"])
    CONCURRENCY = min(16, _e7_real_cap)
    if ENGINE_INFO["kv_tokens"]:
        CONCURRENCY = max(4, min(CONCURRENCY, ENGINE_INFO["kv_tokens"] // EXPECTED_LIVE_TOKENS_PER_SEQ))
''')
update(5,'ENGINE_INFO["concurrency"] = int(CONCURRENCY); ENGINE_INFO["vllm"] = vllm.__version__','ENGINE_INFO["concurrency"] = int(CONCURRENCY); ENGINE_INFO["vllm"] = vllm.__version__\nENGINE_INFO["experiment7"] = {"application_baseline_cap": int(CONCURRENCY), "engine_cap": int(ENGINE_INFO.get("selected_max_num_seqs", 0)), "admission_mode": E7_ADMISSION}')

# Cell 6: controller functionality imported from separate pure testable python file (embedded in notebook next cell source below)
controller=(OUT/'kv_controller_source.py')
controller.write_text('''# Experiment 7 KVAdmission controller — stdlib only, embedded verbatim in notebook.
import math
from collections import deque

KV_METRIC_NAMES = {
    "kv": "vllm:kv_cache_usage_perc",
    "running": "vllm:num_requests_running",
    "waiting": "vllm:num_requests_waiting",
    "preempt": "vllm:num_preemptions",
}

def e7_parse_metrics(rows):
    """One-engine numeric metrics; reject duplicate/malformed/other-engine values."""
    values = {}
    try:
        for row in rows:
            name = row.get("name")
            if name not in KV_METRIC_NAMES.values():
                continue
            labels = row.get("labels") or {}
            if str(labels.get("engine", "0")) != "0":
                return None
            if name in values:
                return None
            val = float(row["value"])
            if not math.isfinite(val):
                return None
            values[name] = val
        if set(values) != set(KV_METRIC_NAMES.values()):
            return None
        kv, run, waiting, pre = (values[KV_METRIC_NAMES[k]] for k in ("kv", "running", "waiting", "preempt"))
        if not (0 <= kv <= 1 and 0 <= run and run.is_integer() and
                0 <= waiting and waiting.is_integer() and 0 <= pre and pre.is_integer()):
            return None
        return {"kv": kv, "running": int(run), "waiting": int(waiting), "preempt": int(pre)}
    except (TypeError, ValueError, KeyError, AttributeError):
        return None

class E7KVAdmission:
    """Decides admissions only; never modifies engine requests or their token limits."""
    def __init__(self, *, mode, engine_cap, base_cap, extra_cap, kv_tokens,
                 poll_sec=15., soft=0.62, projected=0.78, hard=0.90, cooldown_sec=120.):
        self.mode = str(mode)
        self.engine_cap = int(engine_cap)
        self.base_cap = int(base_cap)
        self.extra_cap = min(int(extra_cap), self.engine_cap)
        self.kv_tokens = int(kv_tokens or 0)
        self.poll_sec = float(poll_sec)
        self.soft = float(soft)
        self.projected = float(projected)
        self.hard = float(hard)
        self.cooldown_sec = float(cooldown_sec)
        self.prev_sample = None
        self.sample = None
        self.sample_id = 0
        self.extra_on_sample_id = -1
        self.next_poll = 0.0
        self.cooldown_until = 0.0
        self.transition_sample_id = -1
        self.transition_at = -float("inf")
        self.growth = deque(maxlen=5)
        self.events = []
        self.counters = {"baseline":0,"fixed":0,"adaptive_extra":0,"blocked":0,"metric_invalid":0,"preempt_alerts":0}

    def due(self, now):
        return self.mode == "adaptive" and now >= self.next_poll

    def observe(self, rows, now):
        self.next_poll = now + self.poll_sec
        val = e7_parse_metrics(rows)
        if val is None:
            self.sample = None
            self.growth.clear()
            self.counters["metric_invalid"] += 1
            self.log(now,"metric_invalid")
            return
        val["t"] = float(now)
        if self.sample is not None:
            prev = self.sample
            if val["preempt"] != prev["preempt"]:
                self.cooldown_until = max(self.cooldown_until, now + self.cooldown_sec)
                self.counters["preempt_alerts"] += 1
                self.growth.clear()
                self.log(now, "preemption_or_counter_reset", old=prev["preempt"], new=val["preempt"])
            dt = now - prev["t"]
            if 0 < dt <= max(3*self.poll_sec, 60.):
                self.growth.append(max(0.0,(val["kv"]-prev["kv"])/dt))
        self.prev_sample = self.sample
        self.sample = val
        self.sample_id += 1
        self.log(now,"metric",**{k:val[k] for k in ("kv","running","waiting","preempt")})

    def mark_phase_transition(self, now):
        # One fresh completed snapshot, plus a short hold, needed before extra admission.
        self.transition_at = float(now)
        self.transition_sample_id = self.sample_id

    def decide(self, now, host_active, next_prompt_tokens):
        if host_active >= self.engine_cap:
            return False,"engine_cap"
        # The normal v1.4.4 scheduler fills to baseline. Only a genuine emergency
        # snapshot can override it; when all requests are idle, eviction may be needed.
        fresh = self.sample is not None and 0 <= now-self.sample["t"] <= max(2*self.poll_sec,30.0)
        if host_active < self.base_cap:
            if fresh and self.sample["kv"] >= self.hard and host_active > 0:
                return False,"emergency_kv"
            return True,"baseline"
        if self.mode == "baseline":
            return False,"baseline_cap"
        if host_active >= self.extra_cap:
            return False,"extra_cap"
        if self.mode == "fixed":
            return True,"fixed"
        # Adaptive extra requests require valid, fresh, settled engine telemetry.
        if not fresh:
            return False,"stale_metrics"
        m = self.sample
        if m["running"] != host_active or m["waiting"] != 0:
            return False,"engine_mismatch_or_waiting"
        if now < self.cooldown_until:
            return False,"preemption_cooldown"
        if self.sample_id <= self.transition_sample_id or now-self.transition_at < self.poll_sec:
            return False,"phase_transition"
        if self.sample_id == self.extra_on_sample_id:
            return False,"one_extra_per_snapshot"
        if self.prev_sample is None or not self.growth:
            return False,"growth_not_ready"
        if self.kv_tokens <= 0:
            return False,"kv_pool_unknown"
        if m["kv"] >= self.soft:
            return False,"kv_soft"
        # PROVISIONAL pressure guard, not a physical-memory guarantee.
        # 60s max recent growth plus prompt block reserve and 8%-pt margin.
        slope=max(self.growth)
        prompt_reserve=max(0.05, 1.5*int(next_prompt_tokens)/self.kv_tokens + 0.015)
        estimate=m["kv"] + 60*slope + prompt_reserve + 0.08
        if estimate > self.projected:
            return False,"kv_projected"
        return True,"adaptive_extra"

    def record(self, now, uid, reason, accepted):
        if accepted:
            self.counters[reason] = self.counters.get(reason,0)+1
            if reason == "adaptive_extra":
                self.extra_on_sample_id = self.sample_id
        else:
            self.counters["blocked"] += 1
        self.log(now,"admission" if accepted else "blocked",uid=uid,reason=reason)

    def log(self, now, kind, **kw):
        # Keep bounded event memory; report has aggregate counters too.
        self.events.append({"t":round(float(now),3),"kind":kind,**kw})
        if len(self.events)>10000:
            self.events=self.events[-9000:]

    def report(self):
        return {"mode":self.mode,"engine_cap":self.engine_cap,"baseline_cap":self.base_cap,
                "extra_cap":self.extra_cap,"kv_pool":self.kv_tokens,"last_sample":self.sample,
                "counters":self.counters,"events":self.events,
                "note":"Experimental KV guard, not a proof of memory safety"}
''')
cs=controller.read_text()
marker='RECORDS_PATH = OUT / "records.jsonl"'
update(6,marker,cs+'\n'+marker)
# prepend controller init after SCHED initialization exactly
marker='         "aborted_at_hard_stop": 0, "not_admitted": 0, "max_active": 0, "steps": 0}\n'
initial='''# Engine recipe must match the preferred pinned configuration before any adaptive admission.
_E7_ENGINE_CAP = int(ENGINE_INFO.get("selected_max_num_seqs", 0))
_E7_PREFERRED = bool(
    ENGINE_READY and ENGINE_INFO.get("kv_cache_dtype") == KV_CACHE_DTYPE
    and ENGINE_INFO.get("speculative") == SPECULATIVE_CONFIG
    and ENGINE_INFO.get("prefix_caching") == ENABLE_PREFIX_CACHING
    and ENGINE_INFO.get("attention_backend") == "FLASHINFER"
    and str(ENGINE_INFO.get("attention_backend_resolved", "")).upper() in ("FLASHINFER", "NONE")
)
_E7_ADMISSION_EFFECTIVE = E7_ADMISSION
_E7_DISABLED_REASON = None
if E7_ADMISSION == "adaptive" and not (_E7_PREFERRED and _E7_ENGINE_CAP > CONCURRENCY and ENGINE_INFO.get("kv_tokens")):
    _E7_ADMISSION_EFFECTIVE = "baseline"
    _E7_DISABLED_REASON = "preferred_engine_or_kv_unavailable"
if E7_ADMISSION == "fixed" and _E7_ENGINE_CAP <= CONCURRENCY:
    _E7_ADMISSION_EFFECTIVE = "baseline"
    _E7_DISABLED_REASON = "engine_did_not_expand"
KV_GATE = E7KVAdmission(
    mode=_E7_ADMISSION_EFFECTIVE, engine_cap=_E7_ENGINE_CAP,
    base_cap=CONCURRENCY, extra_cap=E7_EXTRA_CAP,
    kv_tokens=ENGINE_INFO.get("kv_tokens"), poll_sec=E7_POLL_SEC,
    soft=E7_KV_SOFT, projected=E7_KV_PROJECTED_MAX,
    hard=E7_KV_HARD, cooldown_sec=E7_COOLDOWN_SEC)
SCHED["experiment7"] = {"ordering":E7_ORDERING,"requested_admission":E7_ADMISSION,
                          "effective_admission":_E7_ADMISSION_EFFECTIVE,
                          "disabled_reason":_E7_DISABLED_REASON}
'''
update(6,marker,marker+initial)
# transactional Phase1
find='''    STATE[uid] = st
    engine.add_request(_req(uid, 1), {"prompt_token_ids": list(st["prompt_ids"])},
                       make_params(P1_CAPS[uid], SEED + 10 * UNIT_INDEX[uid] + 1))
    SCHED["admitted"] += 1
'''
repl='''    rid = _req(uid, 1)
    try:
        engine.add_request(rid, {"prompt_token_ids": list(st["prompt_ids"])},
                           make_params(P1_CAPS[uid], SEED + 10 * UNIT_INDEX[uid] + 1))
    except Exception:
        # Unknown partial engine registration -> best-effort cleanup; scheduler fails safely.
        try: engine.abort_request([rid])
        except Exception: pass
        raise
    STATE[uid] = st
    SCHED["admitted"] += 1
'''
update(6,find,repl)
# transactional Phase2 + EOS doesn't mutate until engine registration
find='''    if not closed:                                  # v1.1 (F8): an EOS before </think> must not precede the stop text
        while st["p1_ids"] and st["p1_ids"][-1] in EOS_IDS:
            st["p1_ids"].pop()
    prefix = list(st["prompt_ids"]) + list(st["p1_ids"]) + ([] if closed else list(STOP_IDS))
    room = MAX_MODEL_LEN - len(prefix) - 8
    cap = min(int(answer_cap), room)
    if cap < 64:
        return False
    st["phase"] = 2; st["p2_prefix"] = [] if closed else list(STOP_IDS); st["mode"] = "continue" if closed else "forced_close"
    SCHED["phase2_continue" if closed else "phase2_forced"] += 1
    engine.add_request(_req(st["uid"], 2), {"prompt_token_ids": prefix}, make_params(cap, SEED + 10 * UNIT_INDEX[st["uid"]] + 2))
    return True
'''
repl='''    p1_clean = list(st["p1_ids"])
    if not closed:  # Do not mutate original stream before successful engine admission.
        while p1_clean and p1_clean[-1] in EOS_IDS:
            p1_clean.pop()
    prefix = list(st["prompt_ids"]) + p1_clean + ([] if closed else list(STOP_IDS))
    room = MAX_MODEL_LEN - len(prefix) - 8
    cap = min(int(answer_cap), room)
    if cap < 64:
        return False
    rid = _req(st["uid"], 2)
    try:
        engine.add_request(rid, {"prompt_token_ids": prefix},
                           make_params(cap, SEED + 10 * UNIT_INDEX[st["uid"]] + 2))
    except Exception:
        try: engine.abort_request([rid])
        except Exception: pass
        raise
    st["p1_ids"] = p1_clean
    st["phase"] = 2; st["p2_prefix"] = [] if closed else list(STOP_IDS); st["mode"] = "continue" if closed else "forced_close"
    st["p2_cap"] = cap
    SCHED["phase2_continue" if closed else "phase2_forced"] += 1
    KV_GATE.mark_phase_transition(time.perf_counter())
    return True
'''
update(6,find,repl)
update(6,'    queue = [u for u in UNITS if u in PROMPT_IDS]','    queue = [u for u in e7_schedule_units() if u in PROMPT_IDS]')
find='''        while queue and len(active) < CONCURRENCY and now < ADMIT_DEADLINE and not drained:
            admit(queue.pop(0)); active = [s for s in STATE.values() if s["phase"] in (1, 2)]
'''
repl='''        # Poll only in adaptive mode; sampling has a measured CPU cost.
        if KV_GATE.due(now):
            KV_GATE.observe(metrics_snapshot(), time.perf_counter())
        while queue and now < ADMIT_DEADLINE and not drained:
            now = time.perf_counter()
            uid = queue[0]
            allowed, reason = KV_GATE.decide(now, len(active), len(PROMPT_IDS[uid]))
            if not allowed:
                KV_GATE.record(now, uid, reason, False)
                break
            # Queue pop only AFTER successful registration; exceptions keep fallback valid.
            try:
                admit(uid)
            except Exception:
                SCHED["not_admitted"] = len(queue)
                raise
            queue.pop(0)
            KV_GATE.record(time.perf_counter(), uid, reason, True)
            active = [s for s in STATE.values() if s["phase"] in (1, 2)]
            if reason == "adaptive_extra":
                break  # never add two extras using one metrics sample
'''
update(6,find,repl)
# New record safe for post-run even failure.
find='''    SCHED["not_admitted"] = len(queue)
    SCHED["wall_sec"] = round(time.perf_counter() - SCHED["started"], 1)
'''
update(6,find,'    SCHED["kv_controller_counters"] = KV_GATE.counters\n'+find)
find='''    try:
        write_json_atomic(OUT / "vllm_metrics.json", METRICS_SNAPSHOTS)
    except Exception:
        pass
'''
repl=find+'''    try:
        write_json_atomic(OUT / "experiment7_kv_report.json", KV_GATE.report())
        write_json_atomic(OUT / "experiment7_ordering.json", E7_ORDERING_REPORT)
    except Exception as _e:
        print("Experiment7 diagnostic save error:", repr(_e)[:200], flush=True)
'''
update(6,find,repl)

update(6, '    SCHED.setdefault("wall_sec", round(time.perf_counter() - SCHED["started"], 1))',
       '    SCHED.setdefault("kv_controller_counters", KV_GATE.counters)\n    SCHED.setdefault("wall_sec", round(time.perf_counter() - SCHED["started"], 1))')
# Markdown documentation cell before code
md='''# Experiment 7 — Exact Codex Puzzle Ordering + KV Admission Pilot

**Base:** immutable Q27-XHIGH v1.4.4 (the original public LB 26.94 notebook). **No Dual Answer v2 stage.**\n
The original scheduling and engine defaults are preserved with `Q27X_E7_ORDERING=original`, `Q27X_E7_ADMISSION=baseline`, `Q27X_MAX_NUM_SEQS=16`. To respect the user hard rule, `Q27X_E7_STRICT_FULL_BUDGET=1` (default) skips unusual overlong prompts instead of silently reducing the 49,152-token cap; set it to `0` **only for a historical parity test**, since that restores the old reduced-budget path.\n
**Ordering:** Set `Q27X_E7_ORDERING=codex` to apply the exact donor `get_puzzle_priority()` with stable original challenge-JSON ordering. The original `UNITS`, `UNIT_INDEX`, prompts, seeds, model and sampler are unchanged. EVAL samples are filtered only **after** sorting the full original JSON dictionary.\n
**KV / concurrency:** Set `Q27X_MAX_NUM_SEQS=20` with `Q27X_E7_ADMISSION=baseline` for an engine-20 / active-16 overhead probe. For the initial adaptive 18 pilot use `Q27X_E7_ADMISSION=adaptive`, `Q27X_E7_EXTRA_CAP=18`. `fixed` with cap=18 supports the essential fixed-18 comparator, but **must not** be used for a hidden run without prior GPU safety results.\n
**Safety:** Adaptive extra admission defaults OFF. Only 17–18 may be admitted if fresh vLLM metrics permit it. Thresholds are experimental (`soft 0.62`, `projected 0.78`, `hard 0.90`) and NOT a physical KV memory guarantee. A preferred engine startup fallback to 16 is attempted before any degraded recipe. The controller cannot reduce thinking or answer token budgets. Full-budget preflight skips an oversized prompt with a valid input fallback instead of allocating fewer than 49,152 thinking tokens; the original drain/hard-stop deadlines still can force-close generation early.\n
**Validation status:** Notebook/CPU code tests provided separately. **No Kaggle GPU inference, benchmark or hidden submission has been run by this build.** Inspect `q27x/experiment7_kv_report.json` and `q27x/experiment7_ordering.json` for run-level audit evidence. Never call an adaptive run successful if requested `adaptive` but `effective_admission=baseline`.\n
**Experiments:** baseline 16/16 → engine 20/active16 → fixed18 → adaptive18 → conditional active20. Compare exact workload, deadlines, primary score, KV usage, preemptions and completed queries.\n
---\n
'''
nb['cells'][0]['source']=(md+''.join(nb['cells'][0]['source'])).splitlines(keepends=True)
# notebook includes one warning if experiment selected and missing guard; not prevent running. metadata
for _ci,_cell in enumerate(nb['cells']):
    _cell.setdefault('id', f'q27-e7-cell-{_ci:02d}')
nb.setdefault('metadata',{}).setdefault('experiment7',{})
nb['metadata']['experiment7']={'base_sha256':hashlib.sha256(BASE.read_bytes()).hexdigest(),'donor_priority_sha256':sha,'gpu_validated':False}
path=OUT/'Q27_XHIGH_v1_4_4_E7_CODEX_ORDERING_KV.ipynb';path.write_text(json.dumps(nb,ensure_ascii=False,indent=1)+'\n')
for i,c in enumerate(nb['cells']):
 if c['cell_type']=='code':
  src=''.join(c['source']);ast.parse(src);(OUT/f'_cell_{i-1}.py').write_text(src)
(OUT/'BASE_MANIFEST.json').write_text(json.dumps({'base_filename':BASE.name,'base_sha256':hashlib.sha256(BASE.read_bytes()).hexdigest(),'donor_filename':DONOR.name,'donor_sha256':hashlib.sha256(DONOR.read_bytes()).hexdigest(),'priority_function_sha256':sha,'experiment_notebook':path.name},indent=2))
# diff file preserving original
old=json.loads(BASE.read_text())
with (OUT/'SOURCE_DIFF.md').open('w') as f:
 for i in range(1,len(nb['cells'])):
  o=''.join(old['cells'][i]['source']).splitlines(keepends=True);n=''.join(nb['cells'][i]['source']).splitlines(keepends=True)
  if o!=n:
   f.write('## Code cell '+str(i-1)+'\n\n```diff\n'+''.join(difflib.unified_diff(o,n,fromfile='original',tofile='exp7'))+'\n```\n')
print('BUILT',path,'bytes',path.stat().st_size,'sha',sha)
