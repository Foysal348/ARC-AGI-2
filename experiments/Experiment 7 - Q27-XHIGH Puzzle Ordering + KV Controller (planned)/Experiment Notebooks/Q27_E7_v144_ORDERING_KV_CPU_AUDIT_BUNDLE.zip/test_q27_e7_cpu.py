import os,json,ast,zipfile,hashlib,tempfile,types,time,traceback, pathlib, collections,math
p=pathlib.Path(__file__).resolve().parent
with zipfile.ZipFile(p/'Q27_DIRECTION_QUESTION_FOR_GPT_2026-10-12.zip') as z:orig=json.loads(z.read('notebooks/Q27-XHIGH-v1_4_4.ipynb'))
e7=json.loads((p/'Q27-XHIGH-v1_4_4_E7_CODEX_ORDER_KV_CONTROLLER.ipynb').read_text())
def code(n,i):return ''.join(n['cells'][i]['source'])
for i in range(9):
 if i==3 or i==5 or i==1:
  assert code(orig,i)==code(e7,i), 'primary tokenizer/install/parser changed'
for i,c in enumerate(e7['cells']):
 if c['cell_type']=='code':compile(code(e7,i), f'cell_{i}', 'exec')
print('PASS source freeze and cell syntax')

# verify exact donor priority compiled function and stable ties and priority task ordering.
donor=json.load(open(p/'arc-2026d-with-codex (24).ipynb'))
s=''.join(donor['cells'][6]['source']); a=s.index('def get_puzzle_priority'); b=s.index('\ndef local_worker',a)
donor_priority=s[a:b]
s4=code(e7,4); a=s4.index('def get_puzzle_priority'); b=s4.index('\n# Sort on',a)
assert donor_priority.strip()==s4[a:b].strip(), 'priority changed'
import numpy as np
ns={'np':np}
exec(donor_priority,ns)
f=ns['get_puzzle_priority']
# Two intentional equal-priority objects retaining insertion order
z={'train':[{'input':[[0]],'output':[[0]]}], 'test':[{'input':[[0]]}]}
d={'z':z,'a':z,'d':{'train':[{'input':[[0]*21 for _ in range(21)],'output':[[0]*21 for _ in range(21)]}],'test':[{'input':[[0]]}]}}
ordered=sorted(d,key=lambda k:f(k,d));assert ordered[:2]==['z','a'],ordered
print('PASS exact Codex donor function, stable ties')

# Extract controller definitions from actual E7 notebook source only.
s7=code(e7,7)
start=s7.index('E7_REQUIRED_METRICS =')
stop=s7.index('\n_E7_PREFERRED_RECIPE =',start)
ctl_source=s7[start:stop]
now=10000.0
ns={
 'math':math,'deque':collections.deque,'Counter':collections.Counter,
 'NOTEBOOK_T0':0.0,
 'Q27X_KV_EXTRA_THRESHOLD':0.62,
 'Q27X_KV_PROJECTED_CEILING':0.82,
 'Q27X_KV_EMERGENCY':0.90,
}
exec(ctl_source,ns)
Parser=ns['e7_parse_metrics']; C=ns['E7KVAdmission']
REQUIRED=ns['E7_REQUIRED_METRICS']
def sample(kv=.30,run=16,waiting=0,preempt=0):
 return [{'name':name,'value':x,'labels':{'engine':'0','model_name':'Q27'}}
         for name,x in zip(REQUIRED.values(),(kv,run,waiting,preempt))]
assert Parser(sample())=={'kv':.3,'running':16,'waiting':0,'preemptions':0}
assert Parser(sample()[:-1]) is None
assert Parser(sample()+[sample()[0]]) is None
assert Parser([dict(sample()[0],value=float('nan'))]+sample()[1:]) is None
assert Parser([dict(sample()[0],labels={'engine':'1'})]+sample()[1:]) is None

# Real log metric snapshots
with zipfile.ZipFile(p/'Q27_DUAL_v2_GPU_EVAL12_RESULT_FOR_GPT_2026-10-12.zip') as z:
 logs=json.loads(z.read('run_output/q27x/vllm_metrics.json'))
parsed=[Parser(r['metrics']) for r in logs]
assert sum(x is not None for x in parsed)>15,(len(logs),sum(x is not None for x in parsed))
print('PASS actual-vLLM telemetry replay',sum(x is not None for x in parsed),'/',len(parsed))

def make(mode='adaptive',base=16,engine=20,extra=18):
 return C(mode=mode,baseline_cap=base,engine_cap=engine,extra_cap=extra,poll_sec=12,cooldown_sec=120,kv_tokens=1353600)

def decide(c,active,now,deadline=11000):
 return c.decide(now=now,active_count=active,deadline=deadline,next_prompt_tokens=5000)

c=make('off'); assert decide(c,15,now)==(True,'baseline');assert decide(c,16,now)==(False,'fixed_baseline')
c=make('shadow');c.observe(sample(),now,0.1);assert decide(c,15,now)[0];assert decide(c,16,now)==(False,'shadow_only') and c.stats['shadow_would_admit']==1
c=make();assert not decide(c,16,now)[0];c.observe(sample(),now,0.1);assert decide(c,16,now)[0];c.admitted('a#0',now,'adaptive_extra',17);assert not decide(c,17,now)[0];c.observe(sample(.31,run=17),now+12,0.1);assert decide(c,17,now+12)[0];assert not decide(c,18,now+12)[0]
print('PASS baseline16/shadow/adaptive17-18/one-extra-per-snapshot')

c=make();c.observe(sample(.75),now,0.1);assert not decide(c,16,now)[0]
c=make();c.observe(sample(),now,0.1);c.observe(sample(.32,preempt=1),now+12,.1);assert not decide(c,16,now+12)[0];assert c.frozen_expansion
c=make();c.observe(sample(),now,0.1);c.transition(now+1);assert not decide(c,16,now+2)[0];c.observe(sample(),now+12,.1);assert decide(c,16,now+12)[0]
c=make();c.observe(sample(),now,0.1);assert not decide(c,16,now+24)[0]
c=make();c.observe(sample(.94),now,.1);assert not decide(c,15,now)[0]
c=make();c.observe(sample(.94,run=0),now,.1);assert decide(c,0,now)[0] # avoid deadlocking empty engine
print('PASS high KV/preemption/cooldown/phase transition/stale metrics/emergency')

# Basic end-to-end mock stage with base and E7 OFF using identical simulated LLM deltas.
class T:
 def encode(self,x,add_special_tokens=False):return [1]
 def decode(self,toks,skip_special_tokens=False):return '1'
class Engine:
 def __init__(self):self.req={};self.seen=[]
 def add_request(self,rid,prompt,params):
  if rid in self.req:raise RuntimeError('duplicate '+rid)
  self.req[rid]=(prompt,params);self.seen.append(rid)
 def abort_request(self,ids):
  for rid in ids:self.req.pop(rid,None)
 def step(self):
  a=list(self.req)
  for id in a:self.req.pop(id)
  return [types.SimpleNamespace(request_id=rid,outputs=[types.SimpleNamespace(token_ids=[555,101],finish_reason='stop')],finished=True) for rid in a]
class Params:
 def __init__(self,max_tokens,seed):self.max_tokens=max_tokens;self.seed=seed

def run_one(e7mode, admission_order=None):
 with tempfile.TemporaryDirectory() as td:
  out=pathlib.Path(td)/'q27x';out.mkdir()
  units=[f't{i}#0' for i in range(5)]
  ch={f't{i}':{'train':[],'test':[{'input':[[0]]}]} for i in range(5)}
  n={
    'OUT':out,'RECORDS_PATH':out/'records.jsonl', 'time':time,'json':json,'math':math,'Counter':collections.Counter,'deque':collections.deque,
    'TRACE':[], 'NOTEBOOK_T0':0.0,'RERUN':True,'SUBMISSION_PATH':pathlib.Path(td)/'submission.json',
    'HARD_STOP':time.perf_counter()+300,'DRAIN_DEADLINE':time.perf_counter()+200,'ADMIT_DEADLINE':time.perf_counter()+100,
    'ENGINE_READY':True,'ENGINE_INFO':{'actual_max_num_seqs':3,'kv_tokens':1353600,'selected_recipe_index':0,'kv_cache_dtype':'fp8_e4m3','speculative':{'method':'mtp','num_speculative_tokens':3},'prefix_caching':True,'prefix_caching_resolved':True,'attention_backend_resolved':'FLASHINFER'},
    'MAX_NUM_SEQS':3,'CONCURRENCY':3,'Q27X_KV_MODE':'off','Q27X_KV_EXTRA_CAP':18,'Q27X_KV_POLL_SEC':12,'Q27X_KV_COOLDOWN_SEC':120,
    'Q27X_KV_EXTRA_THRESHOLD':.62,'Q27X_KV_PROJECTED_CEILING':.82,'Q27X_KV_EMERGENCY':.9,
    'KV_CACHE_DTYPE':'fp8_e4m3','SPECULATIVE_CONFIG':{'method':'mtp','num_speculative_tokens':3},'ENABLE_PREFIX_CACHING':True,
    'GEN_TOKENS_TOTAL':0,'UNITS':units,'PROMPT_IDS':{uid:[1] for uid in units},'P1_CAPS':{uid:49152 for uid in units},
    'UNIT_TASK':{uid:uid.split('#')[0] for uid in units},'UNIT_Q':{uid:0 for uid in units},
    'UNIT_INDEX':{uid:i for i,uid in enumerate(units)},'CHALLENGES':ch,'TASK_IDS':list(ch),'test_challenges':ch,
    'SEED':20261005,'THINK_CLOSE_ID':555,'EOS_IDS':{2},'STOP_IDS':[555], 'MAX_MODEL_LEN':81920,
    'ANSWER_MAX_TOKENS':8192,'DRAIN_ANSWER_MAX_TOKENS':8192,'REASONING_EFFORT':'xhigh',
    'LOG_EVERY_SEC':100000,'tokenizer':T(),'engine':Engine(),
    'make_params':lambda cap,seed:Params(cap,seed),
    'parse_grid':lambda text:[[1]],
    'make_attempts':lambda uid,grid:{'attempt_1':grid,'attempt_2':[[0]],'src_1':'model','src_2':'test_input'},
    'score_unit':lambda uid,att:None,
    'write_json_atomic':lambda p,obj:pathlib.Path(p).write_text(json.dumps(obj)),
    'identity_submission':lambda ch:{tid:[{'attempt_1':q['input'],'attempt_2':q['input']} for q in task['test']] for tid,task in ch.items()},
    'metrics_snapshot':lambda:sample(run=0,kv=.10),
    'ORDER_ADMIT_RANK':{uid:i for i,uid in enumerate(units)},'CODEX_PRIORITY_TIERS':{uid.split('#')[0]:1 for uid in units},
    'CODEX_ORDERED_TASKS':list(ch),'Q27X_ORDERING':bool(admission_order), 'schedule_units':lambda:(admission_order if admission_order is not None else units),
    'WORKING':pathlib.Path(td),'PROFILE':'EVAL12','CONFIG':{},'P':{},'SKIPPED':{},'N_HIDDEN_UNITS':5,
    'traceback':traceback,
  }
  e = n['engine']
  if e7mode:
   exec(code(e7,7),n)
  else:
   exec(code(orig,7),n)
  assert n['SCHED']['error'] is None,n['SCHED']['error']
  assert len(n['FINAL'])==5
  assert len(e.seen)==5 and len(set(e.seen))==5
  return n['FINAL'],e.seen
# Note full-cell E7 eval takes actual mocked ~? fast.
a,aa=run_one(False);b,bb=run_one(True)
assert a==b and aa==bb
print('PASS integrated original-vs-E7-OFF fake-engine regression (5/5 units, identical requests/outputs)')
custom=[f't{i}#0' for i in (4,3,2,1,0)]
_,seen=run_one(True,custom)
assert seen==[f'{uid}|1' for uid in custom],seen
print('PASS integrated ordering-enabled queue across five distinct UIDs')
print('ALL E7 CPU CATEGORIES PASS')

# Startup ladder smoke: 20-cap preferred recipe fails, 16-cap SAME recipe succeeds.
c6=code(e7,6)
ladder_start=c6.index('# E7: isolate engine max-num-seqs')
ladder_stop=c6.index('\nENGINE_READY = llm is not None',ladder_start)
segment=c6[ladder_start:ladder_stop]
class Startup:
 def __init__(self,**kw):
  startup_calls.append((kw['max_num_seqs'], kw['attention_config']['backend'], kw.get('kv_cache_dtype'), kw.get('speculative_config'),kw['enable_prefix_caching']))
  if kw['max_num_seqs']==20:raise RuntimeError('simulated capacity initialization failure')
startup_calls=[]
seed={'MAX_NUM_SEQS':20,'_LADDER':[('fp8_e4m3',{'method':'mtp','num_speculative_tokens':3},'FLASHINFER',True),('fp8_e4m3',None,'TRITON_ATTN',False)],
      'time':time,'LLM':Startup,'ENGINE_CONFIG':{'max_num_seqs':20,'model':'mock'},'json':json,
      'ENGINE_INFO':{'attempts':[],'fatal':None},'CUDA_LINK':{},'_kill_child_processes':lambda:{'found':0},
      '_wait_gpu_release':lambda:{'released':True},'_engine_smoke':lambda obj:16,'os':os,'gc':__import__('gc')}
exec(segment,seed)
assert startup_calls[0][0]==20 and startup_calls[1][0]==16
assert all(x[1:]==startup_calls[0][1:] for x in startup_calls[:2]),startup_calls
assert seed['ENGINE_INFO']['actual_max_num_seqs']==16
assert seed['ENGINE_INFO']['selected_recipe_index']==0
print('PASS preferred 20-cap -> same-recipe 16-cap fallback, resolved-cap reported')

# Failed admission should not mutate host STATE. Source-level function mock.
source=code(e7,7)
start=source.index('def admit(uid):');end=source.index('\ndef start_phase2(',start)
namespace={'STATE':{},'PROMPT_IDS':{'x#0':[1,2]},'P1_CAPS':{'x#0':49152},'SEED':20261005,
           'UNIT_INDEX':{'x#0':0},'SCHED':{'admitted':0},'time':time,
           '_req':lambda uid,p:f'{uid}|{p}','make_params':lambda *args:args}
class BadEngine:
 def add_request(self,*args):raise RuntimeError('injected add_request failure')
 def abort_request(self,ids):assert ids==['x#0|1']
namespace['engine']=BadEngine()
exec(source[start:end],namespace)
try:namespace['admit']('x#0');raise AssertionError('error not propagated')
except RuntimeError as exc:assert 'injected' in str(exc)
assert namespace['STATE']=={} and namespace['SCHED']['admitted']==0
print('PASS add_request exception preserves STATE and UID candidate')
