# Experiment 7 — Q27-XHIGH v1.4.4 DIRECT + Exact Codex Ordering + Guarded KV Admission

**Built:** 2026-10-12. **Status:** CPU-validated research notebook; **NOT GPU-validated**. Do not submit to the hidden leaderboard without separate approval and 4×L4 pilot verification.

## Frozen source and auditability

- Base is the **original** `Q27-XHIGH-v1_4_4.ipynb` from `Q27_DIRECTION_QUESTION_FOR_GPT_2026-10-12.zip`, not Dual Answer v2. Base SHA256: `959959806170960c665249362fe74bfb5678708b0183976ea58e05535d5fd56e`.
- Exact donor priority copied, without rewriting `get_puzzle_priority()`, from `arc-2026d-with-codex (24).ipynb`, `starter.py`. Source SHA256: `3f6536e80d445389da50ed61b3c4b80edc05ff25989aa1ecf7fdef0626196230`.
- Codex reference v2 supplies the same priority AST. The original challenge JSON insertion order is preserved for stable priority ties; in EVAL mode the tasks are filtered **after** retaining the full challenge-file ordering.
- Original tokenizer and offline install code (notebook cell indices 1 and 3), and grid parsing/scoring (cell index 5), are unmodified. Prompt wording, seed mapping, temperature/top_p/top_k, MTP3, FP8-KV requested recipe, maximum thinking of 49,152, answer allowance 8,192, and forced close remain unchanged.
- **Existing base behavior:** previously `phase1_cap()` silently reduced thinking for oversized prompts. This version explicitly skips requests that cannot fit the full 49,152 tokens plus reserved answer/context, leaving the valid fallback. Ordinary EVAL12 prompts were below this edge case.
- This is DIRECT v1.4.4: **there is NO Dual Answer v2 new second-inference stage**. ARC `attempt_2` retains the original v1.4.4 fallback (identity or mirror).

## Kaggle configuration: important

The notebook accepts these env vars; configure them **before Cell 1 configuration runs**. To set them in the notebook, insert the desired lines into the start of Cell 0 after `import os`, before executing the remaining cells:

```python
# E7-A: Codex ordering ONLY (safe first experiment)
os.environ['Q27X_ORDERING'] = '1'
os.environ['Q27X_MAX_NUM_SEQS'] = '16'
os.environ['Q27X_KV_MODE'] = 'off'

# E7-B1: engine 20-cap probe while the app STILL admits at most 16
# os.environ['Q27X_ORDERING'] = '0'
# os.environ['Q27X_MAX_NUM_SEQS'] = '20'
# os.environ['Q27X_KV_MODE'] = 'shadow'

# E7-B2: adaptive 17–18 expansion, only with explicit GPU probe approval
# os.environ['Q27X_ORDERING'] = '0'
# os.environ['Q27X_MAX_NUM_SEQS'] = '20'
# os.environ['Q27X_KV_MODE'] = 'adaptive'
# os.environ['Q27X_KV_EXTRA_CAP'] = '18'

# E7-C1: COMBINED Codex ordering + adaptive KV controller
# os.environ['Q27X_ORDERING'] = '1'
# os.environ['Q27X_MAX_NUM_SEQS'] = '20'
# os.environ['Q27X_KV_MODE'] = 'adaptive'
# os.environ['Q27X_KV_EXTRA_CAP'] = '18'
```

**Unmodified new-notebook defaults:** `Q27X_ORDERING=1`, `Q27X_MAX_NUM_SEQS=16`, `Q27X_KV_MODE=shadow`, `Q27X_KV_EXTRA_CAP=18`. These give exact Codex ordering plus telemetry/decisions without extra GPU admissions. They are intentionally safe, not an already-activated 18-slot pilot.

A/B configurations, with the same workload and deadline:

| Arm | ORDERING | ENGINE CAP | KV MODE | EXTRA CAP | Purpose |
|---|---:|---:|---|---:|---|
| B0 | 0 | 16 | off | 16 | Original v1.4.4 schedule |
| A1 | 1 | 16 | off | 16 | Exact Codex task ordering |
| B1 | 0 | 20 | shadow | 18 | Engine cap overhead + shadow forecast; maximum active still 16 |
| B2 | 0 | 20 | adaptive | 18 | Guarded adaptive 17–18 |
| B2-fixed | 0 | 20 | fixed | 18 | Guarded observed-KV 18-cap comparator, not an unguarded fixed18 |
| C1 | 1 | 20 | adaptive | 18 | Combined version **after** A1/B2 validation |

## How the controller works

- At active count less than baseline (normally 16): original admission behavior is preserved, except an explicitly measured KV emergency in active controller modes.
- At 16 active: optional extra requires valid **fresh** vLLM metrics (real metric names), no engine backlog, matching host/engine active counts, no recent preemption, no unresolved P1→P2 transition, sufficient observed KV headroom and a **heuristic near-term** growth check.
- One extra request can be admitted per fresh metrics snapshot (default 12-second sampling). The pilot cap is **18 active**.
- If metrics are missing, stale, NaN, or ambiguous, extra admissions stop; baseline inference continues. Preemption or a metric counter reset enters cooldown and permanently freezes extra admissions for safety.
- Reported physical KV pool from `(num_gpu_blocks × block_size)` is used as a rough charge for new prompt tokens. This is **not** an exact physical capacity model for hybrid GDN/Mamba cache. The forecast is not a guaranteed memory safety bound.
- If the 20-cap preferred recipe fails at engine startup, it retries the **same** fp8+MTP+attention+prefix recipe at cap 16, then historical fallback recipes, logging each trial. If engine cap or recipe is not preferred, adaptive expansion is disabled and downgraded to shadow.
- The scheduler atomically preserves queue membership until engine registration succeeds. Failed request registration aborts and stops safely; it does not blindly retry a possibly registered ID.

## Source integration

Notebook **cell 1** (code cell index 2): E7 flags and reporting.

Notebook **cell 3** (code cell index 4): exact donor function, original file-order preservation, ordered unit queue, full-thinking preflight.

Notebook **cell 5** (code cell index 6): 20→16 same-recipe fallback and app baseline cap.

Notebook **cell 6** (code cell index 7): KV parser/controller, transactional admission, phase-transition guard, telemetry and ordering application.

Notebook **cell 7** (code cell index 8): new report fields. All original notebook code can be inspected in `Q27_E7_SOURCE_DIFF.patch`.

## Artifacts generated by the notebook at runtime

- `submission.json`: valid original output schema, guaranteed fallback.
- `q27x/records.jsonl`: per-unit status, answer provenance and E7 queue rank/tier.
- `q27x/run_report.json`: original score/performance fields and E7 configuration.
- `q27x/kv_admission_report.json`: controller counters, admission events, cooldown, metric poll times.
- `q27x/kv_telemetry.json`: latest measured KV/engine active samples and poll latency.
- `q27x/vllm_metrics.json`: original coarse vLLM metrics windows.

**EVAL12 caveat:** base notebook's `submission.json` is the identity fallback for the unseen test challenges, even in an interactive EVAL. EVAL exact-hit reporting comes from `run_report.json`; don't score the identity fallback file as if it held the evaluated model predictions.

## CPU tests and evidence

Unzip this bundle, then run `python test_q27_e7_cpu.py`. The test script uses only local sources included in the bundle.

Validated categories:

1. Notebook syntax and original tokenizer/parser source preservation.
2. Exact donor function and stable tie semantics.
3. **31/31 actual GPU vLLM metrics snapshots** parsed from the previous Dual Answer v2 evidence bundle.
4. Baseline-16 and shadow/adaptive 17–18 decisions with one extra per fresh snapshot.
5. Missing / NaN / duplicate / wrong-label metrics fail closed.
6. Measured high KV, counter increment, cooldown, phase transitions, stale metrics and empty-engine liveness.
7. Original-vs-E7-OFF whole fake-engine scheduler for five units has identical request order/output.
8. Ordering enabled schedules five units in the prescribed order.
9. Simulated preferred 20-cap engine startup fails and 16-cap same-recipe retry succeeds.
10. Simulated `add_request()` failure does not mutate STATE/admitted counts.

These are **CPU/synthetic-source tests**. They do not prove 4×L4 GPU startup, preemption safety, real throughput, or leaderboard improvement.

## GPU GO/NO-GO gates (require separate user authorization)

**G0:** Original A1 16-cap ordering-only interactive EVAL. Verify no unexpected source changes, 49,152-cap and final artifact validity.

**G1:** B1 20-cap engine with 16 app admissions, compare startup time, measured KV pool, MTP recipe and throughput vs matching A/B reference. Large KV-pool regression or engine fallback is a NO-GO for 18-slot expansion.

**G2:** B2 short/mixed then long input 17–18 admission, stable GPU, no OOM/preemptions, higher completed output rate than fixed16. **The user's evidence that hidden test puzzles are easier than EVAL12 should inform workload design, not an assumed exact 2× token-length ratio.**

**G3:** Only after A1/B2 pass, C1 combined with Codex ordering + adaptive admissions. Keep the original 49,152 thinking/8,192 answer configuration and submit only with explicit approval.

No Kaggle run, code push, or submission was performed when building this artifact.

## Two separately labeled notebooks in the bundle

- `Q27-XHIGH-v1_4_4_E7_CODEX_ORDER_KV_CONTROLLER.ipynb` — **safe development version**: Codex ordering ON, engine16, KV shadow mode. Use first.
- `Q27-XHIGH-v1_4_4_E7_CODEX_ORDER_KV_COMBINED_PILOT.ipynb` — **combined experimental pilot**: Codex ordering ON, engine20, active guarded KV admission up to 18. GPU/hidden safety has **not** been demonstrated. **Do not run this version before the 20-cap B1 probe is approved and passes.**

Both are based on the original v1.4.4 DIRECT notebook. The combined pilot differs from the safe version only in the documented cap/mode defaults and banner metadata; it is not a new model or a v2 Dual Answer notebook. Override flags in Cell 0 as described above to choose any A/B arm.
