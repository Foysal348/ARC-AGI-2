# STAGE MANAGER (session 16, owner's request): rounds 1, 2 and 3 of the run in ONE harness process, at the same time.
# Started by step 8 with the harness's python: `python stage_manager.py settings.json`. Writes status.json every few seconds (step 8 prints it)
# and runs.json at the end (step 8 merges the attempts from it).
#   round 1: every task, as it is.
#   round 2: a task whose round-1 run ended WITHOUT a final answer runs again in a new conversation, transposed ("T"; "P" = as it is can be
#            added). Session 17 (owner): also when round 1 had a check() passing every training example but gave no answer (s16: 6 of 10 such
#            functions were wrong or half right on the test). Note: round 1's best function and code (with the orientation it was written
#            for); if that function passes every training example, the note asks to check it on the test inputs and confirm or fix it,
#            otherwise to work breadth-first.
#   round 3: a task whose round-1 and round-2 runs all ended without a final answer runs once more, mirrored left-right ("F"), with the best
#            function and code of each earlier run. Each round builds on the ones before. (S["only_final_ends"] = False: s16's rule, where a
#            100% check() also ended a task.)
# SCHEDULING: a free slot takes a queued round-1 run first, else a queued round-2 run, else a queued round-3 run (owner, session 16).
# SECOND TRY (S["second_try"], session 17, owner, Kaggle; default off): no rounds; every task also gets an independent try 2 ("<id>_2": the
#   same grids, a new conversation, no note), queued from the start as a round-2 run. Round 1 first as above, so a try 2 starts only when
#   no try 1 is queued. Among the queued tries 2: tasks whose try 1 ended without a final answer first, then tasks whose try 1 still runs,
#   then tasks whose try 1 gave a final answer (in the order they were queued within each group).
# BUDGET: every run stops at the same token limit (ARC_MAX_GEN_TOKENS). All runs together get TOTAL_TOKEN_BUDGET decoded tokens. Every round-1
# task keeps its full limit reserved until it ends (round 1 always goes first); a round-2/3 run starts only when a free slot exists AND
# the budget minus (tokens of ended runs + max(used, limit) of running runs + the limit for every round-1 task not started yet) is at
# least one limit. A round-1 task that ends early gives its unused tokens back to rounds 2 and 3.
import asyncio, glob, json, logging, os, re, signal, sys, time
from pathlib import Path

S = json.load(open(sys.argv[1]))
LIMIT = int(S["limit"])
TOTAL = int(S["total_budget"])
CONC = int(S["concurrency"])
ROUND2 = list(S["round2_variants"])        # subset of ["P", "T"]
ROUND3 = list(S["round3_variants"])        # subset of ["F"]
assert set(ROUND2) <= {"P", "T"} and set(ROUND3) <= {"F"}, (ROUND2, ROUND3)
OUT = {1: S["out1"], 2: S["out2"], 3: S["out3"]}
SUB = {1: S["sub1"], 2: S["sub2"], 3: S["sub3"]}
NOTES = S["notes_file"]
STATUS = S["status_file"]
ROUND_OF = {"": 1, "P": 2, "T": 3, "F": 3, "2": 2, "3": 3}   # session 18b: "T" = the transposed try 3 | session 22: "3" = the plain try 3
ONLY_FINAL = bool(S.get("only_final_ends", False))   # session 17: only a final answer ends a task
SECOND_TRY = bool(S.get("second_try", False))       # session 17 (owner, Kaggle): an independent try 2 per task instead of rounds
assert not (SECOND_TRY and (ROUND2 or ROUND3)), "second_try replaces the rounds: round2_variants and round3_variants must be empty"
THIRD_TRY = bool(S.get("third_try", False))        # session 18b (owner): transposed try 3 for tasks whose try 1 gave no final answer
TRY3_MIN_LEFT_S = 60 * float(S.get("try3_min_left_min", 60))
assert not THIRD_TRY or SECOND_TRY, "third_try needs second_try"
# session 17 (Kaggle): per-round token limits written for the harness (ARC_RUN_LIMITS file; 0 = no limit, only the deadline), no token
# budget (total_budget 0: time decides), a pause file (while it exists no run starts: a vLLM server is being restarted), an absolute stop time.
LIMITS_FILE = S.get("limits_file")
ROUND_LIMIT = {int(r): int(v) for r, v in (S.get("round_limits") or {}).items()}
PAUSE_FILE = S.get("pause_file")
STOP_EPOCH = S.get("stop_epoch")
BUDGET_ON = TOTAL > 0
_STOP = []                                   # SIGTERM from the notebook: stop like at the time limit (runs cancelled, runs.json written)
signal.signal(signal.SIGTERM, lambda *_: _STOP.append(1))
assert not LIMITS_FILE or set(ROUND_LIMIT) == {1, 2, 3}, "limits_file needs round_limits for rounds 1, 2 and 3"

from dotenv import load_dotenv
from arcagi2.evaluation.evaluate import puzzle_worker
from arcagi2.solver.config import SOLVER_CONFIGS
from arcagi2.utils.logging_utils import setup_infra_logger_console_handler

tp = lambda g: [list(r) for r in zip(*g)]
fl = lambda g: [list(r)[::-1] for r in g]
TRANSFORM = {"": None, "P": None, "T": tp, "F": fl, "2": None, "3": None}     # each is its own inverse: the same function maps answers back

STEPS = ("This time work breadth-first:\n"
         "1. Look at the examples and write down 4-5 DIFFERENT candidate rules, a few lines each. Do not check any of them by hand.\n"
         "2. Write each rule as a function and run them all through check() in one python call.\n"
         "3. Continue from the rule with the best check() result, using its list of wrong cells. If none comes close, write new "
         "candidate rules that differ from the ones you tried.\n"
         "Never verify a rule cell by cell in your thinking: check() does that exactly and costs far fewer tokens.")
ORIENT = {"": "the original grids", "P": "the original grids", "T": "the original grids transposed (rows and columns swapped)",
          "F": "the original grids mirrored left-right (each row reversed)"}
ORDINAL = {2: "a second", 3: "a third"}
# HYBRID INFORMED TRY 2 (owner, session 18b): try 2 waits until its try 1 has ended. Try 1 gave a final answer -> NOTE_ALT (find a
# different rule); no final -> a fresh start without a note (INFORMED_NEW = True adds NOTE_NEW instead; RTX: no measurable effect).
INFORMED_TRY2 = False              # session 22 (owner): no more 'evolve style': try 2 is plain and queued from the start
INFORMED_NEW = False
NOTE_ALT = ("[Note from the harness] This is a second attempt at this puzzle. An earlier attempt found a rule whose function reproduces EVERY "
            "training example; its code is below. A rule can fit every training example and still be wrong on the test input(s): it may miss "
            "a case that only a test input shows. Find a DIFFERENT rule that also reproduces every training example and would give a different "
            "output on at least one test input, and give that as your final answer. Do not submit the earlier rule again.\n{earlier}")
NOTE_NEW = ("[Note from the harness] This is a second attempt at this puzzle. An earlier attempt used its whole budget without finding a rule "
            "that reproduces every training example. Do not follow the same route: find a different rule.\n{earlier}")
NOTE = ("[Note from the harness] This is {nth} attempt at this puzzle. {prev} without finding a rule that reproduces every training example. "
        "You see {orient}; {saw}\n{earlier}\n{ideas}\n" + STEPS)
NOTE_CONFIRM = ("[Note from the harness] This is {nth} attempt at this puzzle. {prev} You see {orient}; {saw}\n{earlier}\n"
                "A function can reproduce every training example and still be wrong on the test input(s). First check that its rule really "
                "explains every training example, then look at what it does on each test input: write it for the grids you see, run check() and "
                "look at the test outputs with show(). If it is right, give it as your final answer. If it misses something a test input needs, "
                "fix it, run check() again and give the fixed version as your final answer.")
PREV_CONFIRM = {2: ("An earlier attempt wrote a function that reproduces EVERY training example, but its budget of {k}K tokens ran out before it "
                    "gave a final answer.", "the earlier attempt may have seen the grids differently, so its code works on the grids IT saw."),
                3: ("The earlier attempts each used their whole budget of {k}K tokens without giving a final answer; at least one of them wrote a "
                    "function that reproduces EVERY training example.", "the earlier attempts saw the grids differently, so their code works on "
                    "the grids THEY saw.")}
PREV = {2: ("An earlier attempt used its whole budget of {k}K tokens", "the earlier attempt may have seen the grids differently, so its code works "
            "on the grids IT saw.", "Its idea is incomplete or wrong, so do not just repeat it."),
        3: ("The earlier attempts each used their whole budget of {k}K tokens", "the earlier attempts saw the grids differently, so their code "
            "works on the grids THEY saw.", "Their ideas are incomplete or wrong, so do not just repeat them.")}


def log(msg):
    logging.getLogger("arcagi2.evaluation.evaluate").info(f"STAGE {msg}")


def view(task, f):
    if f is None:
        return task
    return {"train": [{"input": f(e["input"]), "output": f(e["output"])} for e in task["train"]],
            "test": [{"input": f(e["input"])} for e in task["test"]]}


def _grid(g):
    return isinstance(g, list) and bool(g) and all(isinstance(r, list) and r and all(isinstance(v, int) and not isinstance(v, bool) for v in r) for r in g) \
        and len({len(r) for r in g}) == 1


class Run:
    def __init__(self, pid, var):
        self.pid, self.var, self.rid = pid, var, pid + ("_" + var if var else "")
        self.round = ROUND_OF[var]
        self.state = "queued"           # queued | running | ended | skipped
        self.task = None
        self.folder = None              # the sample folder (out/<uid>/<sample>/)
        self.used = 0
        self.final = False              # a final answer (attempt_1 grid in the round's submission)
        self.full = False               # a check() record passing every training example
        self.t0 = self.t1 = None

    def find_folder(self):
        if self.folder:
            return self.folder
        for m in glob.glob(f"{OUT[self.round]}/*/metadata.json"):
            try:
                if json.load(open(m))["puzzle_id"] == self.rid:
                    subs = [d for d in glob.glob(os.path.join(os.path.dirname(m), "*/")) if os.path.exists(d + "metadata.json")]
                    if subs:
                        self.folder = subs[0]
                        return self.folder
            except Exception:
                continue
        return None

    def read_used(self):
        f = self.find_folder()
        if f and os.path.exists(f + "run.log"):
            g = re.findall(r"V3_GEN (\d+)", open(f + "run.log", errors="replace").read())
            self.used = int(g[-1]) if g else 0
        return self.used

    def records(self):
        f = self.find_folder()
        try:
            return json.load(open(f + "check_attempts.json")).get("records") or [] if f else []
        except Exception:
            return []

    def finish(self):
        self.read_used()
        try:
            sub = json.load(open(f"{SUB[self.round]}/submission.json"))
        except Exception:
            sub = {}
        self.final = any(isinstance(e, dict) and _grid(e.get("attempt_1")) for e in (sub.get(self.rid) or []))
        self.full = any(r.get("n") and r.get("ok") == r.get("n") for r in self.records())

    @property
    def solved_train(self):
        """the task needs no next round: a final answer (session 17), or (s16 rule) also a check() passing every training example"""
        return self.final or (self.full and not ONLY_FINAL)


def best(run):
    rs = sorted(run.records(), key=lambda r: (r["ok"] / max(1, r["n"]), r["pct"]), reverse=True) if run else []
    return rs[0] if rs else None


def earlier_text(n, prev, var):
    """one line (+ code) per earlier run of the task: what it saw, its best check() result, its code"""
    r = best(prev)
    saw = ORIENT[prev.var] + (" (the same grids as you)" if ORIENT[prev.var] == ORIENT[var] else "")
    if r is None:
        return f"- Attempt {n} saw {saw}. It never wrote a function that check() could test: it spent its budget checking ideas by hand."
    s = f"- Attempt {n} saw {saw}. Its best function got {r['ok']}/{r['n']} training examples right ({r['pct']}% of the training cells)"
    if r.get("code"):
        return s + ". Its code (for the grids it saw):\n```python\n" + r["code"].rstrip() + "\n```"
    return s + "."


async def main():
    logging.getLogger().setLevel(logging.INFO)
    logging.getLogger("httpx").setLevel(logging.WARNING)
    setup_infra_logger_console_handler(logging.INFO)
    load_dotenv(S["env_file"])
    config = SOLVER_CONFIGS[S["config_name"]]
    config.set_vllm_base_url(S["base_url"])
    for r in (1, 2, 3):
        Path(OUT[r]).mkdir(parents=True, exist_ok=False)
        Path(SUB[r]).mkdir(parents=True, exist_ok=True)
        json.dump({}, open(f"{SUB[r]}/submission.json", "w"))
    fh = logging.FileHandler(f"{OUT[1]}/run.log")           # the main log (step 10 reads the sample errors from it)
    fh.setFormatter(logging.Formatter("%(asctime)s - %(levelname)s - %(message)s"))
    lg = logging.getLogger("arcagi2.evaluation.evaluate")
    lg.addHandler(fh); lg.setLevel(logging.INFO)

    tasks = json.load(open(S["challenge_file"]))
    ids = list(tasks)
    notes = {pid: None for pid in ids}                      # round 1: explicitly no note
    def write_notes():
        tmp = NOTES + ".tmp"
        json.dump(notes, open(tmp, "w")); os.replace(tmp, NOTES)
    write_notes()
    limits = {}                                             # session 17: run id -> its decoded-token limit (written before the run starts)
    def write_limits():
        if LIMITS_FILE:
            tmp = LIMITS_FILE + ".tmp"
            json.dump(limits, open(tmp, "w")); os.replace(tmp, LIMITS_FILE)
    write_limits()

    runs = [Run(pid, "") for pid in ids] + ([Run(pid, "2") for pid in ids] if SECOND_TRY else [])
    by = {(r.pid, r.var): r for r in runs}
    if INFORMED_TRY2:
        for r in runs:                                      # informed try 2: waits until its try 1 has ended
            if r.var == "2":
                r.state = "waiting"
    lock = asyncio.Lock()
    sem = asyncio.Semaphore(10 ** 6)                        # concurrency is decided here, not by the semaphore
    k = ROUND_LIMIT.get(1, LIMIT) // 1000                   # the earlier rounds' budget, for the notes
    t_start = time.time()
    deadline = float(STOP_EPOCH) if STOP_EPOCH else t_start + float(S["time_limit_hours"]) * 3600
    events = []

    def event(msg):
        events.append(f"{(time.time() - t_start) / 60:5.1f} min  {msg}")
        log(msg)

    def start(run):
        if run.var == "2":                             # second try: explicitly no note (a missing note stops the harness)
            t1 = by[(run.pid, "")]
            notes[run.rid] = None
            if INFORMED_TRY2 and t1.state == "ended" and (t1.final or INFORMED_NEW):
                notes[run.rid] = (NOTE_ALT if t1.final else NOTE_NEW).format(earlier=earlier_text(1, t1, ""))
            write_notes()
        elif run.var == "3" and THIRD_TRY:           # try 3 (session 22): an independent PLAIN run, explicitly no note
            notes[run.rid] = None
            write_notes()
        elif run.round > 1:
            prev = [r for r in runs if r.pid == run.pid and r.round < run.round]
            prev.sort(key=lambda r: (r.round, r.var))
            earlier = "\n".join(earlier_text(n, r, run.var) for n, r in enumerate(prev, 1))
            if any(r.full for r in prev):              # session 17: an earlier function fits every training example -> confirm or fix it
                pv, saw = PREV_CONFIRM[min(3, len(prev) + 1)]
                notes[run.rid] = NOTE_CONFIRM.format(nth=ORDINAL[run.round], prev=pv.format(k=k), orient=ORIENT[run.var], saw=saw, earlier=earlier)
            else:
                pv, saw, ideas = PREV[min(3, len(prev) + 1)]
                notes[run.rid] = NOTE.format(nth=ORDINAL[run.round], prev=pv.format(k=k), orient=ORIENT[run.var], saw=saw, ideas=ideas,
                                             earlier=earlier)
            write_notes()
        if LIMITS_FILE:
            limits[run.rid] = ROUND_LIMIT[run.round]
            write_limits()
        run.state, run.t0 = "running", time.time()
        run.task = asyncio.create_task(puzzle_worker(semaphore=sem, lock=lock, config=config, puzzle_id=run.rid,
                                                     puzzle_json=view(tasks[run.pid], TRANSFORM[run.var]),
                                                     evaluation_output_folder=Path(OUT[run.round]),
                                                     submission_file=Path(f"{SUB[run.round]}/submission.json"), num_samples=1))
        event(f"start round {run.round} {run.rid}")

    def committed():
        c = 0
        for r in runs:
            if r.state == "ended":
                c += r.used
            elif r.state == "running":
                c += max(r.read_used(), LIMIT)
            elif r.state == "queued" and r.round == 1:
                c += LIMIT
        return c

    def status(done=False, why=""):
        st = {"time_min": round((time.time() - t_start) / 60, 1), "done": done, "why": why, "limit": LIMIT, "total_budget": TOTAL,
              "paused": bool(PAUSE_FILE) and os.path.exists(PAUSE_FILE), "stop_epoch": deadline,
              "concurrency": CONC, "rounds": {}, "events": events[-12:]}
        used = 0
        for rd in (1, 2, 3):
            rr = [r for r in runs if r.round == rd]
            for r in rr:
                if r.state == "running":
                    r.read_used()
            used += sum(r.used for r in rr)
            st["rounds"][rd] = {s: sum(r.state == s for r in rr) for s in ("waiting", "queued", "running", "ended", "skipped")}
            st["rounds"][rd].update(final=sum(r.final for r in rr if r.state == "ended"), full_check=sum(r.full and not r.final for r in rr if r.state == "ended"),
                                    tokens=sum(r.used for r in rr))
        st["tokens_used"] = used
        st["tokens_committed"] = committed()
        tmp = STATUS + ".tmp"
        json.dump(st, open(tmp, "w")); os.replace(tmp, STATUS)

    def follow_up(run):
        """after a run ends: queue the next round of its task when every run so far failed"""
        pid = run.pid
        if THIRD_TRY and run.round == 1 and not run.final and (pid, "3") not in by:
            nr = Run(pid, "3"); runs.append(nr); by[(pid, "3")] = nr
            event(f"try 1 {pid}: no final answer -> try 3 (plain) queued")
        if run.round == 1 and not run.solved_train and ROUND2:
            for v in ROUND2:
                nr = Run(pid, v); runs.append(nr); by[(pid, v)] = nr
            event(f"round 1 {pid}: no final answer" + (", a full check() to confirm" if run.full else ", no full check()") + f" -> round 2 queued ({'+'.join(ROUND2)})")
        elif run.round == 1 and not run.solved_train and not ROUND2 and ROUND3:
            for v in ROUND3:
                nr = Run(pid, v); runs.append(nr); by[(pid, v)] = nr
            event(f"round 1 {pid}: failed -> round 3 queued (no round 2)")
        elif run.round == 2 and ROUND3:
            r2 = [by[(pid, v)] for v in ROUND2]
            if all(r.state == "ended" for r in r2) and not any(r.solved_train for r in r2):
                for v in ROUND3:
                    nr = Run(pid, v); runs.append(nr); by[(pid, v)] = nr
                event(f"round 2 {pid}: no final answer" + (" (a full check() to confirm)" if any(r.full for r in r2) else "") + " -> round 3 queued")

    why = "all runs ended"
    try:
        while True:
            for r in runs:
                if r.state == "running" and r.task.done():
                    r.state, r.t1 = "ended", time.time()
                    r.finish()
                    event(f"end round {r.round} {r.rid}: {r.used // 1000}K tokens | final answer {'yes' if r.final else 'no'} | full check() {'yes' if r.full else 'no'}")
                    follow_up(r)
                    t2 = by.get((r.pid, "2"))
                    if r.var == "" and t2 is not None and t2.state == "waiting":      # informed try 2 may start now
                        t2.state = "queued"
                        event(f"try 2 of {r.pid} queued " + ("with the different-rule note" if r.final else
                                                             ("with the new-route note" if INFORMED_NEW else "fresh (no note)")))
            if time.time() > deadline or _STOP:
                why = "stopped by the notebook" if _STOP else "time limit"
                break
            paused = bool(PAUSE_FILE) and os.path.exists(PAUSE_FILE)
            free_slots = 0 if paused else CONC - sum(r.state == "running" for r in runs)
            for r in runs:                                   # round 1 first: its tokens are reserved
                if free_slots <= 0:
                    break
                if r.state == "queued" and r.round == 1:
                    start(r); free_slots -= 1
            def extra_order(r):                              # session 22 (owner): every try 2 before any try 3 (try 3 last)
                return r.round                               # 2 = try 2, 3 = try 3; queue order within each
            for r in sorted((r for r in runs if r.state == "queued" and r.round in (2, 3)), key=extra_order):
                if free_slots <= 0:
                    break
                if r.round == 3 and THIRD_TRY and deadline - time.time() < TRY3_MIN_LEFT_S:
                    continue                                 # try 3: not in the last minutes
                if r.state == "queued" and (not BUDGET_ON or TOTAL - committed() >= LIMIT):
                    start(r); free_slots -= 1
            running = [r for r in runs if r.state == "running"]
            queued = [r for r in runs if r.state == "queued"]
            if not running and not queued:
                break
            if not running and queued and not paused:        # nothing runs, nothing can start: the budget is used up
                for r in queued:
                    r.state = "skipped"
                event(f"budget used up: {len(queued)} queued runs skipped")
                why = "token budget used up"
                break
            status()
            await asyncio.sleep(float(S.get("poll_s", 5)))
    finally:
        live = [r for r in runs if r.state == "running"]
        for r in live:
            r.task.cancel()
        if live:
            await asyncio.gather(*[r.task for r in live], return_exceptions=True)
            for r in live:
                r.state, r.t1 = "ended", time.time()
                r.finish()
            event(f"stopped ({why}): {len(live)} running runs cancelled")
        for r in runs:
            if r.state in ("queued", "waiting"):
                r.state = "skipped"
        json.dump([{"pid": r.pid, "var": r.var, "rid": r.rid, "round": r.round, "state": r.state, "used": r.used, "final": r.final,
                    "full": r.full, "folder": r.folder, "minutes": round(((r.t1 or time.time()) - r.t0) / 60, 1) if r.t0 else None} for r in runs],
                  open(S["runs_file"], "w"), indent=1)
        status(done=True, why=why)
        fh.close()


asyncio.run(main())
