from collections import Counter

def solution(grid):
    H = len(grid)
    W = len(grid[0])

    # background = most common colour
    cnt = Counter()
    for row in grid:
        for c in row:
            cnt[c] += 1
    bg = cnt.most_common(1)[0][0]

    # 8-connected components of non-background cells
    seen = [[False] * W for _ in range(H)]
    comps = []
    dirs = [(1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (1, -1), (-1, 1), (-1, -1)]
    for r in range(H):
        for c in range(W):
            if grid[r][c] != bg and not seen[r][c]:
                stack = [(r, c)]
                seen[r][c] = True
                cells = []
                while stack:
                    x, y = stack.pop()
                    cells.append((x, y))
                    for dx, dy in dirs:
                        nx, ny = x + dx, y + dy
                        if 0 <= nx < H and 0 <= ny < W and not seen[nx][ny] and grid[nx][ny] != bg:
                            seen[nx][ny] = True
                            stack.append((nx, ny))
                comps.append({"cells": cells,
                              "colors": sorted({grid[r][c] for r, c in cells})})

    # tile = component made of several colours; stencil = the single-colour component(s)
    multi = [c for c in comps if len(c["colors"]) > 1]
    mono = [c for c in comps if len(c["colors"]) == 1]
    tile = sorted(multi, key=lambda c: (-len(c["colors"]), -len(c["cells"])))[0]

    cells = tile["cells"]
    r0, r1 = min(p[0] for p in cells), max(p[0] for p in cells)
    c0, c1 = min(p[1] for p in cells), max(p[1] for p in cells)
    th, tw = r1 - r0 + 1, c1 - c0 + 1
    pat = [[grid[r][c] for c in range(c0, c1 + 1)] for r in range(r0, r1 + 1)]

    mask = [p for c in mono for p in c["cells"]] or \
           [p for c in multi if c is not tile for p in c["cells"]]

    mr0 = min(p[0] for p in mask)
    mc0 = min(p[1] for p in mask)
    mr = max(p[0] - mr0 for p in mask)
    mc = max(p[1] - mc0 for p in mask)

    out = [[bg] * ((mc + 1) * tw) for _ in range((mr + 1) * th)]
    for (r, c) in mask:
        br, bc = (r - mr0) * th, (c - mc0) * tw
        for i in range(th):
            for j in range(tw):
                out[br + i][bc + j] = pat[i][j]
    return out
