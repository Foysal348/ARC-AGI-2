def solution(grid):
    h = len(grid)
    w = len(grid[0])

    # background = most common colour
    cnt = {}
    for row in grid:
        for v in row:
            cnt[v] = cnt.get(v, 0) + 1
    bg = max(cnt, key=lambda k: cnt[k])

    # 4-connected components of non-background cells
    visited = [[False] * w for _ in range(h)]
    comps = []
    for r in range(h):
        for c in range(w):
            if grid[r][c] != bg and not visited[r][c]:
                col = grid[r][c]
                st = [(r, c)]
                visited[r][c] = True
                cells = []
                while st:
                    x, y = st.pop()
                    cells.append((x, y))
                    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        nx, ny = x + dx, y + dy
                        if 0 <= nx < h and 0 <= ny < w and not visited[nx][ny] and grid[nx][ny] == col:
                            visited[nx][ny] = True
                            st.append((nx, ny))
                comps.append((col, cells))

    # big filled squares
    squares = []
    for col, cells in comps:
        r0 = min(r for r, c in cells); r1 = max(r for r, c in cells)
        c0 = min(c for r, c in cells); c1 = max(c for r, c in cells)
        hh, ww = r1 - r0 + 1, c1 - c0 + 1
        if hh == ww >= 4 and len(cells) == hh * ww:
            squares.append((col, r0, r1, c0, c1))

    # small stencil patterns: cells outside the squares, grouped by colour
    in_sq = [[False] * w for _ in range(h)]
    for col, r0, r1, c0, c1 in squares:
        for r in range(r0, r1 + 1):
            for c in range(c0, c1 + 1):
                in_sq[r][c] = True

    small = {}
    for r in range(h):
        for c in range(w):
            v = grid[r][c]
            if v != bg and not in_sq[r][c]:
                small.setdefault(v, []).append((r, c))

    def bbox_mask(cells):
        cs = set(cells)
        r0 = min(r for r, c in cs); r1 = max(r for r, c in cs)
        c0 = min(c for r, c in cs); c1 = max(c for r, c in cs)
        return [[1 if (r, c) in cs else 0 for c in range(c0, c1 + 1)]
                for r in range(r0, r1 + 1)]

    pat = {}
    for col, cs in small.items():
        cs_set = set(cs)
        seen = set()
        groups = []
        for cell in cs:
            if cell in seen:
                continue
            st = [cell]; seen.add(cell); grp = []
            while st:
                x, y = st.pop(); grp.append((x, y))
                for dx in (-1, 0, 1):
                    for dy in (-1, 0, 1):
                        n = (x + dx, y + dy)
                        if n not in seen and n in cs_set:
                            seen.add(n); st.append(n)
            groups.append(grp)
        # pick the most compact group (the 3x3 stencil)
        groups.sort(key=lambda g: (max(r for r, c in g) - min(r for r, c in g) + 1) *
                                   (max(c for r, c in g) - min(c for r, c in g) + 1))
        pat[col] = bbox_mask(groups[0])

    # output = bounding box of the squares + one background margin
    R0 = max(0, min(s[1] for s in squares) - 1)
    R1 = min(h - 1, max(s[2] for s in squares) + 1)
    C0 = max(0, min(s[3] for s in squares) - 1)
    C1 = min(w - 1, max(s[4] for s in squares) + 1)

    out = [[bg] * (C1 - C0 + 1) for _ in range(R1 - R0 + 1)]

    for col, r0, r1, c0, c1 in squares:
        # fill solid
        for r in range(r0, r1 + 1):
            for c in range(c0, c1 + 1):
                out[r - R0][c - C0] = col
        # carve the matching stencil, centred
        p = pat.get(col)
        if p:
            pr, pc = len(p), len(p[0])
            sr = ((r1 - r0 + 1) - pr) // 2
            sc = ((c1 - c0 + 1) - pc) // 2
            for r in range(r0, r1 + 1):
                for c in range(c0, c1 + 1):
                    rr, cc = r - r0 - sr, c - c0 - sc
                    if 0 <= rr < pr and 0 <= cc < pc and p[rr][cc]:
                        out[r - R0][c - C0] = bg
    return out
