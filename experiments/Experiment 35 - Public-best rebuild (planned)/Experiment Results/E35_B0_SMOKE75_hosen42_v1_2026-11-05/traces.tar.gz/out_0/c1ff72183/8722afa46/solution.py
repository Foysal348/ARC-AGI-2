from collections import Counter

def solution(grid):
    H, W = len(grid), len(grid[0])
    bg = Counter(c for r in grid for c in r).most_common(1)[0][0]

    # 8-connected components of non-background cells (single colour each)
    seen = [[False] * W for _ in range(H)]
    comps = []
    for r in range(H):
        for c in range(W):
            if grid[r][c] != bg and not seen[r][c]:
                col = grid[r][c]
                stack = [(r, c)]
                seen[r][c] = True
                cells = []
                while stack:
                    a, b = stack.pop()
                    cells.append((a, b))
                    for da, db in ((1,0),(-1,0),(0,1),(0,-1),(1,1),(1,-1),(-1,1),(-1,-1)):
                        na, nb = a + da, b + db
                        if 0 <= na < H and 0 <= nb < W and not seen[na][nb] and grid[na][nb] == col:
                            seen[na][nb] = True
                            stack.append((na, nb))
                comps.append((col, cells))

    # the solid shape = biggest component (colour A)
    A, solid_cells = max(comps, key=lambda t: len(t[1]))
    rs = [p[0] for p in solid_cells]
    cs = [p[1] for p in solid_cells]
    r0, c0 = min(rs), min(cs)
    shape_cells = sorted((p[0] - r0, p[1] - c0) for p in solid_cells)
    sh = max(p[0] for p in shape_cells) + 1
    sw = max(p[1] for p in shape_cells) + 1

    # dots = all components of the other colour (colour B)
    dot_comps = [t for t in comps if t[0] != A]
    B = dot_comps[0][0]
    dots = [t[1][0] for t in dot_comps]

    # the template's centre = the lone cell of colour A
    center_comps = [t for t in comps if t[0] == A and len(t[1]) == 1]
    if center_comps:
        center = center_comps[0][1][0]
    else:
        vr = [c[0] for t in dot_comps for c in t[1]]
        vc = [c[1] for t in dot_comps for c in t[1]]
        center = (sum(vr) / len(vr), sum(vc) / len(vc))

    out = [[bg] * W for _ in range(H)]

    def stamp(r, c, color):
        for dr, dc in shape_cells:
            rr, cc = r + dr, c + dc
            if 0 <= rr < H and 0 <= cc < W:
                out[rr][cc] = color

    # copy at the template centre, in the dots' colour
    stamp(r0, c0, B)
    # copies at the dot positions, in the shape's colour
    for (r, c) in dots:
        ur = round((r - center[0]) / 2.0)
        uc = round((c - center[1]) / 2.0)
        stamp(r0 + ur * sh, c0 + uc * sw, A)

    return out
