from collections import deque, Counter

def solution(grid):
    h, w = len(grid), len(grid[0])
    g = [row[:] for row in grid]

    # 8-connected groups of non-background cells
    seen = [[False] * w for _ in range(h)]
    groups = []
    for r in range(h):
        for c in range(w):
            if g[r][c] != 0 and not seen[r][c]:
                q = deque([(r, c)]); seen[r][c] = True; cells = []
                while q:
                    r0, c0 = q.popleft(); cells.append((r0, c0))
                    for dr in (-1, 0, 1):
                        for dc in (-1, 0, 1):
                            if dr == 0 and dc == 0:
                                continue
                            rr, cc = r0 + dr, c0 + dc
                            if 0 <= rr < h and 0 <= cc < w and g[rr][cc] != 0 and not seen[rr][cc]:
                                seen[rr][cc] = True; q.append((rr, cc))
                groups.append(cells)

    for cells in groups:
        cnt = Counter(g[r][c] for r, c in cells)
        if len(cnt) < 2:                      # single-colour object: unchanged
            continue
        frame = max(cnt, key=lambda c: cnt[c])          # outer shell
        F = [p for p in cells if g[p[0]][p[1]] == frame]
        M = [p for p in cells if g[p[0]][p[1]] != frame]  # inner fill
        mcnt = Counter(g[p[0]][p[1]] for p in M)
        fill = max(mcnt, key=lambda c: mcnt[c])

        mr = sum(p[0] for p in M) / len(M)
        mc = sum(p[1] for p in M) / len(M)
        r0 = min(p[0] for p in F); r1 = max(p[0] for p in F)
        c0 = min(p[1] for p in F); c1 = max(p[1] for p in F)

        def edge_extent(d):
            if d == 'up':    xs = [p[1] for p in F if p[0] == r0]
            elif d == 'down':xs = [p[1] for p in F if p[0] == r1]
            elif d == 'left':xs = [p[0] for p in F if p[1] == c0]
            else:            xs = [p[0] for p in F if p[1] == c1]
            return max(xs) - min(xs)

        space = {'up': mr, 'down': (h - 1) - mr, 'left': mc, 'right': (w - 1) - mc}
        cand = [(mr - r0, 'up'), (r1 - mr, 'down'), (mc - c0, 'left'), (c1 - mc, 'right')]
        # side of the frame farthest from the fill = the tip the fill pours out of
        direction = max(cand, key=lambda t: (t[0], -edge_extent(t[1]), space[t[1]]))[1]
        d = {'up': (-1, 0), 'down': (1, 0), 'left': (0, -1), 'right': (0, 1)}[direction]

        if d[0] != 0:
            ext = r0 if d[0] < 0 else r1
            tip = min([p for p in F if p[0] == ext], key=lambda p: (abs(p[1] - mc), p))
        else:
            ext = c0 if d[1] < 0 else c1
            tip = min([p for p in F if p[1] == ext], key=lambda p: (abs(p[0] - mr), p))

        for p in M:
            g[p[0]][p[1]] = 0                 # empty the inside
        rr, cc = tip
        for k in range(1, len(M) + 1):        # line of fill cells out through the tip
            nr, nc = rr + d[0] * k, cc + d[1] * k
            if 0 <= nr < h and 0 <= nc < w and g[nr][nc] == 0:
                g[nr][nc] = fill
            else:
                break
    return g
