def solution(grid):
    """The object is a square frame: a 3x3 arrangement of s x s tiles whose centre
    tile is a hole (background). Each of the 8 tiles is copied one tile outward,
    mirrored across the axis/axes of its direction of movement, and the hole is
    filled with the cell that each surrounding tile faces into the hole (corner
    cells from the corner tiles, edge-middle cells from the edge tiles, and the
    hole centre gets the dominant colour of the object)."""
    g = [list(map(int, row)) for row in grid]
    H, W = len(g), len(g[0])

    # background = most common colour
    cnt = {}
    for row in g:
        for v in row:
            cnt[v] = cnt.get(v, 0) + 1
    bg = max(cnt, key=lambda k: (cnt[k], -k))

    # bounding box of the object
    rs = [r for r, row in enumerate(g) if any(v != bg for v in row)]
    cs = [c for c in range(W) if any(row[c] != bg for row in g)]
    r0, r1 = rs[0], rs[-1] + 1
    c0, c1 = cs[0], cs[-1] + 1
    h, w = r1 - r0, c1 - c0
    sr, sc = h // 3, w // 3          # tile size (rows, cols) = hole size

    def tile(br, bc):
        return [[g[r0 + br * sr + i][c0 + bc * sc + j] for j in range(sc)]
                for i in range(sr)]

    out = [row[:] for row in g]

    def place(R, C, blk):
        for i in range(len(blk)):
            for j in range(len(blk[0])):
                r, cc = R + i, C + j
                if 0 <= r < H and 0 <= cc < W:
                    out[r][cc] = blk[i][j]

    # duplicate each of the 8 tiles outward, mirrored about the direction of motion
    for dr, dc in [(-1, -1), (-1, 0), (-1, 1), (0, -1), (0, 1), (1, -1), (1, 0), (1, 1)]:
        br, bc = 1 + dr, 1 + dc
        blk = [row[:] for row in tile(br, bc)]
        if dr:
            blk = blk[::-1]
        if dc:
            blk = [row[::-1] for row in blk]
        place(r0 + (br + dr) * sr, c0 + (bc + dc) * sc, blk)

    # fill the hole with the inner-facing cells of the 8 tiles
    hr0, hc0 = r0 + sr, c0 + sc
    m, n = sr // 2, sc // 2
    inner = {(0, 0): (sr - 1, sc - 1), (0, 1): (sr - 1, n), (0, 2): (sr - 1, 0),
             (1, 0): (m, sc - 1),                        (1, 2): (m, 0),
             (2, 0): (0, sc - 1), (2, 1): (0, n),         (2, 2): (0, 0)}
    hole  = {(0, 0): (0, 0),      (0, 1): (0, n),         (0, 2): (0, sc - 1),
             (1, 0): (m, 0),                            (1, 2): (m, sc - 1),
             (2, 0): (sr - 1, 0), (2, 1): (sr - 1, n),   (2, 2): (sr - 1, sc - 1)}
    for (br, bc), (i, j) in inner.items():
        hi, hj = hole[(br, bc)]
        out[hr0 + hi][hc0 + hj] = tile(br, bc)[i][j]

    # hole centre = dominant (most frequent) non-background colour of the object
    oc = {}
    for r in range(r0, r1):
        for c in range(c0, c1):
            if g[r][c] != bg:
                oc[g[r][c]] = oc.get(g[r][c], 0) + 1
    dom = max(oc, key=lambda k: (oc[k], -k))
    out[hr0 + m][hc0 + n] = dom
    return out
