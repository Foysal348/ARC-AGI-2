def solution(grid):
    H = len(grid)
    W = len(grid[0])
    g = [row[:] for row in grid]

    # structure colour (the grey frame/comb colour): first non-zero on row 0
    s = next((v for v in g[0] if v != 0), 0)
    frame_left = min(c for c in range(W) if g[0][c] == s)
    frame_right = max(c for c in range(W) if g[0][c] == s)

    # left comb
    left_cells = [(r, c) for r in range(H) for c in range(frame_left) if g[r][c] == s]
    floor_row = max(r for r, c in left_cells)
    floor_min = min(c for r, c in left_cells if r == floor_row)
    floor_max = max(c for r, c in left_cells if r == floor_row)
    teeth = [(c, sum(1 for r in range(floor_row) if g[r][c] == s))
             for c in range(floor_min, floor_max + 1)]
    teeth = [(c, h) for c, h in teeth if h > 0]
    offset = (frame_left + 2) - floor_min

    # erase left structure
    for r in range(H):
        for c in range(frame_left):
            g[r][c] = 0

    # clear the frame interior
    for r in range(1, H - 1):
        for c in range(frame_left + 1, frame_right):
            g[r][c] = 0

    # draw the transferred comb floor
    for c in range(floor_min + offset, floor_max + offset + 1):
        g[floor_row][c] = s

    # rebuild each slot: grey tooth from the floor, then the bar on top, grey remainder
    for c, h in teeth:
        rc = c + offset
        bar = [grid[r][rc] for r in range(H) if grid[r][rc] not in (0, s)]
        col = bar[0] if bar else 0
        L = len(bar)
        space = floor_row - h - 1            # rows available between tooth top and ceiling
        Lp = min(L, space)
        for r in range(floor_row - h, floor_row):
            g[r][rc] = s                      # tooth
        top = floor_row - h - Lp
        for r in range(top, floor_row - h):
            g[r][rc] = col                    # bar pushed up against the tooth
        for r in range(1, top):
            g[r][rc] = s                      # empty space above the bar becomes grey
    return g
