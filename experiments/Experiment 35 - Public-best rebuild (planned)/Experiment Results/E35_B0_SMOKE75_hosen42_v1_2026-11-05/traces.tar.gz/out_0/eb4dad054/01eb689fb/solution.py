from collections import Counter, deque
import itertools

def solution(grid):
    H = len(grid); W = len(grid[0])
    bg = Counter(v for row in grid for v in row).most_common(1)[0][0]

    # 4-connected objects of non-background cells
    seen = [[False]*W for _ in range(H)]
    objs = []
    for r in range(H):
        for c in range(W):
            if grid[r][c] == bg or seen[r][c]:
                continue
            q = deque([(r, c)]); seen[r][c] = True; cells = []
            while q:
                x, y = q.popleft(); cells.append((x, y))
                for dx, dy in ((1,0),(-1,0),(0,1),(0,-1)):
                    nx, ny = x+dx, y+dy
                    if 0 <= nx < H and 0 <= ny < W and not seen[nx][ny] and grid[nx][ny] != bg:
                        seen[nx][ny] = True; q.append((nx, ny))
            color = grid[cells[0][0]][cells[0][1]]
            rs = [p[0] for p in cells]; cs = [p[1] for p in cells]
            r0, r1, c0, c1 = min(rs), max(rs), min(cs), max(cs)
            s = set(cells)
            mask = [[1 if (r, c) in s else 0 for c in range(c0, c1+1)] for r in range(r0, r1+1)]
            objs.append(dict(color=color, cells=cells, r0=r0, r1=r1, c0=c0, c1=c1,
                             mask=mask, nholes=sum(1 for row in mask for v in row if v == 0)))

    def rot90(m):
        h = len(m); w = len(m[0])
        return [[m[h-1-i][j] for i in range(h)] for j in range(w)]

    def flip(m):
        return [row[::-1] for row in m]

    def symset(m):
        out = set(); cur = m
        for _ in range(4):
            out.add(tuple(tuple(v) for v in cur))
            out.add(tuple(tuple(v) for v in flip(cur)))
            cur = rot90(cur)
        return out

    def find_orient(b, sh):
        cur = b
        for _ in range(4):
            for m in (cur, flip(cur)):
                if [[int(v) for v in row] for row in m] == sh:
                    return m
            cur = rot90(cur)
        return None

    def blocks(m, k):
        h = len(m); w = len(m[0])
        if h % k or w % k:
            return None
        bm = []
        for i in range(h//k):
            row = []
            for j in range(w//k):
                vals = [m[i*k+di][j*k+dj] for di in range(k) for dj in range(k)]
                if all(vals): row.append(1)
                elif any(vals): return None
                else: row.append(0)
            bm.append(row)
        rs = [i for i, row in enumerate(bm) if any(row)]
        if not rs: return None
        cs = [j for j in range(len(bm[0])) if any(bm[i][j] for i in range(len(bm)))]
        r0, r1, c0, c1 = min(rs), max(rs), min(cs), max(cs)
        return [[bm[i][j] for j in range(c0, c1+1)] for i in range(r0, r1+1)]

    def norm(comp):
        s = set(comp)
        rs = [p[0] for p in comp]; cs = [p[1] for p in comp]
        r0, r1, c0, c1 = min(rs), max(rs), min(cs), max(cs)
        return [[1 if (r, c) in s else 0 for c in range(c0, c1+1)] for r in range(r0, r1+1)]

    for ci, cont in enumerate(objs):
        if cont["nholes"] == 0:
            continue
        # background holes inside the container's bounding box, 4-connected
        hs = {(r, c) for r in range(cont["r0"], cont["r1"]+1)
              for c in range(cont["c0"], cont["c1"]+1) if grid[r][c] == bg}
        vis = set(); clusters = []
        for h0 in sorted(hs):
            if h0 in vis: continue
            q = deque([h0]); vis.add(h0); comp = [h0]
            while q:
                x, y = q.popleft()
                for dx, dy in ((1,0),(-1,0),(0,1),(0,-1)):
                    n = (x+dx, y+dy)
                    if n in hs and n not in vis:
                        vis.add(n); q.append(n); comp.append(n)
            clusters.append(comp)
        hole_area = sum(len(c) for c in clusters)
        clshapes = [norm(c) for c in clusters]
        maxk = max(cont["r1"]-cont["r0"], cont["c1"]-cont["c0"]) + 1
        for k in range(2, maxk+1):
            cands = []; ok = True
            for oi, o in enumerate(objs):
                if oi == ci: continue
                b = blocks(o["mask"], k)
                if b is None: continue
                if sum(sum(row) for row in b) * k * k != len(o["cells"]):
                    ok = False; break
                cands.append((o, b))
            if not ok or len(cands) != len(clshapes): continue
            if sum(len(o["cells"]) for o, _ in cands) != hole_area * k * k: continue
            for perm in itertools.permutations(range(len(clshapes))):
                if all(symset(clshapes[perm[i]]) & {tuple(map(tuple, cands[i][1]))}
                       for i in range(len(cands))):
                    out = [[cont["color"]]*((cont["c1"]-cont["c0"]+1)*k)
                           for _ in range((cont["r1"]-cont["r0"]+1)*k)]
                    for i in range(len(cands)):
                        o, b = cands[i]; cl = clusters[perm[i]]; sh = clshapes[perm[i]]
                        orient = find_orient(b, sh)
                        if orient is None: continue
                        rs = [p[0] for p in cl]; cs = [p[1] for p in cl]
                        R0 = min(rs) - cont["r0"]; C0 = min(cs) - cont["c0"]
                        for i2 in range(len(orient)):
                            for j2 in range(len(orient[0])):
                                if orient[i2][j2]:
                                    for di in range(k):
                                        for dj in range(k):
                                            out[(R0+i2)*k+di][(C0+j2)*k+dj] = o["color"]
                    return out
    return grid
