from collections import Counter, deque

def comps_of_color(g, color):
    """4-connected components of cells of one color."""
    H, W = len(g), len(g[0])
    seen = [[False] * W for _ in range(H)]
    res = []
    for r in range(H):
        for c in range(W):
            if g[r][c] == color and not seen[r][c]:
                q = deque([(r, c)])
                seen[r][c] = True
                cells = []
                while q:
                    a, b = q.popleft()
                    cells.append((a, b))
                    for da, db in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        na, nb = a + da, b + db
                        if 0 <= na < H and 0 <= nb < W and not seen[na][nb] and g[na][nb] == color:
                            seen[na][nb] = True
                            q.append((na, nb))
                res.append(cells)
    return res

def get_bars(g):
    """Find background colour, the horizontal line row/colour, and the vertical bars."""
    H, W = len(g), len(g[0])
    bg = Counter(sum(g, [])).most_common(1)[0][0]
    # the line row is the row with the most non-background cells
    line = max(range(H), key=lambda r: sum(1 for c in range(W) if g[r][c] != bg))
    linecolor = Counter(g[line][c] for c in range(W)).most_common(1)[0][0]
    bars = []
    for color in set(sum(g, [])) - {bg, linecolor}:
        for cells in comps_of_color(g, color):
            rows = sorted(set(r for r, c in cells))
            cols = sorted(set(c for r, c in cells))
            bars.append((min(cols), min(rows), max(rows), cols, color))
    return bg, line, linecolor, bars

def solution(grid):
    H, W = len(grid), len(grid[0])
    bg, line, linecolor, bars = get_bars(grid)
    bars_sorted = sorted(bars, key=lambda b: (b[0], b[1]))          # left to right
    heights = sorted(b[2] - b[1] + 1 for b in bars_sorted)          # heights sorted ascending

    out = [[bg] * W for _ in range(H)]
    for c in range(W):
        out[line][c] = linecolor                                    # redraw the horizontal line

    for (col0, rmin, rmax, cols, color), h in zip(bars_sorted, heights):
        top = line - h // 2
        bot = line + (h - 1) // 2
        for r in range(top, bot + 1):
            for c in cols:
                out[r][c] = color
    return out
