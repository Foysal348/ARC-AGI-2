from collections import deque, Counter

DIRS = {'U': (-1, 0), 'D': (1, 0), 'L': (0, -1), 'R': (0, 1)}
DIRMAP = {(-1, 0): 'U', (1, 0): 'D', (0, 1): 'R', (0, -1): 'L'}


def comps(grid, color):
    """4-connected components of cells with the given color."""
    H, W = len(grid), len(grid[0])
    seen = set()
    out = []
    for r in range(H):
        for c in range(W):
            if grid[r][c] == color and (r, c) not in seen:
                q = deque([(r, c)])
                seen.add((r, c))
                cells = []
                while q:
                    x, y = q.popleft()
                    cells.append((x, y))
                    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        nx, ny = x + dx, y + dy
                        if 0 <= nx < H and 0 <= ny < W and grid[nx][ny] == color and (nx, ny) not in seen:
                            seen.add((nx, ny))
                            q.append((nx, ny))
                out.append(cells)
    return out


def shape_info(grid):
    """Blue blobs paired with their green tab; tab gives the exit side."""
    blues = comps(grid, 1)
    greens = comps(grid, 3)
    shapes = []
    for cells in blues:
        cellset = set(cells)
        for gc in greens:
            dirs = []
            for (x, y) in gc:
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    if (x + dx, y + dy) in cellset:
                        dirs.append((-dx, -dy))   # direction blob -> tab
            if dirs:
                side = DIRMAP[Counter(dirs).most_common(1)[0][0]]
                shapes.append(dict(cells=cells, green=gc, side=side))
                break
    return shapes


def solution(grid):
    H, W = len(grid), len(grid[0])
    shapes = shape_info(grid)
    shape_sets = [set(s['cells']) for s in shapes]
    out = [[8] * W for _ in range(H)]

    stem = [(r, c) for r in range(H) for c in range(W) if grid[r][c] == 2]
    yellow = [(r, c) for r in range(H) for c in range(W) if grid[r][c] == 4][0]
    for (r, c) in stem + [yellow]:
        out[r][c] = 2

    visited = set()
    band = sorted(set(c for r, c in stem)) or [yellow[1]]
    d = 'U'
    pos = yellow[0]

    for _ in range(300):
        dr, dc = DIRS[d]
        hit = None
        # travel along the current band until a (still unvisited) blob is touched
        while True:
            pos += dr or dc
            if not (0 <= pos < H and 0 <= pos < W):
                return out
            line = [(pos, c) for c in band] if d in ('U', 'D') else [(r, pos) for r in band]
            for (r, c) in line:
                out[r][c] = 2
            for i in range(len(shapes)):
                if i in visited:
                    continue
                if any((r, c) in shape_sets[i] for r, c in line):
                    hit = i
                    break
            if hit is not None:
                break

        visited.add(hit)
        s = shapes[hit]
        for (r, c) in s['cells'] + s['green']:
            out[r][c] = 2

        grs = sorted(set(p[0] for p in s['green']))
        gcs = sorted(set(p[1] for p in s['green']))
        d = s['side']
        if d in ('U', 'D'):
            band, pos = gcs, min(grs)
        else:
            band, pos = grs, (min(gcs) if d == 'L' else max(gcs))

    return out
