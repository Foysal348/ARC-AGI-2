from collections import deque, Counter

def comps4(g, bg):
    H, W = len(g), len(g[0])
    seen = set()
    out = []
    for r in range(H):
        for c in range(W):
            if g[r][c] == bg or (r, c) in seen:
                continue
            q = deque([(r, c)])
            seen.add((r, c))
            cells = []
            while q:
                r0, c0 = q.popleft()
                cells.append((r0, c0))
                for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    rr, cc = r0 + dr, c0 + dc
                    if 0 <= rr < H and 0 <= cc < W and g[rr][cc] != bg and (rr, cc) not in seen:
                        seen.add((rr, cc))
                        q.append((rr, cc))
            out.append(cells)
    return out

def holes_of(cells):
    """Number of enclosed (interior) background regions of a component."""
    S = set(cells)
    rs = [r for r, _ in cells]
    cs = [c for _, c in cells]
    r0, r1, c0, c1 = min(rs), max(rs), min(cs), max(cs)
    bg = {(r, c) for r in range(r0, r1 + 1) for c in range(c0, c1 + 1) if (r, c) not in S}
    seen = set()
    n = 0
    for cell in bg:
        if cell in seen:
            continue
        reg = []
        q = deque([cell])
        seen.add(cell)
        while q:
            r, c = q.popleft()
            reg.append((r, c))
            for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                nr, nc = r + dr, c + dc
                if (nr, nc) in bg and (nr, nc) not in seen:
                    seen.add((nr, nc))
                    q.append((nr, nc))
        # interior region = does not touch the bounding box border
        if not any(x[0] in (r0, r1) or x[1] in (c0, c1) for x in reg):
            n += 1
    return n

def has_2x2(cells):
    S = set(cells)
    for (r, c) in S:
        if (r + 1, c) in S and (r, c + 1) in S and (r + 1, c + 1) in S:
            return True
    return False

def solution(grid):
    H, W = len(grid), len(grid[0])
    cnt = Counter(v for row in grid for v in row)
    bg = cnt.most_common(1)[0][0]
    cp = comps4(grid, bg)

    # the color of the gray blobs = most frequent non-background color
    tot = Counter()
    for c in cp:
        tot[grid[c[0][0]][c[0][1]]] += len(c)
    shape_color = tot.most_common(1)[0][0]

    # legend: colored components that are real shapes (not the thin divider line)
    mapping = {}
    for c in cp:
        col = grid[c[0][0]][c[0][1]]
        if col == shape_color:
            continue
        h = holes_of(c)
        if h > 0 or has_2x2(c):
            mapping.setdefault(h, col)

    out = [[grid[r][c] for c in range(W)] for r in range(H)]
    for c in cp:
        col = grid[c[0][0]][c[0][1]]
        if col == shape_color:
            h = holes_of(c)
            new = mapping.get(h, bg)
            for r, cc in c:
                out[r][cc] = new
    return out
