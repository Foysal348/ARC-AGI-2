from collections import Counter


def _comps_color(g, color):
    R = len(g)
    C = len(g[0])
    seen = set()
    out = []
    for r in range(R):
        for c in range(C):
            if g[r][c] == color and (r, c) not in seen:
                st = [(r, c)]
                seen.add((r, c))
                comp = []
                while st:
                    r0, c0 = st.pop()
                    comp.append((r0, c0))
                    for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        rr, cc = r0 + dr, c0 + dc
                        if 0 <= rr < R and 0 <= cc < C and g[rr][cc] == color and (rr, cc) not in seen:
                            seen.add((rr, cc))
                            st.append((rr, cc))
                out.append(sorted(comp))
    return out


def _bracket_info(comp):
    """A 'bracket' = a full bar with two legs and a middle nub.
    Returns (opening_direction, nub_indices_along_the_bar, bbox) or None."""
    rs = [r for r, c in comp]
    cs = [c for r, c in comp]
    r0, r1, c0, c1 = min(rs), max(rs), min(cs), max(cs)
    S = set(comp)
    full_top = all((r0, c) in S for c in range(c0, c1 + 1))
    full_bot = all((r1, c) in S for c in range(c0, c1 + 1))
    full_left = all((r, c0) in S for r in range(r0, r1 + 1))
    full_right = all((r, c1) in S for r in range(r0, r1 + 1))
    if full_top and (c1 - c0) >= (r1 - r0):
        dirn, inner = 'D', r0 + 1
    elif full_bot and (c1 - c0) >= (r1 - r0):
        dirn, inner = 'U', r1 - 1
    elif full_left and (r1 - r0) > (c1 - c0):
        dirn, inner = 'R', c0 + 1
    elif full_right and (r1 - r0) > (c1 - c0):
        dirn, inner = 'L', c1 - 1
    else:
        return None
    if dirn in 'UD':
        legs = [c for c in range(c0, c1 + 1) if all((r, c) in S for r in range(r0, r1 + 1))]
        line = [c for c in range(c0, c1 + 1) if (inner, c) in S]
        nub = [c for c in line if c not in legs]
    else:
        legs = [r for r in range(r0, r1 + 1) if all((r, c) in S for c in range(c0, c1 + 1))]
        line = [r for r in range(r0, r1 + 1) if (r, inner) in S]
        nub = [r for r in line if r not in legs]
    if len(nub) < 1 or len(legs) != 2:
        return None
    return dirn, nub, (r0, r1, c0, c1)


def solution(grid):
    cnt = Counter(v for row in grid for v in row)
    bg = cnt.most_common(1)[0][0]

    # the colour that forms brackets is the shape colour; the other is the marker colour
    shape_color = None
    marker_color = None
    for col in cnt:
        if col == bg:
            continue
        if any(_bracket_info(cp) for cp in _comps_color(grid, col)):
            shape_color = col
        else:
            marker_color = col

    out = [row[:] for row in grid]
    markers = []
    for cp in _comps_color(grid, marker_color):
        pr0 = min(r for r, c in cp)
        pr1 = max(r for r, c in cp)
        pc0 = min(c for r, c in cp)
        pc1 = max(c for r, c in cp)
        markers.append((pr0, pr1, pc0, pc1))
        for (r, c) in cp:          # every marker is removed
            out[r][c] = bg

    for cp in _comps_color(grid, shape_color):
        info = _bracket_info(cp)
        if not info:
            continue
        dirn, nub, (r0, r1, c0, c1) = info
        span = list(range(min(nub), max(nub) + 1))
        far = (r1 if dirn == 'D' else r0) if dirn in 'UD' else (c1 if dirn == 'R' else c0)

        # find the marker that lies straight ahead of the bracket's mouth
        cands = []
        for pr0, pr1, pc0, pc1 in markers:
            if dirn in 'UD':
                if (pc0, pc1) != (min(span), max(span)):
                    continue
                if dirn == 'D' and pr0 > far:
                    cands.append((pr0 - far, (pr0, pr1, pc0, pc1)))
                elif dirn == 'U' and pr1 < far:
                    cands.append((far - pr1, (pr0, pr1, pc0, pc1)))
            else:
                if (pr0, pr1) != (min(span), max(span)):
                    continue
                if dirn == 'R' and pc0 > far:
                    cands.append((pc0 - far, (pr0, pr1, pc0, pc1)))
                elif dirn == 'L' and pc1 < far:
                    cands.append((far - pc1, (pr0, pr1, pc0, pc1)))
        if not cands:
            continue
        _, (pr0, pr1, pc0, pc1) = min(cands)

        inner = r0 + 1 if dirn == 'D' else (r1 - 1 if dirn == 'U' else (c0 + 1 if dirn == 'R' else c1 - 1))
        ext = (pr1 - pr0 + 1) if dirn in 'UD' else (pc1 - pc0 + 1)

        red = []
        black = []
        if dirn == 'D':
            for i in range(1, ext + 1):
                red += [(inner + i, c) for c in span]
            for r in range(inner + ext + 1, pr1 + 1):
                black += [(r, c) for c in span]
        elif dirn == 'U':
            for i in range(1, ext + 1):
                red += [(inner - i, c) for c in span]
            for r in range(pr0, inner - ext):
                black += [(r, c) for c in span]
        elif dirn == 'R':
            for i in range(1, ext + 1):
                red += [(r, inner + i) for r in span]
            for c in range(inner + ext + 1, pc1 + 1):
                black += [(r, c) for r in span]
        else:
            for i in range(1, ext + 1):
                red += [(r, inner - i) for r in span]
            for c in range(pc0, inner - ext):
                black += [(r, c) for r in span]

        # the marker is pulled into the mouth (red), the trail is black
        for (r, c) in red:
            out[r][c] = marker_color
        for (r, c) in black:
            out[r][c] = 0
    return out
