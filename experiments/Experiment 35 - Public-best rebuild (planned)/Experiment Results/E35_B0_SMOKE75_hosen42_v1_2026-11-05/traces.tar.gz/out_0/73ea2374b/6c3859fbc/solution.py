from collections import deque

def solution(grid):
    H = len(grid); W = len(grid[0])

    # separator = a non-zero colour that forms exactly 3 non-adjacent full lines
    def full_lines(axis):
        d = {}
        if axis == 'row':
            for r in range(H):
                row = grid[r]; v = row[0]
                if v != 0 and all(x == v for x in row):
                    d.setdefault(v, []).append(r)
        else:
            for c in range(W):
                v = grid[0][c]
                if v != 0 and all(grid[r][c] == v for r in range(H)):
                    d.setdefault(v, []).append(c)
        return d

    axis = None; ls = None
    for ax in ('row', 'col'):
        for v, l in full_lines(ax).items():
            if len(l) == 3 and l[1] - l[0] > 1 and l[2] - l[1] > 1:
                axis = ax; ls = l; break
        if axis: break

    # four regions between the separators
    cuts = [-1] + ls + [H if axis == 'row' else W]
    segs = []
    for i in range(4):
        a = cuts[i] + 1; b = cuts[i + 1]
        if axis == 'col':
            seg = [[grid[r][c] for c in range(a, b)] for r in range(H)]
        else:
            seg = [[grid[r][c] for c in range(W)] for r in range(a, b)]
        segs.append(seg)

    def nonzeros(seg):
        return [(r, c) for r, row in enumerate(seg) for c, v in enumerate(row) if v != 0]

    def components(cells):
        S = set(cells); seen = set(); n = 0
        for p in cells:
            if p in seen: continue
            n += 1; q = deque([p]); seen.add(p)
            while q:
                r, c = q.popleft()
                for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    p2 = (r + dr, c + dc)
                    if p2 in S and p2 not in seen:
                        seen.add(p2); q.append(p2)
        return n

    def dominant(seg):
        cnt = {}
        for row in seg:
            for v in row:
                if v != 0: cnt[v] = cnt.get(v, 0) + 1
        return max(cnt, key=lambda v: cnt[v])

    # stamp = bounding box of first region's shape
    cellsA = set(nonzeros(segs[0]))
    r0 = min(r for r, c in cellsA); r1 = max(r for r, c in cellsA)
    c0 = min(c for r, c in cellsA); c1 = max(c for r, c in cellsA)
    mask = [[1 if (r, c) in cellsA else 0 for c in range(c0, c1 + 1)] for r in range(r0, r1 + 1)]
    h = len(mask); w = len(mask[0])

    n = components(nonzeros(segs[1]))   # number of copies
    C = dominant(segs[2])               # stamp colour
    D = dominant(segs[3])               # background colour

    if axis == 'col':
        out = [[D] * (n * (w + 1) - 1) for _ in range(h)]
        for t in range(n):
            for r in range(h):
                for c in range(w):
                    if mask[r][c]:
                        out[r][t * (w + 1) + c] = C
    else:
        out = [[D] * w for _ in range(n * (h + 1) - 1)]
        for t in range(n):
            for r in range(h):
                for c in range(w):
                    if mask[r][c]:
                        out[t * (h + 1) + r][c] = C
    return out
