def solution(grid):
    g = [[int(v) for v in row] for row in grid]
    h, w = len(g), len(g[0])
    seen = [[False] * w for _ in range(h)]
    objs = []
    steps = [(-1, 0), (1, 0), (0, -1), (0, 1)]
    # find 4-connected objects of non-background (black) cells
    for r in range(h):
        for c in range(w):
            if seen[r][c] or g[r][c] == 0:
                continue
            seen[r][c] = True
            stack, cells = [(r, c)], []
            while stack:
                y, x = stack.pop()
                cells.append((y, x))
                for dy, dx in steps:
                    ny, nx = y + dy, x + dx
                    if 0 <= ny < h and 0 <= nx < w and not seen[ny][nx] \
                            and g[ny][nx] != 0 and g[ny][nx] == g[y][x]:
                        seen[ny][nx] = True
                        stack.append((ny, nx))
            r0 = min(y for y, _ in cells)
            r1 = max(y for y, _ in cells) + 1
            c0 = min(x for _, x in cells)
            c1 = max(x for _, x in cells) + 1
            objs.append({"size": len(cells), "rows": (r0, r1), "cols": (c0, c1)})

    # a 4x4 hollow frame has 12 cells, a solid 4x4 block has 16
    hollow = sorted([o for o in objs if o["size"] < 16], key=lambda o: (o["rows"][0], o["cols"][0]))
    filled = sorted([o for o in objs if o["size"] == 16], key=lambda o: (o["rows"][0], o["cols"][0]))

    n = max(len(hollow), len(filled))
    out = [[0] * 8 for _ in range(4 * n)]
    for i in range(n):
        for side, lst in ((0, hollow), (4, filled)):
            if i < len(lst):
                o = lst[i]
                for r in range(o["rows"][0], o["rows"][1]):
                    for c in range(o["cols"][0], o["cols"][1]):
                        out[4 * i + (r - o["rows"][0])][side + (c - o["cols"][0])] = g[r][c]
    return out
