from collections import Counter, defaultdict

def frame_rects(g, bg):
    """Find hollow rectangular frames (single-color border components)."""
    h = len(g); w = len(g[0]); rects = []; seen = set()
    for r in range(h):
        for c in range(w):
            v = g[r][c]
            if v == bg or (r, c) in seen:
                continue
            stack = [(r, c)]; comp = []
            while stack:
                x, y = stack.pop()
                if 0 <= x < h and 0 <= y < w and g[x][y] == v and (x, y) not in seen:
                    seen.add((x, y)); comp.append((x, y))
                    stack += [(x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)]
            r1 = min(p[0] for p in comp); r2 = max(p[0] for p in comp)
            c1 = min(p[1] for p in comp); c2 = max(p[1] for p in comp)
            border = set([(x, y) for x in (r1, r2) for y in range(c1, c2 + 1)] +
                         [(x, y) for y in (c1, c2) for x in range(r1 + 1, r2)])
            if border == set(comp) and r2 - r1 >= 2 and c2 - c1 >= 2:
                rects.append((r1, r2, c1, c2))
    return rects

def interior(g, rect):
    r1, r2, c1, c2 = rect
    return [[g[r][c] for c in range(c1 + 1, c2)] for r in range(r1 + 1, r2)]

def lines_of(intg, axis):
    """Lines whose contents repeat along the long axis of the strip."""
    if axis == 'cols':
        return [list(row) for row in intg]
    return [[intg[r][c] for r in range(len(intg))] for c in range(len(intg[0]))]

def repair(intg, axis):
    """Rebuild the interior as a perfect periodic pattern (smallest best period)."""
    Ls = lines_of(intg, axis)
    L = len(Ls[0])
    overall = Counter(v for line in Ls for v in line)
    best = None
    for P in range(1, max(2, L // 2) + 1):
        groups = defaultdict(Counter)
        for k, line in enumerate(Ls):
            for pos, v in enumerate(line):
                groups[(pos % P, k)][v] += 1
        mism = sum(sum(cnt.values()) - max(cnt.values()) for cnt in groups.values())
        if best is None or mism < best[0]:
            best = (mism, P, groups)
    mism, P, groups = best
    pat = {}
    for key, cnt in groups.items():
        mx = max(cnt.values())
        cands = [v for v, c in cnt.items() if c == mx]
        cands.sort(key=lambda v: (-overall[v], v))   # tie-break by overall frequency
        pat[key] = cands[0]
    out = [[0] * len(intg[0]) for _ in range(len(intg))]
    for k, line in enumerate(Ls):
        for pos in range(len(line)):
            v = pat[(pos % P, k)]
            if axis == 'cols':
                out[k][pos] = v
            else:
                out[pos][k] = v
    return out

def solution(grid):
    g = [list(r) for r in grid]
    bg = Counter(v for row in g for v in row).most_common(1)[0][0]
    for rect in frame_rects(g, bg):
        r1, r2, c1, c2 = rect
        intg = interior(g, rect)
        axis = 'rows' if (r2 - r1) > (c2 - c1) else 'cols'
        rep = repair(intg, axis)
        for i in range(r1 + 1, r2):
            for j in range(c1 + 1, c2):
                g[i][j] = rep[i - (r1 + 1)][j - (c1 + 1)]
    return g
