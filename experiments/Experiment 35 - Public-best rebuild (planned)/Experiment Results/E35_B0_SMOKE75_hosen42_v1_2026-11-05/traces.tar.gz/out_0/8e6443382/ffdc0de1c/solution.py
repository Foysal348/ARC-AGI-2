def solution(grid):
    """
    Rule (derived from the training examples):
    For every row and every column, look at the line from both ends.
    If the cell lying exactly on that edge and the next colored cell along the
    line have the SAME color, their distance is a period: the pair is repeated
    like a periodic stripe toward the opposite edge.  The stripe stops when it
    runs into another colored cell, and then the whole stripe takes that
    cell's color (it also covers the blocking cell).  If it reaches the edge
    without hitting anything, the stripe keeps the pair's color.
    Cells that are not part of any stripe (isolated cells, or cells whose two
    nearest cells from an edge differ in color) stay unchanged.
    """
    H, W = len(grid), len(grid[0])
    out = [row[:] for row in grid]

    def line_build(get, L):
        # positions 0..L-1 measured from the anchor edge; get(p) = color there
        cells = [(p, get(p)) for p in range(L) if get(p) != 0]
        if len(cells) < 2 or cells[0][0] != 0:
            return []
        if cells[0][1] != cells[1][1]:
            return []
        period = cells[1][0] - cells[0][0]
        color = cells[0][1]
        pos = [0, period]
        p = 2 * period
        while p < L:
            c = get(p)
            if c != 0:
                if c != color:
                    color = c
                pos.append(p)
                break
            pos.append(p)
            p += period
        return [(p, color) for p in pos]

    # horizontal lines, anchored at left and right edges
    for r in range(H):
        for res, tr in ((line_build(lambda p: grid[r][p], W), lambda p: p),
                        (line_build(lambda p: grid[r][W - 1 - p], W), lambda p: W - 1 - p)):
            for p, c in res:
                out[r][tr(p)] = c

    # vertical lines, anchored at top and bottom edges
    for c in range(W):
        for res, tr in ((line_build(lambda p: grid[p][c], H), lambda p: p),
                        (line_build(lambda p: grid[H - 1 - p][c], H), lambda p: H - 1 - p)):
            for p, c2 in res:
                out[tr(p)][c] = c2

    return out
