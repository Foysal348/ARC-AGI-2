from collections import Counter

def components8(g):
    H, W = len(g), len(g[0])
    bg = Counter(v for r in g for v in r).most_common(1)[0][0]
    seen = [[False] * W for _ in range(H)]
    res = []
    for r in range(H):
        for c in range(W):
            if g[r][c] == bg or seen[r][c]:
                continue
            st = [(r, c)]
            seen[r][c] = True
            cells = []
            while st:
                x, y = st.pop()
                cells.append((x, y))
                for dx in (-1, 0, 1):
                    for dy in (-1, 0, 1):
                        nx, ny = x + dx, y + dy
                        if 0 <= nx < H and 0 <= ny < W and not seen[nx][ny] and g[nx][ny] != bg:
                            seen[nx][ny] = True
                            st.append((nx, ny))
            res.append((g[cells[0][0]][cells[0][1]], sorted(cells)))
    return res

def tip_and_dir(cells):
    # tip = the cell adjacent to the other two; direction = opposite of its two arms.
    # prefer an orthogonally adjacent hub (corner shapes), else a diagonally adjacent one (chevrons).
    for strict in (True, False):
        for h in cells:
            o = [x for x in cells if x != h]
            if strict:
                ok = all(abs(h[0] - a[0]) + abs(h[1] - a[1]) == 1 for a in o)
            else:
                ok = all(max(abs(h[0] - a[0]), abs(h[1] - a[1])) == 1 for a in o)
            if ok:
                d = [(a[0] - h[0], a[1] - h[1]) for a in o]
                pr = d[0][0] + d[1][0]
                pc = d[0][1] + d[1][1]
                pr = 1 if pr > 0 else (-1 if pr < 0 else 0)
                pc = 1 if pc > 0 else (-1 if pc < 0 else 0)
                return h, (-pr, -pc)
    return None

def solution(grid):
    g = grid
    H, W = len(g), len(g[0])
    out = [row[:] for row in g]
    comps = components8(g)

    owner = {}
    for _, cells in comps:
        for c in cells:
            owner[c] = tuple(cells)

    dots = {}
    for _, cells in comps:
        if len(cells) != 3:
            continue
        tp = tip_and_dir(cells)
        if tp is None:
            continue
        tip, (pr, pc) = tp
        r, c = tip[0] + 5 * pr, tip[1] + 5 * pc
        if 0 <= r < H and 0 <= c < W:
            dots[(r, c)] = dots.get((r, c), 0) + 1

    # dot landing on an existing shape recolors that whole shape
    for (r, c) in dots:
        if (r, c) in owner:
            for cell in owner[(r, c)]:
                out[cell[0]][cell[1]] = 9

    # otherwise place the dot; two dots on the same cell become blue
    for (r, c), n in dots.items():
        if (r, c) in owner:
            continue
        out[r][c] = 1 if n >= 2 else 9

    return out
