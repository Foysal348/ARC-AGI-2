def solution(grid):
    """
    Rule (deduced from the training examples):
      * The input has an outer frame: two of its sides are SOLID (a single
        unbroken colour) and the other two are dashed (broken with black gaps).
      * Inside the frame there is a filled rectangle ("content"). Two adjacent
        sides of that content rectangle are lined with a border line whose
        colours are exactly the two solid-frame colours.
      * The output is the content rectangle (border lines removed) transformed
        by the unique dihedral symmetry that carries the two content border
        sides (with their colours) onto the two solid frame sides.
    """
    from collections import Counter

    SIDE_MAP = {
        'id':        {'top': 'top',    'right': 'right',  'bottom': 'bottom', 'left': 'left'},
        'rot90':     {'top': 'right',  'right': 'bottom', 'bottom': 'left',   'left': 'top'},
        'rot180':    {'top': 'bottom', 'right': 'left',   'bottom': 'top',    'left': 'right'},
        'rot270':    {'top': 'left',   'right': 'top',    'bottom': 'right',  'left': 'bottom'},
        'flipH':     {'top': 'top',    'right': 'left',   'bottom': 'bottom', 'left': 'right'},
        'flipV':     {'top': 'bottom', 'right': 'right',  'bottom': 'top',    'left': 'left'},
        'transpose': {'top': 'left',   'right': 'bottom', 'bottom': 'right',  'left': 'top'},
        'anti':      {'top': 'right',  'right': 'top',    'bottom': 'left',   'left': 'bottom'},
    }

    def transform(g, name):
        H, W = len(g), len(g[0])
        if name == 'id':
            return [row[:] for row in g]
        if name == 'rot90':
            return [[g[H - 1 - j][i] for j in range(H)] for i in range(W)]
        if name == 'rot180':
            return [[g[H - 1 - i][W - 1 - j] for j in range(W)] for i in range(H)]
        if name == 'rot270':
            return [[g[j][W - 1 - i] for j in range(H)] for i in range(W)]
        if name == 'flipH':
            return [[g[i][W - 1 - j] for j in range(W)] for i in range(H)]
        if name == 'flipV':
            return [[g[H - 1 - i][j] for j in range(W)] for i in range(H)]
        if name == 'transpose':
            return [[g[j][i] for j in range(H)] for i in range(W)]
        if name == 'anti':
            return [[g[H - 1 - j][W - 1 - i] for j in range(H)] for i in range(W)]
        return [row[:] for row in g]

    H, W = len(grid), len(grid[0])

    # 1) find the solid sides of the outer frame (an edge with no black gaps)
    edges = {'top': grid[0], 'bottom': grid[-1],
             'left': [row[0] for row in grid],
             'right': [row[-1] for row in grid]}
    solid = {}
    for side, line in edges.items():
        if 0 not in line:
            cnt = Counter(c for c in line if c != 0)
            solid[side] = cnt.most_common(1)[0][0]
    solid_colors = set(solid.values())

    # 2) bounding box of the inner content (ignoring background, gray dashes
    #    and the border-line colours taken from the frame)
    cells = [(r, c) for r in range(1, H - 1) for c in range(1, W - 1)
             if grid[r][c] not in (0, 5) and grid[r][c] not in solid_colors]
    r0 = min(r for r, c in cells)
    r1 = max(r for r, c in cells)
    c0 = min(c for r, c in cells)
    c1 = max(c for r, c in cells)

    # 3) find which sides of the content carry a border line of a frame-solid colour
    borders = []

    def is_border_line(vals):
        nz = [v for v in vals if v != 0]
        return len(nz) > 0 and all(v == nz[0] for v in nz) and nz[0] in solid_colors

    if is_border_line([grid[r][c0 - 1] for r in range(r0, r1 + 1)]):
        borders.append(('left', grid[r0][c0 - 1]))
    if is_border_line([grid[r][c1 + 1] for r in range(r0, r1 + 1)]):
        borders.append(('right', grid[r0][c1 + 1]))
    if is_border_line([grid[r0 - 1][c] for c in range(c0, c1 + 1)]):
        borders.append(('top', grid[r0 - 1][c0]))
    if is_border_line([grid[r1 + 1][c] for c in range(c0, c1 + 1)]):
        borders.append(('bottom', grid[r1 + 1][c0]))

    content = [grid[r][c0:c1 + 1] for r in range(r0, r1 + 1)]

    # 4) the symmetry that maps the border sides (with colours) onto the solid frame sides
    target = set(solid.items())
    for name, smap in SIDE_MAP.items():
        if {(smap[bs], bc) for bs, bc in borders} == target:
            return transform(content, name)

    return content
