from collections import Counter, deque

def free_components(grid, sep):
    """4-connected components of cells whose color is not the frame color sep."""
    H, W = len(grid), len(grid[0])
    seen = [[False] * W for _ in range(H)]
    out = []
    for r in range(H):
        for c in range(W):
            if grid[r][c] == sep or seen[r][c]:
                continue
            q = deque([(r, c)])
            seen[r][c] = True
            cells = []
            while q:
                r0, c0 = q.popleft()
                cells.append((r0, c0))
                for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    rr, cc = r0 + dr, c0 + dc
                    if 0 <= rr < H and 0 <= cc < W and not seen[rr][cc] and grid[rr][cc] != sep:
                        seen[rr][cc] = True
                        q.append((rr, cc))
            out.append(cells)
    return out

def ring_depth(grid, cells):
    """For each cell of the region: Chebyshev distance to the region's edge
       (0 = touching the boundary/line), i.e. its concentric-ring layer."""
    H, W = len(grid), len(grid[0])
    inreg = [[False] * (W + 2) for _ in range(H + 2)]   # padded border = outside
    for r, c in cells:
        inreg[r + 1][c + 1] = True
    dist = [[10 ** 9] * (W + 2) for _ in range(H + 2)]
    q = deque()
    for r in range(H + 2):
        for c in range(W + 2):
            if not inreg[r][c]:
                dist[r][c] = 0
                q.append((r, c))
    while q:
        r, c = q.popleft()
        for dr in (-1, 0, 1):
            for dc in (-1, 0, 1):
                rr, cc = r + dr, c + dc
                if 0 <= rr < H + 2 and 0 <= cc < W + 2 and inreg[rr][cc] and dist[rr][cc] > dist[r][c] + 1:
                    dist[rr][cc] = dist[r][c] + 1
                    q.append((rr, cc))
    return {(r, c): dist[r + 1][c + 1] - 1 for r, c in cells}

def solution(grid):
    cnt = Counter(c for row in grid for c in row)
    if len(cnt) < 2:
        return [row[:] for row in grid]
    sep = cnt.most_common(2)[1][0]          # color of the dividing lines/frames
    out = [row[:] for row in grid]
    for cells in free_components(grid, sep):
        colcnt = Counter(grid[r][c] for r, c in cells)
        rbg = colcnt.most_common(1)[0][0]   # background color of this region
        dep = ring_depth(grid, cells)
        # colors of the dots, ordered by ring layer (dots at layer d -> ring d)
        by_depth = {}
        for r, c in cells:
            col = grid[r][c]
            if col == rbg:
                continue
            d = dep[(r, c)]
            if d not in by_depth:
                by_depth[d] = col
        if not by_depth:
            continue                        # no dots: region stays background
        # outermost layers up to the deepest dot; empty layers take the background
        seq = [by_depth.get(d, rbg) for d in range(max(by_depth) + 1)]
        for r, c in cells:
            out[r][c] = seq[dep[(r, c)] % len(seq)]
    return out
