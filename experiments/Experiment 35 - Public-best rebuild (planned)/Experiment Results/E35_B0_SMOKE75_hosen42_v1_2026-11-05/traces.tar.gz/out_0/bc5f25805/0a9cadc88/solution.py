def solution(grid):
    from collections import Counter, deque

    h, w = len(grid), len(grid[0])
    bg = Counter(v for row in grid for v in row).most_common(1)[0][0]

    # 4-connected components of non-background cells
    seen = [[False] * w for _ in range(h)]
    comps = []
    for r in range(h):
        for c in range(w):
            if grid[r][c] != bg and not seen[r][c]:
                col = grid[r][c]
                q = deque([(r, c)])
                seen[r][c] = True
                cells = []
                while q:
                    r0, c0 = q.popleft()
                    cells.append((r0, c0))
                    for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        nr, nc = r0 + dr, c0 + dc
                        if 0 <= nr < h and 0 <= nc < w and not seen[nr][nc] and grid[nr][nc] == col:
                            seen[nr][nc] = True
                            q.append((nr, nc))
                comps.append((col, cells))

    out = [[bg] * w for _ in range(h)]
    frames = {}
    shapes = Counter()

    for col, cells in comps:
        rs = [r for r, _ in cells]
        cs = [c for _, c in cells]
        r0, r1 = min(rs), max(rs)
        c0, c1 = min(cs), max(cs)
        hh, ww = r1 - r0 + 1, c1 - c0 + 1
        border_only = all(r == r0 or r == r1 or c == c0 or c == c1 for r, c in cells)
        if hh > 2 and ww > 2 and border_only and len(cells) == 2 * (hh + ww) - 4:
            # hollow rectangular frame
            frames[col] = (r0, r1, c0, c1)
        else:
            # free-floating shape: counts toward matching frame, disappears otherwise
            shapes[col] += 1

    for col, (r0, r1, c0, c1) in frames.items():
        # redraw the frame
        for r in range(r0, r1 + 1):
            out[r][c0] = col
            out[r][c1] = col
        for c in range(c0, c1 + 1):
            out[r0][c] = col
            out[r1][c] = col
        # one dot per shape of the same colour, on the middle row,
        # packed right-to-left with spacing 2
        n = shapes.get(col, 0)
        mid = (r0 + r1) // 2
        for i in range(n):
            out[mid][c1 - 2 - 2 * i] = col

    return out
