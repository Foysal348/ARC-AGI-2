from collections import Counter

def solution(grid):
    H, W = len(grid), len(grid[0])
    cnt = Counter(v for row in grid for v in row)
    bg = cnt.most_common(1)[0][0]
    others = [c for c in cnt if c != bg]

    # markers: non-background cells sitting on the border
    mk = []
    for r in range(H):
        for c in range(W):
            v = grid[r][c]
            if v != bg and (r == 0 or r == H - 1 or c == 0 or c == W - 1):
                edge = 'top' if r == 0 else 'bottom' if r == H - 1 else 'left' if c == 0 else 'right'
                mk.append((r, c, edge, v))
    mkcol = mk[0][3] if mk else others[0]
    shape = [c for c in others if c != mkcol][0]

    out = [[bg] * W for _ in range(H)]
    axes = [('v', c) if e in ('top', 'bottom') else ('h', r) for (r, c, e, v) in mk]

    def sides(r, c):
        rs = cs = None
        for kind, coord in axes:
            if kind == 'v':
                if c == coord:
                    return None
                cs = 'L' if c < coord else 'R'
            else:
                if r == coord:
                    return None
                rs = 'U' if r < coord else 'D'
        return (rs, cs)

    pieces = {}
    for r in range(H):
        for c in range(W):
            if grid[r][c] != shape:
                continue
            s = sides(r, c)
            if s is None:
                out[r][c] = shape          # cell on an axis stays
            else:
                pieces.setdefault(s, []).append((r, c))

    edges = set(e for (_, _, e, _) in mk)
    for (rs, cs), cells in pieces.items():
        if rs is None:
            rs = 'U' if 'top' in edges else 'D'
        if cs is None:
            cs = 'L' if 'left' in edges else 'R'
        e1 = 'top' if rs == 'U' else 'bottom'
        e2 = 'left' if cs == 'L' else 'right'
        if e1 not in edges and e2 not in edges:
            continue                       # corner with no marker -> piece removed
        r0 = min(r for r, c in cells); r1 = max(r for r, c in cells)
        c0 = min(c for r, c in cells); c1 = max(c for r, c in cells)
        dr = -r0 if rs == 'U' else (H - 1 - r1)
        dc = -c0 if cs == 'L' else (W - 1 - c1)
        for (r, c) in cells:
            out[r + dr][c + dc] = shape

    # red lines fired from each marker inward
    for (r0, c0, e, vc) in mk:
        out[r0][c0] = vc
        cells = []
        r, c = r0, c0
        while 0 <= r < H and 0 <= c < W:
            cells.append((r, c))
            if e == 'top': r += 1
            elif e == 'bottom': r -= 1
            elif e == 'left': c += 1
            else: c -= 1
        runs = []
        for (rr, cc) in cells:
            if grid[rr][cc] == shape:
                if runs and abs(runs[-1][1][0] - rr) + abs(runs[-1][1][1] - cc) == 1:
                    runs[-1][1] = [rr, cc]
                else:
                    runs.append([[rr, cc], [rr, cc]])
        stop = runs[1][0] if len(runs) >= 2 else (runs[0][0] if runs else None)
        for (rr, cc) in cells:
            if grid[rr][cc] != bg:
                continue
            if stop is not None:
                if e == 'top' and rr >= stop[0]: break
                if e == 'bottom' and rr <= stop[0]: break
                if e == 'left' and cc >= stop[1]: break
                if e == 'right' and cc <= stop[1]: break
            out[rr][cc] = vc
    return out
