from collections import Counter, deque

def solution(grid):
    g = [list(r) for r in grid]
    h, w = len(g), len(g[0])
    bg = g[0][0]

    # bands of panels separated by all-background rows/cols
    sep_c = [c for c in range(w) if all(g[r][c] == bg for r in range(h))]
    sep_r = [r for r in range(h) if all(g[r][c] == bg for c in range(w))]

    def bands(seps, n):
        res, prev = [], None
        for x in seps:
            if prev is not None and x > prev + 1:
                res.append((prev + 1, x))
            prev = x
        if prev is not None and prev + 1 < n:
            res.append((prev + 1, n))
        return res

    br = bands(sep_r, h)
    bc = bands(sep_c, w)
    r0, r1 = br[0]

    # panel interior fill colour
    cnt = Counter(g[r][c] for r in range(r0, r1) for c in range(bc[0][0], bc[0][1]))
    fill = cnt.most_common(1)[0][0]

    out = [[fill] * w for _ in range(h)]
    for c in sep_c:
        for r in range(h):
            out[r][c] = bg
    for r in sep_r:
        for c in range(w):
            out[r][c] = bg

    # shapes and their colours for the 4 panels
    shapes, cols = [], []
    for (c0, c1) in bc:
        sh = set((r - r0, c - c0) for r in range(r0, r1) for c in range(c0, c1) if g[r][c] != fill)
        shapes.append(sh)
        cols.append(g[r0 + sorted(sh)[0][0]][c0 + sorted(sh)[0][1]] if sh else None)
    A, B, C = shapes[0], shapes[1], shapes[2]

    def comps(cells, diag=False):
        s = set(cells); seen = set(); res = []
        nb = [(1, 0), (-1, 0), (0, 1), (0, -1)] + ([(1, 1), (1, -1), (-1, 1), (-1, -1)] if diag else [])
        for p in cells:
            if p in seen:
                continue
            q = deque([p]); seen.add(p); cur = []
            while q:
                r, c = q.popleft(); cur.append((r, c))
                for dr, dc in nb:
                    n = (r + dr, c + dc)
                    if n in s and n not in seen:
                        seen.add(n); q.append(n)
            res.append(cur)
        return res

    n = r1 - r0
    # marker cell = the isolated piece of the divider shape (panel 0)
    tick = None
    for comp in comps(A, diag=True):
        if len(comp) == 1:
            tick = comp[0]

    # the divider splits the panel into regions (4-connectivity of non-divider cells)
    free = [(r, c) for r in range(n) for c in range(n) if (r, c) not in A]
    regions = comps(free)
    reg = {}
    for i, comp in enumerate(regions):
        for p in comp:
            reg[p] = i

    tick_side = None
    if tick is not None:
        tr, tc = tick
        for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            p = (tr + dr, tc + dc)
            if p in reg:
                tick_side = reg[p]
                break

    out3 = [[fill] * n for _ in range(n)]
    for (r, c) in B:                       # second panel keeps the marker side
        if (r, c) in A:
            out3[r][c] = cols[1]
        elif reg.get((r, c)) == tick_side:
            out3[r][c] = cols[1]
    for (r, c) in C:                       # third panel keeps the other side
        if (r, c) in A:
            if (r, c) != tick and out3[r][c] == fill:
                out3[r][c] = cols[2]
        elif reg.get((r, c)) != tick_side:
            out3[r][c] = cols[2]

    for i, (c0, c1) in enumerate(bc):
        for r in range(r0, r1):
            for c in range(c0, c1):
                out[r][c] = g[r][c] if i < 3 else out3[r - r0][c - c0]
    return out
