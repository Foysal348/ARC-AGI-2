from collections import Counter, deque

def _find_boxes(g):
    H = len(g); W = len(g[0]); res = []
    for r0 in range(H):
        for r1 in range(r0 + 3, H + 1):
            for c0 in range(W):
                for c1 in range(c0 + 3, W + 1):
                    k = g[r0][c0]
                    ok = True
                    for r in range(r0, r1):
                        if g[r][c0] != k or g[r][c1 - 1] != k:
                            ok = False; break
                    if not ok: continue
                    for c in range(c0, c1):
                        if g[r0][c] != k or g[r1 - 1][c] != k:
                            ok = False; break
                    if not ok: continue
                    inner = [g[r][c] for r in range(r0 + 1, r1 - 1) for c in range(c0 + 1, c1 - 1)]
                    cnt = Counter(inner)
                    bg = cnt.most_common(1)[0][0]
                    if k == bg or len(cnt) == 1: continue
                    res.append((k, r0, r1, c0, c1, bg))
    return [b for b in res if not any(b2 != b and b2[1] <= b[1] and b[2] <= b2[2]
                                      and b2[3] <= b[3] and b[4] <= b2[4] for b2 in res)]

def _interior(g, box):
    k, r0, r1, c0, c1, bg = box
    return [[g[r][c] for c in range(c0 + 1, c1 - 1)] for r in range(r0 + 1, r1 - 1)]

def _comps(reg, bg):
    H = len(reg); W = len(reg[0]); seen = [[False] * W for _ in range(H)]; out = []
    for i in range(H):
        for j in range(W):
            if reg[i][j] == bg or seen[i][j]: continue
            q = deque([(i, j)]); seen[i][j] = True; cells = []
            while q:
                r, c = q.popleft(); cells.append((r, c, reg[r][c]))
                for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    nr, nc = r + dr, c + dc
                    if 0 <= nr < H and 0 <= nc < W and not seen[nr][nc] and reg[nr][nc] != bg:
                        seen[nr][nc] = True; q.append((nr, nc))
            out.append(cells)
    return out

def _markers(g, box):
    reg = _interior(g, box)
    return sorted([(reg[r][c], r, c) for comp in _comps(reg, box[5]) for (r, c, col) in comp])

def _build(g, canvas, objbox):
    k, bg = canvas[0], canvas[5]
    reg = _interior(g, canvas); ih = len(reg); iw = len(reg[0])
    objs = _comps(_interior(g, objbox), objbox[5])
    out = [[bg] * iw for _ in range(ih)]
    for col, mr, mc in _markers(g, canvas):
        chosen = None
        for comp in objs:
            anchors = [(r, c) for (r, c, cc) in comp if cc == col]
            if anchors: chosen = (comp, anchors[0]); break
        if chosen is None: return None
        comp, (ar, ac) = chosen
        dr, dc = mr - ar, mc - ac
        if any(not (0 <= r + dr < ih and 0 <= c + dc < iw) for (r, c, cc) in comp): return None
        for (r, c, cc) in comp:
            out[r + dr][c + dc] = cc
    return [[k] * (iw + 2)] + [[k] + row + [k] for row in out] + [[k] * (iw + 2)]

def solution(grid):
    g = [[int(x) for x in row] for row in grid]
    boxes = _find_boxes(g)
    cands = []
    for cb in boxes:
        for ob in boxes:
            if cb == ob: continue
            r = _build(g, cb, ob)
            if r is None: continue
            single = all(len(c) == 1 for c in _comps(_interior(g, cb), cb[5]))
            cands.append((not single, -len(r), -len(r[0]), len(_markers(g, cb)), r))
    if not cands: return grid
    cands.sort(key=lambda x: (x[0], x[1], x[2], x[3]))
    return cands[0][4]
