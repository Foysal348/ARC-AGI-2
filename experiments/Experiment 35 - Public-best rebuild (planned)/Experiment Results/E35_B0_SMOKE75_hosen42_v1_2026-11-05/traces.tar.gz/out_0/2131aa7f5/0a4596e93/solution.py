from collections import Counter

def _lattice(grid):
    """Rows/cols of the uniform separator lines, and the (start, stop) ranges of each cell-block."""
    n = len(grid); m = len(grid[0])
    sep_rows = [i for i in range(n) if len(set(grid[i])) == 1]
    sep_cols = [j for j in range(m) if len({grid[i][j] for i in range(n)}) == 1]
    rb = [(sep_rows[k] + 1, sep_rows[k + 1]) for k in range(len(sep_rows) - 1)]
    cb = [(sep_cols[k] + 1, sep_cols[k + 1]) for k in range(len(sep_cols) - 1)]
    return rb, cb

def _blocks(grid):
    rb, cb = _lattice(grid)
    B = [[tuple(tuple(grid[r][c] for c in range(c0, c1)) for r in range(r0, r1))
          for c0, c1 in cb] for r0, r1 in rb]
    return B, rb, cb

def solution(grid):
    """
    The grid is a lattice of 3x3 blocks separated by 1-cell lines.  Almost every block
    is the "normal" pattern; a few blocks are the "odd" pattern.  The odd block itself
    contains a shape: the cells of its dominant (fill) colour form a small template.
    The odd blocks present in the input are only a part of that template.  The output
    completes the template: every odd pattern is stamped at the placement of the
    template that contains all the existing odd blocks.
    """
    B, rb, cb = _blocks(grid)
    R = len(rb); C = len(cb)
    cnt = Counter(b for row in B for b in row)
    normal = max(cnt, key=lambda b: cnt[b])
    special = min((b for b in cnt if b != normal), key=lambda b: cnt[b])

    h = len(special); w = len(special[0])
    cc = Counter(x for row in special for x in row)
    fill = cc.most_common(1)[0][0]
    M = {(i, j) for i in range(h) for j in range(w) if special[i][j] == fill}

    S = {(r, c) for r in range(R) for c in range(C) if B[r][c] == special}

    # placements of the template that cover all the existing odd blocks
    offs = [(r0, c0) for r0 in range(R - h + 1) for c0 in range(C - w + 1)
            if all((r - r0, c - c0) in M for (r, c) in S)]
    if not offs:
        offs = [(r0, c0) for r0 in range(R - h + 1) for c0 in range(C - w + 1)]
    offs.sort(key=lambda o: (-(len({(o[0] + i, o[1] + j) for (i, j) in M} & S)), o))
    r0, c0 = offs[0]

    need = {(r0 + i, c0 + j) for (i, j) in M}
    out = [row[:] for row in grid]
    for (r, c) in need:
        if B[r][c] != special:
            r1, r2 = rb[r]; c1, c2 = cb[c]
            for i in range(h):
                for j in range(w):
                    out[r1 + i][c1 + j] = special[i][j]
    return out
