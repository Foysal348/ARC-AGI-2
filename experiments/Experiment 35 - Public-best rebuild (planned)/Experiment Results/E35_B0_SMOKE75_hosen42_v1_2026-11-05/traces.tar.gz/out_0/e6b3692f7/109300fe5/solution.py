from collections import defaultdict, Counter
import itertools

def solution(grid):
    H, W = len(grid), len(grid[0])
    cnt = Counter()
    for row in grid:
        for v in row:
            cnt[v] += 1
    bg = cnt.most_common(1)[0][0]

    dots = [(r, c, grid[r][c]) for r in range(H) for c in range(W) if grid[r][c] != bg]
    byc = defaultdict(list)
    for r, c, v in dots:
        byc[v].append((r, c))

    def seg_cells(a, b):
        dr, dc = b[0] - a[0], b[1] - a[1]
        n = max(abs(dr), abs(dc))
        sr = 1 if dr > 0 else (-1 if dr < 0 else 0)
        sc = 1 if dc > 0 else (-1 if dc < 0 else 0)
        return [(a[0] + sr * i, a[1] + sc * i) for i in range(n + 1)]

    # diagonally aligned same-colour pairs
    pairs_by_color = {}
    for col, ps in byc.items():
        pairs_by_color[col] = [(a, b) for a, b in itertools.combinations(ps, 2)
                               if abs(a[0] - b[0]) == abs(a[1] - b[1])]

    # a colour is a "beam" colour if its segment contains a dot of another colour
    # (the mirror); otherwise the only colour that has aligned pairs is the beam
    beam_colors = set()
    for col, prs in pairs_by_color.items():
        for a, b in prs:
            cells = set(seg_cells(a, b))
            for (r, c, v) in dots:
                if v != col and (r, c) in cells and (r, c) != a and (r, c) != b:
                    beam_colors.add(col)
    if not beam_colors:
        beam_colors = {col for col, prs in pairs_by_color.items() if prs}

    out = [row[:] for row in grid]

    # 1) draw the diagonal segments between each aligned pair of the beam colour
    for col, prs in pairs_by_color.items():
        if col not in beam_colors:
            continue
        for a, b in prs:
            for (r, c) in seg_cells(a, b):
                out[r][c] = col

    # 2) every dot of another colour sitting on a beam reflects it:
    #    a full diagonal line of that dot's colour, perpendicular to the beam,
    #    running to both edges of the grid
    for col, prs in pairs_by_color.items():
        if col not in beam_colors:
            continue
        for a, b in prs:
            cells = set(seg_cells(a, b))
            slope = 1 if (b[0] - a[0]) == (b[1] - a[1]) else -1
            for (r, c, v) in dots:
                if v != col and (r, c) in cells and (r, c) != a and (r, c) != b:
                    if slope == 1:          # reflect to r+c = const
                        rr, cc = r, c
                        while rr - 1 >= 0 and cc + 1 < W:
                            rr -= 1; cc += 1; out[rr][cc] = v
                        rr, cc = r, c
                        while rr + 1 < H and cc - 1 >= 0:
                            rr += 1; cc -= 1; out[rr][cc] = v
                    else:                   # reflect to r-c = const
                        rr, cc = r, c
                        while rr - 1 >= 0 and cc - 1 >= 0:
                            rr -= 1; cc -= 1; out[rr][cc] = v
                        rr, cc = r, c
                        while rr + 1 < H and cc + 1 < W:
                            rr += 1; cc += 1; out[rr][cc] = v

    # 3) the original dots keep their own colour
    for r, c, v in dots:
        out[r][c] = v
    return out
