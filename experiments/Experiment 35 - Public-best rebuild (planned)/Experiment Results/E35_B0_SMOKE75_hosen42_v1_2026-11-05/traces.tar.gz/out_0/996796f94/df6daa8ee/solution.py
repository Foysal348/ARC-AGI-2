import heapq
from collections import Counter

def solution(grid):
    H = len(grid); W = len(grid[0])
    flat = Counter(v for row in grid for v in row)
    bg = flat.most_common(1)[0][0]

    # split non-background cells into solid square "beads" and thin line cells
    bycolor = {}
    for r in range(H):
        for c in range(W):
            v = grid[r][c]
            if v != bg:
                bycolor.setdefault(v, set()).add((r, c))

    blocks = []
    line = []
    for col, cells in bycolor.items():
        seen = set()
        for cell in cells:
            if cell in seen:
                continue
            stack = [cell]; seen.add(cell); comp = [cell]
            while stack:
                r, c = stack.pop()
                for dr in (-1, 0, 1):
                    for dc in (-1, 0, 1):
                        q = (r + dr, c + dc)
                        if q in cells and q not in seen:
                            seen.add(q); stack.append(q); comp.append(q)
            r0 = min(x[0] for x in comp); r1 = max(x[0] for x in comp)
            c0 = min(x[1] for x in comp); c1 = max(x[1] for x in comp)
            k = r1 - r0 + 1
            if k == c1 - c0 + 1 and len(comp) == k * k:
                blocks.append((r0, c0, col, k))       # solid square bead
            else:
                line.extend(comp)                     # line/curve cell

    out = [list(row) for row in grid]
    counts = Counter(b[2] for b in blocks)
    mincols = [c for c in counts if counts[c] == 2]   # colour with exactly 2 beads
    if len(mincols) != 1:
        return out
    ends = [('B', (b[0], b[1])) for b in blocks if b[2] == mincols[0]]
    if len(ends) != 2:
        return out
    A, B = ends

    # graph whose nodes are beads and line cells, joined by 8-adjacency
    block_of = {}
    for (r0, c0, col, k) in blocks:
        for r in range(r0, r0 + k):
            for c in range(c0, c0 + k):
                block_of[(r, c)] = (r0, c0)
    nonbg = {(r, c) for r in range(H) for c in range(W) if grid[r][c] != bg}

    def node_of(cell):
        if cell in block_of:
            return ('B', block_of[cell])
        return ('L', cell)

    nodes = {('B', (b[0], b[1])) for b in blocks} | {('L', p) for p in line}
    adj = {n: set() for n in nodes}
    for n in nodes:
        r0, c0 = n[1]
        if n[0] == 'B':
            k = [b[3] for b in blocks if (b[0], b[1]) == (r0, c0)][0]
            cells = [(r, c) for r in range(r0, r0 + k) for c in range(c0, c0 + k)]
        else:
            cells = [(r0, c0)]
        for cell in cells:
            for dr in (-1, 0, 1):
                for dc in (-1, 0, 1):
                    if dr == 0 and dc == 0:
                        continue
                    q = (cell[0] + dr, cell[1] + dc)
                    if q in nonbg:
                        m = node_of(q)
                        if m != n:
                            adj[n].add(m)

    # shortest route from one special bead to the other, minimising beads passed
    def dij(start, exempt):
        INF = 10**9
        dist = {start: 0}
        pq = [(0, start)]
        while pq:
            d, n = heapq.heappop(pq)
            if dist.get(n, INF) < d:
                continue
            if n == exempt:          # do not travel through the other endpoint
                continue
            for m in adj[n]:
                nd = d + (1 if m[0] == 'B' and m != start and m != exempt else 0)
                if nd < dist.get(m, INF):
                    dist[m] = nd
                    heapq.heappush(pq, (nd, m))
        return dist

    f = dij(A, B)
    g = dij(B, A)
    best = f.get(B, 10**9)
    for n in adj:
        s = f.get(n, 10**9) + g.get(n, 10**9)
        if n[0] == 'L':
            if s == best:
                out[n[1][0]][n[1][1]] = 5           # gray the path
        elif n != A and n != B and s == best + 1:
            k = [b[3] for b in blocks if (b[0], b[1]) == n[1]][0]
            for r in range(n[1][0], n[1][0] + k):
                for c in range(n[1][1], n[1][1] + k):
                    out[r][c] = 3                  # green the intermediate beads
    return out
