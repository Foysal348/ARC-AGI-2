from collections import deque

def _components8(grid, bg):
    H, W = len(grid), len(grid[0])
    seen = [[False] * W for _ in range(H)]
    objs = []
    for r in range(H):
        for c in range(W):
            if grid[r][c] != bg and not seen[r][c]:
                col = grid[r][c]
                q = deque([(r, c)]); seen[r][c] = True; cells = []
                while q:
                    r0, c0 = q.popleft(); cells.append((r0, c0))
                    for dr in (-1, 0, 1):
                        for dc in (-1, 0, 1):
                            if dr == 0 and dc == 0: continue
                            nr, nc = r0 + dr, c0 + dc
                            if 0 <= nr < H and 0 <= nc < W and not seen[nr][nc] and grid[nr][nc] == col:
                                seen[nr][nc] = True; q.append((nr, nc))
                objs.append((col, cells))
    return objs

def _line_of(cells):
    # returns (type, line_constant, v_start, v_end) where v is the coordinate
    # perpendicular to the segment, measured at its two ends
    rs = [p[0] for p in cells]; cs = [p[1] for p in cells]
    r0, r1 = min(rs), max(rs); c0, c1 = min(cs), max(cs)
    if r0 == r1: return ('h', r0, c0, c1)                 # horizontal: v = column
    if c0 == c1: return ('v', c0, r0, r1)                 # vertical:   v = row
    if all(r + c == r1 + c0 for r, c in cells):
        return ('dl', r1 + c0, r0 - c1, r1 - c0)           # down-left: v = r-c
    if all(r - c == r0 - c0 for r, c in cells):
        return ('dr', r0 - c0, r0 + c0, r1 + c1)           # down-right: v = r+c
    return None

def solution(grid):
    H, W = len(grid), len(grid[0])
    vals = [v for row in grid for v in row]
    bg = max(range(10), key=lambda x: vals.count(x))

    objs = _components8(grid, bg)
    lines = [_line_of(cells) for _, cells in objs]

    def length(L):
        if L is None: return len(objs[lines.index(L)]) if False else 0
        return (L[3] - L[2]) + 1 if L[0] in ('h', 'v') else (L[3] - L[2]) // 2 + 1

    idx = [i for i, L in enumerate(lines) if L is not None]
    if len(idx) < 2:
        return [row[:] for row in grid]

    # reference = the second-longest segment
    ref = sorted(idx, key=lambda i: (-length(lines[i]), objs[i][0]))[1]
    _, _, a1, b1 = lines[ref]

    out = [[bg] * W for _ in range(H)]
    for (col, cells), (typ, K, a, b) in zip(objs, lines):
        if typ is None:
            for r, c in cells: out[r][c] = col
            continue
        if typ == 'h':
            for c in range(a1, b1 + 1):
                if 0 <= c < W: out[K][c] = col
        elif typ == 'v':
            for r in range(a1, b1 + 1):
                if 0 <= r < H: out[r][K] = col
        elif typ == 'dl':            # r+c = K, v = r-c  -> r = (K+v)//2
            for v in range(a1, b1 + 1):
                if (K + v) % 2 == 0:
                    r = (K + v) // 2; c = r - v
                    if 0 <= r < H and 0 <= c < W: out[r][c] = col
        else:                        # r-c = K, v = r+c  -> r = (v-K)//2
            for v in range(a1, b1 + 1):
                if (K + v) % 2 == 0:
                    r = (v - K) // 2; c = v - r
                    if 0 <= r < H and 0 <= c < W: out[r][c] = col
    return out
