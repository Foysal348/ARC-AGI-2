def solution(grid):
    H = len(grid)
    W = len(grid[0])
    from collections import Counter
    cnt = Counter(c for row in grid for c in row)
    bg = cnt.most_common(1)[0][0]
    nonbg = [c for c in cnt if c != bg]
    marker = min(nonbg, key=lambda c: cnt[c])          # the small yellow bar
    objcolors = [c for c in nonbg if c != marker]

    ys = [r for r in range(H) for c in range(W) if grid[r][c] == marker]
    xs = [c for r in range(H) for c in range(W) if grid[r][c] == marker]
    out = [row[:] for row in grid]

    if len(set(ys)) == 1:
        # horizontal bar on an edge -> beam travels vertically
        r = ys[0]
        c0, c1 = min(xs), max(xs)
        direction = 1 if r == 0 else -1
        for k in range(H):
            d = (k - r) * direction
            if d < 0:
                continue
            m = d % 6
            if m == 4:
                for c in range(W):
                    if grid[k][c] in objcolors:
                        out[k][c] = 3
                for c in range(c0, c1 + 1):
                    out[k][c] = 3
            elif m in (0, 2):
                for c in range(c0, c1 + 1):
                    out[k][c] = 4
            else:
                for c in range(c0, c1 + 1):
                    out[k][c] = bg
    else:
        # vertical bar on an edge -> beam travels horizontally
        c = xs[0]
        r0, r1 = min(ys), max(ys)
        direction = 1 if c == 0 else -1
        for k in range(W):
            d = (k - c) * direction
            if d < 0:
                continue
            m = d % 6
            if m == 4:
                for r in range(H):
                    if grid[r][k] in objcolors:
                        out[r][k] = 3
                for r in range(r0, r1 + 1):
                    out[r][k] = 3
            elif m in (0, 2):
                for r in range(r0, r1 + 1):
                    out[r][k] = 4
            else:
                for r in range(r0, r1 + 1):
                    out[r][k] = bg
    return out
