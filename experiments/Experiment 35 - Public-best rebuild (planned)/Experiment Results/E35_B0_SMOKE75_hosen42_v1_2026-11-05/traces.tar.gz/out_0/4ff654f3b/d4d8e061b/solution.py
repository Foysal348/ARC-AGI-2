def solution(grid):
    """
    Rule:
    - A solid vertical wall splits the input: a 7-wide left region holding small
      3x3 glyph-shapes (two columns of them, stacked in bands), and a right region
      that is empty except for one gray marker.
    - The output is the right region (same height, width = cols right of the wall).
      The gray marker is the starting point of a chain.
    - The glyphs are read column by column: all shapes of the left column top->bottom,
      then all shapes of the right column top->bottom. Each glyph adds one straight
      bar of its own colour to the end of the chain: the chain always first steps one
      cell down, then runs in the bar direction given by the glyph's shape.
      Symbol meanings (learned from the training examples):
        101/101/111  -> length 2, going left
        101/010/010  -> length 2, going down
        110/101/010  -> length 3, going right
        111/010/101  -> length 4, going left
      (a mirrored glyph flips the horizontal direction).
    """
    H, W = len(grid), len(grid[0])

    # the solid vertical wall column
    wall = 0
    for c in range(W):
        vals = {grid[r][c] for r in range(H)}
        if len(vals) == 1 and next(iter(vals)) != 0:
            wall = c
            break

    out = [[0] * (W - wall - 1) for _ in range(H)]

    # gray marker in the right region -> start of the chain
    start = None
    for r in range(H):
        for c in range(wall + 1, W):
            if grid[r][c] != 0:
                start = (r, c - wall - 1, grid[r][c])
    out[start[0]][start[1]] = start[2]

    def comps(g):
        h, w = len(g), len(g[0])
        seen, res = set(), []
        for r in range(h):
            for c in range(w):
                if g[r][c] == 0 or (r, c) in seen:
                    continue
                stack, seen_local, cells = [(r, c)], set(), []
                stack = [(r, c)]
                seen.add((r, c))
                while stack:
                    x, y = stack.pop()
                    cells.append((x, y))
                    for dx in (-1, 0, 1):
                        for dy in (-1, 0, 1):
                            nx, ny = x + dx, y + dy
                            if 0 <= nx < h and 0 <= ny < w and g[nx][ny] != 0 and (nx, ny) not in seen:
                                seen.add((nx, ny))
                                stack.append((nx, ny))
                res.append((g[cells[0][0]][cells[0][1]], sorted(cells)))
        return res

    def pattern(cells):
        s = set(cells)
        rs = [r for r, c in cells]
        cs = [c for r, c in cells]
        r0, r1, c0, c1 = min(rs), max(rs), min(cs), max(cs)
        return ''.join(''.join('1' if (r, c) in s else '0' for c in range(c0, c1 + 1))
                       for r in range(r0, r1 + 1))

    SYM = {"101101111": ("L", 2),   # two arms + base  -> 2 cells left
           "101010010": ("D", 2),   # funnel          -> 2 cells down
           "110101010": ("R", 3),   # zig-zag         -> 3 cells right
           "111010101": ("L", 4)}   # wide T          -> 4 cells left
    FLIP = {"L": "R", "R": "L", "D": "D"}

    def mirror(p):
        return ''.join(p[3 * i:3 * i + 3][::-1] for i in range(3))

    left, right = [], []
    for color, cells in comps([row[:wall] for row in grid]):
        p = pattern(cells)
        if p in SYM:
            d, L = SYM[p]
        else:
            d, L = SYM[mirror(p)]
            d = FLIP[d]
        bucket = left if max(c for r, c in cells) < wall - 1 else right
        bucket.append((min(r for r, c in cells), color, d, L))

    cur = (start[0], start[1])
    for _row, color, d, L in sorted(left) + sorted(right):
        nr, nc = cur[0] + 1, cur[1]          # always step one row down first
        dr, dc = {"D": (1, 0), "L": (0, -1), "R": (0, 1)}[d]
        for i in range(L):
            out[nr + dr * i][nc + dc * i] = color
        cur = (nr + dr * (L - 1), nc + dc * (L - 1))
    return out
