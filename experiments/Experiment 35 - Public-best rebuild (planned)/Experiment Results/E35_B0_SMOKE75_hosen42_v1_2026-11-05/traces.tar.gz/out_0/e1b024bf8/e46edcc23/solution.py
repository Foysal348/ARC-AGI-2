from collections import Counter

def _components(grid, bg):
    H = len(grid); W = len(grid[0])
    seen = [[False] * W for _ in range(H)]
    res = []
    for r in range(H):
        for c in range(W):
            if grid[r][c] != bg and not seen[r][c]:
                st = [(r, c)]; seen[r][c] = True; cells = []
                while st:
                    x, y = st.pop(); cells.append((x, y))
                    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        nx, ny = x + dx, y + dy
                        if 0 <= nx < H and 0 <= ny < W and not seen[nx][ny] and grid[nx][ny] != bg:
                            seen[nx][ny] = True; st.append((nx, ny))
                res.append(cells)
    return res

def solution(grid):
    H = len(grid); W = len(grid[0])
    out = [row[:] for row in grid]
    bg = Counter(v for row in grid for v in row).most_common(1)[0][0]
    comps = _components(grid, bg)

    boxes = []          # framed squares with a coloured interior
    singles = Counter() # single-cell components (the legend row)
    for cells in comps:
        rs = [p[0] for p in cells]; cs = [p[1] for p in cells]
        r0, r1, c0, c1 = min(rs), max(rs), min(cs), max(cs)
        if r1 - r0 >= 2 and c1 - c0 >= 2:
            frame = grid[r0][c0]
            inner = Counter()
            for r in range(r0 + 1, r1):
                for c in range(c0 + 1, c1):
                    if grid[r][c] != frame:
                        inner[grid[r][c]] += 1
            col = inner.most_common(1)[0][0]
            irows = sorted({r for r in range(r0 + 1, r1) for c in range(c0 + 1, c1) if grid[r][c] == col})
            icols = sorted({c for r in range(r0 + 1, r1) for c in range(c0 + 1, c1) if grid[r][c] == col})
            boxes.append(dict(r0=r0, r1=r1, c0=c0, c1=c1, color=col, irows=irows, icols=icols))
        else:
            singles[r0] += 1

    # legend = the row made of single cells, read left to right
    lrow = max(singles, key=lambda r: singles[r])
    legend = [grid[lrow][c] for c in range(W) if grid[lrow][c] != bg]

    # match legend entries to boxes: k-th occurrence of a colour in legend
    # -> k-th occurrence of that colour in reading order of the boxes
    boxes.sort(key=lambda b: (b["r0"], b["c0"]))
    byc = {}
    for b in boxes:
        byc.setdefault(b["color"], []).append(b)
    used = {}
    chain = []
    for col in legend:
        k = used.get(col, 0)
        lst = byc.get(col, [])
        chain.append(lst[k] if k < len(lst) else None)
        used[col] = k + 1

    # connect each consecutive pair with a straight line of the first box's colour
    for i in range(len(chain) - 1):
        A, B = chain[i], chain[i + 1]
        if A is None or B is None:
            continue
        col = A["color"]
        ro = set(A["irows"]) & set(B["irows"])
        co = set(A["icols"]) & set(B["icols"])
        if ro:                                   # horizontal connection
            r0, r1 = min(ro), max(ro)
            if A["c1"] < B["c0"]:
                lo, hi = A["c1"] + 1, B["c0"] - 1
            else:
                lo, hi = B["c1"] + 1, A["c0"] - 1
            for r in range(r0, r1 + 1):
                for c in range(lo, hi + 1):
                    if grid[r][c] == bg:
                        out[r][c] = col
        elif co:                                 # vertical connection
            c0, c1 = min(co), max(co)
            if A["r1"] < B["r0"]:
                lo, hi = A["r1"] + 1, B["r0"] - 1
            else:
                lo, hi = B["r1"] + 1, A["r0"] - 1
            for r in range(lo, hi + 1):
                for c in range(c0, c1 + 1):
                    if grid[r][c] == bg:
                        out[r][c] = col
    return out
