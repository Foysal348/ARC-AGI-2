def solution(grid):
    n = len(grid)
    m = len(grid[0])
    # bounding box of the black "key" rectangle
    blacks = [(r, c) for r in range(n) for c in range(m) if grid[r][c] == 0]
    r0 = min(r for r, c in blacks)
    r1 = max(r for r, c in blacks)
    c0 = min(c for r, c in blacks)
    c1 = max(c for r, c in blacks)
    h = r1 - r0 + 1
    w = c1 - c0 + 1

    # key: row offset inside the box -> color listed there
    key = {}
    for r in range(r0, r1 + 1):
        for c in range(c0, c1 + 1):
            if grid[r][c] != 0:
                key[r - r0] = grid[r][c]

    # 8-connected components of a given color, excluding those inside the key box
    def components(color):
        cells = {(r, c) for r in range(n) for c in range(m) if grid[r][c] == color}
        seen = set()
        out = []
        for cell in cells:
            if cell in seen:
                continue
            stack = [cell]
            seen.add(cell)
            comp = []
            while stack:
                r, c = stack.pop()
                comp.append((r, c))
                for dr in (-1, 0, 1):
                    for dc in (-1, 0, 1):
                        nb = (r + dr, c + dc)
                        if nb in cells and nb not in seen:
                            seen.add(nb)
                            stack.append(nb)
            out.append(comp)
        return [cm for cm in out
                if not (r0 <= cm[0][0] <= r1 and c0 <= cm[0][1] <= c1)]

    out = [[0] * w for _ in range(h)]
    for off, color in sorted(key.items()):
        k = len(components(color))
        for i in range(k):
            col = 1 + 2 * i
            if col < w:
                out[off][col] = color
    return out
