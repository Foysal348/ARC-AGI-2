from collections import deque, Counter

def solution(grid):
    R = len(grid)
    C = len(grid[0])

    # background = colour of the frame (outermost cells)
    border = ([grid[0][c] for c in range(C)] + [grid[R - 1][c] for c in range(C)] +
              [grid[r][0] for r in range(R)] + [grid[r][C - 1] for r in range(R)])
    bg = Counter(border).most_common(1)[0][0]

    # the "corridor": every non-background cell (the shape lies under the markers too)
    mask = [[grid[r][c] != bg for c in range(C)] for r in range(R)]

    # the black square: its size k and its starting placement (top-left corner)
    blk = [(r, c) for r in range(R) for c in range(C) if grid[r][c] == 0]
    r0 = min(p[0] for p in blk); c0 = min(p[1] for p in blk)
    r1 = max(p[0] for p in blk); c1 = max(p[1] for p in blk)
    k = r1 - r0 + 1

    # colour that makes up the shape itself (used to reveal the vacated spot)
    fill = Counter(grid[r][c] for r in range(R) for c in range(C)
                   if grid[r][c] not in (bg, 0, 2)).most_common(1)[0][0]

    # every placement of a k x k square that fits completely inside the corridor
    P = set()
    for r in range(R - k + 1):
        for c in range(C - k + 1):
            if all(mask[r + dr][c + dc] for dr in range(k) for dc in range(k)):
                P.add((r, c))

    # slide the square one cell at a time through the corridor (BFS)
    dist = {(r0, c0): 0}
    q = deque([(r0, c0)])
    while q:
        p = q.popleft()
        for n in ((p[0] + 1, p[1]), (p[0] - 1, p[1]), (p[0], p[1] + 1), (p[0], p[1] - 1)):
            if n in P and n not in dist:
                dist[n] = dist[p] + 1
                q.append(n)

    # it ends at the farthest reachable position (the other end of the corridor)
    target = max(dist, key=lambda p: dist[p])

    out = [row[:] for row in grid]
    for (r, c) in blk:
        out[r][c] = fill
    for dr in range(k):
        for dc in range(k):
            out[target[0] + dr][target[1] + dc] = 0
    return out
