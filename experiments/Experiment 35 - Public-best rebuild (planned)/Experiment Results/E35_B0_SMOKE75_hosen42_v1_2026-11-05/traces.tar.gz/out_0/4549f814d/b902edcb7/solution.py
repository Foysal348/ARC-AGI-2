from collections import Counter, deque

def solution(grid):
    h = len(grid); w = len(grid[0])
    cnt = Counter(v for row in grid for v in row)
    bg = cnt.most_common(1)[0][0]
    nonbg = [(r, c) for r in range(h) for c in range(w) if grid[r][c] != bg]

    def comps4(sel):
        sel = set(sel); seen = set(); res = []
        for p in sel:
            if p in seen: continue
            q = deque([p]); seen.add(p); comp = set()
            while q:
                r, c = q.popleft(); comp.add((r, c))
                for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    n = (r + dr, c + dc)
                    if n in sel and n not in seen:
                        seen.add(n); q.append(n)
            res.append(comp)
        return res

    # colour that forms a single component = the connecting wire
    colors = sorted(set(grid[r][c] for r, c in nonbg))
    bycol = {col: comps4([p for p in nonbg if grid[p[0]][p[1]] == col]) for col in colors}
    singles = [col for col in colors if len(bycol[col]) == 1]
    path_col = max(singles, key=lambda c: len(bycol[c][0]))
    path_cells = bycol[path_col][0]

    # blobs: 8-connected groups of the other colours; each has a dominant colour
    blobcells = [p for p in nonbg if grid[p[0]][p[1]] != path_col]
    sel = set(blobcells); seen = set(); blobs = []
    for p in blobcells:
        if p in seen: continue
        q = deque([p]); seen.add(p); grp = set()
        while q:
            r, c = q.popleft(); grp.add((r, c))
            for dr in (-1, 0, 1):
                for dc in (-1, 0, 1):
                    n = (r + dr, c + dc)
                    if n in sel and n not in seen:
                        seen.add(n); q.append(n)
        cc = Counter(grid[r][c] for r, c in grp)
        dom = max(cc, key=lambda col: (cc[col], -col))
        blobs.append((grp, dom))

    # find the wire's solid 3x3 square (the loop)
    ring = None
    for r in range(h - 2):
        for c in range(w - 2):
            if all((r + dr, c + dc) in path_cells for dr in range(3) for dc in range(3)):
                ring = (r, c); break
        if ring: break
    center = (ring[0] + 1, ring[1] + 1)
    ring3 = {(ring[0] + dr, ring[1] + dc) for dr in range(3) for dc in range(3)}

    # every wire piece (after removing the loop) takes the colour of the blob it touches
    rest = path_cells - ring3
    out = [row[:] for row in grid]
    tally = Counter()
    for comp in comps4(rest):
        touch = Counter()
        for (r, c) in comp:
            for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                n = (r + dr, c + dc)
                for grp, dom in blobs:
                    if n in grp:
                        touch[dom] += 1
        if touch:
            col = max(touch, key=lambda d: (touch[d], -d))
            for (r, c) in comp:
                out[r][c] = col
            tally[col] += len(comp)

    # inside the loop: the colour the wire mostly became; the loop itself keeps the wire colour
    if tally:
        best = max(tally, key=lambda d: (tally[d], -d))
        out[center[0]][center[1]] = best
    return out
