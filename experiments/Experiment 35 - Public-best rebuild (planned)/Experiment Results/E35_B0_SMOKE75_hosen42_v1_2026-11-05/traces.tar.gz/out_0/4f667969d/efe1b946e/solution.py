def solution(grid: list[list[int]]) -> list[list[int]]:
    """
    A vertical line divides the grid. On one side of the line there are
    horizontal bars (contiguous runs of coloured cells). Each bar is
    "projected" through the line onto the empty side: each colour segment of
    the bar (measured from the end nearest the line outward) is repeated on
    the other side with a period equal to the length of that segment, i.e. the
    colour is placed at distances 1*len, 2*len, 3*len ... from the line.
    Segments nearer the line are painted first and only fill empty cells,
    so a nearer (shorter-period) segment overwrites a farther one.
    """
    H = len(grid)
    W = len(grid[0])

    # --- find the vertical line: the longest contiguous same-colour run in a column
    best = None  # (length, colour, column)
    for c in range(W):
        r = 0
        while r < H:
            v = grid[r][c]
            if v == 0:
                r += 1
                continue
            r1 = r
            while r1 + 1 < H and grid[r1 + 1][c] == v:
                r1 += 1
            if r1 > r and (best is None or r1 - r + 1 > best[0]):
                best = (r1 - r + 1, v, c)
            r = r1 + 1
    if best is None:
        return [row[:] for row in grid]

    runlen, line_color, L = best
    out = [row[:] for row in grid]

    # --- which side holds the bars?
    left_has = any(grid[r][c] != 0 for r in range(H) for c in range(L))
    right_has = any(grid[r][c] != 0 for r in range(H) for c in range(L + 1, W))
    bar_side = 'L' if left_has else 'R'

    for r in range(H):
        # scan the bar side from the line outward, collecting runs of nonzero cells
        scan = range(L - 1, -1, -1) if bar_side == 'L' else range(L + 1, W)
        runs = []
        cur = []
        for c in scan:
            v = grid[r][c]
            if v != 0:
                cur.append(v)
            else:
                if cur:
                    runs.append(cur)
                    cur = []
        if cur:
            runs.append(cur)

        # process runs nearest the line first
        for run in runs:
            # split run into same-colour segments, ordered from the line outward
            segs = []
            for v in run:
                if segs and segs[-1][0] == v:
                    segs[-1][1] += 1
                else:
                    segs.append([v, 1])
            # paint each segment at every distance that is a multiple of its length
            fill = range(L + 1, W) if bar_side == 'L' else range(L - 1, -1, -1)
            for color, ln in segs:
                for c in fill:
                    p = abs(c - L) - 1
                    if p % ln == 0 and out[r][c] == 0:
                        out[r][c] = color
    return out
