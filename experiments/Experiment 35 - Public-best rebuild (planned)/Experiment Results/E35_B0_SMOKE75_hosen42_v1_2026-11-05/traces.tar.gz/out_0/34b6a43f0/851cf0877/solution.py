from collections import Counter, deque

def _components(g, bg):
    """4-connected components of non-background cells; returns list of cell lists."""
    seen = set()
    out = []
    H, W = len(g), len(g[0])
    for r in range(H):
        for c in range(W):
            if g[r][c] == bg or (r, c) in seen:
                continue
            q = deque([(r, c)])
            seen.add((r, c))
            cells = []
            while q:
                x, y = q.popleft()
                cells.append((x, y))
                for nx, ny in [(x+1, y), (x-1, y), (x, y+1), (x, y-1)]:
                    if 0 <= nx < H and 0 <= ny < W and g[nx][ny] != bg and (nx, ny) not in seen:
                        seen.add((nx, ny))
                        q.append((nx, ny))
            out.append(cells)
    return out

def solution(grid):
    g = [list(r) for r in grid]
    H, W = len(g), len(g[0])
    bg = Counter(x for r in g for x in r).most_common(1)[0][0]
    comps = _components(g, bg)

    # single-cell components = the key template; multi-cell components = the blocks
    key_cells = [c[0] for c in comps if len(c) == 1]
    blocks = [c for c in comps if len(c) > 1]
    if not key_cells or not blocks:
        return g

    # build the key matrix (rows/cols of the key dots)
    kr = sorted({r for r, c in key_cells})
    kc = sorted({c for r, c in key_cells})
    K = [[g[r][c] for c in kc] for r in kr]

    # block info: (left col, top row, height, width, color), sorted left to right
    info = []
    for b in blocks:
        rs = [x for x, y in b]
        cs = [y for x, y in b]
        info.append((min(cs), min(rs), max(rs) - min(rs) + 1, max(cs) - min(cs) + 1,
                     g[min(rs)][min(cs)]))
    info.sort()
    n = len(info)
    size = info[0][2]
    spacing = info[1][0] - info[0][0] if n > 1 else size + 1
    anchor_col, anchor_row = info[0][0], info[0][1]
    colors = [it[4] for it in info]

    nR, nC = len(K), len(K[0])

    # find the key row (and column offset) that matches the existing blocks
    match = None
    for r0 in range(nR):
        for c0 in range(nC - n + 1):
            if all(K[r0][c0 + i] == colors[i] for i in range(n)):
                match = (r0, c0)
                break
        if match:
            break
    if match is None:
        return g
    r0, c0 = match

    # expand the key into a grid of blocks
    for ri in range(nR):
        for ci in range(nC):
            col = K[ri][ci]
            if col == bg:
                continue
            br = anchor_row + (ri - r0) * spacing
            bc = anchor_col + (ci - c0) * spacing
            if br < 0 or bc < 0 or br + size > H or bc + size > W:
                continue
            for x in range(br, br + size):
                for y in range(bc, bc + size):
                    g[x][y] = col
    return g
