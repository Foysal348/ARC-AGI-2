from collections import Counter

def solution(grid):
    """
    Rule (deduced from the training examples):
    - The background is the most common colour. Objects are 4-connected groups:
      a "diamond" (3-5-3 shape) and single 5-cell horizontal bars at the bottom
      edge (a diamond cut off by the edge).
    - Objects form vertical stacks in columns (4 rows apart).
    - A column whose stack is cut off by a bar at the bottom edge:
      * bar colour green (3): the stack "absorbs" the objects of all columns with
        a red (2) bar -> its count becomes its own count + total count of the
        red-bar stacks, new diamonds added above the stack (spacing 4 rows).
      * bar colour red (2): the stack stays in place but turns gray (5),
        and the bar itself disappears.
    - Columns without a bar are unchanged.
    """
    R, C = len(grid), len(grid[0])
    bg = Counter(v for r in grid for v in r).most_common(1)[0][0]

    # connected components (4-connectivity) of non-background cells
    seen = [[False] * C for _ in range(R)]
    comps = []
    for r0 in range(R):
        for c0 in range(C):
            if grid[r0][c0] != bg and not seen[r0][c0]:
                st = [(r0, c0)]
                seen[r0][c0] = True
                cells = []
                while st:
                    a, b = st.pop()
                    cells.append((a, b))
                    for da, db in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        na, nb = a + da, b + db
                        if 0 <= na < R and 0 <= nb < C and not seen[na][nb] and grid[na][nb] != bg:
                            seen[na][nb] = True
                            st.append((na, nb))
                comps.append((grid[cells[0][0]][cells[0][1]], sorted(cells)))

    out = [[bg] * C for _ in range(R)]
    bars = {}      # (col0, col1) -> bar colour
    stacks = {}    # (col0, col1) -> list of (colour, cells)
    for col, cells in comps:
        rs = [r for r, c in cells]
        cs = [c for r, c in cells]
        key = (min(cs), max(cs))
        if len(set(rs)) == 1:          # a flat bar (cut-off object at edge)
            bars[key] = col
        else:
            stacks.setdefault(key, []).append((col, cells))

    GREEN = 3
    GRAY = 5
    # total number of diamonds in columns marked by a non-green bar
    absorbed = sum(len(stacks.get(k, [])) for k, c in bars.items() if c != GREEN)

    for key, st in stacks.items():
        st_sorted = sorted(st, key=lambda x: min(r for r, c in x[1]))
        bar = bars.get(key)
        color = GRAY if (bar is not None and bar != GREEN) else st_sorted[0][0]
        add = absorbed if bar == GREEN else 0

        for col, cells in st_sorted:
            for (r, c) in cells:
                out[r][c] = color
        base = st_sorted[0][1]          # topmost diamond of the stack
        for i in range(add):
            for (r, c) in base:
                nr = r - 4 * (i + 1)
                if 0 <= nr < R:
                    out[nr][c] = color
    return out
