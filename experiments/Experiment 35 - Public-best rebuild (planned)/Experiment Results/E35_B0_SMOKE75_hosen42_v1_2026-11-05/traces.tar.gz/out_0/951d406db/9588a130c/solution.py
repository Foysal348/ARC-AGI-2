from collections import Counter, deque

def solution(grid: list[list[int]]) -> list[list[int]]:
    g = [row[:] for row in grid]
    H, W = len(g), len(g[0])

    # ---- 1. find the "key" blocks: solid rectangles (3x3 .. 8x8) of one color
    #         that contain two other marker colors ----
    seen = [[False] * W for _ in range(H)]
    comps = []
    for r in range(H):
        for c in range(W):
            if g[r][c] != 0 and not seen[r][c]:
                q = deque([(r, c)]); seen[r][c] = True; cl = []
                while q:
                    rr, cc = q.popleft(); cl.append((rr, cc))
                    for dr in (-1, 0, 1):
                        for dc in (-1, 0, 1):
                            nr, nc = rr + dr, cc + dc
                            if 0 <= nr < H and 0 <= nc < W and g[nr][nc] != 0 and not seen[nr][nc]:
                                seen[nr][nc] = True; q.append((nr, nc))
                comps.append(cl)

    keys = []
    for cl in comps:
        r0 = min(p[0] for p in cl); r1 = max(p[0] for p in cl)
        c0 = min(p[1] for p in cl); c1 = max(p[1] for p in cl)
        h, w = r1 - r0 + 1, c1 - c0 + 1
        if len(cl) != h * w:          # must be a filled rectangle
            continue
        if not (3 <= h <= 8 and 3 <= w <= 8):
            continue
        cnt = Counter(g[r][c] for r in range(r0, r1 + 1) for c in range(c0, c1 + 1))
        if len(cnt) < 3:
            continue
        bg = cnt.most_common(1)[0][0]
        keys.append((bg, r0, r1, c0, c1, cnt))

    # ---- 2. direction of a key: translation that moves the shape onto the
    #         (red) target shape; smallest such shift wins ----
    def direction(blk):
        bg, r0, r1, c0, c1, cnt = blk
        mk = [c for c in cnt if c != bg]
        if 2 in mk:
            tgt = [(r, c) for r in range(r0, r1 + 1) for c in range(c0, c1 + 1) if g[r][c] == 2]
            src = [(r, c) for r in range(r0, r1 + 1) for c in range(c0, c1 + 1)
                   if g[r][c] not in (bg, 2)]
        else:
            mk = sorted(mk, key=lambda x: cnt[x])
            tc, sc_ = mk[0], mk[1]
            tgt = [(r, c) for r in range(r0, r1 + 1) for c in range(c0, c1 + 1) if g[r][c] == tc]
            src = [(r, c) for r in range(r0, r1 + 1) for c in range(c0, c1 + 1) if g[r][c] == sc_]
        best, bestsc = None, -1
        for s in src:
            for t in tgt:
                v = (t[0] - s[0], t[1] - s[1])
                sh = {(s2[0] + v[0], s2[1] + v[1]) for s2 in src}
                sc = sum(1 for t2 in tgt if t2 in sh)
                n = abs(v[0]) + abs(v[1])
                if best is None or sc > bestsc or (sc == bestsc and n < abs(best[0]) + abs(best[1])):
                    best, bestsc = v, sc
        return best

    dirs = {blk[0]: direction(blk) for blk in keys}

    # ---- 3. the moving dots: every color that never appears inside a key block ----
    in_keys = set()
    for blk in keys:
        in_keys.update(blk[5])
    markers = [(r, c) for r in range(H) for c in range(W)
               if g[r][c] != 0 and g[r][c] not in in_keys]

    # ---- 4. black rooms (4-connected free space) ----
    seenb = [[False] * W for _ in range(H)]
    rooms = []
    for r in range(H):
        for c in range(W):
            if g[r][c] == 0 and not seenb[r][c]:
                q = deque([(r, c)]); seenb[r][c] = True; cl = set()
                while q:
                    rr, cc = q.popleft(); cl.add((rr, cc))
                    for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        nr, nc = rr + dr, cc + dc
                        if 0 <= nr < H and 0 <= nc < W and g[nr][nc] == 0 and not seenb[nr][nc]:
                            seenb[nr][nc] = True; q.append((nr, nc))
                rooms.append(cl)

    def room_of(cell):
        res = set()
        for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            p = (cell[0] + dr, cell[1] + dc)
            for rp in rooms:
                if p in rp:
                    res |= rp
        return res

    out = [row[:] for row in g]
    for m in markers:
        room = room_of(m)
        if not room:
            continue
        # wall color of the room -> which key applies
        cnt = Counter()
        for (r, c) in room:
            for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                nr, nc = r + dr, c + dc
                if 0 <= nr < H and 0 <= nc < W and g[nr][nc] != 0:
                    cnt[g[nr][nc]] += 1
        fc = None
        for col, _ in cnt.most_common():
            if col in dirs:
                fc = col; break
        if fc is None:
            continue
        d = dirs[fc]
        r, c = m
        while True:
            nr, nc = r + d[0], c + d[1]
            if 0 <= nr < H and 0 <= nc < W and (nr, nc) in room:
                r, c = nr, nc
            else:
                break
        out[m[0]][m[1]] = 0
        out[r][c] = g[m[0]][m[1]]
    return out
