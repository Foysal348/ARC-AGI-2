def find_bars(g):
    H = len(g)
    W = len(g[0])
    bars = []
    for c in range(W):
        r = 0
        while r < H:
            if g[r][c] != 0:
                s = r
                while r + 1 < H and g[r + 1][c] != 0:
                    r += 1
                run = [g[x][c] for x in range(s, r + 1)]
                if len(run) >= 3 and run[0] == run[-1] and len(set(run[1:-1])) == 1 and run[1] != run[0]:
                    bars.append((c, s, r, run[0], run[1], r - s - 1))
            r += 1
    return bars


def find_markers(g):
    H = len(g)
    W = len(g[0])
    markers = {}
    for c in range(W):
        if g[0][c] != 0:
            col = g[0][c]
            n = 0
            while n < H and g[n][c] == col:
                n += 1
            markers[col] = n
    return markers


def solution(grid):
    g = [row[:] for row in grid]
    bars = find_bars(g)
    markers = find_markers(g)

    # group bars by cap (top/bottom) color
    groups = {}
    for (c, r1, r2, cap, inner, L) in bars:
        groups.setdefault(cap, []).append((L, c, r1, r2))

    # marker color = which cap-color group, marker height = rank (tallest first)
    for cap, rank in markers.items():
        grp = sorted(groups.get(cap, []), key=lambda x: (-x[0], x[1]))
        if rank - 1 < len(grp):
            L, c, r1, r2 = grp[rank - 1]
            for r in range(r1 + 1, r2):
                g[r][c] = cap
    return g
