def solution(grid):
    """
    Rule: every non-background object is a left-right mirror symmetric shape
    that has been "corrupted" by a few extra cells.  For each object we look
    for the vertical mirror axis that keeps the largest number of cells whose
    mirror image is also present, and delete all the other (asymmetric) cells.
    Ties on the axis are resolved by preferring the axis whose deleted cells
    form the fewest connected blobs (a single protrusion), then the narrowest
    remaining shape.
    """
    H, W = len(grid), len(grid[0])

    # background = most frequent colour
    cnt = {}
    for row in grid:
        for v in row:
            v = int(v)
            cnt[v] = cnt.get(v, 0) + 1
    bg = max(cnt, key=lambda k: cnt[k])

    out = [[bg] * W for _ in range(H)]

    def comps(cells, conn=8):
        nbrs = [(1, 0), (-1, 0), (0, 1), (0, -1)]
        if conn == 8:
            nbrs += [(1, 1), (-1, -1), (1, -1), (-1, 1)]
        seen = set()
        res = []
        for p in cells:
            if p in seen:
                continue
            st = [p]
            seen.add(p)
            comp = set()
            while st:
                x, y = st.pop()
                comp.add((x, y))
                for dx, dy in nbrs:
                    q = (x + dx, y + dy)
                    if q in cells and q not in seen:
                        seen.add(q)
                        st.append(q)
            res.append(comp)
        return res

    for col in set(int(v) for row in grid for v in row) - {bg}:
        all_cells = {(r, c) for r in range(H) for c in range(W) if int(grid[r][c]) == col}
        for S in comps(all_cells, 8):
            cs = [p[1] for p in S]
            cands = []
            for x2 in range(2 * min(cs), 2 * max(cs) + 1):      # axis = x2/2
                K = {p for p in S if (p[0], x2 - p[1]) in S}    # cells with a mirror
                if not K:
                    continue
                n_removed_blobs = len(comps(S - K, 8))
                ks = [p[1] for p in K]
                cands.append((len(K), n_removed_blobs, max(ks) - min(ks), x2, K))
            cands.sort(key=lambda t: (-t[0], t[1], t[2], t[3]))
            for (r, c) in cands[0][4]:
                out[r][c] = col
    return out
