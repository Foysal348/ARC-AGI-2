def solution(grid):
    H = len(grid)
    W = len(grid[0])
    out = [row[:] for row in grid]

    # horizontal red bars (contiguous runs)
    bars = []
    for r in range(H):
        c = 0
        while c < W:
            if grid[r][c] == 2:
                c1 = c
                while c + 1 < W and grid[r][c + 1] == 2:
                    c += 1
                bars.append((r, c1, c))
            c += 1
    bars.sort()

    def first_bar(col, s):
        # first bar strictly below row s whose span contains column col
        for (r, c1, c2) in bars:
            if r > s and c1 <= col <= c2:
                return (r, c1, c2)
        return None

    def put(r, c):
        if 0 <= r < H and 0 <= c < W and out[r][c] != 2:
            out[r][c] = 6

    # markers: pink runs starting at the top row
    stack = []
    for c in range(W):
        if grid[0][c] == 6:
            s = 0
            while s + 1 < H and grid[s + 1][c] == 6:
                s += 1
            stack.append((c, s, False))

    seen = set()
    while stack:
        col, s, side = stack.pop()
        if (col, s, side) in seen:
            continue
        seen.add((col, s, side))
        b = first_bar(col, s)
        start = s if side else s + 1
        if b is None:
            # stroke runs to the bottom of the grid
            for r in range(start, H):
                put(r, col)
        else:
            r, c1, c2 = b
            # the stroke itself, down to the row just above the bar
            for rr in range(start, r):
                put(rr, col)
            # top edge of the frame around the bar (clipped to the grid)
            for cc in range(max(0, c1 - 1), min(W - 1, c2 + 1) + 1):
                put(r - 1, cc)
            # new strokes going down along the two sides of the bar
            if c1 - 1 >= 0:
                stack.append((c1 - 1, r, True))
            if c2 + 1 <= W - 1:
                stack.append((c2 + 1, r, True))

    return out
