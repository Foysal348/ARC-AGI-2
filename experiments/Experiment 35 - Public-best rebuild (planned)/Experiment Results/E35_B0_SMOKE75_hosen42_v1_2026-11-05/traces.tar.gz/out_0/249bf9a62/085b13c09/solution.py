from collections import deque

def _comps4(g, bg=0):
    """4-connected components of non-background cells."""
    H, W = len(g), len(g[0])
    vis = [[False] * W for _ in range(H)]
    out = []
    for r in range(H):
        for c in range(W):
            if g[r][c] != bg and not vis[r][c]:
                q = deque([(r, c)])
                vis[r][c] = True
                cells = []
                while q:
                    x, y = q.popleft()
                    cells.append((x, y))
                    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        nx, ny = x + dx, y + dy
                        if 0 <= nx < H and 0 <= ny < W and not vis[nx][ny] and g[nx][ny] != bg:
                            vis[nx][ny] = True
                            q.append((nx, ny))
                out.append(cells)
    return out

def _hole_regions(g, bg=0):
    """Regions of background cells that cannot reach the grid border."""
    H, W = len(g), len(g[0])
    reach = [[False] * W for _ in range(H)]
    q = deque()
    for r in range(H):
        for c in range(W):
            if g[r][c] == bg and (r == 0 or c == 0 or r == H - 1 or c == W - 1) and not reach[r][c]:
                reach[r][c] = True
                q.append((r, c))
    while q:
        x, y = q.popleft()
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            nx, ny = x + dx, y + dy
            if 0 <= nx < H and 0 <= ny < W and not reach[nx][ny] and g[nx][ny] == bg:
                reach[nx][ny] = True
                q.append((nx, ny))
    regs = []
    seen = [[False] * W for _ in range(H)]
    for r in range(H):
        for c in range(W):
            if g[r][c] == bg and not reach[r][c] and not seen[r][c]:
                q = deque([(r, c)])
                seen[r][c] = True
                reg = []
                while q:
                    x, y = q.popleft()
                    reg.append((x, y))
                    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        nx, ny = x + dx, y + dy
                        if 0 <= nx < H and 0 <= ny < W and not seen[nx][ny] and g[nx][ny] == bg and not reach[nx][ny]:
                            seen[nx][ny] = True
                            q.append((nx, ny))
                regs.append(reg)
    return regs

def solution(grid):
    g = [row[:] for row in grid]
    H, W = len(g), len(g[0])

    # the palette: the only component made of several colours (a 2xN or Nx2 block)
    pal = None
    for cells in _comps4(g):
        if len({g[r][c] for r, c in cells}) > 1:
            pal = cells
    if pal is None:
        return g

    rows = sorted({r for r, c in pal})
    cols = sorted({c for r, c in pal})
    mapping = {}
    if len(rows) == 2:              # pairs read top -> bottom
        r0, r1 = rows
        for c in range(cols[0], cols[-1] + 1):
            mapping[g[r0][c]] = g[r1][c]
    else:                            # pairs read left -> right
        c0, c1 = cols
        for r in range(rows[0], rows[-1] + 1):
            mapping[g[r][c0]] = g[r][c1]

    # fill each enclosed (hole) region with the colour its enclosing frame maps to
    fills = []
    for reg in _hole_regions(g):
        enc = set()
        for (x, y) in reg:
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                a, b = x + dx, y + dy
                if 0 <= a < H and 0 <= b < W and g[a][b] != 0:
                    enc.add(g[a][b])
        if not enc:                 # frame closed only diagonally
            for (x, y) in reg:
                for dx, dy in ((1, 1), (1, -1), (-1, 1), (-1, -1)):
                    a, b = x + dx, y + dy
                    if 0 <= a < H and 0 <= b < W and g[a][b] != 0:
                        enc.add(g[a][b])
        for col in enc:
            if col in mapping:
                for (x, y) in reg:
                    fills.append((x, y, mapping[col]))
    for x, y, col in fills:
        g[x][y] = col
    return g
