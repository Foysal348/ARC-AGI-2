from collections import deque

def solution(grid):
    R, C = len(grid), len(grid[0])

    # 1. find blue (1) objects as 4-connected components
    seen = [[False] * C for _ in range(R)]
    objs = []
    for r in range(R):
        for c in range(C):
            if grid[r][c] == 1 and not seen[r][c]:
                q = deque([(r, c)]); seen[r][c] = True; cells = []
                while q:
                    x, y = q.popleft(); cells.append((x, y))
                    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        nx, ny = x + dx, y + dy
                        if 0 <= nx < R and 0 <= ny < C and not seen[nx][ny] and grid[nx][ny] == 1:
                            seen[nx][ny] = True; q.append((nx, ny))
                objs.append(cells)

    # 2. background cells reachable from outside (flood fill over non-blue cells)
    reach = [[False] * C for _ in range(R)]
    q = deque()
    for r in range(R):
        for c in range(C):
            if (r == 0 or r == R - 1 or c == 0 or c == C - 1) and grid[r][c] != 1 and not reach[r][c]:
                reach[r][c] = True; q.append((r, c))
    while q:
        x, y = q.popleft()
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            nx, ny = x + dx, y + dy
            if 0 <= nx < R and 0 <= ny < C and not reach[nx][ny] and grid[nx][ny] != 1:
                reach[nx][ny] = True; q.append((nx, ny))

    holes = [(r, c) for r in range(R) for c in range(C) if grid[r][c] != 1 and not reach[r][c]]

    out = [row[:] for row in grid]

    # 3. object that encloses a hole -> sky blue (8); the holes -> pink (6)
    for cells in objs:
        rs = [p[0] for p in cells]; cs = [p[1] for p in cells]
        r0, r1, c0, c1 = min(rs), max(rs), min(cs), max(cs)
        if any(r0 <= h[0] <= r1 and c0 <= h[1] <= c1 for h in holes):
            for (r, c) in cells:
                out[r][c] = 8
    for (r, c) in holes:
        out[r][c] = 6

    # 4. red (2) outline: every background cell within 1 cell (8-neighbour) of an object
    for cells in objs:
        objset = set(cells)
        for (r, c) in cells:
            for dr in (-1, 0, 1):
                for dc in (-1, 0, 1):
                    nr, nc = r + dr, c + dc
                    if 0 <= nr < R and 0 <= nc < C and (nr, nc) not in objset and out[nr][nc] == 4:
                        out[nr][nc] = 2

    return out
