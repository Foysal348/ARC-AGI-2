def solution(grid):
    h = len(grid)
    w = len(grid[0])

    # background = most common colour
    counts = {}
    for row in grid:
        for v in row:
            counts[v] = counts.get(v, 0) + 1
    bg = max(counts, key=lambda v: counts[v])

    # cells belonging to the snake
    cells = [(r, c) for r in range(h) for c in range(w) if grid[r][c] != bg]
    S = set(cells)

    # 4-neighbour graph of the snake cells
    nbr = {p: [] for p in cells}
    for p in cells:
        r, c = p
        for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            q = (r + dr, c + dc)
            if q in S:
                nbr[p].append(q)

    # start at the endpoint that is first in reading order (topmost, then leftmost)
    ends = [p for p in cells if len(nbr[p]) <= 1]
    start = min(ends) if ends else min(cells)

    # walk the path
    path = [start]
    prev, cur = None, start
    while True:
        nxts = [q for q in nbr[cur] if q != prev]
        if not nxts:
            break
        prev, cur = cur, nxts[0]
        path.append(cur)

    # group consecutive equal colours into runs, then unfold as a column
    runs = []
    for r, c in path:
        v = grid[r][c]
        if runs and runs[-1][0] == v:
            runs[-1][1] += 1
        else:
            runs.append([v, 1])

    return [[v] for v, k in runs for _ in range(k)]
