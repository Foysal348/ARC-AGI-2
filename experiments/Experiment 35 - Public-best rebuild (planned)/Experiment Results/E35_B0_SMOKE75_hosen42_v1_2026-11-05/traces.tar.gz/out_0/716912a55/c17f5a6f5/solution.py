def solution(grid):
    """
    Recolour every yellow plus/cross (a yellow cell whose four orthogonal
    neighbours are also yellow, plus those four arms) to sky blue (8).
    All other cells are unchanged.
    """
    H = len(grid)
    W = len(grid[0])
    out = [row[:] for row in grid]

    centres = []
    for r in range(H):
        for c in range(W):
            if grid[r][c] == 4 and 0 < r < H - 1 and 0 < c < W - 1:
                if (grid[r - 1][c] == 4 and grid[r + 1][c] == 4 and
                        grid[r][c - 1] == 4 and grid[r][c + 1] == 4):
                    centres.append((r, c))

    for r, c in centres:
        for dr, dc in ((0, 0), (-1, 0), (1, 0), (0, -1), (0, 1)):
            out[r + dr][c + dc] = 8

    return out
