from collections import Counter

def flood_fill(g, pred):
    H, W = len(g), len(g[0])
    seen = [[False] * W for _ in range(H)]
    comps = []
    for r in range(H):
        for c in range(W):
            if seen[r][c] or not pred(g[r][c]):
                continue
            st = [(r, c)]
            seen[r][c] = True
            cells = []
            while st:
                x, y = st.pop()
                cells.append((x, y))
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < H and 0 <= ny < W and not seen[nx][ny] and pred(g[nx][ny]):
                        seen[nx][ny] = True
                        st.append((nx, ny))
            comps.append(cells)
    return comps

def bbox(cells):
    rs = [x for x, y in cells]
    cs = [y for x, y in cells]
    return min(rs), max(rs), min(cs), max(cs)

def solution(grid):
    H, W = len(grid), len(grid[0])
    bg = Counter(v for row in grid for v in row).most_common(1)[0][0]
    comps = flood_fill(grid, lambda v: v != bg)
    info = []
    for c in comps:
        colset = set(grid[x][y] for x, y in c)
        r0, r1, c0, c1 = bbox(c)
        info.append((colset, len(c), r0, r1, c0, c1))

    # the grey rectangular frame: single-colour component that is a solid ring
    frame = None
    for colset, n, r0, r1, c0, c1 in info:
        if len(colset) != 1:
            continue
        col = next(iter(colset))
        per = 2 * (r1 - r0 + 1) + 2 * (c1 - c0 + 1) - 4
        if n == per and all(grid[r][c0] == col and grid[r][c1] == col and
                            grid[r0][c] == col and grid[r1][c] == col
                            for r in range(r0, r1 + 1) for c in range(c0, c1 + 1)):
            frame = (col, r0, r1, c0, c1)
    col, fr0, fr1, fc0, fc1 = frame
    ir0, ir1, ic0, ic1 = fr0 + 1, fr1 - 1, fc0 + 1, fc1 - 1

    # legend keys outside the frame: a two-colour blob (left colour -> right colour)
    legend = {}
    legend_boxes = []
    for colset, n, r0, r1, c0, c1 in info:
        if len(colset) != 2:
            continue
        if fr0 <= r0 <= fr1 and fc0 <= c0 <= fc1:
            continue
        legend[grid[r0][c0]] = grid[r0][c1]
        legend_boxes.append((r0, r1, c0, c1))

    # solid blocks inside the frame, indexed by their slot position
    blocks = {}
    for colset, n, r0, r1, c0, c1 in info:
        if len(colset) != 1:
            continue
        if not (ir0 <= r0 and r1 <= ir1 and ic0 <= c0 and c1 <= ic1):
            continue
        bc = next(iter(colset))
        bh, bw = r1 - r0 + 1, c1 - c0 + 1
        i = (r0 - ir0) // (bh + 1)
        j = (c0 - ic0) // (bw + 1)
        blocks[(i, j)] = (bc, bh, bw)

    h = max(b[1] for b in blocks.values())
    w = max(b[2] for b in blocks.values())
    nr = max(k[0] for k in blocks) + 1
    nc = max(k[1] for k in blocks) + 1

    # shape (glyph) of each block colour: its cells outside the frame and outside the legend
    glyphs = {}
    for bc in set(b[0] for b in blocks.values()):
        pts = [(r, c) for r in range(H) for c in range(W)
               if grid[r][c] == bc and not (fr0 <= r <= fr1 and fc0 <= c <= fc1)
               and not any(a <= r <= b2 and c0 <= c <= c1 for a, b2, c0, c1 in legend_boxes)]
        if pts:
            r0, r1, c0, c1 = bbox(pts)
            glyphs[bc] = [[1 if grid[r][c] == bc else 0 for c in range(c0, c1 + 1)]
                          for r in range(r0, r1 + 1)]

    outH = 2 + nr * (h + 1) + 1
    outW = 2 + nc * (w + 1) + 1
    out = [[bg] * outW for _ in range(outH)]
    for r in range(outH):
        out[r][0] = col
        out[r][outW - 1] = col
    for c in range(outW):
        out[0][c] = col
        out[outH - 1][c] = col

    for (i, j), (bc, _, _) in blocks.items():
        pat = glyphs.get(bc)
        if pat is None:
            continue
        tgt = legend.get(bc, bc)
        R, C = 2 + i * (h + 1), 2 + j * (w + 1)
        for a, row in enumerate(pat):
            for b, v in enumerate(row):
                if v:
                    out[R + a][C + b] = tgt
    return out
