from collections import Counter

def solution(g):
    h = len(g)
    W = len(g[0])
    cnt = Counter(v for row in g for v in row)
    bg = cnt.most_common(1)[0][0]

    # the wall = a column that is one uniform colour (different from the background)
    wall = None
    for c in range(W):
        col = {g[r][c] for r in range(h)}
        if len(col) == 1 and col.pop() != bg:
            wall = c
            break
    wallc = g[0][wall]

    out = [[bg] * W for _ in range(h)]
    for r in range(h):
        out[r][wall] = wallc

    seen = [[False] * W for _ in range(h)]
    red_rows = set()

    for r in range(h):
        for c in range(wall):
            if g[r][c] != bg and not seen[r][c]:
                # 4-connected figure of non-background cells left of the wall
                st = [(r, c)]
                seen[r][c] = True
                cells = []
                while st:
                    a, b = st.pop()
                    cells.append((a, b))
                    for na, nc in ((a + 1, b), (a - 1, b), (a, b + 1), (a, b - 1)):
                        if 0 <= na < h and 0 <= nc < wall and g[na][nc] != bg and not seen[na][nc]:
                            seen[na][nc] = True
                            st.append((na, nc))

                maxc = max(cc for _, cc in cells)
                shift = wall - 1 - maxc          # slide the figure right until it touches the wall

                for rr in sorted({a for a, _ in cells}):
                    row = sorted(cc for a, cc in cells if a == rr)
                    # row touches the wall but is perforated -> red bar on the right of the wall
                    if max(row) == maxc and (max(row) - min(row) + 1) != len(row):
                        red_rows.add(rr)

                for a, b in cells:
                    out[a][b + shift] = g[a][b]

    for rr in red_rows:
        for c in range(wall + 1, W):
            out[rr][c] = 2

    return out
