def solution(grid):
    g = [[int(v) for v in row] for row in grid]
    h, w = len(g), len(g[0])

    # background = most common colour
    cnt = {}
    for row in g:
        for v in row:
            cnt[v] = cnt.get(v, 0) + 1
    bg = max(cnt, key=lambda k: (cnt[k], -k))

    # single-colour, 4-connected objects
    seen = [[False] * w for _ in range(h)]
    objs = []
    for r in range(h):
        for c in range(w):
            if seen[r][c] or g[r][c] == bg:
                continue
            seen[r][c] = True
            stack, cells = [(r, c)], []
            while stack:
                y, x = stack.pop()
                cells.append((y, x))
                for dy, dx in ((-1, 0), (1, 0), (0, -1), (0, 1)):
                    ny, nx = y + dy, x + dx
                    if 0 <= ny < h and 0 <= nx < w and not seen[ny][nx] and g[ny][nx] == g[y][x]:
                        seen[ny][nx] = True
                        stack.append((ny, nx))
            cc = {}
            for y, x in cells:
                cc[g[y][x]] = cc.get(g[y][x], 0) + 1
            col = max(cc, key=lambda k: (cc[k], -k))
            r0 = min(y for y, _ in cells)
            r1 = max(y for y, _ in cells) + 1
            c0 = min(x for _, x in cells)
            c1 = max(x for _, x in cells) + 1
            objs.append({"color": col, "size": len(cells), "rows": (r0, r1), "cols": (c0, c1)})

    # merge objects whose boxes touch or are within 1 cell of each other
    par = list(range(len(objs)))
    def find(x):
        while par[x] != x:
            par[x] = par[par[x]]
            x = par[x]
        return x
    for i in range(len(objs)):
        for j in range(i + 1, len(objs)):
            a, b = objs[i], objs[j]
            dr = max(a["rows"][0] - b["rows"][1], b["rows"][0] - a["rows"][1], 0)
            dc = max(a["cols"][0] - b["cols"][1], b["cols"][0] - a["cols"][1], 0)
            if dr <= 1 and dc <= 1:
                ra, rb = find(i), find(j)
                if ra != rb:
                    par[ra] = rb
    groups = {}
    for i in range(len(objs)):
        groups.setdefault(find(i), []).append(i)
    clusters = sorted(groups.values(), key=lambda idx: -sum(objs[i]["size"] for i in idx))

    # biggest cluster = the structure; the rest = key marks
    big = clusters[0]
    key_marks = [objs[i] for grp in clusters[1:] for i in grp]

    # crop the structure (its bounding box)
    r0 = min(objs[i]["rows"][0] for i in big)
    r1 = max(objs[i]["rows"][1] for i in big)
    c0 = min(objs[i]["cols"][0] for i in big)
    c1 = max(objs[i]["cols"][1] for i in big)
    cr = [row[c0:c1] for row in g[r0:r1]]
    N = len(cr)

    # a key mark of colour c with n cells means: rotate the layer of colour c by n*90 deg clockwise
    rot = {}
    for k in key_marks:
        rot[k["color"]] = (rot.get(k["color"], 0) + k["size"]) % 4

    out = [[0] * N for _ in range(N)]
    for r in range(N):
        for c in range(N):
            v = cr[r][c]
            if not v:
                continue
            rr, cc2 = r, c
            for _ in range(rot.get(v, 0)):
                rr, cc2 = cc2, N - 1 - rr
            out[rr][cc2] = v
    return out
