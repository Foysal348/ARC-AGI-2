# D66 / L66: two 12-hour deep runs of Qwen3.8-27B Poetiq on the 66 hardest eval tasks. Please do a deep analysis (2026-10-17)

**What we ask:**
- A deep, evidence-based analysis of these two runs: what they tell us about how to reach a much higher score with this same model.
- **Verify everything against the files**, including our own analysis in `analysis/`, which may contain mistakes.
- Mark every claim *verified from files* or *hypothesis*.
- End with ranked, concrete recommendations: expected gain, cost in GPU time, and the evidence for each.
- Do not write notebook code.

## 1. Context and fixed constraints

**Competition and goal:**
- Kaggle ARC Prize 2026 (ARC-AGI-2): offline, 12 h on 4×L4.
- The hidden test is **240 tasks** (fact); the public LB scores its 120-task part. Hidden ≈ public evaluation in difficulty.
- **The binding problem is coverage:** finishing the tasks within 12 h.
- Goal: LB 60+ with the same model, Qwen3.8-27B (FP8 now; an INT4 + speculative-decoding engine is coming in Experiment 11). No fine-tuning, no model change.

**Fixed rules:**
- Never fewer than 49,152 thinking tokens per request.
- One change at a time; simple code; a valid submission always.

**Method (Poetiq-style program synthesis):**
1. The model thinks (cap given below; on reaching the cap it is forced to stop thinking and answer within 8,192 tokens), then writes `transform(grid)`.
2. A sandbox checks the program on the train pairs.
3. If all pass, the task stops ("train-verified"). Otherwise the feedback goes into the next iteration, and the task re-queues at the back (FIFO).

Other settings:
- 1 expert, up to 10 iterations, T 1.0.
- attempt_1 / attempt_2 = the two best distinct program outputs per test input.
- The hidden-run clock: last admission 11:45, drain 11:47, hard stop 11:55.

**Baseline R5** (all 120 eval tasks, 77,824 cap, 16 slots):
- 78/172 inputs on eval;
- LB 21.39 on the hidden 240;
- in R5 no task got more than 2 iterations.

## 2. The two runs (identical code except the listed settings)

| | D66 | L66 |
|---|---|---|
| Tasks | the 66 eval tasks R5 did not fully solve (103 test inputs; R5 had 9 of them right) | same |
| Thinking cap | 77,824 | **122,880** (`MAX_MODEL_LEN` 155,648) |
| Slots | 16 | 12 (KV) |
| Seeds | 20261016 / 1 | 20261017 / 2 |
| Notebook | `notebooks/…D66_HARD_DEEP.ipynb` | `notebooks/…L66_HARD_120K.ipynb` |

Both log per iteration, in `poetiq_iterations.jsonl`:
- the program's grid on every test input, plus `test_correct` (known eval answers; logging only, never shown to the solver);
- train soft scores, `p1_finish` (`stop` / `length` = cut at the cap / `drained`) and timestamps.

Other outputs:
- `poetiq_attempt_curve.jsonl`: the deployable two-attempt result after every commit.
- `poetiq_thinking/`: the FULL thinking and answer of every request.
- `poetiq_programs/`: every parsed program.

## 3. Our headline numbers (verify)

| | D66 | L66 |
|---|---|---|
| Inputs right (of 103) | 28 | 34 |
| Of the 94 R5-wrong inputs | 22 | 29 |
| Tokens / tok/s | 10.80 M / 256 | 10.66 M / 254 |
| Requests (iterations 1 / 2 / 3) | 151 (66 / 52 / 33) | 123 (66 / 41 / 16) |
| Iteration 1 cut at the cap | 49/66 | 9/66 |
| Train-passing programs that were test-correct | 14/33 | 15/43 |

Per input:
- only D66 16, only L66 22, both 12;
- **union 50/103**; R5 ∪ D66 ∪ L66 = 51;
- McNemar p = 0.42.

## 4. Questions we most want answered

1. **Complementarity.** The union (50) is far above either run (28 / 34). How much of hard-task failure is sampling variance and how much is a model limit?
   - Estimate pass@k per task from the data.
   - What would two (or three) independent attempts per task score?
   - How should attempt_1 and attempt_2 be chosen without ground truth?
2. **Overfitting.** Only 35–42 % of train-passing programs were test-correct.
   - From the programs, thinking and train soft scores: what separates correct from overfit train-passing programs?
   - Is there a ground-truth-free signal that predicts test correctness: agreement between independent programs, program size or complexity, train fit, thinking features?
   - Should Poetiq continue after a train pass?
3. **Thinking length.**
   - Where in the thinking do correct programs appear?
   - Do long natural closes (78k–123k in L66) help?
   - What happens in cap-forced answers?
   - What thinking budget maximises correct inputs per GPU-hour?
4. **Iterations.** Iteration 2 was about as productive as iteration 1 per slot-hour. When is feedback better than a fresh, independent attempt?
5. **Failure modes,** from the full thinking of failed tasks: which categories, and which prompt or harness change would fix each? Give evidence from specific traces.
6. **Projection.** Given coverage is the limit (240 hidden tasks, 12 h; R5 reached about 172 tasks), which allocation of compute maximises LB?
   - one attempt everywhere, then second independent attempts;
   - iterations;
   - longer caps;
   - with an engine 1.5–3× faster (Experiment 11).

## 5. File map

| Path | What |
|---|---|
| `runs/D66/`, `runs/L66/` | Full Kaggle outputs: `q27x/` (iterations, curve, report, final attempts, vLLM metrics, `poetiq_thinking/`, `poetiq_programs/`), `submission.json`, bundle |
| `runs/R5/` | R5 baseline: report, iterations, final attempts, vLLM metrics |
| `data/` | Public eval challenges and solutions |
| `notebooks/` | The D66 and L66 notebooks |
| `analysis/` | Our analysis script and its report (may contain mistakes) |
| `context/` | Experiment 10 README (history, earlier findings) |
