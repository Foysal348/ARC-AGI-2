# E10 S1: pre-submission audit of a Poetiq notebook for Qwen3.8-27B, against its base R5 (2026-10-16)

**What we ask:**
- Audit `notebooks/Q27-XHIGH-v1_4_4_E10_S1_POETIQ_FIX_ORDER2.ipynb` (**S1**) before we submit it directly to Kaggle.
- S1 is the already-submitted notebook **R5** (`notebooks/BASE_R5_...ipynb`) plus 9 small changes. The full code diff is in `diffs/R5_to_S1.diff`.
- Find anything in S1 that, **in the hidden competition rerun**, could:
  - crash the solver;
  - write an invalid or incomplete `submission.json`;
  - exceed Kaggle's 12-hour limit;
  - lose answers R5 would have kept;
  - waste GPU time.
- **Verify against the files.** Mark each claim *verified from files* or *hypothesis*.
- Our own analysis can be wrong, including the evidence numbers below. Check them.
- **Scope is the 9 changes and their interactions.** This is a go/no-go review for one submission, not a redesign. Ideas for later runs are welcome, but list them separately (see the output format).

## 1. Competition and fixed constraints (the user's decisions; do not argue them)

**Competition:**
- Kaggle ARC Prize 2026 (ARC-AGI-2). One offline notebook, **12 h on 4×L4** including install and model load. Deadline 2026-11-02.
- The rerun solves public + private hidden tasks: about **240 tasks** (about 344 test inputs if they look like eval). The public LB scores its 120-task public part.
- 2 attempts per test input.
- One pending submission at a time. The score arrives about 1 day later.
- A version can be submitted only after its commit run succeeds.

**Engine:** vLLM 0.19, TP4, FP8 weights, fp8 KV (1,353,600 tokens), MTP×3, prefix caching, 16 sequences, pinned Python 3.12 Docker image.

**Hidden ≈ eval in difficulty.** An earlier note said the hidden puzzles are easier; that came from the placeholder and was wrong. **The problem is finishing in time.**

**Fixed rules:**
- Thinking stays **77,824 + 8,192 answer tokens per iteration**. Never propose fewer than 49,152 thinking tokens.
- Same model; no fine-tuning; no model change.
- A valid `submission.json` always.
- One change at a time; simple code.

## 2. Base R5: what was measured (verify in `r5_evidence/`)

| | R5 (EVAL120 commit run) |
|---|---|
| Kernel | `hosen42/q27-xhigh-e10-poetiq-r5-eval120`. Base sha256 `498109b72382d3ab…`, identical to the code that ran |
| Method | Poetiq-style program synthesis: one request per task and iteration. The model writes `transform(grid)`; a sandbox checks it on the train pairs; feedback goes to the next iteration |
| Settings | 1 expert, up to 10 iterations, T 1.0. Alphabetical FIFO; a failed task goes to the back of the queue |
| Eval result | **78/172 test inputs = 45.35 %**, task-normalised 48.61 % |
| Requests | 172 = 120 iteration-1 + 52 iteration-2. 47 still queued at the end |
| Solver | Wall 41,464 s, 11.65 M tokens, 281 tok/s |
| **LB of R5 (hidden rerun)** | **21.39** = 0.44 × eval task-normalised. Our reading: coverage binds at about 240 tasks |
| Clock (log time ≈ Kaggle clock) | Cell 0 at 7.8 s; solver start ≈ 741 s. Drain at 11:36, `solver complete` at 42,204.9 s (11:43:25, 43 s before the 11:44 hard stop). Log end 42,220.7 s; Kaggle runtime 11h43m42s, so **post-solver work takes about 16 s** |
| KV | `vllm:kv_cache_usage_perc` > 0.95 in 11 of 345 samples (120 s sampling), max 0.995, 9 preemptions. Always with 16 running |

Speed of each group in R5:

| Group | Solves / slot-hour |
|---|---|
| Iteration 1, ORDER2 score 2 | 0.465 |
| Iteration 1, ORDER2 score 1 | 0.360 |
| Iteration 1, ORDER2 score 0 | 0.251 |
| Iteration 2, all | 0.225 |

Iteration 2 overall: 52 tasks → 12 solved. Four of them had an iteration-1 score of 0. The iteration-1 score does not predict an iteration-2 solve (p = 0.32–0.40).

## 3. The 9 changes in S1

| ID | Change (cell) | Why | Evidence |
|---|---|---|---|
| **Q** | ORDER2 queue for iteration 1 (cell 7): score = [≥ 3 train pairs] + [1 test input], descending; ties keep sorted-id order. Seeds still use the sorted-id index. Failed tasks still go to the back, so every task gets iteration 1 before any iteration 2 | In a coverage-bound rerun, the tasks done first should be the ones solved fastest | Table above: 0.465 / 0.360 / 0.251 solves per slot-hour |
| **F1** | `poetiq_parse_code` (cell 5): the **last** ```python block that parses and defines `transform()`, else R5's first block | R5 ran the first block, so a short illustrative snippet written before the real solution would be executed | Latent risk; not measured |
| **F3** | Best-program selection (cell 7): a train-passing program stays eligible as best even if one test input fails. The task ranking keeps partly usable candidates; grids are chosen per test input | R5 required all test inputs usable, so one crashing input lost the whole task | R5 lost 5 units this way, including 2 train-verified tasks |
| **A2** | `poetiq_two_attempts` (cell 5): attempt_2 = the next distinct grid; else the test input; else its mirror. Never a copy of attempt_1 | — | R5 attempt_2 duplicated attempt_1 in **134/172** inputs |
| **F2** | Final verification harvest (cell 7): `endwait = min(T0 + budget − 60 s, now + 2 × sandbox timeout)` | R5 used `min(HARD_STOP, …)`, which is already past at the hard stop, so pending verifications were never committed | **Latent in R5:** R5 ended 43 s before its hard stop with 0 pending. The harness shows R5 commits 0/8 and S1 commits 8/8 when the hard stop is reached |
| **C1** | Per-output `try/except` in the step loop (cell 7). An unknown request id is logged and skipped. Any other exception aborts that request, removes it from active, and marks the unit `finished` / `unit_error` | R5 raised `RuntimeError` on an unexpected request id, which ended the whole solver | Harness: R5 crashes; S1 closes only that unit |
| **KV gate** | No new admission while ≥ 12 requests run **and** KV usage > 0.95 (cell 7). The metric is read at most every 5 s via `llm.get_metrics()`, the same API R5 already used (`disable_log_stats=False`). If the metric is unavailable, the gate stays open | Avoid preemptions and prefix-cache eviction near full KV | R5: max KV 0.995, 9 preemptions. The user set 0.95 (0.85 was too strict) |
| **Prefetch** | Background `cat *.safetensors > /dev/null` during pip install (cell 3); best effort, read-only | Shorter model load | Not measured |
| **CLOCK** | `NOTEBOOK_T0` anchored at the kernel process start via `psutil.Process().create_time()`, capped at 600 s, else 0 (cell 1). EVAL120 / RERUN_ALL budget = 12 h − 3 min, hard margin 2 min, verify margin 1 min. Drain (8 min) and admit (2 min) margins unchanged | R5 left about 16 min of the 12 h unused | Schedule below |

**Schedule from T0 (≈ kernel start):**

| | R5 | S1 |
|---|---|---|
| Last admission | 11:34 | **11:45** |
| Drain | 11:36 | **11:47** |
| Hard stop | 11:44 | **11:55** |
| Harvest limit | — | **11:56** |
| Budget end | — | **11:57** |

Expected end: if drain behaves as in R5 (7.3 min to empty), the solver ends near 11:54:20. Worst case: harvest until 11:56, plus about 16 s of post-solver work, gives about 11:56:20, leaving **about 3.5 min** before 12:00.

**Commit profile `S1COMMIT4`** (the non-rerun default):
- 4 eval tasks: `1818057f`, `2ba387bc`, `bf45cf4b`, `58490d8a`. These are the R5 iteration-1 train-verified tasks with the fewest thinking tokens: 26.1k, 29.0k, 33.7k and 38.0k, taking 22–42 min of wall time under 16-way load. The notebook comment says "closed fastest", which is loose wording.
- Budget 90 min, admit until 80 %, drain at 90 %.
- Purpose: a successful commit in about 1 h so the version can be submitted. The rerun ignores it and uses `RERUN_ALL`.

**R1** (`Q27-XHIGH-v1_4_4_E10_S1_T06_EVAL120.ipynb`) is S1 with Poetiq temperature 0.6 and the commit profile set to EVAL120. Diff: `diffs/S1_to_R1_T06_EVAL120.diff`. It is our next 12 h eval run; audit it only for differences from S1.

## 4. Local harness (no GPU): what it proves and what it does not

`build/harness_s1.py` runs the real notebook cells 0, 1, 3, 4 and 6 with:
- the real tokenizer and real eval data;
- a fake vLLM engine;
- a fake verifier keyed on markers in the fake responses.

Scenarios:
- **mixed:** F1, A2, F3, a forced close then a pass, a corrupt output (C1), and the iteration order;
- **kvgate:** fake KV 0.97 with ≥ 4 running and the floor set to 4;
- **hardstop:** hard stop 1.5 s ahead, verification takes 2.5 s;
- **rerun:** hidden-test path, `submission.json` schema.

Results:
- All four pass for S1 and R1: `harness_logs/log3_*.txt`.
- **Negative control R5:**
  - `log_R5_control.txt`: crashes on the unexpected id;
  - `log_hs_E10_86K_POETIQ_R5_EVAL120.txt`: no ORDER2, and 0 of 8 verifications committed at the hard stop.

Not covered by the harness:
- the real vLLM engine, MTP, preemption, real `get_metrics()` values;
- the real sandbox (it is unavailable on Windows; the harness substitutes a verifier);
- the pip install and prefetch on Kaggle;
- `psutil` on Kaggle;
- real wall-clock behaviour.

## 5. Questions we most want answered

1. **Rerun crash and validity paths.** Can any change raise outside its `try` in the `RERUN_ALL` path (cells 1, 3, 5, 7, 8)? If the solver errors, is the final `submission.json` still complete and valid?
2. **Clock.**
   - Is the kernel-process `create_time` the right anchor for Kaggle's 12 h?
   - Is about 3.5 min of worst-case margin safe? Consider the thinking-trace writes, the bundle zip and nbconvert for about 240 tasks instead of 120.
   - Anything after the hard stop that could take minutes?
3. **F3 semantics.**
   - A train-passing but not fully test-usable program can now become `best`, while `finished` still requires `passed and usable`, so such a task keeps iterating (as in R5). Is that consistent?
   - Can a partly usable best displace a fully usable one with an equal score?
   - Does per-input grid selection ever emit a non-grid?
4. **A2.** Is the attempt_2 fallback always schema-valid? Any case where it changes attempt_1?
5. **KV gate.**
   - Starvation or deadlock with 12 or more running?
   - Is the cost of `llm.get_metrics()` every 5 s negligible?
   - Is taking the max over all `kv_cache_usage` gauges right?
   - Behaviour when the gauge is stale.
6. **C1.** After `abort_request`, can a stale output for the same key arrive later and corrupt state? Are verifications in flight for an errored unit handled?
7. **Q (ORDER2)** with hidden tasks: any task that never enters the queue? Interaction with drain and the admission deadline?
8. **Prefetch.** RAM or page-cache pressure, or I/O contention with pip and vLLM load, on the Kaggle 4×L4 machine?
9. **The commit run.** Will `S1COMMIT4` finish well inside its own 90 min budget, including about 12 min of model load?

## 6. Output format

1. **Verdict:** SUBMIT AS IS / SUBMIT AFTER THESE FIXES (list) / DO NOT SUBMIT, with one paragraph of reasons.
2. **Findings table.** Columns:
   - ID;
   - severity: blocker / major / minor;
   - cell and line (or diff hunk);
   - what goes wrong, and when;
   - evidence;
   - verified from files / hypothesis;
   - minimal fix as a code snippet.
3. **Checks you ran** that found nothing (one line each), so we know what was covered.
4. **Optional, separate:** at most 5 ideas for later runs. Each needs its expected effect, evidence, and confirmation that it respects §1.

## 7. File map

| Path | What |
|---|---|
| `notebooks/BASE_R5_Q27-XHIGH-v1_4_4_E10_86K_POETIQ_R5_EVAL120.ipynb` | Base (submitted; LB 21.39) |
| `notebooks/Q27-XHIGH-v1_4_4_E10_S1_POETIQ_FIX_ORDER2.ipynb` | **S1, to be submitted.** sha256 `328a078fde6d…` |
| `notebooks/Q27-XHIGH-v1_4_4_E10_S1_T06_EVAL120.ipynb` | R1 (next eval run). sha256 `813bd57a8ff0…` |
| `diffs/R5_to_S1.diff`, `diffs/S1_to_R1_T06_EVAL120.diff` | Per-cell unified diffs |
| `build/build_e10_s1.py` | The builder: exact-match patches on the base |
| `build/harness_s1.py` | Local harness (fake engine) |
| `harness_logs/` | Harness results: S1, R1 and the R5 negative control |
| `r5_evidence/R5_kaggle_run.log` | Full Kaggle log of R5 (JSON stream with timestamps) |
| `r5_evidence/poetiq_run_report.json`, `poetiq_iterations.jsonl` | R5 report and per-iteration records |
| `r5_evidence/poetiq_vllm_metrics.json` | R5 vLLM metrics every 120 s (KV usage, spec decode) |
| `r5_evidence/R5_units.csv` | Per test-input outcome table for R5 (our extraction) |
| `context/` | Experiment README and our 2026-10-16 analysis. **May contain mistakes;** for example, its claim that R5 *lost* verifications at the hard stop is wrong (see F2) |
