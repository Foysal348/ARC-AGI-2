# E10 D66 deep run: pre-push audit of a 12-hour measurement notebook for Qwen3.8-27B Poetiq (2026-10-16)

**What we ask:**
- Audit `notebooks/Q27-XHIGH-v1_4_4_E10_D66_HARD_DEEP.ipynb` (**D66**) before we push it and spend one 12 h GPU run on it.
- D66 is **not a submission**. Its commit run is the measurement.
- Two questions:
  1. **Correctness:** will it run the intended 66 tasks with the intended settings, for the full 12 h, and save everything we need?
  2. **Design:** will its outputs answer the questions in §3? If not, what minimal change would make them answerable?
- **Verify against the files** and mark each claim *verified from files* or *hypothesis*. Our numbers below can be wrong, so check them.
- Keep to minimal, targeted changes. This is a go/no-go review, not a redesign.

## 1. Context and fixed decisions (the user's; do not argue them)

**Competition:** Kaggle ARC Prize 2026 (ARC-AGI-2), offline, 12 h on 4×L4.
- The hidden test is **240 tasks** (a fact). The public LB scores its 120-task public part.
- Hidden ≈ public evaluation in difficulty.
- The binding problem is finishing in 12 h (coverage).
- **Goal:** LB 60+ with this same model. No fine-tuning, no model change.

**Fixed decisions for D66:**
- **Thinking:** 77,824 + 8,192 tokens per iteration, as in R5. The floor is 49,152 everywhere.
- **Temperature: 1.0** (user decision, 2026-10-16), as in R5.
  - The T 0.6 speed gain is known from existing metrics. Same vLLM engine, R5 T 1.0 vs ORDER2 DIRECT T 0.6:

    | | R5 (T 1.0) | ORDER2 (T 0.6) |
    |---|---|---|
    | MTP acceptance | 0.549 | 0.664 |
    | Decode | 301 tok/s | 351 tok/s |

    This is confounded by the task type.
  - T 0.6 quality is not measured here, and the task selection would bias such a comparison.
- **One expert, up to 10 iterations,** 16 slots, the hidden-run clock: last admission 11:45, drain 11:47, hard stop 11:55.

**Engine:** vLLM 0.19, FP8, fp8 KV, MTP-3, prefix caching, pinned Py3.12 Docker image.

## 2. What D66 is (verify in `diffs/`)

D66 = the S1-60K notebook (submitted today), with three differences:
- **Task list `HARD66`:** the 66 eval tasks R5 did not fully solve, 103 test inputs. They are 57 zero-score tasks (15 of them train-verified in R5 but wrong on test) plus 9 partial ones.
  - Selection: `r5_evidence/poetiq_final_generated.json` compared with `data/arc-agi_evaluation_solutions.json`. An input counts as solved if attempt_1 or attempt_2 matches.
- **Fresh seeds:** `SEED` 20261016 (R5 20261005, the sampling seed base) and `E10_POETIQ_SEED` 1 (R5 0, the example-order shuffle).
- **Thinking 77,824** (S1-60K uses 60,000), as in R5.

Everything else is S1-60K, already audited today. Its earlier audit findings were resolved:
- F2b now cancels queued verifications after the harvest window. Harness control: old 8.4 s → new 4.4 s.
- F3A was not adopted: R5 had 0 train-passing, test-unusable programs.

| Diff | Contents |
|---|---|
| `diffs/S1_60K_to_D66.diff` | Cells 0 and 2 only: profile, seeds, thinking budget |
| `diffs/R5_to_D66.diff` | Everything relative to the R5 base |

## 3. The questions D66 must answer (new information; R5 cannot give it)

**R5 eval facts** (verify in `r5_evidence/`):

| Fact | Value |
|---|---|
| Tasks fully solved | 54 |
| Partial | 9 |
| Zero | 57 |
| Requests | 172 = 120 iteration-1 + 52 iteration-2 |
| Iterations per task | none got more than 2; of the zero-score tasks, 21 got 1 and 36 got 2 |
| Slot time | 184 slot-hours in total, about 1.07 slot-hours per request |

D66 should give about 170 requests, about 2.6 iterations per task.

**Questions:**
1. **Fresh attempt on failed tasks:** what share of R5-failed tasks does a fresh attempt solve? That is, P(solve | R5 failed), at iteration 1 of a new seed. Is the failure a model limit or sampling?
2. **Iterations 3+:** solves per slot-hour on hard tasks at iterations 1, 2, 3, ... R5 never saw iteration 3.
3. **Train-pass but test-wrong:** for the 15 tasks that passed train in R5 but were wrong on test, does a new attempt give a correct program, or the same wrong one?
4. **The compute → score curve** (combined with R5): the eval score as a function of attempts per task. It is used to decide:
   - how far Poetiq can go when Experiment 11 (SGLang + INT4 + DFlash2) gives 2–3× speed;
   - whether spare time goes to more Poetiq iterations or to a DIRECT attempt_2. DIRECT data on all 120 tasks already exists.
5. **Full thinking traces of hard tasks,** to study failure modes.

## 4. Specific checks we want

1. **Selection:** recompute the 66 ids and the 103 inputs from the files. Are they right?
2. **Profile path:** does `HARD66` (with `task_list` and the RERUN-style margins) flow correctly through cell 2?
   - task selection;
   - `TOTAL_BUDGET_SEC`, `HARD_STOP`, drain and admit;
   - eval scoring over the 103 inputs.

   `checks/profile_check_D66.txt` ran the real cells. Verify the logic as well.
3. **Seeds:** do `SEED` and `POETIQ_SEED` make every request differ from R5? Note that `task_index` also changes, because the task list changed. Any seed collision or determinism issue?
4. **Twelve hours:** with 66 tasks, train-verified tasks finish early and failed ones re-queue at the back (FIFO).
   - Can the run idle, end early, or starve?
   - Is there any risk to the 11:55 schedule?
5. **Outputs:** enough to answer §3? Per iteration we need task, iteration, mode/finish, tokens, seconds, score, train_passed, has_python, plus full thinking, programs, the final attempts and the vLLM metrics.
   - Is anything missing, for example per-iteration test-input correctness, or per-iteration candidate grids? R5 kept only the final attempts.
   - If a cheap logging addition would make question 3 or 4 answerable, propose it as a minimal code snippet.
6. **Analysis design:** how should the curve be computed so that it is valid?
   - Selection bias: we condition on R5 failure on purpose.
   - Few tasks: 66.
   - Combining R5 and D66 attempts.
   - Propose the exact estimator.

## 5. Output format

1. **Verdict:** PUSH AS IS / PUSH AFTER THESE FIXES (list) / DO NOT PUSH, with one paragraph.
2. **Findings table.** Columns:
   - ID;
   - severity: blocker / major / minor;
   - cell and line (or diff hunk);
   - what goes wrong, and when;
   - evidence;
   - verified / hypothesis;
   - minimal fix as a code snippet.
3. **Logging additions** (if any) needed for §3, as minimal snippets.
4. **The analysis plan:** estimators and the tables to produce after the run.
5. **Checks you ran** that found nothing, one line each.

## 6. File map

| Path | What |
|---|---|
| `notebooks/Q27-XHIGH-v1_4_4_E10_D66_HARD_DEEP.ipynb` | **D66, to audit.** sha256 `f35cfae3c486…` |
| `notebooks/Q27-XHIGH-v1_4_4_E10_S1_60K_POETIQ_FIX_ORDER2.ipynb` | S1-60K (submitted today; quick-saved as `foysalemonshanto/q27-xhigh-e10-s1-60k-poetiq` v1). sha256 `ed530071…` |
| `notebooks/BASE_R5_...ipynb` | R5 base (LB 21.39). sha256 `498109b7…` |
| `diffs/` | Per-cell unified diffs |
| `build/build_e10_s1.py` | Deterministic builder: S1, R1, A60, D66 variants from R5 |
| `build/harness_s1.py` | CPU harness: real cells, real tokenizer, fake vLLM engine, fake verifier |
| `build/check_profile_d66.py` | Runs the real config and task cells with D66's default profile |
| `checks/` | Profile check and harness logs: mixed, kvgate, hardstop, rerun, slowverify. All PASS. Also the F2b control log for the old S1 |
| `r5_evidence/` | R5 run report, per-iteration records, final attempts, per-unit table (our extraction) |
| `data/` | Public ARC-AGI-2 evaluation challenges and solutions |
