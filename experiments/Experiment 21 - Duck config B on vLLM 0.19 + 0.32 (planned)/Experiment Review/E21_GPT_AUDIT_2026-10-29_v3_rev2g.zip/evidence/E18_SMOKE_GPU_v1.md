# E18 GPU smoke v1 (2026-10-27): vLLM 0.32 + 20 streams, E18SMOKE (20 eval tasks, 45 min)

- Kernel: `foysalemonshanto/q27-xhigh-e18-s1-60k-vllm032-s20` v1, scriptVersionId 362724887.
- Notebook sha 07af34e3, 4x L4, total 42.4 min.
- Outputs: `_scratch/e18_gpu_v1/`. These include the server log `q27x/vllm_server_s1.log`, `e18_engine_stats.json`, `poetiq_vllm_metrics.json` and the full thinking of every request.

## Engine

| Item | Value |
|---|---|
| CELL 2 (S1's vLLM 0.19 install + tokenizer) | done at 161 s (runtime parity PASS) |
| vLLM 0.32 venv install | 175 s |
| Rung used | **s1**: S1's flags + `--language-model-only` |
| Launch to ready | 550 s; the engine smoke took about 1 s ("1 2 3 4 5 6 7 8") |
| Solving starts | about 14.8 min after kernel start. S1 on 0.19 was ready at 668-733 s, so this is about 3-4 min later |
| KV | **1,110,415** tokens as logged by 0.32 (= max-concurrency × max_model_len; VMS without `--language-model-only` logged 1,006,517) → concurrency = 20 |
| Kernels | FlashInfer attention, MarlinFP8ScaledMM, Triton/FLA GDN |
| Mamba cache | align |
| Preemptions | 0 |
| Waiting requests | 0 the whole time |
| Longest log silence during startup | 60 s |

## Throughput

From the server's 10-second stats, Running = 20 for the whole solve.

| Time | Context per stream (approx.) | Decode tok/s | KV usage |
|---|---|---|---|
| 06:19 | ~7k | 457-466 | 39 % |
| 06:22 | ~12-15k | 405-410 | 44-45 % |
| 06:26 | ~20k | 375-400 | 51-52 % |
| 06:30 | ~25k | 355-390 | 58 % |
| 06:34 | ~28-30k | 345-353 | 61-62 % |

- MTP mean acceptance length: 2.5-2.9 (VMS gate prompts: 2.96-3.14).
- Solver: 466,586 tokens in 1,643 s = **284 tok/s overall**, including the startup prefill and the drain stall described below.
- Steady phase: 16.6 → 34.6 min = 412,613 tokens in 18 min = **382 tok/s**.
- Shim: 38 streams; 4 finished stop, 34 aborted (18 drained phase 1 + 16 phase 2 at the hard stop); 0 errors; 0 missing token ids.

## Results

- 2 / 22 eval queries correct (2ba387bc, 1818057f). 4 programs parsed, 2 train-verified.
- This is expected for a 45-minute smoke (audit B L7). The other 18 units were drained at 36 min and then cut by the hard stop at 42 min.

## Finding: the drain re-prefills the whole phase-1 context

Prefix-cache hits during the drain were only 5-9 %.
- At 08:42 (the drain), 18 phase-2 requests entered; the server showed Running 1 / Waiting 17.
- Prompt throughput was 2.4-3.5k tok/s. All 18 were running again only at 08:54. They decoded at about 410 tok/s for about 1 min, and then the hard stop aborted them.
- Over the run: prefix-cache queries 643,503, hits 49,600 (7.7 %).

**Cause** (vLLM 0.32 `config/cache.py:189-195`): `mamba_cache_mode = "align"` caches the Mamba state only at the last token of a scheduler step when that token sits at a multiple of the block size. With MTP (2-4 tokens per step) the decode positions rarely land there. So the generated tokens of an aborted or finished phase 1 have no usable state, and phase 2 recomputes prompt + thinking.

**This is not new in E18.**
- S1's in-process vLLM 0.19 uses the same align mode and the same solver.
- The cost falls on:
  - every forced-close phase 2 (R5: 54 % of requests hit the cap; each re-prefills about 60-70k tokens);
  - the final drain: about 20 units × about 50k tokens at about 2.5k tok/s = about 6.7 min of an 8-min margin.
- Possible levers, all outside the "engine only" scope; the user decides:
  - a longer RERUN drain margin;
  - a solver that continues instead of re-prefilling;
  - a Mamba checkpoint at the abort point.
