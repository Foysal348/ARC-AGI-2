def vms_flags(model, *, tp=4, dp=1, seqs=16, spec=3, kv="fp8_e4m3", backend="FLASHINFER", prefix=True, mem=0.90,
              batched=4096, max_len=106496, extra=None, car_off=True):
    f = [str(model), "--tensor-parallel-size", str(tp), "--kv-cache-dtype", kv, "--max-model-len", str(max_len),
         "--max-num-seqs", str(seqs), "--max-num-batched-tokens", str(batched), "--gpu-memory-utilization", str(mem)]
    f += ["--disable-custom-all-reduce"] if car_off else []
    f += ["--seed", str(SEED), "--host", "127.0.0.1", "--port", str(VMS_PORT),
          "--served-model-name", "q27", "--attention-backend", backend, "--trust-remote-code"]
    if dp > 1:
        f += ["--data-parallel-size", str(dp)]
    f += ["--enable-prefix-caching"] if prefix else ["--no-enable-prefix-caching"]
    if spec:
        f += ["--speculative-config", json.dumps({"method": "mtp", "num_speculative_tokens": int(spec)})]
    for k, v in (extra or {}).items():
        f += [k] + ([] if v is None else [str(v)])
    return f