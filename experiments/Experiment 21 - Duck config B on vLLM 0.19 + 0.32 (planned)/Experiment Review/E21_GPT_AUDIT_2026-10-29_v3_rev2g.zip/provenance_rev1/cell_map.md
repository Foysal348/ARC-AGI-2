
## NB1: `Q27-XHIGH-E21_DUCKB_VLLM_NB1_INT4_S20.ipynb` (sha ad5b2d1f)

| New cell | Title | Donor (notebook sha / cell index) | Relation | Diff file |
|---|---|---|---|---|
| 1 | # ==================================================================== CELL 0 — mode + fal | R3K2 `c058d58b` cell 1 | identical (0 +/- lines) | `diffs/NB1_cell1_vs_R3K2_c1.diff` |
| 2 | # ==================================================================== CELL 1 — configurat | R3K2 `c058d58b` cell 2 | changed (43 +/- lines) | `diffs/NB1_cell2_vs_R3K2_c2.diff` |
| 3 | # ==================================================================== CELL 1b — E14: firs | R3K2 `c058d58b` cell 3 | changed (8 +/- lines) | `diffs/NB1_cell3_vs_R3K2_c3.diff` |
| 4 | # ==================================================================== CELL 2 — offline in | R3K2 `c058d58b` cell 4 | identical (0 +/- lines) | `diffs/NB1_cell4_vs_R3K2_c4.diff` |
| 5 | # ==================================================================== CELL 3 — E12: Duck  | R3K2 `c058d58b` cell 5 | changed (5 +/- lines) | `diffs/NB1_cell5_vs_R3K2_c5.diff` |
| 6 | # E10: original task-order and evaluation profiles, but one Poetiq program per task/expert | R3K2 `c058d58b` cell 6 | identical (0 +/- lines) | `diffs/NB1_cell6_vs_R3K2_c6.diff` |
| 7 | CELL 5 — E21 engine library | composed (below) | donor functions verbatim + new code | `diffs/NB1_cell7_engine_provenance.md` |
| 8 | `e21_cell6` (wrapped function) | R3K2 `c058d58b` cell 9 | body changed: 144 +/- lines (wrapper: def + `global` of every module-level name) | `diffs/NB1_e21_cell6_unwrapped_vs_R3K2_c9.diff` |
| 8 | `e21_cell7` (wrapped function) | R3K2 `c058d58b` cell 10 | body changed: 4 +/- lines (wrapper: def + `global` of every module-level name) | `diffs/NB1_e21_cell7_unwrapped_vs_R3K2_c10.diff` |
| 9 | CELL 8 — runner | new (build_e21.py RUNNER) | new | — |
| 10 | CELL 9 — E21 report | new (build_e21.py REPORT); scoring logic follows R3K2 cell 10's eval block | new | — |
| 0 | markdown | new | new | — |

Dropped R3K2 cells: 7 (SGLang engine), 8 (E14-A1 SGLang arms), 11 (E14-A2 SGLang arms), 12 (E14 JIT cache / bundle).

## NB2: `Q27-XHIGH-E21_DUCKB_VLLM_NB2_FP8_SSM16_S16.ipynb` (sha b968e322)

| New cell | Title | Donor (notebook sha / cell index) | Relation | Diff file |
|---|---|---|---|---|
| 1 | # ==================================================================== CELL 0 — mode + fal | R3K2 `c058d58b` cell 1 | identical (0 +/- lines) | `diffs/NB2_cell1_vs_R3K2_c1.diff` |
| 2 | # ==================================================================== CELL 1 — configurat | R3K2 `c058d58b` cell 2 | changed (43 +/- lines) | `diffs/NB2_cell2_vs_R3K2_c2.diff` |
| 3 | # ==================================================================== CELL 1b — E14: firs | R3K2 `c058d58b` cell 3 | changed (8 +/- lines) | `diffs/NB2_cell3_vs_R3K2_c3.diff` |
| 4 | # ==================================================================== CELL 2 — offline in | R3K2 `c058d58b` cell 4 | identical (0 +/- lines) | `diffs/NB2_cell4_vs_R3K2_c4.diff` |
| 5 | # ==================================================================== CELL 3 — E12: Duck  | R3K2 `c058d58b` cell 5 | changed (5 +/- lines) | `diffs/NB2_cell5_vs_R3K2_c5.diff` |
| 6 | # E10: original task-order and evaluation profiles, but one Poetiq program per task/expert | R3K2 `c058d58b` cell 6 | identical (0 +/- lines) | `diffs/NB2_cell6_vs_R3K2_c6.diff` |
| 7 | CELL 5 — E21 engine library | composed (below) | donor functions verbatim + new code | `diffs/NB2_cell7_engine_provenance.md` |
| 8 | `e21_cell6` (wrapped function) | R3K2 `c058d58b` cell 9 | body changed: 144 +/- lines (wrapper: def + `global` of every module-level name) | `diffs/NB2_e21_cell6_unwrapped_vs_R3K2_c9.diff` |
| 8 | `e21_cell7` (wrapped function) | R3K2 `c058d58b` cell 10 | body changed: 4 +/- lines (wrapper: def + `global` of every module-level name) | `diffs/NB2_e21_cell7_unwrapped_vs_R3K2_c10.diff` |
| 9 | CELL 8 — runner | new (build_e21.py RUNNER) | new | — |
| 10 | CELL 9 — E21 report | new (build_e21.py REPORT); scoring logic follows R3K2 cell 10's eval block | new | — |
| 0 | markdown | new | new | — |

Dropped R3K2 cells: 7 (SGLang engine), 8 (E14-A1 SGLang arms), 11 (E14-A2 SGLang arms), 12 (E14 JIT cache / bundle).
