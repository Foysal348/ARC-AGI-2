def e12v_bring_up():
    global E11_SERVER
    info = ENGINE_INFO["vllm"]
    info["stage"] = "inputs"
    if not (MODEL_PATH / "config.json").is_file():
        raise RuntimeError(f"model missing: {MODEL_PATH}")
    if not E11_HARNESS:
        assert pkg_version("vllm") == "0.19.0", pkg_version("vllm")
        os.environ.setdefault("MAX_JOBS", "4")              # bound FlashInfer JIT build parallelism (S1-60K)
        info["cuda_link"] = ensure_libcuda_linkable()       # S1-60K: makes -lcuda linkable for FlashInfer's JIT
    else:
        info["cuda_link"] = {"probe": "PASS", "harness": True}
    backend = "FLASHINFER" if info["cuda_link"].get("probe") == "PASS" else "TRITON_ATTN"   # = the S1-60K ladder's first
    env = os.environ.copy()
    env.update({"USE_TF": "0", "TRANSFORMERS_NO_TF": "1", "TRANSFORMERS_NO_TORCHVISION": "1", "VLLM_NO_USAGE_STATS": "1",
                "VLLM_MEMORY_PROFILER_ESTIMATE_CUDAGRAPHS": "1", "PYTHONUNBUFFERED": "1"})   # Duck's vllm_env + S1-60K
    launch = ([sys.executable, "-m", "vllm.entrypoints.openai.api_server"] if not E11_HARNESS
              else [sys.executable, os.environ["E12_FAKE_VLLM_SERVER"]])
    flags = [
        # Duck's start_vllm_server, verbatim
        "--model", str(MODEL_PATH), "--served-model-name", VLLM_SERVED_NAME, "--host", "127.0.0.1", "--port", str(VLLM_PORT),
        "--tensor-parallel-size", "4", "--enable-auto-tool-choice", "--tool-call-parser", "qwen3_coder",
        "--generation-config", "vllm", "--enable-prefix-caching", "--default-chat-template-kwargs",
        json.dumps({"preserve_thinking": True}), "--reasoning-parser", "qwen3", "--max-model-len", str(VLLM_MAX_MODEL_LEN),
        # the S1-60K engine (CELL 1 values); keithtyser's Duck launch adds --kv-cache-dtype fp8 the same way
        "--kv-cache-dtype", KV_CACHE_DTYPE, "--speculative-config", json.dumps(SPECULATIVE_CONFIG),
        "--attention-backend", backend, "--max-num-batched-tokens", str(MAX_NUM_BATCHED_TOKENS),
        "--max-num-seqs", str(MAX_NUM_SEQS), "--gpu-memory-utilization", str(GPU_MEMORY_UTILIZATION),
        "--language-model-only", "--disable-custom-all-reduce", "--seed", str(SEED),
        # cached_tokens in usage (prefix-cache measurement; SGLang: --enable-cache-report)
        "--enable-prompt-tokens-details"]
    info.update(stage="launch", flags=flags, attention_backend=backend)
    srv = _E12VllmServer(launch + flags, env)
    srv.start()
    E11_SERVER = srv
    print("E12-V: starting vLLM OpenAI server:", " ".join(flags), flush=True)
    deadline = time.perf_counter() + min(VLLM_LAUNCH_TIMEOUT_SEC, max(60, ADMIT_DEADLINE - time.perf_counter()))
    while True:                                          # = Duck's wait_for_vllm_server (/v1/models)
        if not srv.alive():
            raise RuntimeError(f"vLLM server exited rc={srv.proc.returncode}: " + srv.log_text()[-3000:])
        try:
            models = _e12v_request_json(SGL_URL + "/v1/models", timeout=5)
            info["models"] = [m.get("id") for m in models.get("data", [])]
            break
        except Exception:
            if time.perf_counter() > deadline:
                raise RuntimeError("vLLM server not ready before the deadline: " + srv.log_text()[-3000:])
            time.sleep(2 if E11_HARNESS else 5)
    info["ready_sec"] = round(time.perf_counter() - srv.t0, 1)
    log = srv.log_text()
    kv = re.findall(r"GPU KV cache size: ([\d,]+) tokens", log)
    mc = re.findall(r"Maximum concurrency for ([\d,]+) tokens per request: ([\d.]+)x", log)
    info["kv_tokens_logged"] = int(kv[-1].replace(",", "")) if kv else None
    info["max_concurrency_logged"] = {"tokens": int(mc[-1][0].replace(",", "")), "x": float(mc[-1][1])} if mc else None
    info["stage"] = "smoke"
    # = Duck's run_vllm_api_smoke_test + valid usage counters. E12-V rev 2 (GPT audits, validated): vLLM 0.19 sets
    # usage.prompt_tokens_details only when num_cached_tokens is truthy (chat_completion/serving.py:1601-1603; issue
    # https://github.com/vllm-project/vllm/issues/44377), so this first, cold request has none: record it, never fail on it.
    r = _e12v_request_json(SGL_URL + "/v1/chat/completions", payload={
        "model": VLLM_SERVED_NAME, "messages": [{"role": "user", "content": "Answer in one short sentence: what is 2 + 2?"}],
        "temperature": 0.0, "max_tokens": 96, "chat_template_kwargs": {"enable_thinking": False}}, timeout=300)
    gen = (r["choices"][0]["message"].get("content") or "").strip()
    usage = r.get("usage") or {}
    _det = usage.get("prompt_tokens_details")
    info["smoke"] = {"generated": gen[:200], "usage": usage, "cache_details_present": isinstance(_det, dict),
                     "ok": bool(gen) and isinstance(usage.get("prompt_tokens"), int) and usage["prompt_tokens"] > 0
                     and isinstance(usage.get("completion_tokens"), int) and usage["completion_tokens"] > 0}
    print("E12-V smoke:", json.dumps(info["smoke"]), flush=True)
    if not info["smoke"]["ok"]:
        raise RuntimeError("vLLM smoke failed: " + json.dumps(info["smoke"])[:600])
    return info