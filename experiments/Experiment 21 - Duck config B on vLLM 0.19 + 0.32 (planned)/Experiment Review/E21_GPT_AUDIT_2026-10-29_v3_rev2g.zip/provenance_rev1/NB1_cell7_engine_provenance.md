| Function / name | Donor | In E21 cell 7 | Identical to donor |
|---|---|---|---|
| `ensure_libcuda_linkable` | E12V `e85b69c2` cell 6 | yes | yes (byte-identical text) |
| `_e12v_request_json` | E12V `e85b69c2` cell 6 | yes | yes (byte-identical text) |
| `_E12V_PROM_RE` | E12V `e85b69c2` cell 6 | yes | yes (byte-identical text) |
| `_E12V_ALIAS` | E12V `e85b69c2` cell 6 | yes | yes (byte-identical text) |
| `metrics_snapshot` | E12V `e85b69c2` cell 6 | yes | yes (byte-identical text) |
| `_E12V_STAT_RE` | E12V `e85b69c2` cell 6 | yes | yes (byte-identical text) |
| `e11_decode_summary` | E12V `e85b69c2` cell 6 | yes | yes (byte-identical text) |
| `e11_kill_server` | E12V `e85b69c2` cell 6 | yes | yes (byte-identical text) — then REDEFINED by E21 new code (kill(fast=...), harness finding) |
| `e18_install` | E18 `116d2d41` cell 6 | yes | yes (byte-identical text) |
| `E18Server` | E18 `116d2d41` cell 6 | yes | yes (byte-identical text) |
| `_e18_kill_gpu_pids` | E18 `116d2d41` cell 6 | yes | yes (byte-identical text) |
| `_wait_gpu_release` | E18 `116d2d41` cell 6 | yes | yes (byte-identical text) |

New E21 code (no donor; `build/e21_engine_new.py`): `e21_duck_serving_flags`, `e21_model_path`, `e21_flags_v019`, `e21_flags_v032`, `e21_prom`, `e21_capacity`, `e21_launch`, `e21_relaunch`, `e21_cfgs`, `e21_begin_half`, `e21_end_half`, plus the redefined `e11_kill_server` and the module-level staging join / CUDA link / E21_FLAGS block.

Semantic donors of the new code: `e21_flags_v019` = the E12-V cell 6 `e12v_bring_up` flag list (Duck's start_vllm_server flags + S1-60K engine flags) with `--max-num-seqs` per half, the model path per weights and the optional `--mamba-ssm-cache-dtype`; `e21_flags_v032` = VMS cell 6 `vms_flags()` (arms fp8_mtp3_ssm_fp16 / int4_mtp3_s20 in VMS cell 7) + Duck serving flags + context 135,168; the smoke = E12-V `e12v_bring_up` smoke; the staging join = R3K2 cell 3 `e14_after_install` staging part; the watchdog relaunch = R3K2 cell 9 `_e15b_watchdog` structure.
