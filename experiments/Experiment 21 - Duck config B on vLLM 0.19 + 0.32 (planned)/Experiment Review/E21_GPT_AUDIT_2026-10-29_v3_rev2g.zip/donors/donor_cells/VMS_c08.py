# ==================================================================== CELL V3 — report, bundle
try:
    E14_STATE.enter("REPORT")
    _ref = VMS["arms"].get("ref_fp8_mtp3_s16") or {}
    _rs, _rl = _ref.get("short_tok_s") or 0, _ref.get("long_tok_s") or 0
    f = lambda v, d=0: "—" if v is None else (f"{v:.{d}f}" if isinstance(v, (int, float)) else str(v))
    xr = lambda v, r: "—" if not v or not r else f"{v / r:.2f}"
    L = ["# VMS: vLLM 0.32.0 engine-config matrix", "", f"profile {PROFILE}, rerun {RERUN}, install {VMS.get('install')}",
         f"prompts {VMS.get('prompts')}",
         # rev 2 (GPT pre-GPU audit): the oracle, the production reference vs it, the INT4 MTP static check, dropped arms
         f"gate reference: {VMS.get('gate_reference')} | oracle_ready (certification possible): {bool(VMS.get('oracle_ready'))}",
         "tok/s = steady decode after the prefill settled; e2e = output tokens from submission to the window end / wall (a "
         "submission-to-window-end rate, not completed-request task throughput); "
         "BOUNDARY = PASS with only near-tie divergences (adoptable under the documented tolerance, not exact: confirm "
         "on ARC tasks before production); certified_exact = adoptable and PASS_EXACT",
         f"reference (MTP 3 + prefix caching) vs the oracle: {(VMS.get('ref_vs_oracle') or {}).get('verdict')} "
         f"{json.dumps((VMS.get('ref_vs_oracle') or {}).get('detail'))[:400]}",
         f"INT4 MTP static check: {json.dumps(VMS.get('int4_mtp_static'))[:500]}",
         f"dropped arms: {json.dumps(VMS.get('dropped') or {})}",
         "note: the 40k band shares a ~36k system block; prefix-cache arms reuse it, the oracle and fp8_mtp3_noprefix "
         "prefill it again per request: tok/s is measured after the prefill settled (decode only), the recompute shows "
         "in the e2e column", "",
         "| arm | ok | gate | streams (8k / 40k) | 8k tok/s | x ref | 40k tok/s | x ref | accept 8k / 40k | KV tokens | KV max | preemptions | degenerate 8k / 40k | log errors | XL tok/s (streams) | x ref | accept XL | PCIe-IPC initialized | gate class / XL gate | canary leaks | e2e tok/s 8k / 40k | prefix hits / queries 40k | measurement / capacity / correctness | adoptable |",
         "|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
    _rx = _ref.get("xl_tok_s") or 0
    for k in VMS.get("order") or []:
        a = VMS["arms"][k]
        L.append(f"| {k} | {a.get('ok')} | {a.get('gate')} | {f(a.get('level_short'))} / {f(a.get('level_long'))} | "
                 f"{f(a.get('short_tok_s'))} | {xr(a.get('short_tok_s'), _rs)} | {f(a.get('long_tok_s'))} | {xr(a.get('long_tok_s'), _rl)} | "
                 f"{f(a.get('accept_short'), 2)} / {f(a.get('accept_long'), 2)} | {f(a.get('kv_tokens'))} | "
                 f"{f(((a.get('short') or {}).get('kv_max')), 2)} / {f(((a.get('long') or {}).get('kv_max')), 2)} | "
                 f"{f((a.get('short') or {}).get('preemptions'))} / {f((a.get('long') or {}).get('preemptions'))} | "
                 f"{f((a.get('short') or {}).get('degenerate'))} / {f((a.get('long') or {}).get('degenerate'))} | "
                 f"{a.get('log_errors') or a.get('skipped') or a.get('error') or (a.get('short') or {}).get('error') or (a.get('long') or {}).get('error') or ''} | "
                 f"{f(a.get('xl_tok_s'))} ({f(a.get('level_xl'))}){' ' + str((a.get('xl') or {}).get('error')) if (a.get('xl') or {}).get('error') else ''} | "
                 f"{xr(a.get('xl_tok_s'), _rx)} | {f(a.get('accept_xl'), 2)} | {(a.get('pcie_ipc') or {}).get('initialized', '')} | "
                 f"{a.get('gate_class') or ''} / {a.get('xl_gate') or ''} | {(a.get('canary') or {}).get('foreign_leaks', '')} | "
                 f"{f(a.get('short_e2e_tok_s'))} / {f(a.get('long_e2e_tok_s'))} | "
                 f"{f((a.get('long') or {}).get('prefix_cache_hits'))} / {f((a.get('long') or {}).get('prefix_cache_queries'))} | "
                 f"{a.get('measurement_ok')} / {a.get('capacity_ok')} / {a.get('correctness_ok')} | {a.get('adoptable')}{' certified_exact' if a.get('certified_exact') else ''} |")
    L += ["", "selected kernels per arm (from the server log):"] + [
        f"- {k}: {(VMS['arms'][k].get('kernels') or [])[:6]}" for k in VMS.get("order") or []]
    (VMS_DIR / "vms_report.md").write_text("\n".join(L) + "\n", encoding="utf-8")
    print("\n".join(L), flush=True)
    E14_STATE.end("done")
    e14_save()
    _pack = WORKING / "Q27X_VMS_BUNDLE.zip"
    with zipfile.ZipFile(_pack, "w", zipfile.ZIP_DEFLATED) as z:
        for fp in sorted(VMS_DIR.rglob("*")):
            if fp.is_file() and fp.stat().st_size < 300e6:
                z.write(fp, arcname="vms/" + fp.relative_to(VMS_DIR).as_posix())
        for fp in sorted(E14_OUT.rglob("*")):
            if fp.is_file() and fp.stat().st_size < 300e6:
                z.write(fp, arcname="e14/" + fp.relative_to(E14_OUT).as_posix())
        for fp in (WORKING / "e14_state.json", WORKING / "e14_heartbeat.log"):
            if fp.exists():
                z.write(fp, arcname=fp.name)
    print("VMS bundle:", _pack, round(_pack.stat().st_size / 1e6, 1), "MB", flush=True)
except BaseException:
    print("VMS report error:", traceback.format_exc()[-2000:], flush=True)
try:
    if VMS_SERVER is not None:
        VMS_SERVER.kill()
except Exception:
    pass
