# E12 · Duck REPL agent for ARC-AGI-2 on vLLM 0.19 FP8 + MTP-3 (the S1-60K engine) as an OpenAI server (SMOKE1)

**What runs:** Tufa Labs' Duck harness (Daniel Franzen's milestone-2 fork, vendored byte-identical, Apache-2.0) with a thin ARC-2 adapter: the task is in the system prompt; the model works in a Python REPL with `train`, `test_inputs`, `check(transform)` and `submit(transform)`; the host re-runs each submitted function in a clean sandbox and accepts it only when every train pair is exact. Duck settings = the milestone notebook (12,288 output per request, yield at 2,048 tokens, preserved thinking, 128 Ki context with drain to 58 Ki, T 0.7 / top-p 0.95 / top-k 20). 2 independent branches per task; selection: host-verified > agreement > distinct second grid > best partial > test input.

**Engine:** Duck's own Kaggle vLLM launcher (vLLM 0.19.0 OpenAI server: qwen3_coder tool parser, qwen3 reasoning parser, preserve_thinking default, prefix caching) with the S1-60K engine settings (TP4, fp8_e4m3 KV, MTP-3, FlashInfer, 4096 batched tokens, 16 seqs, 0.90 memory, libcuda shim), max-model-len 135,168, 12 active streams; history key `reasoning` (Duck's default; vLLM 0.19 reads only that).

**Modes:** commit = SMOKE1 (1 task, 2 branches, 15 min; step 3.5) with score; competition rerun = every hidden task, 12 h clock. Inputs = the E11-06 notebook's.
