# ==================================================================== CELL 7b — E14: report, JIT cache, bundle
try:
    E14_STATE.enter("REPORT")
    if E14_DO_MEASURE:
        E14_RESULTS["duck_run"] = {"e12_run": E12_RUN, "usage_all": (report or {}).get("usage_all") if "report" in globals() else None,
                                   "eval": {k: (report or {}).get(k) for k in ("eval_query_hits", "eval_query_total",
                                                                                "eval_task_norm_pct")} if "report" in globals() else None,
                                   "raw_reasoning": [r.get("raw_reasoning") for v in E12_RECORDS.values() for r in v]}
    # JIT / compile caches for the next runs (Notes/07, 11): nv/ and cuda/ never shipped; a 13-field manifest
    if E14_DO_MEASURE and E14_VENV.get("vpy") and not E11_HARNESS and HARD_STOP - time.perf_counter() > 600:
        try:
            _q = subprocess.run([E14_VENV["vpy"], "-c", "import importlib.metadata as m, json, torch; print(json.dumps({k: m.version(k) "
                                 "for k in ('sglang', 'sgl-kernel', 'flashinfer-python', 'torch', 'triton')} | "
                                 "{'cuda_runtime': torch.version.cuda, 'gpu': torch.cuda.get_device_name(0), "
                                 "'sm': '.'.join(map(str, torch.cuda.get_device_capability(0)))}))"],
                                capture_output=True, text=True, timeout=180, env=E14_VENV["env"])
            _v = json.loads(_q.stdout.strip().splitlines()[-1])
            _nv = subprocess.run([str(Path(E14_VENV["env"]["CUDA_HOME"]) / "bin" / "nvcc"), "--version"], capture_output=True,
                                 text=True, timeout=60).stdout.strip().splitlines()[-1:]
            _drv = subprocess.run(["nvidia-smi", "--query-gpu=driver_version", "--format=csv,noheader"], capture_output=True,
                                  text=True, timeout=60).stdout.strip().splitlines()[:1]
            _site = Path(subprocess.run([E14_VENV["vpy"], "-c", "import sysconfig; print(sysconfig.get_paths()['purelib'])"],
                                        capture_output=True, text=True, timeout=60).stdout.strip())
            _man = E14L.jit_manifest(sglang=_v["sglang"], sgl_kernel=_v["sgl-kernel"], flashinfer=_v["flashinfer-python"],
                                     torch=_v["torch"], triton=_v["triton"], cuda_runtime=_v["cuda_runtime"],
                                     nvcc=" ".join(_nv) or "unknown", driver=" ".join(_drv) or "unknown", gpu_name=_v["gpu"],
                                     sm=_v["sm"], wheels=E14L.wheel_inventory(SGL_WHEELHOUSE),
                                     jit_sources=E14L.source_fingerprint([_site / "sglang" / "jit_kernel", _site / "sgl_kernel",
                                                                          _site / "flashinfer"]),
                                     env=E14L.kernel_env(E14_VENV["env"]))
            _tar = E14L.save_jit_cache("/tmp/e11-cache", WORKING / "e14_jit_cache.tar", _man)
            E14_RESULTS["jit_cache"] = {"tar": str(_tar), "bytes": _tar.stat().st_size, "manifest": _man}
        except Exception as _e:
            E14_RESULTS["jit_cache"] = {"error": repr(_e)[:300]}
    E14_STATE.end("done")
    e14_save()
    _lines = ["# E14-A results", "", f"profile {PROFILE}, rerun {RERUN}", "", "## Decisions", ""]
    for _k, _v in (E14_RESULTS.get("decisions") or {}).items():
        _lines.append(f"- {_k}: adopt={_v.get('adopt', _v.get('ok'))} | reason: {_v.get('reason', _v.get('verdict'))} | "
                      f"{json.dumps(_v, default=str)[:400]}")
    _lines += ["", "## Duck run", "", f"- A1 reserve: {E14_RESULTS.get('a1_reserve')}",
               f"- clean start: {E14_RESULTS.get('duck_clean_start')}", f"- window: {E14_RESULTS.get('duck_window')}",
               f"- arm: {E14_RESULTS.get('duck_arm')}", "", "## Phases", ""]
    for _k, _v in (E14_RESULTS.get("phases") or {}).items():
        _lines.append(f"- {_k}: {json.dumps(_v, default=str)[:600]}")
    (E14_OUT / "e14_report.md").write_text("\n".join(_lines), encoding="utf-8")
    _pack = WORKING / "Q27X_E14A_BUNDLE.zip"
    with zipfile.ZipFile(_pack, "w", zipfile.ZIP_DEFLATED) as z:
        for fp in sorted(E14_OUT.rglob("*")):
            if fp.is_file() and fp.stat().st_size < 300e6:
                z.write(fp, arcname="e14/" + fp.relative_to(E14_OUT).as_posix())
        for fp in sorted(OUT.glob("sglang_server_*.log")):
            z.write(fp, arcname="logs/" + fp.name)
        for fp in (WORKING / "e14_state.json", WORKING / "e14_heartbeat.log", OUT / "e12_run_report.json"):
            if fp.exists():
                z.write(fp, arcname=fp.name)
    print("E14 report:", E14_OUT / "e14_report.md", "| bundle", _pack, round(_pack.stat().st_size / 1e6, 1), "MB", flush=True)
    print("E14 decisions:", json.dumps(E14_RESULTS.get("decisions"), default=str)[:2000], flush=True)
except BaseException:
    print("E14 report error:", traceback.format_exc()[-2000:], flush=True)
try:
    e11_kill_server(wait=False)
except Exception:
    pass
