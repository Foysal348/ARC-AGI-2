# ==================================================================== CELL V2 — the vLLM arms
VMS_INT4 = SGL_MODEL_PATH          # RedHat INT4 (compressed-tensors) Kaggle Model; MODEL_PATH = the FP8 repack
VMS_RESERVE = 0.0


def vms_launch(name, flags, env_extra=None, force=False):
    global VMS_SERVER
    rec = {"arm": name, "flags": list(flags), "env": env_extra or {}}
    if HARD_STOP - time.perf_counter() - (0 if force else VMS_RESERVE) - 8 * 60 < 12 * 60:
        rec["skipped"] = "NOT_TESTED_BUDGET: reserved 2 x TP2 slot / hard stop"
        VMS["launches"].append(rec)
        return False, rec
    if VMS_SERVER is not None:
        VMS_SERVER.kill()
        VMS_SERVER = None
    if not VMS_FAKE:
        rec["gpu_free"] = _e11_gpu_free()
    left = HARD_STOP - time.perf_counter() - (0 if force else VMS_RESERVE) - 8 * 60     # rev 2b: after the kill + GPU wait
    if left < 10 * 60:
        rec["skipped"] = "NOT_TESTED_BUDGET: reserved 2 x TP2 slot / hard stop (after the GPU wait)"
        VMS["launches"].append(rec)
        return False, rec
    env = dict(VMS_INST["env"])
    env.update(env_extra or {})
    srv = VServer(name, flags, env)
    srv.start()
    try:          # rev 2g: a crash while this server starts never leaves it holding the GPUs
        ok, why = srv.wait_ready(min(30 * 60, left))
    except BaseException:
        try:
            srv.kill()
        except Exception:
            pass
        raise
    rec.update(ok=ok, why=why, sec=round(time.perf_counter() - srv.t0, 1))
    txt = srv.log_text()
    m = re.findall(r"GPU KV cache size: ([\d,]+) tokens", txt)
    rec["kv_tokens_all"] = [int(x.replace(",", "")) for x in m]          # rev 2b: DP = one line per engine
    rec["kv_tokens"] = min(rec["kv_tokens_all"]) if m else None
    if ok and not m:      # rev 2g-b: a /health 200 without this server's own KV line = another listener on the port
        ok, why = False, "ready, but no 'GPU KV cache size' line in this server's log (another process on the port?)"
    m = re.findall(r"Maximum concurrency for [\d,]+ tokens per request: ([\d.]+)x", txt)
    rec["max_concurrency_at_max_len"] = float(m[-1]) if m else None
    rec["kernels"] = vms_kernels(txt)
    if ok:
        VMS_SERVER = srv
    else:
        rec["log_tail"] = txt[-4000:]
        srv.kill()
    VMS["launches"].append(rec)
    e14_save()
    print(f"VMS launch {name}: {why} | KV {rec.get('kv_tokens')}", flush=True)
    return ok, rec


VMS_REF = {}


def vms_int4_mtp_static(model):
    """rev 2 (GPT audit V3, vLLM #58807: a W4A16 checkpoint with dense BF16 MTP crashed at load because MTP was not in
    quantization_config.ignore, so the predictor was built quantized). vLLM 0.32.0 builds the predictor under prefix
    'mtp' (qwen3_5_mtp.py:233-235) with the target's quant config (:93-105), so every dense mtp.* weight must be
    exempted by the ignore list. CPU only: config.json + the safetensors index, no weights read."""
    out = {"model": str(model)}
    try:
        cfg = json.loads((Path(model) / "config.json").read_text(encoding="utf-8"))
        q = cfg.get("quantization_config") or (cfg.get("text_config") or {}).get("quantization_config") or {}
        ign = [str(x) for x in (q.get("ignore") or [])]

        def ignored(name):
            # rev 2b: vLLM 0.32.0 matches the fused name by exact name or re.match (config_utils.py:344-362, 392-412)
            return any(re.match(x[3:], name) if x.startswith("re:") else name == x for x in ign)
        wm = json.loads((Path(model) / "model.safetensors.index.json").read_text(encoding="utf-8"))["weight_map"]
        mtp = [k for k in wm if k.startswith("mtp.")]
        packed = [k for k in mtp if any(s in k for s in ("weight_packed", "weight_scale", "weight_zero_point"))]
        mods = sorted({k.rsplit(".", 1)[0] for k in mtp if k.endswith(".weight") and ("proj" in k or k.startswith("mtp.fc"))})
        _fuse = {"q_proj": "qkv_proj", "k_proj": "qkv_proj", "v_proj": "qkv_proj", "gate_proj": "gate_up_proj", "up_proj": "gate_up_proj"}
        mods = sorted(set(mods) | {m.rsplit(".", 1)[0] + "." + _fuse[m.rsplit(".", 1)[1]] for m in mods if m.rsplit(".", 1)[1] in _fuse})
        not_ign = [m for m in mods if not ignored(m)]
        out.update(format=q.get("format"), method=q.get("quant_method"), mtp_keys=len(mtp), packed=len(packed),
                   dense_linear_modules=len(mods), not_ignored=not_ign[:10],
                   mtp_ignore_entries=[x for x in ign if "mtp" in x])
        # rev 2g (GPT R4): a packed MTP module that the ignore list exempts would be built dense (wrong shapes)
        packed_mods = sorted({k.rsplit(".", 1)[0] for k in packed})
        packed_ign = [m for m in packed_mods if ignored(m)]
        out.update(packed_modules=len(packed_mods), packed_but_ignored=packed_ign[:10])
        out["ok"] = bool(mtp) and not not_ign and not packed_ign        # rev 2b: un-ignored dense linears = #58807
        out["why"] = "MTP dense and exempted by the ignore list" if out["ok"] and not packed else (
            "MTP stored quantized" if out["ok"] else "dense MTP linears missing from the ignore list (#58807 crash)")
    except Exception as e:
        out.update(ok=False, why=f"static check failed: {type(e).__name__}: {e}"[:300])
    VMS["int4_mtp_static"] = out
    e14_save()
    print("VMS INT4 MTP static check:", json.dumps(out)[:600], flush=True)
    return out["ok"]


VMS_ROWS = {}          # rev 2: each A/A arm's own greedy rows (the production reference and the oracle)


def _texts(rows):
    return [r.get("text") or "" for r in rows]


def vms_save_rows(tag, rows):
    """rev 2b (agent 3 F10): every greedy row kept, so any verdict can be re-judged after the run."""
    try:
        with open(VMS_DIR / "vms_greedy_rows.jsonl", "a", encoding="utf-8") as fh:
            fh.write(json.dumps({"tag": tag, "rows": rows}) + "\n")
    except Exception:
        pass


def vms_aa(name, deadline=None):
    rows = {"serial_a": vms_greedy(_S[:6], deadline=deadline), "serial_b": vms_greedy(_S[:6], deadline=deadline),
            "conc_a": vms_greedy(_S, concurrent=True, deadline=deadline), "conc_b": vms_greedy(_S, concurrent=True, deadline=deadline)}
    if _X:      # rev 2e (GPT audits MEDIUM-7 / E11): a greedy parity reference at ~85k context too
        rows["xl_a"] = vms_greedy(_X[:4], concurrent=True, deadline=deadline)
        rows["xl_b"] = vms_greedy(_X[:4], concurrent=True, deadline=deadline)
    vms_save_rows(name + "_aa", rows)
    s, c = vms_diverge(rows["serial_a"], rows["serial_b"]), vms_diverge(rows["conc_a"], rows["conc_b"])
    complete = all(x["expected"] and x["compared"] == x["expected"] and not x["missing_margins"] for x in (s, c)) \
        and s["expected"] >= min(6, len(_S)) and c["expected"] >= len(_S)       # rev 2g (GPT R5): the planned rows
    return rows, {"serial": s, "conc": c, "complete": complete,
                  "xl": vms_diverge(rows["xl_a"], rows["xl_b"]) if _X else None,
                  "degenerate": vms_degenerate(_texts(rows["serial_a"] + rows["serial_b"] + rows["conc_a"] + rows["conc_b"]))}


def vms_judge(s, c, base, gate=True):
    """The EMS parity rule on integer-token rows against `base` (the oracle once it exists): large-margin flips may not
    exceed base's own A/A flips (serial and all at once); no more degenerate outputs than base's A/A; rev 2e: no more
    degenerated continuations after a divergence than base's A/A; INCOMPLETE when any compared row errored, was
    incomplete or a divergence has no margins (fail closed). gate_class: PASS_EXACT = every sequence identical,
    BOUNDARY = a PASS with only near-tie divergences (adoptable under the documented tolerance, not exact: confirm on ARC
    tasks; certified_exact = adoptable and PASS_EXACT)."""
    cs, aa_s = vms_diverge(base["serial_a"], s), vms_diverge(base["serial_a"], base["serial_b"])
    cc, aa_c = vms_diverge(base["conc_a"], c), vms_diverge(base["conc_a"], base["conc_b"])
    dg, dg_aa = vms_degenerate(_texts(list(s) + list(c))), vms_degenerate(_texts(base["serial_a"] + base["conc_a"]))
    d = {"serial": cs, "conc": cc, "aa_serial": aa_s, "aa_conc": aa_c, "degenerate": dg, "aa_degenerate": dg_aa}
    if not gate:
        return "diagnostic", d
    if any(x["errors"] or x["missing_margins"] or not x["compared"] for x in (cs, aa_s, cc, aa_c)) \
            or cs["expected"] < min(6, len(_S)) or cc["expected"] < len(_S):       # rev 2g (GPT R5): the planned rows
        d["gate_class"] = "INCOMPLETE"
        return "INCOMPLETE", d
    passed = cs["large_margin_flips"] <= aa_s["large_margin_flips"] and cc["large_margin_flips"] <= aa_c["large_margin_flips"] \
        and dg <= dg_aa and cs["tail_bad"] + cc["tail_bad"] <= aa_s["tail_bad"] + aa_c["tail_bad"]
    d["gate_class"] = ("PASS_EXACT" if cs["identical"] == cs["compared"] and cc["identical"] == cc["compared"] else "BOUNDARY") \
        if passed else "FAIL"
    return ("PASS" if passed else "FAIL"), d


def vms_judge_xl(x, base):
    """rev 2e: the ~85k greedy rows against the oracle's own XL A/A (flips and tails decide, as above)."""
    if not base.get("xl_a") or not x:
        return None
    cx, aa = vms_diverge(base["xl_a"], x), vms_diverge(base["xl_a"], base["xl_b"])
    if any(r["errors"] or r["missing_margins"] or not r["compared"] for r in (cx, aa)):
        return {"verdict": "INCOMPLETE", "cmp": cx, "aa": aa}
    ok = cx["large_margin_flips"] <= aa["large_margin_flips"] and cx["tail_bad"] <= aa["tail_bad"]
    return {"verdict": "PASS" if ok else "FAIL", "cmp": cx, "aa": aa}


VMS_CANARY = {}


def vms_canary(level, deadline=None):
    """rev 2e (GPT audit MEDIUM-9, SGLang #36548 cross-request bleed): `level` concurrent greedy requests, each asked to
    repeat its own random sentinel (thinking off); a sentinel found in ANOTHER request's output is a leak."""
    import random as _rnd
    rng = _rnd.Random(SEED + level)
    sent = ["Z%04d-%s" % (i, "".join(rng.choice("QWXJVK") for _ in range(6))) for i in range(level)]
    ids = [tokenizer.encode(tokenizer.apply_chat_template([{"role": "user", "content":
           f"Repeat this code exactly once and nothing else: {s_}"}], tokenize=False, add_generation_prompt=True,
           enable_thinking=False), add_special_tokens=False) for s_ in sent]
    rows = vms_greedy(ids, n_tok=32, concurrent=True, deadline=deadline)
    own = sum(1 for s_, r in zip(sent, rows) if s_ in (r.get("text") or ""))
    leaks = sum(1 for i, r in enumerate(rows) for j, s_ in enumerate(sent) if j != i and s_ in (r.get("text") or ""))
    c_ = {"level": level, "own_hits": own, "foreign_leaks": leaks,
          "errors": sum(1 for r in rows if r.get("error")) + max(0, level - len(rows))}
    # rev 2g (GPT R2F-07): 0 own hits = the detector showed nothing: INCONCLUSIVE, not proof of isolation
    c_["informative"] = own > 0 and c_["errors"] == 0
    c_["classification"] = ("FAIL" if leaks else "INCOMPLETE" if c_["errors"] else
                            "INCONCLUSIVE" if not c_["informative"] else "PASS_NO_OBSERVED_LEAK")
    return c_


def vms_classify(a):
    """rev 2e (GPT audits E8 / HIGH-3): speed, correctness, capacity and adoption kept apart. Re-run for every arm at the
    end (the production reference is judged only once the oracle exists)."""
    level = a.get("level_wanted") or 16
    a["measurement_ok"] = all(vms_window_healthy(a.get(b), level) for b in ("short", "long"))
    a["capacity_ok"] = all(((a.get(b) or {}).get("measured_level") or 0) >= level and not (a.get(b) or {}).get("capacity_limited")
                           for b in ("short", "long"))
    # rev 2g (GPT R1 / R2F-01): missing evidence never counts as a pass: XL PASS whenever XL prompts exist; the canary
    # present, at this level, 0 errors / 0 leaks; DP rows diagnostic; a PCIe-IPC arm must show the init line
    _c = a.get("canary")
    _canary_ok = isinstance(_c, dict) and _c.get("level") == level and _c.get("errors") == 0 and _c.get("foreign_leaks") == 0
    _xl_ok = a.get("xl_gate") == "PASS" if _X else a.get("xl_gate") in (None, "PASS")
    a["backend_unverified"] = bool((a.get("env") or {}).get("VLLM_ALLREDUCE_USE_FLASHINFER_PCIE_IPC")
                                   and not (a.get("pcie_ipc") or {}).get("initialized"))
    a["correctness_ok"] = a.get("gate") == "PASS" and _xl_ok and _canary_ok
    a["adoptable"] = bool(VMS.get("oracle_ready") and a["measurement_ok"] and a["capacity_ok"] and a["correctness_ok"]
                          and not a.get("diagnostic_only") and not a["backend_unverified"]
                          and a.get("server_alive_after") and not a.get("log_errors") and not a.get("error"))
    a["candidate_for_arc_validation"] = a["adoptable"]
    a["production_approved"] = False         # rev 2g: needs the 60k+ generation and ARC task gates (not in this matrix)
    a["certified_exact"] = a["adoptable"] and a.get("gate_class") == "PASS_EXACT"     # rev 2e-d
    a["ok"] = a["measurement_ok"]        # "speed data from clean windows exists"; adoption is a["adoptable"]
    return a


def vms_arm(name, flags, **kw):
    """rev 2f: one arm's own crash never ends the remaining arms (recorded, the server killed, the results saved)."""
    try:
        return _vms_arm(name, flags, **kw)
    except Exception as _e:
        a = dict(VMS["arms"].get(name) or {}, ok=False, adoptable=False, certified_exact=False,
                 error=f"arm crashed: {type(_e).__name__}: {_e}"[:500])
        VMS["arms"][name] = a
        if name not in VMS["order"]:
            VMS["order"].append(name)
        print(f"VMS arm {name} crashed:", traceback.format_exc()[-1500:], flush=True)
        try:
            if VMS_SERVER is not None:
                VMS_SERVER.kill()
        except Exception:
            pass
        e14_save()
        return a


def _vms_arm(name, flags, *, level=16, gate=True, env_extra=None, cap=14 * 60):
    ok, rec = vms_launch(name, flags, env_extra)
    a = {"ok": False, "launch_sec": rec.get("sec"), "kv_tokens": rec.get("kv_tokens"), "skipped": rec.get("skipped"),
         "flags": flags, "env": env_extra or {}, "level_wanted": level, "kernels": rec.get("kernels")}
    VMS["arms"][name] = a          # rev 2g: a crash in the post-processing keeps the measured windows
    if ok:
        # rev 2b (agent 3 F1): one deadline for the whole arm: its cap, and never into the 2 x TP2 reserve
        t_end = min(time.perf_counter() + cap, HARD_STOP - VMS_RESERVE - 120)
        a["deadline_in_sec"] = round(t_end - time.perf_counter())
        _dp = "--data-parallel-size" in [str(x) for x in flags]
        a["diagnostic_only"] = bool(_dp)       # rev 2g (GPT R2F-01): no XL / per-rank canary on DP: never adoptable
        try:
            if gate in ("ref", "oracle"):
                rows, aa = vms_aa(name, deadline=t_end)
                VMS_ROWS[name] = rows
                a["aa"] = aa
                a["canary"] = vms_canary(level, deadline=t_end)
                if gate == "ref":
                    VMS_REF.update(rows)
                    a["gate"] = "reference" if aa["complete"] else "reference (A/A incomplete: every later gate INCOMPLETE)"
                elif aa["degenerate"] == 0 and aa["complete"] and a["canary"].get("foreign_leaks") == 0 \
                        and a["canary"].get("errors") == 0 and ((not _X) or (isinstance(aa.get("xl"), dict)
                        and aa["xl"].get("expected", 0) > 0 and aa["xl"].get("compared") == aa["xl"].get("expected")
                        and not aa["xl"].get("missing_margins"))):      # rev 2g (GPT R2F-10): XL A/A + canary clean
                    # rev 2: the oracle replaces the gate reference; the production reference is judged from its own rows
                    _r = VMS_ROWS.get("ref_fp8_mtp3_s16")
                    VMS_REF.clear()
                    VMS_REF.update(rows)
                    VMS["oracle_ready"] = True       # rev 2e (GPT audits HIGH-1 / E3): certification needs this
                    VMS["gate_reference"] = name + " (FP8, no speculation, prefix caching off)"
                    a["gate"] = "oracle"
                    if _r:
                        _v, _d = vms_judge(_r["serial_a"], _r["conc_a"], rows)
                        # rev 2g-b (agent 2 V1-d): the reference's warm (prefix-hit) A/A rows judged too; the worse counts
                        _v2, _d2 = vms_judge(_r["serial_b"], _r["conc_b"], rows)
                        _rank = {"PASS": 0, "INCOMPLETE": 1, "FAIL": 2}
                        _d["warm_verdict"], _d["warm_gate_class"] = _v2, _d2.get("gate_class")
                        if _rank.get(_v2, 2) > _rank.get(_v, 2):
                            _v, _d = _v2, dict(_d2, cold_verdict=_v, warm_verdict=_v2)
                        elif _v == "PASS" and _d2.get("gate_class") == "BOUNDARY":
                            _d["gate_class"] = "BOUNDARY"
                        VMS["ref_vs_oracle"] = {"verdict": _v, "detail": _d, "xl": vms_judge_xl(_r.get("xl_a"), rows)}
                        if VMS["arms"].get("ref_fp8_mtp3_s16"):
                            VMS["arms"]["ref_fp8_mtp3_s16"].update(gate=_v, gate_class=_d.get("gate_class"),
                                                                  xl_gate=(VMS["ref_vs_oracle"]["xl"] or {}).get("verdict"))
                else:
                    a["gate"] = "oracle unusable (incomplete or degenerate A/A, or a canary leak)"
            elif VMS_REF:
                s, c = vms_greedy(_S[:6], deadline=t_end), vms_greedy(_S, concurrent=True, deadline=t_end)
                xg = vms_greedy(_X[:4], concurrent=True, deadline=t_end) if (_X and not _dp) else None
                vms_save_rows(name + "_gate", {"serial": s, "conc": c, "xl": xg})
                a["gate"], a["gate_detail"] = vms_judge(s, c, VMS_REF, gate=bool(gate))
                a["gate_class"] = a["gate_detail"].get("gate_class")
                a["xl_gate"] = (vms_judge_xl(xg, VMS_REF) or {}).get("verdict") if xg else None
                a["canary"] = vms_canary(level, deadline=t_end)
            # rev 2: a FAIL is recorded and never adopted, but the speed is still measured
            a["short"] = vms_window(_S, level, _ts(75), name + "_short", deadline=t_end)
            # the next band runs unless the server is dead or dirty (a contaminated window would follow)
            _stop_next = lambda w: (w or {}).get("error") == "DIRTY_SERVER_AFTER_WINDOW" or (w or {}).get("idle_after") is False
            if time.perf_counter() < t_end and not _vms_dead() and not _stop_next(a["short"]):
                a["long"] = vms_window(_L, level, _ts(75), name + "_long", deadline=t_end)
            # rev 2d: the XL band (~85k prompts + up to 8k generated, ~100k per stream), at the streams the KV holds
            if _X and not _dp and time.perf_counter() < t_end and not _vms_dead() and not _stop_next(a.get("long")):
                _lx = max(1, min(level, (rec.get("kv_tokens") or 0) // 100_000)) if rec.get("kv_tokens") else min(level, 6)
                a["xl"] = vms_window(_X, _lx, _ts(75), name + "_xl", deadline=t_end)
            a["server_alive_after"] = not _vms_dead()
        except BaseException as _e:
            a["error"] = f"{type(_e).__name__}: {_e}"[:500]
        sig = VMS_SERVER.log_text() if VMS_SERVER is not None else ""
        # rev 2g-c (agent 3 A5): no whole-log 'Preempt' scan (the stats line carries it; one preemption in the diagnostic
        # XL window blocked adoption); the short / long windows require 0 preemptions instead (vms_window_healthy)
        a["log_errors"] = {k: sig.count(k) for k in ("Traceback", "out of memory", "OutOfMemory") if k in sig}
        a["preempt_log_lines"] = sig.count("Preempt")
    if VMS_SERVER is not None and "VLLM_ALLREDUCE_USE_FLASHINFER_PCIE_IPC" in (env_extra or {}):
        _lt = VMS_SERVER.log_text()        # rev 2d: did the PCIe-IPC all-reduce really engage?
        a["pcie_ipc"] = {"initialized": "Initialized FlashInfer PCIe IPC all-reduce" in _lt,
                         "not_provided": "does not provide PcieIpcAllReduceWorkspace" in _lt,
                         "other_warning": [l[-200:] for l in _lt.splitlines() if "PCIe IPC" in l and "Initialized" not in l][:4]}
    for band in ("short", "long", "xl"):
        w = a.get(band) or {}
        a[band + "_tok_s"], a["accept_" + band], a["level_" + band] = w.get("tok_s"), w.get("accept"), w.get("measured_level")
        a[band + "_e2e_tok_s"] = w.get("end_to_end_tok_s")
    vms_classify(a)
    VMS["arms"][name] = a
    VMS["order"].append(name)
    e14_save()
    print("VMS arm", name, json.dumps({k: v for k, v in a.items() if k not in ("flags", "short", "long", "xl")}, default=str)[:700], flush=True)
    return a


if VMS_ON and VMS_INST and not VMS["install"].get("error"):
    _ask = "Find the transformation rule of this ARC-AGI-2 task and describe it, then give the test output grids."
    _rows = lambda g: "\n".join(" ".join(str(v) for v in r) for r in g)
    _tt = lambda t: "".join(f"\nExample {i + 1}\nInput:\n{_rows(p['input'])}\nOutput:\n{_rows(p['output'])}\n"
                            for i, p in enumerate(t["train"])) + \
        "".join(f"\nTest input {j + 1}:\n{_rows(q['input'])}\n" for j, q in enumerate(t["test"]))
    _ids = lambda msgs: tokenizer.encode(tokenizer.apply_chat_template(msgs, tokenize=False, add_generation_prompt=True,
                                                                        enable_thinking=True, reasoning_effort=REASONING_EFFORT),
                                         add_special_tokens=False)
    _S = [_ids([{"role": "user", "content": _ask + "\n" + _tt(CHALLENGES[t])}]) for t in TASK_IDS]
    _all = _load_json(ARC_ROOT / "arc-agi_evaluation_challenges.json")
    _bg, _n = [], 0
    for _t in sorted(_all):
        if _t in CHALLENGES:
            continue
        _bg.append(_tt(_all[_t]))
        _n += len(tokenizer.encode(_bg[-1], add_special_tokens=False))
        if _n >= int(os.environ.get("E14_LONG_TOKENS", 36000)):
            break
    _block = "Reference tasks (not to be solved):\n" + "\n".join(_bg)
    _L = [_ids([{"role": "system", "content": _block}, {"role": "user", "content": _ask + "\n" + _tt(CHALLENGES[t])}])
          for t in TASK_IDS]
    # rev 2d: the XL band, a shared ~85k-token block (vLLM max_model_len 106,496: 85k + 8k generated fits)
    _bgx, _nx = list(_bg), _n
    for _t in sorted(_all):
        if _nx >= int(os.environ.get("E14_XL_TOKENS", 85000)):
            break
        if _t in CHALLENGES or _tt(_all[_t]) in _bgx:
            continue
        _bgx.append(_tt(_all[_t]))
        _nx += len(tokenizer.encode(_bgx[-1], add_special_tokens=False))
    _blockx = "Reference tasks (not to be solved):\n" + "\n".join(_bgx)
    _X = [_ids([{"role": "system", "content": _blockx}, {"role": "user", "content": _ask + "\n" + _tt(CHALLENGES[t])}])
          for t in TASK_IDS]
    VMS["prompts"] = {"short_p50": statistics.median(len(x) for x in _S), "long_p50": statistics.median(len(x) for x in _L),
                      "xl_p50": statistics.median(len(x) for x in _X)}
    E14_STATE.enter("VMS_ARMS")
    vms_arm("ref_fp8_mtp3_s16", vms_flags(MODEL_PATH), gate="ref")
    VMS_RESERVE = _ts(35 * 60)            # the 2 x TP2 slot: no earlier arm may eat it
    # rev 2: the oracle first (FP8, no speculation, prefix caching off), then the arms gated against it
    vms_arm("fp8_target_only_noprefix", vms_flags(MODEL_PATH, spec=0, prefix=False), gate="oracle")
    VMS.setdefault("gate_reference", "ref_fp8_mtp3_s16 (the oracle A/A was not usable)")
    _INT4_OK = vms_int4_mtp_static(VMS_INT4)
    try:          # rev 2g-c (checklist 9): the exact packages and prompts of this run
        VMS["pip_freeze"] = subprocess.run([(VMS.get("install") or {}).get("launch", [sys.executable])[0], "-m", "pip", "freeze"],
                                           capture_output=True, text=True, timeout=180).stdout[-20000:]
    except Exception as _e:
        VMS["pip_freeze"] = repr(_e)[:200]
    VMS["prompt_sha"] = {k_: [__import__("hashlib").sha256(json.dumps(list(x_)).encode()).hexdigest()[:16] for x_ in v_]
                         for k_, v_ in (("short", _S), ("long", _L), ("xl", _X or []))}
    PLAN = [
        # rev 2d: FlashInfer PCIe-IPC all-reduce (cuda_communicator.py: dispatched after custom / quick all-reduce, both
        # off on 4 PCIe GPUs, before NCCL; bf16 / fp16 only)
        ("fp8_mtp3_pcie", vms_flags(MODEL_PATH), dict(env_extra={"VLLM_ALLREDUCE_USE_FLASHINFER_PCIE_IPC": "1"})),
        # rev 2e (GPT audit order): the prefix-cache isolation, MTP width, 20 / 24 streams, then INT4 and SSM variants
        ("fp8_mtp3_noprefix", vms_flags(MODEL_PATH, prefix=False), {}),
        ("fp8_mtp2", vms_flags(MODEL_PATH, spec=2), {}),
        ("fp8_mtp4", vms_flags(MODEL_PATH, spec=4), {}),
        ("fp8_mtp3_s20", vms_flags(MODEL_PATH, seqs=20), dict(level=20)),
        ("fp8_mtp3_s24", vms_flags(MODEL_PATH, seqs=24), dict(level=24)),
        # rev 2 (GPT audit V6): VLLM_TEST_FORCE_FP8_MARLIN is gone (not in v0.32.0 envs.py); --linear-backend replaces it
        # (arg_utils.py:1808-1810, config/kernel.py:244-266). A layer type without that backend falls back to auto, so
        # the arm records the kernels the log says were selected.
        # rev 2b (agent 4 F1, checked in kernels/linear/__init__.py:478-489 + cutlass_scaled_mm_entry.cu:161-174): on SM 8.9
        # the automatic FP8 block-128 choice is already MarlinFP8ScaledMM (weight-only W8A16): CUTLASS block FP8 needs
        # SM 90+, DeepGEMM / B12x too. So "marlin" = the reference; "triton" = the only real W8A8 FP8 GEMM on the L4.
        ("fp8_mtp3_lb_triton", vms_flags(MODEL_PATH, extra={"--linear-backend": "triton"}), {}),
        ("fp8_mtp3_ssm_fp16", vms_flags(MODEL_PATH, extra={"--mamba-ssm-cache-dtype": "float16"}), {}),
        ("int4_mtp3_s16", vms_flags(VMS_INT4), dict(gate=False)),
        ("int4_mtp3_s20", vms_flags(VMS_INT4, seqs=20), dict(level=20, gate=False)),
    ]
    VMS["dropped"] = {"fp8_mtp3_marlin (VLLM_TEST_FORCE_FP8_MARLIN=1)": "the env var is not in vLLM 0.32.0 envs.py "
                      "(removed by PR #52182): the arm would have run the reference unchanged; replaced by --linear-backend",
                      "fp8_mtp3_lb_marlin (--linear-backend marlin)": "on SM 8.9 the automatic FP8 block-128 kernel is "
                      "already MarlinFP8ScaledMM (kernels/linear/__init__.py:478-489; CUTLASS block FP8 needs SM 90+, "
                      "cutlass_scaled_mm_entry.cu:161-174): the arm = the reference"}
    for _name, _fl, _kw in PLAN:
        if _name.startswith("int4_") and not _INT4_OK:
            VMS["arms"][_name] = {"ok": False, "skipped": "INT4 MTP static check failed: " + VMS["int4_mtp_static"].get("why", "")}
            VMS["order"].append(_name)
            continue
        vms_arm(_name, _fl, **_kw)
    # LAST: 2 x TP2 inside one vLLM server (data parallel 2 x tensor parallel 2), 8 seqs per rank = 16 in all
    # (GPT audit V5: --max-num-seqs is per DP rank)
    VMS_RESERVE = 0.0
    # rev 2b (agent 4 F4b, cli/serve.py:107-130): one API server (DP defaults to one per rank, each balancing on its own
    # counts). Custom all-reduce stays OFF: a TP2 group would use it when the P2P test passes (custom_all_reduce.py:
    # 281-291), and on this VM the P2P/IPC path measured 5.5x slower than NCCL (E14A nccl_bench p2p_sys 1,880 us vs 344 us)
    _TP2X = {"--api-server-count": 1}
    _NCCLX = {"NCCL_DEBUG": "INFO", "NCCL_DEBUG_SUBSYS": "INIT"}       # rev 2c (GPT audit Gate D): the NCCL transport in the log
    try:          # rev 2c (Gate D / section 7): the topology and P2P matrices
        VMS["topology"] = {"matrix": subprocess.run(["nvidia-smi", "topo", "-m"], capture_output=True, text=True, timeout=30).stdout[-3000:],
                           "p2p_read": subprocess.run(["nvidia-smi", "topo", "-p2p", "r"], capture_output=True, text=True, timeout=30).stdout[-2000:],
                           "p2p_prop": subprocess.run(["nvidia-smi", "topo", "-p2p", "p"], capture_output=True, text=True, timeout=30).stdout[-2000:]}
    except Exception as _e:
        VMS["topology"] = {"error": repr(_e)[:200]}
    vms_arm("tp2x2_fp8_mtp3", vms_flags(MODEL_PATH, tp=2, dp=2, seqs=8, extra=_TP2X), level=16, gate=True, cap=16 * 60, env_extra=_NCCLX)
    if _INT4_OK:
        vms_arm("tp2x2_int4_mtp3", vms_flags(VMS_INT4, tp=2, dp=2, seqs=8, extra=_TP2X), level=16, gate=False,
                cap=16 * 60, env_extra=_NCCLX)
    else:
        VMS["arms"]["tp2x2_int4_mtp3"] = {"ok": False, "skipped": "INT4 MTP static check failed: " + VMS["int4_mtp_static"].get("why", "")}
        VMS["order"].append("tp2x2_int4_mtp3")
    for _a in VMS["arms"].values():       # rev 2e: the final classification (the reference is judged after the oracle)
        if "level_wanted" in _a:
            vms_classify(_a)
    E14_STATE.enter("VMS_DONE")
    e14_save()
else:
    VMS["skipped"] = "rerun" if RERUN else ("install failed" if VMS_INST is None or (VMS["install"] or {}).get("error") else "VMS off")
    print("VMS skipped:", VMS["skipped"], flush=True)
