# E15B · config B: 2 independent Duck attempts per task (50k + 45k tokens), 16 real streams (SGLang 0.5.21 + RedHat INT4 + DFlash2 W6)

**Base (unchanged code path):** the E14S submission notebook (LB 22.78), built in memory by build_e14.py.

**E15B changes (Experiment 15 Notes/02, 08):** two independent attempts per task, 50,000 then 45,000 generated tokens (attempt 1 on every task first, attempt 2 = a fresh agent with the facts view), no pause / chunk / resume, no 12k / 24k / 32k request caps (cap = remaining budget - 4,096; then one commit turn), a fixed 100k Duck window, the tool contract and the budget in the prompt, submit / check tool calls routed to python, auto-check of candidate / trans names, the sandbox's safe sys shim and time, the defined-functions inventory, code written only in the reasoning harvested at the end, a reply's remaining tool calls run before a yield (no turn rollback), a restarting scheduler worker. Engine: 16 streams (mrr 17, graphs 1..17, mamba 68), the DFlash min-free-slots delayer off, KV per request 50k, request timeout 3,000 s; a 12-stream fallback launch.

**Commit:** all 120 evaluation tasks at the hidden run's compute per task (gate 4b). **Rerun:** every hidden task with the same solver.

**Inputs:** the private dataset `esfersami50/q27-e15b-payload` (files named by their sha256, verified before use) must be attached.
