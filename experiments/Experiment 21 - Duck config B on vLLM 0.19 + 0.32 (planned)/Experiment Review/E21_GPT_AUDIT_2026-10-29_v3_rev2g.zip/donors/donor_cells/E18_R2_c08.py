# E10 — Poetiq program synthesis, train-verification and task-level output report
try:
    for tid in TASK_IDS:
        if tid not in E10_FINAL:
            E10_FINAL[tid]=poetiq_two_attempts(CHALLENGES[tid],[])
    generated={tid:E10_FINAL[tid] for tid in TASK_IDS}
    write_json_atomic(OUT/'poetiq_eval_generated_submission.json',generated)
    report={'run_id':RUN_ID,'profile':PROFILE,'rerun':RERUN,
            'source_base_sha256':'530cb119e302899426a2e3f24c5e100279e7167aef77525b6cb93b90a7fc10c0',
            'donor':'https://github.com/poetiq-ai/poetiq-arc-agi-solver',
            'configuration':CONFIG,'engine':ENGINE_INFO,'scheduler':E10_SCHED,
            'tasks_planned':len(TASK_IDS),'queries_planned':sum(len(CHALLENGES[t]['test']) for t in TASK_IDS),
            'experts_planned':len(E10_STATES),'experts_train_verified':sum(s['status']=='train_verified' for s in E10_STATES.values()),
            'programs_generated':E10_SCHED['programs_parsed'],
            'expert_states':{f'{t}~e{e}':{'iteration':s['iteration'],'status':s['status'],
                                       'best_score':s['best_score']} for (t,e),s in E10_STATES.items()},
            'task_ranked_programs':{tid:len(e10_rank_task(tid)) for tid in TASK_IDS},
            'generated_attempts_path':'q27x/poetiq_eval_generated_submission.json'}
    if SOLUTIONS is not None:
        hits=0;pass1=0;pass2=0;total=0;records=[]
        for tid in TASK_IDS:
            for qi,att in enumerate(E10_FINAL[tid]):
                gold=SOLUTIONS[tid][qi];a=(att['attempt_1']==gold);b=(att['attempt_2']==gold)
                hits+=a or b;pass1+=a;pass2+=b;total+=1
                records.append({'task':tid,'query':qi,'pass1':bool(a),'pass2':bool(b),'hit':bool(a or b)})
        report.update(eval_query_hits=hits,eval_query_total=total,eval_score_pct=round(100*hits/max(1,total),2),
                      eval_pass1_hits=pass1,eval_pass2_hits=pass2,eval_unit_records=records)
    write_json_atomic(OUT/'poetiq_run_report.json',report)
    print('E10 RUN REPORT:',str(OUT/'poetiq_run_report.json'),
          'eval',report.get('eval_query_hits'),'/ ',report.get('eval_query_total'),flush=True)
    # Last: ensure the actual Kaggle submission and bundled version are identical.
    e10_write_submission()
    _pack=WORKING/'Q27X_E10_POETIQ_BUNDLE.zip'
    with zipfile.ZipFile(_pack,'w',zipfile.ZIP_DEFLATED) as z:
        for fp in (SUBMISSION_PATH, OUT/'poetiq_run_report.json',OUT/'poetiq_final_generated.json',
                   OUT/'poetiq_eval_generated_submission.json',OUT/'poetiq_iterations.jsonl',
                   OUT/'poetiq_vllm_metrics.json'):
            if fp.exists():z.write(fp,arcname=fp.name)
    print('E10 bundle:',_pack,flush=True)
except BaseException:
    print('E10 reporting error (submission.json still exists):',traceback.format_exc()[-3000:],flush=True)
