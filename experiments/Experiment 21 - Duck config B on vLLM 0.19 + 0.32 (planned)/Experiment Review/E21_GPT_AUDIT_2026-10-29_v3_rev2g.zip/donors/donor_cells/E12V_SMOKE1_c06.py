# ==================================================================== CELL 5 — engine: vLLM 0.19 OpenAI server (E12-V)
# Duck's own Kaggle vLLM launcher (inference/framework/kaggle.py: start_vllm_server / wait_for_vllm_server /
# run_vllm_api_smoke_test), verbatim flags, plus the S1-60K engine settings (LB 34.58: TP4, fp8_e4m3 KV, MTP-3,
# FlashInfer, prefix caching, 4096 batched tokens, 16 seqs, 0.90 GPU memory, libcuda shim). vllm==0.19.0 is installed by
# CELL 2 (the S1-60K path). The names CELL 6/7 use (SGL_URL, ENGINE_READY, CONCURRENCY, metrics_snapshot, E11_SERVER,
# e11_kill_server, e11_decode_summary, engine) are kept. No launch ladder: if the server does not come up, CELL 0's
# fallback submission stays.
import urllib.request as _urlreq, signal as _signal, statistics as _statistics
E11_HARNESS = os.environ.get("E11_HARNESS") == "1"            # local CPU harness only: fake server, no GPU
VLLM_PORT = int(os.environ.get("E12_VLLM_PORT", 1234))       # Duck's DEFAULT_VLLM_PORT
SGL_URL = f"http://127.0.0.1:{VLLM_PORT}"                      # name kept for CELL 6/7
VLLM_SERVED_NAME = "Qwen/Qwen3.8-27B-FP8"   # E12-V rev 3: keithtyser's Duck served name. NOT "qwen": Duck treats
# "local"/"local-qwen"/"qwen-local"/"qwen" as a preset alias and then sends LOCAL_ANALYZER_MODEL_ID (CELL 3: "pending")
# instead (tool_agent._resolve_analyzer_model); vLLM answered every Duck request with 404 (vLLM SMOKE1 run 1, 2026-10-19).
VLLM_MAX_MODEL_LEN = 135168          # Duck's 128 Ki context window + margin (S1-60K: 106,496)
VLLM_LAUNCH_TIMEOUT_SEC = 30 * 60    # Duck waits 900 s; our 4xL4 load + JIT + CUDA graphs took ~8-9 min (Q27-AGENT run 4)
E12_VLLM_CONCURRENCY = 12            # = the SGLang W1 run (Duck active streams); the server admits up to MAX_NUM_SEQS
ENGINE_READY = False; llm = None; engine = None; CONCURRENCY = 0; E11_SERVER = None
ENGINE_INFO = {"backend": None, "vllm": {"stage": "not started"}, "kv_tokens": None, "concurrency": None, "fatal": None,
               "load_sec": None}

import shutil as _shutil
def ensure_libcuda_linkable(candidates=None, workdir="/tmp/q27x_libcuda_shim"):
    info = {"needed": None, "real": None, "shim": None, "probe": "FAIL"}
    try:
        work = Path(workdir); work.mkdir(parents=True, exist_ok=True)
        if candidates is None:
            existing = [Path(d, "libcuda.so") for d in ("/usr/local/cuda/lib64", "/usr/local/cuda/lib64/stubs",
                                                        "/usr/lib/x86_64-linux-gnu", "/usr/lib64")]
            existing = [p for p in existing if p.exists()]
        else:
            existing = []
        if existing:
            info.update(needed=False, real=str(existing[0]))
        else:
            cands = list(candidates) if candidates is not None else []
            if candidates is None:
                for d in ("/usr/local/nvidia/lib64", "/usr/local/nvidia/lib", "/usr/lib/x86_64-linux-gnu", "/usr/lib64",
                          "/usr/local/cuda/compat"):
                    try:
                        cands += sorted(str(p) for p in Path(d).glob("libcuda.so.*") if p.is_file())
                    except Exception:
                        pass
                try:
                    for line in subprocess.run(["ldconfig", "-p"], capture_output=True, text=True, timeout=30).stdout.splitlines():
                        if "libcuda.so.1" in line and "=>" in line:
                            cands.append(line.split("=>")[-1].strip())
                except Exception:
                    pass
            real = next((Path(c) for c in cands if Path(c).is_file()), None)
            if real is None:
                info["reason"] = "libcuda.so.1 not found"
                return info
            link = work / "libcuda.so"
            if link.exists() or link.is_symlink():
                link.unlink()
            try:
                link.symlink_to(real.resolve())
            except OSError:
                _shutil.copyfile(real, link)
            old = os.environ.get("LIBRARY_PATH", "")
            os.environ["LIBRARY_PATH"] = f"{work}:{old}" if old else str(work)
            info.update(needed=True, real=str(real), shim=str(link), library_path=os.environ["LIBRARY_PATH"])
        cxx = _shutil.which("c++") or _shutil.which("g++")
        if not cxx:
            info["reason"] = "no C++ compiler for the link probe"
            return info
        cp = subprocess.run([cxx, "-shared", "-fPIC", "-x", "c++", "-", "-lcuda", "-o", str(work / "probe.so")],
                            input='extern "C" int q27x_probe() { return 0; }\n', text=True, capture_output=True,
                            timeout=120, env=os.environ.copy())
        info["probe"] = "PASS" if cp.returncode == 0 else "FAIL"
        if cp.returncode != 0:
            info["probe_stderr"] = (cp.stderr or "")[-1500:]
    except Exception as e:
        info["reason"] = f"{type(e).__name__}: {e}"[:500]
    return info



class _E12VllmServer:
    def __init__(self, cmd, env):
        self.cmd, self.env, self.proc, self.log_f = cmd, env, None, None
        self.log_path = OUT / "vllm_openai_server.log"

    def start(self):
        self.log_f = open(self.log_path, "w", encoding="utf-8")
        self.t0 = time.perf_counter()
        self.proc = subprocess.Popen(self.cmd, env=self.env, stdout=self.log_f, stderr=subprocess.STDOUT,
                                     cwd=None if E11_HARNESS else "/tmp", start_new_session=True)

    def alive(self):
        return self.proc is not None and self.proc.poll() is None

    def log_text(self):
        try:
            return self.log_path.read_text(encoding="utf-8", errors="replace")
        except Exception:
            return ""

    def kill(self, wait=True):
        if self.alive():
            for sig, w in ((_signal.SIGTERM, 30 if wait else 0), (getattr(_signal, "SIGKILL", _signal.SIGTERM), 30)):
                try:
                    if hasattr(os, "killpg"):
                        os.killpg(self.proc.pid, sig)          # the whole group: API server, engine core, TP workers
                    else:
                        self.proc.kill()
                except Exception:
                    pass
                try:
                    self.proc.wait(timeout=w if w else 0.1)
                    break
                except Exception:
                    continue
        if self.log_f:
            try:
                self.log_f.close()
            except Exception:
                pass
            self.log_f = None


def e11_kill_server(wait=True):
    if E11_SERVER is not None:
        E11_SERVER.kill(wait=wait)


def _e12v_request_json(url, payload=None, timeout=30):   # = Duck's request_json
    data = None if payload is None else json.dumps(payload).encode("utf-8")
    req = _urlreq.Request(url, data=data, headers={"Content-Type": "application/json"})
    with _urlreq.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


_E12V_PROM_RE = re.compile(r"^([A-Za-z_:][A-Za-z0-9_:]*)(\{[^}]*\})?\s+(\S+)")
# vLLM metric names -> the names CELL 6's heartbeat prints (SGLang wording)
_E12V_ALIAS = {"vllm:num_requests_running": "num_running_reqs", "vllm:num_requests_waiting": "num_queue_reqs",
               "vllm:kv_cache_usage_perc": "token_usage"}


def metrics_snapshot():
    if not ENGINE_READY:
        return []
    try:
        txt = _urlreq.urlopen(SGL_URL + "/metrics", timeout=10).read().decode("utf-8", "replace")
        rows = []
        for line in txt.splitlines():
            m = _E12V_PROM_RE.match(line) if line and not line.startswith("#") else None
            if not m or m.group(1).endswith(("_bucket", "_created")):
                continue
            name = m.group(1)
            if name in _E12V_ALIAS or any(k in name for k in ("prefix_cache", "spec_decode", "generation_tokens_total",
                                                               "prompt_tokens_total", "num_preemptions")):
                try:
                    rows.append({"name": _E12V_ALIAS.get(name, name), "labels": m.group(2), "value": float(m.group(3))})
                except ValueError:
                    pass
        return rows
    except Exception as e:
        return [{"error": repr(e)[:300]}]


_E12V_STAT_RE = re.compile(r"Avg prompt throughput: ([\d.]+) tokens/s, Avg generation throughput: ([\d.]+) tokens/s, "
                           r"Running: (\d+) reqs, Waiting: (\d+) reqs, GPU KV cache usage: ([\d.]+)%, Prefix cache hit rate: ([\d.]+)%")


def e11_decode_summary():
    """vLLM's periodic engine stats lines: generation throughput by running level, KV usage, prefix-cache hit rate."""
    if E11_SERVER is None:
        return None
    rows = [tuple(float(x) for x in m.groups()) for m in _E12V_STAT_RE.finditer(E11_SERVER.log_text())]
    med = lambda v: round(_statistics.median(v), 1) if v else None
    acc = re.findall(r"Mean acceptance length: ([\d.]+)", E11_SERVER.log_text())
    out = {"n_lines": len(rows),
           "running_hist": {str(int(k)): sum(1 for r in rows if r[2] == k) for k in sorted({r[2] for r in rows})},
           "gen_tok_s_median_at_concurrency": med([r[1] for r in rows if r[2] >= E12_VLLM_CONCURRENCY]),
           "gen_tok_s_median_all_busy": med([r[1] for r in rows if r[2] > 0]),
           "waiting_max": max((r[3] for r in rows), default=None), "kv_usage_pct_max": max((r[4] for r in rows), default=None),
           "prefix_cache_hit_pct_last": rows[-1][5] if rows else None,
           "spec_mean_acceptance_median": med([float(a) for a in acc]),
           "preemption_lines": sum(1 for l in E11_SERVER.log_text().splitlines() if "preempt" in l.lower())}
    try:
        write_json_atomic(OUT / "sglang_decode_summary.json", out)   # bundled under this name by CELL 7
    except Exception:
        pass
    return out


def e12v_bring_up():
    global E11_SERVER
    info = ENGINE_INFO["vllm"]
    info["stage"] = "inputs"
    if not (MODEL_PATH / "config.json").is_file():
        raise RuntimeError(f"model missing: {MODEL_PATH}")
    if not E11_HARNESS:
        assert pkg_version("vllm") == "0.19.0", pkg_version("vllm")
        os.environ.setdefault("MAX_JOBS", "4")              # bound FlashInfer JIT build parallelism (S1-60K)
        info["cuda_link"] = ensure_libcuda_linkable()       # S1-60K: makes -lcuda linkable for FlashInfer's JIT
    else:
        info["cuda_link"] = {"probe": "PASS", "harness": True}
    backend = "FLASHINFER" if info["cuda_link"].get("probe") == "PASS" else "TRITON_ATTN"   # = the S1-60K ladder's first
    env = os.environ.copy()
    env.update({"USE_TF": "0", "TRANSFORMERS_NO_TF": "1", "TRANSFORMERS_NO_TORCHVISION": "1", "VLLM_NO_USAGE_STATS": "1",
                "VLLM_MEMORY_PROFILER_ESTIMATE_CUDAGRAPHS": "1", "PYTHONUNBUFFERED": "1"})   # Duck's vllm_env + S1-60K
    launch = ([sys.executable, "-m", "vllm.entrypoints.openai.api_server"] if not E11_HARNESS
              else [sys.executable, os.environ["E12_FAKE_VLLM_SERVER"]])
    flags = [
        # Duck's start_vllm_server, verbatim
        "--model", str(MODEL_PATH), "--served-model-name", VLLM_SERVED_NAME, "--host", "127.0.0.1", "--port", str(VLLM_PORT),
        "--tensor-parallel-size", "4", "--enable-auto-tool-choice", "--tool-call-parser", "qwen3_coder",
        "--generation-config", "vllm", "--enable-prefix-caching", "--default-chat-template-kwargs",
        json.dumps({"preserve_thinking": True}), "--reasoning-parser", "qwen3", "--max-model-len", str(VLLM_MAX_MODEL_LEN),
        # the S1-60K engine (CELL 1 values); keithtyser's Duck launch adds --kv-cache-dtype fp8 the same way
        "--kv-cache-dtype", KV_CACHE_DTYPE, "--speculative-config", json.dumps(SPECULATIVE_CONFIG),
        "--attention-backend", backend, "--max-num-batched-tokens", str(MAX_NUM_BATCHED_TOKENS),
        "--max-num-seqs", str(MAX_NUM_SEQS), "--gpu-memory-utilization", str(GPU_MEMORY_UTILIZATION),
        "--language-model-only", "--disable-custom-all-reduce", "--seed", str(SEED),
        # cached_tokens in usage (prefix-cache measurement; SGLang: --enable-cache-report)
        "--enable-prompt-tokens-details"]
    info.update(stage="launch", flags=flags, attention_backend=backend)
    srv = _E12VllmServer(launch + flags, env)
    srv.start()
    E11_SERVER = srv
    print("E12-V: starting vLLM OpenAI server:", " ".join(flags), flush=True)
    deadline = time.perf_counter() + min(VLLM_LAUNCH_TIMEOUT_SEC, max(60, ADMIT_DEADLINE - time.perf_counter()))
    while True:                                          # = Duck's wait_for_vllm_server (/v1/models)
        if not srv.alive():
            raise RuntimeError(f"vLLM server exited rc={srv.proc.returncode}: " + srv.log_text()[-3000:])
        try:
            models = _e12v_request_json(SGL_URL + "/v1/models", timeout=5)
            info["models"] = [m.get("id") for m in models.get("data", [])]
            break
        except Exception:
            if time.perf_counter() > deadline:
                raise RuntimeError("vLLM server not ready before the deadline: " + srv.log_text()[-3000:])
            time.sleep(2 if E11_HARNESS else 5)
    info["ready_sec"] = round(time.perf_counter() - srv.t0, 1)
    log = srv.log_text()
    kv = re.findall(r"GPU KV cache size: ([\d,]+) tokens", log)
    mc = re.findall(r"Maximum concurrency for ([\d,]+) tokens per request: ([\d.]+)x", log)
    info["kv_tokens_logged"] = int(kv[-1].replace(",", "")) if kv else None
    info["max_concurrency_logged"] = {"tokens": int(mc[-1][0].replace(",", "")), "x": float(mc[-1][1])} if mc else None
    info["stage"] = "smoke"
    # = Duck's run_vllm_api_smoke_test + valid usage counters. E12-V rev 2 (GPT audits, validated): vLLM 0.19 sets
    # usage.prompt_tokens_details only when num_cached_tokens is truthy (chat_completion/serving.py:1601-1603; issue
    # https://github.com/vllm-project/vllm/issues/44377), so this first, cold request has none: record it, never fail on it.
    r = _e12v_request_json(SGL_URL + "/v1/chat/completions", payload={
        "model": VLLM_SERVED_NAME, "messages": [{"role": "user", "content": "Answer in one short sentence: what is 2 + 2?"}],
        "temperature": 0.0, "max_tokens": 96, "chat_template_kwargs": {"enable_thinking": False}}, timeout=300)
    gen = (r["choices"][0]["message"].get("content") or "").strip()
    usage = r.get("usage") or {}
    _det = usage.get("prompt_tokens_details")
    info["smoke"] = {"generated": gen[:200], "usage": usage, "cache_details_present": isinstance(_det, dict),
                     "ok": bool(gen) and isinstance(usage.get("prompt_tokens"), int) and usage["prompt_tokens"] > 0
                     and isinstance(usage.get("completion_tokens"), int) and usage["completion_tokens"] > 0}
    print("E12-V smoke:", json.dumps(info["smoke"]), flush=True)
    if not info["smoke"]["ok"]:
        raise RuntimeError("vLLM smoke failed: " + json.dumps(info["smoke"])[:600])
    return info


_t_engine = time.perf_counter()
if not E10_SANDBOX_SELFTEST.get("ok", False):
    ENGINE_INFO["vllm"]["stage"] = "skipped: sandbox self-test failed"
elif ENGINE_BACKEND != "vllm":
    ENGINE_INFO["vllm"]["stage"] = f"skipped: ENGINE_BACKEND={ENGINE_BACKEND}"
else:
    try:
        e12v_bring_up()
        ENGINE_READY = True
        CONCURRENCY = E12_VLLM_CONCURRENCY
        ENGINE_INFO.update(backend="vllm-0.19.0-fp8-mtp3-openai-server", kv_tokens=ENGINE_INFO["vllm"].get("kv_tokens_logged"),
                           max_model_len=VLLM_MAX_MODEL_LEN)
        ENGINE_INFO["vllm"]["stage"] = "ready"
    except Exception as _e:
        ENGINE_INFO["vllm"]["error"] = f"{type(_e).__name__}: {_e}"[:3000]
        ENGINE_INFO["fatal"] = ENGINE_INFO["vllm"]["error"][:300]
        print("E12-V vLLM engine NOT ready:", ENGINE_INFO["vllm"]["stage"], "|", ENGINE_INFO["vllm"]["error"][:1500], flush=True)
        e11_kill_server(); E11_SERVER = None
        ENGINE_READY = False; CONCURRENCY = 0
ENGINE_INFO["load_sec"] = round(time.perf_counter() - _t_engine, 1)
ENGINE_INFO["concurrency"] = int(CONCURRENCY)
print("engine:", json.dumps(ENGINE_INFO, default=str)[:3000], flush=True)
