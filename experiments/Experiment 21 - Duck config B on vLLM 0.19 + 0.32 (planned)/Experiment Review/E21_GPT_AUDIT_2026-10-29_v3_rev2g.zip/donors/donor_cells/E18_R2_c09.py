# ==================================================================== CELL 8b — E18: engine stats, stop the vLLM server
try:
    _st = {"engine": ENGINE_INFO.get("engine"), "shim": getattr(engine, "stats", None), "concurrency": CONCURRENCY,
           "kv_tokens": ENGINE_INFO.get("kv_tokens"), "scheduler_tok_per_sec": E10_SCHED.get("tok_per_sec"),
           "scheduler_tokens": E10_SCHED.get("tokens"), "max_active": E10_SCHED.get("max_active"),
           "kv_gate_blocks": E10_SCHED.get("kv_gate_blocks"), "metrics_end": metrics_snapshot() if ENGINE_READY else []}
    write_json_atomic(OUT / "e18_engine_stats.json", _st)
    print("E18 engine stats:", json.dumps({k: v for k, v in _st.items() if k != "metrics_end"}, default=str)[:2000], flush=True)
    # rev 2 (audit B-H1): the KV pressure at 20 streams
    _keys = ("num_preemptions", "num_requests_waiting", "kv_cache_usage", "prefix_cache_hits", "prefix_cache_queries")
    print("E18 KV / preemption:", json.dumps({m["name"] + (m.get("labels") or ""): m.get("value") for m in _st["metrics_end"]
                                               if any(k in str(m.get("name")) for k in _keys)})[:1500], flush=True)
except BaseException:
    print("E18 stats error:", traceback.format_exc()[-1500:], flush=True)
try:
    if globals().get("E18_SERVER") is not None:
        E18_SERVER.kill(fast=RERUN)          # rev 2 (B-L4): at once after the rerun's hard stop
        print("E18: vLLM 0.32 server stopped", flush=True)
except BaseException as _e:
    print("E18: server stop error", repr(_e)[:300], flush=True)
