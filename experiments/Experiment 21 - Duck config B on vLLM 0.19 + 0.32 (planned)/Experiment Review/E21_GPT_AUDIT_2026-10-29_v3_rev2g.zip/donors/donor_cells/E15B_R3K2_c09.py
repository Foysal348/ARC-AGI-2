# ==================================================================== CELL 6 — E12: Duck REPL agent, every task, E12_BRANCHES branches
# Every branch is admitted at once; Duck's priority gate keeps ARC3_MAX_ACTIVE_STREAMS conversations active (first
# branches in ORDER2 order before any second branch). A branch ends when the host verifies a submitted program on every
# train pair, at the deadline, or at the optional token cap. Full thinking: Duck's transcript.txt per branch.
_E12_INDEX = {t: i for i, t in enumerate(TASK_IDS)}


def _e12_order2_score(tid):   # = S49 ORDER2 ([>=3 train] + [1 test]) with the cells tie-break, sorted-id order last
    _t = CHALLENGES[tid]
    return int(len(_t["train"]) >= 3) + int(len(_t["test"]) == 1)


def _e12_total_cells(tid):
    _t = CHALLENGES[tid]
    _c = lambda g: len(g) * len(g[0]) if g and g[0] else 0
    return sum(_c(p["input"]) + _c(p["output"]) for p in _t["train"]) + sum(_c(p["input"]) for p in _t["test"])


E12_ORDER = sorted(TASK_IDS, key=lambda t: (-_e12_order2_score(t), _e12_total_cells(t), _E12_INDEX[t]))
E12_RECORDS = {t: [] for t in TASK_IDS}
E12_RUN = {"started_sec": None, "model_id": None, "streams": None, "deadline_in_sec": None, "error": None,
           "branches_done": 0, "branches_accepted": 0, "finished_sec": None}
_E12_LOCK = threading.Lock()
E12_OUT = OUT / "duck"
E12_OUT.mkdir(parents=True, exist_ok=True)


import tempfile as _tempfile
_E12_WRITE_LOCK = threading.Lock()   # rev 2 (GPT audits, reproduced): branches finish concurrently


def _e12_write_json_atomic(path, obj):
    """A unique temp file per write + os.replace (CELL 0's helper reuses one '<name>.tmp' for every writer)."""
    fd, tmp = _tempfile.mkstemp(prefix=Path(path).name + ".", suffix=".tmp", dir=str(Path(path).parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(obj, f)
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def e12_write_submission():
    with _E12_WRITE_LOCK:                          # one writer at a time; the snapshot is taken inside, so it is fresh
        sub = identity_submission(test_challenges)
        if RERUN:
            with _E12_LOCK:
                recs = {t: list(v) for t, v in E12_RECORDS.items() if v}
            for t, rows in E12A.build_submission({t: CHALLENGES[t] for t in recs}, recs).items():
                if t in sub and len(sub[t]) == len(rows):
                    sub[t] = rows
        _e12_write_json_atomic(SUBMISSION_PATH, sub)   # evaluation: keeps the competition-format test fallback


def _e12_branch_done_r6(rec):   # rev 6: a branch reports every pause and its finish; keep the latest per branch
    with _E12_LOCK:
        rows = E12_RECORDS.setdefault(rec["task_id"], [])
        # rev 6g H7-1 (GPT rev 6f audits): callbacks can finish out of order; never let an older record replace a newer one
        _old = next((r for r in rows if r.get("branch") == rec.get("branch")), None)
        if _old is not None and int(rec.get("publish_seq") or 0) <= int(_old.get("publish_seq") or 0):
            E12_RUN["stale_callbacks_dropped"] = E12_RUN.get("stale_callbacks_dropped", 0) + 1
            return
        new = rec.get("branch") not in {r.get("branch") for r in rows}
        rows[:] = [r for r in rows if r.get("branch") != rec.get("branch")] + [rec]
        E12_RUN["branches_started"] = E12_RUN.get("branches_started", 0) + int(new)
        E12_RUN["branches_done"] = sum(1 for v in E12_RECORDS.values() for r in v if r.get("status") == "done")
        E12_RUN["branches_accepted"] = sum(1 for v in E12_RECORDS.values() for r in v if r.get("accepted"))
    if time.perf_counter() >= globals().get("E15B_SOLVE_END_PC", float("inf")):
        E12_RUN["late_writes_skipped"] = E12_RUN.get("late_writes_skipped", 0) + 1     # E15B B1
        return
    try:
        e12_write_submission()
    except Exception as _e:
        print("E12 submission write failed:", repr(_e)[:200], flush=True)


def _e12_g4b_window(hidden_solve_end_sec, solve_start_sec, n_tasks, hidden_tasks=240):
    # gate 4b (user 2026-10-21): this run gets the hidden run's compute per task. H6-16: a function so the real
    # values (42,720 / 1,463 / 12 -> 2,063 s) are unit-tested, not only under the harness's 300 s cap
    per = max(0.0, float(hidden_solve_end_sec) - float(solve_start_sec)) / float(hidden_tasks)
    return per, per * int(n_tasks)


def _e12_shifted_end(end, setup_sec, hard_end):
    # SA-1 / H6-6: a commit window starts after the preflight (and nothing else runs before solving since H6-3); the end
    # moves by the setup time, never past the hard stop
    return min(float(hard_end), float(end) + max(0.0, float(setup_sec)))


def _e15b_gen_tokens_total():
    # E15B #32: the server's own generated-token counter, to count tokens the report misses. B6 (auditor 2 F6): max over
    # the TP ranks of each label set, summed over the other label rows (e.g. is_streaming)
    try:
        import re as _re
        _g = {}
        for r in e11_prom():
            if getattr(r, "name", "") == "sglang:generation_tokens_total" and getattr(r, "value", None) is not None:
                _k = _re.sub(r'tp_rank="[^"]*",?', "", str(getattr(r, "labels", "") or ""))
                _g[_k] = max(_g.get(_k, 0.0), float(r.value))
        return sum(_g.values()) if _g else None
    except Exception:
        return None


def _e15b_all_server_logs():
    # B6 (auditor 2 F6, auditor 3 L85 / L125): every server log of the solve (the crashed ones first), not only the last
    _t = []
    for _p in ((E12_RUN.get("watchdog") or {}).get("old_logs") or []):
        try:
            _t.append(Path(_p).read_text(encoding="utf-8", errors="replace"))
        except Exception:
            pass
    try:
        _t.append(E11_SERVER.log_text())
    except Exception:
        pass
    return "\n".join(_t)


def _e15b_server_log_summary(text):
    # E15B #42 / #53: the engine block from the server log: running-level histogram of the decode lines, queue > 0
    # share, gen throughput, retract / preempt lines (server_args excluded), OOM / Traceback
    import re as _re
    _hist, _q, _tp, _n, _hq, _acc, _tpl = {}, 0, [], 0, {}, [], {}
    for _l in text.splitlines():
        if "Decode batch" not in _l:
            continue
        _m = _re.search(r"#running-req: (\d+)", _l)
        _mq = _re.search(r"#queue-req: (\d+)", _l)
        _mt = _re.search(r"gen throughput \(token/s\): ([\d.]+)", _l)
        if _m:
            _n += 1
            _hist[int(_m.group(1))] = _hist.get(int(_m.group(1)), 0) + 1
            if _mq and int(_mq.group(1)) > 0:     # A1 (Notes/07): the running level while requests wait in the server
                _q += 1
                _hq[int(_m.group(1))] = _hq.get(int(_m.group(1)), 0) + 1
            if _mt:
                _tp.append(float(_mt.group(1)))
                _tpl.setdefault(int(_m.group(1)), []).append(float(_mt.group(1)))     # B6: tok/s per running level
            _ma = _re.search(r"accept len: ([\d.]+)", _l)
            if _ma:
                _acc.append(float(_ma.group(1)))
    _bad = lambda k: sum(1 for _l in text.splitlines() if k in _l.lower() and "server_args" not in _l.lower()
                         and "retraction_policy" not in _l)
    _tp.sort()
    # A3 (Notes/07): the startup split from TP0's lines (weight loads, each CUDA graph capture, KV pool, log start -> ready)
    import datetime as _dt
    _st = {"load_sec": {}, "graph_capture": {}, "kv_tokens": None, "ready_span_sec": None}

    def _ts(_l):
        _m = _re.match(r"\[(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d)", _l)
        return _dt.datetime.strptime(_m.group(1), "%Y-%m-%d %H:%M:%S") if _m else None
    _t_first = _t_ready = None
    for _l in text.splitlines():
        _t = _ts(_l)
        if _t is not None and _t_first is None:
            _t_first = _t
        if "The server is fired up and ready to roll" in _l and _t is not None and _t_ready is None:
            _t_ready = _t
        if "TP0]" not in _l:
            continue
        _m = _re.search(r"Load weight end\. elapsed=([\d.]+) s, type=(\w+)", _l)
        if _m:
            _st["load_sec"][_m.group(2)] = float(_m.group(1))
        _m = _re.search(r"Capture (.+?) CUDA graph end\. elapsed=([\d.]+) s, mem usage=([\d.]+) GB, avail mem=([\d.]+) GB", _l)
        if _m:
            _st["graph_capture"][_m.group(1)] = {"sec": float(_m.group(2)), "mem_gb": float(_m.group(3)),
                                                 "avail_gb_after": float(_m.group(4))}
        _m = _re.search(r"KV Cache is allocated\. dtype: \S+, #tokens: (\d+)", _l)
        if _m and _st["kv_tokens"] is None:
            _st["kv_tokens"] = int(_m.group(1))
    if _t_first is not None and _t_ready is not None:
        _st["ready_span_sec"] = (_t_ready - _t_first).total_seconds()
    _st["graph_capture_sec_total"] = round(sum(v["sec"] for v in _st["graph_capture"].values()), 2)
    return {"decode_lines": _n, "running_hist": dict(sorted(_hist.items())),
            "running_hist_queue_gt0": dict(sorted(_hq.items())), "startup": _st,
            "accept_len_p50": sorted(_acc)[len(_acc) // 2] if _acc else None,
            "gen_tok_s_p50_by_running": {k: sorted(v)[len(v) // 2] for k, v in sorted(_tpl.items())},
            "running_mean_lines": round(sum(k * v for k, v in _hist.items()) / _n, 2) if _n else None,
            "queue_gt0_line_share": round(_q / _n, 3) if _n else None,
            "gen_tok_s_p50": _tp[len(_tp) // 2] if _tp else None,
            "retract_lines": _bad("retract"), "preempt_lines": _bad("preempt"), "oom_lines": _bad("out of memory"),
            "traceback_lines": sum(1 for _l in text.splitlines() if "Traceback" in _l)}


def _e12_capacity_probe():   # rev 6e G4-1: exact names; the max over TP ranks; never sglang:token_usage (max of pools)
    try:
        rows = [r for r in e11_prom() if getattr(r, "value", None) is not None]
    except Exception:
        rows = []
    pick = lambda name: [float(r.value) for r in rows if r.name == name]
    out = {}
    for key, name in (("kv_usage", "sglang:full_token_usage"), ("mamba_usage", "sglang:mamba_usage"),
                      ("running", "sglang:num_running_reqs"), ("queue", "sglang:num_queue_reqs")):
        v = pick(name)
        out[key] = max(v) if v else None
    return out


def _e12_cache_diag(budget_sec=240.0):
    # rev 6e G4-8 (GPT G4B audits): a bounded exact-prompt replay for the prefix-cache misses (G4B: 20/180 requests with
    # 0 cached tokens while KV <= 0.44; suspects SGLang #22935 split 0-hit and #36935 mamba checkpoint eviction).
    # Prompt A (about 9k tokens) warm -> exact replay -> two divergent suffixes -> 12 distinct long prompts at once
    # (churn) -> replay and a divergent suffix again. max_tokens 1, thinking off. Commit mode only.
    import random as _rnd, concurrent.futures as _cf
    t_end = time.monotonic() + float(budget_sec)

    def _blob(seed, rows=150):
        r = _rnd.Random(seed)
        return "\n".join(" ".join(str(r.randrange(10)) for _ in range(30)) for _ in range(rows))

    def _ask(msgs):
        body = {"model": E12_RUN["model_id"], "max_tokens": 1, "temperature": 0.0, "messages": msgs,
                "chat_template_kwargs": {"enable_thinking": False}}
        t0 = time.monotonic()
        req = _urlreq.Request(SGL_URL + "/v1/chat/completions", data=json.dumps(body).encode("utf-8"),
                              headers={"Content-Type": "application/json"})
        r = json.loads(_urlreq.urlopen(req, timeout=max(5.0, t_end - time.monotonic())).read())
        u = r.get("usage") or {}
        det = u.get("prompt_tokens_details") if isinstance(u.get("prompt_tokens_details"), dict) else {}
        return {"prompt": u.get("prompt_tokens"), "cached": int(det.get("cached_tokens") or 0),
                "cached_reported": "cached_tokens" in det, "sec": round(time.monotonic() - t0, 2)}

    A = {"role": "system", "content": "E12-CACHE-DIAG reference A\n" + _blob(1)}
    q = lambda text: {"role": "user", "content": text}
    steps = []

    def step(name, msgs):
        if time.monotonic() > t_end - 5:
            steps.append({"step": name, "skipped": "budget"})
            return
        try:
            res = _ask(msgs)
        except Exception as _e:
            res = {"error": repr(_e)[:200]}
        res["step"] = name
        res.update({"g_" + k: v for k, v in _e12_capacity_probe().items()})
        steps.append(res)
    step("warm", [A, q("Reply with one word.")])
    step("replay_exact", [A, q("Reply with one word.")])
    step("divergent_1", [A, q("Divergent continuation one. Reply with one word.")])
    step("divergent_2", [A, q("Divergent continuation two. Reply with one word.")])
    if time.monotonic() < t_end - 30:
        churn = [[{"role": "system", "content": f"E12-CACHE-DIAG churn {i}\n" + _blob(100 + i)}, q("Reply with one word.")]
                 for i in range(max(1, int(E12_RUN.get("streams") or 12)))]

        def _safe(m):
            try:
                return _ask(m)
            except Exception as _e:
                return {"error": repr(_e)[:120]}
        with _cf.ThreadPoolExecutor(len(churn)) as _ex:
            cr = list(_ex.map(_safe, churn))
        steps.append({"step": "churn", "n": len(cr), "errors": sum(1 for x in cr if "error" in x),
                      "prompt_sum": sum(int(x.get("prompt") or 0) for x in cr),
                      "sec_max": max((x.get("sec") or 0) for x in cr),
                      **{"g_" + k: v for k, v in _e12_capacity_probe().items()}})
    step("replay_after_churn", [A, q("Reply with one word.")])
    step("divergent_after_churn", [A, q("Divergent continuation three. Reply with one word.")])
    by = {x["step"]: x for x in steps if "prompt" in x}
    pa = (by.get("warm") or {}).get("prompt")
    out = {"budget_sec": budget_sec, "prompt_tokens_A": pa, "steps": steps,
           "summary": {k: (by[k]["cached"], by[k]["prompt"]) for k in ("warm", "replay_exact", "divergent_1", "divergent_2",
                                                                         "replay_after_churn", "divergent_after_churn")
                       if k in by}}
    print("E12 cache diag (cached, prompt):", json.dumps(out["summary"]), flush=True)
    return out


def _e12_no_spec(cmd):   # the same server command without --speculative-* (each takes one value)
    out, skip = [], False
    for x in cmd:
        if skip:
            skip = False
            continue
        if str(x).startswith("--speculative-"):
            skip = True
            continue
        out.append(x)
    return out


def _e12_parity():
    # R6-X1 target-only parity (user 2026-10-21): the rev 6 system prompt + first opener of each task, with tools, T 0,
    # one request at a time, max_tokens 2,048, thinking on and off. DFlash2 twice (control), then a relaunch without
    # speculative decoding. Judged on equality and on what Duck acts on (tool-call presence and arguments, finish).
    global E11_SERVER
    TA, _, _, wrs = E12A._import_duck()
    Agent = E12A.make_agent_class()
    probes = []
    for tid in TASK_IDS:
        ag = Agent(task=CHALLENGES[tid], task_id=tid, branch=0, view="facts", model=E12_RUN["model_id"],
                   base_url=SGL_URL + "/v1", provider="vllm")
        d = E12_OUT / f"parity_{tid}"
        d.mkdir(parents=True, exist_ok=True)
        sp = d / TA.RUNTIME_STATE_FILENAME
        wrs(sp, current_frame=None, history=[])
        for think in (True, False):
            probes.append((tid, think, {"model": E12_RUN["model_id"], "max_tokens": 2048, "temperature": 0.0, "top_p": 1.0,
                                        "messages": [{"role": "system", "content": ag._system_prompt},
                                                     {"role": "user", "content": E12A.R6_TEXT["first"] + E12A.R6_COMPLETE}],
                                        "tools": ag._tools(sp), "tool_choice": "auto",
                                        "chat_template_kwargs": {"preserve_thinking": True, "enable_thinking": think}}))

    def _ask(body):
        req = _urlreq.Request(SGL_URL + "/v1/chat/completions", data=json.dumps(body).encode("utf-8"),
                              headers={"Content-Type": "application/json"})
        r = json.loads(_urlreq.urlopen(req, timeout=900).read())
        m = r["choices"][0]["message"]
        return {"reasoning": str(m.get("reasoning_content") or ""), "content": str(m.get("content") or ""),
                "calls": [str((tc.get("function") or {}).get("arguments", "")) for tc in (m.get("tool_calls") or [])],
                "finish": r["choices"][0].get("finish_reason"), "tokens": (r.get("usage") or {}).get("completion_tokens")}

    def _round(tag):
        rows = []
        for tid, think, body in probes:
            try:
                rows.append(_ask(body))
            except Exception as _e:
                rows.append({"error": repr(_e)[:300]})
        (E12_OUT / f"parity_{tag}.json").write_text(json.dumps(rows), encoding="utf-8")
        return rows
    out = {"probes": [{"task": t, "thinking": k} for t, k, _ in probes]}
    a, b = _round("dflash_a"), _round("dflash_b")
    try:
        cmd, env = list(E11_SERVER.cmd), E11_SERVER.env
        e11_kill_server(wait=True)
        srv = E11Server(_e12_no_spec(cmd), env, "target_only")
        srv.start()
        ok, why = srv.wait_ready(min(SGL_RELAUNCH_TIMEOUT_SEC, max(60, HARD_STOP - time.perf_counter() - 600)))
        E11_SERVER = srv
        out["target_only_launch"] = {"ok": ok, "why": why, "spec_flags_removed": [x for x in cmd if str(x).startswith("--speculative-")]}
        t = _round("target_only") if ok else [{"error": "target-only launch failed"} for _ in probes]
    except Exception as _e:
        out["target_only_launch"] = {"ok": False, "why": repr(_e)[:300]}
        t = [{"error": "target-only launch failed"} for _ in probes]

    def _pre(x, y):
        n = 0
        for c1, c2 in zip(x, y):
            if c1 != c2:
                break
            n += 1
        return n
    cmp_ = []
    for (tid, think, _), ra, rb, rt in zip(probes, a, b, t):
        row = {"task": tid, "thinking": think}
        if "error" not in ra and "error" not in rb:
            row["control_identical"] = ra == rb
        if "error" not in ra and "error" not in rt:
            ta, tt = ra["reasoning"] + ra["content"], rt["reasoning"] + rt["content"]
            row.update(target_identical=ra == rt, common_prefix_chars=_pre(ta, tt), dflash_chars=len(ta), target_chars=len(tt),
                       same_tool_call_presence=bool(ra["calls"]) == bool(rt["calls"]), same_tool_args=ra["calls"] == rt["calls"],
                       same_finish=ra["finish"] == rt["finish"], dflash_tokens=ra["tokens"], target_tokens=rt["tokens"])
        cmp_.append(row)
    out["compare"] = cmp_
    ok_rows = [r for r in cmp_ if "target_identical" in r]
    out["summary"] = {"probes": len(cmp_), "control_identical": sum(1 for r in cmp_ if r.get("control_identical")),
                      "target_identical": sum(1 for r in ok_rows if r["target_identical"]),
                      "same_tool_call_presence": sum(1 for r in ok_rows if r["same_tool_call_presence"]),
                      "same_finish": sum(1 for r in ok_rows if r["same_finish"]), "compared": len(ok_rows)}
    print("E12 parity:", json.dumps(out["summary"]), flush=True)
    return out


def _e12_r6_preflight(n):
    # R6-X1 (bounded, inside this session): the drafter's tap-layer config (SGLang #37475) and an isolation smoke for
    # #36548 (n concurrent requests with distinct markers; a marker in another request's reply = contamination).
    out = {}
    try:
        _cfg = json.loads((SGL_DRAFT_PATH / "config.json").read_text(encoding="utf-8"))
        _flat = dict(_cfg)
        for _v in list(_cfg.values()):
            if isinstance(_v, dict):
                _flat.update(_v)
        out["drafter_target_layer_config"] = {k: v for k, v in _flat.items() if "layer" in k.lower()
                                              and ("target" in k.lower() or "tap" in k.lower())}
    except Exception as _e:
        out["drafter_config_error"] = repr(_e)[:200]
    try:
        import concurrent.futures as _cf, random as _rnd
        marks = ["ZQ" + str(_rnd.randrange(10 ** 6, 10 ** 7)) + "K" + str(i) for i in range(n)]

        def _one(m):
            body = {"model": E12_RUN["model_id"], "max_tokens": 24, "temperature": 0.0,
                    "messages": [{"role": "user", "content": "Reply with exactly this code and nothing else: " + m}],
                    "chat_template_kwargs": {"enable_thinking": False}}
            req = _urlreq.Request(SGL_URL + "/v1/chat/completions", data=json.dumps(body).encode("utf-8"),
                                  headers={"Content-Type": "application/json"})
            r = json.loads(_urlreq.urlopen(req, timeout=180).read())
            return str(r["choices"][0]["message"].get("content") or "")
        with _cf.ThreadPoolExecutor(n) as _ex:
            replies = list(_ex.map(_one, marks))
        out.update(E12A.isolation_verdict(marks, replies))     # C6-2: PASS / FAIL / INCONCLUSIVE
    except Exception as _e:
        out.update(isolation_error=repr(_e)[:300], isolation_state="INCONCLUSIVE", isolation_ok=None)
    try:   # R6-X1 parity CONTROL: the same request twice at T 0, one at a time; equal replies = a deterministic baseline.
        # A target-only (no DFlash) comparison needs a separate server launch and is never run beside production.
        pc = []
        for _m in ("PARITY-A-" + str(n), "PARITY-B-" + str(n)):
            _a, _b = _one(_m), _one(_m)
            pc.append({"same": _a == _b, "own_marker": _m in _a})
        out["parity_control"] = {"pairs": len(pc), "identical": sum(x["same"] for x in pc),
                                 "own_marker": sum(x["own_marker"] for x in pc),
                                 "note": "same config, batch size 1, T 0; target-only parity = separate launch (not run)"}
    except Exception as _e:
        out["parity_control"] = {"error": repr(_e)[:300]}
    print("E12 rev 6 preflight:", json.dumps(out)[:800], flush=True)
    return out


def _e12_branch_done(rec):
    with _E12_LOCK:
        E12_RECORDS.setdefault(rec["task_id"], []).append(rec)
        E12_RUN["branches_done"] += 1
        E12_RUN["branches_accepted"] += int(bool(rec.get("accepted")))
    try:
        e12_write_submission()
    except Exception as _e:
        print("E12 submission write failed:", repr(_e)[:200], flush=True)


_E12_STOP = threading.Event()


def _e12_heartbeat(every=300):
    while not _E12_STOP.wait(every):
        snap = {r.get("name"): r.get("value") for r in metrics_snapshot() if isinstance(r, dict) and "name" in r}
        keep = {k: v for k, v in snap.items() if any(s in k for s in ("num_running_reqs", "num_queue_reqs", "gen_throughput",
                                                                        "token_usage", "cache_hit_rate"))}
        print(f"E12 [{(time.perf_counter() - NOTEBOOK_T0) / 60:.0f} min] branches done {E12_RUN['branches_done']}"
              f"/{len(TASK_IDS) * E12_BRANCHES}, accepted {E12_RUN['branches_accepted']} | {json.dumps(keep)[:400]}", flush=True)


if ENGINE_READY and E10_SANDBOX_SELFTEST.get("ok"):
    try:
        try:
            E12_RUN["model_id"] = json.loads(_urlreq.urlopen(SGL_URL + "/v1/models", timeout=30).read())["data"][0]["id"]
        except Exception as _e:
            E12_RUN["model_id"] = str(SGL_MODEL_PATH)
            print("E12: /v1/models failed, using the model path:", repr(_e)[:200], flush=True)
        E12_RUN["streams"] = min(int(CONCURRENCY), E12_STREAMS or int(CONCURRENCY))
        os.environ["ARC3_MAX_ACTIVE_STREAMS"] = str(E12_RUN["streams"])
        _end = HARD_STOP - E12_STOP_BEFORE_HARD_SEC
        if E12_SOLVE_WINDOW_SEC:
            _end = min(_end, time.perf_counter() + E12_SOLVE_WINDOW_SEC)
        if P.get("hidden_equiv"):   # gate 4b (user 2026-10-21): this run gets the hidden run's compute per task
            _ra = PROFILE_TABLE["RERUN_ALL"]
            _hid_end = _ra["time_budget_sec"] - _ra["hard_margin_sec"] - E12_STOP_BEFORE_HARD_SEC
            _start = time.perf_counter() - NOTEBOOK_T0
            _per, _ = _e12_g4b_window(_hid_end, _start, len(TASK_IDS))          # hidden test = 240 tasks
            E12_RUN["g4b"] = {"hidden_solve_end_sec": _hid_end, "solve_start_sec": round(_start), "hidden_tasks": 240,
                              "sec_per_task": round(_per, 1), "tasks": len(TASK_IDS), "window_sec": round(_per * len(TASK_IDS))}
            _end = min(_end, time.perf_counter() + _per * len(TASK_IDS))
            print("E12 gate 4b:", json.dumps(E12_RUN["g4b"]), flush=True)
        E12_RUN["deadline_in_sec"] = round(_end - time.perf_counter())
        E12_RUN["started_sec"] = round(time.perf_counter() - NOTEBOOK_T0)
        print("E12 solving:", len(E12_ORDER), "tasks x", E12_BRANCHES, "branches | streams", E12_RUN["streams"],
              "| model", E12_RUN["model_id"], "| stops in", E12_RUN["deadline_in_sec"], "s | order head", E12_ORDER[:5], flush=True)
        threading.Thread(target=_e12_heartbeat, daemon=True).start()
        # rev 6 R6-S5 (GPT plan review 2): per-stream allowance = 90 % of the KV pool / streams, so 10 resident histories
        # plus their reply reserve fit; the reserve itself follows each request's cap (R6-D1)
        _kv = int(ENGINE_INFO.get("kv_tokens") or 866744)
        E12_RUN["rev6_kv_tokens"] = _kv
        # E15B #46 (Exp 15 Notes/02): a FIXED window, not KV / streams (16 streams -> ~54k would trim earlier than rev 6g);
        # an attempt's history stays <= ~50k, the KV admission gate (0.95) covers memory
        E12_RUN["rev6_window"] = min(131072, int(E15B["E12_B_WINDOW"]))
        os.environ["E12_DUCK_CONTEXT_WINDOW"] = str(E12_RUN["rev6_window"])
        E12_RUN["rev6_preflight"] = _e12_r6_preflight(E12_RUN["streams"])
        if E12_RUN["rev6_preflight"].get("isolation_state") == "INCONCLUSIVE":
            # H6-17 (GPT rev 6e audit 3; user 2026-10-22): a missing marker without a leak is retried once before the
            # 6-stream fail-safe; a FAIL never is
            _first = E12_RUN["rev6_preflight"]
            E12_RUN["rev6_preflight"] = _e12_r6_preflight(E12_RUN["streams"])
            E12_RUN["rev6_preflight"]["retry_of"] = {k: _first.get(k) for k in ("isolation_state", "isolation_own_marker",
                                                                                  "isolation_leaks")}
        # C6-2 (rev 6c audits): full concurrency only on an isolation PASS; FAIL / INCONCLUSIVE / error -> 6 streams
        _workers = E12A.workers_for_isolation(E12_RUN["rev6_preflight"].get("isolation_ok"), E12_RUN["streams"])
        if E12_RUN["rev6_preflight"].get("isolation_state") != "PASS":
            print("E12 rev 6 WARNING: isolation preflight", E12_RUN["rev6_preflight"].get("isolation_state"),
                  "-> workers", _workers, flush=True)
        E12_RUN["rev6_workers"] = _workers
        print("E12 rev 6: window", E12_RUN["rev6_window"], "| workers", _workers, "| first exposure",
              E12_R6["E12_R6_FIRST_EXPOSURE"], "| branch 1 view", E12_R6["E12_R6_B1_VIEW"], flush=True)
        if not RERUN and (E12_SOLVE_WINDOW_SEC or (P.get("hidden_equiv") and E12_RUN.get("g4b"))):
            # SA-1 + H6-6 (GPT rev 6e audit 2): every commit window (gate 4b and the plain solve window) starts after the
            # preflight, bounded by the hard stop; the per-task compute of gate 4b stays the hidden run's. The hidden
            # rerun keeps its absolute end (no window). H6-3: nothing else runs before solving
            _shift = (time.perf_counter() - NOTEBOOK_T0) - E12_RUN["started_sec"]     # started_sec: set when _end was fixed
            _end = _e12_shifted_end(_end, _shift, HARD_STOP - E12_STOP_BEFORE_HARD_SEC)
            E12_RUN["window_shift"] = {"shift_sec": round(_shift, 1),
                                       "window_start_sec": round(time.perf_counter() - NOTEBOOK_T0)}
            if E12_RUN.get("g4b"):
                E12_RUN["g4b"].update(window_start_sec=E12_RUN["window_shift"]["window_start_sec"], shift_sec=round(_shift, 1))
            E12_RUN["deadline_in_sec"] = round(_end - time.perf_counter())
            print("E12: the solve window starts after the preflight (shift", round(_shift, 1), "s), stops in",
                  E12_RUN["deadline_in_sec"], "s", flush=True)
        # E15B #15 (code audit H1): a server watchdog for the solve. A dead SGLang process (or /health failing for
        # 180 s) is relaunched with the same command (at most 2 times, only with >= 20 min left); while it is down the
        # branches wait (arc2_duck.SERVER_DOWN) instead of burning their consecutive-failure budget.
        E12_RUN["watchdog"] = {"relaunches": [], "health_fail_sec_max": 0, "old_logs": [], "tok_acc": 0.0, "tok_last": None,
                               "health_probes": 0}
        _e15b_solve_end = time.perf_counter() + max(0.0, _end - time.perf_counter())
        E15B_SOLVE_END_PC = _e15b_solve_end       # B1: per-branch submission writes stop here (the final write stays)
        _e15b_tok0 = _e15b_gen_tokens_total()
        E12_RUN["watchdog"]["tok_base"] = _e15b_tok0

        # A7 (Notes/07): the limits come from env only for the CPU harness's fault test; Kaggle uses the defaults
        _WD_POLL = float(os.environ.get("E15B_WD_POLL_SEC", "10"))
        _WD_FAIL = float(os.environ.get("E15B_WD_FAIL_SEC", "180"))
        _WD_MIN_LEFT = float(os.environ.get("E15B_WD_MIN_LEFT_SEC", str(20 * 60)))
        E12_RUN["watchdog"]["limits"] = {"poll_sec": _WD_POLL, "fail_sec": _WD_FAIL, "min_left_sec": _WD_MIN_LEFT}

        def _e15b_watchdog():
            global E11_SERVER, SGL_MAX_RUNNING, SGL_SERVER_MAX_RUNNING
            _bad, _sz_last = None, {}
            _wd = E12_RUN["watchdog"]
            while not _E12_STOP.wait(_WD_POLL):
                _srv = E11_SERVER
                _dead = _srv is None or not _srv.alive()
                if not _dead:
                    _tk = _e15b_gen_tokens_total()      # B6: the last counter value of THIS server (it resets on relaunch)
                    if _tk is not None:
                        _wd["tok_last"] = _tk
                    try:     # B2 (auditor 2 F2 / F8): a growing server log = alive (a prefill storm logs batches, decode
                        _sz = os.path.getsize(_srv.log_path)     # logs every 40 steps); /health only when it is silent
                    except Exception:
                        _sz = None
                    if _sz is not None and _sz != _sz_last.get(id(_srv)):
                        _sz_last[id(_srv)] = _sz
                        _bad = None
                        continue
                    try:
                        _wd["health_probes"] += 1
                        _urlreq.urlopen(SGL_URL + "/health", timeout=10).read()
                        _bad = None
                        continue
                    except Exception:
                        _bad = _bad or time.monotonic()
                        E12_RUN["watchdog"]["health_fail_sec_max"] = max(E12_RUN["watchdog"]["health_fail_sec_max"],
                                                                         round(time.monotonic() - _bad))
                        if time.monotonic() - _bad < _WD_FAIL:
                            continue
                _left = _e15b_solve_end - time.perf_counter()
                _rec = {"t": round(time.perf_counter() - NOTEBOOK_T0), "dead": _dead, "left_sec": round(_left)}
                if len(E12_RUN["watchdog"]["relaunches"]) >= 2 or _left < _WD_MIN_LEFT:
                    _rec["action"] = "none (limit or < 20 min left)"
                    E12_RUN["watchdog"]["relaunches"].append(_rec)
                    print("E15B watchdog: server down, no relaunch:", json.dumps(_rec), flush=True)
                    return
                E12A.SERVER_DOWN.set()
                print("E15B watchdog: server down -> relaunch", json.dumps(_rec), flush=True)
                try:
                    try:
                        _tail = _srv.log_text()[-20000:].lower()
                    except Exception:
                        _tail = ""
                    try:
                        _srv.kill()
                    except Exception:
                        pass
                    _wd["old_logs"].append(str(_srv.log_path))
                    if _wd.get("tok_last") is not None and _wd.get("tok_base") is not None:   # B6
                        _wd["tok_acc"] += max(0.0, _wd["tok_last"] - _wd["tok_base"])
                    _wd["tok_base"], _wd["tok_last"] = 0.0, None
                    _e11_gpu_free()
                    # B3 (auditor 2 F3, auditor 3 R1): a 16-stream-specific crash (OOM / RuntimeError) or a second relaunch
                    # -> the 12-stream flags (the clients then queue up to 4 requests at the server)
                    _cfg0 = dict(E14_VENV.get("cfg") or {})
                    _cmd = list(_srv.cmd)
                    if (any(k in _tail for k in E11_OOM_MARKERS) or "runtimeerror" in _tail or _wd["relaunches"]) \
                            and _cfg0 and not _cfg0.get("streams12") and not _cfg0.get("w1") and E14_VENV.get("launch"):
                        _cfg1 = dict(_cfg0, streams12=True, mamba_cache=56)
                        SGL_MAX_RUNNING, SGL_SERVER_MAX_RUNNING = 12, 13
                        _cmd = list(E14_VENV["launch"]) + e11_flags(_cfg1)
                        E14_VENV["cfg"] = _cfg1
                        _rec["streams12"] = True
                    _new = E11Server(_cmd, _srv.env, f"relaunch{len(E12_RUN['watchdog']['relaunches'])}")
                    _new.start()
                    _ok, _why = _new.wait_ready(min(SGL_RELAUNCH_TIMEOUT_SEC, max(60.0, _left - _WD_MIN_LEFT / 2)))
                    _rec.update(ok=_ok, why=_why)
                    if _ok:
                        E11_SERVER = _new
                    else:
                        _new.kill()
                except Exception as _e:
                    _rec.update(ok=False, why=repr(_e)[:300])
                finally:
                    E12A.SERVER_DOWN.clear()
                    E12_RUN["watchdog"]["relaunches"].append(_rec)
                    _bad = None
                print("E15B watchdog:", json.dumps(_rec), flush=True)
                if not _rec.get("ok") and len(_wd["relaunches"]) >= 2:    # B3: a failed relaunch retries once
                    return
        threading.Thread(target=_e15b_watchdog, daemon=True, name="e15b_watchdog").start()
        if P.get("parity"):          # R6-X1 diagnostic profile: no solving (the fallback submission stays)
            E12_RUN["parity"] = _e12_parity()
        else:
          E12A.solve_all_r6({t: CHALLENGES[t] for t in E12_ORDER}, E12_ORDER, out_dir=E12_OUT,
                          deadline=time.monotonic() + max(0.0, _end - time.perf_counter()), base_url=SGL_URL + "/v1",
                          model_id=E12_RUN["model_id"], branches=E12_BRANCHES, max_generated_tokens=E12_MAX_GEN_PER_BRANCH,
                          save_request_logs=E12_REQUEST_LOGS, on_branch_done=_e12_branch_done_r6, workers=_workers,
                          first_exposure_tokens=E12_R6["E12_R6_FIRST_EXPOSURE"] or None, b1_view=E12_R6["E12_R6_B1_VIEW"],
                          min_admit_sec=E12_R6["E12_R6_MIN_ADMIT_SEC"], capacity_probe=_e12_capacity_probe,
                          kv_admit_limit=E12_R6["E12_R6_KV_ADMIT"], kv_poll_sec=E12_R6["E12_R6_KV_POLL"],
                          min_chunk_tokens=E12_R6["E12_R6_MIN_CHUNK"],
                          fair_share=bool(E12_R6["E12_R6_FAIR_SHARE"]),
                          stage2_p90_cutoff=bool(E12_R6["E12_R6_P90_CUTOFF"]),
                          join_grace_sec=90.0,       # E15B #54: room for the final harvest / partial test (30 s grace)
                          max_generated_tokens_b1=E15B["E12_B_ATTEMPT_TOKENS_B1"],
                          skip_b1_if_accepted=bool(E15B["E12_B_SKIP_B1_IF_ACCEPTED"]),     # rev 3i: R
                          extra_attempts=bool(E15B["E12_B_EXTRA_ATTEMPTS"]),               # rev 3i: stage 3
                          max_attempts=int(E15B["E12_B_MAX_ATTEMPTS"]),
                          # rev 3j: 1 = after the attempt 3s (notebook 1), 2 = before the attempt 3s (notebook 2)
                          b1_accepted_mode={1: "after3", 2: "before3"}[int(E15B["E12_B_B1_ACC_MODE"])],
                          weak_commit=bool(E15B["E12_B_WEAK_COMMIT"]))    # rev 3f: attempt 2's session cap
        E12_RUN["rev6_scheduler"] = dict(E12A.SCHED_LAST)
        try:      # E15B #29, #30, #39: per-attempt summary + real concurrency from the 30-s server gauges
            _att = [r for v in E12_RECORDS.values() for r in v]
            _ev = [r.get("b_events") or {} for r in _att]
            # rev 3f: each attempt's own budget (attempt 1 = E12_B_ATTEMPT_TOKENS, attempt 2 = E12_B_ATTEMPT_TOKENS_B1)
            _bud = lambda r: int(E15B["E12_B_ATTEMPT_TOKENS_B1"] if r.get("branch") >= 1 else E15B["E12_B_ATTEMPT_TOKENS"])
            _g = [x for x in (E12_RUN["rev6_scheduler"].get("gauges") or []) if isinstance(x, list) and len(x) >= 5
                  and isinstance(x[3], (int, float))]
            _run = [x[3] for x in _g]
            _q = [x[4] for x in _g if isinstance(x[4], (int, float))]
            # A1 (Notes/07): the 30-s samples in which every client stream was busy (workers_running >= streams)
            _S = E12_RUN.get("streams") or 0
            _full = [x for x in _g if len(x) >= 6 and isinstance(x[5], (int, float)) and _S and x[5] >= _S]
            E12_RUN["b_summary"] = {
                "attempts": len(_att), "attempt2_started": sum(1 for r in _att if r.get("branch") == 1),
                "accepted": sum(1 for r in _att if r.get("accepted")),
                "at_budget": sum(1 for r in _att if int(r.get("generated_tokens") or 0) >= _bud(r) - 64),
                # no host-accepted candidate at all (an accepted exact check counts too), but a transform was written
                "at_budget_with_progress": sum(1 for r in _att if int(r.get("generated_tokens") or 0)
                                               >= _bud(r) - 64
                                               and not any(x.get("accepted") for x in (r.get("submissions") or [])
                                                           + (r.get("checked") or []))
                                               and ((r.get("rev6_events") or {}).get("first_transform_tokens") is not None)),
                "commit_turns": sum(1 for e in _ev if e.get("commit_at_tokens") is not None),
                "commit_with_tool_call": sum(1 for e in _ev if e.get("commit_tool_call")),
                "submit_tool_routed": sum(int(e.get("submit_tool_routed") or 0) for e in _ev),
                "reasoning_harvest_ran": sum(1 for e in _ev if (e.get("reasoning_harvest") or {}).get("ran")),
                "reasoning_harvest_new_accepted": sum(int((e.get("reasoning_harvest") or {}).get("new_accepted") or 0) for e in _ev),
                "trimmed_requests": sum(1 for r in _att for q in (r.get("requests") or []) if q.get("trimmed")),
                "worker_errors": E12_RUN["rev6_scheduler"].get("worker_errors"),
                "setup_failed": E12_RUN["rev6_scheduler"].get("setup_failed"),     # rev 3h: Auditor 4 #4
                "cut_code_saved": sum(int(e.get("cut_code_saved") or 0) for e in _ev),     # rev 3h
                "cut_code_harvested": sum(1 for e in _ev if (e.get("reasoning_harvest") or {}).get("cut_code_blocks")),
                # rev 3i: R + stage 3
                "b1_skipped": E12_RUN["rev6_scheduler"].get("b1_skipped"),
                "extra_started": E12_RUN["rev6_scheduler"].get("extra_started"),
                "extra_by_attempt": E12_RUN["rev6_scheduler"].get("extra_by_attempt"),
                "extra_accepted": sum(1 for r in _att if int(r.get("branch") or 0) >= 2 and r.get("accepted")),
                "b1_deferred": E12_RUN["rev6_scheduler"].get("b1_deferred"),                 # rev 3j
                "b1_deferred_started": E12_RUN["rev6_scheduler"].get("b1_deferred_started"),
                "weak_accepts": E12_RUN["rev6_scheduler"].get("weak_accepts"),               # rev 3k W1
                "weak_only_tasks_continued": E12_RUN["rev6_scheduler"].get("weak_only_tasks_continued"),
                "stage2_errors": E12_RUN["rev6_scheduler"].get("stage2_errors"),
                "server_running_mean": round(sum(_run) / len(_run), 2) if _run else None,
                "server_queue_gt0_share": round(sum(1 for v in _q if v > 0) / len(_q), 3) if _q else None,
                "gauge_samples": len(_g), "streams": E12_RUN.get("streams"),
                "client_full_samples": len(_full),
                "server_running_mean_client_full": round(sum(x[3] for x in _full) / len(_full), 2) if _full else None,
                "server_at_streams_share_client_full": (round(sum(1 for x in _full if x[3] >= _S) / len(_full), 3)
                                                        if _full else None),
                "kv_stale_checks": E12_RUN["rev6_scheduler"].get("kv_stale_checks"),      # A4
                # #34: accepted submissions vs harvested exact checks; #31 roll-up; #35 the effort actually sent
                "accepted_submit": sum(int((r.get("b_candidate") or {}).get("submitted_accepted") or 0) > 0 for r in _att),
                "harvested_only": sum(1 for r in _att if int((r.get("b_candidate") or {}).get("harvested") or 0) > 0
                                      and not int((r.get("b_candidate") or {}).get("submitted_accepted") or 0)),
                "never_wrote_candidate": sum(1 for r in _att if not (r.get("b_candidate") or {}).get("candidate_source_written")),
                "wrote_never_checked": sum(1 for r in _att if (r.get("b_candidate") or {}).get("candidate_source_written")
                                           and not (r.get("b_candidate") or {}).get("check_executed")),
                "partial_test_runs": sum(1 for e in _ev if (e.get("partial_test") or {}).get("name")),
                "effective_effort": E12_REASONING_EFFORT or "xhigh (template default)",
                # #32: server-side generated tokens in the solve vs the attempts' count
                # B6: per server (the counter resets on a relaunch): the finished servers' deltas + the current one
                "server_gen_tokens": (lambda a, b: round((E12_RUN["watchdog"].get("tok_acc") or 0.0) + a - b)
                                      if a is not None and b is not None else None)(
                    _e15b_gen_tokens_total(), E12_RUN["watchdog"].get("tok_base")),
                "counted_gen_tokens": sum(int(r.get("generated_tokens") or 0) for r in _att),
                "server_down_waits": dict(E12A.SERVER_WAITS), "watchdog": E12_RUN.get("watchdog")}
            try:
                E12_RUN["b_summary"]["server_log"] = _e15b_server_log_summary(_e15b_all_server_logs())   # #42 / #53; B6
            except Exception as _e:
                E12_RUN["b_summary"]["server_log"] = {"error": repr(_e)[:200]}
            print("E15B summary:", json.dumps(E12_RUN["b_summary"]), flush=True)
            if _run and E12_RUN["b_summary"]["server_running_mean"] < (E12_RUN.get("streams") or 0) - 0.5:
                print("E15B WARNING: mean server running", E12_RUN["b_summary"]["server_running_mean"], "< streams - 0.5",
                      flush=True)
        except Exception as _e:
            E12_RUN["b_summary"] = {"error": repr(_e)[:300]}
        # H6-3 (GPT rev 6e audits): the cache diagnostic runs AFTER solving, so the solver starts from the same server
        # state as the hidden rerun (which never runs it). Its time comes from what is left before the output margin;
        # the solve deadline never moves for it. Skipped when under 90 s are left
        if not RERUN and not P.get("parity") and E12_R6.get("E12_R6_CACHE_DIAG"):
            _left = HARD_STOP - E12_STOP_BEFORE_HARD_SEC - time.perf_counter() - 30
            if (E12_RUN.get("rev6_scheduler") or {}).get("stragglers"):      # rev 6g H7-4
                E12_RUN["cache_diag"] = {"skipped": "a solver straggler may still be sending requests"}
            elif _left >= 90:
                try:
                    E12_RUN["cache_diag"] = _e12_cache_diag(budget_sec=min(240.0, _left))
                    E12_RUN["cache_diag"]["ran"] = "after solving"
                except Exception as _e:
                    E12_RUN["cache_diag"] = {"error": repr(_e)[:300]}
            else:
                E12_RUN["cache_diag"] = {"skipped": "less than 90 s before the output margin", "left_sec": round(_left)}
    except BaseException:
        E12_RUN["error"] = traceback.format_exc()[-3000:]
        print("E12 solver error (submission.json keeps what was written):", E12_RUN["error"], flush=True)
else:
    E12_RUN["error"] = f"not run: ENGINE_READY={ENGINE_READY}, sandbox self-test={E10_SANDBOX_SELFTEST.get('ok')}"
    print("E12:", E12_RUN["error"], "-> CELL 0 fallback submission", flush=True)
_E12_STOP.set()
E12_RUN["finished_sec"] = round(time.perf_counter() - NOTEBOOK_T0)
try:
    e12_write_submission()
except Exception:
    print("E12 final submission write failed:", traceback.format_exc()[-1000:], flush=True)
