# ==================================================================== CELL 6b — E14-A2: more engine arms after the Duck run
# Plan: Notes/13. The Duck run's server was stopped by CELL 7. Phases (each its own launch): the Duck arm again with an
# agent-like replay (Mamba checkpoint eviction, E14-M) and a cache-hit parity pass; + int8 Mamba checkpoints (same
# replay + the cache-hit parity); target-only (DFlash correctness); DFlash width 6 and 4; the NCCL env arm if the bench
# found one >= 20 % faster at 983,040 B. Nothing here changes the submission.
if E14_DO_MEASURE and E14_CTX is not None:
    E14_RESERVE = 0.0
    _S = E14_PROMPTS["short"]
    _sess = [(s, u) for s, u, _t in E14_PROMPTS["duck"]] * 2
    _base_arm = dict(E14_KEPT)          # the adopted arm (the Duck may have run on another one in a failure path)

    def _cache_hit_parity(tag):
        globals()["E14_LAST_FLUSH"] = E14M.flush_cache(E14_CTX)     # review 9: these prompts were sent already
        a = E14M.parity_pass(E14_CTX, _S[:6], max_new=384, tag=tag + "_cold")
        b = E14M.parity_pass(E14_CTX, _S[:6], max_new=384, tag=tag + "_cached")
        return E14M.compare_passes(a, b, tag + ": fresh vs cached prefix")

    def _a2_reference():
        """The matched width-8 control (audit 18 E14-8): greedy rows of the arm the Duck ran, on THIS launch; every A2
        arm gate below compares with these (int8 cross-arm, target-only, widths, NCCL)."""
        a = E14M.parity_pass(E14_CTX, _S[:6], max_new=256, tag="a2ref_serial_a")
        b = E14M.parity_pass(E14_CTX, _S[:6], max_new=256, tag="a2ref_serial_b")
        c = E14M.parity_pass(E14_CTX, _S, max_new=256, concurrent=True, tag="a2ref_conc_a")
        c2 = E14M.parity_pass(E14_CTX, _S, max_new=256, concurrent=True, tag="a2ref_conc_b")
        globals()["E14_A2_REF"] = E14M.gate_reference(a, b, c, c2)
        return {"serial_aa": E14M.compare_passes(a, b, "A2 base serial A/A"),
                "conc_aa": E14M.compare_passes(c, c2, "A2 base all-at-once A/A")}

    E14_A2_REF = None
    _gate = lambda tag, identity=False: E14M.arm_gate(E14_CTX, _S, E14_A2_REF, tag="gate_" + tag, identity=identity)

    def _gated(tag, windows):
        """The gate first; the throughput windows only when it passed (correctness before speed)."""
        out = {"gate": _gate(tag)}
        if not out["gate"].get("ok"):
            out["windows_skipped"] = "the correctness gate did not pass"
            return out
        out.update(windows())
        return out
    _ok, _ = e14_launch("a2_duck_arm", set_=_base_arm["set"], drop=_base_arm["drop"], env=_base_arm["env"])
    e14_phase("A2-0_reference", _a2_reference, _ts(8 * 60)) if _ok else None
    _r0 = e14_phase("A2-1_agent_replay_default", lambda: {
        "replay": E14M.agent_replay(E14_CTX, _sess, turns=6, admit=SGL_MAX_RUNNING, tool_text=E14_PROMPTS["tool_text"],
                                    tag="default"),
        "cache_parity": _cache_hit_parity("default")}, _ts(14 * 60)) if _ok else None
    _ok, _ = e14_launch("int8_mamba", set_=dict(_base_arm["set"], **{"--enable-int8-mamba-checkpoint": None}),
                        drop=_base_arm["drop"], env=_base_arm["env"])
    _r1 = e14_phase("A2-2_int8_mamba", lambda: _gated("int8", lambda: {   # cross-arm: default vs int8, same ids
        "replay": E14M.agent_replay(E14_CTX, _sess, turns=6, admit=SGL_MAX_RUNNING, tool_text=E14_PROMPTS["tool_text"],
                                    tag="int8"),
        "cache_parity": _cache_hit_parity("int8")}), _ts(16 * 60)) if _ok else None
    try:
        _c0 = ((_r0 or {}).get("replay") or {}).get("classes") or {}
        _c1 = ((_r1 or {}).get("replay") or {}).get("classes") or {}
        _miss = lambda c: (c.get("deeper_miss", 0) + c.get("lost_at_prefill_end", 0)) / max(1, sum(c.values()))
        _pa = E14M.parity_ok((_r1 or {}).get("cache_parity"), (_r0 or {}).get("cache_parity"))
        e14_decide("int8_mamba", [("measured", bool(_r1 and _r0)),
                                  ("cross-arm correctness gate", ((_r1 or {}).get("gate") or {}).get("ok")),
                                  ("fewer cache misses", bool(_c1) and _miss(_c1) < _miss(_c0)),
                                  ("cache-hit parity", _pa["ok"]),
                                  ("no server error signs", not E14M.log_errors((_r1 or {}).get("server_log_signs")))],
                   miss_share_default=round(_miss(_c0), 3), miss_share_int8=round(_miss(_c1), 3), cache_parity=_pa,
                   gate=(_r1 or {}).get("gate"))
    except Exception as _e:
        E14_RESULTS["decisions"]["int8_mamba"] = {"adopt": False, "error": repr(_e)[:200]}

    _ok, _ = e14_launch("target_only", set_=_base_arm["set"], drop=_base_arm["drop"], env=_base_arm["env"], spec=False)
    _rt = e14_phase("A2-3_target_only", lambda: _gated("target", lambda: {
        "short": E14M.steady_window(E14_CTX, _S, level=SGL_MAX_RUNNING, secs=_ts(60), tag="tonly", spec=False)}),
        _ts(14 * 60)) if _ok else None
    E14_RESULTS["decisions"]["dflash_vs_target"] = ((_rt or {}).get("gate") or {"ok": False, "why": "not run"})

    _ref_short = E14_KEPT_WIN.get("short")      # the kept arm's window = the arm the Duck run used
    for _w in (6, 4):
        _ok, _ = e14_launch(f"width{_w}", set_=dict(_base_arm["set"], **{"--speculative-num-draft-tokens": _w}),
                            drop=_base_arm["drop"], env=_base_arm["env"])
        _rw = e14_phase({6: "A2-4_width6", 4: "A2-5_width4"}[_w], lambda w=_w: _gated(f"w{w}", lambda: {
            "short": E14M.steady_window(E14_CTX, _S, level=SGL_MAX_RUNNING, secs=_ts(75), tag=f"w{w}short")}),
            _ts(12 * 60)) if _ok else None
        _sp = E14M.adopt_speed(_ref_short, (_rw or {}).get("short"), min_gain=0.05)
        _acc = ((_rw or {}).get("short") or {}).get("accept_p50")
        e14_decide(f"width{_w}", [("measured", bool(_rw)),
                                  ("correctness gate", ((_rw or {}).get("gate") or {}).get("ok")),
                                  ("speed >= +5 %", _sp["adopt"]),
                                  ("accept <= width", _acc is not None and _acc <= _w),
                                  ("no server error signs", not E14M.log_errors((_rw or {}).get("server_log_signs")))],
                   speed=_sp, accept_p50=_acc, gate=(_rw or {}).get("gate"))
    # NCCL env arm: only if the bench found an arm >= 20 % faster per call at 983,040 B inside CUDA graphs (eager AND
    # graph results correct); adopted only with a real-window gain and a passing correctness gate (transport safety)
    _nb = (E14_RESULTS.get("nccl") or {}).get("summary") or {}
    _win = _nb.get("adopt_candidate")
    _envs = {"p2p_sys": {"NCCL_P2P_LEVEL": "SYS"}, "shm_memcpy": {"NCCL_SHM_USE_CUDA_MEMCPY": "1"}}
    if _win in _envs:
        _ok, _ = e14_launch("nccl_" + _win, set_=_base_arm["set"], drop=_base_arm["drop"],
                            env=dict(_base_arm["env"], **_envs[_win]))
        _rn = e14_phase("A2-6_nccl_" + _win, lambda: _gated("nccl", lambda: {
            "short": E14M.steady_window(E14_CTX, _S, level=SGL_MAX_RUNNING, secs=_ts(75), tag="nccl")}),
            _ts(12 * 60)) if _ok else None
        _sp = E14M.adopt_speed(_ref_short, (_rn or {}).get("short"), min_gain=0.05, per_step=True)
        e14_decide("nccl_" + _win, [("measured", bool(_rn)),
                                    ("correctness gate", ((_rn or {}).get("gate") or {}).get("ok")),
                                    ("speed >= +5 %", _sp["adopt"]),
                                    ("no server error signs", not E14M.log_errors((_rn or {}).get("server_log_signs")))],
                   speed=_sp, gate=(_rn or {}).get("gate"))
    else:
        E14_RESULTS["decisions"]["nccl_env"] = {"adopt": False, "why": "no bench arm >= 20 % faster at 983,040 B",
                                                "bench_summary": _nb}
    try:
        e11_kill_server(wait=True)
    except Exception:
        pass
    E14_STATE.enter("A2_DONE")
    e14_save()
