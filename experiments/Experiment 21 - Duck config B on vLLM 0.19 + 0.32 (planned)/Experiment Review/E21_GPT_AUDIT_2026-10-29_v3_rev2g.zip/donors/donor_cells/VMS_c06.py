import re, signal as _signal, urllib.request as _urlreq      # VMS: the helpers the dropped SGLang engine cell provided
def _e11_gpu_free(max_sec=180):
    """Wait until every GPU shows < 1 GiB used (nvidia-smi); returns the last reading."""
    t0, used = time.perf_counter(), None
    while time.perf_counter() - t0 < max_sec:
        try:
            out = subprocess.run(["nvidia-smi", "--query-gpu=memory.used", "--format=csv,noheader,nounits"],
                                 capture_output=True, text=True, timeout=30).stdout
            used = [int(x) for x in out.split() if x.strip().isdigit()]
            if used and max(used) < 1024:
                return {"free": True, "used_mb": used, "sec": round(time.perf_counter() - t0, 1)}
        except Exception:
            return {"free": None, "error": "nvidia-smi unavailable"}
        time.sleep(3)
    return {"free": False, "used_mb": used}
# ==================================================================== CELL V1 — vLLM 0.32.0 venv, launcher, measurement
import shlex, socket, statistics, threading
VMS = {"install": None, "arms": {}, "launches": [], "order": []}
E14_RESULTS["vms"] = VMS
VMS_FAKE = os.environ.get("VMS_FAKE_SERVER")          # local CPU harness only: a fake vLLM OpenAI server script
VMS_PORT = int(os.environ.get("VMS_PORT", 8011))
VMS_URL = f"http://127.0.0.1:{VMS_PORT}"
VMS_SERVER = None
VMS_DIR = OUT / "vms"
VMS_DIR.mkdir(parents=True, exist_ok=True)


def vms_install():
    """The dataset's installer (restores the '+' Kaggle drops, venv, --no-deps), then a -lcuda shim for FlashInfer JIT."""
    if VMS_FAKE:
        return {"fake": True, "launch": [sys.executable, VMS_FAKE], "env": dict(os.environ)}
    inst = next(iter(sorted(VLLM_WHEELHOUSE.rglob("install_wheelhouse.py"))), None)
    if inst is None:
        raise FileNotFoundError(f"install_wheelhouse.py not under {VLLM_WHEELHOUSE}: attach the vLLM 0.32.0 wheelhouse")
    t0 = time.perf_counter()
    r = subprocess.run([sys.executable, str(inst), "/tmp/vllm-venv"], capture_output=True, text=True, timeout=2400)
    if r.returncode != 0:
        raise RuntimeError("vLLM wheelhouse install failed: " + (r.stdout + r.stderr)[-3000:])
    kv = dict(l.split("=", 1) for l in r.stdout.splitlines() if l.startswith(("VENV_PYTHON=", "CUDA_HOME=")))
    shim = Path("/tmp/vms_libcuda")
    shim.mkdir(exist_ok=True)
    for d in ("/usr/local/nvidia/lib64", "/usr/lib/x86_64-linux-gnu", "/usr/local/cuda/compat", "/usr/lib64"):
        c = sorted(Path(d).glob("libcuda.so.1")) if Path(d).is_dir() else []
        if c and not (shim / "libcuda.so").exists():
            (shim / "libcuda.so").symlink_to(c[0])
    env = {k: v for k, v in os.environ.items() if k not in ("PYTHONPATH", "CUDA_PATH")}
    env.update(CUDA_HOME=kv["CUDA_HOME"], PATH=f"/tmp/vllm-venv/bin:{kv['CUDA_HOME']}/bin:{env.get('PATH', '')}",
               LIBRARY_PATH=f"{shim}:{env.get('LIBRARY_PATH', '')}", HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1",
               VLLM_NO_USAGE_STATS="1", VLLM_LOGGING_LEVEL="INFO", VLLM_CACHE_ROOT="/tmp/vllm-cache",
               VLLM_ALLOW_LONG_MAX_MODEL_LEN="1")
    return {"sec": round(time.perf_counter() - t0, 1), "venv_python": kv["VENV_PYTHON"],
            "launch": ["/tmp/vllm-venv/bin/vllm", "serve"], "env": env}


def vms_flags(model, *, tp=4, dp=1, seqs=16, spec=3, kv="fp8_e4m3", backend="FLASHINFER", prefix=True, mem=0.90,
              batched=4096, max_len=106496, extra=None, car_off=True):
    f = [str(model), "--tensor-parallel-size", str(tp), "--kv-cache-dtype", kv, "--max-model-len", str(max_len),
         "--max-num-seqs", str(seqs), "--max-num-batched-tokens", str(batched), "--gpu-memory-utilization", str(mem)]
    f += ["--disable-custom-all-reduce"] if car_off else []
    f += ["--seed", str(SEED), "--host", "127.0.0.1", "--port", str(VMS_PORT),
          "--served-model-name", "q27", "--attention-backend", backend, "--trust-remote-code"]
    if dp > 1:
        f += ["--data-parallel-size", str(dp)]
    f += ["--enable-prefix-caching"] if prefix else ["--no-enable-prefix-caching"]
    if spec:
        f += ["--speculative-config", json.dumps({"method": "mtp", "num_speculative_tokens": int(spec)})]
    for k, v in (extra or {}).items():
        f += [k] + ([] if v is None else [str(v)])
    return f


class VServer:
    def __init__(self, name, flags, env):
        self.name, self.log_path = name, VMS_DIR / f"vllm_server_{name}.log"
        self.cmd, self.env, self.proc = list(VMS_INST["launch"]) + list(flags), dict(env), None

    def start(self):
        self.log_f = open(self.log_path, "w", encoding="utf-8")
        self.t0 = time.perf_counter()
        self.proc = subprocess.Popen(self.cmd, env=self.env, stdout=self.log_f, stderr=subprocess.STDOUT,
                                     start_new_session=True, cwd=None if VMS_FAKE else "/tmp")

    def alive(self):
        return self.proc is not None and self.proc.poll() is None

    def log_text(self):
        try:
            return self.log_path.read_text(encoding="utf-8", errors="replace")
        except Exception:
            return ""

    def wait_ready(self, timeout):
        while time.perf_counter() - self.t0 < timeout:
            if not self.alive():
                return False, f"exited rc={self.proc.returncode}"
            try:
                _urlreq.urlopen(VMS_URL + "/health", timeout=10).read()
                return True, f"ready in {time.perf_counter() - self.t0:.0f}s"
            except Exception:
                time.sleep(3)
        return False, "timeout"

    def kill(self):
        if self.proc is None:
            return
        for sig, wait in ((_signal.SIGTERM, 30), (getattr(_signal, "SIGKILL", _signal.SIGTERM), 60)):   # rev 2b: TERM first
            try:
                if hasattr(os, "killpg"):
                    os.killpg(self.proc.pid, sig)
                else:
                    self.proc.kill()
            except Exception:
                pass
            try:
                self.proc.wait(timeout=wait)
                return
            except Exception:
                pass


def vms_prom():
    txt = _urlreq.urlopen(VMS_URL + "/metrics", timeout=15).read().decode("utf-8", "replace")
    out = {}
    for line in txt.splitlines():
        if not line or line.startswith("#"):
            continue
        m = re.match(r"^([A-Za-z_:][A-Za-z0-9_:]*)(\{[^}]*\})?\s+(\S+)", line)
        if m:
            try:
                v = float(m.group(3))
            except ValueError:
                continue
            out[m.group(1)] = out.get(m.group(1), 0.0) + v
            out[m.group(1) + "@max"] = max(out.get(m.group(1) + "@max", v), v)     # rev 2b: per-engine max (DP)
    return out


def _met(p, *names):
    return sum(p.get(n, 0.0) for n in names)


class VGen(threading.Thread):
    """One streaming /v1/completions request with prompt token ids; stop() closes the stream (vLLM aborts it).
    rev 2e (GPT audits E1, HIGH-2): integer token ids from return_token_ids (completion/protocol.py:171-180,
    serving.py:417-421; logprobs.tokens are decoded strings), the terminal [DONE] and the finish_reason recorded; a request
    we did not stop that lacks either is an error, never a valid row."""
    def __init__(self, ids, max_new, temperature=1.0, ignore_eos=True, seed=None, logprobs=0):
        super().__init__(daemon=True)
        self.body = {"model": "q27", "prompt": list(ids), "max_tokens": int(max_new), "temperature": temperature,
                     "top_p": 0.95 if temperature else 1.0, "stream": True,
                     "ignore_eos": ignore_eos, "return_token_ids": True}
        if temperature:
            self.body["top_k"] = 20          # rev 2g-b: greedy sends no top_k (temperature 0 = argmax)
        if seed is not None:
            self.body["seed"] = seed
        if logprobs:
            self.body["logprobs"] = int(logprobs)      # rev 2b: the gate compares tokens and top-1 / top-2 margins
        self.text, self.err, self._resp, self._halt = [], None, None, False   # NOT _stop: Thread._stop() is a method join() calls (Py3.12)
        self.tokens, self.margins = [], []
        self.done_seen, self.finish_reason, self.first_token_at = False, None, None

    def run(self):
        try:
            req = _urlreq.Request(VMS_URL + "/v1/completions", data=json.dumps(self.body).encode(), method="POST",
                                  headers={"Content-Type": "application/json"})
            self._resp = _urlreq.urlopen(req, timeout=3600)
            for raw in self._resp:
                if self._halt:
                    break
                line = raw.strip()
                if not line.startswith(b"data:"):
                    continue
                payload = line[5:].strip()
                if payload == b"[DONE]":
                    self.done_seen = True
                    break
                d = json.loads(payload)
                if "error" in d or d.get("object") == "error":     # rev 2b: an in-stream error event (serving.py:497-503)
                    self.err = ("stream error: " + json.dumps(d.get("error") or d.get("message") or d))[:200]
                    break
                for c in d.get("choices") or []:
                    self.text.append(c.get("text") or "")
                    ids_ = c.get("token_ids")
                    lp = c.get("logprobs") or {}
                    if ids_ is None:
                        if c.get("text") or lp.get("tokens"):
                            self.err = "MISSING_STREAM_TOKEN_IDS"
                    elif any(not isinstance(v, int) or isinstance(v, bool) for v in ids_):
                        self.err = "INVALID_STREAM_TOKEN_IDS"
                    else:
                        if ids_ and self.first_token_at is None:
                            self.first_token_at = time.perf_counter()
                        self.tokens.extend(ids_)
                    for top in lp.get("top_logprobs") or []:
                        vals = sorted((v for v in (top or {}).values() if isinstance(v, (int, float))), reverse=True)
                        self.margins.append(round(vals[0] - vals[1], 4) if len(vals) >= 2 else None)
                    if c.get("finish_reason") is not None:
                        self.finish_reason = c["finish_reason"]
                if self.err:
                    break
        except Exception as e:
            if not self._halt:
                self.err = repr(e)[:200]
        if not self._halt and not self.err and not (self.done_seen and self.finish_reason):
            self.err = "INCOMPLETE_SSE: [DONE] seen %s, finish_reason %s" % (self.done_seen, self.finish_reason)

    def stop(self):
        self._halt = True
        try:      # rev 2b: shut the socket down first, so a reader blocked in recv returns (close() alone can wait on it)
            self._resp.fp.raw._sock.shutdown(socket.SHUT_RDWR)
        except Exception:
            pass
        try:
            if self._resp is not None:
                self._resp.close()
        except Exception:
            pass

    def row(self):
        return {"text": "".join(self.text), "tokens": list(self.tokens), "margins": list(self.margins), "error": self.err,
                "done_seen": self.done_seen, "finish_reason": self.finish_reason}


def _vms_dead():
    return VMS_SERVER is not None and not VMS_SERVER.alive()


def vms_idle(wait=60.0):
    """rev 2e (GPT audit E6): 0 running and 0 waiting in 3 consecutive samples (2 s apart) within `wait`."""
    end, hits = time.perf_counter() + wait, 0
    while time.perf_counter() < end:
        try:
            p = vms_prom()
            hits = hits + 1 if (_met(p, "vllm:num_requests_running") == 0 and _met(p, "vllm:num_requests_waiting") == 0) else 0
        except Exception:
            hits = 0
        if hits >= 3:
            return True
        time.sleep(2)
    return False


def vms_window(prompts, level, secs, tag, deadline=None):
    """`level` streams; wait until vllm:num_requests_running reaches level, a stable level - 1, or a KV plateau (requests
    waiting while running stays flat for 30 s); then wait for the prefill to settle; then measure the counters.
    rev 2b: every wait ends at `deadline` (the arm's own: the 2 x TP2 reserve stays intact) and on a dead server.
    rev 2e (GPT audits E5-E7, HIGH-5, E9): the prefill must settle (3 equal prompt-token readings) or the window is
    PREFILL_NOT_SETTLED; the streams are joined and the server must be idle afterwards (else DIRTY_SERVER_AFTER_WINDOW);
    every started stream is checked for empty / degenerate text; steady decode tok/s and end-to-end output tok/s (from
    submission) are both kept; prefix-cache hits / queries / cached prompt tokens are recorded."""
    end = min(HARD_STOP - 120, deadline or HARD_STOP)
    if end - time.perf_counter() < secs + 60:
        return {"skipped": "NOT_TESTED_BUDGET: deadline"}
    # rev 2g: max_tokens up to 32k inside max-model-len 106,496 (a stream that finished inside the window lowered
    # running_mean: a false reject)
    gens = [VGen(prompts[i % len(prompts)], max(1024, min(32768, 106496 - len(prompts[i % len(prompts)]) - 512)))
            for i in range(level)]
    out = {"tag": tag, "level": level}
    p_sub = p0 = p1 = None
    t_sub = t0 = t1 = None
    try:
        try:
            p_sub = vms_prom()
        except Exception:
            p_sub = {}
        t_sub = time.perf_counter()
        for g in gens:
            g.start()
        t_w, got, best, hist, plateau = time.perf_counter(), None, 0, [], False
        while time.perf_counter() < min(t_w + 900, end - secs - 30):
            if _vms_dead():
                out["error"] = "the server died while the streams were admitted"
                return out
            try:
                p = vms_prom()
                run, wait = _met(p, "vllm:num_requests_running"), _met(p, "vllm:num_requests_waiting")
            except Exception:
                run, wait = 0, 0
            best = max(best, run)
            hist.append((time.perf_counter(), run))
            if run >= level:
                got = level
                break
            alive = sum(1 for g in gens if g.is_alive())
            if alive < level - 1 or (alive < level and run >= alive):      # rev 2e-e / 2g: level (or level - 1) unreachable
                out["streams_ended_before_level"] = level - alive
                break
            flat = [r for t_, r in hist if t_ >= hist[-1][0] - 30]
            if wait > 0 and run >= 1 and hist[-1][0] - hist[0][0] >= 30 and len(set(flat)) == 1:
                got, plateau = int(run), True        # KV-bound: measure what the server really holds
                break
            time.sleep(2)
        if got is None and best >= level - 1:
            got = int(best)
        out.update(measured_level=got, plateau=plateau, capacity_limited=plateau, wait_sec=round(time.perf_counter() - t_w, 1))
        if got is None:
            out["error"] = f"the server never ran {level} requests (max {best})"
            return out
        # a request counts as running once its first prefill chunk is scheduled: start only when nothing waits (or the
        # plateau) and 3 consecutive prompt-token readings are equal. Up to 300 s: a no-prefix-cache arm prefills
        # 16 x 40k = 640k tokens (minutes); a window that still did not settle is measured but labelled mixed_load
        # (excluded from measurement_ok), never thrown away
        t_s, last, stable, settled = time.perf_counter(), None, 0, False
        while time.perf_counter() - t_s < 300 and time.perf_counter() < end - secs - 15:
            try:
                p = vms_prom()
                pt, wait = _met(p, "vllm:prompt_tokens_total"), _met(p, "vllm:num_requests_waiting")
            except Exception:
                break
            stable = stable + 1 if (last is not None and pt == last and (wait == 0 or plateau)) else 0
            if stable >= 2:
                settled = True
                break
            last = pt
            time.sleep(2)
        out.update(settle_sec=round(time.perf_counter() - t_s, 1), prefill_settled=settled, mixed_load=not settled)
        p0, t0 = vms_prom(), time.perf_counter()
        runs, kvs, runs_mx = [], [], []
        while time.perf_counter() - t0 < secs:
            time.sleep(2)
            if _vms_dead():
                out["error"] = "the server died inside the window"
                return out
            try:
                p = vms_prom()
                runs.append(_met(p, "vllm:num_requests_running"))
                runs_mx.append(p.get("vllm:num_requests_running@max", 0.0))      # rev 2g-b: per engine (DP skew)
                kvs.append(p.get("vllm:kv_cache_usage_perc@max", 0.0))      # rev 2b: per engine, never the DP sum
            except Exception:
                pass
        p1, t1 = vms_prom(), time.perf_counter()
        out["_runs"], out["_kvs"], out["_runs_mx"] = runs, kvs, runs_mx
    except Exception as e:
        out["error"] = f"{type(e).__name__}: {e}"[:300]
        return out
    finally:
        for g in gens:
            g.stop()
        for g in gens:
            if g.ident is not None:
                g.join(timeout=5)
        out["threads_not_joined"] = sum(1 for g in gens if g.is_alive())
        out["idle_after"] = (not _vms_dead()) and vms_idle(60)
        if out["threads_not_joined"] or not out["idle_after"]:
            out["error"] = out.get("error") or "DIRTY_SERVER_AFTER_WINDOW"
        started = [g for g in gens if g.first_token_at is not None]
        texts = ["".join(g.text) for g in started]
        out.update(finished_empty=sum(1 for g in gens if g.done_seen and not g.tokens),      # rev 2g-c (agent 3 B2)
                   no_first_token=len(gens) - len(started), empty_outputs=sum(1 for x in texts if not x.strip()),
                   degenerate=vms_degenerate(texts), stream_errors=sum(1 for g in gens if g.err),
                   stream_error_samples=[g.err for g in gens if g.err][:3])
    runs, kvs = out.pop("_runs", []), out.pop("_kvs", [])
    out["_runs_mx"] = out.get("_runs_mx") or []
    dt = t1 - t0
    gen = _met(p1, "vllm:generation_tokens_total") - _met(p0, "vllm:generation_tokens_total")
    acc = _met(p1, "vllm:spec_decode_num_accepted_tokens_total") - _met(p0, "vllm:spec_decode_num_accepted_tokens_total")
    drf = _met(p1, "vllm:spec_decode_num_drafts_total") - _met(p0, "vllm:spec_decode_num_drafts_total")
    gen_all = _met(p1, "vllm:generation_tokens_total") - _met(p_sub, "vllm:generation_tokens_total")
    out.update(window_sec=round(dt, 1), tok_s=round(gen / dt, 1) if dt > 0 else None,
               end_to_end_tok_s=round(gen_all / (t1 - t_sub), 1) if t1 and t_sub and t1 > t_sub else None,
               accept=round(1 + acc / drf, 2) if drf > 0 else None, running_mean=round(statistics.mean(runs), 2) if runs else None,
               running_engine_max_mean=round(statistics.mean(out.get("_runs_mx") or [0]), 2),
               kv_max=round(max(kvs), 3) if kvs else None,
               preemptions=_met(p1, "vllm:num_preemptions_total") - _met(p0, "vllm:num_preemptions_total"),
               prefix_cache_hits=_met(p1, "vllm:prefix_cache_hits_total") - _met(p_sub, "vllm:prefix_cache_hits_total"),
               prefix_cache_queries=_met(p1, "vllm:prefix_cache_queries_total") - _met(p_sub, "vllm:prefix_cache_queries_total"),
               prompt_tokens_cached=_met(p1, "vllm:prompt_tokens_cached_total") - _met(p_sub, "vllm:prompt_tokens_cached_total"))
    return out


def vms_window_healthy(w, level):
    """rev 2e (2nd audit HIGH-3): speed is evidence only from a clean window that held its level."""
    return bool(w) and not w.get("error") and not w.get("skipped") and (w.get("tok_s") or 0) > 0 \
        and w.get("prefill_settled") is True and w.get("stream_errors", 0) == 0 and w.get("empty_outputs", 0) == 0 and w.get("degenerate", 0) == 0 \
        and (w.get("measured_level") or 0) >= level and (w.get("running_mean") or 0) >= 0.80 * level \
        and w.get("no_first_token", level) == 0 and w.get("threads_not_joined", 1) == 0 and w.get("idle_after") is True \
        and (w.get("preemptions") or 0) == 0 and w.get("finished_empty", 0) == 0


def vms_greedy(prompts, n_tok=256, concurrent=False, deadline=None):
    """Greedy rows {text, token ids, top-1 / top-2 margins, error, [DONE], finish_reason}; rev 2b: one deadline for the
    whole pass; a row still running at the deadline is stopped and marked."""
    end = min(HARD_STOP - 120, deadline or HARD_STOP)
    gens = [VGen(p, n_tok, temperature=0.0, ignore_eos=False, logprobs=2) for p in prompts]
    if concurrent:
        for g in gens:
            g.start()
        for g in gens:
            g.join(max(0.0, min(900, end - time.perf_counter())))
    else:
        for g in gens:
            if end - time.perf_counter() < 30:
                g.err = "skipped: arm deadline"
                continue
            g.start()
            g.join(max(0.0, min(900, end - time.perf_counter())))
    for g in gens:
        if g.is_alive():
            g.stop()
            g.err = g.err or "stopped: arm deadline"
    return [g.row() for g in gens]


def vms_degenerate(texts):
    """rev 2 (GPT audit V1, vLLM #53912: silent empty / repeated-punctuation output with a normal finish): empty text, a
    run of 32+ identical characters, or >= 200 characters with < 8 distinct characters or < 10 % letters / digits.
    (A distinct-character RATIO would flag every long normal text: 8k characters of prose use ~100 distinct ones.)"""
    return sum(1 for x in texts if vms_text_bad(x))


def vms_grid_like(s):
    """rev 2g (GPT R2F-06): an ARC grid by structure ("0 0 1\n0 0 0", "[[0, 1], ...]"): only digits / brackets / commas /
    whitespace and every row <= 30 cells (the ARC maximum). "0" * 250 or "0 0 0 ..." x 200 is not a grid."""
    s = (s or "").strip()
    return bool(re.fullmatch(r"[0-9,\[\]\s]+", s)) and len(re.findall(r"\d", s)) >= 2 \
        and all(len(re.findall(r"\d", r_)) <= 30 for r_ in re.split(r"\]|\n", s))


def vms_text_bad(x):
    """rev 2e-c: one text is degenerate when empty, or (not grid-like) a 32-character run of one character, < 8 distinct
    characters over 200, or < 10 % letters / digits. A grid is never degenerate (it repeats by nature)."""
    s = (x or "").strip()
    if not s:
        return True
    if vms_grid_like(s):
        return False
    if re.search(r"(.)\1{31,}", s):
        return True
    return len(s) >= 200 and (len(set(s)) < 8 or sum(ch.isalnum() for ch in s) / len(s) < 0.10)


def vms_kernels(txt):
    """rev 2 (GPT audit V6): the GEMM / attention kernels vLLM says it selected (never assume the default)."""
    seen = []
    for ln in txt.splitlines():
        m = re.search(r"((?:Selected|Using|Chose)\b.{0,60}?(?:kernel|backend).{0,80}|--linear-backend=.{0,160})", ln, re.I)
        if m and m.group(1).strip() not in seen:
            seen.append(m.group(1).strip())
    return seen[:30]


def vms_tail_bad(ids):
    """rev 2e (GPT audits E2 / HIGH-10), rev 2e-c: the continuation after the first divergence, decoded, is degenerate by
    the shared text rule (a grid is not; empty, repeated punctuation, near-alphabet-free text is)."""
    ids = list(ids or [])
    if len(ids) < 16:
        return False          # too short to judge
    try:
        return vms_text_bad(tokenizer.decode(ids, skip_special_tokens=True))
    except Exception:
        return False


def vms_diverge(a, b):
    """rev 2b (agent 3 F10): rows compared by integer token id (rev 2e) with the EMS compare_passes rule. A large-margin
    flip = a divergence where either run was confident (top-1 minus top-2 > 1 nat); a divergence without both margins is
    missing evidence, never "no flip"; an errored, incomplete (no [DONE] / finish_reason) or empty row is an error."""
    expected = max(len(a), len(b))
    per = []
    for i in range(expected):
        ra = a[i] if i < len(a) else {"error": "missing row"}
        rb = b[i] if i < len(b) else {"error": "missing row"}
        ia, ib = list(ra.get("tokens") or []), list(rb.get("tokens") or [])
        inc = [x for x in (ra, rb) if "done_seen" in x and not (x.get("done_seen") and x.get("finish_reason"))]
        if ra.get("error") or rb.get("error") or inc or not ia or not ib:
            per.append({"error": ra.get("error") or rb.get("error") or ("incomplete stream" if inc else "no tokens")})
            continue
        if ia == ib:
            per.append({"identical": True})
            continue
        k = next((j for j, (u, v) in enumerate(zip(ia, ib)) if u != v), min(len(ia), len(ib)))
        ma = (ra.get("margins") or [None] * (k + 1))[k] if k < len(ra.get("margins") or []) else None
        mb = (rb.get("margins") or [None] * (k + 1))[k] if k < len(rb.get("margins") or []) else None
        per.append({"identical": False, "first_divergence": k, "margin_a": ma, "margin_b": mb,
                    "missing_margin": ma is None or mb is None,
                    "large_margin_flip": ma is not None and mb is not None and max(ma, mb) > 1.0,
                    "tail_bad": vms_tail_bad(ib[k:])})
    ok = [x for x in per if "identical" in x]
    div = [x for x in ok if not x["identical"]]
    return {"expected": expected, "compared": len(ok), "errors": expected - len(ok),
            "identical": sum(1 for x in ok if x["identical"]), "differ": len(div),
            "large_margin_flips": sum(1 for x in div if x["large_margin_flip"]),
            "missing_margins": sum(1 for x in div if x["missing_margin"]),
            "tail_bad": sum(1 for x in div if x.get("tail_bad")),
            "first_divergence": [x.get("first_divergence") for x in per]}


VMS_INST = None
if VMS_ON:
    try:
        VMS_INST = vms_install()
        VMS["install"] = {k: v for k, v in VMS_INST.items() if k != "env"}
        print("VMS install:", json.dumps(VMS["install"])[:600], flush=True)
    except Exception as _e:
        VMS["install"] = {"error": f"{type(_e).__name__}: {_e}"[:2000]}
        print("VMS install FAILED:", VMS["install"]["error"][:1500], flush=True)
e14_save()
