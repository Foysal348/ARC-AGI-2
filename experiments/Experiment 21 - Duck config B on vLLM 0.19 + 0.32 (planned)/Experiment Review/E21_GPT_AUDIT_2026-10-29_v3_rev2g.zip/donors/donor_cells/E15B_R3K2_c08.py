# ==================================================================== CELL 5b — E14-A1: engine measurements before the Duck run
# Plan: Notes/13, corrected after GPT audits 17-19 (Notes/20). Arms in order, each its own launch: W1 unchanged
# (baseline: windows 8k/40k, profiler, latch test, E14-P token replay, greedy parity serial / A/A / 12 at once), then
# +#44401 (+#41872) backport, +nodelay, + CUDA graphs 1..13. Every arm runs a short correctness gate against the W1
# greedy rows and is adopted only if every recorded condition holds (decisions[*].reason). A1 never eats the reserve of
# the 25-min Duck run; the Duck run (CELL 6) starts on a fresh launch of the kept arm.
import statistics

# ---- E14 shared helpers (CELL 5b and 6b)
def e14_edit_flags(flags, drop=(), set_=None, add=()):
    """drop: flag names removed with their value(s); set_: {flag: value | [values]} replaced or added; add: extra args."""
    out, i, set_ = [], 0, dict(set_ or {})
    names = set(drop) | set(set_)
    while i < len(flags):
        f = flags[i]
        if f in names:
            i += 1
            while i < len(flags) and not str(flags[i]).startswith("--"):
                i += 1
            continue
        out.append(f)
        i += 1
    for k, v in set_.items():
        out += [k] + ([str(x) for x in v] if isinstance(v, (list, tuple)) else ([str(v)] if v is not None else []))
    return out + list(add)


def e14_spec_drop(flags):
    return e14_edit_flags(flags, drop=[f for f in flags if str(f).startswith("--speculative-")])


E14_ARM = {"name": "W1", "set": {}, "drop": (), "env": {}, "spec": True}    # what the server runs now
E14_KEPT = dict(E14_ARM)        # the last ADOPTED arm: next arms build on it; failures and the Duck launch restore it
E14_KEPT_WIN = {}               # the kept arm's windows (short / long / latch): the reference for the next arm
E14_RESERVE = 0.0               # seconds kept for later work (the 25-min Duck run while A1 measures; GPT audits 17-19)
E14_DIRTY = False               # a step left requests running on the server: relaunch before the next phase
E14_GATE_REF = None             # baseline greedy rows for the per-arm correctness gate
E14_LOG_SIGNS = ("runs out of memory", "Not enough space", "Retract", "out of memory", "Traceback", "Exception")


def e14_launch(name, set_=None, drop=(), env=None, spec=True, patches=None, force=False):
    """Kill the current server, launch W1 + this arm's changes, wait (stall watchdog), record caps. A launch that
    could eat the Duck reserve is skipped (force=True: a launch that restores the kept arm or starts the Duck run).
    On a failure the KEPT arm is launched again (never the last launched one, which may have been rejected).
    Returns (ok, record)."""
    global E11_SERVER, E14_ARM, E14_DIRTY
    rec = {"arm": name, "set": set_ or {}, "drop": list(drop), "env": env or {}, "patches": patches, "force": force}
    if not E14M.launch_allowed(time.perf_counter(), HARD_STOP, reserve=0.0 if force else E14_RESERVE, force=force):
        rec["skipped"] = "would eat the Duck reserve" if (not force and E14_RESERVE) else "less than 15 min before the hard stop"
        E14_RESULTS.setdefault("launches", []).append(rec)
        e14_save()
        print(f"E14 launch {name}: skipped ({rec['skipped']})", flush=True)
        return False, rec
    E14_STATE.enter("LAUNCH:" + name, deadline=HARD_STOP)
    t0 = time.perf_counter()
    try:
        e11_kill_server(wait=True)
    except Exception:
        pass
    rec["gpu_free"] = _e11_gpu_free()
    flags = e11_flags(E14_VENV["cfg"])
    flags = e14_edit_flags(flags, drop=drop, set_=set_)
    if not spec:
        flags = e14_spec_drop(flags)
    envx = dict(E14_VENV["env"])
    envx.update(env or {})
    srv = E11Server(E14_VENV["launch"] + flags, envx, "e14_" + name)
    srv.start()
    # a measurement arm may not wait into the Duck reserve (review 3); the Duck / restore launches keep the old bound
    _room = HARD_STOP - time.perf_counter() - (10 * 60 if force else E14_RESERVE + 8 * 60)
    ok, why = srv.wait_ready(min(SGL_RELAUNCH_TIMEOUT_SEC, max(60.0, _room)))
    rec.update(ok=ok, why=why, sec=round(time.perf_counter() - t0, 1), flags=flags, watchdog=getattr(srv, "e14_stats", None))
    if ok:
        E11_SERVER = srv
        caps = e11_caps(srv.log_text())
        rec["caps"] = caps
        if caps.get("kv_tokens"):
            ENGINE_INFO["kv_tokens"] = caps["kv_tokens"]
        E14_ARM = {"name": name, "set": set_ or {}, "drop": tuple(drop), "env": env or {}, "spec": spec}
        E14_DIRTY = False
    else:
        rec["log_tail"] = srv.log_text()[-3000:]
        srv.kill()
        if force and E14_KEPT["name"] != name and not name.startswith("kept_"):
            okb, rb = e14_launch("kept_" + E14_KEPT["name"], set_=E14_KEPT["set"], drop=E14_KEPT["drop"],
                                 env=E14_KEPT["env"], spec=E14_KEPT["spec"], force=True)
            rec["relaunched_kept"] = {"ok": okb, "arm": E14_KEPT["name"], "sec": rb.get("sec")}
    E14_RESULTS.setdefault("launches", []).append(rec)
    e14_save()
    print(f"E14 launch {name}: {why} ({rec['sec']} s)", flush=True)
    return ok, rec


def e14_keep(**windows):
    """Adopt the arm the server runs now: later arms build on it and failures restore it."""
    global E14_KEPT
    E14_KEPT = dict(E14_ARM)
    E14_KEPT_WIN.update({k: v for k, v in windows.items() if v})


def _e14_dirty(obj):
    """True if any cleanup inside a phase result says requests were still running on the server."""
    if isinstance(obj, dict):
        if obj.get("server_idle") is False or obj.get("server_not_idle") is True:
            return True
        return any(_e14_dirty(v) for v in obj.values())
    if isinstance(obj, list):
        return any(_e14_dirty(v) for v in obj[:20])
    return False


def e14_phase(name, fn, cap_sec):
    """Run one phase with its own deadline: min(cap, time left before the hard stop - 8 min - E14_RESERVE); skipped
    (recorded) when less than 2 min would be left. A dirty server from the previous step is relaunched first (no
    carry-over into this phase's windows). Every result and error is recorded and saved at once."""
    global E14_DIRTY
    cap = E14M.phase_budget(time.perf_counter(), HARD_STOP, cap_sec, reserve=E14_RESERVE, margin=8 * 60)
    if cap is not None and E14_DIRTY:       # never measure on a server with leftover requests (review 4: not forced)
        e14_launch(E14_ARM["name"].split("_clean")[0] + "_clean", set_=E14_ARM["set"], drop=E14_ARM["drop"],
                   env=E14_ARM["env"], spec=E14_ARM["spec"])
        cap = E14M.phase_budget(time.perf_counter(), HARD_STOP, cap_sec, reserve=E14_RESERVE, margin=8 * 60)
    if cap is None or E14_DIRTY:
        E14_RESULTS["phases"][name] = {"skipped": "dirty server" if E14_DIRTY else "Duck reserve / hard stop",
                                       "reserve_sec": E14_RESERVE, "left_sec": round(HARD_STOP - time.perf_counter())}
        e14_save()
        print(f"E14 phase {name}: skipped {E14_RESULTS['phases'][name]}", flush=True)
        return None
    E14_CTX.deadline = time.perf_counter() + cap
    E14_STATE.enter("PHASE:" + name, deadline=E14_CTX.deadline, arm=E14_ARM["name"])
    t0 = time.perf_counter()
    _srv = E11_SERVER
    _off = len(_srv.log_text()) if _srv is not None else 0
    try:
        res = fn()
    except BaseException as _e:
        res = {"error": f"{type(_e).__name__}: {_e}"[:500], "traceback": traceback.format_exc()[-1500:]}
    if isinstance(res, dict):
        res.setdefault("arm", E14_ARM["name"])
        res["phase_sec"] = round(time.perf_counter() - t0, 1)
        res["budget"] = {"cap_sec": round(cap, 1), "reserve_sec": E14_RESERVE,
                         "end_before_hard_stop_sec": round(HARD_STOP - E14_CTX.deadline, 1)}
        if _srv is not None:                 # over-admission / eviction signs (substring diagnostic, not a classifier)
            _new = _srv.log_text()[_off:]
            res["server_log_signs"] = {s: _new.count(s) for s in E14_LOG_SIGNS if s in _new}
        if _e14_dirty(res):
            E14_DIRTY = True
            res["server_not_idle_after"] = True
    E14_RESULTS["phases"][name] = res
    e14_save()
    print(f"E14 phase {name}: {json.dumps(res, default=str)[:900]}", flush=True)
    return res


def e14_decide(name, conds, **extra):
    """conds: [(label, bool)]: adopted only if all hold; the first failing label is the recorded reason."""
    why = next((lab for lab, ok in conds if not ok), None)
    E14_RESULTS["decisions"][name] = dict(adopt=why is None, reason="all conditions met" if why is None else why,
                                          conditions={lab: bool(ok) for lab, ok in conds}, **extra)
    return why is None


def _e14_model_id():
    try:
        return json.loads(_urlreq.urlopen(SGL_URL + "/v1/models", timeout=30).read())["data"][0]["id"]
    except Exception:
        return str(SGL_MODEL_PATH)


def _e14_rows(g):
    return "\n".join(" ".join(str(v) for v in r) for r in g)


def _e14_task_text(t):
    s = "".join(f"\nExample {i + 1}\nInput:\n{_e14_rows(p['input'])}\nOutput:\n{_e14_rows(p['output'])}\n"
                for i, p in enumerate(t["train"]))
    return s + "".join(f"\nTest input {j + 1}:\n{_e14_rows(q['input'])}\n" for j, q in enumerate(t["test"]))


def _e14_chat_ids(messages, tools=None, think=True):
    txt = tokenizer.apply_chat_template(messages, tools=tools, tokenize=False, add_generation_prompt=True,
                                        enable_thinking=think, reasoning_effort=REASONING_EFFORT)
    return tokenizer.encode(txt, add_special_tokens=False)


def e14_prompts():
    """short: one real task per stream (the ARC text the model reasons about); long: a shared ~36k-token block of other
    eval tasks + the task (the 40k band); parity: the 12 task prompts, thinking on; Duck: system prompt + tools + first
    opener exactly as the solver sends them."""
    ask = "Find the transformation rule of this ARC-AGI-2 task and describe it, then give the test output grids."
    short = [_e14_chat_ids([{"role": "user", "content": ask + "\n" + _e14_task_text(CHALLENGES[t])}]) for t in TASK_IDS]
    try:
        _all = _load_json(ARC_ROOT / "arc-agi_evaluation_challenges.json")
    except Exception:
        _all = dict(CHALLENGES)
    bg, n = [], 0
    for t in sorted(_all):
        if t in CHALLENGES:
            continue
        txt = _e14_task_text(_all[t])
        bg.append(txt)
        n += len(tokenizer.encode(txt, add_special_tokens=False))
        if n >= int(os.environ.get("E14_LONG_TOKENS", 36000)):
            break
    block = "Reference tasks (not to be solved):\n" + "\n".join(bg)
    long_ = [_e14_chat_ids([{"role": "system", "content": block},
                            {"role": "user", "content": ask + "\n" + _e14_task_text(CHALLENGES[t])}]) for t in TASK_IDS]
    TA, _, _, wrs = E12A._import_duck()
    Agent = E12A.make_agent_class()
    duck = []
    for t in TASK_IDS:
        ag = Agent(task=CHALLENGES[t], task_id=t, branch=0, view="facts", model=E14_CTX.model_id, base_url=SGL_URL + "/v1",
                   provider="vllm")
        d = E14_OUT / f"duck_probe_{t}"
        d.mkdir(parents=True, exist_ok=True)
        sp = d / TA.RUNTIME_STATE_FILENAME
        wrs(sp, current_frame=None, history=[])
        duck.append((ag._system_prompt, E12A.R6_TEXT["first"] + E12A.R6_COMPLETE, ag._tools(sp)))
    tool_text = "Tool output:\n" + _e14_rows(CHALLENGES[TASK_IDS[0]]["train"][0]["input"])
    return {"short": short, "long": long_, "duck": duck, "tool_text": tool_text,
            "tokens": {"short_p50": statistics.median(len(x) for x in short) if short else None,
                       "long_p50": statistics.median(len(x) for x in long_) if long_ else None}}

E14_CTX = None
if E14_DO_MEASURE and ENGINE_READY:
    E14_CTX = E14M.Ctx(SGL_URL, lambda: E11_SERVER.log_text() if E11_SERVER is not None else "", E14_OUT,
                       model_id=_e14_model_id(), deadline=HARD_STOP - 8 * 60, log=print, encode=None,
                       normalize=_E12_TA._normalize_message_content)
    E14_CTX.scale = E14_TS
    E14_KEPT = dict(E14_ARM)
    # Duck reserve (GPT audits 17 HIGH-2, 18 P0, 19 HIGH-E): A1 phases and A1 relaunches never eat the 25-min Duck run:
    # its window + the solver stop margin + preflight + final artifacts + one conservative (cold capture) relaunch
    _rs = {"solve_window": float(E12_SOLVE_WINDOW_SEC or 1500), "stop_before_hard": float(E12_STOP_BEFORE_HARD_SEC),
           "preflight": _ts(300), "artifacts": _ts(600), "duck_relaunch": _ts(400)}
    E14_RESERVE = round(sum(_rs.values()), 1)
    E14_RESULTS["a1_reserve"] = dict(_rs, total=E14_RESERVE)
    _t = time.perf_counter()
    try:
        E14_PROMPTS = e14_prompts()
    except Exception as _e:           # review 13: never let a prompt-builder error stop the notebook before the Duck run
        E14_PROMPTS = {"short": [], "long": [], "duck": [], "tool_text": "", "tokens": {"error": repr(_e)[:300]}}
    E14_RESULTS["prompts"] = dict(E14_PROMPTS["tokens"], sec=round(time.perf_counter() - _t, 1))
    _S, _L = E14_PROMPTS["short"], E14_PROMPTS["long"]
    _summ = lambda d, s: E14T.summarize(d, s)
    _latch = lambda: E14M.latch_test(E14_CTX, _S, _L, decodes=SGL_MAX_RUNNING - 1, arrivals=3, secs=_ts(60),
                                     server_cap=SGL_SERVER_MAX_RUNNING, level=SGL_MAX_RUNNING)

    def _a1_baseline():
        out = {"short": E14M.steady_window(E14_CTX, _S, level=SGL_MAX_RUNNING, secs=_ts(75), tag="w1short"),
               "long": E14M.steady_window(E14_CTX, _L, level=SGL_MAX_RUNNING, secs=_ts(75), tag="w1long")}
        out["profile"] = E14M.steady_window(E14_CTX, _S, level=SGL_MAX_RUNNING, secs=_ts(60), tag="w1prof",
                                            during=lambda c: E14M.profile_steps(c, steps=20, summarize=_summ))
        out["latch"] = _latch()
        return out
    E14_BASE = e14_phase("A1-2_baseline_W1", _a1_baseline, _ts(15 * 60))
    e14_keep(**{k: (E14_BASE or {}).get(k) for k in ("short", "long", "latch")})
    e14_phase("A1-3_replay_E14P", lambda: E14M.replay_check(E14_CTX, E14_PROMPTS["duck"][:3]), _ts(8 * 60))

    def _a1_parity():
        a = E14M.parity_pass(E14_CTX, _S, max_new=512, tag="d_serial_a")
        b = E14M.parity_pass(E14_CTX, _S, max_new=512, tag="d_serial_b")
        c = E14M.parity_pass(E14_CTX, _S, max_new=512, concurrent=True, tag="d_c12")
        c2 = E14M.parity_pass(E14_CTX, _S, max_new=512, concurrent=True, tag="d_c12_b")
        _dirty = any(x and x[0].get("server_not_idle") for x in (a, b, c, c2))
        # every later arm gate compares with these; a reference taken beside leftover requests is no reference (review 12)
        globals()["E14_GATE_REF"] = None if _dirty else E14M.gate_reference(a, b, c, c2)
        # batching alone changes greedy tokens (E12: 152-166 of 512 shared, no fault): concurrency 12 gets its own A/A;
        # the decision rests on large-margin flips (> 1 nat) judged against the A/A, never on raw token equality
        return {"aa": E14M.compare_passes(a, b, "D serial A vs D serial B (A/A)"),
                "aa_c12": E14M.compare_passes(c, c2, "D c12 vs D c12 (A/A under batching)"),
                "contamination": E14M.compare_passes(a, c, "D serial vs D at concurrency 12"),
                "server_not_idle": _dirty, "gate_reference": "invalid (dirty server)" if _dirty else "ok"}
    E14_PAR = e14_phase("A1-4_parity_D", _a1_parity, _ts(12 * 60))
    if isinstance(E14_PAR, dict) and "aa" in E14_PAR:
        E14_RESULTS["decisions"]["dflash_contamination"] = E14M.parity_ok(E14_PAR["contamination"], E14_PAR["aa_c12"],
                                                                          allowance=2, identity="ignore")

    def _arm_windows(tag, latch=True, extra=None):
        """The correctness gate FIRST (audits 17-19: correctness before any throughput arm; a gate placed after the
        windows was once starved of time and rejected a good arm as INCOMPLETE), then the windows only if it passed."""
        def run():
            # identity=False: DFlash2 greedy output is byte-identical within one process but can differ across a
            # restart (#38009, Notes/Research - 4xL4 ...); every arm is a new process, so large-margin flips vs the
            # A/A decide (a corrupt arm still fails: 2.4-nat flips) and identity is only recorded (review 1)
            out = {"gate": E14M.arm_gate(E14_CTX, _S, E14_GATE_REF, tag="gate_" + tag, identity=False)}
            if not out["gate"].get("ok"):
                out["windows_skipped"] = "the correctness gate did not pass"
                return out
            out["flush_after_gate"] = E14M.flush_cache(E14_CTX)   # the windows start uncached like W1's (review 14)
            out["short"] = E14M.steady_window(E14_CTX, _S, level=SGL_MAX_RUNNING, secs=_ts(75), tag=tag + "short")
            out["long"] = E14M.steady_window(E14_CTX, _L, level=SGL_MAX_RUNNING, secs=_ts(75), tag=tag + "long")
            if latch:
                out["latch"] = _latch()
            out.update((extra or (lambda: {}))())
            return out
        return run

    # ---- arm 1: #44401 + #41872 backport (source-hash guarded; refused = arm skipped). Adopted only with a real
    # occupancy gain at the same offered load, a passing correctness gate and no server error signs.
    _site = None
    if not E11_HARNESS:
        try:
            _site = subprocess.run([E14_VENV["vpy"], "-c", "import sglang, os; print(os.path.dirname(sglang.__file__))"],
                                   capture_output=True, text=True, timeout=120).stdout.strip()
        except Exception as _e:
            _site, E14_RESULTS["patch_site_error"] = None, repr(_e)[:200]
    else:
        _site = os.environ.get("E14_FAKE_SGLANG_PKG")
    _pr = E14P.apply(_site, names=("44401", "41872")) if _site else {"error": "sglang package path unknown"}
    E14_RESULTS["patches"] = _pr
    _applied = [n for n, v in (_pr.get("results") or {}).items() if v.get("status") in ("applied", "already applied")]
    if "44401" in _applied:
        _ok, _ = e14_launch("p44401", set_=E14_KEPT["set"], drop=E14_KEPT["drop"], env=E14_KEPT["env"], patches=_applied)
        _pp = e14_phase("A1-5_p44401", _arm_windows("p44401"), _ts(14 * 60)) if _ok else None
        _sp = E14M.adopt_speed(E14_KEPT_WIN.get("short"), (_pp or {}).get("short"), occupancy=True, per_step=True)
        _lg = E14M.latch_gain(E14_KEPT_WIN.get("latch"), (_pp or {}).get("latch"))
        _gt = (_pp or {}).get("gate") or {"ok": False, "why": "not run"}
        _er = E14M.log_errors((_pp or {}).get("server_log_signs"))
        if e14_decide("p44401", [("launched and measured", bool(_ok and _pp and not _pp.get("error"))),
                                 ("correctness gate", _gt.get("ok")),
                                 ("occupancy gain", _lg["gain"]), ("speed not worse", _sp["adopt"]),
                                 ("no server error signs", not _er)],
                      speed=_sp, latch_gain=_lg, gate=_gt, log_errors=_er):
            e14_keep(**{k: _pp.get(k) for k in ("short", "long", "latch")})
    else:
        e14_decide("p44401", [("patch applied", False)], report=_pr)
    if _applied and not (E14_RESULTS["decisions"].get("p44401") or {}).get("adopt"):
        # every applied hunk that was not adopted is reverted (#41872 alone included; review 7); the revert is checked
        _rv = E14P.revert(_site)
        E14_RESULTS["patches_reverted"] = _rv
        if not (isinstance(_rv, dict) and _rv.get("ok")):
            E14_RESULTS["patch_state"] = "revert NOT confirmed: later launches may still run patched files"

    # ---- arm 1b: the DFlash min-free-slots delayer off (Notes/14; source: managers/min_free_slots_delayer.py +
    # scheduler.py L1182-1193). Unset + DFlash -> threshold min(4, max(2, (13 + 5) // 6)) = 3: with 11 running only 2
    # slots are allocatable, so a returning stream waits until a second one finishes = the 11 running + 1 queued state.
    # --min-free-slots-delay 1 disables it ("<= 1 disables"). Needs a real 11 -> 12 gain (latch_gain), not a tie.
    _ok, _ = e14_launch("nodelay", set_=dict(E14_KEPT["set"], **{"--min-free-slots-delay": 1}), drop=E14_KEPT["drop"],
                        env=E14_KEPT["env"])
    _np = e14_phase("A1-5b_nodelay", _arm_windows("nodelay"), _ts(14 * 60)) if _ok else None
    _sp = E14M.adopt_speed(E14_KEPT_WIN.get("short"), (_np or {}).get("short"), occupancy=True, per_step=True)
    _lg = E14M.latch_gain(E14_KEPT_WIN.get("latch"), (_np or {}).get("latch"))
    _gt = (_np or {}).get("gate") or {"ok": False, "why": "not run"}
    _er = E14M.log_errors((_np or {}).get("server_log_signs"))
    if e14_decide("nodelay", [("launched and measured", bool(_ok and _np and not _np.get("error"))),
                              ("correctness gate", _gt.get("ok")),
                              ("occupancy gain", _lg["gain"]), ("speed not worse", _sp["adopt"]),
                              ("no server error signs", not _er)],
                  speed=_sp, latch_gain=_lg, gate=_gt, log_errors=_er):
        e14_keep(**{k: _np.get(k) for k in ("short", "long", "latch")})

    # ---- arm 2: CUDA graphs for every batch size 1..13 (13 = the server's admission limit), on top of the kept arms;
    # adopted only if the server really captured 12 and 13 (fail closed on an unparsed list)
    _gbs = {"--cuda-graph-bs-decode": list(range(1, SGL_SERVER_MAX_RUNNING + 1))}
    _ok, _grec = e14_launch("graphs13", set_=dict(E14_KEPT["set"], **_gbs),
                            drop=tuple(E14_KEPT["drop"]) + ("--cuda-graph-max-bs-decode",), env=E14_KEPT["env"])
    _gcap = ((_grec or {}).get("caps") or {}).get("verify_graph_bs")      # what the server really captured
    _gp = e14_phase("A1-6_graphs13", _arm_windows("g13", latch=False, extra=lambda: {
        "short13": E14M.steady_window(E14_CTX, _S, level=SGL_SERVER_MAX_RUNNING, secs=_ts(60), tag="g13at13")}),
        _ts(12 * 60)) if _ok else None
    _gs = E14M.adopt_speed(E14_KEPT_WIN.get("short"), (_gp or {}).get("short"), per_step=True)
    _gcov = bool(_gcap) and {12, SGL_SERVER_MAX_RUNNING} <= set(_gcap)
    _gt = (_gp or {}).get("gate") or {"ok": False, "why": "not run"}
    _er = E14M.log_errors((_gp or {}).get("server_log_signs"))
    if e14_decide("graphs13", [("launched and measured", bool(_ok and _gp and not _gp.get("error"))),
                               ("correctness gate", _gt.get("ok")),
                               ("captured 12 and 13", _gcov), ("speed not worse", _gs["adopt"]),
                               ("no server error signs", not _er)],
                  speed=_gs, gate=_gt, log_errors=_er, captured_bs=_gcap):
        e14_keep(**{k: _gp.get(k) for k in ("short", "long")})

    # ---- the Duck run starts on a FRESH launch of the kept arm: an empty radix cache and Mamba state like the hidden
    # run, and the kept arm restored after a rejected one (audit 17 HIGH-4 / 18 Q3 / 19 §3). /flush_cache only when the
    # relaunch did not happen; its plain-text reply is classified, never assumed.
    E14_RESERVE = 0.0
    _okf, _ = e14_launch("duck_" + E14_KEPT["name"], set_=E14_KEPT["set"], drop=E14_KEPT["drop"], env=E14_KEPT["env"],
                         spec=E14_KEPT["spec"], force=True)
    _fresh = bool(_okf) or (E14_ARM["name"].startswith("kept_") and bool((E14_RESULTS.get("launches") or [{}])[-1].get("ok")))
    _clean = {"method": "relaunch" if _okf else ("relaunch (kept arm after a failed Duck launch)" if _fresh else "relaunch failed"),
              "ok": _fresh, "arm": E14_ARM["name"]}
    if not _fresh:
        E14_CTX.deadline = time.perf_counter() + max(5.0, min(120.0, HARD_STOP - time.perf_counter() - 8 * 60))
        _idle = E14M.server_idle(E14_CTX, wait=30.0)
        try:
            _msg = (E14M.post_json(E14_CTX, "/flush_cache", {}, timeout=60) or {}).get("text") or ""   # http_server.py:987
        except Exception as _e:
            _msg = "error: " + repr(_e)[:200]
        _fl = _msg.strip().startswith("Cache flushed")
        _clean = {"method": "flush", "idle_before": _idle, "ok": _fl, "reply": _msg.strip()[:300], "arm": E14_ARM["name"]}
    _clean["cold_start_unverified"] = not _clean["ok"]
    _clean["kept_arm_running"] = E14_ARM["set"] == E14_KEPT["set"] and E14_ARM["drop"] == E14_KEPT["drop"] and \
        E14_ARM["env"] == E14_KEPT["env"]
    E14_RESULTS["duck_clean_start"] = _clean
    _clean["server_reachable_and_idle"] = E14M.server_idle(E14_CTX, wait=5.0)
    _avail = HARD_STOP - E12_STOP_BEFORE_HARD_SEC - time.perf_counter()
    E14_RESULTS["duck_window"] = {"planned_sec": E12_SOLVE_WINDOW_SEC, "available_sec": round(_avail),
                                  "status": "full" if _avail >= (E12_SOLVE_WINDOW_SEC or 0) + _ts(300)
                                  else "solver_window_unavailable"}
    E14_RESULTS["duck_arm"] = dict(E14_ARM)
    E14_STATE.enter("DUCK", arm=E14_ARM["name"])
    e14_save()
    print("E14-A1 decisions:", json.dumps({k: (v.get("adopt", v.get("ok")), v.get("reason", v.get("verdict")))
                                           for k, v in E14_RESULTS["decisions"].items()
                                           if isinstance(v, dict)}, default=str)[:1500],
          "| Duck runs on", E14_ARM["name"], "| clean start", _clean, "| window", E14_RESULTS["duck_window"], flush=True)
elif E14_DO_MEASURE:
    E14_RESULTS["phases"]["A1"] = {"skipped": f"engine not ready (ENGINE_READY={ENGINE_READY})"}
    e14_save()
