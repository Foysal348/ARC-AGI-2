# E18 — S1-60K on vLLM 0.32.0, 20 streams

**User (2026-10-27):** S1-60K (LB 34.58, sha `ed530071`) unchanged except the engine: vLLM 0.32.0 instead of 0.19.0, and
20 streams instead of 16. Poetiq, prompts, 60,000 + 8,192 tokens, sampling, queue, KV gate and deadlines are S1's.

- The solver, report, Poetiq core, task order, install (CELL 2) and CELL 0 cells are **byte-identical** to S1-60K.
- CELL 5 runs vLLM 0.32.0 as an OpenAI server from a venv (`foysalemonshanto/vllm-0-32-0-cu13-wheelhouse`, the
  Experiment 14 VMS launch) with S1's engine flags, and gives the solver the same `engine.add_request / step /
  abort_request`, `llm.get_metrics()` and `SamplingParams` names through a shim. Prompts are S1's token ids.
- Ladder: S1 flags + language-model-only → the exact VMS `fp8_mtp3_s20` flags → VMS with Triton attention → S1's own
  in-process vLLM 0.19 engine cell (verbatim).
- Commit run: `E18SMOKE` = 20 eval tasks, 45 min (engine, 20 concurrent units, drain, verification, tok/s). The hidden
  rerun is `RERUN_ALL` (12 h), unchanged.

---

# Q27 E10 — 86K × Poetiq Train-Verified Program Solver

**Base:** User-supplied Q27-XHIGH-v1_4_4_E10_BASE_86K.ipynb (SHA256 `530cb119...`).

**Frozen architecture:** 86K Q27 local vLLM → Poetiq task-level program synthesis → isolated Python execution on visible train pairs → exact/soft feedback → iterative refinement → expert voting/diversity → two ranked attempt grids.

**User decisions:** 77,824 thinking + 8,192 answer; original task order (no Codex ordering); no E9 tail resample; original 4×L4 FP8-KV/MTP3 engine initialization; do not insert old Q27 grid ranker. Poetiq donor default: one expert, 10 iterations, 5 feedback examples, temperature 1.0. Config supports 2/8+ experts and prompt variants 1/2/3 without editing code.

**Source:** [poetiq-ai/poetiq-arc-agi-solver](https://github.com/poetiq-ai/poetiq-arc-agi-solver), MIT. This is a local-vLLM adaptation, not a byte-for-byte Poetiq clone or a measured Poetiq accuracy claim. Kaggle has no internet; all runtime code is embedded here.

**STATUS:** CPU-validated prototype; requires 4×L4 GPU validation. No GPU or Kaggle submission run by the authoring assistant.


**R4T (2026-10-14):** R4 + the full thinking of every iteration saved to `q27x/poetiq_thinking/` (logging only).


**R5 + EVAL120 (2026-10-14):** commit run = all 120 evaluation tasks / 172 test inputs on the hidden-run clock (admit until 11:34, drain 11:36, hard stop 11:44). Everything else is R5 unchanged (77,824 + 8,192, full thinking saved to q27x/poetiq_thinking/). `Q27X_PROFILE=EVAL12` gives the R5 default.


**S1-60K (2026-10-16), submission build and the Experiment 11 base:** R5 + ORDER2 queue + F1/F3/A2/F2/C1 fixes + KV admission gate (0.95, >= 12 running) + weight prefetch + 12 h clock from kernel start (last admission 11:45, drain 11:47, hard stop 11:55; R5 left 16 min unused). **Thinking 60,000 + 8,192** (user: LB test of the 60k threshold against R5's 77,824; `Q27X_THINK_BUDGET` overrides). Temperature 1.0 unchanged. Commit run = 4 quick eval tasks (`S1COMMIT4`, about 1 h) so the version can be submitted; the hidden rerun solves every task. `Q27X_PROFILE=EVAL120` gives the full evaluation run.
