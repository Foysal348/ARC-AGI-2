# ==================================================================== CELL 7 — E12: report, score (evaluation) and bundle
try:
    with _E12_LOCK:
        _recs = {t: list(v) for t, v in E12_RECORDS.items()}
    _gen = E12A.build_submission({t: CHALLENGES[t] for t in TASK_IDS}, _recs)
    write_json_atomic(OUT / "e12_generated_attempts.json", _gen)

    def _usage_summary(u):
        p = sum(int(x.get("prompt") or 0) for x in u); c = sum(int(x.get("cached") or 0) for x in u)
        return {"requests": len(u), "prompt_tokens": p, "cached_tokens": c, "cached_pct": round(100 * c / p, 1) if p else None,
                "completion_tokens": sum(int(x.get("completion") or 0) for x in u),
                "cached_pct_by_request": [round(100 * int(x.get("cached") or 0) / int(x["prompt"]), 1) if x.get("prompt") else None
                                          for x in u][:400]}
    branches = []
    for t in TASK_IDS:
        for r in _recs.get(t, []):
            subs = r.get("submissions") or []
            branches.append({"task": t, "branch": r.get("branch"), "accepted": bool(r.get("accepted")), "turns": r.get("turns"),
                             "failures": r.get("failures"), "note": r.get("note"), "generated_tokens": r.get("generated_tokens"),
                             "total_tokens": r.get("total_tokens"), "sec": round((r.get("t1") or 0) - (r.get("t0") or 0), 1),
                             "submissions": len(subs), "train_exact_per_submission": [sum(map(bool, s.get("train_exact") or []))
                                                                                       for s in subs],
                             "usage": _usage_summary(r.get("usage") or []),
                             # rev 5 metrics (absent before rev 5): harvested check() candidates and event counters
                             "checked_verified": len(r.get("checked") or []),
                             "checked_kept": sum(1 for s in (r.get("checked") or []) if s.get("accepted")),
                             "rev5_events": r.get("rev5_events"),
                             # rev 6 (absent before rev 6)
                             "view": r.get("view"), "status": r.get("status"), "runs": r.get("runs"),
                             "progress_best": (r.get("progress") or {}).get("best"), "rev6_events": r.get("rev6_events"),
                             "stage2_class": r.get("stage2_class"),
                             "overfit_flags": sorted({f for v in (r.get("checked") or []) + (r.get("submissions") or [])
                                                      if v.get("accepted") for f in (v.get("overfit_flags") or [])})})
    _all_u = [x for t in TASK_IDS for r in _recs.get(t, []) for x in (r.get("usage") or [])]
    report = {"run_id": RUN_ID, "profile": PROFILE, "rerun": RERUN, "configuration": CONFIG, "engine": ENGINE_INFO,
              "e12_run": E12_RUN, "order": E12_ORDER, "branches": branches, "usage_all": {k: v for k, v in _usage_summary(_all_u).items()
                                                                                        if k != "cached_pct_by_request"},
              "tasks_planned": len(TASK_IDS), "queries_planned": sum(len(CHALLENGES[t]["test"]) for t in TASK_IDS)}
    def _r6_metrics(rows):   # R6-M1: one report contract (censored first-check = the branch total)
        import statistics as _st
        med = lambda v: _st.median(v) if v else None
        ev = [r.get("rev6_events") or {} for r in rows]
        tot = lambda k: sum(int(e.get(k) or 0) for e in ev)
        ft = [e.get("first_tool_tokens") for e in ev if e.get("first_tool_tokens") is not None]
        fc = [(e.get("first_check_tokens") if e.get("first_check_tokens") is not None else r.get("generated_tokens") or 0)
              for e, r in zip(ev, rows)]
        hist = lambda k: {kk: sum(int((e.get(k) or {}).get(kk, 0)) for e in ev)
                          for kk in sorted({x for e in ev for x in (e.get(k) or {})})}
        vs = sorted(x for e in ev for x in (e.get("verify_sec") or []))
        b0 = [r for r in rows if r.get("branch") == 0]
        return {"branches": len(rows),
                "tasks_exposed": len({r.get("task") for r in b0 if (r.get("generated_tokens") or 0) > 0}),
                "tasks_meaningful": len({r.get("task") for r in rows
                                         if (r.get("rev6_events") or {}).get("first_tool_tokens") is not None}),
                "first_tool_tokens_median": med(ft), "first_check_tokens_median_censored": med(fc),
                # G4-13 (GPT G4B audit 1 M1-B): the observed median is over checked branches only (selection bias)
                "first_check_tokens_median_observed": med([e["first_check_tokens"] for e in ev
                                                           if e.get("first_check_tokens") is not None]),
                "first_check_tokens_median_observed_b0": med([e["first_check_tokens"] for e, r in zip(ev, rows)
                                                              if e.get("first_check_tokens") is not None and r.get("branch") == 0]),
                "checked_branches": sum(1 for e in ev if e.get("first_check_tokens") is not None),
                "never_checked": sum(1 for e in ev if e.get("first_check_tokens") is None),
                "autocheck_calls": tot("autocheck_calls"), "autocheck_functions": tot("autocheck_functions"),
                "grid_rows_suppressed": tot("grid_rows_suppressed"), "length_cut_no_call": tot("length_cut_no_call"),
                "nudges_replaced": tot("nudges_replaced"), "timeouts_clamped": tot("timeouts_clamped"),
                "verify_skipped_deadline": tot("verify_skipped_deadline"),
                "accepted_duplicate_outputs": tot("accepted_duplicate_outputs"),
                "resumes": hist("resumes"), "caps": hist("caps"),
                "verify_sec_p50": vs[len(vs) // 2] if vs else None, "verify_sec_p90": vs[int(len(vs) * 0.9)] if vs else None,
                "status": {s: sum(1 for r in rows if r.get("status") == s) for s in ("paused", "done", "new")},
                **_r6_metrics_more([dict(r, task=t) for t in TASK_IDS for r in _recs.get(t, [])])}

    def _r6_metrics_more(rows):   # rev 6b additions (fix-list R6-M1; raw branch records; label-free, no truth)
        ev = [r.get("rev6_events") or {} for r in rows]
        q = lambda v, f: sorted(v)[min(len(v) - 1, int(f * len(v)))] if v else None
        tot = lambda k: sum(int(e.get(k) or 0) for e in ev)
        rc = tot("reasoning_chars")
        ft = [e.get("facts_tokens") for e in ev if e.get("facts_tokens") is not None]
        acc = [(r, v) for r in rows for v in (r.get("checked") or []) + (r.get("submissions") or []) if v.get("accepted")]
        # G4-7 / G4-13 (GPT G4B audits): a check() and a submit() of one program are 2 events, 1 program
        uniq, preds, progs = {}, {}, {}
        for r, v in acc:
            uniq.setdefault((r.get("task"), r.get("branch"), v.get("name"), json.dumps(v.get("test_outputs"))), v)
            preds.setdefault(r.get("task"), set()).add(json.dumps(v.get("test_outputs")))
            # H6-9 (GPT rev 6e audits 2/3): a program = its source + retained dependencies (src_key), across branches
            progs.setdefault(r.get("task"), set()).add(v.get("src_key") or (r.get("branch"), v.get("name"),
                                                                             json.dumps(v.get("test_outputs"))))
        flags = {}
        for v in uniq.values():
            for f in v.get("overfit_flags") or []:
                flags[f] = flags.get(f, 0) + 1
        by_task = {}
        for r, v in acc:
            by_task.setdefault(r.get("task"), {}).setdefault(r.get("branch"), set()).add(json.dumps(v.get("test_outputs")))
        both = [t for t, d in by_task.items() if len(d) >= 2]
        agree = sum(1 for t in both if set.intersection(*by_task[t].values()))
        b1 = {}
        for r in rows:
            if r.get("branch") == 1 and r.get("stage2_class") is not None:
                own = by_task.get(r.get("task"), {})
                new = len(own.get(1, set()) - own.get(0, set()))
                c = b1.setdefault(str(r["stage2_class"]), {"branches": 0, "new_distinct_verified": 0, "tokens": 0})
                c["branches"] += 1
                c["new_distinct_verified"] += new
                c["tokens"] += int(r.get("generated_tokens") or 0)
        runs = [x for r in rows for x in (r.get("runs") or [])]
        osh = [x["overshoot"] for x in runs if "overshoot" in x]
        rp = [x["first_uncached"] for x in runs if x.get("stage") == 2 and "first_uncached" in x]
        pe = [a / b for r in rows for a, b in ((r.get("rev5_events") or {}).get("prompt_estimates") or []) if b]
        us = [u for r in rows for u in (r.get("usage") or [])]
        try:
            dec = e11_decode_summary() or {}
        except Exception:
            dec = {}
        rh = dec.get("running_hist") or {}
        return {"facts_tokens_p50": q(ft, .5), "facts_tokens_p90": q(ft, .9), "facts_tokens_max": max(ft) if ft else None,
                "hand_reading_grid_row_share": round(tot("reasoning_grid_row_chars") / rc, 4) if rc else None,
                "reasoning_digit_share": round(tot("reasoning_digit_chars") / rc, 4) if rc else None,
                "reasoning_repeat_share": round(tot("reasoning_repeat_chars") / rc, 4) if rc else None,
                "tool_calls": tot("tool_calls"), "redefinition_share": round(tot("redefinitions") / max(1, tot("tool_calls")), 4),
                "infra_errors": tot("infra_errors"), "trim_reasoning_only_blocks": tot("trim_reasoning_only_blocks"),
                "facts_over_target": sum(1 for e in ev if e.get("facts_over_target")),
                "accepted_events": len(acc), "accepted_candidates": len(uniq), "unique_verified_programs": len(uniq),
                # H7-5: the field above is keyed (task, branch, name, outputs), i.e. name / output candidates; the program
                # count by source + dependencies is verified_programs_by_source
                "unique_name_output_candidates": len(uniq),
                "distinct_test_predictions": sum(len(v) for v in preds.values()),
                # H6-9: the old field counted distinct predictions; both are reported now
                "verified_programs_by_source": sum(len(v) for v in progs.values()),
                "verified_programs_per_task": {t: len(v) for t, v in sorted(progs.items())},
                "distinct_predictions_per_task": {t: len(v) for t, v in sorted(preds.items())},
                "overfit_flags": flags, "overfit_flags_counted_on": "unique programs",
                "tasks_with_two_branch_candidates": len(both), "tasks_where_branches_agree": agree,
                "branch1_yield_by_stage2_class": b1,
                "overshoot_p50": q(osh, .5), "overshoot_max": max(osh) if osh else None,
                "stage2_resume_uncached_p50": q(rp, .5), "stage2_resume_uncached_p90": q(rp, .9),
                "prompt_estimate_over_actual_p50": round(q(pe, .5), 3) if pe else None,
                "uncached_prompt_tokens": sum(int(u.get("prompt") or 0) - int(u.get("cached") or 0) for u in us),
                "generated_tokens": sum(int(r.get("generated_tokens") or 0) for r in rows),
                "real_running_max": max((int(k) for k, v in rh.items() if v), default=None) if rh else None,
                "accept_len_median": dec.get("accept_len_median"),
                "fair_share_last": ((E12_RUN.get("rev6_scheduler") or {}).get("shares") or [None])[-1],
                **_r6e_metrics(rows, ev, b1, us)}

    def _r6e_metrics(rows, ev, b1, us):   # rev 6e: G4-14 / G4-15 / G4-18 (label-free, no truth)
        import statistics as _st
        med = lambda v: round(_st.median(v), 1) if v else None
        n = len(rows)
        ftt = [e.get("first_transform_tokens") for e in ev]
        obs = [x for x in ftt if x is not None]
        cens = [x if x is not None else int(r.get("generated_tokens") or 0) for x, r in zip(ftt, rows)]
        best = {}
        for r in rows:
            b = ((r.get("progress") or {}).get("best") or {})
            k = f"{b.get('k')}/{b.get('n')}" if b else "none"
            best[k] = best.get(k, 0) + 1
        b1_tok = sum(c["tokens"] for c in b1.values())
        b1_new = sum(c["new_distinct_verified"] for c in b1.values())
        reqs = [q for r in rows for q in (r.get("requests") or [])]
        later = [q for q in reqs if q.get("i", 0) > 0 and q.get("prompt")]
        zero = [q for q in later if not q.get("cached")]
        runs2 = [x for r in rows for x in (r.get("runs") or []) if x.get("stage") == 2]

        def _yield(sel):   # H6-14 / H7-3: new verified predictions per 100k generated tokens (all / b0 / b1, by stage)
            rr = [(x, r) for r in rows for x in (r.get("runs") or []) if sel(x, r)]
            tok = sum(int(x.get("tokens") or 0) for x, _ in rr)
            nb = sum(int(x.get("new_in_branch") or 0) for x, _ in rr)
            nt = sum(int(x.get("new_for_task") or 0) for x, _ in rr)
            return {"runs": len(rr), "tokens": tok, "new_in_branch": nb, "new_for_task": nt,
                    "per_100k_for_task": round(1e5 * nt / tok, 3) if tok else None,
                    "per_100k_in_branch": round(1e5 * nb / tok, 3) if tok else None}
        nud = [(e, r) for e, r in zip(ev, rows) if e.get("provisional_nudge_tokens") is not None]
        gap = lambda k: [e[k] - e["provisional_nudge_tokens"] for e, _ in nud if e.get(k) is not None]
        return {
            # H6-14 (GPT rev 6e audits): the allocation question is decided on these
            "verified_yield": {"all": _yield(lambda x, r: True), "b0": _yield(lambda x, r: r.get("branch") == 0),
                               "b1": _yield(lambda x, r: r.get("branch") == 1),
                               "stage1": _yield(lambda x, r: x.get("stage") == 1),
                               "stage2": _yield(lambda x, r: x.get("stage") == 2)},
            # H6-18: nudge efficacy (H6-1: sent in a tool result at 24k, else in an opener)
            "nudge": {"branches": len(nud), "via": {k: sum(1 for e, _ in nud if e.get("provisional_nudge_via") == k)
                                                     for k in ("tool", "opener")},
                      # H7-10: emitted (above) vs seen by the model in a later request
                      "seen": sum(1 for e, _ in nud if e.get("provisional_nudge_seen_request") is not None),
                      "emitted_not_seen": sum(1 for e, _ in nud if e.get("provisional_nudge_seen_request") is None),
                      "tokens_p50": med([e["provisional_nudge_tokens"] for e, _ in nud]),
                      "transform_after": len(gap("first_transform_after_nudge")),
                      "tokens_to_transform_p50": med(gap("first_transform_after_nudge")),
                      "check_after": len(gap("first_check_after_nudge")),
                      "tokens_to_check_p50": med(gap("first_check_after_nudge")),
                      "accepted": sum(1 for _, r in nud if r.get("accepted")
                                      or any(v.get("accepted") for v in (r.get("checked") or [])))},
            "progress_same_name_new_source": sum(int(e.get("progress_same_name_new_source") or 0) for e in ev),
            "indexed_view_over_target": sum(1 for e in ev if e.get("view_over_target")),             # H7-8
            "tasks_with_response": len({r.get("task") for r in rows if r.get("branch") == 0
                                        and (r.get("generated_tokens") or 0) > 0}),                  # H7-7
            # G4-14
            "first_transform_tokens_median_observed": med(obs), "first_transform_tokens_median_censored": med(cens),
            "branches_with_transform": len(obs), "branches_with_transform_within_20k": sum(1 for x in obs if x <= 20000),
            "share_with_transform_within_20k": round(sum(1 for x in obs if x <= 20000) / n, 3) if n else None,
            "best_single_function_pairs": dict(sorted(best.items())),
            "b1_new_distinct_verified_per_100k_tokens": round(1e5 * b1_new / b1_tok, 3) if b1_tok else None,
            "provisional_nudges": sum(1 for e in ev if e.get("provisional_nudge_tokens") is not None),
            # G4-18
            "progress_reports": sum(int(e.get("progress_reports") or 0) for e in ev),
            "progress_same_improved": sum(int(e.get("progress_same_improved") or 0) for e in ev),
            "progress_new_hypothesis": sum(int(e.get("progress_new_hypothesis") or 0) for e in ev),
            "stage2_runs": len(runs2), "stage2_runs_improved": sum(1 for x in runs2 if x.get("improved")),
            # G4-15 (null prompt_tokens_details = 0 cached: SGLang 0.5.21 omits it when nothing was cached)
            "requests_instrumented": len(reqs), "later_requests": len(later), "later_zero_hit": len(zero),
            "later_zero_hit_prefix_intact": sum(1 for q in zero if q.get("prefix_ok")),
            "later_zero_hit_trimmed": sum(1 for q in zero if q.get("trimmed")),
            "later_zero_hit_idle_sec_p50": med([q["idle_sec"] for q in zero if q.get("idle_sec") is not None]),
            "later_idle_sec_p50": med([q["idle_sec"] for q in later if q.get("idle_sec") is not None]),
            "later_zero_hit_mamba_p50": med([q["mamba"] for q in zero if q.get("mamba") is not None]),
            "later_prefix_intact_share": round(sum(1 for q in later if q.get("prefix_ok")) / len(later), 3) if later else None,
            # H6-10: character-prefix share and tools / template changes for the zero-hit later requests (still a proxy)
            "later_zero_hit_char_prefix_full": sum(1 for q in zero if q.get("serialized_char_prefix") is not None
                                                   and q.get("prev_chars") and q["serialized_char_prefix"] >= q["prev_chars"] - 2),
            # H7-13 (GPT rev 6f audit 3): unexplained = the serialized prompt kept its prefix, tools / template unchanged,
            # not trimmed, and still 0 cached; otherwise the prompt changed (reason). A proxy, never proof of eviction
            "later_zero_hit_class": _zero_classes(zero),
            "later_zero_hit_tools_or_template_changed": sum(1 for q in zero if q.get("tools_same") is False
                                                            or q.get("template_same") is False),
            "cached_not_reported_requests": sum(1 for q in reqs if q.get("cached_reported") is False),
            "cache_null_detail_requests": sum(1 for u in us if u.get("cached") is None),
            "cache_note": "aggregate over all requests; a missing prompt_tokens_details means 0 cached (SGLang 0.5.21)",
            "concurrency": _r6e_concurrency()}

    def _zero_classes(zero):   # H7-13
        out = {}
        for q in zero:
            full = (q.get("serialized_char_prefix") is not None and q.get("prev_chars")
                    and q["serialized_char_prefix"] >= q["prev_chars"] - 2)
            if q.get("trimmed"):
                k = "prompt_changed:trimmed"
            elif q.get("tools_same") is False:
                k = "prompt_changed:tools"
            elif q.get("template_same") is False:
                k = "prompt_changed:template"
            elif not full:
                k = "prompt_changed:prefix"
            else:
                k = "unexplained_cache_miss"
            out[k] = out.get(k, 0) + 1
        return out

    def _r6e_concurrency():   # G4-15 / Q5: decode rate by running count, split by "a prefill batch ran just before"
        import re as _re, statistics as _st
        try:
            text = E11_SERVER.log_text() if E11_SERVER is not None else ""
        except Exception:
            return None
        g = lambda pat, ln: (lambda m: float(m.group(1)) if m else None)(_re.search(pat, ln))
        by, after = {}, False
        for ln in text.splitlines():
            if "TP0]" not in ln:
                continue
            if "Prefill batch" in ln:
                after = True
                continue
            if "Decode batch" not in ln:
                continue
            n = g(r"#running-req: (\d+)", ln)
            row = by.setdefault(str(int(n)) if n is not None else "?", {"lines": 0, "tok": [], "tok_after_prefill": [],
                                                                         "accept": [], "mamba": []})
            row["lines"] += 1
            t = g(r"gen throughput \(token/s\): ([\d.]+)", ln)
            if t is not None:
                (row["tok_after_prefill"] if after else row["tok"]).append(t)
            for k, pat in (("accept", r"accept len: ([\d.]+)"), ("mamba", r"mamba usage: ([\d.]+)")):
                v = g(pat, ln)
                if v is not None:
                    row[k].append(v)
            after = False
        m = lambda v: round(_st.median(v), 2) if v else None
        return {k: {"lines": v["lines"], "tok_s_p50_clean": m(v["tok"]), "tok_s_p50_after_prefill": m(v["tok_after_prefill"]),
                    "share_after_prefill": round(len(v["tok_after_prefill"]) / max(1, len(v["tok"]) + len(v["tok_after_prefill"])), 3),
                    "accept_len_p50": m(v["accept"]), "mamba_usage_p50": m(v["mamba"])}
                for k, v in sorted(by.items(), key=lambda kv: (len(kv[0]), kv[0]))}
    if _E12_REV6:
        report["rev6"] = {"metrics": _r6_metrics(branches), "scheduler": E12_RUN.get("rev6_scheduler"),
                          "window": E12_RUN.get("rev6_window"), "workers": E12_RUN.get("rev6_workers"),
                          "preflight": E12_RUN.get("rev6_preflight"), "g4b": E12_RUN.get("g4b"),
                          "parity": E12_RUN.get("parity"), "cache_diag": E12_RUN.get("cache_diag")}
    if SOLUTIONS is not None:
        hits = pass1 = pass2 = total = 0; task_norm = 0.0; recs_eval = []
        for t in TASK_IDS:
            th = 0
            for qi, att in enumerate(_gen[t]):
                gold = SOLUTIONS[t][qi]; a = att["attempt_1"] == gold; b = att["attempt_2"] == gold
                hits += a or b; pass1 += a; pass2 += b; total += 1; th += a or b
                acc = [s for r in _recs.get(t, []) for s in (r.get("submissions") or []) if s.get("accepted")]
                harv = [s for r in _recs.get(t, []) for s in (r.get("checked") or []) if s.get("accepted")]
                recs_eval.append({"task": t, "query": qi, "hit": bool(a or b), "pass1": bool(a), "pass2": bool(b),
                                  "accepted_programs": len(acc),
                                  "accepted_programs_correct": sum(1 for s in acc if qi < len(s.get("test_outputs") or [])
                                                                   and s["test_outputs"][qi] == gold),
                                  "harvested_programs": len(harv),
                                  "harvested_programs_correct": sum(1 for s in harv if qi < len(s.get("test_outputs") or [])
                                                                    and s["test_outputs"][qi] == gold)})
            task_norm += th / max(1, len(_gen[t]))
        report.update(eval_query_hits=hits, eval_query_total=total, eval_pass1_hits=pass1, eval_pass2_hits=pass2,
                      eval_task_norm_pct=round(100 * task_norm / max(1, len(TASK_IDS)), 2), eval_unit_records=recs_eval)
        try:    # E15B A2 (Exp 15 Notes/07): what each attempt found. A task counts for an attempt when that attempt has a
            # right output for EVERY test input: "acc" = among its host-accepted candidates, "any" = also partial ones
            def _e15b_has(r, qi, gold, acc_only):
                return any(qi < len(s.get("test_outputs") or []) and s["test_outputs"][qi] == gold
                           for s in (r.get("submissions") or []) + (r.get("checked") or []) if s.get("accepted") or not acc_only)
            _B_TOK = int(E15B["E12_B_ATTEMPT_TOKENS"]) if "E15B" in globals() else 35000
            _pa = dict.fromkeys(("tasks", "b1_started", "hit", "b0_acc", "b1_acc", "both_acc", "b0_only_acc", "b1_only_acc",
                                 "b0_any", "b1_any", "b1_only_any", "hit_without_b0_any", "b0_budget_partial",
                                 "b0_budget_partial_b1_acc"), 0)
            _rows = []
            for t in TASK_IDS:
                _rs = {r.get("branch"): r for r in _recs.get(t, [])}
                _golds = SOLUTIONS[t]
                _f = lambda b, acc: b in _rs and all(_e15b_has(_rs[b], qi, g, acc) for qi, g in enumerate(_golds))
                a0, a1, n0, n1 = _f(0, True), _f(1, True), _f(0, False), _f(1, False)
                hit = all(att["attempt_1"] == g or att["attempt_2"] == g for att, g in zip(_gen[t], _golds))
                r0 = _rs.get(0) or {}
                bp = (int(r0.get("generated_tokens") or 0) >= _B_TOK - 64
                      and not any(x.get("accepted") for x in (r0.get("submissions") or []) + (r0.get("checked") or []))
                      and (r0.get("rev6_events") or {}).get("first_transform_tokens") is not None)
                for k, v in (("tasks", True), ("b1_started", 1 in _rs), ("hit", hit), ("b0_acc", a0), ("b1_acc", a1),
                             ("both_acc", a0 and a1), ("b0_only_acc", a0 and not a1), ("b1_only_acc", a1 and not a0),
                             ("b0_any", n0), ("b1_any", n1), ("b1_only_any", n1 and not n0),
                             ("hit_without_b0_any", hit and not n0), ("b0_budget_partial", bp),
                             ("b0_budget_partial_b1_acc", bp and a1)):
                    _pa[k] += int(bool(v))
                _rows.append({"task": t, "hit": hit, "b0_acc": a0, "b1_acc": a1, "b0_any": n0, "b1_any": n1,
                              "b0_budget_partial": bp, "b0_tokens": r0.get("generated_tokens"),
                              "b1_tokens": (_rs.get(1) or {}).get("generated_tokens")})
            report["eval_b_attempts"] = dict(_pa, rows=_rows)
            # rev 3i: what stage 3 added (a task hit whose only right accepted answer came from attempt 3+)
            _x = {"tasks_with_attempt3plus": 0, "attempt3plus_acc_tasks": 0, "hit_only_from_attempt3plus": 0}
            for t in TASK_IDS:
                _rs = {r.get("branch"): r for r in _recs.get(t, [])}
                _golds = SOLUTIONS[t]
                _ok = lambda b: b in _rs and all(_e15b_has(_rs[b], qi, g, True) for qi, g in enumerate(_golds))
                _hi = [b for b in _rs if (b or 0) >= 2]
                if _hi:
                    _x["tasks_with_attempt3plus"] += 1
                    if any(_ok(b) for b in _hi):
                        _x["attempt3plus_acc_tasks"] += 1
                        if not _ok(0) and not _ok(1):
                            _x["hit_only_from_attempt3plus"] += 1
            report["eval_b_attempts"].update(_x)
            print("E15B stage 3 (eval):", json.dumps(_x), flush=True)
            print("E15B attempts (eval):", json.dumps(_pa), flush=True)
        except Exception as _e:
            report["eval_b_attempts"] = {"error": repr(_e)[:300]}
    try:
        report["e11"] = {"decode_summary": e11_decode_summary(),
                         "shim": engine.stats if isinstance(getattr(engine, "stats", None), dict) else None,
                         "server_log": str(E11_SERVER.log_path) if E11_SERVER is not None else None}
    except Exception as _e11e:
        report["e11"] = {"error": repr(_e11e)[:300]}
    if _E12_REV6 and isinstance(report.get("rev6"), dict):      # rev 6g H7-12 (GPT rev 6f audit 2): per GPU-hour
        try:
            _gh = 4 * max(1, (E12_RUN.get("finished_sec") or 0) - (E12_RUN.get("started_sec") or 0)) / 3600.0
            _solved = len({u["task"] for u in (report.get("eval_unit_records") or [])}
                          - {u["task"] for u in (report.get("eval_unit_records") or []) if not u.get("hit")})
            _yt = (((report["rev6"].get("metrics") or {}).get("verified_yield") or {}).get("all") or {}).get("new_for_task")
            report["rev6"]["per_gpu_hour"] = {
                "gpu_hours": round(_gh, 3),
                "correct_inputs": round(report["eval_query_hits"] / _gh, 3) if report.get("eval_query_hits") is not None else None,
                "tasks_solved": round(_solved / _gh, 3) if report.get("eval_unit_records") else None,
                "new_for_task_predictions": round(_yt / _gh, 3) if _yt is not None else None}
        except Exception as _e:
            report["rev6"]["per_gpu_hour"] = {"error": repr(_e)[:200]}
    write_json_atomic(OUT / "e12_run_report.json", report)
    if _E12_REV6:
        print("E12 rev 6 metrics:", json.dumps(report["rev6"]["metrics"])[:1500], flush=True)
        _sc = report["rev6"].get("scheduler") or {}
        # A3-F4 (rev 6c audits): full coverage is claimed only when stage1_left == 0
        print("E12 rev 6 coverage: tasks initialized", _sc.get("tasks_initialized"), "| request sent",
              _sc.get("tasks_with_request_sent"), "| response", (report["rev6"].get("metrics") or {}).get("tasks_with_response"),
              "/", len(TASK_IDS), "| stage-1 starts left",
              _sc.get("stage1_left"), "| workers", report["rev6"].get("workers"), "(fixed)", "| KV holds", _sc.get("kv_holds"),
              "for", _sc.get("kv_hold_sec"), "s | idle overrides", _sc.get("kv_idle_overrides"),
              "| KV samples", _sc.get("kv_samples"), "missing", _sc.get("kv_missing"),
              "| stragglers", _sc.get("stragglers"), flush=True)
    print("E12 RUN REPORT:", OUT / "e12_run_report.json", "| eval", report.get("eval_query_hits"), "/", report.get("eval_query_total"),
          "| task-norm", report.get("eval_task_norm_pct"), "| accepted branches", E12_RUN["branches_accepted"],
          "| cached", report["usage_all"].get("cached_pct"), "%", flush=True)
    e12_write_submission()
    _pack = WORKING / "Q27X_E12_DUCK_BUNDLE.zip"
    with zipfile.ZipFile(_pack, "w", zipfile.ZIP_DEFLATED) as z:
        for fp in (SUBMISSION_PATH, OUT / "e12_run_report.json", OUT / "e12_generated_attempts.json",
                   OUT / "sglang_decode_summary.json", OUT / "sglang_requests.jsonl"):
            if fp.exists():
                z.write(fp, arcname=fp.name)
        for fp in sorted(E12_OUT.rglob("*")):     # transcripts (full thinking) + branch results
            if fp.is_file() and (fp.name in ("transcript.txt", "branch_result.json") or fp.name.endswith("requests.jsonl")):
                z.write(fp, arcname="duck/" + fp.relative_to(E12_OUT).as_posix())
        if E11_SERVER is not None and E11_SERVER.log_path.exists():
            z.write(E11_SERVER.log_path, arcname=E11_SERVER.log_path.name)
    print("E12 bundle:", _pack, round(_pack.stat().st_size / 1e6, 1), "MB", flush=True)
except BaseException:
    print("E12 reporting error (submission.json still exists):", traceback.format_exc()[-3000:], flush=True)
try:
    e11_kill_server(wait=False)
except Exception:
    pass
