# VMS — vLLM 0.32.0 engine-config matrix (Qwen3.8-27B on 4x L4), engine only

The vLLM twin of the EMS (SGLang) notebook: every vLLM configuration worth testing for 600-800 tok/s, each its own
server launch. Reference = the S1-60K engine (LB 34.58): FP8 block-128, fp8 KV, MTP 3, FLASHINFER, prefix caching,
16 seqs. Arms: the oracle (FP8 target-only, prefix caching off); MTP 2 / 4; 20 / 24 seqs; SSM state fp16; prefix
caching off; --linear-backend triton (Marlin = the auto default on SM 8.9); INT4 (RedHat compressed-tensors) + MTP at 16 and 20 after a static MTP
check; last, 2 x TP2 (data parallel 2 x tensor parallel 2) from a reserved slot.
Each arm: a greedy correctness gate vs the oracle's own A/A (rev 2; INT4 arms diagnostic: other weights) with a
degenerate-output count, then 8k and 40k steady windows measured from /metrics. Report `q27x/vms/vms_report.md`, bundle `Q27X_VMS_BUNDLE.zip`.

**Inputs:** competition data; the FP8 repack and the RedHat INT4 models; the vLLM 0.32.0 wheelhouse
(`foysalemonshanto/vllm-0-32-0-cu13-wheelhouse`); the vLLM 0.19 wheelhouse (only the kernel's tokenizer pins); the
SGLang wheelhouse is NOT needed; the payload dataset (E14 modules).
