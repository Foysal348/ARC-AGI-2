"""E21 rev 2d: the deeper second pass over GPT audits 1-3 + the 10 agent reports (items rev 2c still missed)."""
from pathlib import Path

BD = Path(r"D:/ARC AGI 2/experiments/Experiment 21 - Duck config B on vLLM 0.19 + 0.32 (planned)/Experiment Notebooks/Build")
e = (BD / "e21_engine_new.py").read_text(encoding="utf-8")
b = (BD / "build_e21.py").read_text(encoding="utf-8")


def repe(x, y):
    global e
    assert e.count(x) == 1, (x[:90], e.count(x))
    e = e.replace(x, y)


def repb(x, y):
    global b
    assert b.count(x) == 1, (x[:90], b.count(x))
    b = b.replace(x, y)


# 1. GPT audit 3: the contract probe uses Duck's REAL tool definition (tool_agent._tools + arc2's description), not a stub
repe('''E21_PROBE_TOOLS = [{"type": "function", "function": {"name": "python", "description": "Run Python code and return stdout.",
                    "parameters": {"type": "object", "properties": {"code": {"type": "string"}}, "required": ["code"]}}}]''',
     '''# rev 2d (GPT audit 3): Duck's own tool definition = tool_agent.ToolAgent._tools() with arc2's description
# (arc2_duck.py 1572), so the probe exercises the exact schema the Duck sends
E21_PROBE_TOOLS = [{"type": "function", "function": {"name": "python", "description": E12A.ARC2_TOOL_DESCRIPTION,
                    "parameters": {"type": "object", "properties": {"code": {"type": "string", "description": (
                        "Python code to run. The snippet is ephemeral and is not saved across tool calls.")}},
                        "required": ["code"]}}}]''')
# 2. GPT audits 2-3 (#53912 hybrid MTP + prefix-cache silent corruption): the cache probe compares longer greedy outputs
repe('''        body = {"model": served, "messages": msgs, "temperature": 0.0, "max_tokens": 24,''',
     '''        body = {"model": served, "messages": msgs, "temperature": 0.0, "max_tokens": 96,''')
# 3. GPT audit 2 handoff: after half A's server is gone its Duck workers fail fast; wait (bounded) until they are gone
repe('''        st["end_sec"] = round(time.perf_counter() - NOTEBOOK_T0)
        print(f"E21 half {H} ended at {st['end_sec']} s | GPU release", json.dumps(st.get("gpu_release")), flush=True)''',
     '''        if not last:     # rev 2d (GPT audit 2): a clean handoff, bounded; counted, never assumed
            _w0 = time.perf_counter()
            while e21_scheduler_threads() and time.perf_counter() - _w0 < 120:
                time.sleep(2)
            st["handoff_scheduler_threads_left"] = e21_scheduler_threads()
            st["handoff_wait_sec"] = round(time.perf_counter() - _w0, 1)
        st["end_sec"] = round(time.perf_counter() - NOTEBOOK_T0)
        print(f"E21 half {H} ended at {st['end_sec']} s | GPU release", json.dumps(st.get("gpu_release")),
              "| scheduler threads left", st.get("handoff_scheduler_threads_left"), flush=True)''')
repe('''def e21_end_half(H):''',
     '''def e21_scheduler_threads():
    """Duck scheduler threads still alive (solve_all_r6's worker / probe_loop closures)."""
    n = 0
    for th in threading.enumerate():
        q = getattr(getattr(th, "_target", None), "__qualname__", "") or ""
        if th.is_alive() and q.startswith("solve_all_r6.<locals>."):
            n += 1
    return n


def e21_end_half(H):''')
# 4. GPU-release failure injection for the CPU harness (GPT audit 1 HIGH-5 regression test)
repe('''    rel = _wait_gpu_release()
    if not rel.get("released") and not E21_FAKE:''',
     '''    if E21_FAKE and os.environ.get("E21_FAKE_GPU_HELD") == "1":            # harness only: GPUs never released
        ENGINE_INFO.setdefault("gpu_checks", []).append({"released": False, "tag": tag, "fake_held": True})
        return False
    rel = _wait_gpu_release()
    if not rel.get("released") and not E21_FAKE:''')
(BD / "e21_engine_new.py").write_text(e, encoding="utf-8", newline="\n")

# 5. GPT audit 1 HIGH-4 follow-up: a /metrics outage blocks admissions only for a bounded time (else one stream forever)
repb('''        E21_STATE["probe_failures"] = E21_STATE.get("probe_failures", 0) + 1
        return {"kv_usage": 1.0, "running": None, "queue": None, "mamba_usage": None, "probe_failed": True}''',
     '''        E21_STATE["probe_failures"] = E21_STATE.get("probe_failures", 0) + 1
        _t0 = E21_STATE.setdefault("probe_fail_since", time.monotonic())
        if time.monotonic() - _t0 > 120:     # rev 2d: a long outage -> Duck's own fail-open (counted), not 1 stream forever
            E21_STATE["probe_fail_open"] = E21_STATE.get("probe_fail_open", 0) + 1
            return {"kv_usage": None, "running": None, "queue": None, "mamba_usage": None, "probe_failed": True}
        return {"kv_usage": 1.0, "running": None, "queue": None, "mamba_usage": None, "probe_failed": True}
    E21_STATE.pop("probe_fail_since", None)''')

# 6. GPU smoke variants (user 2026-10-28: CPU audit -> GPU smoke on the user's account -> full run): the same notebook
#    with profile E21SMOKE: 12 evaluation tasks, a 20-min window per half, 2 h budget; RERUN unchanged
repb('''    "E14SEVAL120G4B": {\'\'\')''', '''    # rev 2d: the GPU smoke (both halves, real loads, probes, ~2 h): 12 evaluation tasks, a 20-min window per half
    "E21SMOKE": {"source": "eval", "n_tasks": 12, "time_budget_sec": 2.0 * 3600, "admit_frac": 0.90,
                 "drain_frac": 0.94, "hard_margin_sec": 2 * 60, "verify_margin_sec": 1 * 60,
                 "drain_margin_sec": 8 * 60, "admit_margin_sec": 2 * 60, "solve_window_sec": 20 * 60},
    "E14SEVAL120G4B": {\'\'\')''')
repb('''assert PROFILE in ("E21X2EVAL120", "RERUN_ALL") or os.environ.get("E21_ANY_PROFILE") == "1", PROFILE''',
     '''assert PROFILE in ("E21X2EVAL120", "E21SMOKE", "RERUN_ALL") or os.environ.get("E21_ANY_PROFILE") == "1", PROFILE''')
repb('''def cell1(variant):
    c = E15B[2]
    c = rep(c, 'os.environ.get("Q27X_PROFILE", "E15BEVAL120R3I")', 'os.environ.get("Q27X_PROFILE", "E21X2EVAL120")')''',
     '''def cell1(variant, profile="E21X2EVAL120"):
    c = E15B[2]
    c = rep(c, 'os.environ.get("Q27X_PROFILE", "E15BEVAL120R3I")', f'os.environ.get("Q27X_PROFILE", "{profile}")')''')
repb('''VARIANTS = {"NB1": "Q27-XHIGH-E21_DUCKB_VLLM_NB1_INT4_S20.ipynb", "NB2": "Q27-XHIGH-E21_DUCKB_VLLM_NB2_FP8_SSM16_S16.ipynb"}''',
     '''VARIANTS = {"NB1": "Q27-XHIGH-E21_DUCKB_VLLM_NB1_INT4_S20.ipynb", "NB2": "Q27-XHIGH-E21_DUCKB_VLLM_NB2_FP8_SSM16_S16.ipynb",
            "NB1SMOKE": "Q27-XHIGH-E21_DUCKB_VLLM_NB1_INT4_S20_SMOKE.ipynb",
            "NB2SMOKE": "Q27-XHIGH-E21_DUCKB_VLLM_NB2_FP8_SSM16_S16_SMOKE.ipynb"}''')
repb('''def build(variant):''', '''def build(name):
    variant, profile = (name[:3], "E21SMOKE") if name.endswith("SMOKE") else (name, "E21X2EVAL120")
    return _build(variant, profile, VARIANTS[name])


def _build(variant, profile, out_name):''')
repb('''             ("code", cell1(variant)),''', '''             ("code", cell1(variant, profile)),''')
repb('''    out = NBDIR / VARIANTS[variant]''', '''    out = NBDIR / out_name''')
repb('''    for v in (sys.argv[1:] or ["NB1", "NB2"]):''', '''    for v in (sys.argv[1:] or ["NB1", "NB2", "NB1SMOKE", "NB2SMOKE"]):''')
(BD / "build_e21.py").write_text(b, encoding="utf-8", newline="\n")
print("rev 2d patched")
