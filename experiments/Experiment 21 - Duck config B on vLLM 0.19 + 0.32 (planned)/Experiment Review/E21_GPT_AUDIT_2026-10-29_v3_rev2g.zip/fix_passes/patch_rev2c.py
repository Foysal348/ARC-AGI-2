"""E21 rev 2c: the three GPT audits (2026-10-28) on top of rev 2b. Each claim was checked on the source first."""
from pathlib import Path

BD = Path(r"D:/ARC AGI 2/experiments/Experiment 21 - Duck config B on vLLM 0.19 + 0.32 (planned)/Experiment Notebooks/Build")
b = (BD / "build_e21.py").read_text(encoding="utf-8")


def repb(x, y):
    global b
    assert b.count(x) == 1, (x[:90], b.count(x))
    b = b.replace(x, y)


# ---- CELL 6 patches (inside cell6(), applied to the donor text before wrapping)
CB_OLD = '''def _e12_branch_done_r6(rec):   # rev 6: a branch reports every pause and its finish; keep the latest per branch
    with _E12_LOCK:
        rows = E12_RECORDS.setdefault(rec["task_id"], [])
        # rev 6g H7-1 (GPT rev 6f audits): callbacks can finish out of order; never let an older record replace a newer one
        _old = next((r for r in rows if r.get("branch") == rec.get("branch")), None)
        if _old is not None and int(rec.get("publish_seq") or 0) <= int(_old.get("publish_seq") or 0):
            E12_RUN["stale_callbacks_dropped"] = E12_RUN.get("stale_callbacks_dropped", 0) + 1
            return
        new = rec.get("branch") not in {r.get("branch") for r in rows}
        rows[:] = [r for r in rows if r.get("branch") != rec.get("branch")] + [rec]
        E12_RUN["branches_started"] = E12_RUN.get("branches_started", 0) + int(new)
        E12_RUN["branches_done"] = sum(1 for v in E12_RECORDS.values() for r in v if r.get("status") == "done")
        E12_RUN["branches_accepted"] = sum(1 for v in E12_RECORDS.values() for r in v if r.get("accepted"))
    if time.perf_counter() >= globals().get("E15B_SOLVE_END_PC", float("inf")):'''
CB_NEW = '''def _e12_branch_done_r6(rec, _recs=E12_RECORDS, _run=E12_RUN, _lock=_E12_LOCK, _half=E21_HALF):
    # rev 6: a branch reports every pause and its finish; keep the latest per branch.
    # E21 rev 2c (GPT audits 1-3, CRITICAL, reproduced on this source): the callback is bound to ITS half's records, run
    # state and lock (default arguments, evaluated when this half's CELL 6 defines it). A half-A worker that is still
    # alive (a straggler past join grace) can never write into half B's records, and never writes half B's submission.
    with _lock:
        rows = _recs.setdefault(rec["task_id"], [])
        # rev 6g H7-1 (GPT rev 6f audits): callbacks can finish out of order; never let an older record replace a newer one
        _old = next((r for r in rows if r.get("branch") == rec.get("branch")), None)
        if _old is not None and int(rec.get("publish_seq") or 0) <= int(_old.get("publish_seq") or 0):
            _run["stale_callbacks_dropped"] = _run.get("stale_callbacks_dropped", 0) + 1
            return
        new = rec.get("branch") not in {r.get("branch") for r in rows}
        rows[:] = [r for r in rows if r.get("branch") != rec.get("branch")] + [rec]
        _run["branches_started"] = _run.get("branches_started", 0) + int(new)
        _run["branches_done"] = sum(1 for v in _recs.values() for r in v if r.get("status") == "done")
        _run["branches_accepted"] = sum(1 for v in _recs.values() for r in v if r.get("accepted"))
    if _half != E21_HALF:
        _run["late_cross_half_callbacks"] = _run.get("late_cross_half_callbacks", 0) + 1
        return
    if time.perf_counter() >= globals().get("E15B_SOLVE_END_PC", float("inf")):'''
CB_OLD2 = '''        E12_RUN["late_writes_skipped"] = E12_RUN.get("late_writes_skipped", 0) + 1     # E15B B1
        return'''
CB_NEW2 = '''        _run["late_writes_skipped"] = _run.get("late_writes_skipped", 0) + 1     # E15B B1
        return'''
HB_OLD = '''def _e12_heartbeat(every=300):
    while not _E12_STOP.wait(every):'''
HB_NEW = '''def _e12_heartbeat(every=300, _stop=_E12_STOP):     # E21 rev 2c: bound to this half's stop event (GPT audit 1)
    while not _stop.wait(every):'''
HB_START_OLD = '''        threading.Thread(target=_e12_heartbeat, daemon=True).start()'''
HB_START_NEW = '''        threading.Thread(target=_e12_heartbeat, daemon=True, name="e12_heartbeat").start()'''
SCHED_OLD = '''        E12_RUN["rev6_scheduler"] = dict(E12A.SCHED_LAST)'''
SCHED_NEW = '''        E12_RUN["rev6_scheduler"] = dict(E12A.SCHED_LAST)
        # E21 rev 2c (GPT audits 1-2): the deadline contract as evidence (planned solve end vs when the solver returned)
        E12_RUN["solve_overrun_sec"] = round(max(0.0, time.perf_counter() - _e15b_solve_end), 1)
        E12_RUN["planned_solve_end_sec"] = round(_e15b_solve_end - NOTEBOOK_T0, 1)
        E12_RUN["stragglers"] = (E12_RUN["rev6_scheduler"] or {}).get("stragglers")
        if E12_RUN["solve_overrun_sec"] > 120:
            E12_RUN["deadline_violation"] = True
            print("E21 WARNING: the solver returned", E12_RUN["solve_overrun_sec"], "s after its deadline", flush=True)'''
repb('''def cell6():
    c = E15B[9]''', '''def cell6():
    c = E15B[9]
    for _o, _n in ((CB_OLD, CB_NEW), (CB_OLD2, CB_NEW2), (HB_OLD, HB_NEW), (HB_START_OLD, HB_START_NEW),
                   (SCHED_OLD, SCHED_NEW)):
        c = rep(c, _o, _n)''')
repb('''NEW_PROBE = \'\'\'''', '\n'.join([f"{k} = {v!r}" for k, v in (("CB_OLD", CB_OLD), ("CB_NEW", CB_NEW), ("CB_OLD2", CB_OLD2),
                                                                 ("CB_NEW2", CB_NEW2), ("HB_OLD", HB_OLD), ("HB_NEW", HB_NEW),
                                                                 ("HB_START_OLD", HB_START_OLD), ("HB_START_NEW", HB_START_NEW),
                                                                 ("SCHED_OLD", SCHED_OLD), ("SCHED_NEW", SCHED_NEW))])
     + "\n\n\nNEW_PROBE = '''")

# KV probe: a failed /metrics read blocks admissions while work runs (Duck's idle override admits when nothing runs)
repb('''    try:
        rows = [r for r in e21_prom() if getattr(r, "value", None) is not None]
    except Exception:
        rows = []
    pick = lambda name: [float(r.value) for r in rows if r.name == name]''',
     '''    try:
        rows = [r for r in e21_prom() if getattr(r, "value", None) is not None]
    except Exception:
        rows = None
    if not rows:
        # E21 rev 2c (GPT audit 1 HIGH-4): Duck's KV gate admits on a missing sample (fail-open). On vLLM a failed
        # /metrics read while requests run means "unknown", so report a full pool: admissions wait; with nothing
        # running Duck's idle override still admits (no deadlock); the watchdog handles a dead server.
        E21_STATE["probe_failures"] = E21_STATE.get("probe_failures", 0) + 1
        return {"kv_usage": 1.0, "running": None, "queue": None, "mamba_usage": None, "probe_failed": True}
    pick = lambda name: [float(r.value) for r in rows if r.name == name]''')

# Watchdog: bound to this half's stop event / run state / half id (GPT audit 1 BLOCKER 1)
repb('''        def _e15b_watchdog():
            # E21: the E15B watchdog on vLLM''', '''        _wd_stop, _wd_run, _wd_half = _E12_STOP, E12_RUN, E21_HALF     # E21 rev 2c: this half's objects

        def _e15b_watchdog():
            # E21: the E15B watchdog on vLLM''')
repb('''            _bad, _sz_last = None, {}
            _wd = E12_RUN["watchdog"]
            while not _E12_STOP.wait(_WD_POLL):
                _srv = E11_SERVER''', '''            _bad, _sz_last = None, {}
            _wd = _wd_run["watchdog"]
            while not _wd_stop.wait(_WD_POLL):
                if E21_HALF != _wd_half:          # rev 2c: a half-A watchdog never acts in half B
                    return
                _srv = E11_SERVER''')
b = b.replace('''                        E12_RUN["watchdog"]["health_fail_sec_max"] = max(E12_RUN["watchdog"]["health_fail_sec_max"],''',
              '''                        _wd["health_fail_sec_max"] = max(_wd["health_fail_sec_max"],''')
for o, n in (('''                if len(E12_RUN["watchdog"]["relaunches"]) >= 2 or _left < _WD_MIN_LEFT:''',
              '''                if len(_wd["relaunches"]) >= 2 or _left < _WD_MIN_LEFT:'''),
             ('''                    E12_RUN["watchdog"]["relaunches"].append(_rec)
                    print("E15B watchdog: server down, no relaunch:", json.dumps(_rec), flush=True)''',
              '''                    _wd["relaunches"].append(_rec)
                    print("E15B watchdog: server down, no relaunch:", json.dumps(_rec), flush=True)'''),
             ('''                    E12A.SERVER_DOWN.clear()
                    E12_RUN["watchdog"]["relaunches"].append(_rec)''',
              '''                    E12A.SERVER_DOWN.clear()
                    _wd["relaunches"].append(_rec)''')):
    repb(o, n)

# Report: planned end, overrun, stragglers, comparison validity / fallback status
repb('''            "gpu_checks": _eng.get("gpu_checks"),''',
     '''            "gpu_checks": _eng.get("gpu_checks"),
            "planned_end_sec": _eng.get("end_pc_in_sec"), "planned_solve_end_sec": _run.get("planned_solve_end_sec"),
            "solve_overrun_sec": _run.get("solve_overrun_sec"), "deadline_violation": _run.get("deadline_violation"),
            "stragglers": _run.get("stragglers"), "late_cross_half_callbacks": _run.get("late_cross_half_callbacks"),
            "lmo_in_log": next((a.get("lmo_in_log") for a in reversed(_eng.get("attempts") or []) if "lmo_in_log" in a), None),''')
repb('''    E21_REPORT["windows_sec"] = _ws''',
     '''    E21_REPORT["windows_sec"] = _ws
    # rev 2c (GPT audits 1/3): the comparison is valid only with equal windows (1 %) and the same config in both halves
    _used = {H: (h.get("config_used"), json.dumps((E21_STATE["halves"].get(H, {}).get("engine") or {}).get("cfg"),
                                                     sort_keys=True)) for H, h in E21_REPORT["halves"].items()}
    _cfgs = {json.loads(v[1]).get("weights") if v[1] != "null" else None for v in _used.values()}
    E21_REPORT["config_status"] = ("NOT_RUN" if any(v[0] is None for v in _used.values()) else
                                   "PRIMARY_BOTH" if all(v[0] == "primary" for v in _used.values()) else
                                   "FALLBACK_BOTH" if all(v[0] == "fallback" for v in _used.values()) else
                                   "CONFOUNDED_FALLBACK")
    E21_REPORT["comparison_valid"] = (len(_ws) == 2 and max(_ws) - min(_ws) <= 0.01 * max(_ws)
                                      and E21_REPORT["config_status"] in ("PRIMARY_BOTH", "FALLBACK_BOTH")
                                      and not any(h.get("deadline_violation") for h in E21_REPORT["halves"].values()))''')
(BD / "build_e21.py").write_text(b, encoding="utf-8", newline="\n")

# ---- engine: the effective text-only check; join the heartbeat thread too
e = (BD / "e21_engine_new.py").read_text(encoding="utf-8")


def repe(x, y):
    global e
    assert e.count(x) == 1, (x[:90], e.count(x))
    e = e.replace(x, y)


repe('''        info["capacity"] = e21_capacity(srv.log_text(), cfg["seqs"])''',
     '''        info["capacity"] = e21_capacity(srv.log_text(), cfg["seqs"])
        # rev 2c (GPT audit 3): the engine really runs text-only (the non-default-args line of both versions)
        info["lmo_in_log"] = "'language_model_only': True" in srv.log_text()''')
repe('''            if th.name == "e15b_watchdog" and th is not threading.current_thread():
                th.join(timeout=30)
                st["watchdog_alive_after_join"] = th.is_alive()''',
     '''            if th.name in ("e15b_watchdog", "e12_heartbeat") and th is not threading.current_thread():
                th.join(timeout=30)
                st[th.name + "_alive_after_join"] = th.is_alive()''')
(BD / "e21_engine_new.py").write_text(e, encoding="utf-8", newline="\n")
print("rev 2c patched")
