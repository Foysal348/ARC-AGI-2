"""E21 rev 2g: VAL2_engine F1 (second-relaunch switch to other weights -> served-name 404) + F10 (smoke rejects "4.")."""
from pathlib import Path

BD = Path(r"D:/ARC AGI 2/experiments/Experiment 21 - Duck config B on vLLM 0.19 + 0.32 (planned)/Experiment Notebooks/Build")
e = (BD / "e21_engine_new.py").read_text(encoding="utf-8")


def repe(x, y):
    global e
    assert e.count(x) == 1, (x[:90], e.count(x))
    e = e.replace(x, y)


# F1: Duck's model_id is the first server's served name, which follows the weights; switch only to a config with the
# same weights (NB1: INT4 <-> FP8 never switches, it relaunches the same config)
repe('''if c != cfg]''',
     '''if c != cfg
                and c.get("weights") == (cfg or {}).get("weights")]   # rev 2g (VAL2_engine F1): same served name''')
# F10: a correct short answer ("4", "4.") has <= 2 distinct characters; only long single-character runs are degenerate
repe('''and len(set(gen.replace(" ", ""))) > 2''',
     '''and not (len(gen) >= 8 and len(set(gen.replace(" ", ""))) <= 2)   # rev 2g (VAL2_engine F10)''')
(BD / "e21_engine_new.py").write_text(e, encoding="utf-8", newline="\n")
print("rev 2g patched")
