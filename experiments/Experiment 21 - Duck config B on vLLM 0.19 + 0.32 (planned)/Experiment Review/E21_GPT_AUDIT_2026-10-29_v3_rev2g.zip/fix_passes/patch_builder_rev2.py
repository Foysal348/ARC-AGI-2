"""E21 rev 2: apply the validation-report fixes to build_e21.py (anchored, each anchor must match exactly once)."""
from pathlib import Path

p = Path(r"D:/ARC AGI 2/experiments/Experiment 21 - Duck config B on vLLM 0.19 + 0.32 (planned)/Experiment Notebooks/Build/build_e21.py")
s = p.read_text(encoding="utf-8")


def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (a[:80], s.count(a))
    s = s.replace(a, b)


Q3 = "'" * 3
BS = "\\"

# ---- CELL 1: NB1 stages both weights; follows-A flag; asserts; CONFIG truth
rep('E21_STAGE_PATHS = [{"SGL_MODEL_PATH" if nb1 else "MODEL_PATH"}]        # the weights both halves load (NB1 INT4, NB2 FP8)',
    'E21_STAGE_PATHS = [{"SGL_MODEL_PATH, MODEL_PATH" if nb1 else "MODEL_PATH"}]   # rev 2: NB1 stages its FP8 fallback too (VAL_engine_A2 H2)')
rep('E21_LAUNCH_TIMEOUT_SEC = 30 * 60\n',
    'E21_LAUNCH_TIMEOUT_SEC = 30 * 60\n'
    'E21_B_FOLLOWS_A = True                       # user option (ka): a half-A fallback config is repeated in half B\n'
    'assert PROFILE in ("E21X2EVAL120", "RERUN_ALL") or os.environ.get("E21_ANY_PROFILE") == "1", PROFILE   # rev 2 (E1 LOW-5)\n'
    'assert RERUN or len(E21_HALVES) == 1 or (E12_SOLVE_WINDOW_SEC or 0) > 0, "two halves need a solve window"   # C1 L3\n')
rep('print("E21:", json.dumps(CONFIG["e21"], default=str), flush=True)\n',
    '# rev 2 (VAL_fidelity_E2 LOW-1, E1 LOW-1): CONFIG was snapshot above before this block; record what really runs\n'
    'CONFIG["e11"]["ENGINE_BACKEND"] = ENGINE_BACKEND\n'
    'CONFIG["e12"]["E12_SOLVE_WINDOW_SEC"] = E12_SOLVE_WINDOW_SEC\n'
    'CONFIG["e12"].setdefault("rev6", {})["E12_R6_CACHE_DIAG"] = 0\n'
    'CONFIG["e12"]["E12_STREAMS"] = "per half (CONFIG[\'e21\'] / e12_run.streams)"\n'
    'print("E21:", json.dumps(CONFIG["e21"], default=str), flush=True)\n')

# ---- CELL 3: restore finish_reason "length" for a tool call cut at max_tokens
CELL3_PATCH = '''# E21 rev 2 (VAL_api_D1 F1, verified in the vLLM source): vLLM 0.19 / 0.32 report finish_reason "tool_calls" whenever
# the parser found a call, also for a reply cut at max_tokens (chat_completion/serving.py 0.19 L1550-1560, 0.32
# L1099-1116); SGLang 0.5.21 kept "length", which arc2_duck's cut-call handling (rev 5 B6 / R5-2, the cut-code harvest,
# the R6 "cut" opener) keys on. Restore "length" from the token count (Duck's package files stay byte-identical).
_E21_CC_ORIG = _E12_TA.ToolAgent._chat_completion
E21_LENGTH_RESTORED = {"n": 0}


def _e21_chat_completion(self, messages, **kw):
    res = _E21_CC_ORIG(self, messages, **kw)
    try:
        u = res.usage if isinstance(res.usage, dict) else {}
        cap = kw.get("max_tokens")
        cap = self._max_output_tokens if cap is None else cap
        ct, pt = u.get("completion_tokens"), u.get("prompt_tokens")
        if str(res.finish_reason or "") == "tool_calls" and cap and isinstance(ct, int):
            lim = int(cap) if not isinstance(pt, int) else min(int(cap), E21_VLLM_MAX_MODEL_LEN - int(pt))   # 0.32 clamps
            if ct >= lim:
                res.finish_reason = "length"
                E21_LENGTH_RESTORED["n"] += 1
    except Exception:
        pass
    return res


_E12_TA.ToolAgent._chat_completion = _e21_chat_completion
'''
open(r"D:/ARC AGI 2/experiments/Experiment 21 - Duck config B on vLLM 0.19 + 0.32 (planned)/Experiment Notebooks/Build/e21_cell3_patch.py",
     "w", encoding="utf-8", newline="\n").write(CELL3_PATCH)
rep('''    return c


# ------------------------------------------------------------------ CELL 5: the vLLM engine library''',
    '''    anchor = "_E12_TA, _E12_DP, _e12_run_sandboxed, _ = E12A._import_duck()\\n"
    c = rep(c, anchor, anchor + (HERE / "e21_cell3_patch.py").read_text(encoding="utf-8"))
    return c


# ------------------------------------------------------------------ CELL 5: the vLLM engine library''')

# ---- CELL 6: the vLLM log summary on the rev 2 stats rows (kept as a separate file); the model-id fallback
i0 = s.index("NEW_LOGSUM = " + Q3)
i1 = s.index(Q3, i0 + len("NEW_LOGSUM = ") + 3) + 3
s = s[:i0] + 'NEW_LOGSUM = (HERE / "e21_logsum.py").read_text(encoding="utf-8").rstrip("\\n")' + s[i1:]
LOGSUM = '''def _e15b_server_log_summary(text):
    # E15B #42 / #53 on vLLM (E21): vLLM's 10-s engine stats lines (rev 2: e21_stat_rows, every optional field incl.
    # Preemptions / Deferred) instead of SGLang decode lines: running-level histogram (lines with work), queue > 0 share,
    # generation throughput, prefix-cache hit rate (rolling), KV usage, MTP acceptance, preemptions, the startup KV line
    import re as _re
    rows = e21_stat_rows(text)
    work = [r for r in rows if r["running"] > 0 or r["waiting"] > 0]
    _hist, _hq, _tpl = {}, {}, {}
    for r in work:
        k = r["running"]
        _hist[k] = _hist.get(k, 0) + 1
        if r["waiting"] > 0:
            _hq[k] = _hq.get(k, 0) + 1
        _tpl.setdefault(k, []).append(r["gen_tps"])
    _tp = sorted(r["gen_tps"] for r in work)
    _acc = sorted(float(a) for a in _re.findall(r"Mean acceptance length: ([\\d.]+)", text))
    _kv = _re.findall(r"GPU KV cache size: ([\\d,]+) tokens", text)
    _pre = [r["prefix_pct"] for r in rows if r["prefix_pct"] is not None]
    _n = len(work)
    return {"decode_lines": _n, "running_hist": dict(sorted(_hist.items())),
            "running_hist_queue_gt0": dict(sorted(_hq.items())),
            "startup": {"kv_tokens_logged": int(_kv[0].replace(",", "")) if _kv else None},
            "accept_len_p50": _acc[len(_acc) // 2] if _acc else None,
            "gen_tok_s_p50_by_running": {k: sorted(v)[len(v) // 2] for k, v in sorted(_tpl.items())},
            "running_mean_lines": round(sum(k * v for k, v in _hist.items()) / _n, 2) if _n else None,
            "queue_gt0_line_share": round(sum(_hq.values()) / _n, 3) if _n else None,
            "gen_tok_s_p50": _tp[len(_tp) // 2] if _tp else None,
            "gen_tok_s_mean": round(sum(_tp) / len(_tp), 1) if _tp else None,
            "prefix_cache_hit_pct_last_rolling": _pre[-1] if _pre else None,
            "kv_usage_pct_max": max((r["kv_pct"] for r in rows), default=None),
            "preemptions_in_stats_lines": sum(r["preempt"] for r in rows),
            "preempt_lines": sum(1 for r in rows if r["preempt"]),
            "oom_lines": sum(1 for _l in text.splitlines() if "out of memory" in _l.lower()),
            "traceback_lines": sum(1 for _l in text.splitlines() if "Traceback" in _l)}
'''
open(r"D:/ARC AGI 2/experiments/Experiment 21 - Duck config B on vLLM 0.19 + 0.32 (planned)/Experiment Notebooks/Build/e21_logsum.py",
     "w", encoding="utf-8", newline="\n").write(LOGSUM)
rep('''    c = rep(c, "        _end = HARD_STOP - E12_STOP_BEFORE_HARD_SEC\\n",''',
    '''    c = rep(c, 'E12_RUN["model_id"] = str(SGL_MODEL_PATH)',
            'E12_RUN["model_id"] = E21_SERVED[(ENGINE_INFO.get("cfg") or {}).get("weights", "fp8")]   # E21: the served name')
    c = rep(c, "        _end = HARD_STOP - E12_STOP_BEFORE_HARD_SEC\\n",''')

# ---- wrap(): fail closed on every construct the wrapper cannot preserve
rep('''    for tok in tokenize.generate_tokens(io.StringIO(text).readline):
        assert not (tok.type == tokenize.STRING and "\\n" in tok.string), ("multi-line string", tok.start)''',
    '''    for tok in tokenize.generate_tokens(io.StringIO(text).readline):     # rev 2: any multi-line token (f-strings too)
        assert tok.start[0] == tok.end[0] or tok.type in (tokenize.NEWLINE, tokenize.NL, tokenize.INDENT, tokenize.DEDENT,
                                                          tokenize.ENDMARKER), ("multi-line token", tok.type, tok.start)
    tree = ast.parse(text)
    for n in ast.walk(tree):          # rev 2 (VAL_state_B1 L9, B2 LOW-7): constructs the wrapper cannot keep
        assert not isinstance(n, (ast.Match, ast.Delete) + ((ast.TypeAlias,) if hasattr(ast, "TypeAlias") else ())), \\
            ("construct the wrapper cannot keep", type(n).__name__, getattr(n, "lineno", None))
        if isinstance(n, ast.Call) and isinstance(n.func, ast.Name):
            assert n.func.id not in ("exec", "eval", "locals", "vars", "dir"), ("scope-sensitive call", n.func.id, n.lineno)
    assert not (tree.body and isinstance(tree.body[0], ast.Expr) and isinstance(getattr(tree.body[0], "value", None), ast.Constant)
                and isinstance(tree.body[0].value.value, str)), "a module docstring would become a function docstring"''')
rep('''    glob = "    global " + ", ".join(names) if names else ""
    return f"def {fname}():\\n    # {doc}\\n{glob}\\n{body}\\n"''',
    '''    glob = "    global " + ", ".join(names) if names else ""
    out = f"def {fname}():\\n    # {doc}\\n{glob}\\n{body}\\n"
    import symtable                  # rev 2: every remaining local of the function must be a comprehension variable
    st = symtable.symtable(out, "<wrap>", "exec").get_children()[0]
    comp = set()
    for n in ast.walk(tree):
        if isinstance(n, (ast.ListComp, ast.SetComp, ast.DictComp, ast.GeneratorExp)):
            for g in n.generators:
                for t in ast.walk(g.target):
                    if isinstance(t, ast.Name):
                        comp.add(t.id)
    bad = [x.get_name() for x in st.get_symbols() if x.is_local() and not x.is_global() and x.get_name() not in comp]
    assert not bad, ("locals left in the wrapped cell", bad)
    return out''')

# ---- PUSHED guard by 8-hex prefix; size checked before writing
rep('''    out = NBDIR / VARIANTS[variant]
    if out.exists() and sha(out.read_bytes()) in PUSHED:
        out = out.with_name(out.stem + "_REBUILD.ipynb")
    out.write_bytes(data)
    print(out.name, sha(data)[:8], f"{len(data) / 1024:.0f} kB", "| cells", len(out_cells))
    assert len(data) < 400 * 1024, "Kaggle commit notebook size limit (keep < 400 kB)"''',
    '''    assert len(data) < 400 * 1024, "Kaggle commit notebook size limit (keep < 400 kB)"
    out = NBDIR / VARIANTS[variant]
    pushed = lambda f: f.exists() and any(sha(f.read_bytes()).startswith(x) for x in PUSHED)    # rev 2: 8-hex prefixes
    if pushed(out):
        out = out.with_name(out.stem + "_REBUILD.ipynb")
        assert not pushed(out), out
    out.write_bytes(data)
    print(out.name, sha(data)[:8], f"{len(data) / 1024:.0f} kB", "| cells", len(out_cells))''')
p.write_text(s, encoding="utf-8", newline="\n")
print("builder patched")
