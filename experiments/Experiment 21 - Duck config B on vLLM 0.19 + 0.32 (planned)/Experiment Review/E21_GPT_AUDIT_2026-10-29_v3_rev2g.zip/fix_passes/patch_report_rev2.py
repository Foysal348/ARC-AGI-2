from pathlib import Path

p = Path(r"D:/ARC AGI 2/experiments/Experiment 21 - Duck config B on vLLM 0.19 + 0.32 (planned)/Experiment Notebooks/Build/build_e21.py")
s = p.read_text(encoding="utf-8")


def rep(a, b):
    global s
    assert s.count(a) == 1, (a[:80], s.count(a))
    s = s.replace(a, b)


rep('''            "server_gen_tokens": _bs.get("server_gen_tokens"), "counted_gen_tokens": _bs.get("counted_gen_tokens"),
            "errors": _st.get("errors")}''',
    '''            "server_gen_tokens": _bs.get("server_gen_tokens"), "counted_gen_tokens": _bs.get("counted_gen_tokens"),
            # rev 2: the solve window actually used, the prefill the server recomputed (vLLM align mode never reuses a
            # previous reply: VAL_api_D2 F1), Duck's gate, the server counters, the cut-call restorations, the probe
            "window_sec": _eng.get("window_sec"), "window_note": _eng.get("window_note"), "spec_note": _eng.get("spec_note"),
            "recomputed_prompt_tokens": sum(int(u.get("prompt") or 0) - int(u.get("cached") or 0)
                                            for v in _rec.values() for r in v for u in (r.get("usage") or [])),
            "prompt_tokens": sum(int(u.get("prompt") or 0) for v in _rec.values() for r in v for u in (r.get("usage") or [])),
            "gate": _st.get("gate"), "counters": _eng.get("final_counters"),
            "length_restored": _st.get("length_restored"),
            "contract": next((a.get("contract") for a in reversed(_eng.get("attempts") or []) if a.get("contract")), None),
            "gpu_checks": _eng.get("gpu_checks"),
            "errors": _st.get("errors")}''')
rep('''    write_json_atomic(BASE_OUT / "e21_report.json", E21_REPORT)''',
    '''    _ws = [h.get("deadline_in_sec") for h in E21_REPORT["halves"].values() if h.get("deadline_in_sec")]
    E21_REPORT["windows_sec"] = _ws
    E21_REPORT["windows_equal"] = (max(_ws) - min(_ws) <= 300) if len(_ws) > 1 else None
    if E21_REPORT["windows_equal"] is False:
        print("E21 WARNING: the halves' solve windows differ by more than 5 min:", _ws, flush=True)
    write_json_atomic(BASE_OUT / "e21_report.json", E21_REPORT)''')
rep('''              "% | preempt lines", _h["preempt_lines"], "| errors", len(_h["errors"] or []), flush=True)''',
    '''              "% | preempt lines", _h["preempt_lines"], "| window", _h["window_sec"], "| recomputed",
              _h["recomputed_prompt_tokens"], "/", _h["prompt_tokens"], "| length restored", _h["length_restored"],
              "| errors", len(_h["errors"] or []), flush=True)''')
# the cut-call restorations per half (the counter is cumulative over the notebook)
e = Path(r"D:/ARC AGI 2/experiments/Experiment 21 - Duck config B on vLLM 0.19 + 0.32 (planned)/Experiment Notebooks/Build/e21_engine_new.py")
t = e.read_text(encoding="utf-8")
a = '''        st["gate"] = {"stats": dict(_E12_TA._GATE_STATS), "slots_env": os.environ.get("ARC3_MAX_ACTIVE_STREAMS"),'''
assert t.count(a) == 1
t = t.replace(a, '''        _lr = int(globals().get("E21_LENGTH_RESTORED", {}).get("n", 0))
        st["length_restored"] = _lr - sum(int(v.get("length_restored") or 0) for k, v in E21_STATE["halves"].items() if k != H)
''' + a)
e.write_text(t, encoding="utf-8", newline="\n")
p.write_text(s, encoding="utf-8", newline="\n")
print("report patched")
