"""E21 rev 2b: the findings the first rev-2 pass left out (Experiment Review/E21_FINDINGS_TRACKER.md)."""
from pathlib import Path

E = Path(r"D:/ARC AGI 2/experiments/Experiment 21 - Duck config B on vLLM 0.19 + 0.32 (planned)/Experiment Notebooks/Build/e21_engine_new.py")
s = E.read_text(encoding="utf-8")


def rep(a, b):
    global s
    assert s.count(a) == 1, (a[:80], s.count(a))
    s = s.replace(a, b)


# N5 (VAL_api_D2 F5): the prefix-cache path is part of the contract probe
rep('''    out["ok"] = True
    return out


def e21_launch(H, cfg, tag, timeout=None):''',
    '''    out["cache"] = e21_cache_probe(served)
    out["ok"] = True
    return out


def e21_cache_probe(served):
    """rev 2b (VAL_api_D2 F5): the align-mode prefix-cache path that serves 67-94 % of every later Duck prompt. A shared
    ~5,000-token prefix with a marker per request: the cold request, then the same request again (it must hit the cache,
    >= 1 block) at temperature 0, thinking off; both replies must contain the request's own marker and be equal."""
    import random as _rnd
    rows = " ".join(str(_rnd.Random(7).randrange(10)) for _ in range(9000))
    res = []
    for i in range(2):
        mark = f"QZ{_rnd.randrange(10 ** 6, 10 ** 7)}K{i}"
        msgs = [{"role": "user", "content": "Grid digits for context: " + rows + f"\\n\\nReply with exactly this code: {mark}"}]
        body = {"model": served, "messages": msgs, "temperature": 0.0, "max_tokens": 24,
                "chat_template_kwargs": {"enable_thinking": False}}
        r1 = _e12v_request_json(SGL_URL + "/v1/chat/completions", payload=body, timeout=300)
        r2 = _e12v_request_json(SGL_URL + "/v1/chat/completions", payload=body, timeout=300)
        g1 = r1["choices"][0]["message"].get("content") or ""
        g2 = r2["choices"][0]["message"].get("content") or ""
        u2 = r2.get("usage") or {}
        c2 = ((u2.get("prompt_tokens_details") or {}).get("cached_tokens") or 0)
        res.append({"prompt": u2.get("prompt_tokens"), "cached_repeat": c2, "own_marker": mark in g1 and mark in g2,
                    "equal": g1 == g2})
    if not all(x["own_marker"] and x["equal"] and x["cached_repeat"] >= 1024 for x in res):
        raise RuntimeError(f"cache probe failed: {json.dumps(res)}")
    return res


def e21_v032_install_bg():
    """rev 2b (VAL_timing_C1 M3, VAL_fidelity_E2 LOW-7): build the vLLM 0.32 venv on CPU while half A solves, so half B's
    setup is only its launch. The result (or the error) is what e21_launch would have produced."""
    def _run():
        try:
            E21_STATE["v032_install"] = e18_install()
        except Exception as e:
            E21_STATE["v032_install"] = {"error": f"{type(e).__name__}: {e}"[:600]}
    if E21_STATE.get("v032_install") is None and E21_STATE.get("v032_thread") is None:
        E21_STATE["v032_thread"] = threading.Thread(target=_run, daemon=True, name="e21_v032_install")
        E21_STATE["v032_thread"].start()


def e21_launch(H, cfg, tag, timeout=None):''')

# N3: the background install is joined before a 0.32 launch
rep('''        if isinstance(E21_STATE.get("v032_install"), dict) and E21_STATE["v032_install"].get("error"):''',
    '''        _th = E21_STATE.get("v032_thread")
        if _th is not None and _th.is_alive():
            _th.join(timeout=2400)
        if isinstance(E21_STATE.get("v032_install"), dict) and E21_STATE["v032_install"].get("error"):''')
# N7 (VAL_engine_A2 L7): vLLM 0.32's JIT caches apart from 0.19's (half A keeps the proven defaults)
rep('''        env["VLLM_MEMORY_PROFILER_ESTIMATE_CUDAGRAPHS"] = "1"
        flags = e21_flags_v032(cfg, port, backend)''',
    '''        env["VLLM_MEMORY_PROFILER_ESTIMATE_CUDAGRAPHS"] = "1"
        env.update(TRITON_CACHE_DIR="/tmp/e21-v032-triton", FLASHINFER_WORKSPACE_BASE="/tmp/e21-v032-flashinfer")
        flags = e21_flags_v032(cfg, port, backend)''')
# C1 M3 (b): a 0.32 launch from staged weights is ready in ~550 s; 20 min, so a hung primary leaves time for the fallback
rep('''    if timeout is None:
        timeout = max(60.0, min(E21_LAUNCH_TIMEOUT_SEC, E21_HALF_END_PC - time.perf_counter() - 30 * 60))''',
    '''    if timeout is None:
        _cap = E21_LAUNCH_TIMEOUT_SEC if cfg["vllm"] == "0.19.0" else E21_LAUNCH_TIMEOUT_V032_SEC
        timeout = max(60.0, min(_cap, E21_HALF_END_PC - time.perf_counter() - 30 * 60))''')

# N6 (VAL_engine_A2 L5, VAL_fidelity_E1 LOW-3): a second relaunch uses the half's other config
rep('''    H, cfg = E21_HALF, ENGINE_INFO.get("cfg")
    t = min(''',
    '''    H, cfg = E21_HALF, ENGINE_INFO.get("cfg")
    if len(ENGINE_INFO.get("relaunches") or []) >= 1:          # the same config already crashed once: try the other one
        _alt = [c for _t, c in e21_cfgs(ENGINE_INFO.get("spec") or E21_HALF_SPECS[E21_VARIANT][H]) if c != cfg]
        if _alt:
            cfg = _alt[0]
            ENGINE_INFO["relaunch_cfg_switched"] = dict(cfg)
    t = min(''')
rep('''        srv, info = e21_launch(H, cfg, f"relaunch{len(ENGINE_INFO.setdefault('relaunches', []))}", timeout=t)
        ENGINE_INFO["relaunches"].append({k: info.get(k) for k in ("tag", "ready", "why", "ready_sec", "capacity")})''',
    '''        srv, info = e21_launch(H, cfg, f"relaunch{len(ENGINE_INFO.setdefault('relaunches', []))}", timeout=t)
        ENGINE_INFO["relaunches"].append({k: info.get(k) for k in ("tag", "ready", "why", "ready_sec", "capacity", "cfg")})
        ENGINE_INFO["cfg"] = cfg''')

# N9 (VAL_fidelity_E1 LOW-2): Duck's env base URL = this half's server (hygiene; agents get it explicitly)
rep('''    os.environ["ARC3_REASONING_HISTORY_KEY"] = "reasoning"     # vLLM reads only message["reasoning"] (see CELL 3)
    E21_STATE["halves"][H] = {"engine": ENGINE_INFO}''',
    '''    os.environ["ARC3_REASONING_HISTORY_KEY"] = "reasoning"     # vLLM reads only message["reasoning"] (see CELL 3)
    os.environ["LOCAL_ANALYZER_BASE_URL"] = os.environ["OPENAI_BASE_URL"] = SGL_URL + "/v1"
    E21_STATE["halves"][H] = {"engine": ENGINE_INFO}''')
# N3: start the background 0.32 install once half A's server is up
rep('''    if not ENGINE_READY:
        ENGINE_INFO["fatal"] = ENGINE_INFO.get("fatal") or "no vLLM config became ready"''',
    '''    if H == "A" and "B" in E21_HALVES and any(c.get("vllm") == "0.32.0" for c in E21_HALF_SPECS[E21_VARIANT].values()):
        e21_v032_install_bg()
    if not ENGINE_READY:
        ENGINE_INFO["fatal"] = ENGINE_INFO.get("fatal") or "no vLLM config became ready"''')

# N10 (VAL_fidelity_E1 LOW-6) + N19 (VAL_engine_A1 M2): CELL 7 reads accept_len_median; MTP acceptance warning
rep('''           "spec_mean_acceptance_median": med([float(a) for a in acc]),''',
    '''           "spec_mean_acceptance_median": med([float(a) for a in acc]),
           "accept_len_median": med([float(a) for a in acc]),      # the key CELL 7 reads''')
rep('''        e21_snapshot_counters()
        st["engine"] = ENGINE_INFO
        st["decode_summary"] = e11_decode_summary() if E11_SERVER is not None else None''',
    '''        e21_snapshot_counters()
        st["engine"] = ENGINE_INFO
        st["decode_summary"] = e11_decode_summary() if E11_SERVER is not None else None
        _acc = (st["decode_summary"] or {}).get("accept_len_median")
        if _acc is not None and _acc < 1.5:          # an INT4 MTP-head mismatch shows up here first (VAL_engine_A1 M2)
            st["mtp_acceptance_warning"] = _acc
            print(f"E21 WARNING half {H}: MTP mean acceptance {_acc} < 1.5", flush=True)''')
E.write_text(s, encoding="utf-8", newline="\n")

# ---- CELL 3 patch: count tool calls that came with visible content (0.32 ends reasoning at <tool_call>; D1 F4)
P3 = Path(r"D:/ARC AGI 2/experiments/Experiment 21 - Duck config B on vLLM 0.19 + 0.32 (planned)/Experiment Notebooks/Build/e21_cell3_patch.py")
t = P3.read_text(encoding="utf-8")
a = 'E21_LENGTH_RESTORED = {"n": 0}\n'
assert t.count(a) == 1
t = t.replace(a, 'E21_LENGTH_RESTORED = {"n": 0}\nE21_CALL_WITH_CONTENT = {"n": 0}     # rev 2b (VAL_api_D1 F4): a tool call + visible text\n')
a = '''        if str(res.finish_reason or "") == "tool_calls" and cap and isinstance(ct, int):'''
assert t.count(a) == 1
t = t.replace(a, '''        _m = res.message if isinstance(res.message, dict) else {}
        if _m.get("tool_calls") and str(_m.get("content") or "").strip():
            E21_CALL_WITH_CONTENT["n"] += 1
''' + a)
P3.write_text(t, encoding="utf-8", newline="\n")

# ---- builder: CELL 1 window / reserve / 0.32 timeout / tokenizer fallback; CELL 6 preflight timeout; report fields
B = Path(r"D:/ARC AGI 2/experiments/Experiment 21 - Duck config B on vLLM 0.19 + 0.32 (planned)/Experiment Notebooks/Build/build_e21.py")
b = B.read_text(encoding="utf-8")


def repb(x, y):
    global b
    assert b.count(x) == 1, (x[:80], b.count(x))
    b = b.replace(x, y)


repb('"drain_margin_sec": 8 * 60, "admit_margin_sec": 2 * 60, "solve_window_sec": 5.5 * 3600},',
     '"drain_margin_sec": 8 * 60, "admit_margin_sec": 2 * 60, "solve_window_sec": 5.45 * 3600},   # rev 2b')
repb('E21_B_SETUP_RESERVE_SEC = float(os.environ.get("E21_B_SETUP_RESERVE_SEC", 25 * 60))   # switch + 0.32 install + launch + report',
     'E21_B_SETUP_RESERVE_SEC = float(os.environ.get("E21_B_SETUP_RESERVE_SEC", 30 * 60))   # rev 2b (C1 M3): switch + launch + preflight')
repb('E21_LAUNCH_TIMEOUT_SEC = 30 * 60\n',
     'E21_LAUNCH_TIMEOUT_SEC = 30 * 60\n'
     'E21_LAUNCH_TIMEOUT_V032_SEC = 20 * 60      # rev 2b (C1 M3): 0.32 from staged weights was ready in ~550 s (E18)\n'
     '# rev 2b (VAL_fidelity_E1 M2, E2 M2): Duck counts reasoning tokens with E12_TOKENIZER_JSON (the INT4 file, as R3K2);\n'
     '# without the INT4 model attached it silently fell back to a chars/token ratio. The FP8 tokenizer has the same vocab\n'
     '# and merges and encodes identically (README Finding 4, Kaggle CPU kit on the real files).\n'
     'if not Path(os.environ.get("E12_TOKENIZER_JSON", "")).is_file() and (MODEL_PATH / "tokenizer.json").is_file():\n'
     '    os.environ["E12_TOKENIZER_JSON"] = str(MODEL_PATH / "tokenizer.json")\n')
repb('''    c = rep(c, 'E12_RUN["model_id"] = str(SGL_MODEL_PATH)',''',
     '''    c = rep(c, "r = json.loads(_urlreq.urlopen(req, timeout=180).read())",
            "r = json.loads(_urlreq.urlopen(req, timeout=60).read())     # E21 rev 2b (C1 M3): <= ~2 min per preflight")
    c = rep(c, 'E12_RUN["model_id"] = str(SGL_MODEL_PATH)',''')
repb('''            "length_restored": _st.get("length_restored"),''',
     '''            "length_restored": _st.get("length_restored"),
            "stage1": _e21_stage1(_rec, _run),
            "score_attempt1_strict_pass1": _e21_pass1(_rec),''')
repb('''E21_REPORT = {"run_id": RUN_ID,''',
     '''def _e21_stage1(recs, run):
    """rev 2b (VAL_timing_C2 LOW-4): the attempt-1-only score compares halves only if stage 1 (attempt 1 of every task)
    finished in both: when the last attempt 1 ended, how many attempts 1 never started or were cut by the deadline."""
    b0 = [r for v in recs.values() for r in v if r.get("branch") == 0]
    ends = [max((q.get("t", 0) + (q.get("sec") or 0)) for q in (r.get("requests") or [])) for r in b0 if r.get("requests")]
    t0 = min((r.get("t0") or 0) for r in b0) if b0 else None
    dl = max(ends) if ends else None
    return {"attempt1_records": len(b0), "tasks": len(TASK_IDS),
            "attempt1_missing": len(TASK_IDS) - len({r.get("task_id") for r in b0}),
            "attempt1_cut_by_deadline": sum(1 for e in ends if dl is not None and dl - e < 90) if ends else None,
            "attempt1_all_done_h": round((dl - t0) / 3600, 2) if (ends and t0) else None}


def _e21_pass1(recs):
    if SOLUTIONS is None:
        return None
    gen = E12A.build_submission({t: CHALLENGES[t] for t in TASK_IDS},
                                {t: [r for r in recs.get(t, []) if r.get("branch") == 0] for t in TASK_IDS})
    h = sum(int(a["attempt_1"] == SOLUTIONS[t][qi]) for t in TASK_IDS for qi, a in enumerate(gen[t]))
    return {"pass1_query_hits": h, "queries": sum(len(gen[t]) for t in TASK_IDS)}


E21_REPORT = {"run_id": RUN_ID,''')
repb('''    _ws = [h.get("deadline_in_sec") for h in E21_REPORT["halves"].values() if h.get("deadline_in_sec")]''',
     '''    E21_REPORT["tool_calls_with_content"] = globals().get("E21_CALL_WITH_CONTENT")
    _ws = [h.get("deadline_in_sec") for h in E21_REPORT["halves"].values() if h.get("deadline_in_sec")]''')
B.write_text(b, encoding="utf-8", newline="\n")
print("rev 2b patched")
