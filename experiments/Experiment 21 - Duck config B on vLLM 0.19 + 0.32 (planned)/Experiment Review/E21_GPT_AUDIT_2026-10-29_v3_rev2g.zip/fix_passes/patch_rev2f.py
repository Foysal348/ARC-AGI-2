"""E21 rev 2f: VAL2_cells F1/F2/F3 + VAL2_config_smoke F2/F3/F5/F6 (only run-breaking or result-falsifying items)."""
from pathlib import Path

BD = Path(r"D:/ARC AGI 2/experiments/Experiment 21 - Duck config B on vLLM 0.19 + 0.32 (planned)/Experiment Notebooks/Build")
b = (BD / "build_e21.py").read_text(encoding="utf-8")
e = (BD / "e21_engine_new.py").read_text(encoding="utf-8")


def repb(x, y):
    global b
    assert b.count(x) == 1, (x[:90], b.count(x))
    b = b.replace(x, y)


def repe(x, y):
    global e
    assert e.count(x) == 1, (x[:90], e.count(x))
    e = e.replace(x, y)


# VAL2_cells F1 (reproduced): a module-level `_wd_* = ...` line is made global by wrap(), so half B rebinds it and half
# A's watchdog believes it is half B's. Bind through default arguments (evaluated at def time), as the callback is.
repb('''        _wd_stop, _wd_run, _wd_half = _E12_STOP, E12_RUN, E21_HALF     # E21 rev 2c: this half's objects

        def _e15b_watchdog():''',
     '''        def _e15b_watchdog(_wd_stop=_E12_STOP, _wd_run=E12_RUN, _wd_half=E21_HALF, _e15b_solve_end=_e15b_solve_end):
            # E21 rev 2f (VAL2_cells F1): this half's objects bound at def time (a module-level binding is global
            # after wrap() and half B would rebind it)''')
repb('''                E12A.SERVER_DOWN.set()
                print("E15B watchdog: server down -> relaunch", json.dumps(_rec), flush=True)''',
     '''                if E21_HALF != _wd_half:          # rev 2f: re-check right before acting
                    return
                E12A.SERVER_DOWN.set()
                print("E15B watchdog: server down -> relaunch", json.dumps(_rec), flush=True)''')
# VAL2_cells F2: stage-1 "cut by the deadline" must compare with the deadline, not with the last request end
_A = 'E12_RUN["planned_solve_end_sec"] = round(_e15b_solve_end - NOTEBOOK_T0, 1)' + chr(92) + 'n'
repb(_A, _A + '        E12_RUN["solve_end_epoch"] = time.time() + (_e15b_solve_end - time.perf_counter())   # rev 2f: request t / t0 are epoch' + chr(92) + 'n')
repb('''    dl = max(ends) if ends else None
    return {"attempt1_records": len(b0), "tasks": len(TASK_IDS),
            "attempt1_missing": len(TASK_IDS) - len({r.get("task_id") for r in b0}),
            "attempt1_cut_by_deadline": sum(1 for e in ends if dl is not None and dl - e < 90) if ends else None,
            "attempt1_all_done_h": round((dl - t0) / 3600, 2) if (ends and t0) else None}''',
     '''    last = max(ends) if ends else None
    dl = (run or {}).get("solve_end_epoch")          # rev 2f (VAL2_cells F2): the solve deadline, not the last end
    return {"attempt1_records": len(b0), "tasks": len(TASK_IDS),
            "attempt1_missing": len(TASK_IDS) - len({r.get("task_id") for r in b0}),
            "attempt1_cut_by_deadline": (sum(1 for x in ends if dl - x < 90) if (ends and dl) else None),
            "attempt1_all_done_h": round((last - t0) / 3600, 2) if (ends and t0) else None}''')
# VAL2_config_smoke F2 (HIGH for the smoke): with a 2-h budget half A's fallback had too little time
repb('''    "E21SMOKE": {"source": "eval", "n_tasks": 12, "time_budget_sec": 2.0 * 3600, "admit_frac": 0.90,''',
     '''    "E21SMOKE": {"source": "eval", "n_tasks": 12, "time_budget_sec": 2.5 * 3600, "admit_frac": 0.90,   # rev 2f''')
# VAL2_cells F3 (part): the KV-probe outage clock restarts per half
repe('''    os.environ["LOCAL_ANALYZER_BASE_URL"] = os.environ["OPENAI_BASE_URL"] = SGL_URL + "/v1"''',
     '''    os.environ["LOCAL_ANALYZER_BASE_URL"] = os.environ["OPENAI_BASE_URL"] = SGL_URL + "/v1"
    E21_STATE.pop("probe_fail_since", None)      # rev 2f (VAL2_cells F3): the outage clock is per half''')
# VAL2_config_smoke F6 (reproduced: 9,000 copies of "5"): one RNG for all digits
repe('''    rows = " ".join(str(_rnd.Random(7).randrange(10)) for _ in range(9000))''',
     '''    _r7 = _rnd.Random(7)                       # rev 2f (VAL2_config_smoke F6): one RNG (the old code repeated one digit)
    rows = " ".join(str(_r7.randrange(10)) for _ in range(6000))''')
# VAL2_config_smoke F3: the cache probe runs even when turn 1 made no tool call; F5: in the hidden rerun only real
# breakage (HTTP error, markup in content, degenerate text, broken arguments) is fatal; the history-shortfall and the
# cache probe become warnings there (a false failure on both configs would mean no engine and an identity submission)
repe('''    if not calls:
        out.update(ok=True, turn2="inconclusive: no tool call in turn 1")
        return out''',
     '''    if not calls:
        out.update(turn2="inconclusive: no tool call in turn 1")
        e21_soft(out, "cache", lambda: e21_cache_probe(served))
        out["ok"] = True
        return out''')
repe('''    if reas and short > max(128, len(reas) // 6):
        raise RuntimeError(f"contract: history prompt {p2} short by {short} tokens (reasoning dropped?) {json.dumps(out)}")
    out["cache"] = e21_cache_probe(served)
    out["ok"] = True
    return out''',
     '''    if reas and short > max(128, len(reas) // 6):
        e21_soft(out, "history", lambda: (_ for _ in ()).throw(
            RuntimeError(f"contract: history prompt {p2} short by {short} tokens (reasoning dropped?)")))
    e21_soft(out, "cache", lambda: e21_cache_probe(served))
    out["ok"] = True
    return out


def e21_soft(out, key, fn):
    """rev 2f: a check that is fatal in commit / smoke (falls back) but only a recorded warning in the hidden rerun."""
    try:
        out[key] = fn()
    except Exception as e:
        if not RERUN:
            raise
        out.setdefault("warnings", []).append(f"{key}: {e}"[:600])
        print("E21 WARNING (rerun, not fatal):", key, str(e)[:300], flush=True)''')
(BD / "build_e21.py").write_text(b, encoding="utf-8", newline="\n")
(BD / "e21_engine_new.py").write_text(e, encoding="utf-8", newline="\n")
print("rev 2f patched")
