"""Parse E21's launch commands with the REAL vLLM argument parser of the installed version (Kaggle CPU kit; no GPU needed).
usage: <python with vllm X> e21_flagcheck.py <flags.json> <version>   -> prints one JSON line per command, then a summary.
flags.json = CONFIG["e21"]["flags"] of a notebook run ({"A_primary": {"vllm": "0.19.0", "flags": [...]}, ...}); only the
commands of <version> are checked. vLLM 0.19 commands use the api_server form (--model <path>); 0.32 commands use the
`vllm serve <path>` form, parsed here as --model <path> with the same make_arg_parser (the serve subcommand adds only
the positional model tag). Each parsed namespace is also turned into AsyncEngineArgs (types, choices, JSON values)."""
import json
import sys
import traceback

flags_all = json.load(open(sys.argv[1], encoding="utf-8"))
version = sys.argv[2]
import vllm  # noqa: E402

out = {"vllm": vllm.__version__, "want": version, "checked": 0, "ok": 0, "errors": {}}
assert vllm.__version__.startswith(version), (vllm.__version__, version)
try:
    from vllm.utils.argparse_utils import FlexibleArgumentParser
except Exception:
    from vllm.utils import FlexibleArgumentParser
from vllm.entrypoints.openai.cli_args import make_arg_parser  # noqa: E402
from vllm.engine.arg_utils import AsyncEngineArgs  # noqa: E402

for key, row in sorted(flags_all.items()):
    if row["vllm"] != version:
        continue
    argv = list(row["flags"])
    if not argv[0].startswith("--"):
        argv = ["--model", argv[0]] + argv[1:]
    out["checked"] += 1
    rec = {"key": key}
    try:
        p = make_arg_parser(FlexibleArgumentParser())
        ns = p.parse_args(argv)
        ea = AsyncEngineArgs.from_cli_args(ns)
        rec.update(ok=True, parsed={k: str(getattr(ns, k, None)) for k in (
            "model", "served_model_name", "port", "max_num_seqs", "max_model_len", "kv_cache_dtype", "speculative_config",
            "attention_backend", "mamba_ssm_cache_dtype", "enable_prefix_caching", "tool_call_parser", "reasoning_parser",
            "enable_auto_tool_choice", "default_chat_template_kwargs", "language_model_only", "enable_prompt_tokens_details",
            "generation_config", "trust_remote_code", "disable_custom_all_reduce", "max_num_batched_tokens",
            "gpu_memory_utilization", "tensor_parallel_size")},
            engine_args={k: str(getattr(ea, k, None)) for k in ("mamba_ssm_cache_dtype", "kv_cache_dtype", "max_num_seqs",
                                                                 "enable_prefix_caching", "speculative_config")})
        out["ok"] += 1
    except SystemExit as e:
        rec.update(ok=False, error=f"SystemExit {e.code} (argparse rejected the command)")
    except Exception as e:
        rec.update(ok=False, error=f"{type(e).__name__}: {e}"[:800], tb=traceback.format_exc()[-1500:])
    if not rec["ok"]:
        out["errors"][key] = rec.get("error")
    print(json.dumps(rec), flush=True)
out["all_ok"] = out["checked"] > 0 and out["ok"] == out["checked"]
print("FLAGCHECK", json.dumps(out), flush=True)
