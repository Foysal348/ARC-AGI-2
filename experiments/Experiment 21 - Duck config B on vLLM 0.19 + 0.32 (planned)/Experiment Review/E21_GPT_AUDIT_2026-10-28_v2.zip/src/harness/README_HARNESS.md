# E21 CPU harness

Runs every code cell of a real E21 notebook (NB1 INT4 S20 or NB2 FP8 SSM16 S16) on CPU against a fake vLLM server, then
checks what the notebook produced. No GPU, no install, no Kaggle.

## Files

- `fake_vllm_duck_server.py`: fake vLLM OpenAI server. The notebook's own engine cell launches it as
  `[sys.executable, fake] + flags` (`E11_HARNESS=1`, `E21_FAKE_SERVER=<this file>`). It accepts both argv forms:
  `--model <path> ...` (vLLM 0.19 api_server, half A) and `[serve] <path> ...` (vLLM 0.32 `vllm serve`, half B).
  - It refuses to start (exit 2) if a Duck serving flag is missing (`--enable-auto-tool-choice`,
    `--tool-call-parser qwen3_coder`, `--reasoning-parser qwen3`, `--default-chat-template-kwargs` with preserve_thinking
    true, `--enable-prefix-caching`, `--max-model-len >= 131072`), or if the served name is a Duck alias.
  - It prints vLLM's lines: the KV size line and the max-concurrency line (KV 1,523,200 for an int4/w4a16 path, else
    1,110,415), then the `Engine 000: ...` stats line and the `SpecDecoding metrics: ...` line every 2 s while busy.
  - Endpoints: `/health`, `/v1/models`, `/metrics` (vllm:* gauges and counters), `/fake_stats`, and
    `/v1/chat/completions`. For chat requests it runs the E12 rev 6 scripted Duck program from Exp 14 `e14_fake_server.py`.
  - Reply shape: the thinking goes in `reasoning`. `prompt_tokens_details.cached_tokens` is present only when the value
    is > 0 and `--enable-prompt-tokens-details` is set. A request with prompt + max_tokens > max-model-len gets HTTP 400.
  - Input, as vLLM 0.19 / 0.32 handle it: only `reasoning` of an assistant history message counts toward the prompt.
    `reasoning_content` is ignored, and the fake counts how often each key arrives.
  - Prefix cache: whole 1,600-token blocks of the longest prefix shared with earlier prompts and outputs.
  - Running requests are capped at `--max-num-seqs`; extra requests wait in FIFO order.
  - Fault injection, all optional:
    - `FAKE_REJECT_FLAG=<flag>` rejects a launch with that flag.
    - `FAKE_REJECT=<0.19|0.32|*>:<substring>,...` rejects a launch per argv form.
    - `FAKE_NEVER_READY=1|0.19|0.32` keeps the server from ever becoming ready.
    - `FAKE_DIE_AFTER_SEC=<s>` makes the server die s seconds after the first tool request. Narrow it with
      `FAKE_DIE_FORM`. With `FAKE_DIE_ONCE=1` (the default) only one server per form dies.
  - Evidence: `FAKE_STATE_DIR/launches.jsonl` gets one row per start (argv, form, outcome: ready / refused / rejected /
    never_ready / died), and `stats_<pid>.json` is refreshed every 2 s.
- `harness_e21_nb.py`: the notebook harness. Its setup follows Exp 15 `harness_e15b_nb.py`: the Windows shims, the
  fixtures, the payload in the dataset shape, the INT4 / drafter model dirs in the real Kaggle path shape, and staging to a
  local `shm`.

## Usage

```
E21_MODE=<mode> python harness_e21_nb.py "<notebook.ipynb>"
```

Env:
- `E21_HARNESS_ROOT`: where the run folders go. Default `D:/ARC AGI 2/_scratch/e21/harness_runs`. The notebook's
  working dir is `<root>/run_<NB>_<mode>_<time>/`.
- `E21_FAKE_SERVER`, `E14_FIXTURES_DIR`, `Q27X_PAYLOAD_DIR` (a flat folder of the q27x_*.bin is fine): the defaults are
  the local paths.
- `E21H_PROFILE`: default `EVAL6`, 6 eval tasks.
- `E21H_HALF_SOLVE_SEC`: default 90 s, or 240 s in death mode.
- `E21H_MAX_SEC`: hard limit for the whole run, default 1800 s.

The harness also sets these for the notebook:
- `Q27X_TIME_BUDGET=10800`. A long budget is needed: `e21_begin_half` skips the fallback when fewer than 30 min are
  left, and CELL 1 asserts that 2 x window + reserve fits. Rerun mode uses 2400 instead.
- `E21_B_SETUP_RESERVE_SEC=300`.
- `Q27X_GPU_WAIT_MAX=1`. There is no nvidia-smi, so `_wait_gpu_release` would otherwise wait 180 s per call.
- `E18_SILENCE_SEC=120`, or 15 in halfAfail mode.
- Short Duck budgets, as in the E15B harness: `E12_MAX_GEN=6000`, `E12_B_ATTEMPT_TOKENS_B1=4000`,
  `E12_B_MAX_ATTEMPTS=3`.

Output: one line per check, `[e21 PASS] ...` or `[e21 FAIL] ... -> info`, then a `[e21 SUMMARY]` line. When every check
passes it prints `@@E21_HARNESS_OK@@` and exits 0. Otherwise it prints `@@E21_HARNESS_FAIL@@` and exits 1.

Fixed ports (1234 for half A, 8011 for half B): run the modes one after another, never in parallel.

## Modes

| mode | fault | what must happen |
|---|---|---|
| commit | none | Half A (0.19) runs, then half B (0.32), each on its primary config, both scored. |
| rerun | `KAGGLE_IS_COMPETITION_RERUN=1` | Half A only, on every test task. The submission is half A's generated attempts. Half B never launches. |
| fallbackA | `FAKE_REJECT=0.19:w4a16` (NB1) or `0.19:--mamba-ssm-cache-dtype` (NB2) | Half A's primary exits and its fallback becomes ready (NB1: FP8 seqs 16; NB2: no SSM flag). Half B runs its primary. |
| halfAfail | `FAKE_NEVER_READY=0.19` | Both half-A configs stall. Half A records no engine and does not raise. Half B runs. The submission stays valid. |
| death | `FAKE_DIE_AFTER_SEC=8` (0.19, once) | The half-A server dies mid-solve. The watchdog relaunches it once (`e21_relaunch`, `vllm_server_halfA_relaunch0.log`), and the relaunched server serves Duck. |
| reasoningkey | none (= commit) | Names the reasoning-key checks. Those checks run in every mode. |

## Checks (every mode, where they apply)

- The run:
  - Every code cell ran without an uncaught exception.
  - The notebook has 10 code cells.
  - The halves that ran are `["A","B"]`, or `["A"]` in rerun.
- submission.json: complete and valid (every task, every test input, two grids each), with no temp file left.
- Launches:
  - Every port-1234 launch used the 0.19 form.
  - Every port-8011 launch used the 0.32 form. In rerun there was no 0.32 launch at all.
  - No launch was refused for missing Duck flags.
  - The primary configs match the variant: NB1 is INT4 with seqs 20; NB2 is FP8 with seqs 16 and the float16 SSM flag.
  - The served names are the E21 names.
- Capacity:
  - On every fake server, real running stayed <= `--max-num-seqs`.
  - The capacity check gave the expected streams (20 or 16), and Duck's streams and workers match it.
- Reasoning key:
  - The assistant history carried `reasoning`, and no message or request carried only `reasoning_content`.
  - `ARC3_REASONING_HISTORY_KEY` is `reasoning`.
- No request was over the context limit.
- Per half:
  - The engine is the primary or fallback config the mode expects, and the smoke passed.
  - Duck ran with no solver error, branches started, and the isolation preflight passed.
  - `b_summary` was built from the vLLM probes, and the stats-line summary has lines.
  - There are no worker errors and cached tokens are > 0.
  - The half was scored (commit modes).
  - The artefacts exist: `q27x/half<H>/e12_run_report.json`, `vllm_server_half<H>_<tag>.log`,
    `sglang_decode_summary.json`, `duck/`, and `Q27X_E21_<V>_HALF<H>_DUCK_BUNDLE.zip`.
  - The runner recorded no step error, and the server was stopped at the half's end.
- Order: half B began after half A ended, and every B launch came after every A launch.
- Report:
  - `q27x/e21_report.json` has one row per half with the score / engine / attempts / errors fields.
  - `Q27X_E21_<V>_BUNDLE.zip` holds the report and the submission.
- Profile: the Kaggle default `E21X2EVAL120` has 120 tasks and a 5.5-h window, and both windows fit the budget.
