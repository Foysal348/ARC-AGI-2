"""CPU harness for the E21 notebooks (Duck config B on vLLM 0.19 + 0.32, two halves). Runs ALL code cells of the real
notebook in order against fake_vllm_duck_server.py (no GPU, no install), then checks what it produced and prints a
PASS/FAIL table. Setup (Windows shims, fixtures, payload dataset shape, model-dir fakes) = Exp 15 harness_e15b_nb.py.
usage: python harness_e21_nb.py <notebook> [scale]
env E21_MODE:
  commit       both halves on a few eval tasks (profile E21H_PROFILE, default EVAL6) with short per-half windows
  rerun        KAGGLE_IS_COMPETITION_RERUN=1: half A only, every fixture test task, a complete submission.json
  fallbackA    half A's primary launch is rejected by the fake (NB1: the INT4 path, NB2: --mamba-ssm-cache-dtype; 0.19
               form only) -> its fallback launches; half B runs its primary
  halfAfail    the 0.19 server never becomes ready (FAKE_NEVER_READY=0.19) -> half A has no engine, half B still runs and
               the notebook finishes with a valid submission
  death        the half-A server dies mid-solve (FAKE_DIE_AFTER_SEC, 0.19 form, once) -> the watchdog relaunches it once
  reasoningkey = commit; the reasoning-key checks (history sent under `reasoning`, never only `reasoning_content`)
               are run in every mode, this mode only names them
Other env: E21_HARNESS_ROOT (run folders), E21_FAKE_SERVER (default: next to this file), E14_FIXTURES_DIR,
Q27X_PAYLOAD_DIR, E14_HARNESS_DIR (accepted, unused), E21H_PROFILE, E21H_HALF_SOLVE_SEC, E21H_MAX_SEC (hard limit, 1800).
Output: one line per check `[e21 PASS] ...` / `[e21 FAIL] ... -> info`, then @@E21_HARNESS_OK@@ and exit 0 only when
every check passed (else @@E21_HARNESS_FAIL@@, exit 1). Runs on Windows (shims behind os.name) and Linux / Py 3.12."""
import faulthandler
import json
import os
import shutil
import socket
import struct
import subprocess
import sys
import tempfile
import time
import zipfile
from pathlib import Path

NB = str(Path(sys.argv[1]).resolve())
MODE = os.environ.get("E21_MODE", "commit")
assert MODE in ("commit", "rerun", "fallbackA", "halfAfail", "death", "reasoningkey"), MODE
SCALE = sys.argv[2] if len(sys.argv) > 2 else "0.03"
HERE = Path(__file__).resolve().parent
NBN = Path(NB).name
VAR = "NB1" if "_NB1_" in NBN else "NB2" if "_NB2_" in NBN else None
assert VAR, NBN
FAKE = Path(os.environ.get("E21_FAKE_SERVER") or (HERE / "fake_vllm_duck_server.py"))
FIX = Path(os.environ.get("E14_FIXTURES_DIR", r"D:/ARC AGI 2/_scratch/g4b_bundle_verify/tests/fixtures"))
# Q27X_PAYLOAD_DIR (the Kaggle CPU kit: a flat folder of q27x_*.bin) is passed to the notebook as it is; without it the
# E15B payload is copied into the real dataset shape below
PAYLOAD_ENV = os.environ.get("Q27X_PAYLOAD_DIR")
PAYSRC = Path(r"D:/ARC AGI 2/experiments/Experiment 15 - Duck 2x35k independent attempts (planned)/Experiment Notebooks/Build/payload")
sys.path.insert(0, str(FIX))
import e12_fixtures as B  # noqa: E402

sys.stdout.reconfigure(encoding="utf-8")
faulthandler.dump_traceback_later(float(os.environ.get("E21H_MAX_SEC", 1800)), exit=True)   # never hang forever
if os.name == "nt":   # the E12 harness's Windows-only shims (65 KB sandbox bootstrap as -c; no killpg)
    _real = subprocess.Popen
    _bdir = Path(tempfile.gettempdir()) / "e14_harness_bootstrap"
    _bdir.mkdir(parents=True, exist_ok=True)

    class _Shim(_real):
        def __init__(self, args, *a, **kw):
            if isinstance(args, list) and len(args) >= 5 and args[1:4] == ["-I", "-S", "-c"]:
                f = _bdir / "sandbox_bootstrap.py"
                if not f.exists() or f.read_text(encoding="utf-8") != args[4]:
                    f.write_text(args[4], encoding="utf-8")
                args = [args[0], "-I", "-S", str(f)] + args[5:]
            super().__init__(args, *a, **kw)
    subprocess.Popen = _Shim
    if not hasattr(os, "killpg"):
        import signal as _sig
        os.killpg = lambda pid, sig: os.kill(pid, 9)
        if not hasattr(_sig, "SIGKILL"):
            _sig.SIGKILL = 9

ROOT = Path(os.environ.get("E21_HARNESS_ROOT") or os.environ.get("E21H_ROOT") or r"D:/ARC AGI 2/_scratch/e21/harness_runs")
ROOT.mkdir(parents=True, exist_ok=True)
WORK = ROOT / f"run_{VAR}_{MODE}_{time.strftime('%H%M%S')}"
WORK.mkdir()
STATE = WORK / "fake_state"
ch, sol, multi, single = B.load()
PICK = ["2ba387bc"] + multi[:2] + single[:2]
FP8 = B.TOKDIR_FP8
# the INT4 "model": the tokenizer fixture + a 3 MiB safetensors file, in the REAL Kaggle path shape (staging copies it)
MODELS = WORK / "inputs" / "models" / "foysalemonshanto"
INT4 = MODELS / "qwen3-8-27b-int4-redhat" / "pytorch" / "w4a16-g128" / "1"
shutil.copytree(B.TOKDIR_INT4, INT4)
hdr = json.dumps({"w": {"dtype": "U8", "shape": [3 << 20], "data_offsets": [0, 3 << 20]}}).encode()
hdr += b" " * (-len(hdr) % 8)
(INT4 / "model.safetensors").write_bytes(struct.pack("<Q", len(hdr)) + hdr + os.urandom(3 << 20))
DFL = MODELS / "qwen3-8-27b-dflash2" / "pytorch" / "bf16" / "1"      # CELL 1 still resolves the (unused) drafter path
DFL.mkdir(parents=True)
json.dump({"architectures": ["DFlash2DraftModel"]}, open(DFL / "config.json", "w"))
ARC = WORK / "arc"
ARC.mkdir()
shutil.copy(B.DATA / "arc-agi_evaluation_challenges.json", ARC / "arc-agi_evaluation_challenges.json")
shutil.copy(B.DATA / "arc-agi_evaluation_solutions.json", ARC / "arc-agi_evaluation_solutions.json")
json.dump({t: {"train": ch[t]["train"], "test": [{"input": q["input"]} for q in ch[t]["test"]]} for t in PICK},
          open(ARC / "arc-agi_test_challenges.json", "w"))
DEST = WORK / "shm"
DEST.mkdir()
# the payload dataset in the REAL Kaggle shape: /kaggle/input/datasets/<owner>/<slug>/<file>
if PAYLOAD_ENV:
    PAYLOAD = Path(PAYLOAD_ENV)
else:
    PAYLOAD = WORK / "inputs"
    _pd = PAYLOAD / "datasets" / "esfersami50" / "q27-e15b-payload"
    _pd.mkdir(parents=True)
    for _f in PAYSRC.glob("q27x_*.bin"):
        shutil.copy(_f, _pd / _f.name)
with socket.socket() as s:
    s.bind(("127.0.0.1", 0))
    PORT = s.getsockname()[1]
WIN = os.environ.get("E21H_HALF_SOLVE_SEC", "240" if MODE == "death" else "90")
os.environ.update(Q27X_ARC_ROOT=str(ARC), Q27X_WORKING=str(WORK), Q27X_MODEL=str(FP8), Q27X_SKIP_INSTALL="1",
                  PYTHONIOENCODING="utf-8", E11_HARNESS="1", E11_PORT=str(PORT), E21_FAKE_SERVER=str(FAKE),
                  E11_FAKE_SERVER=str(FAKE), E11_INT4=str(INT4), E11_DFLASH=str(DFL),
                  E12_DIR=str(WORK / "e12_duck"), E14_DIR=str(WORK / "e14_mod"), E14_DEST=str(DEST), E14_TIME_SCALE=SCALE,
                  E14_FIXTURES=str(FIX), FAKE_SPEED="300", FAKE_STATE_DIR=str(STATE), Q27X_PAYLOAD_DIR=str(PAYLOAD),
                  ARC3_HTTP_RETRY_BASE_SECONDS="0.05", ARC3_HTTP_RETRY_MAX_SECONDS="0.1",
                  E12_MAX_GEN="6000", E12_R6_FIRST_EXPOSURE="0", E12_R6_MIN_ADMIT_SEC="5", E12_B_RESERVE="1000",
                  E12_B_ATTEMPT_TOKENS_B1="4000", E12_B_MAX_ATTEMPTS="3",
                  Q27X_GPU_WAIT_MAX="1",                  # no nvidia-smi here: _wait_gpu_release would wait 180 s per call
                  E21_HALF_SOLVE_SEC=WIN, E21_B_SETUP_RESERVE_SEC="300",
                  E18_SILENCE_SEC=os.environ.get("E18_SILENCE_SEC", "15" if MODE == "halfAfail" else "120"))
for k in ("FAKE_REJECT", "FAKE_REJECT_FLAG", "FAKE_NEVER_READY", "FAKE_DIE_AFTER_SEC", "FAKE_DIE_FORM", "Q27X_PROFILE",
          "E12_REASONING_EFFORT", "KAGGLE_IS_COMPETITION_RERUN", "Q27X_TIME_BUDGET", "E15B_WD_POLL_SEC", "E15B_WD_FAIL_SEC",
          "E15B_WD_MIN_LEFT_SEC"):
    os.environ.pop(k, None)
if MODE == "rerun":
    # RERUN_ALL has no solve window: the solve ends when every attempt is done (the fake's programs end quickly)
    os.environ.update(KAGGLE_IS_COMPETITION_RERUN="1", Q27X_TIME_BUDGET=os.environ.get("E21H_RERUN_BUDGET", "2400"))
else:
    # a long notebook budget: e21_begin_half skips the fallback when < 30 min are left, and CELL 1 asserts that two
    # windows + the half-B reserve fit; the short per-half windows (E21_HALF_SOLVE_SEC) keep the run short
    os.environ.update(Q27X_PROFILE=os.environ.get("E21H_PROFILE", "EVAL6"), Q27X_TIME_BUDGET="10800")
if MODE == "fallbackA":
    os.environ["FAKE_REJECT"] = "0.19:w4a16" if VAR == "NB1" else "0.19:--mamba-ssm-cache-dtype"
if MODE == "halfAfail":
    os.environ["FAKE_NEVER_READY"] = "0.19"
if MODE == "death":
    os.environ.update(FAKE_DIE_AFTER_SEC="8", FAKE_DIE_FORM="0.19", FAKE_SPEED="60",
                      E15B_WD_POLL_SEC="2", E15B_WD_FAIL_SEC="20", E15B_WD_MIN_LEFT_SEC="30")

nb = json.load(open(NB, encoding="utf-8"))
code = ["".join(c["source"]) for c in nb["cells"] if c["cell_type"] == "code"]
heads = [c.splitlines()[0][:90] for c in code]
print(f"[e21 harness] {NBN} | variant {VAR} | mode {MODE} | {len(code)} code cells | work {WORK}", flush=True)
G = {"__name__": "__main__"}
t0 = time.time()
cell_sec, cell_err = [], None
for i, c in enumerate(code):
    t = time.time()
    try:
        exec(compile(c, f"<cell{i}>", "exec"), G)
    except BaseException:
        import traceback
        cell_err = (i, heads[i], traceback.format_exc()[-4000:])
        print(f"[e21 harness] UNCAUGHT in code cell {i} ({heads[i]}):\n{cell_err[2]}", flush=True)
        break
    finally:
        cell_sec.append(round(time.time() - t, 1))
faulthandler.cancel_dump_traceback_later()

checks = []


def check(label, cond, info=""):
    try:
        ok = bool(cond() if callable(cond) else cond)
    except Exception as e:
        ok, info = False, f"check raised {type(e).__name__}: {e} | {info}"
    checks.append((label, ok, "" if ok else str(info)[:1500]))


def jload(p):
    try:
        return json.loads(Path(p).read_text(encoding="utf-8"))
    except Exception as e:
        return {"__error__": repr(e)[:200]}


Q = WORK / "q27x"
st = G.get("E21_STATE") or {}
halves_run = list(G.get("E21_HALVES") or [])
want_halves = ["A"] if MODE == "rerun" else ["A", "B"]
launches = [json.loads(l) for l in open(STATE / "launches.jsonl", encoding="utf-8")] if (STATE / "launches.jsonl").exists() else []
stats = {}
for p in STATE.glob("stats_*.json"):
    d = jload(p)
    if "pid" in d:
        stats[d["pid"]] = d
port_of = lambda L: int(L["argv"][L["argv"].index("--port") + 1]) if "--port" in L["argv"] else None
la = [L for L in launches if port_of(L) == 1234]
lb = [L for L in launches if port_of(L) == 8011]
exp_seqs = 20 if VAR == "NB1" else 16
sub = jload(WORK / "submission.json")
test = jload(ARC / "arc-agi_test_challenges.json")

check("notebook: every code cell ran without an uncaught exception", cell_err is None, cell_err)
check("notebook: 10 code cells (CELL 0, 1, 1b, 2, 3, order, 5 engine, 6/7 functions, 8 runner, 9 report)",
      len(code) == 10 and "CELL 5" in heads[6] and "CELL 8" in heads[8] and "CELL 9" in heads[9], heads)
check(f"halves run = {want_halves} (rerun: half A only)", halves_run == want_halves, halves_run)
check("submission.json: every test task, every test input, attempt_1 + attempt_2 grids (lists of lists)",
      lambda: set(sub) == set(test) and all(len(sub[t]) == len(test[t]["test"]) for t in test)
      and all(isinstance(a, dict) and all(isinstance(a.get(k), list) and a[k] and all(isinstance(r, list) for r in a[k])
                                          for k in ("attempt_1", "attempt_2")) for t in sub for a in sub[t]),
      list(sub)[:8])
check("submission.json written atomically, no temp file left", not list(WORK.glob("submission.json.*")),
      list(WORK.glob("submission.json*")))
# ---- launches: argv form per half, Duck flags, the variant's config
check("every half-A launch (port 1234) used the vLLM 0.19 api_server form (--model <path>)",
      la and all(L["form"] == "0.19" and L["argv"][0] == "--model" for L in la), [(L["form"], L["argv"][:2]) for L in la])
if "B" in want_halves:
    check("every half-B launch (port 8011) used the vLLM 0.32 `vllm serve <path>` form", lb and all(
        L["form"] == "0.32" and not L["argv"][0].startswith("--") for L in lb), [(L["form"], L["argv"][:2]) for L in lb])
else:
    check("rerun: half B never launched (no 0.32-form launch, no port 8011)",
          not lb and not any(L["form"] == "0.32" for L in launches), [(L["form"], port_of(L)) for L in launches])
check("no launch was refused for missing Duck serving flags (fake exit 2)", not any(L["outcome"] == "refused" for L in launches),
      [L.get("problems") for L in launches if L["outcome"] == "refused"])


def first_ready(ls):
    return next((L for L in ls if L["outcome"] == "ready"), None)


def flag(L, k):
    return L["argv"][L["argv"].index(k) + 1] if L and k in L["argv"] else None


fa, fb = first_ready(la), first_ready(lb)
model_of = lambda L: (L["argv"][1] if L["form"] == "0.19" else L["argv"][0]) if L else ""
if MODE not in ("fallbackA", "halfAfail"):
    if VAR == "NB1":
        check("NB1 half A primary: INT4 weights (w4a16 path), --max-num-seqs 20, no SSM flag",
              fa and "w4a16" in model_of(fa) and flag(fa, "--max-num-seqs") == "20" and "--mamba-ssm-cache-dtype" not in fa["argv"],
              fa and fa["argv"])
    else:
        check("NB2 half A primary: FP8 weights, --max-num-seqs 16, --mamba-ssm-cache-dtype float16",
              fa and "w4a16" not in model_of(fa) and flag(fa, "--max-num-seqs") == "16"
              and flag(fa, "--mamba-ssm-cache-dtype") == "float16", fa and fa["argv"])
if "B" in want_halves:
    check(f"{VAR} half B primary: the same weights / seqs {exp_seqs} / SSM setting as half A's spec",
          fb and flag(fb, "--max-num-seqs") == str(exp_seqs) and (("w4a16" in model_of(fb)) == (VAR == "NB1"))
          and ((flag(fb, "--mamba-ssm-cache-dtype") == "float16") == (VAR == "NB2")), fb and fb["argv"])
check("served model names are never a Duck alias and are the E21 names",
      all(flag(L, "--served-model-name") in ("Qwen/Qwen3.8-27B-FP8", "Qwen/Qwen3.8-27B-INT4") for L in launches),
      [flag(L, "--served-model-name") for L in launches])
# ---- capacity: real running <= max-num-seqs, stats per server
check("real running never exceeded --max-num-seqs on any server (the fake's own counter)",
      stats and all(d["max_running"] <= d["max_num_seqs"] for d in stats.values()),
      {p: (d["form"], d["max_running"], d["max_inflight"], d["max_num_seqs"]) for p, d in stats.items()})
# ---- the reasoning key (vLLM reads only message["reasoning"])
hr = sum(d.get("hist_msgs_reasoning", 0) + d.get("hist_msgs_both", 0) for d in stats.values())
hrc = sum(d.get("hist_msgs_reasoning_content_only", 0) for d in stats.values())
rrc = sum(d.get("requests_history_reasoning_content_only", 0) for d in stats.values())
check("reasoning key: assistant history carried `reasoning` (> 0 messages) and never only `reasoning_content`",
      hr > 0 and hrc == 0 and rrc == 0, {"reasoning": hr, "reasoning_content_only_msgs": hrc, "requests_rc_only": rrc})
check("reasoning key: ARC3_REASONING_HISTORY_KEY == 'reasoning' at the end of the run",
      G.get("os") and G["os"].environ.get("ARC3_REASONING_HISTORY_KEY") == "reasoning",
      G.get("os") and G["os"].environ.get("ARC3_REASONING_HISTORY_KEY"))
check("no request exceeded --max-model-len (fake 400s)", sum(d.get("context_rejections", 0) for d in stats.values()) == 0,
      {p: d.get("context_rejections") for p, d in stats.items()})
# ---- per half: engine, Duck run, artefacts
expect_engine = {"A": MODE != "halfAfail", "B": True}
for H in want_halves:
    hs = (st.get("halves") or {}).get(H) or {}
    eng = hs.get("engine") or {}
    d = Q / f"half{H}"
    rep = jload(d / "e12_run_report.json")
    e = rep.get("e12_run") or {}
    if expect_engine[H]:
        want_used = "fallback" if (MODE == "fallbackA" and H == "A") else "primary"
        check(f"half {H}: engine ready on the {want_used} config ({eng.get('backend')})", eng.get("used") == want_used
              and str(eng.get("backend") or "").startswith("vllm-" + ("0.19.0" if H == "A" else "0.32.0")),
              {k: eng.get(k) for k in ("used", "backend", "fatal")} | {"attempts": [(a.get("tag"), a.get("why"), str(a.get("error"))[:200]) for a in eng.get("attempts") or []]})
        if MODE == "fallbackA" and H == "A":
            a0 = (eng.get("attempts") or [{}])[0]
            check("fallbackA: half A primary rejected at start (exited), then the fallback config was ready",
                  a0.get("tag") == "primary" and "exited" in str(a0.get("why") or a0.get("error"))
                  and any(L["outcome"] == "rejected" for L in la), (a0.get("why"), a0.get("error")))
            fl = first_ready(la)
            if VAR == "NB1":
                check("fallbackA NB1: half A fallback = FP8 weights, --max-num-seqs 16",
                      fl and "w4a16" not in model_of(fl) and flag(fl, "--max-num-seqs") == "16", fl and fl["argv"])
            else:
                check("fallbackA NB2: half A fallback = FP8 without --mamba-ssm-cache-dtype, seqs 16",
                      fl and "--mamba-ssm-cache-dtype" not in fl["argv"] and flag(fl, "--max-num-seqs") == "16",
                      fl and fl["argv"])
        cap = eng.get("capacity") or {}
        want_streams = 16 if (MODE == "fallbackA" and H == "A") else exp_seqs
        check(f"half {H}: capacity check from the vLLM lines -> {want_streams} streams; Duck streams / workers = that",
              cap.get("streams") == want_streams and e.get("streams") == want_streams and e.get("rev6_workers") == want_streams,
              (cap, e.get("streams"), e.get("rev6_workers")))
        check(f"half {H}: smoke OK, /v1/models = the served name", any((a.get("smoke") or {}).get("ok") for a in eng.get("attempts") or [])
              and any(a.get("models") for a in eng.get("attempts") or []), [(a.get("smoke"), a.get("models")) for a in eng.get("attempts") or []])
        check(f"half {H}: Duck ran without solver error; branches started; isolation preflight PASS",
              not e.get("error") and (e.get("branches_started") or 0) > 0
              and (e.get("rev6_preflight") or {}).get("isolation_state") == "PASS",
              {k: e.get(k) for k in ("error", "branches_started", "branches_done")} | {"iso": (e.get("rev6_preflight") or {}).get("isolation_state")})
        bs = e.get("b_summary") or {}
        sl = bs.get("server_log") or {}
        check(f"half {H}: b_summary from the vLLM probes (gauges, server-side tokens, stats-line summary with lines)",
              not bs.get("error") and bs.get("gauge_samples", 0) >= 0 and bs.get("server_gen_tokens") is not None
              and (sl.get("decode_lines") or 0) > 0 and sl.get("startup", {}).get("kv_tokens"),
              {k: bs.get(k) for k in ("error", "server_gen_tokens", "server_running_mean", "gauge_samples")} | {"sl": sl})
        check(f"half {H}: no worker error, no stale SERVER_DOWN", not bs.get("worker_errors"), bs.get("worker_errors"))
        check(f"half {H}: prefix cache reported (cached tokens > 0 in the Duck usage)",
              ((rep.get("usage_all") or {}).get("cached_tokens") or 0) > 0, rep.get("usage_all"))
        if MODE != "rerun":
            check(f"half {H}: scored (eval_task_norm_pct, pass1, pass2)", rep.get("eval_task_norm_pct") is not None
                  and rep.get("eval_pass1_hits") is not None, {k: rep.get(k) for k in ("eval_query_hits", "eval_task_norm_pct")})
        logs = sorted(p.name for p in d.glob("vllm_server_*.log"))
        check(f"half {H}: artefacts: e12_run_report.json, vllm_server_half{H}_<tag>.log, sglang_decode_summary.json, duck/, "
              f"Q27X_E21_{VAR}_HALF{H}_DUCK_BUNDLE.zip",
              "__error__" not in rep and logs and all(n.startswith(f"vllm_server_half{H}_") for n in logs)
              and (d / "sglang_decode_summary.json").exists() and (d / "duck").is_dir()
              and (WORK / f"Q27X_E21_{VAR}_HALF{H}_DUCK_BUNDLE.zip").exists(),
              (logs, sorted(p.name for p in d.glob("*")) if d.exists() else None))
    else:
        check(f"half {H}: no engine (expected in {MODE}); both configs tried; Duck not run; recorded, not raised",
              not eng.get("used") and eng.get("fatal") and len(eng.get("attempts") or []) == 2
              and "not run" in str(e.get("error") or (hs.get("e12_run") or {}).get("error") or ""),
              {k: eng.get(k) for k in ("used", "fatal")} | {"attempts": [(a.get("tag"), a.get("why"), str(a.get("error"))[:200]) for a in eng.get("attempts") or []], "e12_error": e.get("error")})
    check(f"half {H}: no step error recorded by the runner (begin / cell6 / cell7 / end)", not hs.get("errors"),
          [(x.get("step"), x.get("traceback", "")[-1500:]) for x in hs.get("errors") or []])
    check(f"half {H}: the server was stopped at the half's end (end_sec set)", hs.get("end_sec") is not None, hs.get("end_sec"))
if "A" in want_halves and "B" in want_halves:
    ea, eb = (st.get("halves") or {}).get("A", {}).get("end_sec"), ((st.get("halves") or {}).get("B", {}).get("engine") or {}).get("begin_sec")
    check("half B began after half A ended (one server at a time)", ea is not None and eb is not None and eb >= ea - 1, (ea, eb))
    tA = [L["t"] for L in la]
    tB = [L["t"] for L in lb]
    check("every half-B launch came after every half-A launch", not tA or not tB or min(tB) > max(tA), (tA, tB))
R21 = jload(Q / "e21_report.json")
check("e21_report.json: one row per half with score_full, score_attempt1_only, engine_used, config_used, attempts, errors",
      "__error__" not in R21 and set((R21.get("halves") or {})) == set(want_halves)
      and all({"score_full", "score_attempt1_only", "engine_used", "config_used", "attempts", "errors"} <= set(h)
              for h in (R21.get("halves") or {}).values()), {k: sorted(v) for k, v in (R21.get("halves") or {}).items()})
check(f"final bundle Q27X_E21_{VAR}_BUNDLE.zip holds e21_report.json + submission.json",
      lambda: {"q27x/e21_report.json", "submission.json"} <= set(zipfile.ZipFile(WORK / f"Q27X_E21_{VAR}_BUNDLE.zip").namelist()),
      list(WORK.glob("*.zip")))
if MODE == "rerun":
    gen = jload(Q / "halfA" / "e12_generated_attempts.json")
    _other = sum(1 for t in test for a, q in zip(sub.get(t, []), test[t]["test"])
                 if a.get("attempt_1") != q["input"] or a.get("attempt_2") != q["input"])
    check("rerun: the solver took every test task; submission.json = half A's generated attempts (not only identity)",
          set(G.get("TASK_IDS") or []) == set(test) and set(gen) == set(test) and all(sub[t] == gen[t] for t in test) and _other > 0,
          (sorted(gen) if isinstance(gen, dict) else gen, _other))
else:
    P21 = (G.get("PROFILE_TABLE") or {}).get("E21X2EVAL120") or {}
    check("profile E21X2EVAL120 (the Kaggle default): 120 eval tasks, 5.5-h window; 2 windows + reserve fit the budget",
          P21.get("n_tasks") == 120 and P21.get("solve_window_sec") == 5.5 * 3600
          and 2 * P21["solve_window_sec"] + 25 * 60 < P21["time_budget_sec"] - P21["hard_margin_sec"], P21)
if MODE == "death":
    ha = ((st.get("halves") or {}).get("A") or {})
    wd = (ha.get("e12_run") or {}).get("watchdog") or {}
    rl = wd.get("relaunches") or []
    check("death: the 0.19 server died mid-solve (fake 'died' record, once)",
          sum(1 for L in la if L["outcome"] == "died") == 1, [L["outcome"] for L in la])
    check("death: the watchdog relaunched it once, OK (e21_relaunch), short test limits",
          len(rl) == 1 and rl[0].get("ok") and rl[0].get("dead") and (wd.get("limits") or {}).get("poll_sec") == 2.0, wd)
    check("death: the relaunched server log exists and the relaunched server served Duck tool requests",
          (Q / "halfA" / "vllm_server_halfA_relaunch0.log").exists()
          and any(d["form"] == "0.19" and d["tool_requests"] > 0 for p, d in stats.items()
                  if p == (la[-1]["pid"] if la else None)), (sorted(p.name for p in (Q / "halfA").glob("*.log")), la[-1:] if la else None))
    check("death: half A engine record lists the relaunch", (ha.get("engine") or {}).get("relaunches"),
          (ha.get("engine") or {}).get("relaunches"))

# ---- clean up every fake server still alive
try:
    G["e11_kill_server"](wait=False)
except Exception:
    pass
for L in launches:
    try:
        os.kill(L["pid"], 9)
    except Exception:
        pass
bad = [c for c in checks if not c[1]]
print(f"\n[e21 SUMMARY] {VAR} {MODE}: {len(checks) - len(bad)}/{len(checks)} PASS in {time.time() - t0:.0f} s | cell seconds {cell_sec}")
for c in checks:
    print(f"[e21 {'PASS' if c[1] else 'FAIL'}] {c[0]}" + ("" if c[1] else f" -> {c[2]}"))
print("info: fake servers", json.dumps({p: {k: d.get(k) for k in ("form", "port", "max_num_seqs", "max_running", "max_inflight",
                                                                    "tool_requests", "preflight", "smoke", "hist_msgs_reasoning",
                                                                    "cached_reported", "kv_tokens")} for p, d in stats.items()}))
print("info: launches", [(L["form"], port_of(L), L["outcome"]) for L in launches])
print("@@E21_HARNESS_OK@@" if not bad else "@@E21_HARNESS_FAIL@@", flush=True)
sys.exit(0 if not bad else 1)
