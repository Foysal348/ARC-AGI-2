# Experiment 21 — Duck config B on vLLM 0.19 + vLLM 0.32 (two halves per notebook)

**Status (2026-10-28):** notebooks built and under validation (local CPU harness, then Kaggle CPU kit, then 2× agent
validation). Nothing has been pushed.

## Why

Duck config B (Experiment 15, R3K1/R3K2) has only ever run on SGLang 0.5.21 + RedHat INT4 + DFlash2. On EVAL120, in the
same 6-h window, it scored task-norm 33.47 % (R3K1) and 39.03 % (R3K2).

On the Poetiq method, vLLM beat SGLang on the LB by about 4-7 points:
- vLLM: S1-60K 34.58 / 31.94, S1-49K 32.08, S1-55K 31.81;
- SGLang: P1-60K 29.17, E15P 26.94.

Per-request quality on eval looked equal. Iteration 1 of R5 vs E15P, on the 26 tasks where R5 closed naturally under
60k: 23 vs 22 train-verified. Nobody had measured Duck on vLLM. E12-V ran only a 1-task smoke.

## What runs

| Notebook | Weights / streams | Half A (0-~6 h) | Half B (~6-12 h) | Fallback per half |
|---|---|---|---|---|
| `Q27-XHIGH-E21_DUCKB_VLLM_NB1_INT4_S20.ipynb` | RedHat INT4 W4A16 + MTP-3, **20** streams | vLLM 0.19.0 | vLLM 0.32.0 | FP8 MTP-3, 16 streams |
| `Q27-XHIGH-E21_DUCKB_VLLM_NB2_FP8_SSM16_S16.ipynb` | FP8 + MTP-3 + `--mamba-ssm-cache-dtype float16`, **16** streams | vLLM 0.19.0 | vLLM 0.32.0 | the same without the SSM flag (= S1-60K's engine) |

**Both halves:**
- the same 120 evaluation tasks;
- fresh Duck state;
- own folder `q27x/half<H>/`;
- a solve window of 5.5 h from each half's own solve start (`E21_HALF_SOLVE_SEC`). R3K had about 5.7 h.

Half A must end by `HARD_STOP − 180 − window − 25 min`, so that half B fits.

The hidden rerun (`RERUN_ALL`) runs **half A only**: all 240 tasks, 12 h.

**Report:** `q27x/e21_report.json` gives, per half:
- the full score;
- the **attempt-1-only score**, which can be compared across halves whatever attempt 2 reached;
- the config actually used, the capacity check, tok/s, prefix-cache hits, preemptions and the timeline.

## Donor map (build_e21.py takes and asserts every piece)

| New cell | Source | Change |
|---|---|---|
| CELL 0 | identical in E15B R3K2, E12-V, E18, S1, VMS (asserted) | none |
| CELL 1 | E15B R3K2 (`c058d58b`) CELL 1 | default profile `E21X2EVAL120` (new row, 12 h − 3 min, `solve_window_sec` 5.5 h); E21 block appended (variant, half specs, `ENGINE_BACKEND = "vllm"`, staging list, window, ports, served names, 0.32 wheelhouse, SGLang cache diagnostic off) |
| CELL 1b | E15B CELL 1b | staging also for `vllm`, of the variant's weights (`E21_STAGE_PATHS`); the read probe on them; the submit-arm label |
| CELL 2 | E15B CELL 2, verbatim | (with `ENGINE_BACKEND = "vllm"` it installs vllm==0.19.0 into the kernel, the S1 path) |
| CELL 3 | E15B CELL 3 (Duck package `q27x_e15b_duck_9e4b89285136.bin`) | + `ARC3_REASONING_HISTORY_KEY=reasoning` (see Findings 1) |
| order cell | identical in all donors (asserted) | none |
| CELL 5 (engine) | verbatim: E12-V CELL 5 (`e85b69c2`, the run 2 Duck server: libcuda shim, request helper, Prometheus reader + aliases, stats-line summary, kill); E18 R2 CELL 5 (`116d2d41`: `e18_install`, `E18Server`, `_e18_kill_gpu_pids`, `_wait_gpu_release` = S1) | new `e21_engine_new.py`: vLLM 0.19 flags (= the E12-V command + `--max-num-seqs` per half + optional SSM flag + INT4 path), vLLM 0.32 flags (= VMS `vms_flags` arm + Duck serving flags + 135,168 context), capacity check, launch + smoke, begin / end half, watchdog relaunch, staging join |
| CELL 6 | E15B CELL 6, wrapped as `e21_cell6()` (every module-level name global) | `_e12_capacity_probe` → vLLM gauges; `_e15b_gen_tokens_total` → `vllm:generation_tokens_total`; `_e15b_server_log_summary` → vLLM stats lines; watchdog → `e21_relaunch()`; the solve end capped by the half's end. The scheduler call (`solve_all_r6` + every config-B parameter) is unchanged. |
| CELL 7 | E15B CELL 7, wrapped as `e21_cell7()` | per-half bundle name; cache-note text |
| CELL 8 | new | runs the halves: begin → CELL 6 → CELL 7 → end, each step isolated |
| CELL 9 | new | the two-half report + bundle |

**Dropped from E15B:**
- the SGLang engine cell;
- the E14-A1/A2 SGLang measurement arms;
- the E14 JIT-cache cell.

**Dead code kept:** `_e12_parity` (parity profile only, never called).

## Findings while building (2026-10-28)

1. **Reasoning history key.** E15B's Duck sends prior thinking as `reasoning_content` (DUCK_ENV).
   - vLLM 0.19 reads only `message["reasoning"]` on input: `vllm/entrypoints/chat_utils.py:1512`.
   - vLLM 0.32 does the same: `vllm/renderers/chat_utils.py:2083`.
   - So on vLLM the history would lose the thinking, and prefix-cache hits would drop.
   - The E12-V run 2 Duck sent `reasoning`, and its prompts grew by the generated tokens (6,882 + 12,288 → 19,215).
   - Fix: `ARC3_REASONING_HISTORY_KEY=reasoning` (CELL 3 and each half).
2. **Duck package correction.** R3K2 ran `q27x_e15b_duck_9e4b89285136.bin` (CELL 3 line 9), not `d6faf44ec0d5` (the R3J notebooks, Exp 15 Notes/14).
3. **SSM fp16 is not new for us.** SGLang production already runs `--mamba-ssm-dtype float16`. vLLM 0.19's `CacheConfig` has `mamba_ssm_cache_dtype` (`config/cache.py:105`).
4. **INT4 vs FP8 template and tokenizer.** Checked on the E13 fixture copies of both model folders:
   - `chat_template.jinja` is identical (sha c3cf9e34), and equal to the FP8 tokenizer_config's embedded template;
   - vocab and added tokens are equal;
   - encode and decode are identical on grid, code, thinking and template text.
   - To be re-checked on the real Kaggle model files in the CPU kit.
5. **RedHat INT4 quantization config:** compressed-tensors pack-quantized W4A16 g128. It ignores `re:^mtp.*`, every `linear_attn` (GDN), `lm_head` and the vision tower. The MTP head and the GDN layers are BF16. vLLM 0.32 ran it (VMS, diagnostic). On vLLM 0.19 it is untested: NB1's fallback covers that.
6. **R3K2 really ran 16 concurrent streams:** server running mean 15.62; 3,109 lines at 16. Its `E12_LIVE_BRANCHES = 12` is unused by the rev6 scheduler.
7. **Duck on vLLM prefix cache (E12-V run 2):** turn 2 hit 4,800 / 19,215; later turns 67-94 %. SGLang gives 93 %. vLLM's mamba `align` mode caches in 1,600-token blocks.

## Pre-run capacity check (per half, printed by CELL 5)

- Effective KV = vLLM's "Maximum concurrency" factor × max-model-len.
- Duck streams = min(seqs, effective KV // 50,000), at least 8.
- R3K2 per-attempt peak context: p50 57k, p90 65k, max 79k.
- **NB2 (FP8, 16 streams):** needs 16 × 57k ≈ 0.91 M at the p50 peak. FP8 effective KV is about 1.03-1.11 M.
- **NB1 (INT4, 20 streams):** needs about 1.14 M. INT4 frees about 3.5 GB per GPU.
- Both are checked against the logged values at launch.

## Validation plan

1. Local CPU harness (`src/harness/`): fake vLLM Duck server and modes commit / rerun / fallbackA / halfAfail / death / reasoningkey.
2. Kaggle CPU kit on the pinned image (Python 3.12). It also hashes the real model files from Finding 4.
3. 10 agents validating twice.
4. GPU commit / push only after the user's go.
