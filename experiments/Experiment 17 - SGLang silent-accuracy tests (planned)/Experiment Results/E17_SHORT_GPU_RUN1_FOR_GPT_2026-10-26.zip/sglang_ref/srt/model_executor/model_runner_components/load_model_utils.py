from __future__ import annotations

import datetime
import logging
import os
import socket
import threading
from typing import TYPE_CHECKING, Any

import msgspec
import torch
import torch.distributed as dist

from sglang.srt.arg_groups.overrides import (
    modelexpress_transport_of,
    modelexpress_url_of,
)
from sglang.srt.configs.device_config import DeviceConfig
from sglang.srt.configs.load_config import LoadConfig, LoadFormat
from sglang.srt.constants import GPU_MEMORY_TYPE_WEIGHTS
from sglang.srt.debug_utils.tensor_dump_forward_hook import (
    register_forward_hook_for_model,
)
from sglang.srt.distributed.parallel_state import monkey_patch_vllm_parallel_state
from sglang.srt.model_loader.loader import get_model_loader
from sglang.srt.model_loader.remote_instance_weight_loader_utils import (
    RemoteInstanceWeightLoaderBackend,
    trigger_init_weights_send_group_for_remote_instance_request,
)
from sglang.srt.platforms import current_platform
from sglang.srt.runtime_context import (
    get_context,
    get_exec,
    get_model,
    get_observability,
    get_parallel,
)
from sglang.srt.utils.common import is_npu
from sglang.srt.utils.network import NetworkAddress

if TYPE_CHECKING:
    from sglang.srt.configs.model_config import ModelConfig
    from sglang.srt.server_args import ServerArgs
    from sglang.srt.speculative.spec_info import SpeculativeAlgorithm

logger = logging.getLogger(__name__)

_is_npu = is_npu()


UNBALANCED_MODEL_LOADING_TIMEOUT_S = 480  # leave more time for post data processing


def maybe_precompile_model_kernels_after_loading(model, device: str) -> None:
    precompile = getattr(model, "precompile_kernels_after_loading", None)
    if precompile is None:
        return

    if device == "cuda":
        current_platform.synchronize()
        current_platform.empty_cache()
    precompile()
    if device == "cuda":
        current_platform.synchronize()
        current_platform.empty_cache()


class LoadedModel(msgspec.Struct, frozen=True, kw_only=True):
    loader: Any
    model: Any
    remote_instance_weight_info: Any | None
    startup_weight_load: Any | None = None


def maybe_downgrade_dtype_for_legacy_gpu(*, model_config: ModelConfig) -> None:
    if torch.cuda.get_device_capability()[0] < 8:
        logger.info(
            "Compute capability below sm80. Use float16 due to lack of bfloat16 support."
        )

        # Device-driven, so every runner in the process resolves the same way;
        # the per-runner truth is model_config.dtype, this is the record.
        get_context().override("ModelRunner._sm80_dtype_fallback", dtype="float16")
        model_config.dtype = torch.float16
        if torch.cuda.get_device_capability()[1] < 5:
            raise RuntimeError("SGLang only supports sm75 and above.")


def maybe_trigger_remote_instance_nccl_send_group(
    *, tp_rank: int, load_format: str | None = None
) -> None:
    """``load_format`` is this runner's effective format: a draft loading under
    ``--speculative-draft-draft-load-format`` needs its own send group, and the
    target's format cannot answer for it."""
    if (
        (load_format or get_model().load_format) == LoadFormat.REMOTE_INSTANCE
        and get_model().remote_instance_weight_loader_backend
        == RemoteInstanceWeightLoaderBackend.NCCL
    ):
        if tp_rank == 0:
            instance_ip = NetworkAddress.resolve_host(socket.gethostname())
            t = threading.Thread(
                target=trigger_init_weights_send_group_for_remote_instance_request,
                args=(
                    get_model().remote_instance_weight_loader_seed_instance_ip,
                    get_model().remote_instance_weight_loader_seed_instance_service_port,
                    get_model().remote_instance_weight_loader_send_weights_group_ports,
                    instance_ip,
                ),
            )
            t.start()


def load_kv_cache_scales(*, model, kv_cache_dtype: str) -> None:
    """``kv_cache_dtype`` is the caller's resolved value. Required rather than
    defaulted: a fallback to ``server_args`` would be a hidden global read for
    any future caller that forgets to pass one."""
    if kv_cache_dtype == "fp8_e4m3":
        if get_model().quantization_param_path is not None:
            if callable(getattr(model, "load_kv_cache_scales", None)):
                model.load_kv_cache_scales(get_model().quantization_param_path)
                logger.info(
                    "Loaded KV cache scaling factors from %s",
                    get_model().quantization_param_path,
                )
            else:
                raise RuntimeError(
                    "Using FP8 KV cache and scaling factors provided but "
                    "model %s does not support loading scaling factors.",
                    model.__class__,
                )
        else:
            logger.warning(
                "Using FP8 KV cache but no scaling factors "
                "provided. Defaulting to scaling factors of 1.0."
            )


def resolve_sliding_window_size(model, model_config: ModelConfig) -> int | None:
    # Parse other args
    sliding_window_size = None
    if hasattr(model, "get_attention_sliding_window_size"):
        sliding_window_size = model.get_attention_sliding_window_size()
    elif model_config.is_hybrid_swa and model_config.sliding_window_size is not None:
        # sliding window field in model config may have different meaning for different kinds of models (e.g., dllm), here we only consider the sliding window in SWA model
        sliding_window_size = model_config.sliding_window_size
    elif model_config.attention_chunk_size is not None:
        sliding_window_size = model_config.attention_chunk_size
        logger.info(
            f"Setting sliding_window_size to be attention_chunk_size: {sliding_window_size}"
        )
    return sliding_window_size


def report_online_quantization(*, model) -> None:
    # TODO: Make sure all models have `quant_config` attribute, and all online quantization methods register which layers they actually quantize.
    quantized_layers = getattr(
        getattr(model, "quant_config", None), "quantized_layers", None
    )
    if (
        get_model().quantization is not None
        and isinstance(quantized_layers, tuple)
        and len(quantized_layers) == 2
    ):
        layer_types, quantized_layers_count = quantized_layers
        logger.info(
            f"Online {get_model().quantization} quantization: quantized {quantized_layers_count} layers of types: {layer_types}"
        )


def maybe_register_debug_tensor_dump_hook(
    *,
    model,
    spec_algorithm: SpeculativeAlgorithm,
    is_draft_worker: bool,
    tp_size: int,
    tp_rank: int,
    pp_rank: int,
) -> None:
    if get_observability().debug_tensor_dump_output_folder is not None:
        dump_folder = get_observability().debug_tensor_dump_output_folder
        if spec_algorithm.is_eagle():
            role = "draft" if is_draft_worker else "target"
            dump_folder = os.path.join(dump_folder, role)
        register_forward_hook_for_model(
            model,
            dump_folder,
            get_observability().debug_tensor_dump_layers,
            tp_size,
            tp_rank,
            pp_rank,
        )


def build_load_config(
    *,
    server_args: ServerArgs,
    tp_rank: int,
    load_format: str | None = None,
    remote_instance_weight_transporter_engine: Any,
    remote_instance_weight_transporter_session_id: str,
    draft_model_idx: int | None,
    weight_cache_mode: str,
    weight_cache_socket: str | None,
) -> LoadConfig:
    from sglang.srt.configs.modelopt_config import ModelOptConfig

    modelopt_config = ModelOptConfig(
        quant=get_model().modelopt_quant,
        checkpoint_restore_path=get_model().modelopt_checkpoint_restore_path,
        checkpoint_save_path=get_model().modelopt_checkpoint_save_path,
        export_path=get_model().modelopt_export_path,
        quantize_and_serve=get_model().quantize_and_serve,
    )

    return LoadConfig(
        load_format=load_format or get_model().load_format,
        download_dir=get_model().download_dir,
        model_loader_extra_config=get_model().model_loader_extra_config,
        tp_rank=tp_rank,
        remote_instance_weight_loader_seed_instance_ip=get_model().remote_instance_weight_loader_seed_instance_ip,
        remote_instance_weight_loader_seed_instance_service_port=get_model().remote_instance_weight_loader_seed_instance_service_port,
        remote_instance_weight_loader_send_weights_group_ports=get_model().remote_instance_weight_loader_send_weights_group_ports,
        remote_instance_weight_loader_backend=get_model().remote_instance_weight_loader_backend,
        remote_instance_weight_loader_transfer_engine=remote_instance_weight_transporter_engine,
        remote_instance_weight_loader_transfer_engine_session_id=remote_instance_weight_transporter_session_id,
        modelexpress_url=modelexpress_url_of(server_args),
        modelexpress_transport=modelexpress_transport_of(server_args),
        modelopt_config=modelopt_config,
        rl_quant_profile=get_model().rl_quant_profile,
        draft_model_idx=draft_model_idx,
        weight_cache_mode=weight_cache_mode,
        weight_cache_socket=weight_cache_socket,
    )


def maybe_enable_ipc_weight_cache(
    *,
    load_config: LoadConfig,
) -> None:
    """Switch ``load_config`` onto the IPC weight-cache path, in place.

    Overrides the load format to ``IPC_CACHE`` (remembering the original as the
    disk fallback). Idempotent: the format swap is guarded on ``!= IPC_CACHE``
    so a second call (e.g. a weight reload) can't overwrite the captured
    fallback format.
    """
    if get_model().weight_cache_mode == "off":
        return

    if load_config.load_format != LoadFormat.IPC_CACHE:
        load_config.fallback_load_format = load_config.load_format
        load_config.load_format = LoadFormat.IPC_CACHE


def load_model_with_memory_saver(
    *,
    model_config: ModelConfig,
    load_config: LoadConfig,
    device: str,
    gpu_id: int,
    memory_saver_adapter: Any,
    is_draft_worker: bool,
) -> LoadedModel:
    # Remove monkey_patch when linear.py quant remove dependencies with vllm
    monkey_patch_vllm_parallel_state()

    if not is_draft_worker:
        architectures = model_config.hf_config.architectures or []
        is_qwen4_exp = "Qwen4ExpForConditionalGeneration" in architectures
        ple_offload_embedding = get_exec().offload.ple_offload_embedding
        if ple_offload_embedding and not is_qwen4_exp:
            raise ValueError(
                "--ple-offload-embedding only supports Qwen4ExpForConditionalGeneration"
            )
        if is_qwen4_exp:
            model_config.hf_text_config.ple_offload_embedding = ple_offload_embedding
            model_config.hf_text_config.ple_offload_backend = (
                get_exec().offload.ple_offload_backend
            )
            if get_exec().offload.ple_offload_backend != "file":
                model_config.hf_text_config.ple_offload_dir = (
                    get_exec().offload.ple_offload_dir
                )
            else:
                from sglang.srt.models.qwen4_exp_ple_table import (
                    check_file_backend_supported,
                    default_ple_table_dir,
                )

                model_config.hf_text_config.ple_offload_dir = (
                    get_exec().offload.ple_offload_dir
                    or default_ple_table_dir(get_model().model_path)
                )
                if ple_offload_embedding and device == "cuda":
                    check_file_backend_supported(
                        torch.cuda.current_device() if torch.cuda.is_available() else 0
                    )

    enable_cpu_backup = get_exec().features.enable_weights_cpu_backup or (
        is_draft_worker and get_exec().features.enable_draft_weights_cpu_backup
    )

    # In zero-copy IPC mode, the weights are shared with the daemon via
    # CUDA IPC and must not be offloaded/reloaded by the memory saver.
    is_ipc_zero_copy = get_model().weight_cache_mode != "off"
    if is_ipc_zero_copy and enable_cpu_backup:
        logger.warning(
            "[ModelRunner] Disabling weights CPU backup in zero-copy IPC mode — "
            "IPC-mapped weights cannot be offloaded to CPU."
        )
        enable_cpu_backup = False

    remote_instance_weight_info = None
    startup_weight_load = None
    with memory_saver_adapter.region(
        GPU_MEMORY_TYPE_WEIGHTS,
        enable_cpu_backup=enable_cpu_backup,
    ):
        loader = get_model_loader(
            load_config=load_config,
            model_config=model_config,
        )
        device_config = DeviceConfig(device, gpu_id)
        if get_model().is_startup_weight_load_overlap:
            from sglang.srt.model_executor.model_runner_components.startup_weight_load import (
                StartupWeightLoadManager,
            )

            startup_weight_load = StartupWeightLoadManager.create_from_published_config(
                loader=loader,
                model_config=model_config,
                load_config=load_config,
                device_config=device_config,
                is_draft_worker=is_draft_worker,
            )
            model = startup_weight_load.prepare()
        else:
            model = loader.load_model(
                model_config=model_config,
                device_config=device_config,
            )
        if hasattr(loader, "remote_instance_transfer_engine_weight_info"):
            remote_instance_weight_info = (
                loader.remote_instance_transfer_engine_weight_info
            )
    if (
        not is_draft_worker
        and get_exec().offload.ple_offload_embedding
        and device == "cuda"
    ):
        current_platform.empty_cache()
    # Cache needs to be cleared after loading model weights (in the loader.load_model function).
    # To avoid conflict with memory_saver_adapter.region, empty_cache operation is now moved here.
    if _is_npu:
        torch.npu.empty_cache()
    monkey_patch_vllm_parallel_state(reverse=True)

    return LoadedModel(
        loader=loader,
        model=model,
        remote_instance_weight_info=remote_instance_weight_info,
        startup_weight_load=startup_weight_load,
    )


def dist_barrier_after_load(
    *,
    elastic_ep_backend: str | None,
    tp_rank: int,
    is_ep_joiner: bool = False,
) -> None:
    if elastic_ep_backend == "mooncake":
        # Mooncake does not support `monitored_barrier`
        if not is_ep_joiner:
            dist.barrier(group=get_parallel().tp_group.cpu_group)
    else:
        # Handle the case where some ranks do not finish loading.
        try:
            dist.monitored_barrier(
                group=get_parallel().tp_group.cpu_group,
                timeout=datetime.timedelta(seconds=UNBALANCED_MODEL_LOADING_TIMEOUT_S),
                wait_all_ranks=True,
            )
        except RuntimeError:
            raise ValueError(
                f"TP rank {tp_rank} could finish the model loading, but there are other ranks that didn't finish loading. It is likely due to unexpected failures (e.g., OOM) or a slow node."
            ) from None
