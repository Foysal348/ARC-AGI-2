# E17: SGLang silent-accuracy tests (#43567 chain, DFlash parity)

profile E17SHORT, rerun False, engine sglang-0.5.21-int4-dflash2-w6-s16, plan PLAN_E17 rev 2 (2026-10-26)
E17 cell error: none

## Phase 0

- schedule_batch.py sha256 b2f78c781de88c36ce27cc5d44b343420338b4da299e885c575665d6fab843ca; #43567 at start not_applied; after apply applied; at the end not_applied
- DFlash taps [5, 19, 33, 47, 61] (num_target_layers 64, block 8): ok True
- vocab config 248320, used 248320; GDN backend line True, KDA line False
- checkpoint KV-scale keys 32 ['model.language_model.layers.11.self_attn.k_scale', 'model.language_model.layers.11.self_attn.v_scale', 'model.language_model.layers.15.self_attn.k_scale', 'model.language_model.layers.15.self_attn.v_scale', 'model.language_model.layers.19.self_attn.k_scale', 'model.language_model.layers.19.self_attn.v_scale', 'model.language_model.layers.23.self_attn.k_scale', 'model.language_model.layers.23.self_attn.v_scale']; scale log lines ['[2026-10-26 17:20:07 TP0] Using FP8 KV cache but no scaling factors provided. Defaulting to scaling factors of 1.0.', '[2026-10-26 17:20:07 TP3] Using FP8 KV cache but no scaling factors provided. Defaulting to scaling factors of 1.0.', '[2026-10-26 17:20:07 TP2] Using FP8 KV cache but no scaling factors provided. Defaulting to scaling factors of 1.0.', '[2026-10-26 17:20:07 TP1] Using FP8 KV cache but no scaling factors provided. Defaulting to scaling factors of 1.0.', '[2026-10-26 17:20:10 TP0] Using FP8 KV cache but no scaling factors provided. Defaulting to scaling factors of 1.0.', '[2026-10-26 17:20:10 TP1] Using FP8 KV cache but no scaling factors provided. Defaulting to scaling factors of 1.0.']

- runtime KV scales (TP0, first 0 of None layers): []

## T1 arms (full-vocabulary KL, reference = the same prompt after flush + warm prefixes)

| arm | launch | slots / interval | verdict | prompt | ref cached | seed cached | reuse cached | A/A KL max | tol | reuse KL max | top-1 changed | alloc attempts / failed | stale candidate / confirmed | spec fallback / crossed | safety leaks / stale |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| L1_t1a_128 | — | None | RemoteDisconnected: Remote end closed connection without response | | | | | | | | | | | | |
| L5_t1c_dflash | — | None | RemoteDisconnected: Remote end closed connection without response | | | | | | | | | | | | |
| L7_t1a_128_patched | — | None | RemoteDisconnected: Remote end closed connection without response | | | | | | | | | | | | |
| L9_t1c_dflash_patched | — | None | RemoteDisconnected: Remote end closed connection without response | | | | | | | | | | | | |

**Decision A:** {"unpatched_bug_arms": [], "patched_clean": [], "verdict": "NOT_EXPOSED_OR_INCONCLUSIVE"}

**L6 control (no_buffer + MTP, #43387 path):** SHORT session (user 2026-10-26): follow-up only if the bug shows

## T2 natural pressure (production flags, 16 streams)

- T2 skipped: SHORT session (user 2026-10-26): follow-up only if the bug shows

## T3b DFlash vs target-only (radix off, greedy)

- L12_t3b_target: verdict None; compares {}; rows null; accept None; error 
- L13_t3b_dflash: verdict None; compares {}; rows null; accept None; error 

## T3a fp16 vs fp32 SSM (long prefixes, target-only, radix off)

- fp16 A/A: null
- fp32 vs fp16: null

skipped: {"L2_t1a_128_hook_off": "SHORT session (user 2026-10-26): follow-up only if the bug shows", "L3_t1a_256": "SHORT session (user 2026-10-26): follow-up only if the bug shows", "L4_t1b_forced": "SHORT session (user 2026-10-26): follow-up only if the bug shows", "L6_class2_mtp": "SHORT session (user 2026-10-26): follow-up only if the bug shows", "L12_t3b_target": "SHORT session (user 2026-10-26): follow-up only if the bug shows", "L13_t3b_dflash": "SHORT session (user 2026-10-26): follow-up only if the bug shows", "L8_t1a_256_patched": "SHORT session (user 2026-10-26): follow-up only if the bug shows", "T2": "SHORT session (user 2026-10-26): follow-up only if the bug shows", "L15_t3a_fp32": "SHORT session (user 2026-10-26): follow-up only if the bug shows"}

## Launches

| launch | ok | sec | hook self-test | caps |
|---|---|---|---|---|
| L1_t1a_128 | True  | 76.7 | True | {"capped_to": null, "kv_tokens": 1729386, "mamba_cache_size": 4, "verify_graph_bs": null, "prefill_graph_captured": false, "avail_mem_gb_last": 3.17} |
| L5_t1c_dflash | True  | 66.3 | True | {"capped_to": null, "kv_tokens": 1143992, "mamba_cache_size": 4, "verify_graph_bs": [1], "prefill_graph_captured": false, "avail_mem_gb_last": 3.1} |
| L7_t1a_128_patched | True  | 61.3 | True | {"capped_to": null, "kv_tokens": 1729386, "mamba_cache_size": 4, "verify_graph_bs": null, "prefill_graph_captured": false, "avail_mem_gb_last": 3.17} |
| L9_t1c_dflash_patched | True  | 66.3 | True | {"capped_to": null, "kv_tokens": 1143992, "mamba_cache_size": 4, "verify_graph_bs": [1], "prefill_graph_captured": false, "avail_mem_gb_last": 3.1} |

Verdict ceiling of this session: ENGINE_CORRECTNESS_VALIDATED. No LB uplift is claimed.
