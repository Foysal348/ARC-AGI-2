# E15P: the E15B engine cell (Poetiq uses /generate through the shim; the chat parsers of the Duck flags do not touch
# /generate). rev 2 (Notes/19): F3 pending deltas for the drain, F4 admission usage = max(KV, mamba), F15 a smoke
# failure relaunches the 12-stream config once, F2 e15p_relaunch_s12() for a mid-run restart, F12 pool maxima.
# E12: = E11-06 CELL 5 unchanged except the Duck serving flags in e11_flags().
# ==================================================================== CELL 5 — engine: SGLang 0.5.21 + RedHat INT4 + DFlash2 (E11-04 W1)
# E11-05. The scheduler (next cells) is S49's, unchanged. It drives the engine with the vLLM calls it already uses
# (add_request / step / abort_request, DELTA token ids, finish 'stop' | 'length' | 'abort'); the shim below maps them onto
# SGLang's HTTP API: /generate streamed with --incremental-streaming-output (disjoint deltas, tokenizer_manager.py:2493-2515),
# /abort_request (the stream then ends with finish type 'abort'), /metrics. Launch = E11-04 W1, measured 2026-10-18.
# If SGLang does not come up (inputs, install, launch, smoke incl. abort), the server is killed and CELL 5b runs S49's vLLM.
import queue as _queue, signal as _signal, statistics as _statistics, types as _types, urllib.request as _urlreq
E11_HARNESS = os.environ.get("E11_HARNESS") == "1"            # local CPU harness only: fake server, no install, no GPU
SGL_PORT = int(os.environ.get("E11_PORT", 30000))
SGL_URL = f"http://127.0.0.1:{SGL_PORT}"
E11_SGL = {"requested": ENGINE_BACKEND, "ok": False, "stage": "not started", "inputs": {}, "install": None, "attempts": [],
           "caps": None, "launch_flags": None, "smoke": None, "error": None, "tokenizer_check": E11_TOKENIZER_CHECK}
E11_SERVER = None
ENGINE_READY = False; llm = None; engine = None; CONCURRENCY = 0
ENGINE_INFO = {"backend": None, "sglang": E11_SGL, "kv_tokens": None, "concurrency": None, "fatal": None, "load_sec": None}


class SamplingParams:
    """vLLM-shaped container. The shim sends max_tokens, temperature, top_p, top_k. The seed is not sent: SGLang 0.5.21
    uses sampling_seed only under --enable-deterministic-inference (sampling_batch_info.py:143-157), so sampling is random."""
    def __init__(self, max_tokens=16, seed=None, temperature=1.0, top_p=1.0, top_k=-1, **kw):
        self.max_tokens, self.seed = int(max_tokens), seed
        self.temperature, self.top_p, self.top_k = float(temperature), float(top_p), int(top_k)
        self.extra = kw


class RequestOutputKind:
    DELTA = "delta"


def make_params(max_tokens, seed):
    return SamplingParams(max_tokens=int(max_tokens), seed=int(seed), detokenize=False, skip_special_tokens=False,
                          output_kind=RequestOutputKind.DELTA, **SAMPLING)


class E11Fail(Exception):
    pass


def _e11_post(path, payload, timeout=30):
    req = _urlreq.Request(SGL_URL + path, data=json.dumps(payload).encode(), method="POST",
                          headers={"Content-Type": "application/json"})
    with _urlreq.urlopen(req, timeout=timeout) as r:
        return r.read()


def _e11_gpu_used():
    try:
        return [int(x) for x in subprocess.run(["nvidia-smi", "--query-gpu=memory.used", "--format=csv,noheader,nounits"],
                                               capture_output=True, text=True, timeout=30).stdout.split()]
    except Exception:
        return []


def _e11_gpu_free(max_sec=180):
    t = time.perf_counter()
    while time.perf_counter() - t < max_sec:
        u = _e11_gpu_used()
        if E11_HARNESS or (u and max(u) < 1024):
            return {"free": True, "sec": round(time.perf_counter() - t), "used_mb": u}
        time.sleep(5)
    for _pat in ("sglang.launch_server", "sglang::"):
        subprocess.run(["pkill", "-9", "-f", _pat], capture_output=True)
    time.sleep(15)
    return {"free": False, "sec": round(time.perf_counter() - t), "used_mb": _e11_gpu_used(), "pkill": True}


# ---- install (= E11-03/04 C1): a venv from the wheelhouse lock, --no-deps; CUDA 13 pip runtime as CUDA_HOME; link shims
def e11_install():
    if E11_HARNESS:
        return Path(sys.executable), dict(os.environ), {"harness": True}
    shims, t0 = {}, time.perf_counter()
    venv = Path("/tmp/sglang-venv"); vpy = venv / "bin" / "python"
    # Kaggle drops '+' from dataset file names (flashinfer_jit_cache-0.6.18+cu130 -> ...0.6.18cu130); rebuild the original
    # names from SHA256SUMS as links in a find-links folder, checking the hash of every renamed wheel
    fl = Path("/tmp/e11-wheels"); fl.mkdir(parents=True, exist_ok=True)
    renamed = []
    for line in (SGL_WHEELHOUSE / "SHA256SUMS").read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        h, name = line.split("  ", 1); name = name.strip()
        if not name.endswith(".whl"):
            continue
        s = SGL_WHEELHOUSE / name if (SGL_WHEELHOUSE / name).exists() else SGL_WHEELHOUSE / name.replace("+", "")
        if not s.exists():
            raise E11Fail(f"wheel missing from the dataset: {name}")
        if s.name != name:
            d = hashlib.sha256()
            with open(s, "rb") as f:
                for b in iter(lambda: f.read(16 * 1024 * 1024), b""):
                    d.update(b)
            if d.hexdigest() != h:
                raise E11Fail(f"sha256 mismatch for {s.name}")
            renamed.append(f"{s.name} -> {name}")
        if not (fl / name).exists():
            (fl / name).symlink_to(s)
    shims["renamed_wheels"] = renamed
    if not vpy.exists():
        subprocess.run([sys.executable, "-m", "venv", "--without-pip", str(venv)], check=True, timeout=300)
        r = subprocess.run([sys.executable, "-m", "pip", "--python", str(vpy), "install", "--no-index", "--find-links", str(fl),
                            "--requirement", str(SGL_WHEELHOUSE / "requirements.lock"), "--no-deps", "--only-binary", ":all:",
                            "--no-compile", "--disable-pip-version-check", "--no-warn-conflicts", "-q"],
                           capture_output=True, text=True, timeout=1800)
        if r.returncode != 0:
            raise E11Fail("offline SGLang install failed: " + (r.stderr or r.stdout)[-1500:])
    site = Path(subprocess.run([str(vpy), "-c", "import sysconfig; print(sysconfig.get_paths()['purelib'])"],
                               capture_output=True, text=True, check=True, timeout=120).stdout.strip())
    cuda_home = site / "nvidia" / "cu13"
    # E11-02 BUILD_PROBE: the pip CUDA runtime ships lib/libcudart.so.13 only; JIT links need libcudart.so and lib64
    if not (cuda_home / "lib" / "libcudart.so").exists():
        (cuda_home / "lib" / "libcudart.so").symlink_to("libcudart.so.13"); shims["libcudart.so"] = "created"
    if not (cuda_home / "lib64").exists():
        (cuda_home / "lib64").symlink_to("lib"); shims["lib64"] = "created"
    # E10 run 1: FlashInfer's JIT link needs -lcuda; Kaggle has only libcuda.so.1
    libcuda = Path("/tmp/e11-libcuda")
    have = [d for d in ("/usr/local/cuda/lib64", "/usr/local/cuda/lib64/stubs", "/usr/lib/x86_64-linux-gnu", "/usr/lib64")
            if Path(d, "libcuda.so").exists()]
    if have:
        shims["libcuda.so"] = f"exists in {have[0]}"
    else:
        real = None
        try:
            for line in subprocess.run(["ldconfig", "-p"], capture_output=True, text=True, timeout=30).stdout.splitlines():
                if "libcuda.so.1" in line and "=>" in line:
                    real = line.split("=>")[-1].strip(); break
        except Exception:
            pass
        for d in ("/usr/local/nvidia/lib64", "/usr/lib/x86_64-linux-gnu", "/usr/lib64"):
            if real is None and Path(d, "libcuda.so.1").exists():
                real = str(Path(d, "libcuda.so.1"))
        if real:
            libcuda.mkdir(parents=True, exist_ok=True)
            if (libcuda / "libcuda.so").is_symlink() or (libcuda / "libcuda.so").exists():
                (libcuda / "libcuda.so").unlink()
            (libcuda / "libcuda.so").symlink_to(Path(real).resolve()); shims["libcuda.so"] = f"shim -> {real}"
        else:
            shims["libcuda.so"] = "libcuda.so.1 NOT FOUND"
    env = {k: v for k, v in os.environ.items() if k not in ("PYTHONPATH", "CUDA_HOME", "CUDA_PATH")}
    env.update({
        "PATH": os.pathsep.join([str(venv / "bin"), str(cuda_home / "bin"), os.environ.get("PATH", "")]),
        "CUDA_HOME": str(cuda_home), "CUDA_PATH": str(cuda_home),
        "LIBRARY_PATH": os.pathsep.join(x for x in (str(libcuda), str(cuda_home / "lib"), os.environ.get("LIBRARY_PATH", "")) if x),
        "LD_LIBRARY_PATH": os.pathsep.join(x for x in (str(cuda_home / "lib"), os.environ.get("LD_LIBRARY_PATH", "")) if x),
        "TORCH_CUDA_ARCH_LIST": "8.9", "MAX_JOBS": "4",
        "SGLANG_CACHE_DIR": "/tmp/e11-cache/sglang", "CUDA_CACHE_PATH": "/tmp/e11-cache/cuda",
        "TRITON_CACHE_DIR": "/tmp/e11-cache/triton", "TORCH_EXTENSIONS_DIR": "/tmp/e11-cache/torch_ext",
        "HF_HUB_OFFLINE": "1", "TRANSFORMERS_OFFLINE": "1", "TOKENIZERS_PARALLELISM": "false",
        "CUDA_DEVICE_ORDER": "PCI_BUS_ID", "PYTHONUNBUFFERED": "1",
    })
    env.update(E14L.jit_cache_env())      # E14: SGLANG_JIT_CACHE_DIR set explicitly (it is not under SGLANG_CACHE_DIR)
    shims.update(cuda_home=str(cuda_home), venv_python=str(vpy), sec=round(time.perf_counter() - t0, 1))
    return vpy, env, shims


# ---- launch: the E11-04 W1 command; one diagnosed fallback per cause (E11-04 rev 2b next_launch)
W1 = {"strategy": "extra_buffer_lazy", "mamba_cache": 68, "no_prefill_graph": True, "mem": "0.83"}   # E15B: 16 x ~3 slots + radix
E11_OOM_MARKERS = ("out of memory", "outofmemory", "cuda error: out of memory", "not enough memory", "insufficient memory",
                   "cudaerrormemoryallocation")


def e11_flags(cfg):
    f = ["--model-path", str(SGL_MODEL_PATH), "--tp-size", "4", "--kv-cache-dtype", "fp8_e4m3",
         "--context-length", str(SGL_CONTEXT_LEN), "--max-running-requests", str(SGL_SERVER_MAX_RUNNING),
         "--chunked-prefill-size", "4096", "--mamba-ssm-dtype", "float16", "--enable-metrics", "--disable-flashinfer-autotune",
         "--random-seed", str(SEED), "--host", "127.0.0.1", "--port", str(SGL_PORT), "--log-level", "info",
         "--cuda-graph-max-bs-decode", str(SGL_MAX_RUNNING), "--watchdog-timeout", "1800", "--decode-log-interval", "40",
         "--speculative-algorithm", "DFLASH", "--speculative-draft-model-path", str(SGL_DRAFT_PATH),
         "--speculative-draft-model-quantization", "unquant", "--speculative-num-draft-tokens", "8"]
    if cfg["no_prefill_graph"]:
        f += ["--disable-prefill-cuda-graph"]
    f += ["--mamba-radix-cache-strategy", cfg["strategy"], "--max-mamba-cache-size", str(cfg["mamba_cache"]),
          "--mem-fraction-static", cfg["mem"],
          # E11-05: streaming for the shim (disjoint deltas). rev 2: interval 1 = a chunk every decode step. With N > 1 the
          # rule is len(output_ids) % N == 1 (output_streamer.py:427-436); DFLASH accepts several tokens per step, so a
          # stream could skip that residue for long stretches and the drain would lose the unsent thinking.
          "--incremental-streaming-output", "--stream-interval", "1"]
    # E12: Duck milestone-2 serving flags (dfranzen notebook cell 12; each verified in SGLang 0.5.21): OpenAI tool calls
    # and reasoning split for /v1/chat/completions, preserved thinking by default, prefix-aware scheduling, cached_tokens
    # in usage. /generate (the smoke below) is unaffected.
    f += ["--reasoning-parser", "qwen3", "--tool-call-parser", "qwen3_coder",
          "--default-chat-template-kwargs", json.dumps({"preserve_thinking": True}),
          "--schedule-policy", "lpm", "--enable-cache-report"]
    if E12_MAMBA_TRACK_64:
        f += ["--mamba-track-interval", "64", "--page-size", "64"]
    return f


# E14S (Notes/30, R2): the adopted arm = DFlash width 6 (531 vs 505 tok/s, gate PASS) on CUDA graphs 1..13 (captured
# 12 and 13, gate PASS). Set in every launch unless the E14A measurements run (they start from W1 and set each arm per
# launch).
E14_SUBMIT_ARM = {"--cuda-graph-bs-decode": [str(b) for b in range(1, SGL_SERVER_MAX_RUNNING + 1)],
                  "--speculative-num-draft-tokens": ["6"],
                  # E15B #36 (Exp 15 Notes/02): the DFlash min-free-slots delayer off ("<= 1 disables",
                  # managers/min_free_slots_delayer.py): with it the last stream waited while the others ran (EVAL120:
                  # 11.2 of 12 running, queue > 0 for 72 % of the time)
                  "--min-free-slots-delay": ["1"]}
E14_SUBMIT_DROP = ("--cuda-graph-max-bs-decode",)
_e11_flags_w1 = e11_flags


def e11_flags(cfg):
    f = _e11_flags_w1(cfg)
    if E14_DO_MEASURE or cfg.get("w1"):     # E15B #16: the W1 fallback launch keeps the plain W1 flags
        return f
    out, i, names = [], 0, set(E14_SUBMIT_ARM) | set(E14_SUBMIT_DROP)
    while i < len(f):
        if f[i] in names:
            i += 1
            while i < len(f) and not str(f[i]).startswith("--"):
                i += 1
            continue
        out.append(f[i])
        i += 1
    for k, v in E14_SUBMIT_ARM.items():
        out += [k] + list(v)
    if cfg.get("streams12"):     # E15B #16: the 12-stream fallback launch (graphs 1..13, mrr 13; the delayer stays off)
        out = e14_edit_flags_b(out, {"--max-running-requests": ["13"], "--cuda-graph-bs-decode": [str(b) for b in range(1, 14)]})
    assert "--enable-prefill-delayer" not in out
    return out


def e14_edit_flags_b(flags, set_):
    out, i = [], 0
    while i < len(flags):
        if flags[i] in set_:
            i += 1
            while i < len(flags) and not str(flags[i]).startswith("--"):
                i += 1
            continue
        out.append(flags[i])
        i += 1
    for k, v in set_.items():
        out += [k] + list(v)
    return out


def e11_next(cfg, tail, used):
    """(cfg, reason) for the one diagnosed relaunch of this cause, or None. Lazy / prefill causes are read from error
    lines only (normal startup lines also say 'Mamba Cache ...')."""
    t = "\n".join(l for l in (tail or "").splitlines()
                  if any(k in l.lower() for k in ("error", "exception", "assert", "unsupported", "not supported")))[-4000:].lower()
    global SGL_MAX_RUNNING, SGL_SERVER_MAX_RUNNING
    _oom = any(k in (tail or "").lower() for k in E11_OOM_MARKERS)
    if not cfg.get("streams12") and "streams12" not in used:   # E15B #16 (H2): ANY failed 16-stream launch
        # E15B #16: a 16-stream launch that ran out of memory or failed without a diagnosed cause relaunches at the
        # E14S 12-stream size (mamba 56, mrr 13, graphs 1..13; the delayer stays off); the capacity gate then sees 12
        SGL_MAX_RUNNING, SGL_SERVER_MAX_RUNNING = 12, 13
        return dict(cfg, streams12=True, mamba_cache=56), "streams12"
    if _oom and cfg["mem"] == "0.83" and "oom" not in used:
        return dict(cfg, mem="0.78"), "oom"
    if cfg["strategy"] == "extra_buffer_lazy" and ("lazy" in t or "extra_buffer" in t or "mamba" in t) and "lazy" not in used:
        return dict(cfg, strategy="extra_buffer", mamba_cache=5 * SGL_SERVER_MAX_RUNNING), "lazy"   # E15B: 5 slots x mrr
    if cfg["no_prefill_graph"] and "graph" in t and "prefill" not in used:
        return dict(cfg, no_prefill_graph=False), "prefill"
    if "w1" not in used:          # E15B #16 (H2): last resort, the plain W1 flags (width 8, the server's defaults)
        return dict(cfg, w1=True), "w1"
    return None


def e11_slots(cfg):
    """kv_cache_configurator.py:2232-2261 with the overlap scheduler on: extra_buffer 5, extra_buffer_lazy 4 slots."""
    return {"extra_buffer_lazy": 4, "no_buffer": 3}.get(cfg["strategy"], 5)


def e11_caps(text):
    """Effective limits from the server log (/get_server_info reports the requested values)."""
    caps = {}
    m = re.findall(r"max_running_requests is capped to (\d+) by the mamba state cache \(max_mamba_cache_size=(\d+), (\d+) state", text)
    caps["capped_to"] = min(int(a) for a, _, _ in m) if m else None
    tp0 = "\n".join(l for l in text.splitlines() if "TP0]" in l) or text
    kv = re.findall(r"KV Cache is allocated\. dtype: ([\w.]+), #tokens: (\d+), K size: ([\d.]+) GB, V size: ([\d.]+) GB", tp0)
    caps["kv_tokens"] = int(kv[0][1]) if kv else None                     # first TP0 line = target (second = drafter)
    mc = re.findall(r"Mamba Cache is allocated\. max_mamba_cache_size: (\d+)", tp0)
    caps["mamba_cache_size"] = int(mc[0]) if mc else None
    vb = re.findall(r"Capture target verify CUDA graph begin\..*?bs=\[([\d, ]+)\]", text)
    caps["verify_graph_bs"] = [int(x) for x in re.findall(r"\d+", vb[0])] if vb else None
    caps["prefill_graph_captured"] = "Capture target prefill CUDA graph" in text
    am = re.findall(r"avail mem=([\d.]+) GB", tp0)
    caps["avail_mem_gb_last"] = float(am[-1]) if am else None
    return caps


def e11_capacity_gate(caps, cfg):
    """rev 2 (GPT audit): fail-closed. Every limit must be in the server log; concurrency = the smallest of 12, the mamba
    cache // state slots (and the logged cap), the largest captured verify-graph batch <= 12, and KV // 70k."""
    slots = e11_slots(cfg)
    mc, kv, free = caps.get("mamba_cache_size"), caps.get("kv_tokens"), caps.get("avail_mem_gb_last")
    eff = min(SGL_MAX_RUNNING, mc // slots) if isinstance(mc, int) else None
    if eff is not None and caps.get("capped_to"):
        eff = min(eff, caps["capped_to"])
    bs = [b for b in (caps.get("verify_graph_bs") or []) if b <= SGL_MAX_RUNNING]
    caps.update(slots_per_request=slots, effective_running=eff)
    conc = min(SGL_MAX_RUNNING, eff or 0, max(bs) if bs else 0, (kv or 0) // SGL_KV_PER_REQUEST)
    g = {"mamba_cache_logged": eff is not None, "kv_logged": kv is not None, "verify_graph_logged": bool(bs),
         "running_min": (eff or 0) >= SGL_MIN_RUNNING, "kv_min": (kv or 0) >= SGL_MIN_KV,
         "prefill_graph_as_requested": (caps.get("prefill_graph_captured") is False) if cfg["no_prefill_graph"] else True,
         "headroom": isinstance(free, (int, float)) and free >= SGL_MIN_FREE_GB, "concurrency_min": conc >= SGL_MIN_RUNNING}
    g["pass"] = all(g.values())
    return g, conc


class E11Server:
    def __init__(self, cmd, env, tag):
        self.cmd, self.env, self.tag, self.proc, self.log_f = cmd, env, tag, None, None
        self.log_path = OUT / f"sglang_server_{tag}.log"

    def start(self):
        self.log_f = open(self.log_path, "w", encoding="utf-8")
        self.t0 = time.perf_counter()
        self.proc = subprocess.Popen(self.cmd, env=self.env, stdout=self.log_f, stderr=subprocess.STDOUT,
                                     cwd=None if E11_HARNESS else "/tmp", start_new_session=True)

    def alive(self):
        return self.proc is not None and self.proc.poll() is None

    def log_text(self):
        try:
            return self.log_path.read_text(encoding="utf-8", errors="replace")
        except Exception:
            return ""

    def wait_ready(self, timeout):
        # E14-0 (Notes/07, 11): stall-based. Progress = log growth or the server tree's read() bytes + page faults (the
        # mmap weight load is silent in the log); stalls: 900 s while loading, 720 s while compiling (> the ~6 min silent
        # first verify-graph capture); a progressing server is never given up before t0 + timeout
        def _health():
            _urlreq.urlopen(SGL_URL + "/health", timeout=10).read()
            return True
        mon = E14L.StallMonitor(self.proc, self.log_path, poll_sec=2 if E11_HARNESS else 5, log=print)
        ok, why, self.e14_stats = mon.wait(_health, give_up_at=self.t0 + timeout)
        return ok, why

    def kill(self, wait=True):
        if self.proc is not None and not self.alive() and hasattr(os, "killpg"):    # E15B B4: orphaned TP workers
            try:
                os.killpg(self.proc.pid, getattr(_signal, "SIGKILL", _signal.SIGTERM))
            except Exception:
                pass
        if self.alive():
            for sig, w in ((_signal.SIGTERM, 30 if wait else 0), (getattr(_signal, "SIGKILL", _signal.SIGTERM), 30)):
                try:
                    if hasattr(os, "killpg"):
                        os.killpg(self.proc.pid, sig)          # the whole group: TP workers, scheduler, detokenizer
                    else:
                        self.proc.kill()
                except Exception:
                    pass
                try:
                    self.proc.wait(timeout=w if w else 0.1)
                    break
                except Exception:
                    continue
        if self.log_f:
            try:
                self.log_f.close()
            except Exception:
                pass
            self.log_f = None


def e11_kill_server(wait=True):
    if E11_SERVER is not None:
        E11_SERVER.kill(wait=wait)


# ---- the shim: the vLLM engine calls of the S49 scheduler on top of SGLang's HTTP API
class _E11Completion:
    __slots__ = ("token_ids", "finish_reason")

    def __init__(self, ids, reason):
        self.token_ids, self.finish_reason = ids, reason


class _E11Output:
    __slots__ = ("request_id", "outputs", "finished")

    def __init__(self, rid, ids, reason):
        self.request_id, self.outputs, self.finished = rid, [_E11Completion(ids, reason)], reason is not None


class E11SglangEngine:
    """add_request starts one streaming /generate per request in a thread; step() returns the token deltas that arrived
    (merged per request, order kept) and raises when the server died; abort_request posts /abort_request per id."""

    def __init__(self, server):
        self.server, self.q, self.aborted, self.done = server, _queue.Queue(), set(), {}
        self.held = []                      # E15P rev 2 (F3): items of other requests set aside by take_pending()
        self.lock = threading.Lock()
        self.stats = {"added": 0, "finished": 0, "by_reason": {}, "errors": [], "prompt_tokens": 0, "cached_tokens": 0,
                      "completion_tokens": 0, "aborts_sent": 0, "abort_errors": 0, "abort_timeouts": 0,
                      "abort_wait_sec_max": 0.0, "accept_len_sum": 0.0, "accept_len_n": 0}
        self.req_log = OUT / "sglang_requests.jsonl"

    def add_request(self, rid, prompt, params):
        if not self.server.alive():
            raise RuntimeError(f"SGLang server is not running (rc={self.server.proc.returncode})")
        sp = {"max_new_tokens": int(params.max_tokens), "temperature": float(params.temperature), "top_p": float(params.top_p),
              "top_k": int(params.top_k), "skip_special_tokens": False, "no_stop_trim": True}
        body = json.dumps({"rid": rid, "input_ids": [int(x) for x in prompt["prompt_token_ids"]],
                           "sampling_params": sp, "stream": True}).encode()
        with self.lock:
            self.stats["added"] += 1
        threading.Thread(target=self._stream, args=(rid, body, time.perf_counter()), daemon=True).start()

    def _stream(self, rid, body, t0):
        reason, meta, err, n = None, {}, None, 0
        try:
            req = _urlreq.Request(SGL_URL + "/generate", data=body, method="POST", headers={"Content-Type": "application/json"})
            with _urlreq.urlopen(req, timeout=SGL_STREAM_IDLE_SEC) as r:
                for raw in r:
                    line = raw.strip()
                    if not line.startswith(b"data:"):
                        continue
                    data = line[5:].strip()
                    if data == b"[DONE]":
                        break
                    d = json.loads(data)
                    if "error" in d:
                        err = str(d["error"])[:300]
                        break
                    ids = d.get("output_ids") or []
                    m = d.get("meta_info") or {}
                    fr = m.get("finish_reason")
                    if fr is not None and reason is None:
                        reason = (fr.get("type") if isinstance(fr, dict) else str(fr)) or "stop"
                        meta = m
                    n += len(ids)
                    if ids or reason is not None:
                        self.q.put((rid, list(ids), reason))
                    if reason is not None:
                        break
        except Exception as e:
            err = f"{type(e).__name__}: {e}"[:300]
        if reason is None:
            reason = "error"
            self.q.put((rid, [], "error"))
        rec = {"rid": rid, "finish": reason, "tokens": n, "sec": round(time.perf_counter() - t0, 1),
               "prompt_tokens": meta.get("prompt_tokens"), "cached_tokens": meta.get("cached_tokens"),
               "completion_tokens": meta.get("completion_tokens"), "spec_accept_length": meta.get("spec_accept_length"),
               "error": err}
        with self.lock:
            self.done[rid] = reason                     # rev 2: the stream has ended (abort_request waits for this)
            s = self.stats
            s["finished"] += 1; s["by_reason"][reason] = s["by_reason"].get(reason, 0) + 1
            s["prompt_tokens"] += int(meta.get("prompt_tokens") or 0); s["cached_tokens"] += int(meta.get("cached_tokens") or 0)
            s["completion_tokens"] += int(meta.get("completion_tokens") or 0)
            if meta.get("spec_accept_length") is not None:
                s["accept_len_sum"] += float(meta["spec_accept_length"]); s["accept_len_n"] += 1
            if err and len(s["errors"]) < 50:
                s["errors"].append(f"{rid}: {err}")
            try:
                with open(self.req_log, "a", encoding="utf-8") as f:
                    f.write(json.dumps(rec) + "\n")
            except Exception:
                pass

    def step(self):
        if not self.server.alive():
            raise RuntimeError(f"SGLang server exited (rc={self.server.proc.returncode}); see {self.server.log_path}")
        items, self.held = list(self.held), []
        if not items:
            try:
                items.append(self.q.get(timeout=0.05))
            except _queue.Empty:
                return []
        while True:
            try:
                items.append(self.q.get_nowait())
            except _queue.Empty:
                break
        merged = {}
        for rid, ids, reason in items:
            m = merged.setdefault(rid, [[], None])
            if m[1] is None:
                m[0].extend(ids); m[1] = reason
        return [_E11Output(rid, ids, reason) for rid, (ids, reason) in merged.items()]

    def take_pending(self, rids):
        """E15P rev 2 (F3, GPT audit 1 HIGH-2): after abort_request() the streams of rids have ended, but their last deltas
        may still sit in the queue (step() moves them only on its next call). Returns rid -> (token ids in order, final
        reason or None) for rids; every other item is kept, in order, for the next step()."""
        rids, out, rest = set(rids), {}, []
        items, self.held = list(self.held), []
        while True:
            try:
                items.append(self.q.get_nowait())
            except _queue.Empty:
                break
        for rid, ids, reason in items:
            if rid in rids:
                o = out.setdefault(rid, [[], None])
                if o[1] is None:
                    o[0].extend(ids)
                    o[1] = reason
            else:
                rest.append((rid, ids, reason))
        self.held = rest
        return {k: (v[0], v[1]) for k, v in out.items()}

    def abort_request(self, ids, wait_sec=30.0):
        """rev 2 (GPT audit, verified: /abort_request only dispatches; scheduler.py:5558-5572 finishes a running request
        after one more decode pass). All POSTs go out in parallel, then this waits (bounded, one shared deadline) until
        each stream has ended, so the slot is released before the caller admits phase 2. Returns rid -> final reason,
        'timeout' or the POST error."""
        ids = list(ids)
        if not ids:
            return {}
        t0, posted = time.perf_counter(), {}
        for rid in ids:
            self.aborted.add(rid)

        def _post(rid):
            try:
                _e11_post("/abort_request", {"rid": rid}, timeout=wait_sec)
                posted[rid] = True
            except Exception as e:
                posted[rid] = f"{type(e).__name__}: {e}"[:200]
        ths = [threading.Thread(target=_post, args=(rid,), daemon=True) for rid in ids]
        for t in ths:
            t.start()
        for t in ths:
            t.join(max(0.0, wait_sec - (time.perf_counter() - t0)))
        while time.perf_counter() - t0 < wait_sec and any(r not in self.done for r in ids):
            time.sleep(0.02)
        out = {}
        with self.lock:
            for rid in ids:
                p = posted.get(rid, "post timeout")
                if p is True:
                    self.stats["aborts_sent"] += 1
                else:
                    self.stats["abort_errors"] += 1
                    if len(self.stats["errors"]) < 50:
                        self.stats["errors"].append(f"abort {rid}: {p}")
                if rid in self.done:
                    out[rid] = self.done[rid]
                else:
                    out[rid] = "timeout" if p is True else p
                    self.stats["abort_timeouts"] += 1
            self.stats["abort_wait_sec_max"] = max(self.stats["abort_wait_sec_max"], round(time.perf_counter() - t0, 2))
        return out


_E11_PROM_RE = re.compile(r"^([A-Za-z_:][A-Za-z0-9_:]*)(\{[^}]*\})?\s+(\S+)")


def e11_prom(timeout=10):
    txt = _urlreq.urlopen(SGL_URL + "/metrics", timeout=timeout).read().decode("utf-8", "replace")
    rows = []
    for line in txt.splitlines():
        if not line or line.startswith("#"):
            continue
        m = _E11_PROM_RE.match(line)
        if not m:
            continue
        try:
            rows.append(_types.SimpleNamespace(name=m.group(1), labels=m.group(2), value=float(m.group(3))))
        except ValueError:
            continue
    return rows


class E11SglangLLM:
    """llm.get_metrics() for the S49 KV gate: the gate reads names containing 'kv_cache_usage'. SGLang's full_token_usage
    (KV pool used, evictable cache excluded) is given that name; token_usage = max(full, mamba) is kept as it is."""

    def get_metrics(self):
        rows = e11_prom()
        # E15P rev 2 (F4, GPT audits 1-2): the bottleneck pool, not the KV pool alone. SGLang 0.5.21 token_usage =
        # max(full, swa, mamba) (pool_stats_observer.py:69-73, 128); mamba_usage counts active slots only (:272-276)
        anyu = [r.value for r in rows if r.name == "sglang:token_usage"]
        pools = [r.value for r in rows if r.name in ("sglang:full_token_usage", "sglang:mamba_usage")]
        kv = max(anyu) if anyu else (max(pools) if pools else None)
        if kv is not None and kv == kv and 0.0 <= kv <= 1.5:
            rows.append(_types.SimpleNamespace(name="e11:kv_cache_usage(sglang:token_usage=max(full,mamba))", labels=None,
                                               value=kv))
        return rows


_E11_SNAP_KEYS = ("num_running_reqs", "num_queue_reqs", "token_usage", "gen_throughput", "spec_accept", "cache_hit_rate",
                  "retract", "generation_tokens_total", "prompt_tokens_total", "cached_tokens_total", "kv_cache_usage",
                  "num_requests_total", "mamba_usage")   # E15P rev 2 (F12): + mamba_usage


def metrics_snapshot():
    if not ENGINE_READY:
        return []
    try:
        return [{"name": r.name, "labels": r.labels, "value": r.value} for r in llm.get_metrics()
                if any(k in r.name for k in _E11_SNAP_KEYS) and not r.name.endswith(("_bucket", "_created"))]
    except Exception as e:
        return [{"error": repr(e)[:300]}]


_E11_KV_RE = re.compile(r"([A-Za-z#][A-Za-z#_ ()/\-]*?):\s*(-?\d+(?:\.\d+)?)")


def e11_decode_summary():
    """Decode rate by running level and by mean context per running request, from the server's TP0 decode lines."""
    if E11_SERVER is None:
        return None
    rows = []
    _texts = []
    for _p in list(globals().get("E15P_OLD_LOGS") or []):     # E15P rev 2: servers replaced by a restart
        try:
            _texts.append(Path(_p).read_text(encoding="utf-8", errors="replace"))
        except Exception:
            pass
    _texts.append(E11_SERVER.log_text())
    for line in "\n".join(_texts).splitlines():
        if "Decode batch" in line and "TP0]" in line:
            rows.append({k.strip(): float(v) for k, v in _E11_KV_RE.findall(line.split("Decode batch", 1)[1])})
    def med(v):
        return round(_statistics.median(v), 1) if v else None
    bins = {}
    for r in rows:
        n, ft, g = r.get("#running-req"), r.get("#full token"), r.get("gen throughput (token/s)")
        if not n or ft is None or g is None:
            continue
        ctx = ft / n
        k = "<10k" if ctx < 10000 else "10-20k" if ctx < 20000 else "20-40k" if ctx < 40000 else "40-60k" if ctx < 60000 else ">=60k"
        bins.setdefault(f"running={int(n)}" if n < SGL_MAX_RUNNING else "running=max", {}).setdefault(k, []).append(g)
    out = {"n_lines": len(rows),
           "running_hist": {str(int(k)): sum(1 for r in rows if r.get("#running-req") == k) for k in sorted({r.get("#running-req", 0) for r in rows})},
           "gen_tok_s_median_at_max": med([r["gen throughput (token/s)"] for r in rows
                                           if r.get("#running-req") == SGL_MAX_RUNNING and "gen throughput (token/s)" in r]),
           "accept_len_median": med([r["accept len"] for r in rows if "accept len" in r]),
           "queue_max": max((r.get("#queue-req", 0) for r in rows), default=None),
           "retract_lines": sum(1 for l in "\n".join(_texts).splitlines() if "retract" in l.lower() and "retraction_policy" not in l and "server_args" not in l.lower()),
           # E15P rev 2 (F12): pool maxima seen in the decode lines
           "full_token_usage_max": max((r["full token usage"] for r in rows if "full token usage" in r), default=None),
           "mamba_usage_max": max((r["mamba usage"] for r in rows if "mamba usage" in r), default=None),
           "running_max": max((r.get("#running-req", 0) for r in rows), default=None),
           "by_context": {lvl: {k: {"lines": len(v), "gen_tok_s_median": med(v)} for k, v in d.items()} for lvl, d in bins.items()}}
    try:
        write_json_atomic(OUT / "sglang_decode_summary.json", out)
    except Exception:
        pass
    return out


def e11_smoke(eng):
    """The shim's own path: (a) greedy 16 tokens, streamed deltas == completion_tokens; (b) abort mid-stream -> the stream
    ends with finish 'abort' (the drain and the hard stop rely on it to free the slot)."""
    res, t0 = {}, time.perf_counter()
    ids = tokenizer.encode("Reply with the digits 1 2 3 4 5 6 7 8:", add_special_tokens=False)
    eng.add_request("e11-smoke-a", {"prompt_token_ids": ids}, SamplingParams(max_tokens=16, temperature=0.0, top_p=1.0, top_k=-1))
    got, fin = [], None
    while fin is None and time.perf_counter() - t0 < 300:
        for o in eng.step():
            if o.request_id == "e11-smoke-a":
                got += o.outputs[0].token_ids; fin = o.outputs[0].finish_reason if o.finished else None
    time.sleep(0.5)
    logged = [json.loads(l) for l in open(eng.req_log, encoding="utf-8")] if eng.req_log.exists() else []
    meta = next((r for r in logged if r["rid"] == "e11-smoke-a"), {})
    res["a"] = {"tokens": len(got), "finish": fin, "completion_tokens": meta.get("completion_tokens"),
                "text": tokenizer.decode(got)[:80]}
    res["a"]["ok"] = bool(got) and fin in ("stop", "length") and meta.get("completion_tokens") == len(got)
    t1 = time.perf_counter()
    eng.add_request("e11-smoke-b", {"prompt_token_ids": ids}, SamplingParams(max_tokens=4096, temperature=0.6, top_p=0.95, top_k=20))
    got, fin, sent = [], None, False
    while fin is None and time.perf_counter() - t1 < 300:
        for o in eng.step():
            if o.request_id == "e11-smoke-b":
                got += o.outputs[0].token_ids; fin = o.outputs[0].finish_reason if o.finished else None
        if got and not sent:
            eng.abort_request(["e11-smoke-b"]); sent = True; t_abort = time.perf_counter()
        if sent and time.perf_counter() - t_abort > 60:
            break
    res["b"] = {"tokens": len(got), "finish": fin, "abort_sent": sent,
                "abort_to_finish_sec": round(time.perf_counter() - t_abort, 2) if sent else None}
    res["b"]["ok"] = sent and fin == "abort" and len(got) < 4096
    res["ok"] = res["a"]["ok"] and res["b"]["ok"]
    res["sec"] = round(time.perf_counter() - t0, 1)
    return res


def e11_bring_up():
    global E11_SERVER, SGL_MAX_RUNNING, SGL_SERVER_MAX_RUNNING   # E15B: the 12-stream fallbacks
    E11_SGL["stage"] = "inputs"
    inp = {"int4": SGL_MODEL_PATH, "dflash2": SGL_DRAFT_PATH, "wheelhouse": SGL_WHEELHOUSE}
    E11_SGL["inputs"] = {k: str(v) for k, v in inp.items()}
    missing = [k for k, v in inp.items() if not (v / ("BUILD_INFO.json" if k == "wheelhouse" else "config.json")).is_file()]
    if missing:
        raise E11Fail(f"inputs missing: {missing}")
    if (_load_json(SGL_MODEL_PATH / "config.json").get("quantization_config") or {}).get("quant_method") != "compressed-tensors":
        raise E11Fail("INT4 checkpoint is not compressed-tensors")
    E11_SGL["stage"] = "install"
    vpy, env, E11_SGL["install"] = e11_install()
    launch = [str(vpy), "-m", "sglang.launch_server"] if not E11_HARNESS else [sys.executable, os.environ["E11_FAKE_SERVER"]]
    e14_after_install(vpy, env)             # E14: NCCL bench while the copy runs, then the staged model paths
    E14_VENV["launch"] = list(launch)
    cfg, used = dict(W1), []
    for i in range(4):      # E15B B5: 16 -> 12 -> diagnosed -> W1
        left = SGL_GIVE_UP_AT - time.perf_counter()
        if left < 60:
            raise E11Fail("give-up deadline reached before a launch")
        E11_SGL["stage"] = f"launch {i}"
        srv = E11Server(launch + e11_flags(cfg), env, f"try{i}")
        srv.start()
        # E14-0: the first launch may use the time up to the give-up (the stall rule decides), relaunches keep 20 min
        ok, why = srv.wait_ready(left if i == 0 else min(SGL_RELAUNCH_TIMEOUT_SEC, left))
        att = {"try": i, "cfg": dict(cfg), "ready": ok, "why": why, "sec": round(time.perf_counter() - srv.t0, 1)}
        E11_SGL["attempts"].append(att)
        print(f"E11 SGLang launch {i} {cfg}: {why}", flush=True)
        if ok:
            E11_SERVER = srv
            break
        tail = srv.log_text()[-20000:]
        att["log_tail"] = tail[-3000:]
        srv.kill()
        att["gpu_free"] = _e11_gpu_free()
        nxt = e11_next(cfg, tail, used)
        if nxt is None:
            raise E11Fail(f"launch {i} failed ({why}); no diagnosed fallback")
        cfg, reason = nxt
        used.append(reason); att["retry_reason"] = reason
    else:
        raise E11Fail("4 launches failed")
    E11_SGL["launch_flags"] = e11_flags(cfg)
    E14_VENV["cfg"] = dict(cfg)
    E14_STATE.enter("READY", ready=getattr(E11_SERVER, "e14_stats", None))
    caps = e11_caps(E11_SERVER.log_text())
    caps["gate"], caps["concurrency"] = e11_capacity_gate(caps, cfg)
    if not caps["gate"]["pass"] and not cfg.get("streams12") and SGL_GIVE_UP_AT - time.perf_counter() > 120:
        # E15B #16: the 16-stream server came up but failed the capacity gate (e.g. GPU headroom): one relaunch at the
        # E14S 12-stream size, the delayer still off
        E11_SGL["gate16"] = {"caps": dict(caps), "cfg": dict(cfg)}
        print("E15B: 16-stream capacity gate failed -> 12-stream relaunch:", json.dumps(caps["gate"]), flush=True)
        E11_SERVER.kill()
        _e11_gpu_free()
        SGL_MAX_RUNNING, SGL_SERVER_MAX_RUNNING = 12, 13
        cfg = dict(cfg, streams12=True, mamba_cache=56)
        srv = E11Server(launch + e11_flags(cfg), env, "try_s12")
        srv.start()
        ok, why = srv.wait_ready(min(SGL_RELAUNCH_TIMEOUT_SEC, max(60.0, SGL_GIVE_UP_AT - time.perf_counter())))
        E11_SGL["attempts"].append({"try": "s12", "cfg": dict(cfg), "ready": ok, "why": why,
                                    "sec": round(time.perf_counter() - srv.t0, 1)})
        if not ok:
            srv.kill()
            raise E11Fail(f"12-stream relaunch after the 16-stream gate failed: {why}")
        E11_SERVER = srv
        E11_SGL["launch_flags"] = e11_flags(cfg)
        E14_VENV["cfg"] = dict(cfg)
        caps = e11_caps(E11_SERVER.log_text())
        caps["gate"], caps["concurrency"] = e11_capacity_gate(caps, cfg)
    E11_SGL["caps"] = caps
    print("E11 caps:", json.dumps(caps), flush=True)
    if not caps["gate"]["pass"]:
        raise E11Fail("capacity gate failed: " + json.dumps(caps["gate"]))
    E11_SGL["stage"] = "smoke"
    eng = E11SglangEngine(E11_SERVER)
    E11_SGL["smoke"] = e11_smoke(eng)
    print("E11 smoke:", json.dumps(E11_SGL["smoke"]), flush=True)
    if not E11_SGL["smoke"]["ok"]:
        if not cfg.get("streams12") and SGL_GIVE_UP_AT - time.perf_counter() > 120:   # E15P rev 2 (F15, GPT audit 2)
            E11_SGL["smoke16"] = dict(E11_SGL["smoke"])
            print("E15P: 16-stream smoke failed -> 12-stream relaunch:", json.dumps(E11_SGL["smoke"])[:600], flush=True)
            return e15p_relaunch_s12("smoke", min(SGL_RELAUNCH_TIMEOUT_SEC, max(60.0, SGL_GIVE_UP_AT - time.perf_counter())))
        raise E11Fail("smoke failed: " + json.dumps(E11_SGL["smoke"])[:600])
    return eng, caps


E15P_OLD_LOGS = []          # server logs of servers replaced by a relaunch (F12 decode summary)
E15P_RELAUNCHES = []


def e15p_relaunch_s12(reason, timeout_sec):
    """E15P rev 2 (F2 / F15): stop the current server and start the 12-stream configuration (mrr 13, graphs 1..13, mamba
    56; the W1 flags stay W1) with the same venv, env and staged model (no reinstall); then the capacity gate and the
    smoke. Returns (engine, caps); raises E11Fail. Sets SGL_MAX_RUNNING 12 so the gate gives concurrency 12."""
    global E11_SERVER, SGL_MAX_RUNNING, SGL_SERVER_MAX_RUNNING
    rec = {"reason": reason, "t": round(time.perf_counter() - NOTEBOOK_T0), "timeout_sec": round(timeout_sec)}
    E15P_RELAUNCHES.append(rec)
    old = E11_SERVER
    env = getattr(old, "env", None)
    if old is not None:
        try:
            E15P_OLD_LOGS.append(str(old.log_path))
            old.kill()
        except Exception as e:
            rec["kill_error"] = repr(e)[:200]
    rec["gpu_free"] = _e11_gpu_free()
    if env is None or not E14_VENV.get("launch"):
        raise E11Fail("relaunch: no launch command / env recorded")
    cfg0 = dict(E14_VENV.get("cfg") or W1)
    cfg = dict(cfg0) if (cfg0.get("w1") or cfg0.get("streams12")) else dict(cfg0, streams12=True, mamba_cache=56)
    SGL_MAX_RUNNING, SGL_SERVER_MAX_RUNNING = 12, 13
    srv = E11Server(list(E14_VENV["launch"]) + e11_flags(cfg), env, f"relaunch{len(E15P_RELAUNCHES)}_{reason}")
    srv.start()
    ok, why = srv.wait_ready(timeout_sec)
    rec.update(ready=ok, why=why, cfg=dict(cfg), sec=round(time.perf_counter() - srv.t0, 1))
    E11_SGL.setdefault("attempts", []).append(dict(rec, **{"try": "relaunch_" + reason}))
    if not ok:
        srv.kill()
        raise E11Fail(f"12-stream relaunch ({reason}) not ready: {why}")
    E11_SERVER = srv
    E11_SGL["launch_flags"] = e11_flags(cfg)
    E14_VENV["cfg"] = dict(cfg)
    caps = e11_caps(srv.log_text())
    caps["gate"], caps["concurrency"] = e11_capacity_gate(caps, cfg)
    rec["gate"] = caps["gate"]
    if not caps["gate"]["pass"]:
        raise E11Fail(f"12-stream relaunch ({reason}) capacity gate failed: " + json.dumps(caps["gate"]))
    eng_ = E11SglangEngine(srv)
    E11_SGL["smoke"] = e11_smoke(eng_)
    rec["smoke_ok"] = bool(E11_SGL["smoke"]["ok"])
    if not E11_SGL["smoke"]["ok"]:
        raise E11Fail(f"12-stream relaunch ({reason}) smoke failed: " + json.dumps(E11_SGL["smoke"])[:400])
    E11_SGL["caps"] = caps
    print("E15P relaunch:", json.dumps(rec, default=str)[:800], flush=True)
    return eng_, caps


_t_engine = time.perf_counter()
if not E10_SANDBOX_SELFTEST.get("ok", False):
    E11_SGL["stage"] = "skipped: sandbox self-test failed"
elif ENGINE_BACKEND != "sglang":
    E11_SGL["stage"] = f"skipped: ENGINE_BACKEND={ENGINE_BACKEND}"
else:
    try:
        engine, _caps = e11_bring_up()
        llm = E11SglangLLM()
        ENGINE_READY = True
        CONCURRENCY = int(_caps["concurrency"])                     # rev 2: from the capacity gate (W1: 12)
        # rev 2: SGLang-only clock and KV gate (see CELL 1): drain 12 min before the hard stop; gate from 10 running
        if "drain_margin_sec" in P and P["drain_margin_sec"] < SGL_DRAIN_MARGIN_SEC:
            DRAIN_DEADLINE = HARD_STOP - SGL_DRAIN_MARGIN_SEC
            ADMIT_DEADLINE = DRAIN_DEADLINE - P["admit_margin_sec"]
            assert NOTEBOOK_T0 < ADMIT_DEADLINE < DRAIN_DEADLINE < HARD_STOP
        # rev 3b (user 2026-10-18): request length limit = the server's context (155,648, the E11-04 launch), so the
        # 60k thinking floor never forces a feedback trim or a skip (room for prompts up to ~87k; real max seen 28k).
        # phase1_cap() and phase 2 read MAX_MODEL_LEN at call time; the vLLM fallback keeps S1-60K's 106,496.
        MAX_MODEL_LEN = SGL_CONTEXT_LEN
        PROMPT_TOKEN_LIMIT = MAX_MODEL_LEN - ANSWER_MAX_TOKENS - CONTEXT_SAFETY - MIN_THINK_BUDGET
        assert phase1_cap(38049) == THINK_BUDGET and phase1_cap(80000) == THINK_BUDGET
        E10_KV_GATE_MIN_ACTIVE = min(E10_KV_GATE_MIN_ACTIVE, SGL_KV_GATE_MIN_ACTIVE)
        E10_KV_ADMIT_MAX = min(E10_KV_ADMIT_MAX, SGL_KV_ADMIT_MAX)
        E11_SGL.update(ok=True, stage="ready")
        ENGINE_INFO.update(backend="sglang-0.5.21-int4-dflash2-" + ("w1" if (E14_VENV.get("cfg") or {}).get("w1") else "w6") + f"-s{SGL_MAX_RUNNING}", kv_tokens=_caps.get("kv_tokens"),
                           effective_running=_caps.get("effective_running"),
                           drain_before_hard_stop_sec=round(HARD_STOP - DRAIN_DEADLINE), max_model_len=MAX_MODEL_LEN,
                           kv_gate={"min_active": E10_KV_GATE_MIN_ACTIVE, "admit_max": E10_KV_ADMIT_MAX})
    except Exception as _e:
        E11_SGL["error"] = f"{type(_e).__name__}: {_e}"[:3000]
        E11_SGL["traceback"] = traceback.format_exc()[-3000:]
        print("E11 SGLang engine NOT ready:", E11_SGL["stage"], "|", E11_SGL["error"][:1500], flush=True)
        e11_kill_server(); E11_SERVER = None
        engine = None; llm = None; ENGINE_READY = False; CONCURRENCY = 0
ENGINE_INFO["load_sec"] = round(time.perf_counter() - _t_engine, 1)
ENGINE_INFO["concurrency"] = int(CONCURRENCY)
print("engine:", json.dumps(ENGINE_INFO, default=str)[:3000], flush=True)
