# P1 SPARSE FINAL

- Base notebook SHA-256: 21c99f92bb6ecdbb97fadc66c15b10ea24a13bcb1958b06774ba522e6f1a9f6e
- Donor build_bundles.py blob: 45f2ff9fca842a71d5214ca2efce5d92c6af9829
- Treatment: Arm B deletions + Arm C mechanics block.
- ACTION7: unchanged, expected `to_engine_action("ACTION7") is None`.
- Control prompt: 12681 chars / d091a36db1ccf79e5caa35b2cd31949370ef95810d00d713cc98eb27a3cd60a6
- P1 prompt: 13032 chars / 620c352791957f63c31338a71bc28855119f9b557cbc1f88a23aa0182cbbfe6e
- Runtime tool-output tokens: 1024

No model, vLLM, context, sampling, scheduler, tool, memory, action-cap, game-set or timing treatment is added by P1.
