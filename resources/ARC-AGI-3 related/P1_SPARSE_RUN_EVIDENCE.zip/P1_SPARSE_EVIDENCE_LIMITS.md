# P1 evidence limits

- Raw Jupyter/Kaggle cell stdout is NOT tee'd into the ZIP. Tee-ing stdout would alter the execution path.
  Experiment-critical console facts are mirrored in patch/preflight/runtime JSON. If a cell itself errors or
  shows an unexpected warning, also keep the executed Kaggle notebook as supplemental evidence.
- `requests.jsonl` is intentionally absent because frozen B0 uses `save_request_logs=False`.
  `transcripts/` proves every system-prompt block and `prompts/` preserves Duck's latest rendered model-input
  snapshot per game.
- Promotion still requires >=2 matched runs; a single historical B0 reference is orientation, not an envelope.
