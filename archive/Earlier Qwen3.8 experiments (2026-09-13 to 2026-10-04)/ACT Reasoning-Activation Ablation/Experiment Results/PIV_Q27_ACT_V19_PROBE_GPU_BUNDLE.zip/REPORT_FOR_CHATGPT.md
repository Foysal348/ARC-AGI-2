# PIV-Q27-ACT-v1.9 — PROBE_GPU

- Run ID: `20260915T124541Z` | arms: **ACT-LOW, ACT-MEDIUM, ACT-BUDGET3072** | tasks: **8** | accuracy is real: **False**
- Frozen reference: ACT-XHIGH (v1.7 SMOKE) tool_engagement=0.00, budget_death=1.00, 0.160 s/token

## PROVEN BY PREFLIGHT (CPU, fake model) — harness correctness only
- Qwen tool-XML parser (incl. fence unwrap, prose-mention tolerance, rehearsal-in-think guard)
- persistent REPL semantics, protected puzzle, SystemExit survival, dead-worker restart
- fresh exact verifier: train gate before test execution, per-test partial outputs, sentinel protocol
- two-level retry accounting (max 2 consecutive step retries), guard-rejection not charged, dynamic multi-call budget
- forced-close construction: byte-exact Qwen early-stopping text; stop sentence replays in history with exactly one </think>
- natural </think> cut at the think cap -> token-exact continuation WITHOUT injection; exact </think>-id think/post token split
- repeated identical tool snippets counted (no KeyError); AST stateful-reuse metric; ranked winner selection
- real scheduler under a fake LLM for every arm incl. two-phase forced-close path and projected-deadline stop
- gate policy: Scenario-G, missing/duplicate terminal record, verdict tiers

## MEASURED ONLY ON REAL GPU — model behaviour
- natural thinking length per arm
- tool engagement / first tool turn
- post-forced-close action mix
- final-program and train-exact rates
- ARC exact outputs
- sec/output-token and projected wall-clock

## Arm comparison

| arm | tool_eng | final_prog | train_exact | exact | budget_death | first_turn_len | natural_close | forced_close | action_cap_hit | reuse_events | think_tok/turn | gen_tok/task | proj_h(20%) | tier | promote |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| ACT-XHIGH (frozen v1.7 SMOKE reference, not rerun) | 0.00 | 0.00 | 0.00 | 0.0000 | 1.00 | 1.00 | 0.00 | 0.00 | None | None | 12288 | 12288 | 4.06 | none | False |
| ACT-LOW | 0.88 | 0.00 | 0.00 | 0.0000 | 1.00 | 0.38 | 0.56 | 0.00 | None | 2 | 715 | 3011 | 2.18 | activation | False |
| ACT-MEDIUM | 0.12 | 0.00 | 0.00 | 0.0000 | 1.00 | 1.00 | 0.06 | 0.00 | None | 0 | 2560 | 5082 | 1.84 | none | False |
| ACT-BUDGET3072 | 0.88 | 0.00 | 0.00 | 0.0000 | 1.00 | 0.12 | 0.21 | 0.79 | 0.23 | 2 | 3072 | 4819 | 2.53 | activation | False |

## PROBE canary (3072 per-turn / 5120 total tokens, 2 calls, 2 turns — NOT P0 budgets)

- arms with activation: **['ACT-LOW', 'ACT-BUDGET3072']**
- projected Proxy-48 hours in the table above are for PROBE budgets and must not be read as P0 projections.
- PROBE answers only: does the arm reach a tool call at all? Productivity/quality are measured in SMOKE_GPU.

## Recommendation

- PROBE: activation in ['ACT-LOW', 'ACT-BUDGET3072'] -> run SMOKE_GPU on those arms
- ranked arms: ['ACT-LOW', 'ACT-BUDGET3072', 'ACT-MEDIUM']

## Files
- `arm_comparison.csv/json`, `arm_deltas_vs_frozen_xhigh.json`, `recommendation.json`, `measurement_contract.json`
- per arm: `arms/<arm>/{smoke_gate.json, measurement_report.json, verdict.json, agent_diagnostics.csv, task_output_scores.csv, raw_generations.jsonl, traces/, wave_metrics.jsonl}`