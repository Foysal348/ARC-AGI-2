# PIV-Q27-C1-v2.3 — PREFLIGHT

- Run ID: `20260917T111920Z` | arms: **ACT-LOW, ACT-MEDIUM, ACT-BUDGET3072** | tasks: **48** | accuracy is real: **False**
- Frozen reference: ACT-XHIGH (v1.7 SMOKE) tool_engagement=0.00, budget_death=1.00, 0.160 s/token

## PROVEN BY PREFLIGHT (CPU, fake model) — harness correctness only
- Qwen tool-XML parser (incl. fence unwrap, prose-mention tolerance, rehearsal-in-think guard)
- persistent REPL semantics, protected puzzle, SystemExit survival, dead-worker restart
- fresh exact verifier: train gate before test execution, per-test partial outputs, sentinel protocol
- two-level retry accounting (max 2 consecutive step retries), guard-rejection not charged, dynamic multi-call budget
- forced-close construction: byte-exact Qwen early-stopping text; stop sentence replays in history with exactly one </think>
- natural </think> cut at the think cap -> token-exact continuation WITHOUT injection; exact </think>-id think/post token split
- repeated identical tool snippets counted (no KeyError); AST stateful-reuse metric; ranked winner selection
- real scheduler under a fake LLM for every arm incl. two-phase forced-close path and projected-deadline stop
- gate policy: Scenario-G, missing/duplicate terminal record, usable-test-required promotion, tool activation diagnostic only
- fresh verifier: test timeout preserves train-exact evidence; guard rejection does not claim subprocess execution
- competition scoring: output-level exact rate distinguished from strict all-query task diagnostic

## MEASURED ONLY ON REAL GPU — model behaviour
- natural thinking length per arm
- tool engagement / first tool turn
- post-forced-close action mix
- final-program, syntax-valid, verifier-execution and train-exact rates
- valid test execution and official exact tasks
- sec/output-token and projected wall-clock

## Arm comparison

| arm | tool_eng | final_prog | syntax_valid | verifier_exec | train_exact | valid_test | competition_output_exact | strict_all_query_task_exact | budget_death | gen_tok/task | sec/tok | tier | proxy_ready |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| ACT-XHIGH (frozen v1.7 SMOKE reference, not rerun) | 0.00 | 0.00 | None | None | 0.00 | None | None | None | 1.00 | 12288 | 0.1601 | none | False |
| ACT-LOW | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0000 | 0.00 | 0.00 | 0 | None | none | False |
| ACT-MEDIUM | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0000 | 0.00 | 0.00 | 0 | None | none | False |
| ACT-BUDGET3072 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.00 | 0.0000 | 0.00 | 0.00 | 0 | None | none | False |

## Recommendation

- PREFLIGHT ONLY: mock/fake-model records validate the harness. No model-behaviour or solver-quality recommendation is permitted.
- ranked arms: ['ACT-LOW', 'ACT-MEDIUM', 'ACT-BUDGET3072']

## Files
- `arm_comparison.csv/json`, `matched_task_quality.csv`, `arm_deltas_vs_frozen_xhigh.json`, `recommendation.json`, `measurement_contract.json`
- per arm: `arms/<arm>/{task_quality.csv, smoke_gate.json, measurement_report.json, verdict.json, agent_diagnostics.csv, task_output_scores.csv, raw_generations.jsonl, traces/, wave_metrics.jsonl}`