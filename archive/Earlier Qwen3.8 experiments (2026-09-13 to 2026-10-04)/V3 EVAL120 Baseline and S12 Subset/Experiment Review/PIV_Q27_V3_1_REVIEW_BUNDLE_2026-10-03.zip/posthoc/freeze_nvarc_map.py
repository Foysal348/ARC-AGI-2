"""Freeze NVARC's per-query eval120 result (Probmul rank 1-2 = the two submitted attempts) from the NVARC experiment
notebook's own printed output (cell 15). Used only for post-hoc PIV measurement, never inside the solver."""
import hashlib, json, re, sys
from pathlib import Path
NB = Path(r"D:\ARC AGI 2\Document\31_experiment Notebook_arc-2026d-with-codex (22).ipynb")
nb = json.loads(NB.read_text(encoding="utf-8"))
txt = "".join("".join(o.get("text", "")) for o in nb["cells"][15].get("outputs", []))
q = {}
for m in re.finditer(r"Subkey: ([0-9a-f]{8})_(\d+)\nProbmul rank : (\w+)", txt):
    tid, k, rank = m.group(1), int(m.group(2)), m.group(3)
    q.setdefault(tid, {})[k] = None if rank == "None" else int(rank)
ranks = {t: [q[t][k] for k in sorted(q[t])] for t in sorted(q)}
tasks = {t: [r is not None and r <= 2 for r in v] for t, v in ranks.items()}
score = {t: sum(v) / len(v) for t, v in tasks.items()}
out = {"source_notebook": NB.name, "source_sha256": hashlib.sha256(NB.read_bytes()).hexdigest(), "source_cell": 15,
       "rule": "query solved iff Probmul rank in {1,2}",
       "n_tasks": len(tasks), "n_queries": sum(len(v) for v in tasks.values()),
       "task_equivalents": round(sum(score.values()), 4), "arc_score_pct": round(100 * sum(score.values()) / len(tasks), 2),
       "fully_solved": sorted(t for t, s in score.items() if s == 1.0),
       "no_query_solved": sorted(t for t, s in score.items() if s == 0.0),
       "per_task_queries_solved": tasks, "per_task_probmul_rank": ranks}
Path("nvarc_eval120_frozen.json").write_text(json.dumps(out, indent=1), encoding="utf-8")
print({k: out[k] for k in ["n_tasks", "n_queries", "task_equivalents", "arc_score_pct"]},
      "fully", len(out["fully_solved"]), "misses", len(out["no_query_solved"]))
