"""Post-hoc PIV measurement on EVAL120 against the frozen baseline definitions and the frozen NVARC map.

usage: python score_vs_nvarc.py <raw_generations.jsonl> <arc-agi_evaluation_solutions.json> [nvarc_eval120_frozen.json]

PIV submits one output per query (its final program run on the test input). Definitions as in
CANONICAL_BASELINE_EVAL120_2026-10-03.md: Train-Verified = final program exact on every training pair in the fresh
verifier; Strict Solved = every query of the task correct; ARC score = mean over tasks of fraction of queries correct.
Combination policy measured (not used by the solver): for a Train-Verified PIV task, PIV output becomes attempt_1 and
NVARC's rank-1 candidate attempt_2; every other task keeps NVARC's two attempts."""
import json, sys
from pathlib import Path

raw, sol_path = Path(sys.argv[1]), Path(sys.argv[2])
nv_path = Path(sys.argv[3]) if len(sys.argv) > 3 else Path(__file__).with_name("nvarc_eval120_frozen.json")
sol = json.loads(sol_path.read_text(encoding="utf-8"))
nv = json.loads(nv_path.read_text(encoding="utf-8"))
latest = {}
for line in raw.read_text(encoding="utf-8").splitlines():
    if not line.strip():
        continue
    r = json.loads(line)
    if str(r.get("status")) in {"complete", "failed"}:
        latest[str(r["task_id"])] = r   # last terminal record wins (repair records are appended after exploration)
# a subset run (e.g. V3.1-S12) is scored over the tasks it ran; a full run over all 120
tids = sorted(sol) if len(latest) >= len(sol) else sorted(t for t in sol if t in latest)
rows = []
for t in tids:
    r = latest.get(t, {})
    outs = list(r.get("test_outputs") or [])
    q = [i < len(outs) and outs[i] is not None and outs[i] == g for i, g in enumerate(sol[t])]
    tv = bool(r.get("all_train_exact"))
    nr = nv["per_task_probmul_rank"][t]
    nq = [x is not None and x <= 2 for x in nr]
    comb = [(q[i] or nr[i] == 1) if tv else nq[i] for i in range(len(q))]
    rows.append({"task_id": t, "has_record": bool(r), "train_verified": tv, "piv_queries": q, "piv_strict": all(q),
                 "piv_score": sum(q) / len(q), "nvarc_score": sum(nq) / len(nq), "nvarc_miss": not any(nq),
                 "combined_score": sum(comb) / len(comb), "verbatim_commit": bool(r.get("verbatim_commit"))})
n = len(rows)
out = {
    "tasks_scored": n, "subset_run": n < len(sol), "tasks_with_terminal_record": sum(x["has_record"] for x in rows),
    "train_verified": sum(x["train_verified"] for x in rows),
    "strict_solved": sum(x["piv_strict"] for x in rows),
    "arc_score_pct": round(100 * sum(x["piv_score"] for x in rows) / n, 2),
    "query_exact": "%d/%d" % (sum(sum(x["piv_queries"]) for x in rows), sum(len(x["piv_queries"]) for x in rows)),
    "train_verified_but_wrong_on_test": sorted(x["task_id"] for x in rows if x["train_verified"] and not x["piv_strict"]),
    "PIV_ONLY_strict_among_nvarc_misses": sorted(x["task_id"] for x in rows if x["piv_strict"] and x["nvarc_miss"]),
    "piv_strict_tasks": sorted(x["task_id"] for x in rows if x["piv_strict"]),
    "nvarc_arc_score_pct": round(100 * sum(x["nvarc_score"] for x in rows) / n, 2),
    "combined_arc_score_pct": round(100 * sum(x["combined_score"] for x in rows) / n, 2),
    "combined_minus_nvarc_pct": round(100 * sum(x["combined_score"] - x["nvarc_score"] for x in rows) / n, 2),
    "combination_losses": sorted(x["task_id"] for x in rows if x["combined_score"] < x["nvarc_score"]),
}
print(json.dumps(out, indent=1))
Path(raw.parent / "posthoc_vs_nvarc.json").write_text(json.dumps({"summary": out, "rows": rows}, indent=1), encoding="utf-8")
