# PIV-Q27-V3.1 — response to the V3 pre-run audit (NO-GO, 7-patch set)

Every finding was first reproduced in code, then fixed. All changes are in `build/make_v3.py` as explicit
`old -> new` edits against `PIV-Q27-EVAL120-MEASUREMENT.ipynb` (the baseline run's notebook).

## Finding -> fix

| sev | audit finding | v3.1 fix | evidence |
|---|---|---|---|
| P0 | verbatim commit on train-exact even if test execution fails | gate is `all_train_exact and test_execution_ok`; a train-exact program that fails on a test input is NOT committed, the model gets `TEST INPUT FAILURE: ... It has NOT been submitted` and keeps working; the candidate is still kept as best candidate | harness `v31_train_exact_test_fails.txt`: 0 commits, 8 blocked, 8 kept via fallback |
| P0 | repaired code stored without the library | repair is OFF this run; in addition `_v25_update_record_from_selected` now stores `with_library(code)` so a later V3R stores exactly what was verified | builder edit |
| P0 | repair budget outside 12,288 cap | repair OFF (`REPAIR_POLICY_ENABLED = False`); the repair cell skip now honours the flag (baseline only skipped for PREFLIGHT/fake model) | all 4 harness logs: `repair round skipped: REPAIR_POLICY_ENABLED=False` |
| P0 | repair ignores the global deadline | same: no repair generation at all; deadline run shows no repair after the stop | `v31_deadline_injection.txt` |
| P1 | ranking = exact pairs only (`>=`) | `_v3_train_quality` = (train-exact AND test runs, train-exact, exact pairs, right-shaped pairs, test runs, pairs without exception, -wrong-cell fraction over all expected cells; wrong-shape/exception pairs count every cell wrong). Strict `>`. Used for best-candidate update, exploration-final fallback and finalizer fallback. Test targets never used | self-test `near_miss_ranking` (7-level strict ordering incl. 0-exact close vs far) |
| P1 | runtime reports 120 executed on a 45-task deadline stop | stage records `tasks_requested`, `tasks_executed` (= terminal records of this RUN_ID among pending), `tasks_unstarted`; cumulative uses terminal count | deadline run: 29 terminal / 91 incomplete, runtime reports **29** (v3 reported 120) |
| P1 | prompt said arc_overview/verify_solution usable inside `solution` | prompt split: "Exploration-only helpers (NEVER call them inside `solution`, they read `puzzle`)" vs "Grid helpers also available inside your final `solution`"; self-check asserts both strings | prompt build asserts |
| P1 | builder drops computed globals / mutation / type alias | dependency-aware builder: keeps imports, defs, classes, and module-level assignments / in-place method calls whose free names are builtins, library helpers or previously kept names, that do not read `puzzle`, do not call exploration-only helpers, and do not call a function that reads `puzzle`; drops anything depending on a dropped value. Prompt: "Define `solution` with `def`. Everything it depends on must be a top-level import, a function or class definition, or a constant; never `puzzle`" | self-test `builder_regressions`: computed constant, mutation (`T[k]=v`, `T.update`), type alias, puzzle exclusion, puzzle-reading function call exclusion, print/verify_solution exclusion, control flow exclusion, dependent-on-dropped exclusion, undefined AugAssign exclusion, alias `solution = solve` -> None |
| P1 | NVARC per-task map missing | `posthoc/nvarc_eval120_frozen.json` (from NVARC notebook cell 15, Probmul rank; source sha256 recorded) + `posthoc/score_vs_nvarc.py`. Not used by the solver | on the baseline run the scorer reproduces the canonical numbers exactly: TV 3, Strict 2, 1.67 %, PIV-only 0, NVARC 27.92 % (`posthoc/baseline_check_output.json`) |
| P2 | background_color is a heuristic | prompt: "most common colour, a heuristic: pass `background=` explicitly when unsure" | prompt |

Not adopted: `mismatch_component_count` in the ranking tuple (wrong-cell fraction already orders near misses; kept the tuple simple).

## Harness (fake vLLM, real tokenizer/template/data, real subprocess REPL + verifier), v3.1 notebook

| run | result |
|---|---|
| normal, 120 tasks | 120/120 terminal; all self-tests pass; 7 verbatim commits; 0 test-failed; repair skipped (flag); runtime 120 |
| train-exact but test fails (`HARNESS_V31_TESTFAIL=1`, lookup raises KeyError on test) | **0 commits**; 8 candidates blocked and reported; 8 finals = best candidate (beats finalizer identity) |
| deadline injection | clean stop, 29 terminal, `STAGE B INCOMPLETE - 91`; runtime reports 29; no repair |
| over-cap injection | exactly 16 tasks isolated as `engine_output_exceeded_max_tokens_phase1`; rest complete; 7 commits |

Process note: an earlier v3.1 harness attempt ran two harness processes concurrently on the same working directory;
those logs were discarded and all four runs repeated one at a time. Only the clean logs are in this bundle.

## Run plan

EVAL120 (120 public evaluation tasks), arm ACT-LOW-FORCED, 12,288 tokens/task, concurrency 12, repair off.
Measured afterwards with `posthoc/score_vs_nvarc.py`. Primary metric: Strict Solved among NVARC's 81 misses.

---

## Round 2 — S12 audit (NO-GO, 4 patches)

| finding | verified | fix |
|---|---|---|
| builder keeps stale `K = 0` after a dropped `K = puzzle...`; tainted helper -> solution | reproduced | taint on dropped rebinding/mutation, fixpoint, tainted `solution` -> no module + message to the model |
| pilot-gate failure shrinks the 12-task denominator to 2 | confirmed (cell 8) | immutable `PLANNED_TASK_IDS`; `v3_planned_report.json` always over the planned list, INCOMPLETE banner + not-run list |
| equal-quality finalizer replaces the tested best candidate | confirmed | ties keep the tested candidate (`>=`) |
| stale last markdown cell | confirmed | replaced with V3.1 run instructions |
| NVARC map not inside the notebook | confirmed | frozen map embedded; planned report prints PIV strict solves on NVARC misses |
| context gate (20,992) may skip tasks | real in principle, inactive: max initial prompt on all 120 eval tasks = 18,320 | unchanged |

## Round 3 — full-notebook audit (NO-GO, builder scope)

All four counterexamples (walrus, nested-function local, comprehension shadowing, `del`) reproduced. Instead of more
hand-written scope rules:

1. **Scope facts from `symtable`** (the compiler's own analysis), plus AST supplements for what symtable does not
   report (AugAssign read, `:=` inside a comprehension, in-place mutation, calls of kept functions that write globals).
   `build/unit_builder.py` (run from `build/`) runs 14 must-reject + 10 must-keep cases: **0 failures on Python 3.12 (Kaggle)
   and 3.14**.
2. **Runtime fidelity check**: after every fresh verification, the live REPL's `solution()` is run on every training
   input (probe not recorded as a cell) and its output signatures compared with the fresh module's. Mismatch or
   unknown -> candidate not accepted, not committed, model told which examples differ. Self-tested with a real worker.
3. Historical v2.x markdown collapsed under "SUPERSEDED".

Harness after round 3: S12 12/12, 5/5 fidelity match, 1 commit; full 120: 120/120, 35/35 match, 7 commits;
test-fail: 0 commits, 8 blocked, 36/36 match. `final_from_best_candidate` rises (0 -> 14) because of the tie rule:
the harness's exploration identity candidate ties the finalizer's identity program.
