"""v3.1 scenario: HARNESS_V31_TESTFAIL=1 makes the pos-6 train-exact program raise KeyError on the test input."""
from pathlib import Path
p = Path(__file__).with_name("harness_c1.py")
s = p.read_text(encoding="utf-8")
old = 'grid[0][0], grid[-1][-1]), grid)")\n'
assert s.count(old) == 1, s.count(old)
new = ('grid[0][0], grid[-1][-1]), grid)")\n'
       '                    if os.environ.get("HARNESS_V31_TESTFAIL"):\n'
       '                        _cheat = _cheat.replace("return T.get(", "return T[").replace("grid[-1][-1]), grid)", "grid[-1][-1])]")\n')
s = s.replace(old, new)
p.write_text(s, encoding="utf-8")
import ast; ast.parse(s); print("testfail scenario installed")
