# Prompt for the reviewer — paste this as your first message, with the zip attached

You audited **PIV-Q27-V3** and returned **NO-GO** with a 7-patch pre-run set. This bundle is **V3.1**, which applies
that set. Please re-audit it before the GPU run (one EVAL120 run costs ~10–13 of our ~60 weekly quota-hours; one
leaderboard submission per day; deadline 2026-11-02).

## Context (short)

* Kaggle 4×L4, vLLM 0.19.0, TP=4, offline, 12 h limit; 2 quota-hours per wall-hour.
* Model: Qwen3.8-27B-FP8 (fixed — do not recommend switching).
* Frozen baseline (`docs/CANONICAL_BASELINE_EVAL120_2026-10-03.md`): Train-Verified 3/120, Strict Solved 2/120, ARC
  score 1.67 %. The same solver's hidden-test submission scored **1.67 public LB**, matching the EVAL120 measurement.
* NVARC (team's other pipeline) = 27.92 % on EVAL120, 81 tasks with no query solved. **PIV's success metric: Strict
  Solved tasks among those 81.**

## What to read

1. `docs/V31_CHANGES_VS_V3_REVIEW.md` — every audit finding → fix → evidence, in one table. Start here.
2. `build/make_v3.py` — all changes as `old -> new` edits against the baseline notebook (v3.1 additions: commit gate,
   `_v3_train_quality`, dependency-aware `build_candidate_module`, `_v3_report_text`, regression self-tests, runtime
   accounting, repair skip flag, repair record `with_library`, prompt helper split).
3. `notebooks/PIV-Q27-V3_1-EVAL120-ALLFIX.ipynb` — the notebook that would run. V3 and the baseline notebook are
   included for diffing.
4. `harness_logs/` — four clean fake-engine runs on the v3.1 notebook (normal, train-exact-but-test-fails, deadline,
   over-cap). `harness/patch_harness_v31.py` adds the test-fail scenario.
5. `posthoc/` — frozen NVARC per-task map + scorer; `baseline_check_output.json` shows it reproduces the canonical
   numbers on the baseline run.

## What I want from you

1. Is each of your 7 patches implemented correctly and completely? Any regression it introduced?
2. `build_candidate_module` (new): find inputs where the module passes in the REPL but fails fresh, passes fresh with
   different semantics than the REPL, or keeps something that crashes at import (e.g. reads `puzzle` indirectly).
3. `_v3_train_quality`: is the ordering sound? Any case where a worse program displaces a better one, or where the
   fallback replaces a finalizer program that is actually better?
4. Commit gate: any path where a program that fails on a test input is still submitted verbatim, or where a valid
   train-exact + test-ok program is NOT committed?
5. Measurement integrity vs the baseline, and whether the post-hoc NVARC scorer computes the primary metric correctly.
6. GO / NO-GO for the EVAL120 GPU run. Separate confirmed defects (file/line + concrete failure) from suggestions.

## Map of the zip

```
PROMPT_FOR_REVIEWER.md
docs/V31_CHANGES_VS_V3_REVIEW.md, docs/CANONICAL_BASELINE_EVAL120_2026-10-03.md
notebooks/PIV-Q27-V3_1-EVAL120-ALLFIX.ipynb, PIV-Q27-V3-EVAL120-ALLFIX.ipynb, PIV-Q27-EVAL120-MEASUREMENT.ipynb
build/make_v3.py, build/piv_library.py
harness/harness_c1.py, patch_harness_v3.py, patch_harness_v3b.py, patch_harness_v31.py
harness_logs/v31_normal_120tasks.txt, v31_train_exact_test_fails.txt, v31_deadline_injection.txt, v31_overcap_injection.txt
posthoc/freeze_nvarc_map.py, nvarc_eval120_frozen.json, score_vs_nvarc.py, baseline_check_output.json
SHA256SUMS.txt
```
