# Prompt for the reviewer — paste this as your first message, with the zip attached

You are reviewing **PIV-Q27-V3**, a notebook that has **not yet run on GPU**. It changes ten things at once in a
Qwen3.8-27B program-synthesis solver for ARC Prize 2026 (ARC-AGI-2). A GPU run costs ~10–13 of our ~60 weekly
quota-hours, and the team gets one leaderboard submission per day with ~30 days left, so a bug that wastes the run is
expensive. Find what would break it or make its measurement misleading **before** it runs.

## Context (short)

* Hardware: Kaggle 4×L4, vLLM 0.19.0, tensor-parallel 4, offline, 12 h limit. A 4×L4 session burns 2 quota-hours per
  wall-clock hour.
* The previous run of the same solver on the **120 public evaluation tasks** (answers known) is frozen in
  `docs/CANONICAL_BASELINE_EVAL120_2026-10-03.md`: **Train-Verified 3/120, Strict Solved 2/120, ARC score 1.67 %**,
  4.56 h wall clock. Three independent reviews agreed on the diagnosis; every v3 change answers one finding there.
* The team's other pipeline (NVARC) scores 27.92 % on the same 120 tasks. PIV currently adds **zero** tasks NVARC does
  not already solve, but 25 of its 36 near-miss programs are on tasks NVARC misses entirely. **PIV's success metric is
  therefore additional Strict Solved tasks among NVARC's 81 misses**, not PIV's standalone score.

## What v3 changes (each item maps to a baseline finding)

| baseline finding | v3 change | where |
|---|---|---|
| 49/120 first turns spent all 6,144 exploration tokens transcribing grids, never acting | arm `ACT-LOW-FORCED`: low effort, forced `</think>` after 2,048 thinking tokens; prompt forbids transcription; `puzzle.keys()` instruction removed | config `ARM_CONFIG`, prompt `build_agent_user_prompt` |
| forced arm's last action cut at exactly 768 tokens | `ACTION_RESERVE_TOKENS = ACTION_MAX_TOKENS` (2,048) | config |
| only 3/173 tool calls ever ran a complete `solution()` on the training pairs | after every successful tool call, a standalone module is built from the REPL history (`build_candidate_module`) and fresh-verified; the report is appended to the tool output | helpers cell + scheduler tool loop |
| a verified program could be rewritten by the finalizer | train-exact candidate committed verbatim; task ends | scheduler, after the tool message |
| 38/120 finalizers truncated at exactly 2,048 tokens | `FINAL_RESERVE_TOKENS = 4096`; total budget 12,288 (8,192 exploration + 4,096) | config |
| ~65 % of failed-finalizer text was reasoning in comments | code-only `TERMINAL_FINALIZER_INSTRUCTION`; finalizer temperature 0.1 | config |
| handoff = last 1,024 reasoning tokens (102/120 truncated) | if a candidate exists: best candidate code + verifier report instead | `_terminal_messages_with_reasoning_handoff` |
| hand-written BFS/geometry bugs (e.g. `_connected` bug in `8e5c0c38`) | tested helper library preloaded in the REPL and prepended to every verified program | `PIV_LIBRARY_SRC`, `with_library`, verifier wrapper |
| repair: 52/79 parse failures, budget taken from leftovers | repair only near misses (≥1 exact pair, or all failing pairs right-sized with ≤20 % wrong cells); own 4,096 budget | repair cell, `_v25_repair_admission` |
| 29 % of wave time with ≤2 active requests | dynamic backfill: a finished task's slot is refilled immediately | scheduler batch loop |
| — | best tested candidate is kept when the finalizer fails to parse or commits something worse | scheduler finalizer + exploration-final paths |

`build/make_v3.py` contains every change as an explicit `old → new` edit against the previous notebook
(`PIV-Q27-EVAL120-MEASUREMENT.ipynb`, also included); that is the fastest way to review.
`build/piv_library.py` is the helper library verbatim. `docs/rendered_user_prompt_1818057f.txt` is the exact prompt
the model will see for one task.

## What the local harness showed (fake vLLM, real tokenizer/template, real data, real subprocess REPL/verifier)

| run | result |
|---|---|
| normal, all 120 tasks | completes; 120/120 terminal records; all self-tests pass (incl. new library/candidate-builder tests); positive control and interface gate pass; forced close fired on 106 tasks; auto-verify on 21 tasks (35 runs); 7 verbatim commits, each `verified`, finalizer not started, program carries the library; backfill kept 10–12 tasks active through stage B |
| deadline injection | stops cleanly at 45 tasks, reports `STAGE B INCOMPLETE — 75 tasks`, no crash |
| over-cap injection on the forced phase-1 path | exactly the 16 injected tasks are isolated as `engine_output_exceeded_max_tokens_phase1`; the other 104 complete; backfill unaffected |

Two harness defects were found and fixed during this (not notebook defects): the fake "train-exact" scenario first
returned more tokens than the request cap, then embedded whole evaluation grids that do not fit a 2,048-token action.

The harness cannot show: whether Qwen follows the new workflow, how low effort + forced close behaves on the real
model, real throughput with backfill at concurrency 12, or accuracy.

## What I want from you

1. **Correctness of the new control flow.** In particular: the verbatim-commit `break` inside the per-call loop and
   everything that runs after it in that turn; `_init_task` and the backfill loop (state init, worker lifecycle,
   deadline/stop interaction, records for tasks still queued at the deadline); the finalizer fallback to the best
   candidate; double-recording of any task.
2. **`build_candidate_module`.** It keeps imports, defs, classes and literal assignments from successful REPL cells,
   in order, and drops everything else. Where can that produce a module that passes in the REPL but fails fresh, or
   the reverse? Is dropping computed module-level constants (e.g. `DIRS = list(...)`) acceptable given the model is
   told via the verifier report?
3. **Library injection.** It is exec'd into the REPL namespace at init and prepended to every program before fresh
   verification (`fresh_verify_solution` is wrapped). Any path where a stored or scored program runs without it, or
   where the guard rejects it? Any helper with wrong semantics?
4. **Measurement integrity.** Will the run's scores still be comparable with the canonical baseline (same 120 tasks,
   same scorer)? What in the new mechanisms could inflate or deflate Train-Verified/Strict Solved artificially?
5. **Budget/runtime.** Total budget rises from 8,192 to 12,288 tokens per task while backfill and early verbatim
   commits save time. Is ~4.5–6.5 h a sound estimate? Any way it overruns 12 h?
6. **Anything that should be removed** from this run because its risk outweighs its value.

Please separate confirmed defects (with file/line and a concrete failure scenario) from concerns and suggestions.
Do not recommend switching away from Qwen3.8-27B.

## Map of the zip

```
PROMPT_FOR_REVIEWER.md       this file
notebooks/
  PIV-Q27-V3-EVAL120-ALLFIX.ipynb       the notebook under review
  PIV-Q27-EVAL120-MEASUREMENT.ipynb     its predecessor (the baseline run's notebook)
build/
  make_v3.py                  every change as old -> new edits
  piv_library.py              the preloaded helper library
harness/
  harness_c1.py               fake-engine harness as used (incl. v3 scenarios)
  patch_harness_v3.py, patch_harness_v3b.py
harness_logs/
  v3_normal_120tasks.txt, v3_deadline_injection.txt, v3_overcap_injection.txt
docs/
  CANONICAL_BASELINE_EVAL120_2026-10-03.md   the frozen baseline v3 is compared against
  rendered_user_prompt_1818057f.txt          exact model-facing prompt for one task
SHA256SUMS.txt
```
