"""Harness scenarios for v3: exercise automatic candidate verification and verbatim commit."""
from pathlib import Path

p = Path(__file__).with_name("harness_c1.py")
s = p.read_text(encoding="utf-8")
NL = chr(92) + "n"

# pos 2: second tool call defines an identity solution() -> auto-verify feedback, task keeps going
old2 = '''                elif pos == 2:
                    o = _Out(tok, act(TOOL(f"x{n_tool}={n_tool}; print(x{n_tool})")), 200, "stop")'''
new2 = '''                elif pos == 2:
                    _c2 = ("def solution(grid):NL    return [row[:] for row in grid]" if n_tool == 1
                           else f"x{n_tool}={n_tool}; print(x{n_tool})")
                    o = _Out(tok, act(TOOL(_c2)), 200, "stop")'''.replace("NL", NL)
assert s.count(old2) == 1, s.count(old2)
s = s.replace(old2, new2)

# pos 6: first tool call defines a train-exact lookup solution() -> verbatim commit ends the task
anchor6 = "                elif pos == 6:\n                    seq = [TOOL(\"print(puzzle.keys())\"),"
assert s.count(anchor6) == 1, s.count(anchor6)
new6 = '''                elif pos == 6 and os.environ.get("HARNESS_V3_COMMIT", "1") == "1" and n_tool == 0:
                    _task = G["eval_challenges"][tid]
                    _cheat = ("T = " + repr({repr(ex["input"]): ex["output"] for ex in _task["train"]})
                              + "NLdef solution(grid):NL    return T.get(repr(grid), grid)")
                    o = _Out(tok, act(TOOL(_cheat)), 4000, "stop")
'''.replace("NL", NL)
s = s.replace(anchor6, new6 + anchor6)
p.write_text(s, encoding="utf-8")
import ast
ast.parse(s)
print("harness v3 scenarios added")
