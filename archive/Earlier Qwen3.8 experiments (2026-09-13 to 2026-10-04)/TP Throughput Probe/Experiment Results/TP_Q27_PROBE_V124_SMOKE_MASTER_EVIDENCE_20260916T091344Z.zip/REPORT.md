# TP-Q27-THROUGHPUT-PROBE-v1.2.4-MASTER — SMOKE_GPU — 20260916T091344Z

comparison_valid: **True** | anchor: `{"expected_sec_per_token_per_seq": 0.16, "expected_agg_tps_at_8": 50.0, "anchor_output_tokens": 4096, "measured_sec_per_token_per_seq": 0.16562922038891614, "measured_agg_tps_at_8": 48.300656014772606, "ratio_speed": 0.9660131202954522, "pass": true}` | drift: `{"start_tps": 27.149407499664502, "end_tps": 27.238624042305034, "ratio": 1.0032861322163895, "bounds": [0.8, 1.2], "pass": true}`

Cache verification: `{}`

## Leaders (numerics-safe unless marked raw)

`{
  "tp4_numerics_safe": {
    "config": "C0_frozen_q1",
    "agg_tps": 37.68298678339031,
    "n": 16,
    "mixed_tps": 23.58689130790645,
    "stability_cv": 0.0004067157534279246,
    "numerics_exact": true
  },
  "tp2_single_numerics_safe": null,
  "tp2x2_safe": null,
  "single_engine_numerics_safe": {
    "config": "C0_frozen_q1",
    "agg_tps": 37.68298678339031,
    "n": 16,
    "mixed_tps": 23.58689130790645,
    "stability_cv": 0.0004067157534279246,
    "numerics_exact": true
  },
  "prefix_extension": null,
  "memory_capacity": {
    "config": "C0_frozen_q1",
    "kv_cache_tokens": 159936
  },
  "raw_throughput_including_experimental": {
    "config": "C1_graph_noAR",
    "agg_tps": 48.95461330454298,
    "n": 16,
    "mixed_tps": 31.448590735403815,
    "stability_cv": 0.00027807472886727,
    "numerics_exact": false
  }
}`

Next solver-smoke candidates: `{"tp4_engine": "C0_frozen_q1", "tp2_single": null, "tp2x2_topology": null}`

## Measurement files

- `analysis/summary_table.csv` — per-config aggregate view
- `analysis/phase_metrics.csv` — every physical phase, prompt balance, integrity, energy estimate
- `analysis/common_concurrency.csv` — common n=8/16/32/64 task-ID matched view
- `analysis/pairwise_effects.csv` — one-variable deltas
- `analysis/stability.json` — repeated-wave jitter/CV
- `analysis/gpu_health.csv` — thermal/clock/utilization summary
- `analysis/runtime_health.csv` — preemption/error/reclaim/timeout evidence
- `analysis/topology_pairings.csv` — TP2×2 perfect-matching sweep evidence
- `measurement/batch_plan*.json` — balanced prompt assignment evidence
- `environment/*` — driver/GPU topology/CPU/RAM/disk/pip/runtime evidence

## Guardrails

- Real chat-template rendering is fail-closed.
- No solver candidate is emitted if the C0 long anchor fails.
- Single-engine candidates require greedy-fingerprint prefix agreement >= NUMERICS_MIN_PREFIX_AGREEMENT vs C0 (exactness reported separately).
- MTP is measured but excluded from direct solver promotion.
- Raw fixed-length throughput, mixed-length throughput, multi-turn prefix reuse, stability, memory and energy are reported separately.

## What this does not prove

Solve quality, final ARC score, leaderboard method attribution, or real multi-turn solver wall-clock. Those require the next real solver smoke.