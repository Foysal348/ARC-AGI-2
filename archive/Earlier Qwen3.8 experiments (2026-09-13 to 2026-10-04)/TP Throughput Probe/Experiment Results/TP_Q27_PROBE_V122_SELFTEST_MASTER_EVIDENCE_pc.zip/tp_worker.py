
# tp_worker.py -- measure one vLLM engine configuration. Written by the TP-Q27 v1.2.2 MASTER probe notebook.
import argparse, json, os, sys, time, random, traceback, dataclasses

class Unsupported(Exception):
    pass

def read_json(p):
    with open(p, "r", encoding="utf-8") as f:
        return json.load(f)

class FakeEngine:
    """CPU stand-in with a plausible speed model; only for SELFTEST_CPU."""
    def __init__(self, spec, result):
        kw = dict(spec["engine_kwargs"])
        name = spec["name"]
        if "fake_fail" in name:
            raise RuntimeError("selftest: simulated engine init failure (CUDA OOM during graph capture)")
        if "fake_hang" in name:
            time.sleep(3600)
        self.scale = float(spec.get("fake_time_scale", 1.0))
        base = 6.25
        if not kw.get("enforce_eager", True):
            base *= 2.6
        if not kw.get("disable_custom_all_reduce", True):
            base *= 1.08
        if kw.get("kv_cache_dtype") == "fp8":
            base *= 0.97
        self.base = base
        self.prefix = bool(kw.get("enable_prefix_caching"))
        self.seen = set()
        self.seen_texts = set()
        time.sleep(0.3 * 1.0)
        result["engine_kwargs_used"] = kw
        result["load_sec"] = 277.0 + (90.0 if not kw.get("enforce_eager", True) else 0.0)
        result["fake"] = True

    def generate(self, prompts, sp):
        n=len(prompts); splist=sp if isinstance(sp,list) else [sp]*n
        mts=[int(x["max_tokens"]) for x in splist]; per_seq=self.base/(1.0+0.012*n)
        prior=list(self.seen_texts)
        def cp_chars(a,b):
            k=0; m=min(len(a),len(b))
            while k<m and a[k]==b[k]: k+=1
            return k
        cached=[]; prefill_each=[]
        for p in prompts:
            c=max([cp_chars(p,q) for q in prior] or [0]) if self.prefix else 0
            c_tok=min(len(p)//4,c//4); cached.append(c_tok)
            uncached=max(1,len(p)//4-c_tok); rate=40000.0 if c_tok>0 else 4000.0
            prefill_each.append(uncached/rate)
        self.seen_texts.update(prompts); self.seen.update(hash(p) for p in prompts)
        prefill=sum(prefill_each); decode_work=sum(mts)/max(1.0,n*per_seq)
        time.sleep((prefill+decode_work)/self.scale)
        outs=[]
        for j,(p,one) in enumerate(zip(prompts,splist)):
            mt=int(one["max_tokens"]); rng=random.Random(int(one.get("seed",0))+n+j)
            ids=[rng.randrange(1000,50000) for _ in range(mt)] if float(one.get("temperature",1.0))>0 else [(i*7919+len(p))%50000 for i in range(mt)]
            dec=max(0.0,(mt-1)/max(1e-9,per_seq)); ttft=prefill_each[j]
            outs.append({"prompt_token_ids":[0]*(len(p)//4),"token_ids":ids,"num_cached_tokens":cached[j],
                         "num_cache_creation_tokens":max(0,len(p)//4-cached[j]),
                         "metrics":{"first_token_latency":ttft,"queued_ts":0.0,"scheduled_ts":0.0,"first_token_ts":ttft,"last_token_ts":ttft+dec,"num_generation_tokens":mt,"is_corrupted":False}})
        return outs


class RealEngine:
    def __init__(self, spec, result):
        import inspect
        import vllm
        from vllm import LLM, SamplingParams
        from vllm.engine.arg_utils import EngineArgs
        self.SamplingParams = SamplingParams
        result["runtime"] = {"vllm": getattr(vllm, "__version__", None)}
        valid = {f.name for f in dataclasses.fields(EngineArgs)} | set(inspect.signature(LLM.__init__).parameters)
        valid.discard("kwargs"); valid.discard("self")
        kw = dict(spec["engine_kwargs"])
        overrides = dict(spec.get("overrides", {}))
        # The Q1-frozen base kwargs are known-good on this stack; only the ladder's override keys can be
        # unsupported. A rejected override is a distinct outcome ("unsupported"), not an engine failure.
        unsupported = sorted(k for k in overrides if k not in valid)
        result["unsupported_kwargs"] = unsupported
        result["base_kwargs_not_in_signature"] = sorted(k for k in kw if k not in valid and k not in overrides)
        if unsupported:
            raise Unsupported("engine kwargs not accepted by this vLLM build: %s" % unsupported)
        result["engine_kwargs_used"] = kw
        t0 = time.perf_counter()
        try:
            self.llm = LLM(**kw)
        except Exception as e:
            msg = "%s: %s" % (type(e).__name__, e)
            if overrides and any(k in msg for k in overrides):
                result["unsupported_kwargs"] = sorted(k for k in overrides if k in msg)
                raise Unsupported(msg)
            raise
        result["load_sec"] = time.perf_counter() - t0

    def generate(self, prompts, sp):
        if isinstance(sp,list): params=[self.SamplingParams(**x) for x in sp]
        else: params=self.SamplingParams(**sp)
        outs=self.llm.generate(prompts,params,use_tqdm=False)
        rows=[]
        for o in outs:
            m=getattr(o,"metrics",None)
            md=None
            if m is not None:
                md={k:getattr(m,k,None) for k in ("arrival_time","queued_ts","scheduled_ts","first_token_ts","last_token_ts","first_token_latency","num_generation_tokens","is_corrupted")}
            rows.append({"prompt_token_ids":list(getattr(o,"prompt_token_ids",None) or []),
                         "token_ids":list(o.outputs[0].token_ids),
                         "num_cached_tokens":getattr(o,"num_cached_tokens",None),
                         "num_cache_creation_tokens":getattr(o,"num_cache_creation_tokens",None),
                         "metrics":md})
        return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--spec", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--fake", action="store_true")
    a = ap.parse_args()
    spec = read_json(a.spec)
    scale = float(spec.get("fake_time_scale", 1.0)) if a.fake else 1.0
    result = {"config": spec["name"], "status": "started", "phases": [], "timeline": [], "error": None,
              "engine_kwargs_used": None, "unsupported_kwargs": [], "load_sec": None, "fingerprint": None,
              "worker_pid": os.getpid(), "started_epoch": time.time()}

    def dump():
        tmp = a.out + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(result, f, indent=2, sort_keys=True, default=str)
        os.replace(tmp, a.out)

    def mark(event):
        result["timeline"].append({"event": event, "epoch": time.time()})
        dump()

    dump()
    pool = read_json(spec["prompts_path"])
    texts = [r["prompt"] for r in pool]
    ptoks = [int(r["prompt_tokens"]) for r in pool]
    history_texts=[r.get("history_seed",r["prompt"]) for r in pool]
    history_ptoks=[int(r.get("history_seed_tokens",r["prompt_tokens"])) for r in pool]
    ext_small_texts=[r.get("prompt_extension_small",r["prompt"]) for r in pool]
    ext_small_ptoks=[int(r.get("prompt_extension_small_tokens",r["prompt_tokens"])) for r in pool]
    ext_texts=[r.get("prompt_extension",r["prompt"]) for r in pool]
    ext_ptoks=[int(r.get("prompt_extension_tokens",r["prompt_tokens"])) for r in pool]
    ext_large_texts=[r.get("prompt_extension_large",r["prompt"]) for r in pool]
    ext_large_ptoks=[int(r.get("prompt_extension_large_tokens",r["prompt_tokens"])) for r in pool]
    ext_agent_texts=[r.get("prompt_extension_agent",r["prompt"]) for r in pool]
    ext_agent_ptoks=[int(r.get("prompt_extension_agent_tokens",r["prompt_tokens"])) for r in pool]
    shared_small=[int(r.get("shared_prefix_tokens_small",0)) for r in pool]
    shared_medium=[int(r.get("shared_prefix_tokens_medium",0)) for r in pool]
    shared_large=[int(r.get("shared_prefix_tokens_large",0)) for r in pool]
    shared_agent=[int(r.get("shared_prefix_tokens_agent",0)) for r in pool]
    out_tokens = int(spec["output_tokens"])
    seed = int(spec["seed"])
    engine = None

    def wave(name,idx,sp,note=None,text_source=None,ptok_source=None,base_ptok_source=None,shared_prefix_source=None):
        source=texts if text_source is None else text_source; psource=ptoks if ptok_source is None else ptok_source
        bsource=None if base_ptok_source is None else base_ptok_source; shsource=None if shared_prefix_source is None else shared_prefix_source
        ts=[source[i%len(source)] for i in idx]; prompt_lengths=[int(psource[i%len(psource)]) for i in idx]
        base_lengths=[int(bsource[i%len(bsource)]) for i in idx] if bsource is not None else None
        shared_lengths=[int(shsource[i%len(shsource)]) for i in idx] if shsource is not None else None
        pt_expected=sum(prompt_lengths); requested=([int(x["max_tokens"]) for x in sp] if isinstance(sp,list) else [int(sp["max_tokens"])]*len(ts))
        mark("phase_start:"+name); t0=time.perf_counter(); outs=engine.generate(ts,sp); wall=(time.perf_counter()-t0)*scale; mark("phase_end:"+name)
        ot=[len(o["token_ids"]) for o in outs]; pe=[len(o["prompt_token_ids"]) for o in outs]
        cached=[o.get("num_cached_tokens") for o in outs]; cached_valid=[int(x) for x in cached if x is not None]
        metrics=[o.get("metrics") or {} for o in outs]
        def pct(a,q):
            a=sorted(float(x) for x in a if x is not None)
            if not a:return None
            pos=(len(a)-1)*q; lo=int(pos); hi=min(len(a)-1,lo+1); f=pos-lo
            return a[lo]*(1-f)+a[hi]*f
        ttft=[m.get("first_token_latency") for m in metrics if m.get("first_token_latency") is not None]
        qtime=[]; dtime=[]; req_tps=[]
        for m,tok in zip(metrics,ot):
            q0,q1=m.get("queued_ts"),m.get("scheduled_ts"); f,l=m.get("first_token_ts"),m.get("last_token_ts")
            if q0 is not None and q1 is not None and q1>=q0: qtime.append(q1-q0)
            if f is not None and l is not None and l>=f:
                d=l-f; dtime.append(d)
                if d>0 and tok>1: req_tps.append((tok-1)/d)
        pls=sorted(prompt_lengths)
        ph={"phase":name,"n":len(ts),"wall_sec":wall,"requested_output_tokens":requested,"requested_output_tokens_total":sum(requested),"max_tokens":max(requested) if requested else 0,
            "out_tokens_total":sum(ot),"out_tokens_list":ot,"out_tokens_min":min(ot),"out_tokens_max":max(ot),"all_reached_max_tokens":all(t==r for t,r in zip(ot,requested)),
            "prompt_tokens_total_tokenizer":pt_expected,"prompt_tokens_total_engine":(sum(pe) if all(pe) else None),
            "prompt_tokens_min":min(pls),"prompt_tokens_median":pct(pls,0.5),"prompt_tokens_p90":pct(pls,0.9),"prompt_tokens_max":max(pls),
            "prompt_unique_indices":len(set(i%len(source) for i in idx)),"prompts_repeated":(len(set(i%len(source) for i in idx))<len(idx)),"prompt_index_range":[min(idx),max(idx)] if idx else None,
            "agg_gen_tps":sum(ot)/wall if wall>0 else None,"per_seq_gen_tps":(sum(ot)/len(ot))/wall if wall>0 else None,
            "sec_per_output_token_per_seq":wall/max(1,max(requested) if requested else 1),"effective_full_prefill_tps":pt_expected/wall if wall>0 else None,"prefill_tps":pt_expected/wall if wall>0 else None,
            "num_cached_tokens_list":cached,"num_cached_tokens_total":sum(cached_valid) if cached_valid else None,
            "cache_hit_ratio_prompt":(sum(cached_valid)/pt_expected) if cached_valid and pt_expected else None,
            "ttft_sec_median":pct(ttft,0.5),"ttft_sec_p95":pct(ttft,0.95),"queue_sec_median":pct(qtime,0.5),"queue_sec_p95":pct(qtime,0.95),
            "request_decode_sec_median":pct(dtime,0.5),"request_decode_sec_p95":pct(dtime,0.95),"request_decode_tps_median":pct(req_tps,0.5),"request_decode_tps_p05":pct(req_tps,0.05),
            "request_timing_available_count":sum(1 for m in metrics if m),"request_metrics":metrics,"note":note}
        if base_lengths is not None:
            base_total=sum(base_lengths); new_total=max(0,pt_expected-base_total); ph["base_prompt_tokens_total"]=base_total; ph["new_suffix_tokens_total"]=new_total; ph["new_suffix_tps"]=new_total/wall if wall>0 else None
        if shared_lengths is not None:
            sh=sum(shared_lengths); ph["expected_shared_prefix_tokens_total"]=sh
            ph["cached_vs_expected_shared_ratio"]=(sum(cached_valid)/sh) if cached_valid and sh>0 else None
        result["phases"].append(ph); dump(); return outs


    def balanced(n, salt=0):
        # prompts.json is sorted by length. Quantile-spaced indices make n=8/16/32/... comparable.
        if n <= 0: return []
        m=len(texts); k=min(n,m)
        if k == 1: base=[0]
        else: base=[int(round(j*(m-1)/(k-1))) for j in range(k)]
        if n > m: base += [base[(j+salt)%len(base)] for j in range(n-m)]
        if base and salt:
            q=salt%len(base); base=base[q:]+base[:q]
        return base

    def balanced_from(candidates, n, salt=0):
        candidates=list(candidates)
        if not candidates or n<=0: return []
        k=min(n,len(candidates))
        if k==1: out=[candidates[0]]
        else: out=[candidates[int(round(j*(len(candidates)-1)/(k-1)))] for j in range(k)]
        if n>len(candidates): out += [out[(j+salt)%len(out)] for j in range(n-len(candidates))]
        if out and salt:
            q=salt%len(out); out=out[q:]+out[:q]
        return out

    try:
        mark("load_start")
        engine = FakeEngine(spec, result) if a.fake else RealEngine(spec, result)
        mark("load_end")
        dump()
        max_seqs = int(spec["engine_kwargs"].get("max_num_seqs", 16))
        base_sp = {"temperature": 1.0, "top_p": 0.95, "top_k": 20, "seed": seed, "ignore_eos": True}
        pool_len = len(texts)
        # warmup (also validates generate() on this engine)
        n_warm = min(int(spec["warmup_prompts"]), pool_len)
        _warm_texts=[t + "\n\n# throughput-warmup-only" for t in texts]
        _warm_ptoks=[x + 8 for x in ptoks]
        wave("warmup", balanced(n_warm, salt=5), dict(base_sp, max_tokens=16), text_source=_warm_texts, ptok_source=_warm_ptoks, note="cache-isolated warmup prompt variant")

        if spec.get("drift_sentinel"):
            wave("decode@8", balanced(8,salt=2), dict(base_sp,max_tokens=out_tokens), note="end-session frozen-Q1 drift sentinel")
            fk=min(int(spec["fingerprint_prompts"]),len(texts)); fp_sp={"temperature":0.0,"max_tokens":int(spec["fingerprint_tokens"]),"ignore_eos":True,"seed":seed}
            outs=wave("fingerprint",balanced(fk,salt=3),fp_sp); result["fingerprint"]=[o["token_ids"] for o in outs]; result["status"]="ok"
            result["finished_epoch"]=time.time(); dump(); print("TP_WORKER_DONE status=ok config=%s"%spec["name"],flush=True); return

        # Synchronized TP2x2 member: load/warm first, then wait for parent barrier and run one balanced decode wave.
        if spec.get("pair_member"):
            from pathlib import Path as _P
            bdir = _P(spec["barrier_dir"]); bdir.mkdir(parents=True, exist_ok=True)
            (_P(bdir) / ("ready_" + str(spec["pair_member_id"]))).write_text("ready")
            go = _P(bdir) / "GO"
            wait0 = time.time()
            while not go.exists():
                if time.time() - wait0 > float(spec.get("barrier_timeout_sec", 300)):
                    raise RuntimeError("pair barrier timeout")
                time.sleep(0.2)
            n = min(int(spec["pair_n"]), max_seqs)
            _off = int(spec.get("pair_prompt_offset", 0))
            idx = [(i + _off) % len(texts) for i in balanced(n, salt=100 + int(spec.get("pair_member_id",0))*17)]
            wave("pair_decode@%d" % n, idx, dict(base_sp, max_tokens=out_tokens), note="synchronized TP2x2 member")
            result["status"] = "ok"; result["finished_epoch"] = time.time(); dump()
            print("TP_WORKER_DONE status=ok config=%s" % spec["name"], flush=True)
            return

        if spec.get("anchor_long"):
            n_anchor = min(int(spec.get("anchor_batch_n", 8)), max_seqs)
            wave("anchor_long@%d" % n_anchor, balanced(n_anchor, salt=7),
                 dict(base_sp, max_tokens=int(spec.get("anchor_output_tokens", out_tokens))), note="Q1/PIV long-decode anchor")

        used_decode=set()
        for n in sorted(int(x) for x in spec["decode_points"]):
            if n > max_seqs:
                result["phases"].append({"phase": "decode@%d" % n, "n": n, "skipped": "n > max_num_seqs=%d" % max_seqs}); dump(); continue
            idx = balanced(n, salt=n//4)
            used_decode.update(i % pool_len for i in idx)
            wave("decode@%d" % n, idx, dict(base_sp, max_tokens=out_tokens), note="balanced prompt-length quantiles")

        # Solver-representative long decode: PIV's active reasoning budget is 3,072 model tokens/turn.
        # Only selected configs carry solver_long_n so this does not multiply every optional row's cost.
        if spec.get("solver_long_n"):
            ln=min(int(spec["solver_long_n"]),max_seqs)
            wave("solver_long@%d" % ln, balanced(ln,salt=61),
                 dict(base_sp,max_tokens=int(spec.get("solver_long_tokens",3072))),
                 note="solver-representative 3072-token decode")

        # Mixed completion lengths: controlled continuous-batching tail, independent of EOS behavior.
        mn=min(int(spec.get("mixed_batch_n", 16)), max_seqs)
        if bool(spec["engine_kwargs"].get("enable_prefix_caching")):
            _fresh_mixed=[i for i in range(pool_len) if i not in used_decode]
            midx=balanced_from(_fresh_mixed if len(_fresh_mixed)>=mn else range(pool_len), mn, salt=53)
            _mixed_note="controlled heterogeneous max_tokens; fresh prompts for prefix-cache row" if len(_fresh_mixed)>=mn else "controlled heterogeneous max_tokens; prefix-cache overlap unavoidable"
        else:
            midx=balanced(mn, salt=53); _mixed_note="controlled heterogeneous max_tokens; continuous-batching tail"
        fracs=list(spec.get("mixed_output_fractions", [0.25,0.5,0.75,1.0]))
        mixed_sp=[]
        for j in range(mn):
            cap=max(1,int(round(out_tokens*float(fracs[j%len(fracs)]))))
            mixed_sp.append(dict(base_sp, max_tokens=cap, seed=seed+j+10000))
        wave("mixed_decode@%d" % mn, midx, mixed_sp, note=_mixed_note)

        # Repeatability / jitter at one balanced point. Prefix-cache rows are excluded to avoid measuring warmed cache.
        if not bool(spec["engine_kwargs"].get("enable_prefix_caching")):
            sn=min(int(spec.get("stability_batch_n", 32)), max_seqs)
            for rr in range(int(spec.get("stability_repeats", 2))):
                wave("stability@%d_r%d" % (sn,rr+1), balanced(sn, salt=71+rr*11),
                     dict(base_sp, max_tokens=int(spec.get("stability_tokens", 256)), seed=seed+20000+rr), note="repeatability/jitter wave")

        # Base cold/exact-repeat plus tool-history cache seed and realistic next-turn extensions.
        k=min(int(spec["prefill_prompts"]),pool_len,max_seqs); fresh=[i for i in range(pool_len) if i not in used_decode]
        if len(fresh)>=k:
            pre_idx=[fresh[int(round(j*(len(fresh)-1)/max(1,k-1)))] for j in range(k)]; overlap_note=None
        else:
            pre_idx=balanced(k,salt=91); overlap_note="insufficient fresh prompts; cold may overlap earlier phases"
        pre_sp={"temperature":0.0,"max_tokens":1,"ignore_eos":True}
        wave("prefill_cold",pre_idx,pre_sp,note=overlap_note)
        wave("prefill_warm_exact",pre_idx,pre_sp,note="identical prompts re-sent"+("; "+overlap_note if overlap_note else ""),shared_prefix_source=ptoks)
        # v1.2.2: the tool-history seed and the extension waves only carry information when prefix caching
        # is on (otherwise every 'cached' ratio is 0 by construction and the waves cost ~10 min per row).
        if bool(spec["engine_kwargs"].get("enable_prefix_caching")):
            # Seed the exact assistant-tool-call history so extension phases can verify full-history prefix reuse.
            wave("tool_history_seed",pre_idx,pre_sp,note="historical assistant reasoning+tool-call prefix seed",text_source=history_texts,ptok_source=history_ptoks)
            wave("prefill_warm_extension_small",pre_idx,pre_sp,note="cached tool-history + small tool result",text_source=ext_small_texts,ptok_source=ext_small_ptoks,base_ptok_source=history_ptoks,shared_prefix_source=shared_small)
            wave("prefill_warm_extension",pre_idx,pre_sp,note="cached tool-history + medium tool result",text_source=ext_texts,ptok_source=ext_ptoks,base_ptok_source=history_ptoks,shared_prefix_source=shared_medium)
            wave("prefill_warm_extension_large",pre_idx,pre_sp,note="cached tool-history + large tool result",text_source=ext_large_texts,ptok_source=ext_large_ptoks,base_ptok_source=history_ptoks,shared_prefix_source=shared_large)
        else:
            result["phases"].append({"phase":"prefill_extensions","skipped":"enable_prefix_caching=False: extension waves carry no cache information on this row"}); dump()
        if spec.get("agent_turn_n"):
            an=min(int(spec["agent_turn_n"]),len(pre_idx),max_seqs); aidx=pre_idx[:an]
            wave("agent_turn_extension@%d"%an,aidx,dict(base_sp,max_tokens=int(spec.get("agent_turn_output_tokens",256)),seed=seed+31000),
                 note="cached tool-history + new tool result + next assistant decode",text_source=ext_agent_texts,ptok_source=ext_agent_ptoks,base_ptok_source=history_ptoks,shared_prefix_source=shared_agent)


        fk=min(int(spec["fingerprint_prompts"]),len(texts))
        fp_sp={"temperature":0.0,"max_tokens":int(spec["fingerprint_tokens"]),"ignore_eos":True,"seed":seed}
        outs=wave("fingerprint", balanced(fk,salt=3), fp_sp)
        result["fingerprint"]=[o["token_ids"] for o in outs]
        result["status"] = "ok"
    except Unsupported as e:
        result["status"] = "unsupported"
        result["error"] = str(e)
    except BaseException as e:
        result["status"] = "failed"
        result["error"] = "%s: %s" % (type(e).__name__, e)
        result["traceback"] = traceback.format_exc()
    result["finished_epoch"] = time.time()
    dump()
    code = 0 if result["status"] in ("ok", "unsupported") else 3
    print("TP_WORKER_DONE status=%s config=%s" % (result["status"], spec["name"]), flush=True)
    # Prefer a clean exit (vLLM's atexit hooks shut the TP workers down); if that hangs, hard-exit
    # after 90 s. The parent reclaims any GPU process that survives either path.
    import threading
    threading.Thread(target=lambda: (time.sleep(90.0), os._exit(code)), daemon=True).start()
    engine = None
    import gc
    gc.collect()
    sys.stdout.flush(); sys.stderr.flush()
    sys.exit(code)

if __name__ == "__main__":
    main()
