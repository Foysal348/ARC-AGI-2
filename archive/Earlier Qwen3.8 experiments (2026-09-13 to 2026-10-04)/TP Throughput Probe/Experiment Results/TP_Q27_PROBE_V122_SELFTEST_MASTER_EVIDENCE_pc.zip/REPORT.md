# TP-Q27-THROUGHPUT-PROBE-v1.2.2-MASTER — SELFTEST_CPU — 20260916T063429Z

comparison_valid: **True** | anchor: `{"expected_sec_per_token_per_seq": 0.16, "expected_agg_tps_at_8": 50.0, "anchor_output_tokens": 4096, "measured_sec_per_token_per_seq": 0.179756713867274, "measured_agg_tps_at_8": 44.50459639525296, "ratio_speed": 0.8900919279050592, "pass": true}` | drift: `{"start_tps": 30.875551029322487, "end_tps": 29.465590866532555, "ratio": 0.9543340890839197, "bounds": [0.8, 1.2], "pass": true}`

Cache verification: `{"C5_noAR_prefix64": {"extension_ratio": 0.506833860677421, "agent_turn_ratio": 0.6882225433526011, "verified": true}}`

## Leaders (numerics-safe unless marked raw)

`{
  "tp4_numerics_safe": {
    "config": "C5_noAR_prefix64",
    "agg_tps": 185.40648196021252,
    "n": 32,
    "mixed_tps": 113.4429948815516,
    "stability_cv": null,
    "numerics_exact": true
  },
  "tp2_single_numerics_safe": {
    "config": "T2_tp2_AR",
    "agg_tps": 84.1199037226444,
    "n": 64,
    "mixed_tps": 48.91582656395424,
    "stability_cv": 0.011034043268131424,
    "numerics_exact": true
  },
  "tp2x2_safe": {
    "config": "T3_tp2x2_pair_noAR_p01_23",
    "agg_tps": 152.07036223856224,
    "n": 64,
    "mixed_tps": null,
    "stability_cv": null,
    "numerics_exact": null
  },
  "single_engine_numerics_safe": {
    "config": "C5_noAR_prefix64",
    "agg_tps": 185.40648196021252,
    "n": 32,
    "mixed_tps": 113.4429948815516,
    "stability_cv": null,
    "numerics_exact": true
  },
  "prefix_extension": {
    "config": "C5_noAR_prefix64",
    "wall_speedup": 0.24789226979391832,
    "new_suffix_tps": 678.795582725292
  },
  "memory_capacity": null,
  "raw_throughput_including_experimental": {
    "config": "C5_noAR_prefix64",
    "agg_tps": 185.40648196021252,
    "n": 32,
    "mixed_tps": 113.4429948815516,
    "stability_cv": null,
    "numerics_exact": true
  }
}`

Next solver-smoke candidates: `{"tp4_engine": "C5_noAR_prefix64", "tp2_single": "T2_tp2_AR", "tp2x2_topology": "T3_tp2x2_pair_noAR_p01_23"}`

## Measurement files

- `analysis/summary_table.csv` — per-config aggregate view
- `analysis/phase_metrics.csv` — every physical phase, prompt balance, energy estimate
- `analysis/pairwise_effects.csv` — one-variable deltas
- `analysis/stability.json` — repeated-wave jitter/CV
- `analysis/gpu_health.csv` — thermal/clock/utilization summary
- `analysis/runtime_health.csv` — preemption/error/reclaim/timeout evidence
- `analysis/topology_pairings.csv` — TP2×2 perfect-matching sweep evidence
- `measurement/batch_plan*.json` — balanced prompt assignment evidence
- `environment/*` — driver/GPU topology/CPU/RAM/disk/pip/runtime evidence

## Guardrails

- Real chat-template rendering is fail-closed.
- No solver candidate is emitted if the C0 long anchor fails.
- Single-engine candidates require greedy-fingerprint prefix agreement >= NUMERICS_MIN_PREFIX_AGREEMENT vs C0 (exactness reported separately).
- MTP is measured but excluded from direct solver promotion.
- Raw fixed-length throughput, mixed-length throughput, multi-turn prefix reuse, stability, memory and energy are reported separately.

## What this does not prove

Solve quality, final ARC score, leaderboard method attribution, or real multi-turn solver wall-clock. Those require the next real solver smoke.