# TP-Q27-THROUGHPUT-PROBE-v1.0 — SELFTEST_CPU — run 20260915T190534Z

Model: `C:\Users\hp\AppData\Local\Temp\claude\d--ARC-AGI-2\1c6db7aa-c78b-4b3a-b97a-5c67187fe52f\scratchpad\fake_input\models\foysalemonshanto\qwen3-8-27b-fp8-repacked-v1\pytorch\hf-fp8\1` (fingerprint 443b56c49ad7a50f) | runtime {'vllm': None, 'transformers': None, 'tokenizers': '0.23.2', 'huggingface-hub': '1.31.0', 'python': '3.14.6'} | fake_engine=True

Output tokens per sequence: 64 (ignore_eos) | prompt pool 16 tasks, prompt tokens min/median/p90/max = 291/3792/8915/21795

## Ladder

| config | status | load s | KV tokens | max conc | best n | agg tok/s | per-seq tok/s | prefill cold tok/s | warm/cold | peak GPU MiB | numerics vs C0 | error |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| C0_frozen_q1 | ok | 277.0 | - | - | 16 | 55.6 | 3.47 | 13499.1 | 1.01 | - | 1.00 (4/4 identical) |  |
| C1_cudagraph | ok | 367.0 | - | - | 16 | 94.1 | 5.88 | 13831.2 | 1.01 | - | 1.00 (4/4 identical) |  |
| C2_cudagraph_customAR | ok | 367.0 | - | - | 16 | 96.0 | 6.00 | 13579.0 | 1.02 | - | 1.00 (4/4 identical) |  |
| C3_mns64 | ok | 367.0 | - | - | 64 | 132.2 | 2.07 | 13986.1 | 0.99 | - | 1.00 (4/4 identical) |  |
| C4_mns128 | ok | 367.0 | - | - | 128 | 133.3 | 1.04 | 13995.2 | 0.98 | - | 1.00 (4/4 identical) |  |
| C5_mns64_prefix | ok | 367.0 | - | - | 32 | 165.6 | 5.17 | 110774.9 | 0.93 | - | 1.00 (4/4 identical) |  |
| C6_mns64_prefix_align | ok | 367.0 | - | - | 32 | 190.5 | 5.95 | 109819.5 | 1.00 | - | 1.00 (4/4 identical) |  |
| C7_mns128_kvfp8 | ok | 367.0 | - | - | 128 | 135.4 | 1.06 | 13827.5 | 1.00 | - | 1.00 (4/4 identical) |  |
| ZZ_fake_fail | failed | - | - | - | - | - | - | - | - | - | - | RuntimeError: selftest: simulated engine init failure (CUDA OOM during graph cap |
| ZZ_fake_hang | timeout | - | - | - | - | - | - | - | - | - | - |  |
| ZZ_fake_skip | skipped_deadline | - | - | - | - | - | - | - | - | - | - | projected 16666666.7 min (+0.0 min reserved for required configs) > remaining 29 |

## Per-point detail

- **C0_frozen_q1**: n=8: agg 36.7 tok/s (decode-only est 45.2), per-seq 4.59 tok/s, wall 14s; n=16: agg 55.6 tok/s (decode-only est 84.5), per-seq 3.47 tok/s, wall 18s (prompts repeated)
- **C1_cudagraph**: n=8: agg 72.9 tok/s (decode-only est 114.5), per-seq 9.12 tok/s, wall 7s; n=16: agg 94.1 tok/s (decode-only est 217.1), per-seq 5.88 tok/s, wall 11s (prompts repeated)
- **C2_cudagraph_customAR**: n=8: agg 74.7 tok/s (decode-only est 120.2), per-seq 9.34 tok/s, wall 7s; n=16: agg 96.0 tok/s (decode-only est 233.6), per-seq 6.00 tok/s, wall 11s (prompts repeated)
- **C3_mns64**: n=16: agg 97.7 tok/s (decode-only est 233.6), per-seq 6.10 tok/s, wall 10s (prompts repeated); n=32: agg 117.9 tok/s (decode-only est 395.5), per-seq 3.68 tok/s, wall 17s (prompts repeated); n=64: agg 132.2 tok/s (decode-only est 621.8), per-seq 2.07 tok/s, wall 31s (prompts repeated)
- **C4_mns128**: n=64: agg 127.3 tok/s (decode-only est 526.0), per-seq 1.99 tok/s, wall 32s (prompts repeated); n=128: agg 133.3 tok/s (decode-only est 645.7), per-seq 1.04 tok/s, wall 61s (prompts repeated)
- **C5_mns64_prefix**: n=32: agg 165.6 tok/s (decode-only est 189.1), per-seq 5.17 tok/s, wall 12s (prompts repeated)
- **C6_mns64_prefix_align**: n=32: agg 190.5 tok/s (decode-only est 222.6), per-seq 5.95 tok/s, wall 11s (prompts repeated)
- **C7_mns128_kvfp8**: n=64: agg 126.6 tok/s (decode-only est 532.9), per-seq 1.98 tok/s, wall 32s (prompts repeated); n=128: agg 135.4 tok/s (decode-only est -), per-seq 1.06 tok/s, wall 60s (prompts repeated)

## Anchor check

`{"expected_agg_tps_at_8": 51.0, "expected_sec_per_token": 0.16, "measured_agg_tps_at_8": 36.723516385431786, "ratio": 0.7200689487339565, "pass": true}`

## Verdict

- best config: **C6_mns64_prefix_align** at n=32: **190.5 tok/s aggregate**, 5.95 tok/s per sequence
- speed-up vs frozen Q1 engine: 3.43x | target 300 tok/s met: **False**
- recommended overrides: `{"disable_custom_all_reduce": false, "enable_prefix_caching": true, "enforce_eager": false, "mamba_cache_mode": "align", "max_num_seqs": 64}`
- prefix caching: `{"C5_mns64_prefix": {"status": "ok", "warm_over_cold": 0.9255804941626399, "unsupported": []}, "C6_mns64_prefix_align": {"status": "ok", "warm_over_cold": 1.0047338256014875, "unsupported": []}}`

## Projection (generation-only hours at best aggregate tok/s)

| set | K samples/task | tokens/sample | total tokens | hours @best | hours @frozen Q1 |
|---|---|---|---|---|---|
| public_eval_120 | 1 | 8192 | 983,040 | 1.43 | 4.91 |
| public_eval_120 | 1 | 12288 | 1,474,560 | 2.15 | 7.37 |
| public_eval_120 | 2 | 8192 | 1,966,080 | 2.87 | 9.83 |
| public_eval_120 | 2 | 12288 | 2,949,120 | 4.30 | 14.74 |
| public_eval_120 | 4 | 8192 | 3,932,160 | 5.73 | 19.66 |
| public_eval_120 | 4 | 12288 | 5,898,240 | 8.60 | 29.49 |
| public_eval_120 | 8 | 8192 | 7,864,320 | 11.47 | 39.32 |
| public_eval_120 | 8 | 12288 | 11,796,480 | 17.20 | 58.98 |
| public_eval_120 | 16 | 8192 | 15,728,640 | 22.94 | 78.64 |
| public_eval_120 | 16 | 12288 | 23,592,960 | 34.41 | 117.96 |
| hidden_test_240 | 1 | 8192 | 1,966,080 | 2.87 | 9.83 |
| hidden_test_240 | 1 | 12288 | 2,949,120 | 4.30 | 14.74 |
| hidden_test_240 | 2 | 8192 | 3,932,160 | 5.73 | 19.66 |
| hidden_test_240 | 2 | 12288 | 5,898,240 | 8.60 | 29.49 |
| hidden_test_240 | 4 | 8192 | 7,864,320 | 11.47 | 39.32 |
| hidden_test_240 | 4 | 12288 | 11,796,480 | 17.20 | 58.98 |
| hidden_test_240 | 8 | 8192 | 15,728,640 | 22.94 | 78.64 |
| hidden_test_240 | 8 | 12288 | 23,592,960 | 34.41 | 117.96 |
| hidden_test_240 | 16 | 8192 | 31,457,280 | 45.88 | 157.28 |
| hidden_test_240 | 16 | 12288 | 47,185,920 | 68.82 | 235.92 |

## What this run does NOT measure

- Solve quality: outputs are ignore_eos token streams, never parsed. Engine flags do not change the model's policy; the greedy fingerprint column shows how far kernel numerics drift.
- Multi-turn agent wall-clock (tool execution, verifier) — only generation and prefill.
- Anything about which decode point is *needed*: that comes from the sampling recipe (K samples/task), see projection table.