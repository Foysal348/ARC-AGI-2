
# tp_worker.py -- measure one vLLM engine configuration. Written by the TP-Q27 probe notebook.
import argparse, json, os, sys, time, random, traceback, dataclasses

class Unsupported(Exception):
    pass

def read_json(p):
    with open(p, "r", encoding="utf-8") as f:
        return json.load(f)

class FakeEngine:
    """CPU stand-in with a plausible speed model; only for SELFTEST_CPU."""
    def __init__(self, spec, result):
        kw = dict(spec["engine_kwargs"])
        name = spec["name"]
        if "fake_fail" in name:
            raise RuntimeError("selftest: simulated engine init failure (CUDA OOM during graph capture)")
        if "fake_hang" in name:
            time.sleep(3600)
        self.scale = float(spec.get("fake_time_scale", 1.0))
        base = 6.25
        if not kw.get("enforce_eager", True):
            base *= 2.6
        if not kw.get("disable_custom_all_reduce", True):
            base *= 1.08
        if kw.get("kv_cache_dtype") == "fp8":
            base *= 0.97
        self.base = base
        self.prefix = bool(kw.get("enable_prefix_caching"))
        self.seen = set()
        time.sleep(0.3 * 1.0)
        result["engine_kwargs_used"] = kw
        result["load_sec"] = 277.0 + (90.0 if not kw.get("enforce_eager", True) else 0.0)
        result["fake"] = True

    def generate(self, prompts, sp):
        n = len(prompts)
        mt = int(sp["max_tokens"])
        per_seq = self.base / (1.0 + 0.012 * n)
        prefill = 0.0
        for p in prompts:
            h = hash(p)
            rate = 40000.0 if (self.prefix and h in self.seen) else 4000.0
            prefill += (len(p) / 4.0) / rate
            self.seen.add(h)
        time.sleep((prefill + mt / per_seq) / self.scale)
        rng = random.Random(int(sp.get("seed", 0)) + n)
        outs = []
        for p in prompts:
            if float(sp.get("temperature", 1.0)) > 0:
                ids = [rng.randrange(1000, 50000) for _ in range(mt)]
            else:
                ids = [(i * 7919 + len(p)) % 50000 for i in range(mt)]
            outs.append({"prompt_token_ids": [0] * (len(p) // 4), "token_ids": ids})
        return outs

class RealEngine:
    def __init__(self, spec, result):
        import inspect
        import vllm
        from vllm import LLM, SamplingParams
        from vllm.engine.arg_utils import EngineArgs
        self.SamplingParams = SamplingParams
        result["runtime"] = {"vllm": getattr(vllm, "__version__", None)}
        valid = {f.name for f in dataclasses.fields(EngineArgs)} | set(inspect.signature(LLM.__init__).parameters)
        valid.discard("kwargs"); valid.discard("self")
        kw = dict(spec["engine_kwargs"])
        overrides = dict(spec.get("overrides", {}))
        # The Q1-frozen base kwargs are known-good on this stack; only the ladder's override keys can be
        # unsupported. A rejected override is a distinct outcome ("unsupported"), not an engine failure.
        unsupported = sorted(k for k in overrides if k not in valid)
        result["unsupported_kwargs"] = unsupported
        result["base_kwargs_not_in_signature"] = sorted(k for k in kw if k not in valid and k not in overrides)
        if unsupported:
            raise Unsupported("engine kwargs not accepted by this vLLM build: %s" % unsupported)
        result["engine_kwargs_used"] = kw
        t0 = time.perf_counter()
        try:
            self.llm = LLM(**kw)
        except Exception as e:
            msg = "%s: %s" % (type(e).__name__, e)
            if overrides and any(k in msg for k in overrides):
                result["unsupported_kwargs"] = sorted(k for k in overrides if k in msg)
                raise Unsupported(msg)
            raise
        result["load_sec"] = time.perf_counter() - t0

    def generate(self, prompts, sp):
        params = self.SamplingParams(**sp)
        outs = self.llm.generate(prompts, params, use_tqdm=False)
        return [{"prompt_token_ids": list(getattr(o, "prompt_token_ids", None) or []),
                 "token_ids": list(o.outputs[0].token_ids)} for o in outs]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--spec", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--fake", action="store_true")
    a = ap.parse_args()
    spec = read_json(a.spec)
    scale = float(spec.get("fake_time_scale", 1.0)) if a.fake else 1.0
    result = {"config": spec["name"], "status": "started", "phases": [], "timeline": [], "error": None,
              "engine_kwargs_used": None, "unsupported_kwargs": [], "load_sec": None, "fingerprint": None,
              "worker_pid": os.getpid(), "started_epoch": time.time()}

    def dump():
        tmp = a.out + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(result, f, indent=2, sort_keys=True, default=str)
        os.replace(tmp, a.out)

    def mark(event):
        result["timeline"].append({"event": event, "epoch": time.time()})
        dump()

    dump()
    pool = read_json(spec["prompts_path"])
    texts = [r["prompt"] for r in pool]
    ptoks = [int(r["prompt_tokens"]) for r in pool]
    out_tokens = int(spec["output_tokens"])
    seed = int(spec["seed"])
    engine = None

    def wave(name, idx, sp, note=None):
        ts = [texts[i % len(texts)] for i in idx]
        pt_expected = sum(ptoks[i % len(ptoks)] for i in idx)
        mark("phase_start:" + name)
        t0 = time.perf_counter()
        outs = engine.generate(ts, sp)
        wall = (time.perf_counter() - t0) * scale
        mark("phase_end:" + name)
        ot = [len(o["token_ids"]) for o in outs]
        pe = [len(o["prompt_token_ids"]) for o in outs]
        ph = {"phase": name, "n": len(ts), "wall_sec": wall, "max_tokens": int(sp["max_tokens"]),
              "out_tokens_total": sum(ot), "out_tokens_min": min(ot), "out_tokens_max": max(ot),
              "all_reached_max_tokens": all(t == int(sp["max_tokens"]) for t in ot),
              "prompt_tokens_total_tokenizer": pt_expected,
              "prompt_tokens_total_engine": (sum(pe) if all(pe) else None),
              "prompts_repeated": (max(idx) >= len(texts)) if idx else False,
              "prompt_index_range": [min(idx), max(idx)] if idx else None,
              "agg_gen_tps": sum(ot) / wall if wall > 0 else None,
              "per_seq_gen_tps": (sum(ot) / len(ot)) / wall if wall > 0 else None,
              "sec_per_output_token_per_seq": wall / max(1, int(sp["max_tokens"])),
              "prefill_tps": pt_expected / wall if wall > 0 else None,
              "note": note}
        result["phases"].append(ph)
        dump()
        return outs

    try:
        mark("load_start")
        engine = FakeEngine(spec, result) if a.fake else RealEngine(spec, result)
        mark("load_end")
        dump()
        max_seqs = int(spec["engine_kwargs"].get("max_num_seqs", 16))
        base_sp = {"temperature": 1.0, "top_p": 0.95, "top_k": 20, "seed": seed, "ignore_eos": True}
        pool_len = len(texts)
        # warmup (also validates generate() on this engine)
        n_warm = min(int(spec["warmup_prompts"]), pool_len)
        wave("warmup", list(range(n_warm)), dict(base_sp, max_tokens=16))
        # decode capacity points. Each point takes the NEXT slice of the pool so that, with prefix
        # caching on, a later point does not re-prefill prompts an earlier point already cached.
        # (Slices wrap and are flagged 'prompts_repeated' when the pool is smaller than the demand.)
        start = n_warm
        for n in sorted(int(x) for x in spec["decode_points"]):
            if n > max_seqs:
                result["phases"].append({"phase": "decode@%d" % n, "n": n, "skipped": "n > max_num_seqs=%d" % max_seqs})
                dump()
                continue
            idx = [start + j for j in range(n)]
            wave("decode@%d" % n, idx, dict(base_sp, max_tokens=out_tokens),
                 note=("pool slice wraps (prompts reused across points)" if start + n > pool_len else None))
            start += n
        # prefill cold vs warm: prompts NOT used by any decode point when the pool allows it, otherwise
        # flagged (a prefix-caching engine would already hold them, making 'cold' warm).
        k = min(int(spec["prefill_prompts"]), pool_len, max_seqs)
        fresh = pool_len - min(start, pool_len)
        if fresh >= max(4, k // 2):
            k = min(k, fresh)
            pre_idx = list(range(pool_len - k, pool_len))
            overlap_note = None
        else:
            pre_idx = list(range(k))
            overlap_note = "prefill prompts overlap decode prompts (pool too small); cold may already be cached"
        pre_sp = {"temperature": 0.0, "max_tokens": 1, "ignore_eos": True}
        wave("prefill_cold", pre_idx, pre_sp, note=overlap_note)
        wave("prefill_warm", pre_idx, pre_sp, note="identical prompts re-sent" + ("; " + overlap_note if overlap_note else ""))
        # greedy fingerprint for cross-config numerics comparison
        fk = min(int(spec["fingerprint_prompts"]), len(texts))
        fp_sp = {"temperature": 0.0, "max_tokens": int(spec["fingerprint_tokens"]), "ignore_eos": True, "seed": seed}
        outs = wave("fingerprint", list(range(fk)), fp_sp)
        result["fingerprint"] = [o["token_ids"] for o in outs]
        result["status"] = "ok"
    except Unsupported as e:
        result["status"] = "unsupported"
        result["error"] = str(e)
    except BaseException as e:
        result["status"] = "failed"
        result["error"] = "%s: %s" % (type(e).__name__, e)
        result["traceback"] = traceback.format_exc()
    result["finished_epoch"] = time.time()
    dump()
    code = 0 if result["status"] in ("ok", "unsupported") else 3
    print("TP_WORKER_DONE status=%s config=%s" % (result["status"], spec["name"]), flush=True)
    # Prefer a clean exit (vLLM's atexit hooks shut the TP workers down); if that hangs, hard-exit
    # after 90 s. The parent reclaims any GPU process that survives either path.
    import threading
    threading.Thread(target=lambda: (time.sleep(90.0), os._exit(code)), daemon=True).start()
    engine = None
    import gc
    gc.collect()
    sys.stdout.flush(); sys.stderr.flush()
    sys.exit(code)

if __name__ == "__main__":
    main()
