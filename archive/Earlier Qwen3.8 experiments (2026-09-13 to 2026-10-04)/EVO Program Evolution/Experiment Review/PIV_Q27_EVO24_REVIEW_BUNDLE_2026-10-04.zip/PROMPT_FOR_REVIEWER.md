# Prompt for the reviewer — paste this as your first message, with the zip attached

You are reviewing **PIV-Q27-EVO24**, a Kaggle notebook that has **not run on GPU yet**. Find anything that would make the
run fail, waste GPU quota, or produce a misleading measurement. Separate **confirmed defects** (file/line + concrete
failure scenario) from concerns and suggestions. Do not recommend switching away from Qwen3.8-27B for this run.

## Context

* Kaggle "ARC Prize 2026 - ARC-AGI-2", 4×L4 (96 GB), offline, 12 h limit; 4×L4 burns 2 quota-hours per wall-hour,
  ~15 4×L4-hours per week per account. Deadline 2026-11-02.
* Team LB 32.64 (NVARC-style pipeline). Our Qwen3.8-27B-FP8 REPL agent (PIV) scored 1.67 % on the 120 public
  evaluation tasks and 1.67 public LB. A 12-task follow-up (V3.1-S12) fixed the plumbing (0 zero-tool tasks, 0 truncated
  finalizers) but solved nothing new; its "near misses" turned out to be at the level of returning the input unchanged
  (`docs/PIV_Q27_V31_S12_RESULT_2026-10-04.md`).
* Public evidence that verified-program search helps a lot: Imbue code evolution (Kimi K2.5 12.1 → 34.0 % on
  ARC-AGI-2), PiVOTools stateful REPL (GPT-OSS-120B 6.11 → 26.38 %), Symbolica Agentica.
* Plan agreed with the team: first test **evolution with the same model** on a frozen 24-task subset, then an A/B with
  ThinkingCap-Qwen3.8-27B (shorter reasoning) on the same tasks. `docs/EXPERIMENT_PLAN.md` has the full order.

## What EVO24 does

* Cells 1–7 are the V3.1 notebook's tested infrastructure, unchanged: config, data, tokenizer/chat template, safety
  guard, fresh subprocess verifier, preloaded helper library, vLLM 0.19 TP=4 model load.
  Only edits: `EXPERIMENT_ID`, bundle name, and a frozen 24-task subset
  (`random.Random(20261004).sample(sorted(eval ids), 24)`; 16 NVARC misses, 7 NVARC full solves, 1 partial).
* Cell 8 (new, `build/cell_evo.py`): per task
  1. **4 independent candidates** (different "lens" hint each): the model writes `## Rule` in plain words and a
     `solution(grid)` in one python block;
  2. each candidate is verified in a fresh process on every training pair (test inputs executed only when all training
     pairs are exact);
  3. ranking by the near-miss-aware quality tuple from V3.1 (`_v3_train_quality`);
  4. **2 repair generations**: the 2 best candidates with different training outputs are sent back with the verifier
     report and their own wrong grids (wrong cells marked `*`); a task stops as soon as one candidate is train-exact and
     runs on the test input(s);
  5. **pass@2**: up to two train-exact candidates with different test outputs.
  Generation is two-phase per call: phase 1 thinks until `</think>` or 3,072 tokens (stop on the `</think>` token id);
  phase 2 continues token-exactly (forced close with Qwen's documented stop-thinking text if needed) and writes the
  answer (≤2,048 tokens). Aggregate cap 32,768 generated tokens per task. Seeds are deterministic per (task, round, slot).
* Cell 9 (new, `build/cell_report.py`): strict pass@2 scoring against the public solutions, complementarity with the
  frozen NVARC per-task map (EVOLUTION_ONLY / BOTH / NVARC_ONLY), pre-registered verdict
  (STRONG GO: ≥5 solved and ≥3 on NVARC misses; PROMISING: ≥3 solved or ≥2 on NVARC misses; else WEAK), bundle zip.
* `build/make_evo24.py` builds the notebook from `notebooks/PIV-Q27-V3_1-EVAL120-ALLFIX.ipynb` (included).

## Local harness (fake vLLM, real tokenizer/template/data, real subprocess verifier)

`harness_logs/h_normal.txt`: all scripted paths ran — solved in round 0 (task stops), solved by repair, forced think
close, answers without code / with syntax error / raising, strict-correct pass@2 classified as BOTH. `h_deadline.txt`:
deadline stop after round 0, report and bundle still written. The harness caught one real bug that is fixed: cell 7's
`deadline` is on the `perf_counter` clock, the first draft compared it with `time.time()` (every run would have stopped
after round 0). The harness cannot show model quality or real throughput.

## What I want from you

1. **Correctness** of cell 8: two-phase generation and token-exact continuation (stop_token_ids, the `</think>` id,
   forced close), parsing of rule/code, verification, parent selection, early stop, budget accounting, deadline check
   (note there is none before round 0), pass@2 selection, record logging.
2. **Measurement integrity** of cell 9: strict scoring, NVARC classification, anything that inflates or deflates the
   result; is the 24-task design and the verdict rule sound for a go/no-go decision?
3. **Prompt quality**: `evo_initial_prompt` and `evo_repair_prompt` (see `build/cell_evo.py`). Will Qwen3.8 at
   reasoning_effort "medium" with a 3,072-token thinking budget produce usable rules and code? Should the budget,
   effort, organism count or repair depth be different for the first run?
4. **Runtime/quota**: my estimate is 1.2–1.7 h wall (2.5–3.5 quota-hours) with `max_num_seqs` 16. Is that sound? Any
   path that can run away?
5. Anything to fix **before** the run versus things that can wait.

## Map of the zip

```
PROMPT_FOR_REVIEWER.md
notebooks/PIV-Q27-EVO24-EVOLUTION.ipynb      the notebook under review
notebooks/PIV-Q27-V3_1-EVAL120-ALLFIX.ipynb  base notebook (cells 1-7 come from here)
build/make_evo24.py, cell_evo.py, cell_report.py, piv_library.py
harness/harness_c1.py                         fake-engine harness incl. the EVO scenario
harness_logs/h_normal.txt, h_deadline.txt
docs/EXPERIMENT_PLAN.md, CANONICAL_BASELINE_EVAL120_2026-10-03.md, PIV_Q27_V31_S12_RESULT_2026-10-04.md
posthoc/nvarc_eval120_frozen.json
SHA256SUMS.txt
```
