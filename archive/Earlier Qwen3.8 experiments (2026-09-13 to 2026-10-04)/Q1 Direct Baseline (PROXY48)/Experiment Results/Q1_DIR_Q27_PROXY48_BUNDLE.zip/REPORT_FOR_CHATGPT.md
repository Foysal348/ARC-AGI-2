# Q1-DIR-Q27-PROXY48 — Qwen3.8-27B Direct Baseline Results

Run ID: `20260913T134749Z`
Run profile: **PROXY48** | Task set: **PROXY48**
Proxy-48 SHA256: `8f432c60a35091dcda2b890574b1f4d3c03aaf48a5b3b7f96b4e88c35d359134`
Accuracy interpretable: **True**
Active tasks: **48**
Run status: **COMPLETE**

## Primary output-weighted result

- Thinking OFF raw exact: **0.00%**
- Thinking XHIGH raw exact: **0.00%**
- OFF ∪ XHIGH pass@2: **0.00%**

## Coverage / complementarity

- OFF-only correct outputs: **0**
- XHIGH-only correct outputs: **0**
- Both correct: **0**
- Neither correct: **56**
- Identical valid OFF/XHIGH outputs: **0.00%**
- Candidate registry rows: **112** | exact-grid clusters: **31**
- Ignored stale/incompatible checkpoint rows: **0**
- Ignored foreign checkpoint rows: **0**
- off exact compatible coverage: **48/48** | missing=0 | extra_raw=0
- xhigh exact compatible coverage: **48/48** | missing=0 | extra_raw=0

## Interface / compute

`explicit-<think> tokens` counts only text inside literal `<think>...</think>` tags. Qwen3.8 may emit visible untagged reasoning in this vLLM/template path; zero therefore does NOT mean no reasoning.
- off: parse-valid=60.42%, length-limit=37.50%, avg generated=2217.5, avg explicit-<think> tokens=0.0 tokens
- xhigh: parse-valid=0.00%, length-limit=100.00%, avg generated=12288.0, avg explicit-<think> tokens=0.0 tokens
- Model load: 275.0s | total elapsed: 233.5 min

## Frozen source context (not current Q1 results)

- NVARC diagnostic: GT present in 55/172 output pools (32.0%); current dual 33.50 vs pool oracle 41.17.
- NVARC diagnostic: average raw duplicate ratio 37.8%; scorer rank correlation 0.961 on GT-present cases.
- Therefore Q1 saves canonical candidates, exact-grid clusters and provenance for later NVARC∪Qwen oracle analysis; it does not alter NVARC.

## Promotion gate

Promote beyond Q1 only after checking: valid-grid/parse reliability, truncation, OFF-vs-XHIGH unique coverage, source-EDA slice behavior, tokens/wall-clock, and later offline NVARC union/oracle coverage from saved candidates.
The next causal comparison after a usable direct branch is PIV-Q27-P0 (stateful REPL) vs PTQ-Q27-T0 (fresh-call deterministic repair) under matched budgets.

## Files to upload/analyze

- `raw_generations.jsonl`
- `current_generation_records.jsonl`
- `current_compatible_generations.jsonl`
- `checkpoint_audit.json`
- `checkpoint_contract_selftest.json`
- `candidate_registry.jsonl`
- `candidate_clusters.jsonl`
- `task_output_scores.csv`
- `category_scores.csv`
- `generation_diagnostics.csv`
- `correctness_overlap.json`
- `predictions_union_off_xhigh.json`
- `proxy48_source_eda.csv`
- `SOURCE_ALIGNMENT.json`
- `run_metadata.json`