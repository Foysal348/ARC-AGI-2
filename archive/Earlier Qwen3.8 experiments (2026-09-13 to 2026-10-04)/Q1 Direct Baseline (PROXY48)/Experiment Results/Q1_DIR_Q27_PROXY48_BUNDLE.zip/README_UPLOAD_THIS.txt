Q1-DIR-Q27-PROXY48
Run profile: PROXY48
Upload this bundle back to ChatGPT after Kaggle Run All:
/kaggle/working/Q1_DIR_Q27_PROXY48_BUNDLE.zip

PREFLIGHT accuracy is synthetic. SMOKE_GPU is runtime-only. PROXY48 is the Q1 research run.
