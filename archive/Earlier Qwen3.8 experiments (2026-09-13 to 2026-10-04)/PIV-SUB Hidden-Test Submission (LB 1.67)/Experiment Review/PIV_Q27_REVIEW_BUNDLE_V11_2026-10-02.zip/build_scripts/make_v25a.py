"""Build PIV-Q27-C1 v2.5A from v2.5 by applying exactly the four audited fixes."""
import hashlib
import json
import os
from pathlib import Path

# Project root; override with PIV_PROJECT_ROOT on another machine.
PROJECT_ROOT = Path(os.environ.get("PIV_PROJECT_ROOT", r"D:\ARC AGI 2"))
SRC = PROJECT_ROOT / (r"Research Base Experiment\PIV-Q27-C1-v2_5-CANDIDATE-FIRST-VERIFIER-FEEDBACK-REPAIR.ipynb")
DST = PROJECT_ROOT / (r"Research Base Experiment\PIV-Q27-C1-v2_5A-CANDIDATE-FIRST-VERIFIER-FEEDBACK-REPAIR.ipynb")

nb = json.loads(SRC.read_text(encoding="utf-8"))
cells = nb["cells"]


def code_cell(pred):
    hits = [c for c in cells if c["cell_type"] == "code" and pred("".join(c["source"]))]
    assert len(hits) == 1, (pred, len(hits))
    return hits[0]


def edit(cell, old, new, count=1):
    s = "".join(cell["source"])
    assert s.count(old) == count, (old[:80], s.count(old))
    s = s.replace(old, new)
    cell["source"] = s.splitlines(keepends=True)


# ---------------------------------------------------------------- P1-1: pre-register the shared repair budget
c1 = code_cell(lambda s: "REPAIR_SEED_OFFSET = 3_000_000" in s)
edit(c1, """REPAIR_POLICY_ENABLED = True""", '''REPAIR_POLICY_ENABLED = True
# v2.5A PRE-REGISTRATION (measured on the frozen v2.4G run 20260918T104631Z, not a bug):
# the repair round draws from the SAME TOTAL_GENERATED_TOKEN_CAP as exploration, so its cap is
# min(REPAIR_MAX_TOKENS, leftover budget, context headroom). Observed leftovers were 1,229-8,839 (ACT-LOW)
# and 2,175-4,315 (ACT-BUDGET3072). For ACT-LOW 271d71e2 / 2c181942 / 16b78196 the leftover (1,841 / 1,229 /
# 1,305) is SMALLER than candidate #1's own JSON size (2,254 / 2,866 / 2,790), so those repairs cannot even
# re-emit a program of the same length and are expected to end as repair_output_parse_failed (finish=length).
# Read any "repair helped k/N" result against this ceiling; a separate repair budget is a future decision.
REPAIR_BUDGET_PREREGISTRATION = {
    "repair_shares_total_generated_token_cap": True,
    "cap_formula": "min(REPAIR_MAX_TOKENS, TOTAL_GENERATED_TOKEN_CAP - generated_tokens, MAX_MODEL_LEN - prompt_tokens - CONTEXT_SAFETY_TOKENS)",
    "v24g_leftover_tokens": {"ACT-LOW": [1229, 1305, 1841, 2403, 2888, 3107, 3256, 8839],
                             "ACT-BUDGET3072": [2175, 2299, 2661, 2728, 2788, 2946, 3425, 4315]},
    "v24g_expected_structural_truncations": ["ACT-LOW/271d71e2", "ACT-LOW/2c181942", "ACT-LOW/16b78196"],
}''')

# ---------------------------------------------------------------- P0-2: module-level sampling-param factories
c_sched = code_cell(lambda s: "def run_real_piv():" in s)
nested = '''    def _mk_params(cap, seed):
        return SamplingParams(
            temperature=PIV_SAMPLING["temperature"], top_p=PIV_SAMPLING["top_p"], top_k=PIV_SAMPLING["top_k"],
            min_p=PIV_SAMPLING["min_p"], presence_penalty=PIV_SAMPLING["presence_penalty"],
            repetition_penalty=PIV_SAMPLING["repetition_penalty"], max_tokens=int(cap), ignore_eos=False,
            seed=int(seed), skip_special_tokens=False, spaces_between_special_tokens=False)

    def _mk_finalizer_params(cap, seed):
        if StructuredOutputsParams is None:
            raise RuntimeError("StructuredOutputsParams unavailable in real terminal-pilot profile")
        _so=StructuredOutputsParams(json=FINALIZER_JSON_SCHEMA)
        return SamplingParams(
            temperature=FINALIZER_SAMPLING["temperature"], top_p=FINALIZER_SAMPLING["top_p"],
            top_k=FINALIZER_SAMPLING["top_k"], min_p=FINALIZER_SAMPLING["min_p"],
            presence_penalty=FINALIZER_SAMPLING["presence_penalty"],
            repetition_penalty=FINALIZER_SAMPLING["repetition_penalty"], max_tokens=int(cap), ignore_eos=False,
            seed=int(seed), skip_special_tokens=False, spaces_between_special_tokens=False,
            structured_outputs=_so)

'''
module_level = '''# v2.5A: module-level request factories. CELL 8B (repair round) calls _mk_finalizer_params from module scope,
# so these must not be nested inside run_real_piv().
def _mk_params(cap, seed):
    return SamplingParams(
        temperature=PIV_SAMPLING["temperature"], top_p=PIV_SAMPLING["top_p"], top_k=PIV_SAMPLING["top_k"],
        min_p=PIV_SAMPLING["min_p"], presence_penalty=PIV_SAMPLING["presence_penalty"],
        repetition_penalty=PIV_SAMPLING["repetition_penalty"], max_tokens=int(cap), ignore_eos=False,
        seed=int(seed), skip_special_tokens=False, spaces_between_special_tokens=False)

def _mk_finalizer_params(cap, seed):
    if StructuredOutputsParams is None:
        raise RuntimeError("StructuredOutputsParams unavailable in real terminal-pilot profile")
    _so=StructuredOutputsParams(json=FINALIZER_JSON_SCHEMA)
    return SamplingParams(
        temperature=FINALIZER_SAMPLING["temperature"], top_p=FINALIZER_SAMPLING["top_p"],
        top_k=FINALIZER_SAMPLING["top_k"], min_p=FINALIZER_SAMPLING["min_p"],
        presence_penalty=FINALIZER_SAMPLING["presence_penalty"],
        repetition_penalty=FINALIZER_SAMPLING["repetition_penalty"], max_tokens=int(cap), ignore_eos=False,
        seed=int(seed), skip_special_tokens=False, spaces_between_special_tokens=False,
        structured_outputs=_so)

def run_real_piv():'''
edit(c_sched, nested, "")
edit(c_sched, "def run_real_piv():", module_level)

# ---------------------------------------------------------------- P0-1: correct the repair-helper self-test
c_help = code_cell(lambda s: "def run_v25_repair_helper_selftests():" in s)
edit(c_help, '''    _dim_identity=_v25_pair_diag({"index":1,"exact":False,"pred":fake_task["train"][1]["input"],"error":None},fake_task["train"][1])
    assert _dim_identity["kind"]=="dims_mismatch" and _dim_identity["identity"],_dim_identity''',
     '''    # v2.5A: identity with CHANGED dims is dims_mismatch; identity with SAME dims is cells_wrong. Both must set identity.
    _dim_identity=_v25_pair_diag({"index":0,"exact":False,"pred":[[1,2,3]],"error":None},{"input":[[1,2,3]],"output":[[1],[2],[3]]})
    assert _dim_identity["kind"]=="dims_mismatch" and _dim_identity["identity"],_dim_identity
    _cells_identity=_v25_pair_diag({"index":1,"exact":False,"pred":fake_task["train"][1]["input"],"error":None},fake_task["train"][1])
    assert _cells_identity["kind"]=="cells_wrong" and _cells_identity["identity"],_cells_identity''')

# ---------------------------------------------------------------- P1-2: keep the real verifier error when train is empty
edit(c_help, '''def _v25_feedback_text(verifier, task, max_feedback_tokens=REPAIR_FEEDBACK_MAX_TOKENS):
    train=list((verifier or {}).get("train") or [])
    exact=sum(1 for x in train if x.get("exact"))
    n=len(task.get("train",[]))
    diags=[]''',
     '''def _v25_feedback_bounded(txt, max_feedback_tokens):
    ids=list(tokenizer.encode(txt,add_special_tokens=False))
    truncated=False
    if len(ids)>int(max_feedback_tokens):
        txt=tokenizer.decode(ids[:int(max_feedback_tokens)],skip_special_tokens=False).strip()
        truncated=True
    return txt,len(tokenizer.encode(txt,add_special_tokens=False)),truncated

def _v25_feedback_text(verifier, task, max_feedback_tokens=REPAIR_FEEDBACK_MAX_TOKENS):
    train=list((verifier or {}).get("train") or [])
    exact=sum(1 for x in train if x.get("exact"))
    n=len(task.get("train",[]))
    if not train:
        # v2.5A: train_timeout / train_code_error return no per-pair results. Report the verifier's own error
        # instead of claiming an exception on every pair.
        _vs=str((verifier or {}).get("verifier_status") or "unknown")
        _ve=_v25_exception_last_line((verifier or {}).get("train_error") or (verifier or {}).get("error") or "no verifier error text")
        _txt="\\n".join([f"candidate #1 fresh-train result: 0/{n} exact.",
                        f"VERIFIER: {_vs}; {_ve}",
                        "The verifier returned no per-pair result, so the whole program failed before any pair was scored.",
                        "Return a self-contained program that terminates quickly and avoids the reported failure.",
                        "Repair the standalone solution(grid) program. Do not rely on REPL variables or helper state from exploration."]).strip()
        _txt,_tok,_tr=_v25_feedback_bounded(_txt,max_feedback_tokens)
        return {"text":_txt,"tokens":_tok,"truncated":_tr,"train_exact_count":0,"n_train":int(n),
                "identity_pairs":[],"pair_diags":[],"verifier_level_failure":True}
    diags=[]''')

# self-test coverage for the new branch
edit(c_help, '''    # Failure injection: repair prompt overflow -> no admission.''',
     '''    # v2.5A: verifier-level failure (no per-pair results) must surface the verifier error, not fake exceptions.
    _vl=_v25_feedback_text({"train":[],"all_train_exact":False,"verifier_status":"train_timeout",
                            "train_error":"verifier stage timeout after 20s"},fake_task)
    assert _vl["verifier_level_failure"] and "VERIFIER: train_timeout" in _vl["text"] and "timeout after 20s" in _vl["text"],_vl
    assert "missing verifier pair result" not in _vl["text"],_vl
    # Failure injection: repair prompt overflow -> no admission.''')
edit(c_help, '''             "repair_verifier_timeout_preserves_candidate1":True,"overcap_injection":True}''',
     '''             "repair_verifier_timeout_preserves_candidate1":True,"overcap_injection":True,
             "verifier_level_failure_feedback":True}''')

# ---------------------------------------------------------------- P0-2 guard: fail fast, in every profile
c_rep = code_cell(lambda s: "CELL 8B" in s and "run_v25_repair_round_for_arm" in s)
edit(c_rep, '''REPAIR_ARTIFACT_ROWS=[]''',
     '''# v2.5A interface guard: the repair wave builds finalizer requests at module scope. Assert the factories exist
# in EVERY profile (PREFLIGHT included) so a nesting regression cannot survive until after the scheduler has run.
for _fn in ("_mk_finalizer_params","_mk_params"):
    assert callable(globals().get(_fn)), f"v2.5A: {_fn} must be defined at module level in the scheduler cell"
assert _mk_finalizer_params.__qualname__==_mk_finalizer_params.__name__, _mk_finalizer_params.__qualname__

REPAIR_ARTIFACT_ROWS=[]''')

# ---------------------------------------------------------------- manifest: carry the pre-registration
c_man = code_cell(lambda s: '"v25_repair":{"enabled":REPAIR_POLICY_ENABLED' in s)
edit(c_man, '''"budget_action_reserve_frozen":ACTION_RESERVE_TOKENS},''',
     '''"budget_action_reserve_frozen":ACTION_RESERVE_TOKENS,"budget_preregistration":REPAIR_BUDGET_PREREGISTRATION},''')

# ---------------------------------------------------------------- header / version strings
for c in cells:
    s = "".join(c["source"])
    if c["cell_type"] == "markdown" and "v2.5" in s and "REPAIR" in s.upper():
        s = s.replace("v2.5", "v2.5A", 1)
        c["source"] = s.splitlines(keepends=True)
        break

DST.write_text(json.dumps(nb, indent=1, ensure_ascii=False) + "\n", encoding="utf-8")
print("wrote", DST)
print("sha256", hashlib.sha256(DST.read_bytes()).hexdigest())
