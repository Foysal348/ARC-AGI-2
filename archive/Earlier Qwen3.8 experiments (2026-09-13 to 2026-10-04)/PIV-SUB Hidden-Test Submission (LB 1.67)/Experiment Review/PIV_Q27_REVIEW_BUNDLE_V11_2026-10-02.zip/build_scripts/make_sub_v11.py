"""Build PIV-Q27-SUB-v1.0 (hidden-test submission notebook) from the audited v2.5A solver notebook.

Keeps cells 1..8B (config -> data -> EDA -> prompts -> context -> helpers/verifier -> engine -> scheduler -> repair)
and replaces every scoring/measurement cell with submission machinery:
  * identity-fallback submission.json written before the model is allocated, then rewritten incrementally;
  * the frozen v2.4G adaptive controller reused on the attached test file (pilot -> interface gate -> full sweep);
  * CPU test-execution pass so unverified programs can still fill attempt_2;
  * run report + evidence bundle.
"""
import hashlib
import json
import os
from pathlib import Path

# Project root; override with PIV_PROJECT_ROOT on another machine.
PROJECT_ROOT = Path(os.environ.get("PIV_PROJECT_ROOT", r"D:\ARC AGI 2"))
SRC = PROJECT_ROOT / (r"Research Base Experiment\PIV-Q27-C1-v2_5A-CANDIDATE-FIRST-VERIFIER-FEEDBACK-REPAIR.ipynb")
DST = PROJECT_ROOT / (r"Research Base Experiment\PIV-Q27-SUB-v1_1-HIDDEN-TEST-SUBMISSION.ipynb")

nb = json.loads(SRC.read_text(encoding="utf-8"))
cells = nb["cells"]
code_idx = [i for i, c in enumerate(cells) if c["cell_type"] == "code"]
assert len(code_idx) == 16, len(code_idx)


def edit(i, old, new, count=1):
    c = cells[i]
    s = "".join(c["source"])
    assert s.count(old) == count, (i, old[:70], s.count(old))
    c["source"] = s.replace(old, new).splitlines(keepends=True)


C_CONFIG, C_DATA, C_EDA, C_PROMPT, C_CTX, C_HELP, C_ENGINE, C_SCHED, C_REPAIR = code_idx[:9]

# =====================================================================================
# CELL 1 — profiles, budgets, submission paths
# =====================================================================================
edit(C_CONFIG, 'EXPERIMENT_ID = "PIV-Q27-C1-v2.5"',
     'EXPERIMENT_ID = "PIV-Q27-SUB-v1.1"')
edit(C_CONFIG, 'GENERATION_CONTRACT_VERSION = "piv-q27-c1-candidate-first-repair-v2.5"',
     'GENERATION_CONTRACT_VERSION = "piv-q27-sub-hidden-test-v1.1"')
edit(C_CONFIG, 'RUN_PROFILE = "ADAPTIVE_SMOKE"   # default: one-session real GPU workflow',
     'RUN_PROFILE = "SUBMIT"   # default: full sweep over the attached arc-agi_test_challenges.json')

edit(C_CONFIG, '''    "ADAPTIVE_SMOKE": {''', '''    "SUBMIT_SMOKE": {
        # Interface rehearsal on the first 4 test tasks (~20 min). Never submit this run.
        "use_model": True, "task_set": "TESTALL", "active_tasks": 4,
        "agent_batch_size": 4, "max_tool_calls": 6, "max_model_turns": 12,
        "per_turn_max_tokens": 8192, "total_generated_token_cap": 8192,
        "max_retries": 2,
        "tool_timeout_sec": 10.0, "verifier_timeout_sec": 20.0,
        "bundle_name": "PIV_Q27_SUB_V10_SMOKE_BUNDLE.zip",
        "reset_outputs": True, "accuracy_is_real": True,
    },
    "SUBMIT_FAST": {
        # Same pipeline, half the per-task budget: coverage of every task in roughly a third of the time.
        # Use it when a submission is needed inside one working day; SUBMIT is the better-quality sweep.
        "use_model": True, "task_set": "TESTALL", "active_tasks": 0,
        "agent_batch_size": 12, "max_tool_calls": 4, "max_model_turns": 8,
        "per_turn_max_tokens": 4096, "total_generated_token_cap": 4096,
        "max_retries": 1,
        "tool_timeout_sec": 10.0, "verifier_timeout_sec": 20.0,
        "bundle_name": "PIV_Q27_SUB_V10_FAST_BUNDLE.zip",
        "reset_outputs": True, "accuracy_is_real": True,
    },
    "SUBMIT": {
        # Full sweep: active_tasks=0 means "every task in the attached test file" (hidden set at scoring time).
        "use_model": True, "task_set": "TESTALL", "active_tasks": 0,
        "agent_batch_size": 12, "max_tool_calls": 6, "max_model_turns": 12,
        "per_turn_max_tokens": 8192, "total_generated_token_cap": 8192,
        "max_retries": 2,
        "tool_timeout_sec": 10.0, "verifier_timeout_sec": 20.0,
        "bundle_name": "PIV_Q27_SUB_V10_BUNDLE.zip",
        "reset_outputs": True, "accuracy_is_real": True,
    },
    "ADAPTIVE_SMOKE": {''')

edit(C_CONFIG, '''# v2.4 terminal-commit policy. Total task budget is unchanged; exploration may never consume this reserve.
FINAL_RESERVE_TOKENS = 4096
EXPLORATION_TOKEN_CAP = 12288 - FINAL_RESERVE_TOKENS''',
     '''# v2.4 terminal-commit policy. Total task budget is unchanged; exploration may never consume this reserve.
SUBMIT_MODE = RUN_PROFILE.startswith("SUBMIT")
TASK_TOKEN_CAP = int(PROFILE["total_generated_token_cap"])
# SUBMISSION PRE-REGISTRATION (wall-clock driven, deliberately different from the frozen v2.4G/v2.5 measurement run):
#   per-task budget 8,192 instead of 12,288 and finalizer reserve 2,048 instead of 4,096, concurrency 12 instead of 8,
#   single arm. v2.4G measured ~4.25 min per task-run at batch 8 with the 12,288 budget, i.e. ~8.5 h for 120 tasks and
#   ~17 h for 240 - more than one Kaggle session. These three changes buy coverage; they are NOT a quality claim and
#   make this run non-comparable with the v2.4G/v2.5 arm measurements.
FINAL_RESERVE_TOKENS = 2048 if SUBMIT_MODE else 4096
EXPLORATION_TOKEN_CAP = TASK_TOKEN_CAP - FINAL_RESERVE_TOKENS''')
edit(C_CONFIG, 'assert EXPLORATION_TOKEN_CAP + FINAL_RESERVE_TOKENS == 12288',
     'assert EXPLORATION_TOKEN_CAP + FINAL_RESERVE_TOKENS == TASK_TOKEN_CAP')
edit(C_CONFIG, '''if TOTAL_GENERATED_TOKEN_CAP != 12288:
    raise RuntimeError("v2.5 repair experiment requires the frozen 12,288-token total task budget.")''',
     '''_EXPECTED_TASK_BUDGET = {"SUBMIT": 8192, "SUBMIT_SMOKE": 8192, "SUBMIT_FAST": 4096}
if TOTAL_GENERATED_TOKEN_CAP != _EXPECTED_TASK_BUDGET.get(RUN_PROFILE, 12288):
    raise RuntimeError(f"unexpected total task budget {TOTAL_GENERATED_TOKEN_CAP} for profile {RUN_PROFILE}")''')
edit(C_CONFIG, 'TERMINAL_POLICY_ENABLED = (RUN_PROFILE in {"TERMINAL_PILOT","ADAPTIVE_SMOKE"})',
     '''# Every submission profile needs the terminal commit: without it a task that exhausts exploration ends with no
# program at all, and the interface gate (correctly) refuses to continue.
TERMINAL_POLICY_ENABLED = bool(SUBMIT_MODE or RUN_PROFILE in {"TERMINAL_PILOT","ADAPTIVE_SMOKE"})
assert (not SUBMIT_MODE) or TERMINAL_POLICY_ENABLED''')
edit(C_CONFIG, 'ARMS = list(ARM_CONFIG) if RUN_PROFILE == "PREFLIGHT" else list(QUALITY_SMOKE_ARMS)',
     '''# One arm only: a second arm cannot fit the session, and ACT-LOW has no forced-close phase-2 truncation defect.
SUBMIT_ARM = "ACT-LOW"
ARMS = [SUBMIT_ARM] if SUBMIT_MODE else (list(ARM_CONFIG) if RUN_PROFILE == "PREFLIGHT" else list(QUALITY_SMOKE_ARMS))''')
edit(C_CONFIG, 'BASE_WORK_ROOT = Path("/kaggle/working/piv_q27_c1_v25")',
     'BASE_WORK_ROOT = Path("/kaggle/working/piv_q27_sub_v10")')
edit(C_CONFIG, 'DEFAULT_SEC_PER_OUTPUT_TOKEN = 0.20   # projection prior before the first measured wave',
     '''DEFAULT_SEC_PER_OUTPUT_TOKEN = 0.20   # projection prior before the first measured wave
# v1.1: the line the notebook must never cross, independent of the solver's safety reserve. Used by the terminal
# finalizer guard so a last-chance program is only dropped when the SESSION itself is at risk.
SESSION_HARD_MARGIN_SEC = 10 * 60''')
edit(C_CONFIG, 'SAFETY_RESERVE_SEC = 60 * 60',
     '''# SUBMIT keeps a larger reserve: the CPU test-execution pass, the final submission write and the bundle all
# happen after the last GPU wave.
SAFETY_RESERVE_SEC = (75 * 60) if SUBMIT_MODE else (60 * 60)''')
edit(C_CONFIG, 'print("WORK_ROOT:", WORK_ROOT)',
     '''print("WORK_ROOT:", WORK_ROOT)
if SUBMIT_MODE:
    print("SUBMIT MODE | arm:", ARMS, "| per-task tokens:", TASK_TOKEN_CAP,
          "| finalizer reserve:", FINAL_RESERVE_TOKENS, "| concurrency:", AGENT_BATCH_SIZE)''')

# =====================================================================================
# NEW CELL 2B — submission state, written before any GPU work
# =====================================================================================
BOOTSTRAP = r'''# =====================================================================================
# CELL 0 - FALLBACK SUBMISSION BOOTSTRAP (standard library only; nothing above it can fail first)
# Review finding 2026-10-02: the submission machinery lived after the model/wheelhouse/pip/runtime checks and the
# public-data loads, so any of those failing left /kaggle/working/submission.json absent. This cell needs only the
# standard library and the attached test file.
#
# Severity note: a Kaggle code-competition submission is scored from the hidden-data re-run, and a notebook that
# raises scores nothing whether or not this file exists. The environment checks below therefore still raise loudly -
# quietly submitting identity grids would spend a daily submission on a guaranteed zero. This cell protects the
# interactive case, and guarantees the file on disk is never a stale newer-but-invalid one.
# =====================================================================================
import json as _json
import os as _os
from pathlib import Path as _Path

_SUB_BOOTSTRAP_PATH = _Path("/kaggle/working/submission.json")
_SUB_BOOTSTRAP_TEST_FILE = _Path("/kaggle/input/competitions/arc-prize-2026-arc-agi-2/arc-agi_test_challenges.json")
BOOTSTRAP_SUBMISSION_WRITTEN = False
BOOTSTRAP_SUBMISSION_ERROR = None
try:
    if not _SUB_BOOTSTRAP_TEST_FILE.is_file():
        _found = sorted(_Path("/kaggle/input").rglob("arc-agi_test_challenges.json"))
        if len(_found) != 1:
            raise FileNotFoundError(f"expected exactly one arc-agi_test_challenges.json, found {len(_found)}")
        _SUB_BOOTSTRAP_TEST_FILE = _found[0]
    with open(_SUB_BOOTSTRAP_TEST_FILE, "r", encoding="utf-8") as _fh:
        _boot_tasks = _json.load(_fh)
    _boot_payload = {}
    for _tid, _task in _boot_tasks.items():
        _answers = []
        for _query in _task["test"]:
            _grid = [[int(_cell) for _cell in _row] for _row in _query["input"]]
            if not (1 <= len(_grid) <= 30) or not (1 <= len(_grid[0]) <= 30):
                raise ValueError(f"{_tid}: test input is not a legal ARC grid")
            _answers.append({"attempt_1": [r[:] for r in _grid], "attempt_2": [r[:] for r in _grid]})
        _boot_payload[_tid] = _answers
    _SUB_BOOTSTRAP_PATH.parent.mkdir(parents=True, exist_ok=True)
    _boot_tmp = _SUB_BOOTSTRAP_PATH.with_name(f".bootstrap.{_os.getpid()}.tmp")
    with open(_boot_tmp, "w", encoding="utf-8", newline="\n") as _fh:
        _json.dump(_boot_payload, _fh, separators=(",", ":"))
        _fh.write("\n"); _fh.flush(); _os.fsync(_fh.fileno())
    _os.replace(_boot_tmp, _SUB_BOOTSTRAP_PATH)
    BOOTSTRAP_SUBMISSION_WRITTEN = True
    print(f"Bootstrap identity submission written for {len(_boot_payload)} tasks "
          f"({sum(len(v) for v in _boot_payload.values())} queries): {_SUB_BOOTSTRAP_PATH}")
except Exception as _boot_exc:
    # Never block the run: CELL 2B rewrites and validates the file with the full machinery anyway.
    BOOTSTRAP_SUBMISSION_ERROR = f"{type(_boot_exc).__name__}: {_boot_exc}"
    print("Bootstrap submission could not be written:", BOOTSTRAP_SUBMISSION_ERROR)
'''

SUB_STATE = r'''# =====================================================================================
# CELL 2B — SUBMISSION STATE
# A competition-legal submission.json exists from this point on. Every later stage can only improve it;
# nothing downstream can leave the file missing or malformed.
# =====================================================================================
import numbers

SUBMISSION_PATH = Path("/kaggle/working/submission.json")
SUB_TASK_IDS = sorted(test_challenges)
SUB_TASK_SET = set(SUB_TASK_IDS)
SUB_WRITE_MIN_INTERVAL_SEC = 30.0
SUB_CANDIDATES = {}      # task_id -> [candidate dicts]
SUB_SKIPPED = {}         # task_id -> why the solver never attempted it
SUB_INGEST_ERRORS = []
SUB_WRITE_COUNT = 0
_SUB_LAST_WRITE = float("-inf")

def sub_sanitize_grid(grid):
    """Return a competition-legal copy of `grid`, or None.

    v1.1: strict types. Python/NumPy integers are accepted; bool, numpy.bool_ and every float are rejected, including
    floats that happen to be integral. The previous version used int(cell) with an equality test, which silently
    turned 1.0 and numpy.bool_(True) into colour 1. Grids reaching this point have already passed the verifier's own
    clean() (which also rejects non-integers), so this is defence in depth - but the docstring must be true.
    """
    if not isinstance(grid, list) or not (1 <= len(grid) <= 30): return None
    if not isinstance(grid[0], list): return None
    width = len(grid[0])
    if not (1 <= width <= 30): return None
    out = []
    for row in grid:
        if not isinstance(row, list) or len(row) != width: return None
        clean_row = []
        for cell in row:
            if isinstance(cell, bool) or not isinstance(cell, numbers.Integral): return None
            if type(cell).__name__ in {"bool_", "bool8"}: return None   # NumPy booleans are Integral
            value = int(cell)
            if not (0 <= value <= 9): return None
            clean_row.append(value)
        out.append(clean_row)
    return out

def sub_identity_grid(task, query_index):
    return [row[:] for row in task["test"][query_index]["input"]]

def sub_add_candidate(task_id, code_sha256, grids, source, rank, train_exact_pairs=0):
    """Register one program's outputs. rank 2 = train-verified program, 1 = unverified program."""
    if task_id not in SUB_TASK_SET: return False
    queries = len(test_challenges[task_id]["test"])
    cleaned = []
    for qi in range(queries):
        raw = grids[qi] if (isinstance(grids, list) and qi < len(grids)) else None
        cleaned.append(sub_sanitize_grid(raw) if raw is not None else None)
    if not any(g is not None for g in cleaned): return False
    rows = SUB_CANDIDATES.setdefault(task_id, [])
    rows.append({"code_sha256": str(code_sha256), "grids": cleaned, "source": str(source),
                 "rank": int(rank), "train_exact_pairs": int(train_exact_pairs), "order": len(rows)})
    return True

def sub_rank_key(candidate):
    return (int(candidate["rank"]), int(candidate["train_exact_pairs"]), int(candidate["order"]))

def build_submission_payload():
    """attempt_1 = best-ranked program output, attempt_2 = best DIFFERENT output, identity copy where nothing exists."""
    payload = {}
    for task_id in SUB_TASK_IDS:
        task = test_challenges[task_id]
        ranked = sorted(SUB_CANDIDATES.get(task_id, []), key=sub_rank_key, reverse=True)
        answers = []
        for qi in range(len(task["test"])):
            identity = sub_identity_grid(task, qi)
            picks = []
            for candidate in ranked:
                grid = candidate["grids"][qi]
                if grid is None: continue
                if any(grid == chosen for chosen in picks): continue
                picks.append(grid)
                if len(picks) == 2: break
            answers.append({"attempt_1": picks[0] if picks else identity,
                            "attempt_2": picks[1] if len(picks) > 1 else identity})
        payload[task_id] = answers
    return payload

def validate_submission_payload(payload):
    if set(payload) != SUB_TASK_SET:
        raise RuntimeError("submission task ids do not match the attached test challenges")
    for task_id, answers in payload.items():
        queries = len(test_challenges[task_id]["test"])
        if len(answers) != queries:
            raise RuntimeError(f"{task_id}: {len(answers)} answers for {queries} test inputs")
        for answer in answers:
            if set(answer) != {"attempt_1", "attempt_2"}:
                raise RuntimeError(f"{task_id}: attempt keys {sorted(answer)}")
            for key in ("attempt_1", "attempt_2"):
                if sub_sanitize_grid(answer[key]) is None:
                    raise RuntimeError(f"{task_id}/{key}: illegal grid")
    return True

def write_submission(force=False):
    """Atomic, validated write. Throttled so the solver loop can call it after every record."""
    global _SUB_LAST_WRITE, SUB_WRITE_COUNT
    now = time.perf_counter()
    if (not force) and (now - _SUB_LAST_WRITE) < SUB_WRITE_MIN_INTERVAL_SEC:
        return False
    payload = build_submission_payload()
    validate_submission_payload(payload)
    temporary = SUBMISSION_PATH.with_name(f".{SUBMISSION_PATH.name}.{os.getpid()}.tmp")
    with open(temporary, "w", encoding="utf-8", newline="\n") as handle:
        json.dump(payload, handle, separators=(",", ":"), ensure_ascii=False)
        handle.write("\n"); handle.flush(); os.fsync(handle.fileno())
    os.replace(temporary, SUBMISSION_PATH)
    _SUB_LAST_WRITE = now; SUB_WRITE_COUNT += 1
    return True

def sub_ingest_record(record):
    """Take the test-grid outputs of one solver record into the submission candidate pool."""
    task_id = str(record.get("task_id") or "")
    if task_id not in SUB_TASK_SET: return False
    code = record.get("final_code")
    if not code: return False
    outputs = list(record.get("test_outputs") or [])
    if not any(g is not None for g in outputs): return False
    sha = record.get("final_code_sha256") or hashlib.sha256(str(code).encode("utf-8")).hexdigest()
    rank = 2 if bool(record.get("all_train_exact")) else 1
    for existing in SUB_CANDIDATES.get(task_id, []):
        if existing["code_sha256"] == sha and existing["rank"] == rank:
            return False
    return sub_add_candidate(task_id, sha, outputs, f"piv:{record.get('record_stage') or 'scheduler'}",
                             rank, int(record.get("train_exact_count") or 0))

def sub_coverage():
    queries_with_grid = 0
    for task_id in SUB_TASK_IDS:
        for qi in range(len(test_challenges[task_id]["test"])):
            if any(c["grids"][qi] is not None for c in SUB_CANDIDATES.get(task_id, [])):
                queries_with_grid += 1
    return {
        "tasks": len(SUB_TASK_IDS),
        "queries": sum(len(test_challenges[t]["test"]) for t in SUB_TASK_IDS),
        "tasks_with_any_program_output": sum(1 for t in SUB_TASK_IDS if SUB_CANDIDATES.get(t)),
        "tasks_with_train_verified_output": sum(1 for t in SUB_TASK_IDS
                                                if any(c["rank"] >= 2 for c in SUB_CANDIDATES.get(t, []))),
        "queries_with_model_grid": queries_with_grid,
        "tasks_skipped_by_solver": len(SUB_SKIPPED),
        "submission_writes": SUB_WRITE_COUNT,
    }

def run_submission_selftests():
    """Schema/fallback/ranking regressions. These run on every profile, before any GPU allocation."""
    probe_task = next(iter(SUB_TASK_IDS))
    probe = test_challenges[probe_task]
    identity = sub_identity_grid(probe, 0)
    assert sub_sanitize_grid(identity) == identity
    assert sub_sanitize_grid([[0, 1], [2]]) is None                     # ragged
    assert sub_sanitize_grid([[10]]) is None                            # colour out of range
    assert sub_sanitize_grid([[True]]) is None                          # python bool
    assert sub_sanitize_grid([[1.5]]) is None                           # float
    assert sub_sanitize_grid([[1.0]]) is None                           # an integral float is still a float
    try:
        import numpy as _np
        assert sub_sanitize_grid([[_np.bool_(True)]]) is None            # Integral, but not a colour
        assert sub_sanitize_grid([[_np.float64(1.0)]]) is None
        assert sub_sanitize_grid([[_np.int64(2)]]) == [[2]]               # NumPy integers stay legal
    except ImportError:
        pass
    assert sub_sanitize_grid([]) is None                                # empty
    assert sub_sanitize_grid([[1] * 31]) is None                        # too wide
    saved = {k: list(v) for k, v in SUB_CANDIDATES.items()}
    try:
        SUB_CANDIDATES.clear()
        payload = build_submission_payload()
        validate_submission_payload(payload)
        assert payload[probe_task][0]["attempt_1"] == identity and payload[probe_task][0]["attempt_2"] == identity
        queries = len(probe["test"])
        weak = [[[1]] for _ in range(queries)]
        strong = [[[2]] for _ in range(queries)]
        assert sub_add_candidate(probe_task, "weak", weak, "selftest", 1, 0)
        assert sub_add_candidate(probe_task, "strong", strong, "selftest", 2, 3)
        payload = build_submission_payload()
        validate_submission_payload(payload)
        assert payload[probe_task][0]["attempt_1"] == [[2]], payload[probe_task][0]
        assert payload[probe_task][0]["attempt_2"] == [[1]], payload[probe_task][0]
        # an illegal grid from a program must never reach the file
        assert not sub_add_candidate(probe_task, "illegal", [[[42]] for _ in range(queries)], "selftest", 2, 3)
        # a record without test outputs contributes nothing
        assert not sub_ingest_record({"task_id": probe_task, "final_code": "def solution(grid): return grid",
                                      "test_outputs": [None] * queries, "all_train_exact": False})
        assert sub_ingest_record({"task_id": probe_task, "final_code": "def solution(grid): return grid",
                                  "final_code_sha256": "deadbeef", "test_outputs": strong,
                                  "all_train_exact": True, "train_exact_count": 2})
        payload = build_submission_payload()
        validate_submission_payload(payload)
    finally:
        SUB_CANDIDATES.clear(); SUB_CANDIDATES.update(saved)
    result = {"schema_guards": True, "identity_fallback": True, "rank_order": True,
              "illegal_grid_rejected": True, "record_ingest": True, "strict_numeric_types": True,
              "bootstrap_fallback_present": bool(globals().get("BOOTSTRAP_SUBMISSION_WRITTEN"))}
    (WORK_ROOT / "submission_selftest.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print("Submission self-tests PASS:", result)
    return result

SUBMISSION_SELFTEST = run_submission_selftests()
write_submission(force=True)
print("Identity-fallback submission written:", SUBMISSION_PATH, "|", json.dumps(sub_coverage()))
'''

# =====================================================================================
# CELL 4 — TESTALL task selection
# =====================================================================================
edit(C_PROMPT, '''if TASK_SET == "PROXY48": ACTIVE_TASK_IDS = list(PROXY48_TASK_IDS)
elif TASK_SET == "SMOKE8": ACTIVE_TASK_IDS = choose_smoke8_from_proxy()
elif TASK_SET == "PILOT2": ACTIVE_TASK_IDS = list(TERMINAL_PILOT_TASK_IDS)
else: raise RuntimeError(f"Unknown TASK_SET={TASK_SET}")
ACTIVE_TASK_SET=set(ACTIVE_TASK_IDS)
if len(ACTIVE_TASK_IDS)!=ACTIVE_TASK_LIMIT or len(ACTIVE_TASK_SET)!=ACTIVE_TASK_LIMIT:
    raise RuntimeError("Active task count/uniqueness mismatch")
if not ACTIVE_TASK_SET.issubset(set(PROXY48_TASK_IDS)):
    raise RuntimeError("Active set escaped frozen Proxy-48")''',
     '''if TASK_SET == "PROXY48": ACTIVE_TASK_IDS = list(PROXY48_TASK_IDS)
elif TASK_SET == "SMOKE8": ACTIVE_TASK_IDS = choose_smoke8_from_proxy()
elif TASK_SET == "PILOT2": ACTIVE_TASK_IDS = list(TERMINAL_PILOT_TASK_IDS)
elif TASK_SET == "TESTALL":
    # Submission mode. The solver now works on the ATTACHED test file, which Kaggle replaces with the hidden
    # tasks at scoring time, so no task id may be hard-coded. Public evaluation tasks keep their solutions for
    # the EDA cell above; test tasks are merged in afterwards and never carry a solution.
    _test_ids = sorted(test_challenges)
    for _tid, _task in test_challenges.items():
        if _tid in eval_challenges and _tid not in _TESTALL_MERGED:
            raise RuntimeError(f"test task id {_tid} collides with a public evaluation id")
        eval_challenges[_tid] = _task
        _TESTALL_MERGED.add(_tid)
    ACTIVE_TASK_IDS = _test_ids[:ACTIVE_TASK_LIMIT] if ACTIVE_TASK_LIMIT else list(_test_ids)
else: raise RuntimeError(f"Unknown TASK_SET={TASK_SET}")
ACTIVE_TASK_SET=set(ACTIVE_TASK_IDS)
if TASK_SET == "TESTALL":
    if len(ACTIVE_TASK_IDS) != len(ACTIVE_TASK_SET) or not ACTIVE_TASK_IDS:
        raise RuntimeError("Active task count/uniqueness mismatch")
    if not ACTIVE_TASK_SET.issubset(SUB_TASK_SET):
        raise RuntimeError("Active set escaped the attached test file")
    SUBMIT_PILOT_TASK_IDS = list(ACTIVE_TASK_IDS[:2])
    print(f"TESTALL: {len(ACTIVE_TASK_IDS)} tasks |",
          sum(len(test_challenges[t]["test"]) for t in ACTIVE_TASK_IDS), "queries | pilot:", SUBMIT_PILOT_TASK_IDS)
else:
    if len(ACTIVE_TASK_IDS)!=ACTIVE_TASK_LIMIT or len(ACTIVE_TASK_SET)!=ACTIVE_TASK_LIMIT:
        raise RuntimeError("Active task count/uniqueness mismatch")
    if not ACTIVE_TASK_SET.issubset(set(PROXY48_TASK_IDS)):
        raise RuntimeError("Active set escaped frozen Proxy-48")''')
edit(C_PROMPT, '''# Frozen task selection: same Proxy-48; SMOKE is a deterministic subset of it.''',
     '''_TESTALL_MERGED = set()

# Frozen task selection: same Proxy-48; SMOKE is a deterministic subset of it.''')

# =====================================================================================
# CELL 5 — oversized prompts must drop the task, not kill the run
# =====================================================================================
edit(C_CTX, '''active_prompt_tokens=prompt_df[prompt_df.task_id.isin(ACTIVE_TASK_IDS)]["prompt_tokens"].to_numpy()
max_initial_prompt=int(active_prompt_tokens.max())
CONTEXT_SAFETY_TOKENS=512
MAX_RENDERED_INPUT_TOKENS=MAX_MODEL_LEN-PER_TURN_MAX_TOKENS-CONTEXT_SAFETY_TOKENS
if max_initial_prompt > MAX_RENDERED_INPUT_TOKENS:
    raise RuntimeError(f"Initial PIV prompt exceeds context: {max_initial_prompt} > {MAX_RENDERED_INPUT_TOKENS}")''',
     '''CONTEXT_SAFETY_TOKENS=512
MAX_RENDERED_INPUT_TOKENS=MAX_MODEL_LEN-PER_TURN_MAX_TOKENS-CONTEXT_SAFETY_TOKENS
_prompt_tokens_by_task={r["task_id"]:int(r["prompt_tokens"]) for r in prompt_records}
_oversized=[t for t in ACTIVE_TASK_IDS if _prompt_tokens_by_task.get(t,0) > MAX_RENDERED_INPUT_TOKENS]
if _oversized:
    if not SUBMIT_MODE:
        raise RuntimeError(f"Initial PIV prompt exceeds context for {_oversized}")
    # Submission mode: a task whose puzzle text cannot fit keeps its identity fallback instead of killing the run.
    for _tid in _oversized:
        SUB_SKIPPED[_tid]={"reason":"initial_prompt_exceeds_context",
                           "prompt_tokens":_prompt_tokens_by_task.get(_tid),
                           "limit":int(MAX_RENDERED_INPUT_TOKENS)}
    ACTIVE_TASK_IDS=[t for t in ACTIVE_TASK_IDS if t not in set(_oversized)]
    ACTIVE_TASK_SET=set(ACTIVE_TASK_IDS)
    PROMPT_RECORD_MAP={k:v for k,v in PROMPT_RECORD_MAP.items() if k in ACTIVE_TASK_SET}
    SUBMIT_PILOT_TASK_IDS=[t for t in globals().get("SUBMIT_PILOT_TASK_IDS",[]) if t in ACTIVE_TASK_SET] or list(ACTIVE_TASK_IDS[:2])
    print(f"SUBMIT: dropped {len(_oversized)} task(s) whose prompt exceeds {MAX_RENDERED_INPUT_TOKENS} tokens:",_oversized[:10])
    if not ACTIVE_TASK_IDS:
        raise RuntimeError("Every attached task exceeds the context budget; nothing can be solved.")
active_prompt_tokens=prompt_df[prompt_df.task_id.isin(ACTIVE_TASK_IDS)]["prompt_tokens"].to_numpy()
max_initial_prompt=int(active_prompt_tokens.max())''')

# =====================================================================================
# CELL 7 — the terminal positive control gates the sweep, so it must run in SUBMIT too
# =====================================================================================
edit(C_ENGINE, '        if RUN_PROFILE in {"TERMINAL_PILOT","ADAPTIVE_SMOKE"}:',
     '        if SUBMIT_MODE or RUN_PROFILE in {"TERMINAL_PILOT","ADAPTIVE_SMOKE"}:   # gates the sweep; must run in every submission profile')

# =====================================================================================
# CELL 8 — incremental submission writes + SUBMIT controller
# =====================================================================================

# the terminal-policy self-test hard-codes the 12,288/4,096 arithmetic; derive it from the live constants instead.
edit(C_SCHED, """    generated=TOTAL_GENERATED_TOKEN_CAP-5000
    cap=exploration_cap_v24(generated_tokens=generated,prompt_tokens=1000,forced_policy=False)
    assert cap<=904,(cap,generated)""",
     """    generated=TOTAL_GENERATED_TOKEN_CAP-5000
    cap=exploration_cap_v24(generated_tokens=generated,prompt_tokens=1000,forced_policy=False)
    _admissible=max(0,int(EXPLORATION_TOKEN_CAP)-int(generated))   # 904 at the frozen 12,288/4,096 setting
    assert cap<=_admissible,(cap,_admissible,generated)""")
edit(C_SCHED, '''def append_record(rec):
    with open(RAW_GENERATIONS_PATH,"a",encoding="utf-8") as f:
        f.write(json.dumps(rec,ensure_ascii=False,default=str)+"\\n")''',
     '''def append_record(rec):
    with open(RAW_GENERATIONS_PATH,"a",encoding="utf-8") as f:
        f.write(json.dumps(rec,ensure_ascii=False,default=str)+"\\n")
    if SUBMIT_MODE:
        # Submission safety: every terminal record immediately improves the on-disk submission, so a session that
        # dies mid-sweep still leaves the best file reached so far. Never allowed to break the solver loop.
        try:
            sub_ingest_record(rec); write_submission()
        except Exception as _sub_exc:
            SUB_INGEST_ERRORS.append({"task_id":rec.get("task_id"),"error":f"{type(_sub_exc).__name__}: {_sub_exc}"})''')

edit(C_SCHED, '''    if RUN_PROFILE == "ADAPTIVE_SMOKE":''',
     '''    if RUN_PROFILE == "ADAPTIVE_SMOKE" or SUBMIT_MODE:''')
edit(C_SCHED, '''        _adaptive_full_ids = list(choose_smoke8_from_proxy())
        _adaptive_pilot_ids = list(TERMINAL_PILOT_TASK_IDS)''',
     '''        if SUBMIT_MODE:
            # Same controller, test tasks: 2-task interface rehearsal, then the whole attached file.
            _adaptive_full_ids = list(ACTIVE_TASK_IDS)
            _adaptive_pilot_ids = list(SUBMIT_PILOT_TASK_IDS)
        else:
            _adaptive_full_ids = list(choose_smoke8_from_proxy())
            _adaptive_pilot_ids = list(TERMINAL_PILOT_TASK_IDS)''')
edit(C_SCHED, '''        if not set(_adaptive_pilot_ids).issubset(set(_adaptive_full_ids)):''',
     '''        if not _adaptive_pilot_ids or not set(_adaptive_pilot_ids).issubset(set(_adaptive_full_ids)):''')
edit(C_SCHED, '''            print("ADAPTIVE STAGE B — interface clean; continuing automatically to full frozen SMOKE8")
            print("SMOKE8:", ACTIVE_TASK_IDS)''',
     '''            print("ADAPTIVE STAGE B — interface clean; continuing automatically to the full task set")
            print("TASKS:", len(ACTIVE_TASK_IDS) if SUBMIT_MODE else ACTIVE_TASK_IDS)''')
edit(C_SCHED, '''print("Cell 8 complete. Arms:", ARMS, "| work root:", WORK_ROOT, "| fixed setup sec:", round(ACT_FIXED_SETUP_ELAPSED_SEC, 1))''',
     '''if SUBMIT_MODE:
    write_submission(force=True)
    print("Submission after the solver sweep:", json.dumps(sub_coverage()))
print("Cell 8 complete. Arms:", ARMS, "| work root:", WORK_ROOT, "| fixed setup sec:", round(ACT_FIXED_SETUP_ELAPSED_SEC, 1))''')

# v1.1 (review finding): completion must be DERIVED. run_real_piv() can break out of its batch loop on the safety
# deadline, leaving later batches with no record at all, while the old code still set ADAPTIVE_SMOKE_COMPLETED=True,
# so run_report.json claimed "completed" for a truncated sweep.
edit(C_SCHED, '''            ADAPTIVE_SMOKE_COMPLETED = True
            ADAPTIVE_STOP_REASON = None''',
     '''            _coverage_missing = {}
            for _arm in ARMS:
                activate_arm(_arm)
                _done = {str(r.get("task_id")) for r in read_existing_records()
                         if str(r.get("status")) in {"complete", "failed"}}
                _missing = [t for t in ACTIVE_TASK_IDS if t not in _done]
                if _missing:
                    _coverage_missing[_arm] = _missing
            ADAPTIVE_COVERAGE_MISSING = _coverage_missing
            ADAPTIVE_SMOKE_COMPLETED = not _coverage_missing
            ADAPTIVE_STOP_REASON = None if ADAPTIVE_SMOKE_COMPLETED else "incomplete_terminal_coverage"
            if _coverage_missing:
                print("STAGE B INCOMPLETE - tasks without a terminal record:",
                      {a: len(v) for a, v in _coverage_missing.items()})''')

# v1.1 (review finding): the terminal finalizer wave was guarded only by "are we already past the deadline?".
edit(C_SCHED, """                        if final_tids:
                            batch_wave_no+=1; global_wave_no+=1""",
     """                        if final_tids:
                            _fin_spt=float(globals().get("MEASURED_SEC_PER_OUTPUT_TOKEN") or DEFAULT_SEC_PER_OUTPUT_TOKEN)
                            _fin_projected=max(m["cap"] for m in final_meta)*_fin_spt*float(WAVE_TIME_SAFETY_FACTOR)+float(WAVE_OVERHEAD_SEC)
                            # Derived from the LIVE deadline, so a self-test that overrides `deadline` is not
                            # affected: in a real run this is exactly notebook_start + TOTAL_RUNTIME_SEC - margin.
                            _fin_hard_limit=deadline+float(SAFETY_RESERVE_SEC)-float(SESSION_HARD_MARGIN_SEC)
                            if time.perf_counter()+_fin_projected >= _fin_hard_limit:
                                print(f"[{arm}] finalizer skipped for {len(final_tids)} task(s): projected "
                                      f"{_fin_projected/60:.1f} min would cross the hard session limit")
                                for _ftid in list(final_tids):
                                    _fst=states[_ftid]
                                    if _fst.get("done"): continue
                                    _fst["infrastructure_failure"]=True
                                    _fst.setdefault("infrastructure_errors",[]).append(
                                        {"phase":"finalizer","error":f"projected {_fin_projected:.0f}s finalizer would cross the hard session limit"})
                                    _fst["generated_tokens_observed_lower_bound"]=True
                                    _fst["done"]=True
                                    _frec=complete_record(_fst,eval_challenges[_ftid],None,"failed","global_deadline_projected",
                                                          f"projected finalizer {_fin_projected:.0f}s would cross the hard session limit")
                                    _frec["status"]="failed"; append_record(_frec)
                                final_tids=[]; final_prompts=[]; final_params=[]; final_meta=[]
                        if final_tids:
                            batch_wave_no+=1; global_wave_no+=1""")

# =====================================================================================
# CELL 8B — repair must be chunked and deadline-aware over hundreds of tasks
# =====================================================================================
edit(C_REPAIR, '''    if jobs:
        prompts=[j["rp"]["rendered"] for j in jobs]''',
     '''    if jobs and SUBMIT_MODE:
        # One generate() call per AGENT_BATCH_SIZE jobs, each pre-checked against the safety deadline. A 200-task
        # repair wave in a single call could not be interrupted and would overrun the session.
        _chunks=[jobs[i:i+AGENT_BATCH_SIZE] for i in range(0,len(jobs),AGENT_BATCH_SIZE)]
    elif jobs:
        _chunks=[jobs]
    else:
        _chunks=[]
    for _chunk in _chunks:
        _spt=float(globals().get("MEASURED_SEC_PER_OUTPUT_TOKEN") or DEFAULT_SEC_PER_OUTPUT_TOKEN)
        _projected=max(j["cap"] for j in _chunk)*_spt*float(WAVE_TIME_SAFETY_FACTOR)+float(WAVE_OVERHEAD_SEC)
        if time.perf_counter()+_projected >= deadline:
            # v1.1: report EVERY remaining job, not only this chunk, so repair_summary stays complete.
            _stop_index=_chunks.index(_chunk)
            _skipped=0
            for _rest in _chunks[_stop_index:]:
                for j in _rest:
                    m=copy.deepcopy(j["meta"]); m.update({"repair_attempted":False,"repair_status":"repair_skipped_deadline"})
                    summary_rows.append({"arm":arm,"task_id":j["tid"],**m}); _skipped+=1
            print(f"[{arm}] repair: stopping before a {_projected/60:.1f} min chunk would cross the deadline; "
                  f"{_skipped} job(s) skipped")
            break
        jobs=_chunk
        prompts=[j["rp"]["rendered"] for j in jobs]''')

# keep the rejected repair program: a different wrong program is still a better attempt_2 than copying the input.
edit(C_REPAIR, '''                r=_v25_update_record_from_selected(j["base"],sel_idx,sel_code,sel_v,m,generated_add=nt,repair_finish=fr)
                append_record(r); summary_rows.append({"arm":arm,"task_id":j["tid"],**m})''',
     '''                r=_v25_update_record_from_selected(j["base"],sel_idx,sel_code,sel_v,m,generated_add=nt,repair_finish=fr)
                if int(sel_idx)==1:
                    # Candidate #2 lost the selection, but the submission can still use it for attempt_2.
                    r["repair_candidate2_code"]=code2
                    r["repair_candidate2_code_sha256"]=hashlib.sha256((code2 or "").encode()).hexdigest()
                append_record(r); summary_rows.append({"arm":arm,"task_id":j["tid"],**m})''')

# =====================================================================================
# NEW CELLS after 8B
# =====================================================================================
SUB_TEST_EXEC = r'''# =====================================================================================
# CELL 8C — TEST EXECUTION FOR UNVERIFIED PROGRAMS (CPU only)
# The solver's verifier runs test inputs only after an all-train-exact gate, which is the right rule for a
# measurement. For a submission, a program that failed training is still a better attempt_2 than copying the
# input, so every remaining program is executed here in a fresh sandbox.
# =====================================================================================
SUB_TEST_EXEC_SUMMARY = {"enabled": bool(SUBMIT_MODE), "programs_executed": 0, "candidates_added": 0,
                         "guard_rejected": 0, "failures": 0, "skipped_deadline": 0, "elapsed_sec": 0.0}
SUB_UNVERIFIED_BUDGET_SEC = 20 * 60
SUB_UNVERIFIED_TIMEOUT_SEC = min(float(VERIFIER_TIMEOUT_SEC), 10.0)
SUB_MAX_PROGRAMS_PER_TASK = 3

def sub_run_program_on_test_inputs(code, task, timeout_sec, stop_at=None):
    """Fresh subprocess per test input, mirroring the verifier's own test stage.

    v1.1: `stop_at` is checked before EVERY query, so one multi-query task cannot run past the budget. Queries that
    are not executed return None and simply contribute no candidate grid.
    """
    outputs = []
    for query in task_without_test_solutions(task)["test"]:
        if stop_at is not None and time.perf_counter() >= stop_at:
            outputs.append(None)
            continue
        started, result = _run_verifier_stage({"mode": "test", "code": code, "test_input": query["input"]}, timeout_sec)
        ok = bool(started) and str(result.get("stage_status") or "") == "ok" and result.get("ok") and result.get("pred") is not None
        outputs.append(result.get("pred") if ok else None)
    return outputs

if SUBMIT_MODE:
    _t0 = time.perf_counter()
    _stop_at = min(deadline, _t0 + SUB_UNVERIFIED_BUDGET_SEC)   # v1.1: one absolute stop line for the whole pass
    _programs = {}
    for _arm in ARMS:
        _path = WORK_ROOT / "arms" / _arm / "raw_generations.jsonl"
        if not _path.exists(): continue
        for _line in _path.read_text(encoding="utf-8").splitlines():
            if not _line.strip(): continue
            try: _rec = json.loads(_line)
            except Exception: continue
            _tid = str(_rec.get("task_id") or "")
            if _tid not in SUB_TASK_SET: continue
            # Each record can carry two distinct programs: the selected one and a rejected repair candidate.
            for _key in ("final_code", "repair_candidate2_code"):
                if _rec.get(_key):
                    _programs.setdefault(_tid, []).append({
                        "code": _rec[_key],
                        "code_sha256": (_rec.get("final_code_sha256") if _key == "final_code"
                                        else _rec.get("repair_candidate2_code_sha256")),
                        "train_exact_count": (_rec.get("train_exact_count") if _key == "final_code" else 0),
                        "origin": _key})
    for _tid, _recs in _programs.items():
        if time.perf_counter() >= _stop_at:
            SUB_TEST_EXEC_SUMMARY["skipped_deadline"] += 1
            continue
        _seen = {c["code_sha256"] for c in SUB_CANDIDATES.get(_tid, [])}
        _done = 0
        for _rec in reversed(_recs):          # newest program first (repair output before candidate #1)
            if _done >= SUB_MAX_PROGRAMS_PER_TASK: break
            _code = _rec.get("code")
            _sha = _rec.get("code_sha256") or hashlib.sha256(str(_code).encode("utf-8")).hexdigest()
            if _sha in _seen: continue
            _seen.add(_sha)
            _ok, _reason = guard_python_code(_code, final=True)
            if not _ok:
                SUB_TEST_EXEC_SUMMARY["guard_rejected"] += 1
                continue
            if time.perf_counter() >= _stop_at:       # v1.1: also enforced between the programs of one task
                SUB_TEST_EXEC_SUMMARY["skipped_deadline"] += 1
                break
            try:
                _outputs = sub_run_program_on_test_inputs(_code, test_challenges[_tid], SUB_UNVERIFIED_TIMEOUT_SEC,
                                                          stop_at=_stop_at)
            except Exception as _exc:
                SUB_TEST_EXEC_SUMMARY["failures"] += 1
                SUB_INGEST_ERRORS.append({"task_id": _tid, "error": f"test_exec: {type(_exc).__name__}: {_exc}"})
                continue
            SUB_TEST_EXEC_SUMMARY["programs_executed"] += 1
            _done += 1
            if sub_add_candidate(_tid, _sha, _outputs,
                                 f"test_execution:{_rec.get('origin') or 'final_code'}",
                                 1 if _rec.get("origin") == "final_code" else 0,
                                 int(_rec.get("train_exact_count") or 0)):
                SUB_TEST_EXEC_SUMMARY["candidates_added"] += 1
        write_submission()
    SUB_TEST_EXEC_SUMMARY["elapsed_sec"] = round(time.perf_counter() - _t0, 1)
    write_submission(force=True)
    print("Unverified-program test execution:", json.dumps(SUB_TEST_EXEC_SUMMARY))
    print("Submission coverage:", json.dumps(sub_coverage()))
else:
    print("Not a submission profile; skipping test execution for unverified programs.")
'''

SUB_REPORT = r'''# =====================================================================================
# CELL 9 — FINAL SUBMISSION + RUN REPORT
# =====================================================================================
write_submission(force=True)
_final_payload = json.loads(SUBMISSION_PATH.read_text(encoding="utf-8"))
validate_submission_payload(_final_payload)

def sub_record_rollup():
    rows = []
    for _arm in ARMS:
        _path = WORK_ROOT / "arms" / _arm / "raw_generations.jsonl"
        if not _path.exists(): continue
        _latest = {}
        for _line in _path.read_text(encoding="utf-8").splitlines():
            if not _line.strip(): continue
            try: _rec = json.loads(_line)
            except Exception: continue
            _latest[str(_rec.get("task_id"))] = _rec
        for _tid, _rec in _latest.items():
            rows.append({"arm": _arm, "task_id": _tid, "status": _rec.get("status"),
                         "stop_reason": _rec.get("stop_reason"), "record_stage": _rec.get("record_stage"),
                         "model_turns": _rec.get("model_turns"), "tool_calls": _rec.get("tool_calls"),
                         "generated_tokens": _rec.get("generated_tokens"),
                         "final_program": bool(_rec.get("final_code")),
                         "all_train_exact": bool(_rec.get("all_train_exact")),
                         "train_exact_count": _rec.get("train_exact_count"),
                         "verifier_status": _rec.get("verifier_status"),
                         "infrastructure_failure": bool(_rec.get("infrastructure_failure"))})
    return pd.DataFrame(rows)

SUB_RECORDS_DF = sub_record_rollup()
if len(SUB_RECORDS_DF):
    SUB_RECORDS_DF.to_csv(WORK_ROOT / "task_records.csv", index=False)

_coverage = sub_coverage()
_attempted = int(len(SUB_RECORDS_DF)) if len(SUB_RECORDS_DF) else 0
RUN_REPORT = {
    "experiment_id": EXPERIMENT_ID, "run_id": RUN_ID, "profile": RUN_PROFILE, "arm": ARMS,
    "status": ("completed" if bool(globals().get("ADAPTIVE_SMOKE_COMPLETED")) else "stopped_early"),
    "stop_reason": globals().get("ADAPTIVE_STOP_REASON"),
    "interface_gate": globals().get("ADAPTIVE_INTERFACE_GATE"),
    "coverage_missing_tasks": {k: len(v) for k, v in (globals().get("ADAPTIVE_COVERAGE_MISSING") or {}).items()},
    "bootstrap_submission_written": bool(globals().get("BOOTSTRAP_SUBMISSION_WRITTEN")),
    "bootstrap_submission_error": globals().get("BOOTSTRAP_SUBMISSION_ERROR"),
    "session_hard_margin_sec": SESSION_HARD_MARGIN_SEC,
    "submission_path": str(SUBMISSION_PATH),
    "submission_sha256": hashlib.sha256(SUBMISSION_PATH.read_bytes()).hexdigest(),
    "submission_valid": True,
    "coverage": _coverage,
    "tasks_in_attached_file": len(SUB_TASK_IDS),
    "tasks_offered_to_solver": len(ACTIVE_TASK_IDS),
    "tasks_with_terminal_record": _attempted,
    "tasks_skipped_before_solving": SUB_SKIPPED,
    "train_verified_tasks": int(SUB_RECORDS_DF["all_train_exact"].sum()) if len(SUB_RECORDS_DF) else 0,
    "final_program_tasks": int(SUB_RECORDS_DF["final_program"].sum()) if len(SUB_RECORDS_DF) else 0,
    "infrastructure_failure_tasks": int(SUB_RECORDS_DF["infrastructure_failure"].sum()) if len(SUB_RECORDS_DF) else 0,
    "stop_reason_counts": (SUB_RECORDS_DF["stop_reason"].value_counts().to_dict() if len(SUB_RECORDS_DF) else {}),
    "unverified_test_execution": SUB_TEST_EXEC_SUMMARY,
    "repair": globals().get("V25_REPAIR_RUN_SUMMARY"),
    "submission_selftest": globals().get("SUBMISSION_SELFTEST"),
    "ingest_errors": SUB_INGEST_ERRORS[:50],
    "budget": {"per_task_generated_tokens": TOTAL_GENERATED_TOKEN_CAP, "exploration_cap": EXPLORATION_TOKEN_CAP,
               "finalizer_reserve": FINAL_RESERVE_TOKENS, "concurrency": AGENT_BATCH_SIZE,
               "max_tool_calls": MAX_TOOL_CALLS, "max_model_turns": MAX_MODEL_TURNS,
               "verifier_timeout_sec": VERIFIER_TIMEOUT_SEC},
    "wall_clock": {"elapsed_sec": round(time.perf_counter() - NOTEBOOK_WALL_START, 1),
                   "total_runtime_budget_sec": TOTAL_RUNTIME_SEC, "safety_reserve_sec": SAFETY_RESERVE_SEC,
                   "setup_sec": round(float(globals().get("ACT_FIXED_SETUP_ELAPSED_SEC") or 0.0), 1)},
    "engine": globals().get("ENGINE_RUNTIME_CONTRACT"),
    "preregistration": {
        "non_comparable_with_v24g_v25": True,
        "changes_vs_measurement_run": [f"per-task budget {TOTAL_GENERATED_TOKEN_CAP} (was 12288)", f"finalizer reserve {FINAL_RESERVE_TOKENS} (was 4096)",
                                       f"concurrency {AGENT_BATCH_SIZE} (was 8)", f"single arm {ARMS}"],
        "reason": "wall-clock coverage of the whole hidden test file inside one 12-hour session",
        "repair_budget": globals().get("REPAIR_BUDGET_PREREGISTRATION"),
    },
}
(WORK_ROOT / "run_report.json").write_text(json.dumps(RUN_REPORT, indent=2, default=str), encoding="utf-8")
print("=" * 116)
print("RUN REPORT")
print(json.dumps({k: v for k, v in RUN_REPORT.items() if k not in {"interface_gate", "repair", "engine"}},
                 indent=2, default=str))
if _coverage["tasks_with_train_verified_output"] == 0:
    print("\nWARNING: no task produced a train-verified program. The submission is schema-valid but is expected to score ~0.")
'''

SUB_BUNDLE = r'''# =====================================================================================
# CELL 10 — MANIFEST + EVIDENCE BUNDLE
# =====================================================================================
def sha256_file(path, chunk=1024 * 1024):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(chunk), b""): h.update(b)
    return h.hexdigest()

shutil.copyfile(SUBMISSION_PATH, WORK_ROOT / "submission.json")
manifest = []
for p in sorted(WORK_ROOT.rglob("*")):
    if p.is_file() and p.name != "MANIFEST.csv":
        manifest.append({"file": str(p.relative_to(WORK_ROOT)), "bytes": p.stat().st_size, "sha256": sha256_file(p)})
pd.DataFrame(manifest).to_csv(WORK_ROOT / "MANIFEST.csv", index=False)
ZIP_PATH = Path("/kaggle/working") / BUNDLE_NAME
if ZIP_PATH.exists(): ZIP_PATH.unlink()
with zipfile.ZipFile(ZIP_PATH, "w", compression=zipfile.ZIP_DEFLATED) as zf:
    for p in sorted(WORK_ROOT.rglob("*")):
        if p.is_file(): zf.write(p, arcname=str(p.relative_to(WORK_ROOT)))
print("=" * 116)
print(EXPERIMENT_ID, RUN_PROFILE, "PIPELINE COMPLETE")
print("Submission:", SUBMISSION_PATH, "| sha256:", RUN_REPORT["submission_sha256"])
print("Bundle:", ZIP_PATH, "| MB:", round(ZIP_PATH.stat().st_size / 1024 ** 2, 2))
print("Submit /kaggle/working/submission.json from a SAVED Run All version only.")
'''

FINAL_MD = """## Run sequence — PIV-Q27-SUB v1.0 (hidden-test submission)

1. Attach, with **Internet OFF** and **GPU L4 x4**: the competition input, the pinned Qwen3.8-27B-FP8 model, and the
   vLLM wheelhouse dataset.
2. `RUN_PROFILE = "SUBMIT_SMOKE"` for a ~20 minute interface rehearsal on 4 tasks. **Never submit that version.**
3. `RUN_PROFILE = "SUBMIT"` (default) → **Save & Run All**, then submit `/kaggle/working/submission.json` from the
   saved version.

What the run guarantees, in order:
* a schema-valid identity-fallback `submission.json` exists before the model is allocated;
* the 2-task interface gate must pass before the full sweep starts (a failed gate stops the run and keeps the
  fallback submission);
* every terminal record rewrites `submission.json` atomically, so a dead session keeps the best file reached;
* the wall-clock deadline stops scheduling new waves instead of overrunning the session;
* unverified programs still fill `attempt_2` through a CPU test-execution pass;
* `run_report.json` states coverage, train-verified task count and every pre-registered deviation from the
  v2.4G/v2.5 measurement runs.

`attempt_1` is the highest-ranked program output (train-verified first), `attempt_2` the best different output, and an
identity copy of the test input wherever no program produced a legal grid.
"""

cells.insert(C_CONFIG, {"cell_type": "code", "metadata": {}, "execution_count": None, "outputs": [],
                        "source": BOOTSTRAP.splitlines(keepends=True)})
code_idx = [i for i, c in enumerate(cells) if c["cell_type"] == "code"]
C_DATA = code_idx[2]

insert_at = C_DATA + 1
cells.insert(insert_at, {"cell_type": "code", "metadata": {}, "execution_count": None, "outputs": [],
                         "source": SUB_STATE.splitlines(keepends=True)})
# locate the repair cell by content: inserting cells shifted every index.
C_REPAIR_NEW = next(i for i, c in enumerate(cells)
                    if c["cell_type"] == "code" and "".join(c["source"]).lstrip().startswith("# ====")
                    and "def run_v25_repair_round_for_arm" in "".join(c["source"]))
tail_start = C_REPAIR_NEW + 1
del cells[tail_start:]
for src in (SUB_TEST_EXEC, SUB_REPORT, SUB_BUNDLE):
    cells.append({"cell_type": "code", "metadata": {}, "execution_count": None, "outputs": [],
                  "source": src.splitlines(keepends=True)})
cells.append({"cell_type": "markdown", "metadata": {}, "source": FINAL_MD.splitlines(keepends=True)})

header = cells[0]
head_src = "".join(header["source"])
head_src = ("# PIV-Q27-SUB v1.1 — HIDDEN-TEST SUBMISSION\n\n"
            "Submission notebook derived from the audited **PIV-Q27-C1 v2.5A** solver "
            "(`sha256 2188b999efeb6e286fc914bb8c1d876a5c9bdab99537842cd8c94360cd47d5ff`). The solver core — stateful\n"
            "Python REPL agent, Qwen tool XML contract, terminal-commit finalizer, fresh exact train verifier and the\n"
            "v2.5 verifier-feedback repair round — is unchanged. Everything measurement-specific was replaced by\n"
            "submission machinery; see the run-sequence note at the end of the notebook.\n\n"
            "**Pre-registered deviations from the measurement runs (wall-clock driven, not quality claims):**\n"
            "per-task budget 8,192 tokens (was 12,288), finalizer reserve 2,048 (was 4,096), concurrency 12 (was 8),\n"
            "single arm `ACT-LOW`. v2.4G measured ~4.25 min per task-run at batch 8 and the 12,288-token budget, which\n"
            "would need roughly 8.5 h for 120 tasks and ~17 h for 240 — more than one Kaggle session.\n\n"
            "**v1.1 fixes after independent review:** fallback submission bootstrapped in the first cell; completion\n"
            "status derived from terminal coverage; the terminal finalizer wave is projected against the hard session\n"
            "limit; strict grid types; every skipped repair job reported; the CPU test-execution budget is enforced\n"
            "inside the program and query loops.\n\n"
            "---\n\n" + head_src.split("\n", 1)[1].lstrip("\n"))
header["source"] = head_src.splitlines(keepends=True)

nb["metadata"] = dict(nb.get("metadata") or {})
nb["metadata"]["piv_q27_sub"] = {
    "derived_from": "PIV-Q27-C1-v2_5A-CANDIDATE-FIRST-VERIFIER-FEEDBACK-REPAIR.ipynb",
    "derived_from_sha256": hashlib.sha256(SRC.read_bytes()).hexdigest(),
    "purpose": "hidden-test submission.json production",
    "default_profile": "SUBMIT",
    "review_fixes": ["bootstrap_fallback_cell", "coverage_derived_completion", "finalizer_hard_limit_projection",
                     "strict_grid_types", "complete_repair_reporting", "inner_cpu_budget_checks"],
}

DST.write_text(json.dumps(nb, indent=1, ensure_ascii=False) + "\n", encoding="utf-8")
print("wrote", DST)
print("code cells:", sum(1 for c in nb["cells"] if c["cell_type"] == "code"))
print("sha256", hashlib.sha256(DST.read_bytes()).hexdigest())
