"""P3: make the harness and build scripts runnable on another machine (env-var path overrides)."""
from pathlib import Path

BASE = Path(__file__).parent
SCRATCH_DEFAULT = str(BASE)

# ---------------------------------------------------------------- harness
h = BASE / "c1v24e" / "harness_c1.py"
s = h.read_text(encoding="utf-8")
old_s = 'S = Path(r"' + SCRATCH_DEFAULT + '")'
new_s = ('# Scratch root holding the fake Kaggle tree (fake_input/, fake_working_c1/).\n'
         '# Override on another machine: PIV_HARNESS_SCRATCH=/path/to/scratch python harness_c1.py SUBMIT <notebook>\n'
         'S = Path(os.environ.get("PIV_HARNESS_SCRATCH", r"' + SCRATCH_DEFAULT + '"))')
if "PIV_HARNESS_SCRATCH" not in s:
    assert s.count(old_s) == 1, (old_s, s.count(old_s))
    s = s.replace(old_s, new_s)
    # the default notebook path is a dead reference to a v2.4E file; require argv[2] instead
    import re
    s = re.sub(r'NB = Path\(sys\.argv\[2\]\) if len\(sys\.argv\) > 2 else Path\(r"[^"]*"\)',
               'NB = Path(sys.argv[2])   # notebook path is required: python harness_c1.py <PROFILE> <notebook.ipynb>',
               s, count=1)
    h.write_text(s, encoding="utf-8")
    import ast
    ast.parse(s)
    print("harness: PIV_HARNESS_SCRATCH override added, notebook path now required")
else:
    print("harness: already patched")

# ---------------------------------------------------------------- build scripts
for name in ("make_v25a.py", "make_sub_v10.py"):
    p = BASE / "c1v25" / name
    t = p.read_text(encoding="utf-8")
    if "PIV_PROJECT_ROOT" in t:
        print(name, "already patched")
        continue
    t = t.replace("import json\nfrom pathlib import Path",
                  "import json\nimport os\nfrom pathlib import Path", 1)
    marker = 'SRC = Path(r"D:\\ARC AGI 2\\'
    assert marker in t, name
    t = t.replace('SRC = Path(r"D:\\ARC AGI 2\\',
                  '# Project root; override with PIV_PROJECT_ROOT on another machine.\n'
                  'PROJECT_ROOT = Path(os.environ.get("PIV_PROJECT_ROOT", r"D:\\ARC AGI 2"))\n'
                  'SRC = PROJECT_ROOT / (r"', 1)
    t = t.replace('DST = Path(r"D:\\ARC AGI 2\\', 'DST = PROJECT_ROOT / (r"', 1)
    # close the parentheses that the two replacements opened
    lines = t.splitlines(keepends=True)
    for i, line in enumerate(lines):
        if line.startswith("SRC = PROJECT_ROOT / (r\"") or line.startswith("DST = PROJECT_ROOT / (r\""):
            lines[i] = line.rstrip("\n").rstrip(")") + ")\n" if line.rstrip().endswith(")") else line
    t = "".join(lines)
    p.write_text(t, encoding="utf-8")
    import ast
    ast.parse(t)
    print(name, "patched")
