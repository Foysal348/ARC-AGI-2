"""Apply the external-review fixes to make_sub_v10.py, producing the PIV-SUB v1.1 builder.

P0  earliest-possible fallback submission: a new stdlib-only bootstrap cell before the config cell.
P1a completion status derived from terminal coverage instead of asserted unconditionally.
P1b hard session-limit projection before the terminal finalizer wave (checked against the 12 h limit, not against
    the solver's safety reserve, so a task's last chance to emit a program is not thrown away).
P2a strict grid sanitizer (NumPy ints allowed; bool, numpy.bool_ and every float rejected).
P2b repair rows emitted for every remaining chunk when the deadline stops the round.
P2c CPU test-execution budget enforced inside the program and query loops.
"""
from pathlib import Path

p = Path(__file__).with_name("make_sub_v10.py")
s = p.read_text(encoding="utf-8")
T3 = "'" * 3


def sub(old, new, count=1):
    global s
    assert s.count(old) == count, (old[:90], s.count(old))
    s = s.replace(old, new)


# ---------------------------------------------------------------- version strings / output path
sub("""     'EXPERIMENT_ID = "PIV-Q27-SUB-v1.0"')""", """     'EXPERIMENT_ID = "PIV-Q27-SUB-v1.1"')""")
sub("""     'GENERATION_CONTRACT_VERSION = "piv-q27-sub-hidden-test-v1.0"')""",
    """     'GENERATION_CONTRACT_VERSION = "piv-q27-sub-hidden-test-v1.1"')""")
sub('PIV-Q27-SUB-v1_0-HIDDEN-TEST-SUBMISSION.ipynb")', 'PIV-Q27-SUB-v1_1-HIDDEN-TEST-SUBMISSION.ipynb")')

# ---------------------------------------------------------------- P2a strict sanitizer
sub('''def sub_sanitize_grid(grid):
    """Return a competition-legal copy of `grid`, or None. Rejects bools, floats, ragged rows, colors outside 0-9."""''',
    '''def sub_sanitize_grid(grid):
    """Return a competition-legal copy of `grid`, or None.

    v1.1: strict types. Python/NumPy integers are accepted; bool, numpy.bool_ and every float are rejected, including
    floats that happen to be integral. The previous version used int(cell) with an equality test, which silently
    turned 1.0 and numpy.bool_(True) into colour 1. Grids reaching this point have already passed the verifier's own
    clean() (which also rejects non-integers), so this is defence in depth - but the docstring must be true.
    """''')
sub('''        for cell in row:
            if isinstance(cell, bool): return None
            try: value = int(cell)
            except Exception: return None
            if value != cell or not (0 <= value <= 9): return None
            clean_row.append(value)''',
    '''        for cell in row:
            if isinstance(cell, bool) or not isinstance(cell, numbers.Integral): return None
            if type(cell).__name__ in {"bool_", "bool8"}: return None   # NumPy booleans are Integral
            value = int(cell)
            if not (0 <= value <= 9): return None
            clean_row.append(value)''')
sub('''SUBMISSION_PATH = Path("/kaggle/working/submission.json")
SUB_TASK_IDS = sorted(test_challenges)''',
    '''import numbers

SUBMISSION_PATH = Path("/kaggle/working/submission.json")
SUB_TASK_IDS = sorted(test_challenges)''')
sub('''    assert sub_sanitize_grid([[True]]) is None                          # bool
    assert sub_sanitize_grid([[1.5]]) is None                           # float''',
    '''    assert sub_sanitize_grid([[True]]) is None                          # python bool
    assert sub_sanitize_grid([[1.5]]) is None                           # float
    assert sub_sanitize_grid([[1.0]]) is None                           # an integral float is still a float
    try:
        import numpy as _np
        assert sub_sanitize_grid([[_np.bool_(True)]]) is None            # Integral, but not a colour
        assert sub_sanitize_grid([[_np.float64(1.0)]]) is None
        assert sub_sanitize_grid([[_np.int64(2)]]) == [[2]]               # NumPy integers stay legal
    except ImportError:
        pass''')
sub('''    result = {"schema_guards": True, "identity_fallback": True, "rank_order": True,
              "illegal_grid_rejected": True, "record_ingest": True}''',
    '''    result = {"schema_guards": True, "identity_fallback": True, "rank_order": True,
              "illegal_grid_rejected": True, "record_ingest": True, "strict_numeric_types": True,
              "bootstrap_fallback_present": bool(globals().get("BOOTSTRAP_SUBMISSION_WRITTEN"))}''')

# ---------------------------------------------------------------- P1b hard session margin constant
sub("""edit(C_CONFIG, 'SAFETY_RESERVE_SEC = 60 * 60',""",
    """edit(C_CONFIG, 'DEFAULT_SEC_PER_OUTPUT_TOKEN = 0.20   # projection prior before the first measured wave',
     {T}DEFAULT_SEC_PER_OUTPUT_TOKEN = 0.20   # projection prior before the first measured wave
# v1.1: the line the notebook must never cross, independent of the solver's safety reserve. Used by the terminal
# finalizer guard so a last-chance program is only dropped when the SESSION itself is at risk.
SESSION_HARD_MARGIN_SEC = 10 * 60{T})
edit(C_CONFIG, 'SAFETY_RESERVE_SEC = 60 * 60',""".replace("{T}", T3))

# ---------------------------------------------------------------- P1a completion derived from coverage
sub('''# =====================================================================================
# CELL 8B — repair must be chunked and deadline-aware over hundreds of tasks
# =====================================================================================''',
    '''# v1.1 (review finding): completion must be DERIVED. run_real_piv() can break out of its batch loop on the safety
# deadline, leaving later batches with no record at all, while the old code still set ADAPTIVE_SMOKE_COMPLETED=True,
# so run_report.json claimed "completed" for a truncated sweep.
edit(C_SCHED, {T}            ADAPTIVE_SMOKE_COMPLETED = True
            ADAPTIVE_STOP_REASON = None{T},
     {T}            _coverage_missing = {}
            for _arm in ARMS:
                activate_arm(_arm)
                _done = {str(r.get("task_id")) for r in read_existing_records()
                         if str(r.get("status")) in {"complete", "failed"}}
                _missing = [t for t in ACTIVE_TASK_IDS if t not in _done]
                if _missing:
                    _coverage_missing[_arm] = _missing
            ADAPTIVE_COVERAGE_MISSING = _coverage_missing
            ADAPTIVE_SMOKE_COMPLETED = not _coverage_missing
            ADAPTIVE_STOP_REASON = None if ADAPTIVE_SMOKE_COMPLETED else "incomplete_terminal_coverage"
            if _coverage_missing:
                print("STAGE B INCOMPLETE - tasks without a terminal record:",
                      {a: len(v) for a, v in _coverage_missing.items()}){T})

# v1.1 (review finding): the terminal finalizer wave was guarded only by "are we already past the deadline?".
edit(C_SCHED, """                        if final_tids:
                            batch_wave_no+=1; global_wave_no+=1""",
     """                        if final_tids:
                            _fin_spt=float(globals().get("MEASURED_SEC_PER_OUTPUT_TOKEN") or DEFAULT_SEC_PER_OUTPUT_TOKEN)
                            _fin_projected=max(m["cap"] for m in final_meta)*_fin_spt*float(WAVE_TIME_SAFETY_FACTOR)+float(WAVE_OVERHEAD_SEC)
                            _fin_hard_limit=notebook_start+float(TOTAL_RUNTIME_SEC)-float(SESSION_HARD_MARGIN_SEC)
                            if time.perf_counter()+_fin_projected >= _fin_hard_limit:
                                print(f"[{arm}] finalizer skipped for {len(final_tids)} task(s): projected "
                                      f"{_fin_projected/60:.1f} min would cross the hard session limit")
                                for _ftid in list(final_tids):
                                    _fst=states[_ftid]
                                    if _fst.get("done"): continue
                                    _fst["infrastructure_failure"]=True
                                    _fst.setdefault("infrastructure_errors",[]).append(
                                        {"phase":"finalizer","error":f"projected {_fin_projected:.0f}s finalizer would cross the hard session limit"})
                                    _fst["generated_tokens_observed_lower_bound"]=True
                                    _fst["done"]=True
                                    _frec=complete_record(_fst,eval_challenges[_ftid],None,"failed","global_deadline_projected",
                                                          f"projected finalizer {_fin_projected:.0f}s would cross the hard session limit")
                                    _frec["status"]="failed"; append_record(_frec)
                                final_tids=[]; final_prompts=[]; final_params=[]; final_meta=[]
                        if final_tids:
                            batch_wave_no+=1; global_wave_no+=1""")

# =====================================================================================
# CELL 8B — repair must be chunked and deadline-aware over hundreds of tasks
# ====================================================================================='''.replace("{T}", T3))

# ---------------------------------------------------------------- P2b every remaining repair chunk is reported
sub('''        if time.perf_counter()+_projected >= deadline:
            for j in _chunk:
                m=copy.deepcopy(j["meta"]); m.update({"repair_attempted":False,"repair_status":"repair_skipped_deadline"})
                summary_rows.append({"arm":arm,"task_id":j["tid"],**m})
            print(f"[{arm}] repair: stopping before a {_projected/60:.1f} min chunk would cross the deadline")
            break''',
    '''        if time.perf_counter()+_projected >= deadline:
            # v1.1: report EVERY remaining job, not only this chunk, so repair_summary stays complete.
            _stop_index=_chunks.index(_chunk)
            _skipped=0
            for _rest in _chunks[_stop_index:]:
                for j in _rest:
                    m=copy.deepcopy(j["meta"]); m.update({"repair_attempted":False,"repair_status":"repair_skipped_deadline"})
                    summary_rows.append({"arm":arm,"task_id":j["tid"],**m}); _skipped+=1
            print(f"[{arm}] repair: stopping before a {_projected/60:.1f} min chunk would cross the deadline; "
                  f"{_skipped} job(s) skipped")
            break''')

# ---------------------------------------------------------------- P2c CPU budget inside the loops
sub('''def sub_run_program_on_test_inputs(code, task, timeout_sec):
    """Fresh subprocess per test input, mirroring the verifier's own test stage."""
    outputs = []
    for query in task_without_test_solutions(task)["test"]:''',
    '''def sub_run_program_on_test_inputs(code, task, timeout_sec, stop_at=None):
    """Fresh subprocess per test input, mirroring the verifier's own test stage.

    v1.1: `stop_at` is checked before EVERY query, so one multi-query task cannot run past the budget. Queries that
    are not executed return None and simply contribute no candidate grid.
    """
    outputs = []
    for query in task_without_test_solutions(task)["test"]:
        if stop_at is not None and time.perf_counter() >= stop_at:
            outputs.append(None)
            continue''')
sub('''if SUBMIT_MODE:
    _t0 = time.perf_counter()
    _programs = {}''',
    '''if SUBMIT_MODE:
    _t0 = time.perf_counter()
    _stop_at = min(deadline, _t0 + SUB_UNVERIFIED_BUDGET_SEC)   # v1.1: one absolute stop line for the whole pass
    _programs = {}''')
sub('''        if time.perf_counter() >= deadline or (time.perf_counter() - _t0) > SUB_UNVERIFIED_BUDGET_SEC:
            SUB_TEST_EXEC_SUMMARY["skipped_deadline"] += 1
            continue''',
    '''        if time.perf_counter() >= _stop_at:
            SUB_TEST_EXEC_SUMMARY["skipped_deadline"] += 1
            continue''')
sub('''            try:
                _outputs = sub_run_program_on_test_inputs(_code, test_challenges[_tid], SUB_UNVERIFIED_TIMEOUT_SEC)''',
    '''            if time.perf_counter() >= _stop_at:       # v1.1: also enforced between the programs of one task
                SUB_TEST_EXEC_SUMMARY["skipped_deadline"] += 1
                break
            try:
                _outputs = sub_run_program_on_test_inputs(_code, test_challenges[_tid], SUB_UNVERIFIED_TIMEOUT_SEC,
                                                          stop_at=_stop_at)''')

# ---------------------------------------------------------------- run report carries the new facts
sub('''    "interface_gate": globals().get("ADAPTIVE_INTERFACE_GATE"),''',
    '''    "interface_gate": globals().get("ADAPTIVE_INTERFACE_GATE"),
    "coverage_missing_tasks": {k: len(v) for k, v in (globals().get("ADAPTIVE_COVERAGE_MISSING") or {}).items()},
    "bootstrap_submission_written": bool(globals().get("BOOTSTRAP_SUBMISSION_WRITTEN")),
    "bootstrap_submission_error": globals().get("BOOTSTRAP_SUBMISSION_ERROR"),
    "session_hard_margin_sec": SESSION_HARD_MARGIN_SEC,''')

# ---------------------------------------------------------------- P0 bootstrap cell
BOOTSTRAP_SRC = '''# =====================================================================================
# CELL 0 - FALLBACK SUBMISSION BOOTSTRAP (standard library only; nothing above it can fail first)
# Review finding 2026-10-02: the submission machinery lived after the model/wheelhouse/pip/runtime checks and the
# public-data loads, so any of those failing left /kaggle/working/submission.json absent. This cell needs only the
# standard library and the attached test file.
#
# Severity note: a Kaggle code-competition submission is scored from the hidden-data re-run, and a notebook that
# raises scores nothing whether or not this file exists. The environment checks below therefore still raise loudly -
# quietly submitting identity grids would spend a daily submission on a guaranteed zero. This cell protects the
# interactive case, and guarantees the file on disk is never a stale newer-but-invalid one.
# =====================================================================================
import json as _json
import os as _os
from pathlib import Path as _Path

_SUB_BOOTSTRAP_PATH = _Path("/kaggle/working/submission.json")
_SUB_BOOTSTRAP_TEST_FILE = _Path("/kaggle/input/competitions/arc-prize-2026-arc-agi-2/arc-agi_test_challenges.json")
BOOTSTRAP_SUBMISSION_WRITTEN = False
BOOTSTRAP_SUBMISSION_ERROR = None
try:
    if not _SUB_BOOTSTRAP_TEST_FILE.is_file():
        _found = sorted(_Path("/kaggle/input").rglob("arc-agi_test_challenges.json"))
        if len(_found) != 1:
            raise FileNotFoundError(f"expected exactly one arc-agi_test_challenges.json, found {len(_found)}")
        _SUB_BOOTSTRAP_TEST_FILE = _found[0]
    with open(_SUB_BOOTSTRAP_TEST_FILE, "r", encoding="utf-8") as _fh:
        _boot_tasks = _json.load(_fh)
    _boot_payload = {}
    for _tid, _task in _boot_tasks.items():
        _answers = []
        for _query in _task["test"]:
            _grid = [[int(_cell) for _cell in _row] for _row in _query["input"]]
            if not (1 <= len(_grid) <= 30) or not (1 <= len(_grid[0]) <= 30):
                raise ValueError(f"{_tid}: test input is not a legal ARC grid")
            _answers.append({"attempt_1": [r[:] for r in _grid], "attempt_2": [r[:] for r in _grid]})
        _boot_payload[_tid] = _answers
    _SUB_BOOTSTRAP_PATH.parent.mkdir(parents=True, exist_ok=True)
    _boot_tmp = _SUB_BOOTSTRAP_PATH.with_name(f".bootstrap.{_os.getpid()}.tmp")
    with open(_boot_tmp, "w", encoding="utf-8", newline="\\n") as _fh:
        _json.dump(_boot_payload, _fh, separators=(",", ":"))
        _fh.write("\\n"); _fh.flush(); _os.fsync(_fh.fileno())
    _os.replace(_boot_tmp, _SUB_BOOTSTRAP_PATH)
    BOOTSTRAP_SUBMISSION_WRITTEN = True
    print(f"Bootstrap identity submission written for {len(_boot_payload)} tasks "
          f"({sum(len(v) for v in _boot_payload.values())} queries): {_SUB_BOOTSTRAP_PATH}")
except Exception as _boot_exc:
    # Never block the run: CELL 2B rewrites and validates the file with the full machinery anyway.
    BOOTSTRAP_SUBMISSION_ERROR = f"{type(_boot_exc).__name__}: {_boot_exc}"
    print("Bootstrap submission could not be written:", BOOTSTRAP_SUBMISSION_ERROR)
'''
sub("SUB_STATE = r" + T3 + "# ==",
    "BOOTSTRAP = r" + T3 + BOOTSTRAP_SRC + T3 + "\n\nSUB_STATE = r" + T3 + "# ==")

# insert it as the first code cell, and locate the repair cell by content (indices shift)
sub('''insert_at = C_DATA + 1
cells.insert(insert_at, {"cell_type": "code", "metadata": {}, "execution_count": None, "outputs": [],
                         "source": SUB_STATE.splitlines(keepends=True)})
# recompute indices after the insert
code_idx = [i for i, c in enumerate(cells) if c["cell_type"] == "code"]
C_REPAIR_NEW = code_idx[9]
tail_start = C_REPAIR_NEW + 1''',
    '''cells.insert(C_CONFIG, {"cell_type": "code", "metadata": {}, "execution_count": None, "outputs": [],
                        "source": BOOTSTRAP.splitlines(keepends=True)})
code_idx = [i for i, c in enumerate(cells) if c["cell_type"] == "code"]
C_DATA = code_idx[2]

insert_at = C_DATA + 1
cells.insert(insert_at, {"cell_type": "code", "metadata": {}, "execution_count": None, "outputs": [],
                         "source": SUB_STATE.splitlines(keepends=True)})
# locate the repair cell by content: inserting cells shifted every index.
C_REPAIR_NEW = next(i for i, c in enumerate(cells)
                    if c["cell_type"] == "code" and "CELL 8B" in "".join(c["source"]))
tail_start = C_REPAIR_NEW + 1''')

# ---------------------------------------------------------------- header + metadata
sub('''"# PIV-Q27-SUB v1.0 — HIDDEN-TEST SUBMISSION\\n\\n"''',
    '''"# PIV-Q27-SUB v1.1 — HIDDEN-TEST SUBMISSION\\n\\n"''')
sub('''            "---\\n\\n" + head_src.split("\\n", 1)[1].lstrip("\\n"))''',
    '''            "**v1.1 fixes after independent review:** fallback submission bootstrapped in the first cell; completion\\n"
            "status derived from terminal coverage; the terminal finalizer wave is projected against the hard session\\n"
            "limit; strict grid types; every skipped repair job reported; the CPU test-execution budget is enforced\\n"
            "inside the program and query loops.\\n\\n"
            "---\\n\\n" + head_src.split("\\n", 1)[1].lstrip("\\n"))''')
sub('''    "default_profile": "SUBMIT",''', '''    "default_profile": "SUBMIT",
    "review_fixes": ["bootstrap_fallback_cell", "coverage_derived_completion", "finalizer_hard_limit_projection",
                     "strict_grid_types", "complete_repair_reporting", "inner_cpu_budget_checks"],''')

p.write_text(s, encoding="utf-8")
import ast
ast.parse(s)
print("make_sub_v10.py -> v1.1 builder patched")
