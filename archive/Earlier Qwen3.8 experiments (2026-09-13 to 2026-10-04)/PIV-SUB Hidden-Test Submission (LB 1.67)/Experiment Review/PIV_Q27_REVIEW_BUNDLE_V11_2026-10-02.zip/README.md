# ARC Prize 2026 / ARC-AGI-2 — Qwen3.8-27B PIV track: review bundle **v1.1**, 2026-10-02

Second round. The first bundle (`PIV_Q27_REVIEW_BUNDLE_2026-10-02.zip`) was audited independently; all seven findings
were real, two needed their impact restated, and every one is now fixed and re-verified.
**`reports/PIV_Q27_SUB_V11_REVIEW_RESPONSE_2026-10-02.md` is the document to read first** — it lists each finding, the
evidence that confirmed it, the two restatements, what changed, and how each control fix was proven by failure
injection rather than by inspection.

**What I would like checked this round**

1. Are the three control fixes right, not just present? — coverage-derived completion, the finalizer's hard-session
   limit (deliberately *not* the solver's safety reserve), and the single `_stop_at` line for the CPU pass.
2. Does the new first cell (fallback bootstrap) hold under the cases the previous review raised: missing model mount,
   failed wheel install, a stale `submission.json` from an earlier interactive run, an unreadable test file?
3. Is my reading of Kaggle scoring correct — that a notebook which raises scores nothing regardless of the file on
   disk, so "write the fallback earlier" is about diagnosis and staleness, not about rescuing a failed run? If that is
   wrong, the P0 severity goes back up and the environment checks should degrade instead of raising.
4. Anything in the still-open list at the end of the response document: concurrency 12 vs the KV cache, whether
   `SUBMIT_FAST` (2,048 exploration tokens) is worth a session at all, and the repair round's cost in that profile.

---

## 1. Inventory

```
notebooks/
  PIV-Q27-SUB-v1_1-HIDDEN-TEST-SUBMISSION.ipynb                     submission notebook (fixed)
  PIV-Q27-C1-v2_5A-CANDIDATE-FIRST-VERIFIER-FEEDBACK-REPAIR.ipynb   solver, unchanged this round
  PIV-Q27-C1-v2_5-ORIGINAL-FROM-CHATGPT.ipynb                       the unfixed solver input, for diffing
reports/
  PIV_Q27_SUB_V11_REVIEW_RESPONSE_2026-10-02.md   response to the review: findings, evidence, fixes, proofs
  PIV_Q27_SUB_V10_AND_V25A_HANDOFF_2026-10-02.md  design/plan/competitor analysis (first round)
  PIV_Q27_C1_V25_FAKE_ENGINE_AUDIT_2026-09-18.md  the audit that produced v2.5A
harness/
  harness_c1.py            fake-engine harness (now honours PIV_HARNESS_SCRATCH; notebook path is argv[2])
  restore_harness.py, patch_harness_sub{,2,3}.py   how it was rebuilt and extended
  inject_deadline.py       the failure-injection hooks used to prove the time guards
build_scripts/
  make_v25a.py             v2.5  -> v2.5A        (every fix as explicit string edits)
  make_sub_v11.py          v2.5A -> PIV-SUB v1.1 (every change as explicit string edits)
  patch_sub_v11.py         v1.0 builder -> v1.1 builder: exactly the review fixes, isolated
  fix_paths_p3.py          the P3 path-portability change
harness_logs/              stdout of every run, including the four injection runs
rehearsal_artifacts/       run reports + the submission.json produced by the 240-task rehearsals
competitor_baseline/       the public Kaggle notebook that uses our uploaded model
SHA256SUMS.txt             standard `sha256sum -c` format, LF endings
MANIFEST.csv               file, bytes, sha256
```

`build_scripts/patch_sub_v11.py` is the fastest way to review this round: it contains *only* the fixes made in
response to the audit, as `old_string -> new_string` pairs.

SHA-256 of the notebooks:

| file | sha256 |
|---|---|
| `PIV-Q27-SUB-v1_1-HIDDEN-TEST-SUBMISSION.ipynb` | `2042c2914bd6621b673930c9c10a6e0aad23713fba8fc9301480c51a9b793386` |
| `PIV-Q27-C1-v2_5A-...ipynb` | `2188b999efeb6e286fc914bb8c1d876a5c9bdab99537842cd8c94360cd47d5ff` |
| `PIV-Q27-C1-v2_5-ORIGINAL-FROM-CHATGPT.ipynb` | `eb7d65ba6b0f1f0da56975ee467b3eb1b10f41539059561332403b376bff7ee6` |

Verify with `cd <extracted> && sha256sum -c SHA256SUMS.txt` (this now works; the previous bundle's file had a size
column and CRLF endings).

---

## 2. Project context

* Competition: ARC Prize 2026 (ARC-AGI-2), Kaggle, offline, 12 h, 4×L4 (24 GB each). Model: Qwen3.8-27B-FP8
  (`foysalemonshanto/qwen3-8-27b-fp8-repacked-v1`), vLLM 0.19.0, TP=4, `max_model_len=29696`, `max_num_seqs=16`,
  `gpu_memory_utilization=0.90`, prefix caching OFF (OOMs), `enforce_eager=False` ("C1": 129 tok/s at 8 concurrent
  long decodes vs 48 eager).
* Approach ("PIV"): a stateful Python REPL agent writes `solution(grid)`; a fresh subprocess verifier requires exact
  equality on **all** train pairs before the program runs on the test inputs; a terminal-commit finalizer (no tools,
  `enable_thinking=False`, structured JSON) guarantees a program artifact; v2.5 adds one verifier-feedback repair
  round.
* Last GPU run (v2.4G, 2026-09-18, 78 min, 16 task-runs): interface fully healthy (16/16 finalizer JSON parsed,
  syntax-valid, verifier executed, positive control passed) but **0/16 programs were all-train-exact**. The expected
  score of any submission today is therefore ~0; the goals are to prove the submission path and to measure the
  train-verified rate on the real test file.
* Leaderboard: top entries 72–77; the owner's 32.64 comes from a different (NVARC) pipeline, not this model.

---

## 3. How the local verification works, and what it cannot prove

`harness/harness_c1.py` executes the notebook's code cells in-process on Windows with:

* **real** Qwen tokenizer and `chat_template.jinja` from the pinned Kaggle model;
* **real** Kaggle competition JSONs (downloaded through the Kaggle API). The local
  `arc-agi_test_challenges.json` placeholder has **240 tasks / 259 queries**; Kaggle swaps in the hidden set at
  scoring time;
* **real** subprocess REPL and **real** subprocess verifier, with real timeouts;
* **stubbed** `torch`/`vllm`: a scripted engine that plays eight scenarios by task position (tool call then
  exploration blow-up at cap, tool/tool/final, six tool calls, malformed tool XML, prose with no action, a 15 s
  sleeping tool, guard-rejected code, long thinking every turn) plus repair-stage scenarios (truncated JSON, raising
  program, timing-out program, blocked import, over-cap output, and a lookup-table program that genuinely passes train
  verification). `HARNESS_OVERCAP=1` makes the engine exceed `max_tokens`, which must be caught.
* **injection hooks** (new): `HARNESS_SHRINK_PRIOR`, `HARNESS_SHRINK_TOTAL`, `HARNESS_SHRINK_RESERVE`,
  `HARNESS_SHRINK_MARGIN`, `HARNESS_SHRINK_DEADLINE` drive the time guards into their corners on CPU.

**Proves:** control flow, budget arithmetic, parser/verifier/record/submission plumbing, deadline behaviour, failure
taxonomy, and that no cell raises.
**Cannot prove:** real model behaviour or solve quality; real vLLM timing and memory (especially KV pressure at 12
concurrent sequences); real structured-output behaviour at that concurrency. Those need the GPU.

### Reproducing

Prerequisites: Python 3.14 with `tokenizers`, `jinja2`, `numpy`, `pandas`, `scikit-learn`; the model's
`tokenizer.json` + `chat_template.jinja` under
`<scratch>/fake_input/models/foysalemonshanto/qwen3-8-27b-fp8-repacked-v1/pytorch/hf-fp8/1/` and the competition
JSONs under `<scratch>/fake_input/competitions/arc-prize-2026-arc-agi-2/`.

```
export PIV_HARNESS_SCRATCH=/path/to/scratch
python harness_c1.py SUBMIT_SMOKE <submission notebook>
python harness_c1.py SUBMIT_FAST  <submission notebook>
python harness_c1.py SUBMIT       <submission notebook>
python harness_c1.py PREFLIGHT    <solver notebook>     # v2.5A profiles
python harness_c1.py TERMINAL_PILOT <solver notebook>
python harness_c1.py ADAPTIVE_SMOKE <solver notebook>
HARNESS_OVERCAP=1 python harness_c1.py ADAPTIVE_SMOKE <solver notebook>
# the injection runs that prove the new guards:
HARNESS_SHRINK_PRIOR=0.0005 HARNESS_SHRINK_DEADLINE=200 python harness_c1.py SUBMIT <submission notebook>
HARNESS_SHRINK_PRIOR=0.0005 HARNESS_SHRINK_TOTAL=600 HARNESS_SHRINK_RESERVE=20 HARNESS_SHRINK_MARGIN=610 \
    python harness_c1.py SUBMIT_SMOKE <submission notebook>
```

Both build scripts honour `PIV_PROJECT_ROOT`. Rebuilding v2.5A from v2.5 reproduces sha `2188b999…` byte-for-byte on
this machine; on a Linux checkout expect an LF/CRLF difference only.

---

## 4. PIV-SUB v1.1 — the claims to check

Derived from v2.5A. The solver cells (config → data → EDA → prompts → context → parser/REPL/verifier/repair helpers →
engine → scheduler → repair round) are the audited solver, unchanged in substance. Submission machinery:

0. **CELL 0 bootstrap (new in v1.1)** — standard library only; writes an identity `submission.json` before anything
   that can fail. Records `BOOTSTRAP_SUBMISSION_WRITTEN` / `BOOTSTRAP_SUBMISSION_ERROR` in the run report; never
   raises.
1. **CELL 2B submission state** — self-tests (ragged, out-of-range, bool, `numpy.bool_`, float, integral float,
   NumPy int, empty, >30 wide; rank order; record ingestion; bootstrap presence), then rewrites the file.
2. **`TESTALL` task set** — ids from the attached test file only; public evaluation tasks are merged into the solver's
   task map after the EDA cell, with a collision check.
3. **Oversized prompts** — dropped with a recorded reason instead of raising.
4. **Controller** — positive control → 2-task interface rehearsal → gate → full sweep; a failed gate stops the run and
   keeps the fallback. **Completion is derived from terminal coverage** (v1.1).
5. **Incremental writes** — `append_record` ingests each record and atomically rewrites the file (throttled 30 s),
   inside a `try/except` that cannot break the solver loop.
6. **Deadlines** — the scheduler's per-wave projection stops scheduling; the repair round is chunked with a per-chunk
   projection and now reports **every** skipped job; the terminal finalizer is projected against the **hard session
   limit** (`SESSION_HARD_MARGIN_SEC = 10 min`, derived from the live deadline so self-tests are unaffected).
7. **CPU test-execution pass** — one `_stop_at = min(deadline, start + 20 min)` enforced before each task, each
   program and each query; executes programs that failed the train gate, including the repair candidate that lost
   selection, so `attempt_2` is a different program rather than a copy of the input.
8. **Answer selection** — `attempt_1` = highest-ranked program output (train-verified first, then more train-exact
   pairs, then newer), `attempt_2` = best *different* output, identity copy where nothing legal exists. Grids pass a
   strict sanitizer (NumPy ints allowed; bool, `numpy.bool_` and all floats rejected).
9. **`run_report.json` + bundle** — coverage, train-verified count, stop-reason histogram, repair summary, interface
   gate, `coverage_missing_tasks`, bootstrap status, `session_hard_margin_sec`, ingest errors, pre-registration.

### Verification status (logs in `harness_logs/`)

| run | result |
|---|---|
| `SUBMIT_SMOKE` (4 tasks) | completes; bootstrap wrote 240 tasks / 259 queries; gate passes; self-tests include the strict-type cases |
| `SUBMIT_FAST` (all 240 tasks) | completes in 1,572 s; gate passes; 240/240 terminal records; CPU pass executed 314 programs, added 254 candidates; `"status": "completed"` |
| `SUBMIT` (all 240 tasks) | see `harness_logs/v11_SUBMIT.txt` |
| injection: short deadline | stage B truncated at 62/240 → `incomplete_terminal_coverage`, `coverage_missing_tasks` populated, 45 repair jobs reported as skipped |
| injection: hard session limit | `finalizer skipped for 1 task(s)`; the notebook's REAL-scheduler terminal-commit self-test still passes; submission stays valid |
| injection: realistic proportions | the solver deadline stops work first and the finalizer guard never fires — it is a last-resort net |

`submission.json` is validated outside the notebook after every run: ids identical to `sample_submission.json`, one
answer per test input, only `attempt_1`/`attempt_2`, zero illegal grids, and 45 queries carrying two genuinely
different attempts in the 240-task rehearsal.

### Profiles

| profile | per-task tokens | finalizer reserve | concurrency | tool calls / turns |
|---|---|---|---|---|
| `SUBMIT_SMOKE` | 8,192 | 2,048 | 4 | 6 / 12 |
| `SUBMIT_FAST` | 4,096 | 2,048 | 12 | 4 / 8 |
| `SUBMIT` (default) | 8,192 | 2,048 | 12 | 6 / 12 |

Pre-registered deviations from the v2.4G/v2.5 measurement runs (stated in the notebook and the run report, and why
these runs are **not comparable** with the arm measurements): smaller per-task budget, smaller finalizer reserve,
concurrency 12 instead of 8, single arm `ACT-LOW`.

---

## 5. Runtime projection

Measured on GPU (v2.4G): 16 task-runs in 78 min wall clock including ~8.25 min model load; per-arm loops 39 min
(ACT-LOW, ~10.4k generated tokens/task) and 28.5 min, i.e. **≈4.25–4.9 min per task-run at batch 8 with a
12,288-token budget** (~0.00047 min per generated token per task). Scaling linearly in tokens, assuming 0.75
efficiency for concurrency 8 → 12, plus ~10 min load and ~20 min of post-passes:

| | 120 hidden tasks | 240 tasks |
|---|---|---|
| `SUBMIT_FAST` (4,096) | ≈ 3.5–4 h | ≈ 7–7.5 h |
| `SUBMIT` (8,192) | ≈ 7–7.5 h | exceeds the 10.75 h internal deadline → ~75–85 % coverage, rest stays identity |

---

## 6. Known risks and open questions

1. **KV pressure at concurrency 12** (~160–168k tokens of KV; 12 × 12–15k context sits at the edge). Never run.
   vLLM should preempt and recompute rather than fail. `SUBMIT_SMOKE` on real hardware is the cheap probe.
2. **`SUBMIT_FAST` leaves 2,048 exploration tokens**, so most of PIV's REPL mechanism is removed; it exists only to
   fit one working day.
3. **Expected score ~0** — v2.4G produced no train-exact program and nothing since has changed the solver's reasoning.
4. **Repair cost in `SUBMIT_FAST`**: the leftover of a 4,096-token budget rarely admits a repair, while the round
   still re-verifies every candidate (~1–3 s each). Deadline-guarded and now fully reported.
5. **Runtime provenance**: still vLLM 0.19.0 from a third-party wheelhouse dataset. `competitor_baseline/` shows the
   cleaner pattern (own wheel bundle + per-wheel sha256 manifest). Not changed on the eve of a run.
6. **`language_model_only=True`** (used by the competitor) is untested here and might free KV memory.

---

## 7. Recommended run order on Kaggle

1. `RUN_PROFILE = "SUBMIT_SMOKE"` → interactive (~25–35 min incl. load). Confirms the real stack. Never submit it.
2. `RUN_PROFILE = "SUBMIT_FAST"` → **Save & Run All** → submit `/kaggle/working/submission.json` from that version.
3. Later: `RUN_PROFILE = "SUBMIT"`, and `PIV-Q27-C1 v2.5A` with `ADAPTIVE_SMOKE` (78 min) for the repair measurement on
   the public evaluation set, where answers are known.

Attach in every case, **Internet OFF**, **GPU L4 ×4**: the competition data, the pinned Qwen3.8-27B-FP8 model, and the
vLLM wheelhouse dataset.
