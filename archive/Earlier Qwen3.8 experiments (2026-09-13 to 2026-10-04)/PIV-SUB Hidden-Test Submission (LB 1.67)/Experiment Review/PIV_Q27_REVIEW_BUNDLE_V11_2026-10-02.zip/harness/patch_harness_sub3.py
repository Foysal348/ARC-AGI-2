"""Harness support for v1.1: the bootstrap cell uses its own path literals."""
from pathlib import Path
p = Path(__file__).with_name("harness_c1.py")
s = p.read_text(encoding="utf-8")
old = """    if 'Path("/kaggle/working/submission.json")' in src:"""
new = """    if '_Path("/kaggle/working/submission.json")' in src:
        src = src.replace('_Path("/kaggle/working/submission.json")', '_Path(r"' + str(WORKING / "submission.json") + '")')
        src = src.replace('_Path("/kaggle/input/competitions/arc-prize-2026-arc-agi-2/arc-agi_test_challenges.json")',
                          '_Path(r"' + str(FAKE_INPUT / "competitions/arc-prize-2026-arc-agi-2/arc-agi_test_challenges.json") + '")')
        src = src.replace('_Path("/kaggle/input")', '_Path(r"' + str(FAKE_INPUT) + '")')
    if 'Path("/kaggle/working/submission.json")' in src:"""
assert s.count(old) == 1
p.write_text(s.replace(old, new), encoding="utf-8")
# the config cell is no longer notebook cell 1 (the bootstrap cell precedes it): key on content.
s2 = p.read_text(encoding="utf-8")
old2 = """    if i == 1:
        for a, b in rep.items():"""
new2 = """    if 'MODEL_PATH = Path("/kaggle/input/models/' in src or 'RUN_PROFILE = "' in src:
        for a, b in rep.items():"""
assert s2.count(old2) == 1, s2.count(old2)
p.write_text(s2.replace(old2, new2), encoding="utf-8")
import ast; ast.parse(p.read_text(encoding="utf-8"))
print("harness patch 3 applied")
