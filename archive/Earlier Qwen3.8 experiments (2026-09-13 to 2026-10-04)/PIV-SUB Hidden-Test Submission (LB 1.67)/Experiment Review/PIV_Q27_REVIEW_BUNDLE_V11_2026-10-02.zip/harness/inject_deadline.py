"""Failure injection: shrink the solver deadline (P1a) or the hard session limit (P1b) to prove the new guards fire."""
from pathlib import Path

p = Path(__file__).with_name("harness_c1.py")
s = p.read_text(encoding="utf-8")

anchor = '    print(f"\\n################ CELL {i} ################", flush=True); t0 = time.perf_counter()'
inject = '''    if os.environ.get("HARNESS_SHRINK_DEADLINE") and "deadline = notebook_start" in src:
        src = src.replace("deadline = notebook_start + TOTAL_RUNTIME_SEC - SAFETY_RESERVE_SEC",
                          'deadline = notebook_start + float(os.environ["HARNESS_SHRINK_DEADLINE"])')
    if os.environ.get("HARNESS_SHRINK_SESSION") and "SESSION_HARD_MARGIN_SEC = 10 * 60" in src:
        src = src.replace("SESSION_HARD_MARGIN_SEC = 10 * 60",
                          'SESSION_HARD_MARGIN_SEC = TOTAL_RUNTIME_SEC - float(os.environ["HARNESS_SHRINK_SESSION"])')
''' + anchor
assert s.count(anchor) == 1, s.count(anchor)
assert "HARNESS_SHRINK_DEADLINE" not in s, "already injected"
p.write_text(s.replace(anchor, inject), encoding="utf-8")
import ast
ast.parse(p.read_text(encoding="utf-8"))
print("deadline injection hooks added")
