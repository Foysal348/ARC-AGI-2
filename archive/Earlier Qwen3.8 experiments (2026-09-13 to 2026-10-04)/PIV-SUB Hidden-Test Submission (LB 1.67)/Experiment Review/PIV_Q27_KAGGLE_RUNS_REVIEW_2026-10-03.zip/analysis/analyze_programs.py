"""Re-run every program the EVAL120 run produced against its task's train pairs and classify the failure."""
import json, subprocess, sys, collections, tempfile, os

C = "fake_input/competitions/arc-prize-2026-arc-agi-2/"
ev = json.load(open(C + "arc-agi_evaluation_challenges.json", encoding="utf-8"))
recs = {}
for line in open("kev/b/arms/ACT-LOW/raw_generations.jsonl", encoding="utf-8"):
    r = json.loads(line); recs.setdefault(r["task_id"], []).append(r)
last = {t: v[-1] for t, v in recs.items()}

RUNNER = r'''
import json,sys,copy
payload=json.load(sys.stdin)
ns={}
try:
    exec(payload["code"],ns,ns)
except BaseException as e:
    print(json.dumps({"err":"compile:"+type(e).__name__})); sys.exit()
fn=ns.get("solution")
if fn is None:
    print(json.dumps({"err":"no_solution"})); sys.exit()
out=[]
for ex in payload["train"]:
    try:
        p=fn(copy.deepcopy(ex["input"]))
        out.append({"pred":p})
    except BaseException as e:
        out.append({"exc":type(e).__name__})
print(json.dumps({"res":out}))
'''

def classify(code, task):
    try:
        p = subprocess.run([sys.executable, "-c", RUNNER], input=json.dumps({"code": code, "train": task["train"]}),
                           capture_output=True, text=True, timeout=20)
        d = json.loads(p.stdout.strip().splitlines()[-1])
    except Exception as e:
        return "runner_fail", {}
    if "err" in d:
        return d["err"], {}
    kinds = []
    for ex, r in zip(task["train"], d["res"]):
        if "exc" in r: kinds.append("exception"); continue
        pred = r.get("pred")
        if pred == ex["output"]: kinds.append("exact")
        elif pred == ex["input"]: kinds.append("identity")
        elif not isinstance(pred, list) or not pred or not isinstance(pred[0], list): kinds.append("invalid")
        elif (len(pred), len(pred[0])) != (len(ex["output"]), len(ex["output"][0])): kinds.append("dims")
        else: kinds.append("cells")
    return "ran", collections.Counter(kinds)

summary = collections.Counter(); per_task = {}
all_identity = 0; all_exception = 0; any_exact = 0
for tid, r in last.items():
    code = r.get("final_code")
    if not code:
        summary["NO PROGRAM (finalizer truncated)"] += 1; continue
    status, kinds = classify(code, ev[tid])
    if status != "ran":
        summary[f"program unusable: {status}"] += 1; continue
    n = sum(kinds.values())
    per_task[tid] = dict(kinds)
    if kinds.get("identity", 0) == n: all_identity += 1
    if kinds.get("exception", 0) == n: all_exception += 1
    if kinds.get("exact", 0) > 0: any_exact += 1
    if kinds.get("exact", 0) == n: summary["ALL train pairs exact"] += 1
    elif kinds.get("exception", 0) == n: summary["every pair raises"] += 1
    elif kinds.get("identity", 0) == n: summary["returns input unchanged on every pair"] += 1
    elif kinds.get("dims", 0) + kinds.get("invalid", 0) == n: summary["wrong output size on every pair"] += 1
    else: summary["partially wrong (cells/mixed)"] += 1

print("=== WHAT THE 120 TASKS PRODUCED")
for k, v in summary.most_common(): print(f"  {v:4d}  {k}")
print(f"\nprograms that matched at least one train pair: {any_exact}")
tot = collections.Counter()
for d in per_task.values(): tot.update(d)
print("per-pair outcome across all executed programs:", dict(tot))
json.dump(per_task, open("kev/program_failure_modes.json", "w"), indent=1)
