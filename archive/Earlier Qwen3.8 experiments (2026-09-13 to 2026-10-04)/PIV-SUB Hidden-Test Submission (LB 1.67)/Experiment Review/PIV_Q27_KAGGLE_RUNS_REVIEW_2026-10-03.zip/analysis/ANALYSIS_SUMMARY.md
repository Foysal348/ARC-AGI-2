# First-pass analysis of the two Kaggle runs (2026-10-03)

Everything below was computed from the files in this zip. "Measured" means read directly from run outputs or from a
local re-run of the generated programs; "inferred" is marked as such.

## Run facts (measured)

| | EVAL120 | Submission run |
|---|---|---|
| notebook | `PIV-Q27-EVAL120-MEASUREMENT.ipynb` | `PIV-Q27-SUB-v1_3-HIDDEN-TEST-SUBMISSION.ipynb` |
| Kaggle kernel | `esfersami50/piv-q27-eval120-measurement` v1 | `esfersami50/piv-q27-sub-v1-3-full-hidden-test` v1 |
| tasks / queries | 120 / 172 (public evaluation, answers published) | 240 / 259 (placeholder = training copies) |
| terminal records | 120 / 120 | 240 / 240 |
| infrastructure failures | 0 | 0 |
| programs produced | 82 | 220 |
| all-train-exact | 3 (`1818057f`, `2ba387bc`, `7b5033c1`) | 103 |
| test correct | 2 tasks (`1818057f`, `2ba387bc`) = 1.67 %; 2/172 outputs = 1.16 % | 113/259 queries = 43.6 % (scored by us against training solutions) |
| wall clock | ≈7 h (loop 15,664 s) | 22,445 s ≈6.2 h (setup 737 s) |
| per-task generated tokens | median 8,192 (84/120 used the full budget) | — |
| decode speed | 0.049 s per output token per sequence (median) | — |
| submission | — | valid: ids match `sample_submission.json`, 0 illegal grids, sha256 `e14dda38…`; submitted 2026-10-03, pending |

Budget in both runs: 8,192 generated tokens per task = 6,144 exploration + 2,048 finalizer reserve; single arm
`ACT-LOW` (`reasoning_effort="low"`, natural thinking close); concurrency 12; max 6 tool calls / 12 turns.

## EVAL120 funnel (measured; local re-run of every program against its training pairs)

| outcome | tasks |
|---|---|
| no program: finalizer JSON truncated | 38 |
| partially wrong | 46 |
| wrong output size on every pair | 12 |
| identity (input returned) on every pair | 10 |
| exception on every pair | 7 |
| program hangs locally (>20 s) | 4 |
| all training pairs exact | 3 |

Per-pair outcomes across all programs that ran: exact 21, wrong cells 118, wrong dims 28, identity 35, exception 21,
invalid 16. Programs matching at least one training pair: 13. Mean training pairs matched per program: 0.26.

## Finding 1 — finalizer truncation (measured)

* 38/38 failed finalizers produced exactly 2,048 tokens with `finish_reason=length` → `json_parse_error`.
* 80/80 successful finalizers: median 945, max 1,824 tokens, all `stop`.
* Not driven by task size: truncated tasks average 400 input cells vs 364 for parsed ones.
* The earlier v2.4G run (4,096 reserve, 12,288 total) parsed 16/16. The 2,048 reserve was our choice to fit the
  submission schedule.

## Finding 2 — 41 % of tasks never call the tool (measured)

* 49/120 tasks: zero tool calls. 11 of them are also among the 38 truncated.
* Sampled traces (`cb2d8a2c`, `13e47133`, `16de56c4`): turn 1 = 6,144 tokens, `finish_reason=length`,
  `natural_think_close=False`, `reasoning_mode=implicit_open_think`; the text transcribes the grids row by row.
* Turn kinds over all tasks: tool 173, text 109, terminal_finalizer 118, final 2, malformed_tool 1.
* First turn: 71 `stop`, 49 `length`. Think tokens per turn: p50 94, p90 6,144 (bimodal).

## Finding 3 — REPL use and success (measured)

| tasks with a program | n | all-train-exact | ≥1 pair exact | degenerate (identity/exception on all pairs) |
|---|---|---|---|---|
| 0 tool calls | 36 | 0 | 3 | 11 |
| ≥1 tool call | 42 | 3 | 10 | 6 |

The three verified programs: `1818057f` (3 pairs, 173 cells, 2 tool calls, 692 chars), `2ba387bc` (4 pairs, 479 cells,
3 tool calls, 1,908 chars), `7b5033c1` (2 pairs, 256 cells, 2 tool calls, 1,638 chars; train-exact but test wrong).

## Finding 4 — repair round (measured)

`candidate1_not_eligible` 38, `repair_not_needed_candidate1_train_exact` 3, `repair_output_parse_failed` 52,
`repair_verified` 27. Improved train-exact pairs on 1 task; candidate #2 selected once; 0 new all-train-exact.
Repair wall time 667 s.

## Inferred (not measured)

* Fixing truncation alone recovers 38 tasks from a guaranteed zero; if they behave like the other programs, that is
  roughly +1 verified task.
* If the 49 zero-tool tasks behaved like the tool-using group (3/42 ≈ 7 % verified), that is roughly +3–4 verified.
* Together: 3 → ~7–9 verified, 2 → ~4–6 solved (~3–5 %). These are extrapolations from small counts.

## Compute fact (measured)

A 4×L4 session consumes 2.0 quota-hours per wall-clock hour (8.07 quota-minutes over 2.02 wall-minutes with two
sessions running; consistent with the 21-minute smoke run consuming 43 quota-minutes).
