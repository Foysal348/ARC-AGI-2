# PIV-Q27-EVAL120-v1.0 — EVAL120

- Run ID: `20261002T173709Z` | arms: **ACT-LOW** | tasks: **120** | accuracy is real: **True**
- Frozen reference: ACT-XHIGH (v1.7 SMOKE) tool_engagement=0.00, budget_death=1.00, 0.160 s/token

## PROVEN BY PREFLIGHT (CPU, fake model) — harness correctness only
- Qwen tool-XML parser (incl. fence unwrap, prose-mention tolerance, rehearsal-in-think guard)
- persistent REPL semantics, protected puzzle, SystemExit survival, dead-worker restart
- fresh exact verifier: train gate before test execution, per-test partial outputs, sentinel protocol
- two-level retry accounting (max 2 consecutive step retries), guard-rejection not charged, dynamic multi-call budget
- forced-close construction: byte-exact Qwen early-stopping text; stop sentence replays in history with exactly one </think>
- natural </think> cut at the think cap -> token-exact continuation WITHOUT injection; exact </think>-id think/post token split
- repeated identical tool snippets counted (no KeyError); AST stateful-reuse metric; ranked winner selection
- real scheduler under a fake LLM for every arm incl. two-phase forced-close path and projected-deadline stop
- gate policy: Scenario-G, missing/duplicate terminal record, usable-test-required promotion, tool activation diagnostic only
- fresh verifier: test timeout preserves train-exact evidence; guard rejection does not claim subprocess execution
- competition scoring: output-level exact rate distinguished from strict all-query task diagnostic
- v2.4 terminal reserve/admission invariants, no-tools non-thinking renderer, structured terminal parser, and real-scheduler fake-LLM terminal transition
- v2.4C: terminal parser tolerates skip_special_tokens=False control tokens; indented tool payloads dedented; gate survives the terminal_finalizer wave row; every terminal stop reason is classified; engine output-count mismatch and batch aborts leave no task without a record

## MEASURED ONLY ON REAL GPU — model behaviour
- natural thinking length per arm
- tool engagement / first tool turn
- post-forced-close action mix
- final-program, syntax-valid, verifier-execution and train-exact rates
- valid test execution and official exact tasks
- sec/output-token and projected wall-clock
- terminal positive-control backend behavior, finalizer completion/parse/verifier funnel, feedback presence in rendered terminal prompt

## Arm comparison

| arm | tool_eng | final_prog | syntax_valid | verifier_exec | train_exact | valid_test | competition_output_exact | strict_all_query_task_exact | budget_death | gen_tok/task | sec/tok | tier | promotion_candidate |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| ACT-XHIGH (frozen v1.7 SMOKE reference, not rerun) | 0.00 | 0.00 | None | None | 0.00 | None | None | None | 1.00 | 12288 | 0.1601 | none | False |
| ACT-LOW | 0.59 | 0.68 | 0.68 | 0.68 | 0.03 | 0.02 | 0.0116 | 0.02 | 0.00 | 7829 | 0.0493 | usable_quality | True |

## Recommendation

- v2.5 COMPLETED WITH EXECUTABLE PROGRAMS BUT REPAIR DID NOT YIELD USABLE VERIFIED QUALITY. Inspect semantic failure taxonomy / candidate-search strategy next; do not reopen terminal reserve tuning or add reviewer/pass@K yet.
- ranked arms: ['ACT-LOW']

## Files
- `arm_comparison.csv/json`, `matched_task_quality.csv`, `arm_deltas_vs_frozen_xhigh.json`, `recommendation.json`, `measurement_contract.json`, `v25_repair_run_summary.json`
- per arm: `arms/<arm>/{task_quality.csv, repair_summary.csv/json, repair_feedback.jsonl, deferred_phase2_768_diagnostic.json, smoke_gate.json, measurement_report.json, verdict.json, agent_diagnostics.csv, task_output_scores.csv, raw_generations.jsonl, traces/, wave_metrics.jsonl}`