# Review bundle — first real Kaggle runs of the PIV pipeline (2026-10-03)

Start with `PROMPT_FOR_REVIEWER.md` (context + questions), then `analysis/ANALYSIS_SUMMARY.md` (our numbers).

| folder | contents |
|---|---|
| `notebooks/` | the two notebooks exactly as pushed to Kaggle |
| `kaggle_outputs/eval120/` | complete output of the 120-task evaluation run (answers known) |
| `kaggle_outputs/submission_run/` | complete output of the submission run, incl. `submission.json` and `run_report.json` |
| `kaggle_logs/` | full stdout of both Kaggle sessions |
| `analysis/` | our analysis, a per-task CSV of all 120 evaluation tasks, and the program re-run script |

`analysis/analyze_programs.py` expects the competition JSONs under `fake_input/competitions/arc-prize-2026-arc-agi-2/`
and the EVAL120 records under `kev/b/` relative to the working directory; adjust the two paths at the top to rerun it.

Verify integrity with `sha256sum -c SHA256SUMS.txt`.
