# Prompt for the reviewer — paste this as your first message, with the zip attached

You are joining an ARC Prize 2026 (ARC-AGI-2) Kaggle team as an independent analyst. The attached zip contains two
notebooks that just ran on real Kaggle hardware, their complete outputs and logs, and our own first-pass analysis.
I want a **deep, skeptical analysis** of where the score is being lost and what to change next. Treat our analysis as
a hypothesis to check, not as ground truth — re-derive numbers from the raw files where you can.

---

## 1. Where we stand

* **Goal:** a large leaderboard improvement with **Qwen3.8-27B-FP8** (we will not switch models). Current best team
  score is **32.64**, but that came from a *different* pipeline (an NVARC test-time-training approach), not from this
  model. Leaderboard leaders are at 72–77.
* **Time left:** deadline 2026-11-02 23:59 UTC → **about 30 days**. **One submission per day per team.**
* **Hardware:** Kaggle, offline, 12-hour limit, **4× NVIDIA L4** (22 GiB usable each). vLLM 0.19.0, tensor-parallel 4,
  `max_model_len=29696`, `max_num_seqs=16`, CUDA graphs on, prefix caching off (it OOMs), KV cache ≈10 GiB/GPU.
* **Compute budget (measured, important):** a 4×L4 session burns **2 quota-hours per wall-clock hour**. Each account
  has 30 quota-hours per week ⇒ **~15 real hours of 4×L4 per account per week**; we have two accounts on the team ⇒
  ~30 real hours per week. A full 12-hour run would consume 24 of one account's 30 hours. Every GPU run is expensive.
* **Kaggle data facts (verified):** `arc-agi_test_challenges.json` locally has 240 tasks / 259 queries, and **every
  one of the 240 is a byte-identical copy of a task in the 1000-task training file** (zero overlap with evaluation).
  At scoring time Kaggle swaps in the hidden set under the same filename. `arc-agi_evaluation_challenges.json` has
  **120 tasks / 172 queries with published solutions** — the only place where real ARC-AGI-2 difficulty meets known
  answers. Evaluation grids are about twice as large as training ones (≈353 vs ≈171 input cells per train pair).

## 2. The method ("PIV")

A stateful Python REPL agent. Per task, the model (Qwen3.8-27B, `reasoning_effort="low"`, Qwen tool-call XML) may think,
call a `python` tool against a persistent REPL that has the puzzle preloaded, and eventually emit a standalone
`solution(grid)` program. If exploration ends without a program, a **terminal finalizer** (no tools, thinking off,
structured JSON `{"solution_code": ...}`) forces one. A **fresh subprocess verifier** runs the program on every training
pair; only if *all* are exact is it run on the test inputs. One **repair round** feeds verifier diffs back to the model
for a second candidate. Per-task budget in these runs: **8,192 generated tokens = 6,144 exploration + 2,048 finalizer
reserve**, at most 6 tool calls / 12 turns, 12 tasks in flight at once.

## 3. The two runs in the zip (same solver, same budget)

| | `PIV-Q27-EVAL120-MEASUREMENT` | `PIV-Q27-SUB-v1_3-HIDDEN-TEST-SUBMISSION` |
|---|---|---|
| purpose | measure accuracy | produce the submitted `submission.json` |
| tasks | 120 public evaluation tasks (answers known) | 240 placeholder test tasks (training copies, answers known to us) |
| wall clock | ≈7 h | ≈6.2 h |
| programs produced | 82 / 120 | 220 / 240 |
| all-train-exact | **3 / 120** | 103 / 240 |
| **test answers correct** | **2 / 120 tasks = 1.67 %** (2/172 outputs) | **113 / 259 = 43.6 %** |
| infrastructure failures | 0 | 0 |

The submission from the second notebook was submitted on 2026-10-03 and is pending a hidden-set score. We expect
~1–2 points, because the hidden set is evaluation-level difficulty.

So: **the same pipeline scores 43.6 % on training-level tasks and 1.67 % on evaluation-level tasks.**

## 4. Our first-pass analysis of the EVAL120 run (please verify)

Funnel over the 120 evaluation tasks (from `analysis/eval120_per_task.csv`, which also includes a local re-run of every
program against its training pairs):

| outcome | tasks |
|---|---|
| no program — finalizer JSON truncated at exactly 2,048 tokens, `finish_reason=length` | **38** |
| program partially wrong (right-size grids, wrong cells) | 46 |
| wrong output size on every pair | 12 |
| returns the input unchanged on every pair | 10 |
| raises on every pair | 7 |
| program hangs (>20 s locally) | 4 |
| all training pairs exact | **3** (2 of them also correct on test) |

Claims we believe are true:

1. **Self-inflicted loss of 32 %.** All 38 finalizer failures stopped at exactly the 2,048-token reserve; every
   successful finalizer output was ≤1,824 tokens. An earlier run used a 4,096 reserve and parsed 16/16. We halved it
   to fit the schedule.
2. **41 % of tasks never use the REPL.** 49/120 tasks made zero tool calls. Their traces all look the same: turn 1
   generates 6,144 tokens with `finish_reason=length`, never closes `</think>`, and the text is the model re-typing the
   grids row by row ("Row 0: 7 1 1 1 …") although they are already in the prompt.
3. **REPL use is where every success came from.** Of tasks with a program: 0 tool calls → 0/36 all-train-exact;
   ≥1 tool call → 3/42. All three verified programs used 2–3 tool calls.
4. **The repair round is net negative here.** 120 rows: 52 `repair_output_parse_failed` (same truncation), 27
   `repair_verified`, 1 task improved, 0 new verified programs; cost ≈667 s.
5. Even when a program runs, it is far from right: mean **0.26** training pairs matched per program.

Our proposed next experiment (critique it, don't assume it is right):
restore the 4,096 finalizer reserve (total 10,240), force `</think>` closure after ~3,072 thinking tokens, add a prompt
rule against transcribing grids, sample K=4 independent programs per task with a train-verified pick, and disable
repair until truncation is fixed.

## 5. What I want from you

Please answer, citing the files and numbers you used:

1. **Verify or refute** the five claims in §4 from the raw files (`raw_generations.jsonl`, `traces/*.jsonl`,
   `task_quality.csv`, `repair_summary.json`, the Kaggle logs). Flag anything we got wrong or over-read.
2. **What else is going wrong that we did not see?** Look especially at: the 46 "partially wrong" programs (are they
   near misses or unrelated guesses?), the 12 wrong-size programs, the turn structure of tasks that *did* use the REPL,
   the prompt itself, the tool-output truncation (`MAX_TOOL_OUTPUT_CHARS=4000`), and timing per wave in
   `wave_metrics.jsonl`.
3. **Why 43.6 % on training-level tasks but 1.67 % on evaluation-level ones?** Is it task difficulty alone, or does
   something in our setup (grid size vs. context, budget, prompt) break specifically on larger evaluation grids?
4. **Rank the next changes by expected gain per GPU-hour**, given ~30 real 4×L4 hours per week and one submission per
   day. Be concrete: what to change, what you expect it to do to the 3/120 and 2/120 numbers, and how to measure it on
   the 120 evaluation tasks without burning a whole week of quota.
5. **Is this approach viable for a large improvement at all** with Qwen3.8-27B on 4×L4 in 30 days, or should part of
   the budget go elsewhere (e.g. more samples per task, test-time augmentation, ensembling with the 32.64 pipeline)?
   Give your honest assessment and the evidence for it.

Ground rules: distinguish clearly between what the files show and what you infer; when you give a number, say how you
computed it; do not recommend switching away from Qwen3.8-27B.

---

## 6. Map of the zip

```
README.md                                   what is where
PROMPT_FOR_REVIEWER.md                      this file
notebooks/
  PIV-Q27-EVAL120-MEASUREMENT.ipynb         measurement notebook (as pushed to Kaggle)
  PIV-Q27-SUB-v1_3-HIDDEN-TEST-SUBMISSION.ipynb   submission notebook (as pushed to Kaggle)
kaggle_outputs/
  eval120/          full output bundle of the EVAL120 run (per-arm records, traces, scores, repair, wave metrics)
  submission_run/   full output bundle of the submission run (incl. submission.json and run_report.json)
kaggle_logs/
  eval120_kaggle_run_log.txt                complete stdout of the Kaggle session
  submission_run_kaggle_run_log.txt
analysis/
  ANALYSIS_SUMMARY.md                       our analysis with the exact numbers
  eval120_per_task.csv                      one row per evaluation task, joined with a local program re-run
  program_failure_modes.json                per-task training-pair outcomes from the local re-run
  analyze_programs.py                       the re-run script
SHA256SUMS.txt                              `sha256sum -c SHA256SUMS.txt`
```

Key files inside each output bundle: `arms/ACT-LOW/raw_generations.jsonl` (one record per task, last record wins),
`arms/ACT-LOW/traces/<task_id>.jsonl` (one event per model turn, including `raw_text`),
`arms/ACT-LOW/measurement_report.json`, `arms/ACT-LOW/strict_task_level_scores.csv`,
`arms/ACT-LOW/repair_summary.json`, `arms/ACT-LOW/wave_metrics.jsonl`.
