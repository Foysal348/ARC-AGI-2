# ARC Prize 2026 / ARC-AGI-2 — Qwen3.8-27B PIV track: review bundle, 2026-10-02

**Who this is for:** an independent reviewer (another model or a person) asked to validate two notebooks before they
are run on Kaggle GPU. Everything here was produced by Claude in one session on the project owner's Windows machine.
No GPU time was spent.

**What I want validated** (in priority order):

1. **`notebooks/PIV-Q27-SUB-v1_0-HIDDEN-TEST-SUBMISSION.ipynb`** — brand-new submission notebook. It is the first
   thing in this project that will ever produce a `submission.json`. Please attack it on these axes:
   * Can any execution path leave `/kaggle/working/submission.json` missing, malformed, or with task ids that do not
     match the attached test file? (Claimed: no — see §4.)
   * Can it overrun the 12-hour session instead of stopping cleanly?
   * Can a wrong grid shape, a non-int cell, a numpy scalar, or a >30×30 grid reach the file?
   * Is `attempt_1` / `attempt_2` selection sane, and does anything leak test-set answers into the solver prompt?
     (The test file has no answers, but check `task_without_test_solutions` usage and the repair-feedback path.)
2. **`notebooks/PIV-Q27-C1-v2_5A-...ipynb`** — the solver/measurement notebook, i.e. ChatGPT's v2.5 plus four audited
   fixes. The original is included as `PIV-Q27-C1-v2_5-ORIGINAL-FROM-CHATGPT.ipynb` so you can diff.
3. Whether the **runtime projections** in §5 are defensible, and whether the pre-registered budget changes are a
   reasonable trade for coverage.

---

## 1. Inventory

```
notebooks/
  PIV-Q27-SUB-v1_0-HIDDEN-TEST-SUBMISSION.ipynb          submission notebook (NEW)
  PIV-Q27-C1-v2_5A-CANDIDATE-FIRST-VERIFIER-FEEDBACK-REPAIR.ipynb   solver, audited+fixed
  PIV-Q27-C1-v2_5-ORIGINAL-FROM-CHATGPT.ipynb            the unfixed input, for diffing
reports/
  PIV_Q27_C1_V25_FAKE_ENGINE_AUDIT_2026-09-18.md         the audit that produced the four fixes
  PIV_Q27_SUB_V10_AND_V25A_HANDOFF_2026-10-02.md         today's handoff (design + plan + competitor analysis)
harness/
  harness_c1.py                                          the local fake-engine harness that runs the notebooks
  restore_harness.py, patch_harness_sub.py, patch_harness_sub2.py   how harness_c1.py was rebuilt/extended
build_scripts/
  make_v25a.py                                           v2.5  -> v2.5A   (every fix, as explicit string edits)
  make_sub_v10.py                                        v2.5A -> PIV-SUB (every change, as explicit string edits)
harness_logs/                                            full stdout of the local runs
rehearsal_artifacts/
  run_report_SUBMIT_240tasks.json                        run report from a complete 240-task fake-engine sweep
  submission_example_fake_engine.json                    the submission.json that sweep produced
competitor_baseline/                                     the public Kaggle notebook that uses our uploaded model
```

The two build scripts are the most efficient way to review: they contain **every** modification as
`edit(cell, old_string, new_string)` pairs, so the diff is readable without diffing 500 KB of JSON.

SHA-256 (verify before reviewing):

| file | sha256 |
|---|---|
| `PIV-Q27-SUB-v1_0-HIDDEN-TEST-SUBMISSION.ipynb` | `a4dd53d6f0f160dff9eb389f15fabe1c8a05b2caa28d331e09a9a9d0dc56f513` |
| `PIV-Q27-C1-v2_5A-...ipynb` | `2188b999efeb6e286fc914bb8c1d876a5c9bdab99537842cd8c94360cd47d5ff` |
| `PIV-Q27-C1-v2_5-ORIGINAL-FROM-CHATGPT.ipynb` | `eb7d65ba6b0f1f0da56975ee467b3eb1b10f41539059561332403b376bff7ee6` |

---

## 2. Project context a reviewer needs

* Competition: ARC Prize 2026 (ARC-AGI-2), Kaggle, offline, 12 h, 4×L4 (24 GB each). Model: Qwen3.8-27B-FP8
  (`foysalemonshanto/qwen3-8-27b-fp8-repacked-v1`), vLLM 0.19.0, TP=4, `max_model_len=29696`, `max_num_seqs=16`,
  `gpu_memory_utilization=0.90`, prefix caching OFF (OOMs), `enforce_eager=False` ("C1": measured 129 tok/s at 8
  concurrent long decodes vs 48 eager).
* Approach ("PIV"): a stateful Python REPL agent writes a `solution(grid)` program; a **fresh subprocess verifier**
  requires exact equality on *all* train pairs before the program is executed on the test inputs; a terminal-commit
  finalizer (no tools, `enable_thinking=False`, structured JSON) guarantees a program artifact; v2.5 adds one repair
  round driven by verifier feedback.
* Last real GPU run (v2.4G, 2026-09-18, 78 min, 16 task-runs): interface fully healthy — 16/16 finalizer JSON parsed,
  syntax-valid, verifier executed, positive control passed — but **0/16 programs were all-train-exact** (best 2 of 4
  pairs). So the expected score of any submission today is ~0. Today's goals are (a) prove the submission path,
  (b) measure the train-verified rate on the real test file.
* Leaderboard context: top entries are at 72–77; the owner's current 32.64 comes from a different (NVARC) pipeline,
  not from this model.

---

## 3. How the local verification works, and what it cannot prove

`harness/harness_c1.py` executes the notebook's code cells **in-process** on Windows with:

* **real** Qwen tokenizer and `chat_template.jinja` from the pinned Kaggle model (so every prompt, token count,
  tool-call render and `</think>` handling is the real thing);
* **real** ARC data: the actual Kaggle competition JSONs, downloaded through the Kaggle API
  (`arc-agi_{training,evaluation,test}_*.json`, `sample_submission.json`). The local `arc-agi_test_challenges.json`
  placeholder contains **240 tasks / 259 queries**; Kaggle swaps in the hidden set at scoring time;
* **real** subprocess REPL and **real** subprocess verifier (actual `python -c` processes, actual timeouts);
* **stubbed** `torch` / `vllm`: a scripted `_FakeLLM` returns, per task position, one of eight scenarios — tool call
  then exploration blow-up at cap, tool/tool/final program, six tool calls, malformed tool XML, prose with no action,
  a 15 s sleeping tool (REPL timeout + restart), guard-rejected code, and long thinking every turn; plus repair-stage
  scenarios (truncated JSON, exception program, timing-out program, blocked import, over-cap output, and a
  lookup-table program that genuinely passes train verification). `HARNESS_OVERCAP=1` additionally makes the engine
  return more tokens than `max_tokens`, which must be caught.

**What this proves:** control flow, budget arithmetic, parser/verifier/record/submission plumbing, deadline logic,
failure taxonomy, and that no cell raises.

**What it cannot prove:** anything about real model behaviour or solve quality; real vLLM timing and memory
(especially KV pressure at 12 concurrent sequences, see §6); real structured-output backend behaviour at that
concurrency. Those need the GPU.

### Reproducing the runs

Prerequisites: Python 3.14 with `tokenizers`, `jinja2`, `numpy`, `pandas`, `scikit-learn`; a Kaggle API token; the
model's `tokenizer.json` + `chat_template.jinja` and the competition JSONs placed under
`<scratch>/fake_input/models/foysalemonshanto/qwen3-8-27b-fp8-repacked-v1/pytorch/hf-fp8/1/` and
`<scratch>/fake_input/competitions/arc-prize-2026-arc-agi-2/`. `harness_c1.py` hard-codes that scratch path near the
top — change `S` to your own.

```
python harness_c1.py PREFLIGHT       <notebook>   # v2.5A only
python harness_c1.py TERMINAL_PILOT  <notebook>   # v2.5A only
python harness_c1.py ADAPTIVE_SMOKE  <notebook>   # v2.5A only
HARNESS_OVERCAP=1 python harness_c1.py ADAPTIVE_SMOKE <notebook>
python harness_c1.py SUBMIT_SMOKE    <submission notebook>
python harness_c1.py SUBMIT_FAST     <submission notebook>
python harness_c1.py SUBMIT          <submission notebook>
```

---

## 4. PIV-SUB v1.0 — the claims to check

Derived from v2.5A; cells 1–8B (config → data → EDA → prompts → context → parser/REPL/verifier/repair helpers →
engine → scheduler → repair round) are the audited solver, unchanged in substance. All scoring/measurement cells were
removed and replaced by:

1. **Cell 2B** — submission state. Writes a competition-legal identity-fallback `submission.json` **before the model
   is allocated**, after self-tests that reject ragged grids, colours outside 0–9, bools, floats, empty grids and
   >30-wide grids, and that check rank ordering and record ingestion. Claim: from this point on no path can leave the
   file missing or malformed.
2. **Task set `TESTALL`** — ids come from the attached test file only; nothing is hard-coded. Public evaluation tasks
   (which have answers, used by the EDA cell) are merged into the solver's task map **after** that cell, with an
   explicit collision check.
3. **Oversized prompts** — a task whose rendered prompt exceeds `MAX_MODEL_LEN − per_turn − 512` is dropped with a
   recorded reason instead of raising (v2.5A raises, which would kill a submission run).
4. **Controller** — the frozen v2.4G adaptive flow is reused: terminal positive control → 2-task interface rehearsal →
   interface gate → full sweep. A failed gate stops the run and keeps the fallback submission.
5. **Incremental writes** — `append_record` ingests each terminal record and rewrites `submission.json` atomically
   (`os.replace`, throttled to 30 s), inside a `try/except` that can never break the solver loop.
6. **Deadline** — the scheduler's existing per-wave projection stops scheduling; the repair round is now chunked by
   `AGENT_BATCH_SIZE` with a per-chunk projection (a 200-job single `generate()` call could not be interrupted).
7. **CPU test-execution pass** — the verifier only runs test inputs after an all-train-exact gate. For a submission,
   programs that failed training are still executed here (guarded, 10 s per input, 20-minute budget), including the
   repair candidate that lost selection, so `attempt_2` is a genuinely different program rather than a copy of the
   input.
8. **Answer selection** — `attempt_1` = highest-ranked program output (train-verified first, then more train-exact
   pairs, then newer), `attempt_2` = best *different* output, identity copy wherever no program produced a legal grid.
9. **`run_report.json` + bundle** — coverage, train-verified count, stop-reason histogram, repair summary, interface
   gate, ingest errors, pre-registration.

**Three P0 defects were found and fixed while testing this notebook.** Each would have wasted a full GPU session:

| defect | effect |
|---|---|
| the terminal positive control only ran for `TERMINAL_PILOT`/`ADAPTIVE_SMOKE` | in a submission profile `positive_control_ok` was `False`, so the notebook failed **its own** interface gate and skipped the entire sweep |
| `TERMINAL_POLICY_ENABLED` excluded `SUBMIT_FAST` | with no terminal commit, any task that exhausted exploration ended with no program at all; the gate then failed |
| a self-test hard-coded the 12,288/4,096 token arithmetic (`assert cap <= 904`) | `AssertionError` in every profile with a different budget |

**Local verification status** (logs in `harness_logs/`):

| profile | result |
|---|---|
| `SUBMIT_SMOKE` (4 tasks) | completes; gate passes; submission updated |
| `SUBMIT` (all 240 tasks, 20 batches of 12) | completes in 1,602 s: gate passes, 240/240 terminal records, 210 final programs, chunked repair round, CPU pass executed 314 programs / added 254 candidates, run report, bundle |
| `SUBMIT_FAST` (all 240 tasks) | completes in 1,578 s: gate passes, 240/240 terminal records, chunked repair round, CPU pass executed 314 programs / added 254 candidates, run report, bundle |

The produced `submission.json` (`rehearsal_artifacts/`) was validated **outside** the notebook: ids identical to
`sample_submission.json`, one answer per test input, only `attempt_1`/`attempt_2` keys, **zero illegal grids**, and in
the smoke run one query carried two genuinely different attempts (`[[7,0,7],[7,0,7],[7,7,0]]` vs `[[7,0,7]]`).
Note that with the fake engine most programs are identity programs, so most attempts equal the input by construction —
that is a property of the stub, not of the notebook.

### Profiles

| profile | per-task tokens | finalizer reserve | concurrency | tool calls / turns |
|---|---|---|---|---|
| `SUBMIT_SMOKE` | 8,192 | 2,048 | 4 | 6 / 12 |
| `SUBMIT_FAST` | 4,096 | 2,048 | 12 | 4 / 8 |
| `SUBMIT` (default) | 8,192 | 2,048 | 12 | 6 / 12 |

**Pre-registered deviations from the v2.4G/v2.5 measurement runs** — stated in the notebook header and the run
report, and the reason these runs are **not comparable** with the arm measurements: smaller per-task budget, smaller
finalizer reserve, concurrency 12 instead of 8, single arm `ACT-LOW` (chosen partly because `ACT-BUDGET3072` still has
the known 768-token phase-2 truncation defect).

---

## 5. Runtime projection — please sanity-check this

Measured on GPU (v2.4G, 2026-09-18): 2 arms × 8 tasks = 16 task-runs in 78 min wall clock, including ~8.25 min model
load; per-arm solver loops were 39 min (ACT-LOW, ~10.4k generated tokens/task) and 28.5 min (ACT-BUDGET3072), i.e.
**≈4.25–4.9 min per task-run at batch 8 with a 12,288-token budget**, ≈0.00047 min per generated token per task.

Scaling that linearly in tokens and assuming only 0.75 efficiency when raising concurrency 8 → 12, plus ~10 min load
and ~20 min of post-passes:

| | 120 hidden tasks | 240 tasks |
|---|---|---|
| `SUBMIT_FAST` (4,096) | ≈ 3.5–4 h | ≈ 7–7.5 h |
| `SUBMIT` (8,192) | ≈ 7–7.5 h | exceeds the 10.75 h internal deadline → ~75–85 % coverage, rest stays identity |

If you think the concurrency assumption or the token scaling is wrong, say so — this is the number that decides
whether a submission lands today.

---

## 6. Known risks and open questions

1. **KV pressure at concurrency 12.** The measured KV cache is ~160–168k tokens. Twelve sequences at ~12–13k context
   each sits right at that limit, so vLLM may preempt and recompute (slower, not fatal). Nobody has run this
   configuration. Is 12 the right choice, or should it be 8 (proven) or 10?
2. **`SUBMIT_FAST` gives the agent only 2,048 exploration tokens** (4,096 − 2,048 reserve). In v2.4G, ACT-LOW spent
   8,192+ tokens thinking before any tool call, so FAST will mostly become "think briefly, then commit a program
   through the finalizer" with few or no REPL iterations. That is deliberate for coverage, but it removes most of
   PIV's mechanism. Is a fast run of a weakened mechanism the right use of a session, or is one `SUBMIT` run better?
3. **Expected score ~0.** v2.4G produced no train-exact program; nothing since has changed the solver's reasoning.
   The owner has accepted this ("score 1 is fine") to get the submission path proven.
4. **Repair cost on 240 tasks:** the repair round re-verifies every candidate in a fresh subprocess (~1–3 s each,
   ~8 min) before any repair generation, and does it again for candidate #2. Deadline-guarded, but is it worth the
   time in `SUBMIT_FAST`, where the leftover budget is usually too small to admit a repair at all?
5. **Runtime provenance:** both notebooks still install vLLM 0.19.0 from a third-party wheelhouse dataset
   (`driessmit1/arc3-vllm-h100-wheelhouse-v3`). `competitor_baseline/` shows a cleaner pattern: a separate
   internet-ON notebook downloads wheels and emits a `runtime_manifest.json` with per-wheel sha256 that the
   submission notebook verifies before installing. Recommended, not yet done.
6. **`language_model_only=True`** (used by the competitor's `LLM(...)`) is untested here and might free KV memory.

---

## 7. The competitor baseline in `competitor_baseline/`

Public Kaggle notebook `phamtruongdat/notebookfa6c76ce70`, which attaches **our** uploaded model. Pulled through the
Kaggle API and included verbatim. It is the direct non-thinking baseline: prompt = `{"examples", "test_input"}` →
`{"grid": ...}`, `enable_thinking=False`, `n=2`, temp 0.7 / top_p 0.8 / top_k 20, 4,096 output tokens, batch 4,
`enforce_eager=True`, prefix caching off; no train verification, no program synthesis, no REPL; identity fallback on
parse failure. Expected ARC-AGI-2 score ~0–2%. It is included for the three engineering ideas listed in §6.5/§6.6 and
in the handoff report, not as a method to copy.

---

## 8. Recommended run order on Kaggle

1. `RUN_PROFILE = "SUBMIT_SMOKE"` → interactive run (~25–35 min incl. model load). Confirms the real stack. **Never
   submit this version.**
2. `RUN_PROFILE = "SUBMIT_FAST"` → **Save & Run All** → submit `/kaggle/working/submission.json` from that saved
   version.
3. Later: `RUN_PROFILE = "SUBMIT"` for the better sweep, and `PIV-Q27-C1 v2.5A` with `ADAPTIVE_SMOKE` (78 min) for the
   repair measurement on the public evaluation set, where answers are known.

Inputs to attach in every case, with **Internet OFF** and **GPU L4 ×4**: the competition data, the pinned
Qwen3.8-27B-FP8 model, and the vLLM wheelhouse dataset.
