# SPDX-License-Identifier: MIT-0
"""Offline ARC-AGI submission wrapper for an attached Qwen model.

The public entry point supervises a separate inference process so a wall-clock
deadline can terminate CUDA workers and leave the last complete submission.
Only the Python standard library is imported until the inference worker starts.
"""

from __future__ import annotations

import argparse
import copy
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time
import traceback
from dataclasses import dataclass
from typing import Any


MODEL_SLUG = "qwen3-8-27b-fp8-repacked-v1"
DEFAULT_MODEL = Path("/kaggle/input") / MODEL_SLUG / "pytorch/hf-fp8/1"
Grid = list[list[int]]


@dataclass(frozen=True)
class Case:
    task_id: str
    test_index: int
    train: list[dict[str, Grid]]
    input_grid: Grid


def validate_grid(value: Any) -> Grid:
    """Return a copied ARC grid, rejecting bools, floats, and ragged rows."""
    if not isinstance(value, list) or not 1 <= len(value) <= 30:
        raise ValueError("A grid must have between 1 and 30 rows.")
    width = len(value[0]) if isinstance(value[0], list) else 0
    if not 1 <= width <= 30:
        raise ValueError("A grid must have between 1 and 30 columns.")
    for row in value:
        if not isinstance(row, list) or len(row) != width:
            raise ValueError("A grid must be rectangular.")
        if any(type(cell) is not int or not 0 <= cell <= 9 for cell in row):
            raise ValueError("Grid cells must be integers from 0 through 9.")
    return [row[:] for row in value]


def load_challenges(path: Path) -> dict[str, dict[str, Any]]:
    """Read challenges and retain train input/output and test input only.

    Public validation files can include test outputs. They are deliberately
    neither read into the sanitized structure nor used by inference.
    """
    with path.open(encoding="utf-8") as handle:
        raw = json.load(handle)
    if not isinstance(raw, dict) or not raw:
        raise ValueError("The challenges file must contain a nonempty task mapping.")
    challenges: dict[str, dict[str, Any]] = {}
    for task_id, task in raw.items():
        if not isinstance(task_id, str) or not isinstance(task, dict):
            raise ValueError("Each challenge must have a string ID and object value.")
        train, tests = task.get("train"), task.get("test")
        if not isinstance(train, list) or not train:
            raise ValueError(f"{task_id}: training examples are missing.")
        if not isinstance(tests, list) or not tests:
            raise ValueError(f"{task_id}: test inputs are missing.")
        try:
            clean_train = [
                {"input": validate_grid(item["input"]),
                 "output": validate_grid(item["output"])}
                for item in train
            ]
            clean_tests = [{"input": validate_grid(item["input"])} for item in tests]
        except (KeyError, TypeError, ValueError) as error:
            raise ValueError(f"{task_id}: invalid challenge: {error}") from error
        challenges[task_id] = {"train": clean_train, "test": clean_tests}
    return challenges


def flatten_cases(challenges: dict[str, dict[str, Any]]) -> list[Case]:
    return [
        Case(task_id, index, task["train"], test["input"])
        for task_id, task in challenges.items()
        for index, test in enumerate(task["test"])
    ]


def fallback_submission(challenges: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """Identity guesses keep every required attempt present before inference."""
    return {
        task_id: [
            {"attempt_1": copy.deepcopy(test["input"]),
             "attempt_2": copy.deepcopy(test["input"])}
            for test in task["test"]
        ]
        for task_id, task in challenges.items()
    }


def validate_submission(submission: Any, challenges: dict[str, dict[str, Any]]) -> None:
    if not isinstance(submission, dict) or set(submission) != set(challenges):
        raise ValueError("Submission IDs must exactly match the challenge IDs.")
    for task_id, task in challenges.items():
        answers = submission[task_id]
        if not isinstance(answers, list) or len(answers) != len(task["test"]):
            raise ValueError(f"{task_id}: expected one entry per test input, in order.")
        for answer in answers:
            if not isinstance(answer, dict) or set(answer) != {"attempt_1", "attempt_2"}:
                raise ValueError(f"{task_id}: each entry needs attempt_1 and attempt_2.")
            validate_grid(answer["attempt_1"])
            validate_grid(answer["attempt_2"])


def atomic_json_write(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    with temporary.open("w", encoding="utf-8", newline="\n") as handle:
        json.dump(value, handle, separators=(",", ":"), ensure_ascii=False)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)


def parse_grid(text: str) -> Grid:
    """Extract JSON safely; reasoning content cannot become an answer."""
    if not isinstance(text, str):
        raise ValueError("The generated response is not text.")
    # Non-thinking mode is requested, but defend against a model emitting tags.
    if "<think>" in text:
        text = re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL)
        if "<think>" in text:
            raise ValueError("The response ends inside a thinking block.")
    # Some templates provide the opening tag in the prompt, so only the closing
    # tag appears in the returned completion. Everything before it is reasoning.
    if "</think>" in text:
        text = text.rsplit("</think>", 1)[1]
    # Decode only the first complete JSON value. Searching its interior after a
    # validation failure could incorrectly accept part of a malformed 3-D grid.
    match = re.search(r"[\[{]", text)
    if match is None:
        raise ValueError("No JSON grid was found in the response.")
    try:
        value, _ = json.JSONDecoder().raw_decode(text, match.start())
    except json.JSONDecodeError as error:
        raise ValueError("The generated grid is not valid JSON.") from error
    if isinstance(value, dict):
        value = value.get("grid")
    return validate_grid(value)


def prompt_messages(case: Case) -> list[dict[str, str]]:
    payload = {"examples": case.train, "test_input": case.input_grid}
    return [
        {"role": "system", "content": (
            "Solve this ARC grid transformation. Infer one consistent rule from "
            "all training input/output pairs and apply it to the test input. "
            "Each integer 0 through 9 is a color. Output dimensions may change. "
            'Return only valid JSON in the form {"grid":[[0,1],[2,3]]}. '
            "Return one rectangular grid, with no explanation or reasoning."
        )},
        {"role": "user", "content": json.dumps(payload, separators=(",", ":"))},
    ]


def discover_model(value: str, input_root: Path = Path("/kaggle/input")) -> Path:
    if value != "auto":
        model = Path(value).expanduser().resolve()
        if not (model / "config.json").is_file():
            raise FileNotFoundError(f"No config.json at the local model path: {model}")
        return model
    expected = input_root / MODEL_SLUG / "pytorch/hf-fp8/1"
    if (expected / "config.json").is_file():
        return expected
    # New Kaggle mount layouts can add models/<owner>/ before the model slug.
    candidates = sorted({
        path.parent for path in input_root.rglob("config.json")
        if MODEL_SLUG in path.parts
    }) if input_root.exists() else []
    if len(candidates) == 1:
        return candidates[0]
    if not candidates:
        raise FileNotFoundError(
            f"Attach Kaggle model {MODEL_SLUG}, or set --model to its local directory."
        )
    raise ValueError(f"Multiple model directories found; set --model explicitly: {candidates}")


def load_backend(args: argparse.Namespace) -> tuple[Any, Any, Any, Path]:
    # Never resolve/download a Hub model or tokenizer during a submission run.
    os.environ["HF_HUB_OFFLINE"] = "1"
    os.environ["TRANSFORMERS_OFFLINE"] = "1"
    os.environ["HF_DATASETS_OFFLINE"] = "1"
    os.environ["HF_HUB_DISABLE_TELEMETRY"] = "1"
    model_path = discover_model(args.model)
    from transformers import AutoTokenizer
    from vllm import LLM, SamplingParams

    tokenizer = AutoTokenizer.from_pretrained(
        str(model_path), local_files_only=True, trust_remote_code=False
    )
    engine = LLM(
        model=str(model_path),
        tokenizer=str(model_path),
        tensor_parallel_size=args.tensor_parallel_size,
        dtype="bfloat16",
        language_model_only=True,
        max_model_len=args.max_model_len,
        max_num_seqs=args.batch_size * 2,
        max_num_batched_tokens=8192,
        gpu_memory_utilization=args.gpu_memory_utilization,
        enforce_eager=True,
        # Keep hybrid-model prefix caching disabled for version compatibility.
        enable_prefix_caching=False,
        trust_remote_code=False,
        seed=0,
    )
    sampling = SamplingParams(
        n=2, temperature=0.7, top_p=0.8, top_k=20,
        max_tokens=args.max_output_tokens, seed=0,
    )
    return tokenizer, engine, sampling, model_path


def initial_report(cases: list[Case], args: argparse.Namespace) -> dict[str, Any]:
    return {
        "status": "starting", "mode": "smoke" if args.max_cases is not None else "full",
        "total_cases": len(cases), "case_limit": args.max_cases,
        "processed_cases": 0, "generated_cases": 0, "valid_model_attempts": 0,
        "fallback_attempts": 2 * len(cases), "parse_failures": 0,
        "prompt_too_long_cases": 0, "errors": [],
        "model": args.model, "elapsed_seconds": 0.0,
    }


def record_error(report: dict[str, Any], message: str, case: Case | None = None) -> None:
    if len(report["errors"]) < 20:
        entry: dict[str, Any] = {"message": message[:1000]}
        if case is not None:
            entry.update(task_id=case.task_id, test_index=case.test_index)
        report["errors"].append(entry)


def checkpoint(args: argparse.Namespace, submission: dict[str, Any],
               report: dict[str, Any], started: float) -> None:
    report["elapsed_seconds"] = round(time.monotonic() - started, 3)
    atomic_json_write(args.output, submission)
    atomic_json_write(args.report, report)


def run_worker(args: argparse.Namespace) -> int:
    started = time.monotonic()
    challenges = load_challenges(args.challenges)
    cases = flatten_cases(challenges)
    submission = fallback_submission(challenges)
    report = initial_report(cases, args)
    report["status"] = "loading_model"
    checkpoint(args, submission, report, started)
    try:
        tokenizer, engine, sampling, model_path = load_backend(args)
        report["model"] = str(model_path)
        report["status"] = "running"
        checkpoint(args, submission, report, started)
        selected = cases[:args.max_cases] if args.max_cases is not None else cases
        for offset in range(0, len(selected), args.batch_size):
            batch = selected[offset:offset + args.batch_size]
            prompts: list[str] = []
            active: list[Case] = []
            for case in batch:
                prompt = tokenizer.apply_chat_template(
                    prompt_messages(case), tokenize=False,
                    add_generation_prompt=True, enable_thinking=False,
                )
                token_count = len(tokenizer.encode(prompt, add_special_tokens=False))
                if token_count + args.max_output_tokens > args.max_model_len:
                    report["prompt_too_long_cases"] += 1
                    record_error(report, f"Prompt has {token_count} tokens; context budget exceeded.", case)
                    continue
                prompts.append(prompt)
                active.append(case)
            if prompts:
                results = engine.generate(prompts, sampling, use_tqdm=False)
                if len(results) != len(active):
                    raise RuntimeError("The inference engine returned the wrong number of requests.")
                for case, result in zip(active, results):
                    report["generated_cases"] += 1
                    answer = submission[case.task_id][case.test_index]
                    for attempt in range(2):
                        try:
                            if attempt >= len(result.outputs):
                                raise ValueError("The engine returned fewer than two completions.")
                            grid = parse_grid(result.outputs[attempt].text)
                            answer[f"attempt_{attempt + 1}"] = grid
                            report["valid_model_attempts"] += 1
                            report["fallback_attempts"] -= 1
                        except ValueError as error:
                            report["parse_failures"] += 1
                            record_error(report, f"Attempt {attempt + 1}: {error}", case)
            report["processed_cases"] += len(batch)
            validate_submission(submission, challenges)
            checkpoint(args, submission, report, started)
            print(
                f"Processed {report['processed_cases']}/{len(selected)} cases; "
                f"valid model attempts={report['valid_model_attempts']}, "
                f"fallback attempts={report['fallback_attempts']}.", flush=True,
            )
        report["status"] = "smoke_complete" if args.max_cases is not None else "completed"
        checkpoint(args, submission, report, started)
        return 0
    except Exception as error:
        report["status"] = "failed"
        record_error(report, f"{type(error).__name__}: {error}")
        checkpoint(args, submission, report, started)
        traceback.print_exc()
        return 1


def terminate_worker(process: subprocess.Popen[Any]) -> None:
    """Terminate the process tree, including vLLM's multiprocessing workers."""
    if os.name == "nt":
        subprocess.run(
            ["taskkill", "/PID", str(process.pid), "/T", "/F"],
            check=False, capture_output=True,
        )
    else:
        try:
            os.killpg(process.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            pass
        # The leader can exit before a child; still signal the whole group.
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
    try:
        process.wait(timeout=10)
    except subprocess.TimeoutExpired:
        raise RuntimeError("The inference worker did not stop after termination.")


def run_supervisor(args: argparse.Namespace) -> int:
    started = time.monotonic()
    challenges = load_challenges(args.challenges)
    cases = flatten_cases(challenges)
    submission = fallback_submission(challenges)
    report = initial_report(cases, args)
    if args.dry_run:
        report["status"] = "dry_run"
        validate_submission(submission, challenges)
        checkpoint(args, submission, report, started)
        print(f"Schema-only dry run: wrote identity guesses for {len(cases)} test inputs.")
        return 0
    checkpoint(args, submission, report, started)
    command = [sys.executable, str(Path(__file__).resolve()), "--worker"]
    for flag, value in (
        ("--challenges", args.challenges), ("--output", args.output),
        ("--report", args.report), ("--model", args.model),
        ("--batch-size", args.batch_size), ("--max-model-len", args.max_model_len),
        ("--max-output-tokens", args.max_output_tokens),
        ("--tensor-parallel-size", args.tensor_parallel_size),
        ("--gpu-memory-utilization", args.gpu_memory_utilization),
    ):
        command.extend([flag, str(value)])
    if args.max_cases is not None:
        command.extend(["--max-cases", str(args.max_cases)])
    options: dict[str, Any] = {"start_new_session": True} if os.name != "nt" else {
        "creationflags": subprocess.CREATE_NEW_PROCESS_GROUP
    }
    process = subprocess.Popen(command, **options)
    timed_out = False
    try:
        return_code = process.wait(timeout=max(0.001, args.time_limit_seconds - (time.monotonic() - started)))
    except subprocess.TimeoutExpired:
        timed_out = True
        terminate_worker(process)
        return_code = 124
    except BaseException:
        terminate_worker(process)
        raise
    with args.report.open(encoding="utf-8") as handle:
        report = json.load(handle)
    with args.output.open(encoding="utf-8") as handle:
        validate_submission(json.load(handle), challenges)
    report["supervisor_elapsed_seconds"] = round(time.monotonic() - started, 3)
    report["worker_exit_code"] = process.returncode
    if timed_out:
        report["status"] = "timed_out"
        record_error(report, "Time limit reached; retained the last complete submission checkpoint.")
    elif return_code != 0:
        report["status"] = "failed"
        record_error(report, f"Inference worker exited with code {return_code}; this is not a successful model run.")
    atomic_json_write(args.report, report)
    print(
        f"Status: {report['status']}; valid model attempts={report['valid_model_attempts']}; "
        f"fallback attempts={report['fallback_attempts']}. Report: {args.report}", flush=True,
    )
    return return_code if return_code >= 0 else 1


def positive_int(value: str) -> int:
    number = int(value)
    if number < 1:
        raise argparse.ArgumentTypeError("Must be at least 1.")
    return number


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--challenges", type=Path, default=Path(
        "/kaggle/input/arc-prize-2026-arc-agi-2/arc-agi_test_challenges.json"))
    parser.add_argument("--model", default="auto", help="Local attached model directory, or auto.")
    parser.add_argument("--output", type=Path, default=Path("/kaggle/working/submission.json"))
    parser.add_argument("--report", type=Path, default=Path("/kaggle/working/inference_report.json"))
    parser.add_argument("--time-limit-seconds", type=float, default=10.5 * 60 * 60)
    parser.add_argument("--batch-size", type=positive_int, default=4)
    parser.add_argument("--max-model-len", type=positive_int, default=16384)
    parser.add_argument("--max-output-tokens", type=positive_int, default=4096)
    parser.add_argument("--tensor-parallel-size", type=positive_int, default=4)
    parser.add_argument("--gpu-memory-utilization", type=float, default=0.85)
    parser.add_argument("--max-cases", type=positive_int, help="Explicit smoke test; remaining cases use identity guesses.")
    parser.add_argument("--dry-run", action="store_true", help="Check submission schema without loading a model.")
    parser.add_argument("--worker", action="store_true", help=argparse.SUPPRESS)
    args = parser.parse_args(argv)
    if not args.time_limit_seconds > 0:
        parser.error("--time-limit-seconds must be positive.")
    if not 0 < args.gpu_memory_utilization < 1:
        parser.error("--gpu-memory-utilization must lie between 0 and 1.")
    if args.max_output_tokens >= args.max_model_len:
        parser.error("--max-output-tokens must be smaller than --max-model-len.")
    args.challenges = args.challenges.resolve()
    args.output = args.output.resolve()
    args.report = args.report.resolve()
    if args.output == args.report or args.challenges in (args.output, args.report):
        parser.error("Challenges, submission, and report must be different paths.")
    return args


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    try:
        return run_worker(args) if args.worker else run_supervisor(args)
    except Exception as error:
        print(f"{type(error).__name__}: {error}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
', encoding='utf-8