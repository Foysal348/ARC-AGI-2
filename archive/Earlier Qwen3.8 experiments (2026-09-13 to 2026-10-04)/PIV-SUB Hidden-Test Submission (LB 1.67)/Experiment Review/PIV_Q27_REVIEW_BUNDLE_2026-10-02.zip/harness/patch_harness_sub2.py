"""Second harness patch for the submission notebook: generic task->scenario mapping and the spaced bundle path."""
from pathlib import Path

p = Path(__file__).with_name("harness_c1.py")
s = p.read_text(encoding="utf-8")

# 1) bundle path is written with spaces in the submission notebook.
old_bundle = """    if 'Path("/kaggle/working")/BUNDLE_NAME' in src: src = src.replace('Path("/kaggle/working")/BUNDLE_NAME', 'Path(r"' + str(WORKING) + '")/BUNDLE_NAME')"""
new_bundle = """    for _bp in ('Path("/kaggle/working")/BUNDLE_NAME', 'Path("/kaggle/working") / BUNDLE_NAME'):
        if _bp in src: src = src.replace(_bp, 'Path(r"' + str(WORKING) + '")/BUNDLE_NAME')"""
assert old_bundle in s
s = s.replace(old_bundle, new_bundle)

# 2) the fake engine keyed scenarios to SMOKE8 membership; submission profiles run arbitrary test tasks.
old_pos = """            pos = smoke.index(tid)"""
new_pos = """            if tid in smoke:
                pos = smoke.index(tid)
            else:
                # Submission profiles: spread the eight scripted failure scenarios over the active task list.
                _active = list(G["ACTIVE_TASK_IDS"])
                pos = (_active.index(tid) % 8) if tid in _active else 0"""
assert old_pos in s
s = s.replace(old_pos, new_pos)

# 3) _tid() scans ACTIVE_TASK_IDS; make sure the challenge map covers submission tasks too (it does: merged).
p.write_text(s, encoding="utf-8")
import ast; ast.parse(s)
print("harness patch 2 applied")
