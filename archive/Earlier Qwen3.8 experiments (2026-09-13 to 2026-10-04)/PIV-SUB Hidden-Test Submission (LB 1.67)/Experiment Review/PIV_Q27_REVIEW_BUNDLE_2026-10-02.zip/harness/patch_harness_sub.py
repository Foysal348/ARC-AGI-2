"""Extend the restored harness so it can also drive PIV-Q27-SUB (submission profiles)."""
from pathlib import Path

p = Path(__file__).with_name("harness_c1.py")
s = p.read_text(encoding="utf-8")

# work root + submission path redirects
s = s.replace(
    """    'Path("/kaggle/working/piv_q27_c1_v25")': f'Path(r"{WORKING / "piv_q27_c1_v25"}")',""",
    """    'Path("/kaggle/working/piv_q27_c1_v25")': f'Path(r"{WORKING / "piv_q27_c1_v25"}")',
    'Path("/kaggle/working/piv_q27_sub_v10")': f'Path(r"{WORKING / "piv_q27_sub_v10"}")',""")
s = s.replace(
    """    if 'Path("/kaggle/working")/BUNDLE_NAME' in src:""",
    """    if 'Path("/kaggle/working/submission.json")' in src:
        src = src.replace('Path("/kaggle/working/submission.json")', 'Path(r"' + str(WORKING / "submission.json") + '")')
    if 'Path("/kaggle/working")/BUNDLE_NAME' in src:""")

# the RUN_PROFILE switch line differs between the solver and submission notebooks.
s = s.replace(
    """    'RUN_PROFILE = "ADAPTIVE_SMOKE"   # default': f'RUN_PROFILE = "{PROFILE}"   # harness',""",
    """    'RUN_PROFILE = "ADAPTIVE_SMOKE"   # default': f'RUN_PROFILE = "{PROFILE}"   # harness',
    'RUN_PROFILE = "SUBMIT"   # default': f'RUN_PROFILE = "{PROFILE}"   # harness',""")
s = s.replace(
    """            if src.count(a) == 0 and "piv_q27_c1_v2" in a: continue   # work root differs per notebook version""",
    """            if src.count(a) == 0 and ("piv_q27_" in a or "RUN_PROFILE = " in a): continue   # differs per notebook""")

# the submission notebook has no "piv_q27_c1_v25" work root; the skip rule already covers it.
# fake engine: a repair prompt is detected by its marker, which is unchanged, so no new scenario is needed.
p.write_text(s, encoding="utf-8")
import ast; ast.parse(s)
print("harness extended for SUBMIT profiles")
