"""Restore the archived v2.4E harness and re-apply the v2.5 adaptations (scratchpad was cleaned)."""
from pathlib import Path

SRC = Path(r"D:\ARC AGI 2\Research Experiment result\harness_c1_v24e_fake_engine.py")
DST = Path(__file__).with_name("harness_c1.py")
s = SRC.read_text(encoding="utf-8-sig")
NL = chr(92) + "n"

# 1) v2.5 work root + generalized bundle-path rewrite + drop the GitHub multi_query hack (real Kaggle data now).
s = s.replace(
    """    'Path("/kaggle/working/piv_q27_c1_v24")': f'Path(r"{WORKING / "piv_q27_c1_v24"}")',""",
    """    'Path("/kaggle/working/piv_q27_c1_v24")': f'Path(r"{WORKING / "piv_q27_c1_v24"}")',
    'Path("/kaggle/working/piv_q27_c1_v25")': f'Path(r"{WORKING / "piv_q27_c1_v25"}")',""")
s = s.replace(
    """    '    "multi_query": 8,': '    "multi_query": 7,   # HARNESS: GitHub public data differs from Kaggle for one proxy task',\n""", "")
s = s.replace(
    """        for a, b in rep.items():
            assert src.count(a) == 1, a
            src = src.replace(a, b)""",
    """        for a, b in rep.items():
            if src.count(a) == 0 and "piv_q27_c1_v2" in a: continue   # work root differs per notebook version
            assert src.count(a) == 1, a
            src = src.replace(a, b)""")
s = s.replace(
    """    if i == 15: src = src.replace('Path("/kaggle/working")/BUNDLE_NAME',""",
    """    if 'Path("/kaggle/working")/BUNDLE_NAME' in src: src = src.replace('Path("/kaggle/working")/BUNDLE_NAME',""")

# 2) repair-stage scenarios for the fake engine (v2.5 CELL 8B prompts carry the feedback SHA marker).
anchor = """            if terminal:
                if pos == 4: o = _Out(tok, BAD_JSON, cap, "length")"""
block = '''            repair = "[V25_REPAIR_FEEDBACK_SHA256=" in text
            if repair:
                task = G["eval_challenges"][tid]
                cheat = "T=" + repr({repr(ex["input"]): ex["output"] for ex in task["train"]}) + "NLdef solution(grid):NL    return T.get(repr(grid), grid)NL"
                cheat_json = json.dumps({"solution_code": cheat}) + "<|im_end|>"
                cl = len(tok.encode(cheat_json, add_special_tokens=False)); fits = cl <= cap - 8
                _oc = bool(os.environ.get('HARNESS_OVERCAP'))
                def J(code, n, fr="stop", overcap=False): return _Out(tok, json.dumps({"solution_code": code}) + "<|im_end|>", n, fr, overcap=overcap)
                if pos == 7 and fits and not _oc: o = _Out(tok, cheat_json, cl, "stop")          # verified repair -> candidate #2 selected
                elif pos == 0:                  o = _Out(tok, GOOD_JSON, 120, "stop")            # identity again -> delta 0
                elif pos == 1:                  o = J("def solution(grid):NL    return grid[:1]", 80)                     # dims mismatch
                elif pos == 2:                  o = _Out(tok, BAD_JSON, cap, "length")            # truncated JSON -> parse failed
                elif pos == 3:                  o = J("def solution(grid):NL    return grid[99][99]", 80)                 # exception
                elif pos == 5:                  o = J("import timeNLdef solution(grid):NL    time.sleep(15)NL    return grid", 80)  # verifier timeout
                elif pos == 6:                  o = J("import osNLdef solution(grid):NL    return grid", 80)              # guard reject
                else:                           o = J("def solution(grid):NL    return grid[:1]", (cap + 5 if _oc else 80), overcap=_oc)  # overcap injection
                FAKE_LOG.append((arm, tid, "repair", pos, o.finish_reason, len(o.token_ids), "cheat" if (pos == 7 and fits and not _oc) else "other"))
                outs.append(_Req(o, pids)); continue
'''.replace("NL", NL)
assert s.count(anchor) == 1
s = s.replace(anchor, block + anchor)

# 3) the log directory must exist.
s = s.replace('(S / "c1v24e" / f"fake_llm_log_', '(Path(__file__).parent / f"fake_llm_log_')


# 4) overcap support in _Out (v2.4F/G harness feature, absent from the archived v2.4E copy) + pos-7 injection.
s = s.replace("""class _Out:
    def __init__(self, tok, text, n, fr):
        ids = list(tok.encode(text, add_special_tokens=False)) or [0]
        if len(ids) > int(n):                       # real vLLM never exceeds max_tokens""",
"""class _Out:
    def __init__(self, tok, text, n, fr, overcap=False):
        ids = list(tok.encode(text, add_special_tokens=False)) or [0]
        if len(ids) > int(n) and not overcap:        # real vLLM never exceeds max_tokens; overcap=True simulates a violation""")
s = s.replace("""                    o = _Out(tok, act(TOOL("print(len(puzzle['train']))")) if forced_p2 else LONG_THINK, (300 if forced_p2 else cap), ("stop" if forced_p2 else "length"))""",
"""                    _oc1 = bool(os.environ.get('HARNESS_OVERCAP')) and not forced_p2
                    o = _Out(tok, act(TOOL("print(len(puzzle['train']))")) if forced_p2 else LONG_THINK, (300 if forced_p2 else cap), ("stop" if forced_p2 else "length"), overcap=_oc1)""")

DST.write_text(s, encoding="utf-8")
import ast; ast.parse(s)
print("restored + patched:", DST, len(s), "chars")
