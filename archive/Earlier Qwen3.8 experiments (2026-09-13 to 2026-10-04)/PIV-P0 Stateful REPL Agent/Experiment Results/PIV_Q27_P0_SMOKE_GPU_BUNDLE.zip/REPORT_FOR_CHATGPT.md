# PIV-Q27-P0-v1.7 — SMOKE_GPU

- Run complete: **True**
- Accuracy is real: **False**
- Frozen tasks: **8**
- PIV source commit: `b3d4494892c6d85fa2a35d548271fb02ea3e191b`
- Output-weighted exact: **0.0000**
- Strict task exact: **0.0000**
- Train-perfect program rate: **0.0000**
- Valid-grid rate: **0.0000**

## Causal intervention
Persistent Python REPL + model/tool history + self-contained solution(grid) + fresh all-train exact gate.

## P0 exclusions
No reviewer, no PTQ repair, no second lineage, no NVARC seeding, no judge, no evolution.

## Source-level verification
See `source_level_verification.json` and `SOURCE_ALIGNMENT.json` for SOURCE vs LOCAL boundaries.